/*    */ package android.icu.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class UCharacterCategory
/*    */   implements UCharacterEnums.ECharacterCategory
/*    */ {
/* 15 */   UCharacterCategory() { throw new RuntimeException("Stub!"); }
/* 16 */   public static String toString(int category) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\icu\lang\UCharacterCategory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
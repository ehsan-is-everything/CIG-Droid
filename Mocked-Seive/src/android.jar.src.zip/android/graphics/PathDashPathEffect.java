/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PathDashPathEffect
/*    */   extends PathEffect
/*    */ {
/*    */   public static enum Style
/*    */   {
/* 23 */     MORPH, 
/* 24 */     ROTATE, 
/* 25 */     TRANSLATE;
/*    */     private Style() {} }
/* 27 */   public PathDashPathEffect(Path shape, float advance, float phase, Style style) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\graphics\PathDashPathEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
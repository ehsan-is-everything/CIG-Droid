/*    */ package android.graphics.drawable;
/*    */ 
/*    */ import android.content.res.Resources;
/*    */ import android.util.AttributeSet;
/*    */ import org.xmlpull.v1.XmlPullParser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PaintDrawable
/*    */   extends ShapeDrawable
/*    */ {
/* 21 */   public PaintDrawable() { throw new RuntimeException("Stub!"); }
/* 22 */   public PaintDrawable(int color) { throw new RuntimeException("Stub!"); }
/* 23 */   public void setCornerRadius(float radius) { throw new RuntimeException("Stub!"); }
/* 24 */   public void setCornerRadii(float[] radii) { throw new RuntimeException("Stub!"); }
/* 25 */   protected boolean inflateTag(String name, Resources r, XmlPullParser parser, AttributeSet attrs) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\graphics\drawable\PaintDrawable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
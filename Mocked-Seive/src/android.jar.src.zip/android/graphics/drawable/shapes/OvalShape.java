/*    */ package android.graphics.drawable.shapes;
/*    */ 
/*    */ import android.graphics.Canvas;
/*    */ import android.graphics.Outline;
/*    */ import android.graphics.Paint;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OvalShape
/*    */   extends RectShape
/*    */ {
/* 21 */   public OvalShape() { throw new RuntimeException("Stub!"); }
/* 22 */   public void draw(Canvas canvas, Paint paint) { throw new RuntimeException("Stub!"); }
/* 23 */   public void getOutline(Outline outline) { throw new RuntimeException("Stub!"); }
/* 24 */   public OvalShape clone() throws CloneNotSupportedException { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\graphics\drawable\shapes\OvalShape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PorterDuff
/*    */ {
/*    */   public static enum Mode
/*    */   {
/* 22 */     ADD, 
/* 23 */     CLEAR, 
/* 24 */     DARKEN, 
/* 25 */     DST, 
/* 26 */     DST_ATOP, 
/* 27 */     DST_IN, 
/* 28 */     DST_OUT, 
/* 29 */     DST_OVER, 
/* 30 */     LIGHTEN, 
/* 31 */     MULTIPLY, 
/* 32 */     OVERLAY, 
/* 33 */     SCREEN, 
/* 34 */     SRC, 
/* 35 */     SRC_ATOP, 
/* 36 */     SRC_IN, 
/* 37 */     SRC_OUT, 
/* 38 */     SRC_OVER, 
/* 39 */     XOR;
/*    */     private Mode() {} }
/* 41 */   public PorterDuff() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\graphics\PorterDuff.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
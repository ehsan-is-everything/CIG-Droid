/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PaintFlagsDrawFilter
/*    */   extends DrawFilter
/*    */ {
/*    */   public PaintFlagsDrawFilter(int clearBits, int setBits)
/*    */   {
/* 21 */     throw new RuntimeException("Stub!");
/*    */   }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\graphics\PaintFlagsDrawFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
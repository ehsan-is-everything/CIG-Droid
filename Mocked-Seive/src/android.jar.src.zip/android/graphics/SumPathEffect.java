/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SumPathEffect
/*    */   extends PathEffect
/*    */ {
/*    */   public SumPathEffect(PathEffect first, PathEffect second)
/*    */   {
/* 21 */     throw new RuntimeException("Stub!");
/*    */   }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\graphics\SumPathEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
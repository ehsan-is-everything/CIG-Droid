/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LinearGradient
/*    */   extends Shader
/*    */ {
/* 21 */   public LinearGradient(float x0, float y0, float x1, float y1, int[] colors, float[] positions, Shader.TileMode tile) { throw new RuntimeException("Stub!"); }
/* 22 */   public LinearGradient(float x0, float y0, float x1, float y1, int color0, int color1, Shader.TileMode tile) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\graphics\LinearGradient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
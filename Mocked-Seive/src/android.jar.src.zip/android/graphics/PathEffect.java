/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PathEffect
/*    */ {
/* 20 */   public PathEffect() { throw new RuntimeException("Stub!"); }
/* 21 */   protected void finalize() throws Throwable { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\graphics\PathEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
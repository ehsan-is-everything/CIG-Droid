/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PorterDuffXfermode
/*    */   extends Xfermode
/*    */ {
/*    */   public PorterDuffXfermode(PorterDuff.Mode mode)
/*    */   {
/* 21 */     throw new RuntimeException("Stub!");
/*    */   }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\graphics\PorterDuffXfermode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColorFilter
/*    */ {
/*    */   @Deprecated
/* 26 */   public ColorFilter() { throw new RuntimeException("Stub!"); }
/* 27 */   protected void finalize() throws Throwable { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\graphics\ColorFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
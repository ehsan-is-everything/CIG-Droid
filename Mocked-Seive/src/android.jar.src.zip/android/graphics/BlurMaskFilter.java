/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlurMaskFilter
/*    */   extends MaskFilter
/*    */ {
/*    */   public static enum Blur
/*    */   {
/* 23 */     INNER, 
/* 24 */     NORMAL, 
/* 25 */     OUTER, 
/* 26 */     SOLID;
/*    */     private Blur() {} }
/* 28 */   public BlurMaskFilter(float radius, Blur style) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\graphics\BlurMaskFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
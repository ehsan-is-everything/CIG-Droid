/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Outline
/*    */ {
/* 20 */   public Outline() { throw new RuntimeException("Stub!"); }
/* 21 */   public Outline(Outline src) { throw new RuntimeException("Stub!"); }
/* 22 */   public void setEmpty() { throw new RuntimeException("Stub!"); }
/* 23 */   public boolean isEmpty() { throw new RuntimeException("Stub!"); }
/* 24 */   public boolean canClip() { throw new RuntimeException("Stub!"); }
/* 25 */   public void setAlpha(float alpha) { throw new RuntimeException("Stub!"); }
/* 26 */   public float getAlpha() { throw new RuntimeException("Stub!"); }
/* 27 */   public void set(Outline src) { throw new RuntimeException("Stub!"); }
/* 28 */   public void setRect(int left, int top, int right, int bottom) { throw new RuntimeException("Stub!"); }
/* 29 */   public void setRect(Rect rect) { throw new RuntimeException("Stub!"); }
/* 30 */   public void setRoundRect(int left, int top, int right, int bottom, float radius) { throw new RuntimeException("Stub!"); }
/* 31 */   public void setRoundRect(Rect rect, float radius) { throw new RuntimeException("Stub!"); }
/* 32 */   public boolean getRect(Rect outRect) { throw new RuntimeException("Stub!"); }
/* 33 */   public float getRadius() { throw new RuntimeException("Stub!"); }
/* 34 */   public void setOval(int left, int top, int right, int bottom) { throw new RuntimeException("Stub!"); }
/* 35 */   public void setOval(Rect rect) { throw new RuntimeException("Stub!"); }
/* 36 */   public void setConvexPath(Path convexPath) { throw new RuntimeException("Stub!"); }
/* 37 */   public void offset(int dx, int dy) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\graphics\Outline.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.appwidget;
/*    */ 
/*    */ import android.content.BroadcastReceiver;
/*    */ import android.content.Context;
/*    */ import android.content.Intent;
/*    */ import android.os.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AppWidgetProvider
/*    */   extends BroadcastReceiver
/*    */ {
/* 21 */   public AppWidgetProvider() { throw new RuntimeException("Stub!"); }
/* 22 */   public void onReceive(Context context, Intent intent) { throw new RuntimeException("Stub!"); }
/* 23 */   public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) { throw new RuntimeException("Stub!"); }
/* 24 */   public void onAppWidgetOptionsChanged(Context context, AppWidgetManager appWidgetManager, int appWidgetId, Bundle newOptions) { throw new RuntimeException("Stub!"); }
/* 25 */   public void onDeleted(Context context, int[] appWidgetIds) { throw new RuntimeException("Stub!"); }
/* 26 */   public void onEnabled(Context context) { throw new RuntimeException("Stub!"); }
/* 27 */   public void onDisabled(Context context) { throw new RuntimeException("Stub!"); }
/* 28 */   public void onRestored(Context context, int[] oldWidgetIds, int[] newWidgetIds) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\appwidget\AppWidgetProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
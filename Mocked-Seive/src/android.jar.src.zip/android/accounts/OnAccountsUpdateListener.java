package android.accounts;

public abstract interface OnAccountsUpdateListener
{
  public abstract void onAccountsUpdated(Account[] paramArrayOfAccount);
}


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\accounts\OnAccountsUpdateListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
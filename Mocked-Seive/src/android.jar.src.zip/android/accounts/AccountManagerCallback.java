package android.accounts;

public abstract interface AccountManagerCallback<V>
{
  public abstract void run(AccountManagerFuture<V> paramAccountManagerFuture);
}


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\accounts\AccountManagerCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
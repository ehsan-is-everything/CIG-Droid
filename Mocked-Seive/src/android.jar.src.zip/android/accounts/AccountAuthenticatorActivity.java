/*    */ package android.accounts;
/*    */ 
/*    */ import android.app.Activity;
/*    */ import android.os.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccountAuthenticatorActivity
/*    */   extends Activity
/*    */ {
/* 21 */   public AccountAuthenticatorActivity() { throw new RuntimeException("Stub!"); }
/* 22 */   public final void setAccountAuthenticatorResult(Bundle result) { throw new RuntimeException("Stub!"); }
/* 23 */   protected void onCreate(Bundle icicle) { throw new RuntimeException("Stub!"); }
/* 24 */   public void finish() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\accounts\AccountAuthenticatorActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.accounts;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NetworkErrorException
/*    */   extends AccountsException
/*    */ {
/* 20 */   public NetworkErrorException() { throw new RuntimeException("Stub!"); }
/* 21 */   public NetworkErrorException(String message) { throw new RuntimeException("Stub!"); }
/* 22 */   public NetworkErrorException(String message, Throwable cause) { throw new RuntimeException("Stub!"); }
/* 23 */   public NetworkErrorException(Throwable cause) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\accounts\NetworkErrorException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
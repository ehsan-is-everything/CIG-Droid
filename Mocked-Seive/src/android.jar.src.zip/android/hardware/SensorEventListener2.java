package android.hardware;

public abstract interface SensorEventListener2
  extends SensorEventListener
{
  public abstract void onFlushCompleted(Sensor paramSensor);
}


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\hardware\SensorEventListener2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
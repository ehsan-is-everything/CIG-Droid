/*    */ package android.hardware;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TriggerEventListener
/*    */ {
/*    */   public TriggerEventListener()
/*    */   {
/* 20 */     throw new RuntimeException("Stub!");
/*    */   }
/*    */   
/*    */   public abstract void onTrigger(TriggerEvent paramTriggerEvent);
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\hardware\TriggerEventListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
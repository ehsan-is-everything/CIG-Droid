/*    */ package android.hardware.camera2;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TotalCaptureResult
/*    */   extends CaptureResult
/*    */ {
/* 21 */   TotalCaptureResult() { throw new RuntimeException("Stub!"); }
/* 22 */   public List<CaptureResult> getPartialResults() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\hardware\camera2\TotalCaptureResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
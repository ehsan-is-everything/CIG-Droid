/*    */ package android.hardware.camera2.params;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BlackLevelPattern
/*    */ {
/*    */   public static final int COUNT = 4;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 20 */   BlackLevelPattern() { throw new RuntimeException("Stub!"); }
/* 21 */   public int getOffsetForIndex(int column, int row) { throw new RuntimeException("Stub!"); }
/* 22 */   public void copyTo(int[] destination, int offset) { throw new RuntimeException("Stub!"); }
/* 23 */   public boolean equals(Object obj) { throw new RuntimeException("Stub!"); }
/* 24 */   public int hashCode() { throw new RuntimeException("Stub!"); }
/* 25 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\hardware\camera2\params\BlackLevelPattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.hardware.camera2.params;
/*    */ 
/*    */ import android.util.Rational;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ColorSpaceTransform
/*    */ {
/* 20 */   public ColorSpaceTransform(Rational[] elements) { throw new RuntimeException("Stub!"); }
/* 21 */   public ColorSpaceTransform(int[] elements) { throw new RuntimeException("Stub!"); }
/* 22 */   public Rational getElement(int column, int row) { throw new RuntimeException("Stub!"); }
/* 23 */   public void copyElements(Rational[] destination, int offset) { throw new RuntimeException("Stub!"); }
/* 24 */   public void copyElements(int[] destination, int offset) { throw new RuntimeException("Stub!"); }
/* 25 */   public boolean equals(Object obj) { throw new RuntimeException("Stub!"); }
/* 26 */   public int hashCode() { throw new RuntimeException("Stub!"); }
/* 27 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\hardware\camera2\params\ColorSpaceTransform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
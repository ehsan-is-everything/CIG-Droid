/*    */ package android.hardware;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SensorEvent
/*    */ {
/*    */   public int accuracy;
/*    */   
/*    */ 
/*    */   public Sensor sensor;
/*    */   
/*    */ 
/*    */   public long timestamp;
/*    */   
/*    */ 
/*    */ 
/*    */   SensorEvent()
/*    */   {
/* 20 */     throw new RuntimeException("Stub!");
/*    */   }
/*    */   
/*    */ 
/* 24 */   public final float[] values = null;
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\hardware\SensorEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
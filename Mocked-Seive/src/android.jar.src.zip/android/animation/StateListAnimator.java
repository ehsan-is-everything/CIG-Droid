/*    */ package android.animation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StateListAnimator
/*    */   implements Cloneable
/*    */ {
/* 21 */   public StateListAnimator() { throw new RuntimeException("Stub!"); }
/* 22 */   public void addState(int[] specs, Animator animator) { throw new RuntimeException("Stub!"); }
/* 23 */   public StateListAnimator clone() { throw new RuntimeException("Stub!"); }
/* 24 */   public void jumpToCurrentState() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\animation\StateListAnimator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
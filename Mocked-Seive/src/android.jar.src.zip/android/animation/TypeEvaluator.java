package android.animation;

public abstract interface TypeEvaluator<T>
{
  public abstract T evaluate(float paramFloat, T paramT1, T paramT2);
}


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\animation\TypeEvaluator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
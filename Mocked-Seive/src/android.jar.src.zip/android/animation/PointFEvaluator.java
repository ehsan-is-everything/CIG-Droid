/*    */ package android.animation;
/*    */ 
/*    */ import android.graphics.PointF;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PointFEvaluator
/*    */   implements TypeEvaluator<PointF>
/*    */ {
/* 20 */   public PointFEvaluator() { throw new RuntimeException("Stub!"); }
/* 21 */   public PointFEvaluator(PointF reuse) { throw new RuntimeException("Stub!"); }
/* 22 */   public PointF evaluate(float fraction, PointF startValue, PointF endValue) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\animation\PointFEvaluator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
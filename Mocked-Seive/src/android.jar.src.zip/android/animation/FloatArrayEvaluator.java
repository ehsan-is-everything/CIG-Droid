/*    */ package android.animation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FloatArrayEvaluator
/*    */   implements TypeEvaluator<float[]>
/*    */ {
/* 21 */   public FloatArrayEvaluator() { throw new RuntimeException("Stub!"); }
/* 22 */   public FloatArrayEvaluator(float[] reuseArray) { throw new RuntimeException("Stub!"); }
/* 23 */   public float[] evaluate(float fraction, float[] startValue, float[] endValue) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\animation\FloatArrayEvaluator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
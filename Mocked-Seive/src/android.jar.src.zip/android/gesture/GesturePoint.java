/*    */ package android.gesture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GesturePoint
/*    */ {
/*    */   public final long timestamp;
/*    */   
/*    */ 
/*    */ 
/*    */   public final float x;
/*    */   
/*    */ 
/*    */   public final float y;
/*    */   
/*    */ 
/*    */ 
/* 20 */   public GesturePoint(float x, float y, long t) { throw new RuntimeException("Stub!"); }
/* 21 */   public Object clone() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\gesture\GesturePoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
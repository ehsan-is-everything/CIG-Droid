/*    */ package android.gesture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Prediction
/*    */ {
/*    */   public final String name;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public double score;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 20 */   Prediction() { throw new RuntimeException("Stub!"); }
/* 21 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\gesture\Prediction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
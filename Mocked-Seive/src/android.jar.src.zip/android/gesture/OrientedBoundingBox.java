/*    */ package android.gesture;
/*    */ 
/*    */ 
/*    */ public class OrientedBoundingBox
/*    */ {
/*    */   public final float centerX;
/*    */   
/*    */   public final float centerY;
/*    */   
/*    */   public final float height;
/*    */   
/*    */   public final float orientation;
/*    */   
/*    */   public final float squareness;
/*    */   
/*    */   public final float width;
/*    */   
/*    */   OrientedBoundingBox()
/*    */   {
/* 20 */     throw new RuntimeException("Stub!");
/*    */   }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\gesture\OrientedBoundingBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
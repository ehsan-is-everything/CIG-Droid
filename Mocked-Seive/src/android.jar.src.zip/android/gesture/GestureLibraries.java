/*    */ package android.gesture;
/*    */ 
/*    */ import android.content.Context;
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GestureLibraries
/*    */ {
/* 20 */   GestureLibraries() { throw new RuntimeException("Stub!"); }
/* 21 */   public static GestureLibrary fromFile(String path) { throw new RuntimeException("Stub!"); }
/* 22 */   public static GestureLibrary fromFile(File path) { throw new RuntimeException("Stub!"); }
/* 23 */   public static GestureLibrary fromPrivateFile(Context context, String name) { throw new RuntimeException("Stub!"); }
/* 24 */   public static GestureLibrary fromRawResource(Context context, int resourceId) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\gesture\GestureLibraries.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
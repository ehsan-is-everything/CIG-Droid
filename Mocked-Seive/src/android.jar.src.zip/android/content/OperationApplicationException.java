/*    */ package android.content;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OperationApplicationException
/*    */   extends Exception
/*    */ {
/* 21 */   public OperationApplicationException() { throw new RuntimeException("Stub!"); }
/* 22 */   public OperationApplicationException(String message) { throw new RuntimeException("Stub!"); }
/* 23 */   public OperationApplicationException(String message, Throwable cause) { throw new RuntimeException("Stub!"); }
/* 24 */   public OperationApplicationException(Throwable cause) { throw new RuntimeException("Stub!"); }
/* 25 */   public OperationApplicationException(int numSuccessfulYieldPoints) { throw new RuntimeException("Stub!"); }
/* 26 */   public OperationApplicationException(String message, int numSuccessfulYieldPoints) { throw new RuntimeException("Stub!"); }
/* 27 */   public int getNumSuccessfulYieldPoints() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\content\OperationApplicationException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
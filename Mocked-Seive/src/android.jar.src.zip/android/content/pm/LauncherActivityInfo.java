/*    */ package android.content.pm;
/*    */ 
/*    */ import android.content.ComponentName;
/*    */ import android.graphics.drawable.Drawable;
/*    */ import android.os.UserHandle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LauncherActivityInfo
/*    */ {
/* 20 */   LauncherActivityInfo() { throw new RuntimeException("Stub!"); }
/* 21 */   public ComponentName getComponentName() { throw new RuntimeException("Stub!"); }
/* 22 */   public UserHandle getUser() { throw new RuntimeException("Stub!"); }
/* 23 */   public CharSequence getLabel() { throw new RuntimeException("Stub!"); }
/* 24 */   public Drawable getIcon(int density) { throw new RuntimeException("Stub!"); }
/* 25 */   public ApplicationInfo getApplicationInfo() { throw new RuntimeException("Stub!"); }
/* 26 */   public long getFirstInstallTime() { throw new RuntimeException("Stub!"); }
/* 27 */   public String getName() { throw new RuntimeException("Stub!"); }
/* 28 */   public Drawable getBadgedIcon(int density) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\content\pm\LauncherActivityInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
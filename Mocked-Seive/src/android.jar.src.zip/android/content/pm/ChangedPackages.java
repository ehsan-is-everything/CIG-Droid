/*    */ package android.content.pm;
/*    */ 
/*    */ import android.os.Parcel;
/*    */ import android.os.Parcelable;
/*    */ import android.os.Parcelable.Creator;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ChangedPackages
/*    */   implements Parcelable
/*    */ {
/* 20 */   public ChangedPackages(int sequenceNumber, List<String> packageNames) { throw new RuntimeException("Stub!"); }
/* 21 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/* 22 */   public void writeToParcel(Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/* 23 */   public int getSequenceNumber() { throw new RuntimeException("Stub!"); }
/* 24 */   public List<String> getPackageNames() { throw new RuntimeException("Stub!"); }
/*    */   
/* 26 */   public static final Parcelable.Creator<ChangedPackages> CREATOR = null;
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\content\pm\ChangedPackages.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
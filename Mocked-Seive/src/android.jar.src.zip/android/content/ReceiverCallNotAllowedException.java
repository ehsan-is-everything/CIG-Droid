/*    */ package android.content;
/*    */ 
/*    */ import android.util.AndroidRuntimeException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReceiverCallNotAllowedException
/*    */   extends AndroidRuntimeException
/*    */ {
/*    */   public ReceiverCallNotAllowedException(String msg)
/*    */   {
/* 21 */     throw new RuntimeException("Stub!");
/*    */   }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\content\ReceiverCallNotAllowedException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
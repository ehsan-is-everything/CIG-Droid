/*    */ package android.content;
/*    */ 
/*    */ import android.os.IBinder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SyncContext
/*    */ {
/* 20 */   SyncContext() { throw new RuntimeException("Stub!"); }
/* 21 */   public void onFinished(SyncResult result) { throw new RuntimeException("Stub!"); }
/* 22 */   public IBinder getSyncContextBinder() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\content\SyncContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
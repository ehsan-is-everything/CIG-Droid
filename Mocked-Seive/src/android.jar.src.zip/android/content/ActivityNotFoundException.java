/*    */ package android.content;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActivityNotFoundException
/*    */   extends RuntimeException
/*    */ {
/* 21 */   public ActivityNotFoundException() { throw new RuntimeException("Stub!"); }
/* 22 */   public ActivityNotFoundException(String name) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\content\ActivityNotFoundException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
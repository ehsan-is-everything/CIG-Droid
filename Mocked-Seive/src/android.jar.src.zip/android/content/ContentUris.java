/*    */ package android.content;
/*    */ 
/*    */ import android.net.Uri;
/*    */ import android.net.Uri.Builder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentUris
/*    */ {
/* 20 */   public ContentUris() { throw new RuntimeException("Stub!"); }
/* 21 */   public static long parseId(Uri contentUri) { throw new RuntimeException("Stub!"); }
/* 22 */   public static Uri.Builder appendId(Uri.Builder builder, long id) { throw new RuntimeException("Stub!"); }
/* 23 */   public static Uri withAppendedId(Uri contentUri, long id) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\content\ContentUris.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
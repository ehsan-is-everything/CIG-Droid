/*    */ package android.content;
/*    */ 
/*    */ import android.net.Uri;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UriMatcher
/*    */ {
/*    */   public static final int NO_MATCH = -1;
/*    */   
/* 20 */   public UriMatcher(int code) { throw new RuntimeException("Stub!"); }
/* 21 */   public void addURI(String authority, String path, int code) { throw new RuntimeException("Stub!"); }
/* 22 */   public int match(Uri uri) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\content\UriMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
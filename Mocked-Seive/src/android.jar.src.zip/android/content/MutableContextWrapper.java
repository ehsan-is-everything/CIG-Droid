/*    */ package android.content;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MutableContextWrapper
/*    */   extends ContextWrapper
/*    */ {
/*    */   public MutableContextWrapper(Context base)
/*    */   {
/* 21 */     super((Context)null);throw new RuntimeException("Stub!"); }
/* 22 */   public void setBaseContext(Context base) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\content\MutableContextWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
package android.content;

public abstract interface SyncStatusObserver
{
  public abstract void onStatusChanged(int paramInt);
}


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\content\SyncStatusObserver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
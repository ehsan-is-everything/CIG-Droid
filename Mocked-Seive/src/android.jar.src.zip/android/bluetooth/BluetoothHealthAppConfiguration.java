/*    */ package android.bluetooth;
/*    */ 
/*    */ import android.os.Parcel;
/*    */ import android.os.Parcelable;
/*    */ import android.os.Parcelable.Creator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BluetoothHealthAppConfiguration
/*    */   implements Parcelable
/*    */ {
/* 22 */   BluetoothHealthAppConfiguration() { throw new RuntimeException("Stub!"); }
/* 23 */   public boolean equals(Object o) { throw new RuntimeException("Stub!"); }
/* 24 */   public int hashCode() { throw new RuntimeException("Stub!"); }
/* 25 */   public String toString() { throw new RuntimeException("Stub!"); }
/* 26 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/* 27 */   public int getDataType() { throw new RuntimeException("Stub!"); }
/* 28 */   public String getName() { throw new RuntimeException("Stub!"); }
/* 29 */   public int getRole() { throw new RuntimeException("Stub!"); }
/* 30 */   public void writeToParcel(Parcel out, int flags) { throw new RuntimeException("Stub!"); }
/*    */   
/* 32 */   public static final Parcelable.Creator<BluetoothHealthAppConfiguration> CREATOR = null;
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\bluetooth\BluetoothHealthAppConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
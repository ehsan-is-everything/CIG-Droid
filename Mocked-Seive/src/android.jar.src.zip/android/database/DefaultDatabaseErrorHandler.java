/*    */ package android.database;
/*    */ 
/*    */ import android.database.sqlite.SQLiteDatabase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultDatabaseErrorHandler
/*    */   implements DatabaseErrorHandler
/*    */ {
/* 20 */   public DefaultDatabaseErrorHandler() { throw new RuntimeException("Stub!"); }
/* 21 */   public void onCorruption(SQLiteDatabase dbObj) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\database\DefaultDatabaseErrorHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
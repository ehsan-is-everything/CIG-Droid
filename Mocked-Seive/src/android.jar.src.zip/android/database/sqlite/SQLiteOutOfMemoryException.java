/*    */ package android.database.sqlite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLiteOutOfMemoryException
/*    */   extends SQLiteException
/*    */ {
/* 21 */   public SQLiteOutOfMemoryException() { throw new RuntimeException("Stub!"); }
/* 22 */   public SQLiteOutOfMemoryException(String error) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\database\sqlite\SQLiteOutOfMemoryException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
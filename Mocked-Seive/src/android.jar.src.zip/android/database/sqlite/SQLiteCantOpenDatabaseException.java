/*    */ package android.database.sqlite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLiteCantOpenDatabaseException
/*    */   extends SQLiteException
/*    */ {
/* 21 */   public SQLiteCantOpenDatabaseException() { throw new RuntimeException("Stub!"); }
/* 22 */   public SQLiteCantOpenDatabaseException(String error) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\database\sqlite\SQLiteCantOpenDatabaseException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
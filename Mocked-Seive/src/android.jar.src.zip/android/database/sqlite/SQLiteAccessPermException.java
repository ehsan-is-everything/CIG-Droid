/*    */ package android.database.sqlite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLiteAccessPermException
/*    */   extends SQLiteException
/*    */ {
/* 21 */   public SQLiteAccessPermException() { throw new RuntimeException("Stub!"); }
/* 22 */   public SQLiteAccessPermException(String error) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\database\sqlite\SQLiteAccessPermException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
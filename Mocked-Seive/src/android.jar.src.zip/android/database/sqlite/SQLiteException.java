/*    */ package android.database.sqlite;
/*    */ 
/*    */ import android.database.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLiteException
/*    */   extends SQLException
/*    */ {
/* 21 */   public SQLiteException() { throw new RuntimeException("Stub!"); }
/* 22 */   public SQLiteException(String error) { throw new RuntimeException("Stub!"); }
/* 23 */   public SQLiteException(String error, Throwable cause) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\database\sqlite\SQLiteException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
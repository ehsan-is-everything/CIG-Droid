/*    */ package android.database.sqlite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SQLiteQuery
/*    */   extends SQLiteProgram
/*    */ {
/* 21 */   SQLiteQuery() { throw new RuntimeException("Stub!"); }
/* 22 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\database\sqlite\SQLiteQuery.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
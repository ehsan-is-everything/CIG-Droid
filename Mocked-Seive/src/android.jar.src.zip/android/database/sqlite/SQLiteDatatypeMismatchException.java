/*    */ package android.database.sqlite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLiteDatatypeMismatchException
/*    */   extends SQLiteException
/*    */ {
/* 21 */   public SQLiteDatatypeMismatchException() { throw new RuntimeException("Stub!"); }
/* 22 */   public SQLiteDatatypeMismatchException(String error) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\database\sqlite\SQLiteDatatypeMismatchException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
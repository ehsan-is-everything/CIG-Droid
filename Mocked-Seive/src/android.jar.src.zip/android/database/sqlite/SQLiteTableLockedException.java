/*    */ package android.database.sqlite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLiteTableLockedException
/*    */   extends SQLiteException
/*    */ {
/* 21 */   public SQLiteTableLockedException() { throw new RuntimeException("Stub!"); }
/* 22 */   public SQLiteTableLockedException(String error) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\database\sqlite\SQLiteTableLockedException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.database;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CursorIndexOutOfBoundsException
/*    */   extends IndexOutOfBoundsException
/*    */ {
/* 21 */   public CursorIndexOutOfBoundsException(int index, int size) { throw new RuntimeException("Stub!"); }
/* 22 */   public CursorIndexOutOfBoundsException(String message) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\database\CursorIndexOutOfBoundsException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
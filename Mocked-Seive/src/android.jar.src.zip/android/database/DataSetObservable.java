/*    */ package android.database;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataSetObservable
/*    */   extends Observable<DataSetObserver>
/*    */ {
/* 21 */   public DataSetObservable() { throw new RuntimeException("Stub!"); }
/* 22 */   public void notifyChanged() { throw new RuntimeException("Stub!"); }
/* 23 */   public void notifyInvalidated() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\database\DataSetObservable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
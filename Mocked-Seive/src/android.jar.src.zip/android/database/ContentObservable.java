/*    */ package android.database;
/*    */ 
/*    */ import android.net.Uri;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentObservable
/*    */   extends Observable<ContentObserver>
/*    */ {
/* 21 */   public ContentObservable() { throw new RuntimeException("Stub!"); }
/* 22 */   public void registerObserver(ContentObserver observer) { throw new RuntimeException("Stub!"); }
/*    */   @Deprecated
/* 24 */   public void dispatchChange(boolean selfChange) { throw new RuntimeException("Stub!"); }
/* 25 */   public void dispatchChange(boolean selfChange, Uri uri) { throw new RuntimeException("Stub!"); }
/*    */   @Deprecated
/* 27 */   public void notifyChange(boolean selfChange) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\database\ContentObservable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
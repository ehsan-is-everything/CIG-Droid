/*    */ package android.drm;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DrmRights
/*    */ {
/* 20 */   public DrmRights(String rightsFilePath, String mimeType) { throw new RuntimeException("Stub!"); }
/* 21 */   public DrmRights(String rightsFilePath, String mimeType, String accountId) { throw new RuntimeException("Stub!"); }
/* 22 */   public DrmRights(String rightsFilePath, String mimeType, String accountId, String subscriptionId) { throw new RuntimeException("Stub!"); }
/* 23 */   public DrmRights(File rightsFile, String mimeType) { throw new RuntimeException("Stub!"); }
/* 24 */   public DrmRights(ProcessedData data, String mimeType) { throw new RuntimeException("Stub!"); }
/* 25 */   public byte[] getData() { throw new RuntimeException("Stub!"); }
/* 26 */   public String getMimeType() { throw new RuntimeException("Stub!"); }
/* 27 */   public String getAccountId() { throw new RuntimeException("Stub!"); }
/* 28 */   public String getSubscriptionId() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\drm\DrmRights.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
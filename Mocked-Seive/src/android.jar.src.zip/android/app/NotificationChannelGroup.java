/*    */ package android.app;
/*    */ 
/*    */ import android.os.Parcel;
/*    */ import android.os.Parcelable;
/*    */ import android.os.Parcelable.Creator;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NotificationChannelGroup
/*    */   implements Parcelable
/*    */ {
/* 20 */   public NotificationChannelGroup(String id, CharSequence name) { throw new RuntimeException("Stub!"); }
/* 21 */   public void writeToParcel(Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/* 22 */   public String getId() { throw new RuntimeException("Stub!"); }
/* 23 */   public CharSequence getName() { throw new RuntimeException("Stub!"); }
/* 24 */   public List<NotificationChannel> getChannels() { throw new RuntimeException("Stub!"); }
/* 25 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/* 26 */   public boolean equals(Object o) { throw new RuntimeException("Stub!"); }
/* 27 */   public NotificationChannelGroup clone() { throw new RuntimeException("Stub!"); }
/* 28 */   public int hashCode() { throw new RuntimeException("Stub!"); }
/* 29 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */   
/* 31 */   public static final Parcelable.Creator<NotificationChannelGroup> CREATOR = null;
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\app\NotificationChannelGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
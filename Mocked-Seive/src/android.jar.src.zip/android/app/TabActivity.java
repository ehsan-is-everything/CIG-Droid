/*    */ package android.app;
/*    */ 
/*    */ import android.os.Bundle;
/*    */ import android.widget.TabHost;
/*    */ import android.widget.TabWidget;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class TabActivity
/*    */   extends ActivityGroup
/*    */ {
/* 22 */   public TabActivity() { throw new RuntimeException("Stub!"); }
/* 23 */   public void setDefaultTab(String tag) { throw new RuntimeException("Stub!"); }
/* 24 */   public void setDefaultTab(int index) { throw new RuntimeException("Stub!"); }
/* 25 */   protected void onRestoreInstanceState(Bundle state) { throw new RuntimeException("Stub!"); }
/* 26 */   protected void onPostCreate(Bundle icicle) { throw new RuntimeException("Stub!"); }
/* 27 */   protected void onSaveInstanceState(Bundle outState) { throw new RuntimeException("Stub!"); }
/* 28 */   public void onContentChanged() { throw new RuntimeException("Stub!"); }
/* 29 */   protected void onChildTitleChanged(Activity childActivity, CharSequence title) { throw new RuntimeException("Stub!"); }
/* 30 */   public TabHost getTabHost() { throw new RuntimeException("Stub!"); }
/* 31 */   public TabWidget getTabWidget() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\app\TabActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.app;
/*    */ 
/*    */ import android.os.Bundle;
/*    */ import android.view.LayoutInflater;
/*    */ import android.view.View;
/*    */ import android.view.ViewGroup;
/*    */ import android.widget.ListAdapter;
/*    */ import android.widget.ListView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ListFragment
/*    */   extends Fragment
/*    */ {
/* 21 */   public ListFragment() { throw new RuntimeException("Stub!"); }
/* 22 */   public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) { throw new RuntimeException("Stub!"); }
/* 23 */   public void onViewCreated(View view, Bundle savedInstanceState) { throw new RuntimeException("Stub!"); }
/* 24 */   public void onDestroyView() { throw new RuntimeException("Stub!"); }
/* 25 */   public void onListItemClick(ListView l, View v, int position, long id) { throw new RuntimeException("Stub!"); }
/* 26 */   public void setListAdapter(ListAdapter adapter) { throw new RuntimeException("Stub!"); }
/* 27 */   public void setSelection(int position) { throw new RuntimeException("Stub!"); }
/* 28 */   public int getSelectedItemPosition() { throw new RuntimeException("Stub!"); }
/* 29 */   public long getSelectedItemId() { throw new RuntimeException("Stub!"); }
/* 30 */   public ListView getListView() { throw new RuntimeException("Stub!"); }
/* 31 */   public void setEmptyText(CharSequence text) { throw new RuntimeException("Stub!"); }
/* 32 */   public void setListShown(boolean shown) { throw new RuntimeException("Stub!"); }
/* 33 */   public void setListShownNoAnimation(boolean shown) { throw new RuntimeException("Stub!"); }
/* 34 */   public ListAdapter getListAdapter() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\app\ListFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
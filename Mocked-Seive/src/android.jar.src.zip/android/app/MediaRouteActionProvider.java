/*    */ package android.app;
/*    */ 
/*    */ import android.content.Context;
/*    */ import android.view.ActionProvider;
/*    */ import android.view.MenuItem;
/*    */ import android.view.View;
/*    */ import android.view.View.OnClickListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MediaRouteActionProvider
/*    */   extends ActionProvider
/*    */ {
/*    */   public MediaRouteActionProvider(Context context)
/*    */   {
/* 21 */     super((Context)null);throw new RuntimeException("Stub!"); }
/* 22 */   public void setRouteTypes(int types) { throw new RuntimeException("Stub!"); }
/* 23 */   public void setExtendedSettingsClickListener(View.OnClickListener listener) { throw new RuntimeException("Stub!"); }
/*    */   
/* 25 */   public View onCreateActionView() { throw new RuntimeException("Stub!"); }
/* 26 */   public View onCreateActionView(MenuItem item) { throw new RuntimeException("Stub!"); }
/* 27 */   public boolean onPerformDefaultAction() { throw new RuntimeException("Stub!"); }
/* 28 */   public boolean overridesItemVisibility() { throw new RuntimeException("Stub!"); }
/* 29 */   public boolean isVisible() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\app\MediaRouteActionProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
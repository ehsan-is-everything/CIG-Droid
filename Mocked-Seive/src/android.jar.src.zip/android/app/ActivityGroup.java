/*    */ package android.app;
/*    */ 
/*    */ import android.os.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ActivityGroup
/*    */   extends Activity
/*    */ {
/* 22 */   public ActivityGroup() { throw new RuntimeException("Stub!"); }
/* 23 */   public ActivityGroup(boolean singleActivityMode) { throw new RuntimeException("Stub!"); }
/* 24 */   protected void onCreate(Bundle savedInstanceState) { throw new RuntimeException("Stub!"); }
/* 25 */   protected void onResume() { throw new RuntimeException("Stub!"); }
/* 26 */   protected void onSaveInstanceState(Bundle outState) { throw new RuntimeException("Stub!"); }
/* 27 */   protected void onPause() { throw new RuntimeException("Stub!"); }
/* 28 */   protected void onStop() { throw new RuntimeException("Stub!"); }
/* 29 */   protected void onDestroy() { throw new RuntimeException("Stub!"); }
/* 30 */   public Activity getCurrentActivity() { throw new RuntimeException("Stub!"); }
/* 31 */   public final LocalActivityManager getLocalActivityManager() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\app\ActivityGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
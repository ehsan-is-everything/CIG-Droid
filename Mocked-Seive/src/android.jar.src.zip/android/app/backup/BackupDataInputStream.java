/*    */ package android.app.backup;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BackupDataInputStream
/*    */   extends InputStream
/*    */ {
/* 21 */   BackupDataInputStream() { throw new RuntimeException("Stub!"); }
/* 22 */   public int read() throws IOException { throw new RuntimeException("Stub!"); }
/* 23 */   public int read(byte[] b, int offset, int size) throws IOException { throw new RuntimeException("Stub!"); }
/* 24 */   public int read(byte[] b) throws IOException { throw new RuntimeException("Stub!"); }
/* 25 */   public String getKey() { throw new RuntimeException("Stub!"); }
/* 26 */   public int size() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\app\backup\BackupDataInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
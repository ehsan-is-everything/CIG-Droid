/*    */ package android.app.backup;
/*    */ 
/*    */ import android.content.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BackupManager
/*    */ {
/* 20 */   public BackupManager(Context context) { throw new RuntimeException("Stub!"); }
/* 21 */   public void dataChanged() { throw new RuntimeException("Stub!"); }
/* 22 */   public static void dataChanged(String packageName) { throw new RuntimeException("Stub!"); }
/* 23 */   public int requestRestore(RestoreObserver observer) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\app\backup\BackupManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
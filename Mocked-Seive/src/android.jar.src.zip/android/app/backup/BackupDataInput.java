/*    */ package android.app.backup;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BackupDataInput
/*    */ {
/* 20 */   BackupDataInput() { throw new RuntimeException("Stub!"); }
/* 21 */   public boolean readNextHeader() throws IOException { throw new RuntimeException("Stub!"); }
/* 22 */   public String getKey() { throw new RuntimeException("Stub!"); }
/* 23 */   public int getDataSize() { throw new RuntimeException("Stub!"); }
/* 24 */   public int readEntityData(byte[] data, int offset, int size) throws IOException { throw new RuntimeException("Stub!"); }
/* 25 */   public void skipEntityData() throws IOException { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\app\backup\BackupDataInput.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
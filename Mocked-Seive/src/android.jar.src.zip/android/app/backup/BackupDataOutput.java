/*    */ package android.app.backup;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BackupDataOutput
/*    */ {
/* 20 */   BackupDataOutput() { throw new RuntimeException("Stub!"); }
/* 21 */   public long getQuota() { throw new RuntimeException("Stub!"); }
/* 22 */   public int writeEntityHeader(String key, int dataSize) throws IOException { throw new RuntimeException("Stub!"); }
/* 23 */   public int writeEntityData(byte[] data, int size) throws IOException { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\app\backup\BackupDataOutput.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
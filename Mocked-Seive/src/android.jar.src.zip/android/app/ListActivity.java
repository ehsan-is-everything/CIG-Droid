/*    */ package android.app;
/*    */ 
/*    */ import android.os.Bundle;
/*    */ import android.view.View;
/*    */ import android.widget.ListAdapter;
/*    */ import android.widget.ListView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ListActivity
/*    */   extends Activity
/*    */ {
/* 21 */   public ListActivity() { throw new RuntimeException("Stub!"); }
/* 22 */   protected void onListItemClick(ListView l, View v, int position, long id) { throw new RuntimeException("Stub!"); }
/* 23 */   protected void onRestoreInstanceState(Bundle state) { throw new RuntimeException("Stub!"); }
/* 24 */   protected void onDestroy() { throw new RuntimeException("Stub!"); }
/* 25 */   public void onContentChanged() { throw new RuntimeException("Stub!"); }
/* 26 */   public void setListAdapter(ListAdapter adapter) { throw new RuntimeException("Stub!"); }
/* 27 */   public void setSelection(int position) { throw new RuntimeException("Stub!"); }
/* 28 */   public int getSelectedItemPosition() { throw new RuntimeException("Stub!"); }
/* 29 */   public long getSelectedItemId() { throw new RuntimeException("Stub!"); }
/* 30 */   public ListView getListView() { throw new RuntimeException("Stub!"); }
/* 31 */   public ListAdapter getListAdapter() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Mahmoud\Desktop\android.jar!\android\app\ListActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
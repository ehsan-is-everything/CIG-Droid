package android.filterfw.io;

public class GraphIOException
  extends Exception
{
  public GraphIOException() {}
  
  public GraphIOException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\filterfw\io\GraphIOException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.filterfw;

import android.filterfw.core.Filter;
import android.filterfw.core.FilterFactory;
import android.filterfw.core.FilterFunction;
import android.filterfw.core.FrameManager;

public class FilterFunctionEnvironment
  extends MffEnvironment
{
  public FilterFunctionEnvironment()
  {
    super(null);
  }
  
  public FilterFunctionEnvironment(FrameManager paramFrameManager)
  {
    super(paramFrameManager);
  }
  
  public FilterFunction createFunction(Class paramClass, Object... paramVarArgs)
  {
    String str = "FilterFunction(" + paramClass.getSimpleName() + ")";
    Filter localFilter = FilterFactory.sharedFactory().createFilterByClass(paramClass, str);
    localFilter.initWithAssignmentList(paramVarArgs);
    return new FilterFunction(getContext(), localFilter);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\filterfw\FilterFunctionEnvironment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
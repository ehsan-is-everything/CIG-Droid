package android.filterfw.core;

import java.lang.reflect.Field;

public class FieldPort
  extends InputPort
{
  protected Field mField;
  protected boolean mHasFrame;
  protected Object mValue;
  protected boolean mValueWaiting = false;
  
  public FieldPort(Filter paramFilter, String paramString, Field paramField, boolean paramBoolean)
  {
    super(paramFilter, paramString);
    this.mField = paramField;
    this.mHasFrame = paramBoolean;
  }
  
  /* Error */
  public boolean acceptsFrame()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 18	android/filterfw/core/FieldPort:mValueWaiting	Z
    //   6: istore_2
    //   7: iload_2
    //   8: ifne +9 -> 17
    //   11: iconst_1
    //   12: istore_3
    //   13: aload_0
    //   14: monitorexit
    //   15: iload_3
    //   16: ireturn
    //   17: iconst_0
    //   18: istore_3
    //   19: goto -6 -> 13
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	27	0	this	FieldPort
    //   22	4	1	localObject	Object
    //   6	2	2	bool1	boolean
    //   12	7	3	bool2	boolean
    // Exception table:
    //   from	to	target	type
    //   2	7	22	finally
  }
  
  public void clear() {}
  
  public Object getTarget()
  {
    try
    {
      Object localObject = this.mField.get(this.mFilter);
      return localObject;
    }
    catch (IllegalAccessException localIllegalAccessException) {}
    return null;
  }
  
  public boolean hasFrame()
  {
    try
    {
      boolean bool = this.mHasFrame;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public Frame pullFrame()
  {
    try
    {
      throw new RuntimeException("Cannot pull frame on " + this + "!");
    }
    finally {}
  }
  
  public void pushFrame(Frame paramFrame)
  {
    setFieldFrame(paramFrame, false);
  }
  
  protected void setFieldFrame(Frame paramFrame, boolean paramBoolean)
  {
    try
    {
      assertPortIsOpen();
      checkFrameType(paramFrame, paramBoolean);
      Object localObject2 = paramFrame.getObjectValue();
      if (((localObject2 == null) && (this.mValue != null)) || (!localObject2.equals(this.mValue)))
      {
        this.mValue = localObject2;
        this.mValueWaiting = true;
      }
      this.mHasFrame = true;
      return;
    }
    finally {}
  }
  
  public void setFrame(Frame paramFrame)
  {
    setFieldFrame(paramFrame, true);
  }
  
  public String toString()
  {
    return "field " + super.toString();
  }
  
  /* Error */
  public void transfer(FilterContext paramFilterContext)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 18	android/filterfw/core/FieldPort:mValueWaiting	Z
    //   6: istore_3
    //   7: iload_3
    //   8: ifeq +39 -> 47
    //   11: aload_0
    //   12: getfield 20	android/filterfw/core/FieldPort:mField	Ljava/lang/reflect/Field;
    //   15: aload_0
    //   16: getfield 36	android/filterfw/core/FilterPort:mFilter	Landroid/filterfw/core/Filter;
    //   19: aload_0
    //   20: getfield 88	android/filterfw/core/FieldPort:mValue	Ljava/lang/Object;
    //   23: invokevirtual 104	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   26: aload_0
    //   27: iconst_0
    //   28: putfield 18	android/filterfw/core/FieldPort:mValueWaiting	Z
    //   31: aload_1
    //   32: ifnull +15 -> 47
    //   35: aload_0
    //   36: getfield 36	android/filterfw/core/FilterPort:mFilter	Landroid/filterfw/core/Filter;
    //   39: aload_0
    //   40: getfield 108	android/filterfw/core/FilterPort:mName	Ljava/lang/String;
    //   43: aload_1
    //   44: invokevirtual 114	android/filterfw/core/Filter:notifyFieldPortValueUpdated	(Ljava/lang/String;Landroid/filterfw/core/FilterContext;)V
    //   47: aload_0
    //   48: monitorexit
    //   49: return
    //   50: astore 4
    //   52: new 47	java/lang/RuntimeException
    //   55: dup
    //   56: new 49	java/lang/StringBuilder
    //   59: dup
    //   60: invokespecial 51	java/lang/StringBuilder:<init>	()V
    //   63: ldc 116
    //   65: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: aload_0
    //   69: getfield 20	android/filterfw/core/FieldPort:mField	Ljava/lang/reflect/Field;
    //   72: invokevirtual 119	java/lang/reflect/Field:getName	()Ljava/lang/String;
    //   75: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   78: ldc 121
    //   80: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   83: invokevirtual 66	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   86: invokespecial 69	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   89: athrow
    //   90: astore_2
    //   91: aload_0
    //   92: monitorexit
    //   93: aload_2
    //   94: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	95	0	this	FieldPort
    //   0	95	1	paramFilterContext	FilterContext
    //   90	4	2	localObject	Object
    //   6	2	3	bool	boolean
    //   50	1	4	localIllegalAccessException	IllegalAccessException
    // Exception table:
    //   from	to	target	type
    //   11	26	50	java/lang/IllegalAccessException
    //   2	7	90	finally
    //   11	26	90	finally
    //   26	31	90	finally
    //   35	47	90	finally
    //   52	90	90	finally
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\filterfw\core\FieldPort.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
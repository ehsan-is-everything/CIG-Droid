package android.filterfw.core;

import android.util.Log;
import dalvik.system.PathClassLoader;
import java.util.HashSet;
import java.util.Iterator;

public class FilterFactory
{
  private static final String TAG = "FilterFactory";
  private static Object mClassLoaderGuard = new Object();
  private static ClassLoader mCurrentClassLoader = Thread.currentThread().getContextClassLoader();
  private static HashSet<String> mLibraries = new HashSet();
  private static boolean mLogVerbose = Log.isLoggable("FilterFactory", 2);
  private static FilterFactory mSharedFactory;
  private HashSet<String> mPackages = new HashSet();
  
  public static void addFilterLibrary(String paramString)
  {
    if (mLogVerbose) {
      Log.v("FilterFactory", "Adding filter library " + paramString);
    }
    synchronized (mClassLoaderGuard)
    {
      if (mLibraries.contains(paramString))
      {
        if (mLogVerbose) {
          Log.v("FilterFactory", "Library already added");
        }
        return;
      }
      mLibraries.add(paramString);
      mCurrentClassLoader = new PathClassLoader(paramString, mCurrentClassLoader);
      return;
    }
  }
  
  public static FilterFactory sharedFactory()
  {
    if (mSharedFactory == null) {
      mSharedFactory = new FilterFactory();
    }
    return mSharedFactory;
  }
  
  public void addPackage(String paramString)
  {
    if (mLogVerbose) {
      Log.v("FilterFactory", "Adding package " + paramString);
    }
    this.mPackages.add(paramString);
  }
  
  /* Error */
  public Filter createFilterByClass(Class paramClass, String paramString)
  {
    // Byte code:
    //   0: aload_1
    //   1: ldc 105
    //   3: invokevirtual 111	java/lang/Class:asSubclass	(Ljava/lang/Class;)Ljava/lang/Class;
    //   6: pop
    //   7: aload_1
    //   8: iconst_1
    //   9: anewarray 107	java/lang/Class
    //   12: dup
    //   13: iconst_0
    //   14: ldc 113
    //   16: aastore
    //   17: invokevirtual 117	java/lang/Class:getConstructor	([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    //   20: astore 6
    //   22: aload 6
    //   24: iconst_1
    //   25: anewarray 4	java/lang/Object
    //   28: dup
    //   29: iconst_0
    //   30: aload_2
    //   31: aastore
    //   32: invokevirtual 123	java/lang/reflect/Constructor:newInstance	([Ljava/lang/Object;)Ljava/lang/Object;
    //   35: checkcast 105	android/filterfw/core/Filter
    //   38: astore 8
    //   40: aload 8
    //   42: ifnonnull +102 -> 144
    //   45: new 125	java/lang/IllegalArgumentException
    //   48: dup
    //   49: new 58	java/lang/StringBuilder
    //   52: dup
    //   53: invokespecial 59	java/lang/StringBuilder:<init>	()V
    //   56: ldc 127
    //   58: invokevirtual 65	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   61: aload_2
    //   62: invokevirtual 65	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   65: ldc -127
    //   67: invokevirtual 65	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   70: invokevirtual 69	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   73: invokespecial 131	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   76: athrow
    //   77: astore_3
    //   78: new 125	java/lang/IllegalArgumentException
    //   81: dup
    //   82: new 58	java/lang/StringBuilder
    //   85: dup
    //   86: invokespecial 59	java/lang/StringBuilder:<init>	()V
    //   89: ldc -123
    //   91: invokevirtual 65	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   94: aload_1
    //   95: invokevirtual 136	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   98: ldc -118
    //   100: invokevirtual 65	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: invokevirtual 69	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   106: invokespecial 131	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   109: athrow
    //   110: astore 5
    //   112: new 125	java/lang/IllegalArgumentException
    //   115: dup
    //   116: new 58	java/lang/StringBuilder
    //   119: dup
    //   120: invokespecial 59	java/lang/StringBuilder:<init>	()V
    //   123: ldc -116
    //   125: invokevirtual 65	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   128: aload_1
    //   129: invokevirtual 136	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   132: ldc -114
    //   134: invokevirtual 65	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   137: invokevirtual 69	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   140: invokespecial 131	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   143: athrow
    //   144: aload 8
    //   146: areturn
    //   147: astore 7
    //   149: aconst_null
    //   150: astore 8
    //   152: goto -112 -> 40
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	155	0	this	FilterFactory
    //   0	155	1	paramClass	Class
    //   0	155	2	paramString	String
    //   77	1	3	localClassCastException	ClassCastException
    //   110	1	5	localNoSuchMethodException	NoSuchMethodException
    //   20	3	6	localConstructor	java.lang.reflect.Constructor
    //   147	1	7	localThrowable	Throwable
    //   38	113	8	localFilter	Filter
    // Exception table:
    //   from	to	target	type
    //   0	7	77	java/lang/ClassCastException
    //   7	22	110	java/lang/NoSuchMethodException
    //   22	40	147	java/lang/Throwable
  }
  
  public Filter createFilterByClassName(String paramString1, String paramString2)
  {
    if (mLogVerbose) {
      Log.v("FilterFactory", "Looking up class " + paramString1);
    }
    Class localClass = null;
    Iterator localIterator = this.mPackages.iterator();
    for (;;)
    {
      String str;
      if (localIterator.hasNext()) {
        str = (String)localIterator.next();
      }
      try
      {
        if (mLogVerbose) {
          Log.v("FilterFactory", "Trying " + str + "." + paramString1);
        }
        synchronized (mClassLoaderGuard)
        {
          localClass = mCurrentClassLoader.loadClass(str + "." + paramString1);
          if (localClass != null) {
            if (localClass == null) {
              throw new IllegalArgumentException("Unknown filter class '" + paramString1 + "'!");
            }
          }
        }
      }
      catch (ClassNotFoundException localClassNotFoundException) {}
    }
    return createFilterByClass(localClass, paramString2);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\filterfw\core\FilterFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.filterfw.core;

import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import java.util.Vector;

public class RandomScheduler
  extends Scheduler
{
  private Random mRand = new Random();
  
  public RandomScheduler(FilterGraph paramFilterGraph)
  {
    super(paramFilterGraph);
  }
  
  public void reset() {}
  
  public Filter scheduleNextNode()
  {
    Vector localVector = new Vector();
    Iterator localIterator = getGraph().getFilters().iterator();
    while (localIterator.hasNext())
    {
      Filter localFilter = (Filter)localIterator.next();
      if (localFilter.canProcess()) {
        localVector.add(localFilter);
      }
    }
    if (localVector.size() > 0) {
      return (Filter)localVector.elementAt(this.mRand.nextInt(localVector.size()));
    }
    return null;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\filterfw\core\RandomScheduler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.filterfw.core;

class GLFrameTimer
{
  private static StopWatchMap mTimer = null;
  
  public static StopWatchMap get()
  {
    if (mTimer == null) {
      mTimer = new StopWatchMap();
    }
    return mTimer;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\filterfw\core\GLFrameTimer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
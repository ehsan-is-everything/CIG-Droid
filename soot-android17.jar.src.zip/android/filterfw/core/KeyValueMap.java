package android.filterfw.core;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class KeyValueMap
  extends HashMap<String, Object>
{
  public static KeyValueMap fromKeyValues(Object... paramVarArgs)
  {
    KeyValueMap localKeyValueMap = new KeyValueMap();
    localKeyValueMap.setKeyValues(paramVarArgs);
    return localKeyValueMap;
  }
  
  public float getFloat(String paramString)
  {
    Object localObject = get(paramString);
    if (localObject != null) {}
    for (Float localFloat = (Float)localObject;; localFloat = null) {
      return localFloat.floatValue();
    }
  }
  
  public int getInt(String paramString)
  {
    Object localObject = get(paramString);
    if (localObject != null) {}
    for (Integer localInteger = (Integer)localObject;; localInteger = null) {
      return localInteger.intValue();
    }
  }
  
  public String getString(String paramString)
  {
    Object localObject = get(paramString);
    if (localObject != null) {
      return (String)localObject;
    }
    return null;
  }
  
  public void setKeyValues(Object... paramVarArgs)
  {
    if (paramVarArgs.length % 2 != 0) {
      throw new RuntimeException("Key-Value arguments passed into setKeyValues must be an alternating list of keys and values!");
    }
    for (int i = 0; i < paramVarArgs.length; i += 2)
    {
      if (!(paramVarArgs[i] instanceof String)) {
        throw new RuntimeException("Key-value argument " + i + " must be a key of type " + "String, but found an object of type " + paramVarArgs[i].getClass() + "!");
      }
      put((String)paramVarArgs[i], paramVarArgs[(i + 1)]);
    }
  }
  
  public String toString()
  {
    StringWriter localStringWriter = new StringWriter();
    Iterator localIterator = entrySet().iterator();
    if (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      Object localObject = localEntry.getValue();
      if ((localObject instanceof String)) {}
      for (String str = "\"" + localObject + "\"";; str = localObject.toString())
      {
        localStringWriter.write((String)localEntry.getKey() + " = " + str + ";\n");
        break;
      }
    }
    return localStringWriter.toString();
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\filterfw\core\KeyValueMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.filterfw.core;

public class NativeAllocatorTag {}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\filterfw\core\NativeAllocatorTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
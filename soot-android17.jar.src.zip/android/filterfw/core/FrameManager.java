package android.filterfw.core;

public abstract class FrameManager
{
  private FilterContext mContext;
  
  public Frame duplicateFrame(Frame paramFrame)
  {
    Frame localFrame = newFrame(paramFrame.getFormat());
    localFrame.setDataFromFrame(paramFrame);
    return localFrame;
  }
  
  public Frame duplicateFrameToTarget(Frame paramFrame, int paramInt)
  {
    MutableFrameFormat localMutableFrameFormat = paramFrame.getFormat().mutableCopy();
    localMutableFrameFormat.setTarget(paramInt);
    Frame localFrame = newFrame(localMutableFrameFormat);
    localFrame.setDataFromFrame(paramFrame);
    return localFrame;
  }
  
  public FilterContext getContext()
  {
    return this.mContext;
  }
  
  public GLEnvironment getGLEnvironment()
  {
    if (this.mContext != null) {
      return this.mContext.getGLEnvironment();
    }
    return null;
  }
  
  public abstract Frame newBoundFrame(FrameFormat paramFrameFormat, int paramInt, long paramLong);
  
  public abstract Frame newFrame(FrameFormat paramFrameFormat);
  
  public abstract Frame releaseFrame(Frame paramFrame);
  
  public abstract Frame retainFrame(Frame paramFrame);
  
  void setContext(FilterContext paramFilterContext)
  {
    this.mContext = paramFilterContext;
  }
  
  public void tearDown() {}
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\filterfw\core\FrameManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
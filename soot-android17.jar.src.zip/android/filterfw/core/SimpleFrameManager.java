package android.filterfw.core;

public class SimpleFrameManager
  extends FrameManager
{
  private Frame createNewFrame(FrameFormat paramFrameFormat)
  {
    switch (paramFrameFormat.getTarget())
    {
    default: 
      throw new RuntimeException("Unsupported frame target type: " + FrameFormat.targetToString(paramFrameFormat.getTarget()) + "!");
    case 1: 
      return new SimpleFrame(paramFrameFormat, this);
    case 2: 
      return new NativeFrame(paramFrameFormat, this);
    case 3: 
      GLFrame localGLFrame = new GLFrame(paramFrameFormat, this);
      localGLFrame.init(getGLEnvironment());
      return localGLFrame;
    }
    return new VertexFrame(paramFrameFormat, this);
  }
  
  public Frame newBoundFrame(FrameFormat paramFrameFormat, int paramInt, long paramLong)
  {
    switch (paramFrameFormat.getTarget())
    {
    default: 
      throw new RuntimeException("Attached frames are not supported for target type: " + FrameFormat.targetToString(paramFrameFormat.getTarget()) + "!");
    }
    GLFrame localGLFrame = new GLFrame(paramFrameFormat, this, paramInt, paramLong);
    localGLFrame.init(getGLEnvironment());
    return localGLFrame;
  }
  
  public Frame newFrame(FrameFormat paramFrameFormat)
  {
    return createNewFrame(paramFrameFormat);
  }
  
  public Frame releaseFrame(Frame paramFrame)
  {
    int i = paramFrame.decRefCount();
    if ((i == 0) && (paramFrame.hasNativeAllocation()))
    {
      paramFrame.releaseNativeAllocation();
      paramFrame = null;
    }
    while (i >= 0) {
      return paramFrame;
    }
    throw new RuntimeException("Frame reference count dropped below 0!");
  }
  
  public Frame retainFrame(Frame paramFrame)
  {
    paramFrame.incRefCount();
    return paramFrame;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\filterfw\core\SimpleFrameManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
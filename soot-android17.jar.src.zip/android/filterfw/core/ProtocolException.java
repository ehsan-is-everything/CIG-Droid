package android.filterfw.core;

public class ProtocolException
  extends RuntimeException
{
  public ProtocolException() {}
  
  public ProtocolException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\filterfw\core\ProtocolException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
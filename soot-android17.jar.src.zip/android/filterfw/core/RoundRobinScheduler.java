package android.filterfw.core;

import java.util.Iterator;
import java.util.Set;

public class RoundRobinScheduler
  extends Scheduler
{
  private int mLastPos = -1;
  
  public RoundRobinScheduler(FilterGraph paramFilterGraph)
  {
    super(paramFilterGraph);
  }
  
  public void reset()
  {
    this.mLastPos = -1;
  }
  
  public Filter scheduleNextNode()
  {
    Set localSet = getGraph().getFilters();
    if (this.mLastPos >= localSet.size()) {
      this.mLastPos = -1;
    }
    int i = 0;
    Object localObject = null;
    int j = -1;
    Iterator localIterator = localSet.iterator();
    while (localIterator.hasNext())
    {
      Filter localFilter = (Filter)localIterator.next();
      if (localFilter.canProcess())
      {
        if (i > this.mLastPos) {
          break label95;
        }
        if (localObject == null)
        {
          localObject = localFilter;
          j = i;
        }
      }
      i++;
      continue;
      label95:
      this.mLastPos = i;
      return localFilter;
    }
    if (localObject != null)
    {
      this.mLastPos = j;
      return (Filter)localObject;
    }
    return null;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\filterfw\core\RoundRobinScheduler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
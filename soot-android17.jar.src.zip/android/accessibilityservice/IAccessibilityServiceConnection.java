package android.accessibilityservice;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import android.view.accessibility.IAccessibilityInteractionConnectionCallback;
import android.view.accessibility.IAccessibilityInteractionConnectionCallback.Stub;

public abstract interface IAccessibilityServiceConnection
  extends IInterface
{
  public abstract float findAccessibilityNodeInfoByAccessibilityId(int paramInt1, long paramLong1, int paramInt2, IAccessibilityInteractionConnectionCallback paramIAccessibilityInteractionConnectionCallback, int paramInt3, long paramLong2)
    throws RemoteException;
  
  public abstract float findAccessibilityNodeInfoByViewId(int paramInt1, long paramLong1, int paramInt2, int paramInt3, IAccessibilityInteractionConnectionCallback paramIAccessibilityInteractionConnectionCallback, long paramLong2)
    throws RemoteException;
  
  public abstract float findAccessibilityNodeInfosByText(int paramInt1, long paramLong1, String paramString, int paramInt2, IAccessibilityInteractionConnectionCallback paramIAccessibilityInteractionConnectionCallback, long paramLong2)
    throws RemoteException;
  
  public abstract float findFocus(int paramInt1, long paramLong1, int paramInt2, int paramInt3, IAccessibilityInteractionConnectionCallback paramIAccessibilityInteractionConnectionCallback, long paramLong2)
    throws RemoteException;
  
  public abstract float focusSearch(int paramInt1, long paramLong1, int paramInt2, int paramInt3, IAccessibilityInteractionConnectionCallback paramIAccessibilityInteractionConnectionCallback, long paramLong2)
    throws RemoteException;
  
  public abstract AccessibilityServiceInfo getServiceInfo()
    throws RemoteException;
  
  public abstract boolean performAccessibilityAction(int paramInt1, long paramLong1, int paramInt2, Bundle paramBundle, int paramInt3, IAccessibilityInteractionConnectionCallback paramIAccessibilityInteractionConnectionCallback, long paramLong2)
    throws RemoteException;
  
  public abstract boolean performGlobalAction(int paramInt)
    throws RemoteException;
  
  public abstract void setServiceInfo(AccessibilityServiceInfo paramAccessibilityServiceInfo)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IAccessibilityServiceConnection
  {
    private static final String DESCRIPTOR = "android.accessibilityservice.IAccessibilityServiceConnection";
    static final int TRANSACTION_findAccessibilityNodeInfoByAccessibilityId = 2;
    static final int TRANSACTION_findAccessibilityNodeInfoByViewId = 4;
    static final int TRANSACTION_findAccessibilityNodeInfosByText = 3;
    static final int TRANSACTION_findFocus = 5;
    static final int TRANSACTION_focusSearch = 6;
    static final int TRANSACTION_getServiceInfo = 8;
    static final int TRANSACTION_performAccessibilityAction = 7;
    static final int TRANSACTION_performGlobalAction = 9;
    static final int TRANSACTION_setServiceInfo = 1;
    
    public Stub()
    {
      attachInterface(this, "android.accessibilityservice.IAccessibilityServiceConnection");
    }
    
    public static IAccessibilityServiceConnection asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.accessibilityservice.IAccessibilityServiceConnection");
      if ((localIInterface != null) && ((localIInterface instanceof IAccessibilityServiceConnection))) {
        return (IAccessibilityServiceConnection)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.accessibilityservice.IAccessibilityServiceConnection");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.accessibilityservice.IAccessibilityServiceConnection");
        if (paramParcel1.readInt() != 0) {}
        for (AccessibilityServiceInfo localAccessibilityServiceInfo2 = (AccessibilityServiceInfo)AccessibilityServiceInfo.CREATOR.createFromParcel(paramParcel1);; localAccessibilityServiceInfo2 = null)
        {
          setServiceInfo(localAccessibilityServiceInfo2);
          paramParcel2.writeNoException();
          return true;
        }
      case 2: 
        paramParcel1.enforceInterface("android.accessibilityservice.IAccessibilityServiceConnection");
        float f5 = findAccessibilityNodeInfoByAccessibilityId(paramParcel1.readInt(), paramParcel1.readLong(), paramParcel1.readInt(), IAccessibilityInteractionConnectionCallback.Stub.asInterface(paramParcel1.readStrongBinder()), paramParcel1.readInt(), paramParcel1.readLong());
        paramParcel2.writeNoException();
        paramParcel2.writeFloat(f5);
        return true;
      case 3: 
        paramParcel1.enforceInterface("android.accessibilityservice.IAccessibilityServiceConnection");
        float f4 = findAccessibilityNodeInfosByText(paramParcel1.readInt(), paramParcel1.readLong(), paramParcel1.readString(), paramParcel1.readInt(), IAccessibilityInteractionConnectionCallback.Stub.asInterface(paramParcel1.readStrongBinder()), paramParcel1.readLong());
        paramParcel2.writeNoException();
        paramParcel2.writeFloat(f4);
        return true;
      case 4: 
        paramParcel1.enforceInterface("android.accessibilityservice.IAccessibilityServiceConnection");
        float f3 = findAccessibilityNodeInfoByViewId(paramParcel1.readInt(), paramParcel1.readLong(), paramParcel1.readInt(), paramParcel1.readInt(), IAccessibilityInteractionConnectionCallback.Stub.asInterface(paramParcel1.readStrongBinder()), paramParcel1.readLong());
        paramParcel2.writeNoException();
        paramParcel2.writeFloat(f3);
        return true;
      case 5: 
        paramParcel1.enforceInterface("android.accessibilityservice.IAccessibilityServiceConnection");
        float f2 = findFocus(paramParcel1.readInt(), paramParcel1.readLong(), paramParcel1.readInt(), paramParcel1.readInt(), IAccessibilityInteractionConnectionCallback.Stub.asInterface(paramParcel1.readStrongBinder()), paramParcel1.readLong());
        paramParcel2.writeNoException();
        paramParcel2.writeFloat(f2);
        return true;
      case 6: 
        paramParcel1.enforceInterface("android.accessibilityservice.IAccessibilityServiceConnection");
        float f1 = focusSearch(paramParcel1.readInt(), paramParcel1.readLong(), paramParcel1.readInt(), paramParcel1.readInt(), IAccessibilityInteractionConnectionCallback.Stub.asInterface(paramParcel1.readStrongBinder()), paramParcel1.readLong());
        paramParcel2.writeNoException();
        paramParcel2.writeFloat(f1);
        return true;
      case 7: 
        paramParcel1.enforceInterface("android.accessibilityservice.IAccessibilityServiceConnection");
        int j = paramParcel1.readInt();
        long l1 = paramParcel1.readLong();
        int k = paramParcel1.readInt();
        Bundle localBundle;
        if (paramParcel1.readInt() != 0)
        {
          localBundle = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
          int m = paramParcel1.readInt();
          IAccessibilityInteractionConnectionCallback localIAccessibilityInteractionConnectionCallback = IAccessibilityInteractionConnectionCallback.Stub.asInterface(paramParcel1.readStrongBinder());
          long l2 = paramParcel1.readLong();
          boolean bool2 = performAccessibilityAction(j, l1, k, localBundle, m, localIAccessibilityInteractionConnectionCallback, l2);
          paramParcel2.writeNoException();
          if (!bool2) {
            break label522;
          }
        }
        for (int n = 1;; n = 0)
        {
          paramParcel2.writeInt(n);
          return true;
          localBundle = null;
          break;
        }
      case 8: 
        label522:
        paramParcel1.enforceInterface("android.accessibilityservice.IAccessibilityServiceConnection");
        AccessibilityServiceInfo localAccessibilityServiceInfo1 = getServiceInfo();
        paramParcel2.writeNoException();
        if (localAccessibilityServiceInfo1 != null)
        {
          paramParcel2.writeInt(1);
          localAccessibilityServiceInfo1.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          paramParcel2.writeInt(0);
        }
      }
      paramParcel1.enforceInterface("android.accessibilityservice.IAccessibilityServiceConnection");
      boolean bool1 = performGlobalAction(paramParcel1.readInt());
      paramParcel2.writeNoException();
      if (bool1) {}
      for (int i = 1;; i = 0)
      {
        paramParcel2.writeInt(i);
        return true;
      }
    }
    
    private static class Proxy
      implements IAccessibilityServiceConnection
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      /* Error */
      public float findAccessibilityNodeInfoByAccessibilityId(int paramInt1, long paramLong1, int paramInt2, IAccessibilityInteractionConnectionCallback paramIAccessibilityInteractionConnectionCallback, int paramInt3, long paramLong2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 9
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 10
        //   10: aload 9
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 9
        //   19: iload_1
        //   20: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   23: aload 9
        //   25: lload_2
        //   26: invokevirtual 41	android/os/Parcel:writeLong	(J)V
        //   29: aload 9
        //   31: iload 4
        //   33: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   36: aload 5
        //   38: ifnull +74 -> 112
        //   41: aload 5
        //   43: invokeinterface 45 1 0
        //   48: astore 12
        //   50: aload 9
        //   52: aload 12
        //   54: invokevirtual 48	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   57: aload 9
        //   59: iload 6
        //   61: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   64: aload 9
        //   66: lload 7
        //   68: invokevirtual 41	android/os/Parcel:writeLong	(J)V
        //   71: aload_0
        //   72: getfield 15	android/accessibilityservice/IAccessibilityServiceConnection$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   75: iconst_2
        //   76: aload 9
        //   78: aload 10
        //   80: iconst_0
        //   81: invokeinterface 54 5 0
        //   86: pop
        //   87: aload 10
        //   89: invokevirtual 57	android/os/Parcel:readException	()V
        //   92: aload 10
        //   94: invokevirtual 61	android/os/Parcel:readFloat	()F
        //   97: fstore 14
        //   99: aload 10
        //   101: invokevirtual 64	android/os/Parcel:recycle	()V
        //   104: aload 9
        //   106: invokevirtual 64	android/os/Parcel:recycle	()V
        //   109: fload 14
        //   111: freturn
        //   112: aconst_null
        //   113: astore 12
        //   115: goto -65 -> 50
        //   118: astore 11
        //   120: aload 10
        //   122: invokevirtual 64	android/os/Parcel:recycle	()V
        //   125: aload 9
        //   127: invokevirtual 64	android/os/Parcel:recycle	()V
        //   130: aload 11
        //   132: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	133	0	this	Proxy
        //   0	133	1	paramInt1	int
        //   0	133	2	paramLong1	long
        //   0	133	4	paramInt2	int
        //   0	133	5	paramIAccessibilityInteractionConnectionCallback	IAccessibilityInteractionConnectionCallback
        //   0	133	6	paramInt3	int
        //   0	133	7	paramLong2	long
        //   3	123	9	localParcel1	Parcel
        //   8	113	10	localParcel2	Parcel
        //   118	13	11	localObject	Object
        //   48	66	12	localIBinder	IBinder
        //   97	13	14	f	float
        // Exception table:
        //   from	to	target	type
        //   10	36	118	finally
        //   41	50	118	finally
        //   50	99	118	finally
      }
      
      /* Error */
      public float findAccessibilityNodeInfoByViewId(int paramInt1, long paramLong1, int paramInt2, int paramInt3, IAccessibilityInteractionConnectionCallback paramIAccessibilityInteractionConnectionCallback, long paramLong2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 9
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 10
        //   10: aload 9
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 9
        //   19: iload_1
        //   20: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   23: aload 9
        //   25: lload_2
        //   26: invokevirtual 41	android/os/Parcel:writeLong	(J)V
        //   29: aload 9
        //   31: iload 4
        //   33: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   36: aload 9
        //   38: iload 5
        //   40: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   43: aload 6
        //   45: ifnull +67 -> 112
        //   48: aload 6
        //   50: invokeinterface 45 1 0
        //   55: astore 12
        //   57: aload 9
        //   59: aload 12
        //   61: invokevirtual 48	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   64: aload 9
        //   66: lload 7
        //   68: invokevirtual 41	android/os/Parcel:writeLong	(J)V
        //   71: aload_0
        //   72: getfield 15	android/accessibilityservice/IAccessibilityServiceConnection$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   75: iconst_4
        //   76: aload 9
        //   78: aload 10
        //   80: iconst_0
        //   81: invokeinterface 54 5 0
        //   86: pop
        //   87: aload 10
        //   89: invokevirtual 57	android/os/Parcel:readException	()V
        //   92: aload 10
        //   94: invokevirtual 61	android/os/Parcel:readFloat	()F
        //   97: fstore 14
        //   99: aload 10
        //   101: invokevirtual 64	android/os/Parcel:recycle	()V
        //   104: aload 9
        //   106: invokevirtual 64	android/os/Parcel:recycle	()V
        //   109: fload 14
        //   111: freturn
        //   112: aconst_null
        //   113: astore 12
        //   115: goto -58 -> 57
        //   118: astore 11
        //   120: aload 10
        //   122: invokevirtual 64	android/os/Parcel:recycle	()V
        //   125: aload 9
        //   127: invokevirtual 64	android/os/Parcel:recycle	()V
        //   130: aload 11
        //   132: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	133	0	this	Proxy
        //   0	133	1	paramInt1	int
        //   0	133	2	paramLong1	long
        //   0	133	4	paramInt2	int
        //   0	133	5	paramInt3	int
        //   0	133	6	paramIAccessibilityInteractionConnectionCallback	IAccessibilityInteractionConnectionCallback
        //   0	133	7	paramLong2	long
        //   3	123	9	localParcel1	Parcel
        //   8	113	10	localParcel2	Parcel
        //   118	13	11	localObject	Object
        //   55	59	12	localIBinder	IBinder
        //   97	13	14	f	float
        // Exception table:
        //   from	to	target	type
        //   10	43	118	finally
        //   48	57	118	finally
        //   57	99	118	finally
      }
      
      /* Error */
      public float findAccessibilityNodeInfosByText(int paramInt1, long paramLong1, String paramString, int paramInt2, IAccessibilityInteractionConnectionCallback paramIAccessibilityInteractionConnectionCallback, long paramLong2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 9
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 10
        //   10: aload 9
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 9
        //   19: iload_1
        //   20: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   23: aload 9
        //   25: lload_2
        //   26: invokevirtual 41	android/os/Parcel:writeLong	(J)V
        //   29: aload 9
        //   31: aload 4
        //   33: invokevirtual 71	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   36: aload 9
        //   38: iload 5
        //   40: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   43: aload 6
        //   45: ifnull +67 -> 112
        //   48: aload 6
        //   50: invokeinterface 45 1 0
        //   55: astore 12
        //   57: aload 9
        //   59: aload 12
        //   61: invokevirtual 48	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   64: aload 9
        //   66: lload 7
        //   68: invokevirtual 41	android/os/Parcel:writeLong	(J)V
        //   71: aload_0
        //   72: getfield 15	android/accessibilityservice/IAccessibilityServiceConnection$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   75: iconst_3
        //   76: aload 9
        //   78: aload 10
        //   80: iconst_0
        //   81: invokeinterface 54 5 0
        //   86: pop
        //   87: aload 10
        //   89: invokevirtual 57	android/os/Parcel:readException	()V
        //   92: aload 10
        //   94: invokevirtual 61	android/os/Parcel:readFloat	()F
        //   97: fstore 14
        //   99: aload 10
        //   101: invokevirtual 64	android/os/Parcel:recycle	()V
        //   104: aload 9
        //   106: invokevirtual 64	android/os/Parcel:recycle	()V
        //   109: fload 14
        //   111: freturn
        //   112: aconst_null
        //   113: astore 12
        //   115: goto -58 -> 57
        //   118: astore 11
        //   120: aload 10
        //   122: invokevirtual 64	android/os/Parcel:recycle	()V
        //   125: aload 9
        //   127: invokevirtual 64	android/os/Parcel:recycle	()V
        //   130: aload 11
        //   132: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	133	0	this	Proxy
        //   0	133	1	paramInt1	int
        //   0	133	2	paramLong1	long
        //   0	133	4	paramString	String
        //   0	133	5	paramInt2	int
        //   0	133	6	paramIAccessibilityInteractionConnectionCallback	IAccessibilityInteractionConnectionCallback
        //   0	133	7	paramLong2	long
        //   3	123	9	localParcel1	Parcel
        //   8	113	10	localParcel2	Parcel
        //   118	13	11	localObject	Object
        //   55	59	12	localIBinder	IBinder
        //   97	13	14	f	float
        // Exception table:
        //   from	to	target	type
        //   10	43	118	finally
        //   48	57	118	finally
        //   57	99	118	finally
      }
      
      /* Error */
      public float findFocus(int paramInt1, long paramLong1, int paramInt2, int paramInt3, IAccessibilityInteractionConnectionCallback paramIAccessibilityInteractionConnectionCallback, long paramLong2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 9
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 10
        //   10: aload 9
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 9
        //   19: iload_1
        //   20: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   23: aload 9
        //   25: lload_2
        //   26: invokevirtual 41	android/os/Parcel:writeLong	(J)V
        //   29: aload 9
        //   31: iload 4
        //   33: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   36: aload 9
        //   38: iload 5
        //   40: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   43: aload 6
        //   45: ifnull +67 -> 112
        //   48: aload 6
        //   50: invokeinterface 45 1 0
        //   55: astore 12
        //   57: aload 9
        //   59: aload 12
        //   61: invokevirtual 48	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   64: aload 9
        //   66: lload 7
        //   68: invokevirtual 41	android/os/Parcel:writeLong	(J)V
        //   71: aload_0
        //   72: getfield 15	android/accessibilityservice/IAccessibilityServiceConnection$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   75: iconst_5
        //   76: aload 9
        //   78: aload 10
        //   80: iconst_0
        //   81: invokeinterface 54 5 0
        //   86: pop
        //   87: aload 10
        //   89: invokevirtual 57	android/os/Parcel:readException	()V
        //   92: aload 10
        //   94: invokevirtual 61	android/os/Parcel:readFloat	()F
        //   97: fstore 14
        //   99: aload 10
        //   101: invokevirtual 64	android/os/Parcel:recycle	()V
        //   104: aload 9
        //   106: invokevirtual 64	android/os/Parcel:recycle	()V
        //   109: fload 14
        //   111: freturn
        //   112: aconst_null
        //   113: astore 12
        //   115: goto -58 -> 57
        //   118: astore 11
        //   120: aload 10
        //   122: invokevirtual 64	android/os/Parcel:recycle	()V
        //   125: aload 9
        //   127: invokevirtual 64	android/os/Parcel:recycle	()V
        //   130: aload 11
        //   132: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	133	0	this	Proxy
        //   0	133	1	paramInt1	int
        //   0	133	2	paramLong1	long
        //   0	133	4	paramInt2	int
        //   0	133	5	paramInt3	int
        //   0	133	6	paramIAccessibilityInteractionConnectionCallback	IAccessibilityInteractionConnectionCallback
        //   0	133	7	paramLong2	long
        //   3	123	9	localParcel1	Parcel
        //   8	113	10	localParcel2	Parcel
        //   118	13	11	localObject	Object
        //   55	59	12	localIBinder	IBinder
        //   97	13	14	f	float
        // Exception table:
        //   from	to	target	type
        //   10	43	118	finally
        //   48	57	118	finally
        //   57	99	118	finally
      }
      
      /* Error */
      public float focusSearch(int paramInt1, long paramLong1, int paramInt2, int paramInt3, IAccessibilityInteractionConnectionCallback paramIAccessibilityInteractionConnectionCallback, long paramLong2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 9
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 10
        //   10: aload 9
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 9
        //   19: iload_1
        //   20: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   23: aload 9
        //   25: lload_2
        //   26: invokevirtual 41	android/os/Parcel:writeLong	(J)V
        //   29: aload 9
        //   31: iload 4
        //   33: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   36: aload 9
        //   38: iload 5
        //   40: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   43: aload 6
        //   45: ifnull +68 -> 113
        //   48: aload 6
        //   50: invokeinterface 45 1 0
        //   55: astore 12
        //   57: aload 9
        //   59: aload 12
        //   61: invokevirtual 48	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   64: aload 9
        //   66: lload 7
        //   68: invokevirtual 41	android/os/Parcel:writeLong	(J)V
        //   71: aload_0
        //   72: getfield 15	android/accessibilityservice/IAccessibilityServiceConnection$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   75: bipush 6
        //   77: aload 9
        //   79: aload 10
        //   81: iconst_0
        //   82: invokeinterface 54 5 0
        //   87: pop
        //   88: aload 10
        //   90: invokevirtual 57	android/os/Parcel:readException	()V
        //   93: aload 10
        //   95: invokevirtual 61	android/os/Parcel:readFloat	()F
        //   98: fstore 14
        //   100: aload 10
        //   102: invokevirtual 64	android/os/Parcel:recycle	()V
        //   105: aload 9
        //   107: invokevirtual 64	android/os/Parcel:recycle	()V
        //   110: fload 14
        //   112: freturn
        //   113: aconst_null
        //   114: astore 12
        //   116: goto -59 -> 57
        //   119: astore 11
        //   121: aload 10
        //   123: invokevirtual 64	android/os/Parcel:recycle	()V
        //   126: aload 9
        //   128: invokevirtual 64	android/os/Parcel:recycle	()V
        //   131: aload 11
        //   133: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	134	0	this	Proxy
        //   0	134	1	paramInt1	int
        //   0	134	2	paramLong1	long
        //   0	134	4	paramInt2	int
        //   0	134	5	paramInt3	int
        //   0	134	6	paramIAccessibilityInteractionConnectionCallback	IAccessibilityInteractionConnectionCallback
        //   0	134	7	paramLong2	long
        //   3	124	9	localParcel1	Parcel
        //   8	114	10	localParcel2	Parcel
        //   119	13	11	localObject	Object
        //   55	60	12	localIBinder	IBinder
        //   98	13	14	f	float
        // Exception table:
        //   from	to	target	type
        //   10	43	119	finally
        //   48	57	119	finally
        //   57	100	119	finally
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.accessibilityservice.IAccessibilityServiceConnection";
      }
      
      /* Error */
      public AccessibilityServiceInfo getServiceInfo()
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_1
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_2
        //   8: aload_1
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_0
        //   15: getfield 15	android/accessibilityservice/IAccessibilityServiceConnection$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   18: bipush 8
        //   20: aload_1
        //   21: aload_2
        //   22: iconst_0
        //   23: invokeinterface 54 5 0
        //   28: pop
        //   29: aload_2
        //   30: invokevirtual 57	android/os/Parcel:readException	()V
        //   33: aload_2
        //   34: invokevirtual 81	android/os/Parcel:readInt	()I
        //   37: ifeq +28 -> 65
        //   40: getstatic 87	android/accessibilityservice/AccessibilityServiceInfo:CREATOR	Landroid/os/Parcelable$Creator;
        //   43: aload_2
        //   44: invokeinterface 93 2 0
        //   49: checkcast 83	android/accessibilityservice/AccessibilityServiceInfo
        //   52: astore 5
        //   54: aload_2
        //   55: invokevirtual 64	android/os/Parcel:recycle	()V
        //   58: aload_1
        //   59: invokevirtual 64	android/os/Parcel:recycle	()V
        //   62: aload 5
        //   64: areturn
        //   65: aconst_null
        //   66: astore 5
        //   68: goto -14 -> 54
        //   71: astore_3
        //   72: aload_2
        //   73: invokevirtual 64	android/os/Parcel:recycle	()V
        //   76: aload_1
        //   77: invokevirtual 64	android/os/Parcel:recycle	()V
        //   80: aload_3
        //   81: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	82	0	this	Proxy
        //   3	74	1	localParcel1	Parcel
        //   7	66	2	localParcel2	Parcel
        //   71	10	3	localObject	Object
        //   52	15	5	localAccessibilityServiceInfo	AccessibilityServiceInfo
        // Exception table:
        //   from	to	target	type
        //   8	54	71	finally
      }
      
      public boolean performAccessibilityAction(int paramInt1, long paramLong1, int paramInt2, Bundle paramBundle, int paramInt3, IAccessibilityInteractionConnectionCallback paramIAccessibilityInteractionConnectionCallback, long paramLong2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.accessibilityservice.IAccessibilityServiceConnection");
            localParcel1.writeInt(paramInt1);
            localParcel1.writeLong(paramLong1);
            localParcel1.writeInt(paramInt2);
            if (paramBundle != null)
            {
              localParcel1.writeInt(1);
              paramBundle.writeToParcel(localParcel1, 0);
              localParcel1.writeInt(paramInt3);
              if (paramIAccessibilityInteractionConnectionCallback != null)
              {
                localIBinder = paramIAccessibilityInteractionConnectionCallback.asBinder();
                localParcel1.writeStrongBinder(localIBinder);
                localParcel1.writeLong(paramLong2);
                this.mRemote.transact(7, localParcel1, localParcel2, 0);
                localParcel2.readException();
                int i = localParcel2.readInt();
                if (i == 0) {
                  break label170;
                }
                bool = true;
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            IBinder localIBinder = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          continue;
          label170:
          boolean bool = false;
        }
      }
      
      public boolean performGlobalAction(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.accessibilityservice.IAccessibilityServiceConnection");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(9, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public void setServiceInfo(AccessibilityServiceInfo paramAccessibilityServiceInfo)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +41 -> 56
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 106	android/accessibilityservice/AccessibilityServiceInfo:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/accessibilityservice/IAccessibilityServiceConnection$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: iconst_1
        //   34: aload_2
        //   35: aload_3
        //   36: iconst_0
        //   37: invokeinterface 54 5 0
        //   42: pop
        //   43: aload_3
        //   44: invokevirtual 57	android/os/Parcel:readException	()V
        //   47: aload_3
        //   48: invokevirtual 64	android/os/Parcel:recycle	()V
        //   51: aload_2
        //   52: invokevirtual 64	android/os/Parcel:recycle	()V
        //   55: return
        //   56: aload_2
        //   57: iconst_0
        //   58: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   61: goto -32 -> 29
        //   64: astore 4
        //   66: aload_3
        //   67: invokevirtual 64	android/os/Parcel:recycle	()V
        //   70: aload_2
        //   71: invokevirtual 64	android/os/Parcel:recycle	()V
        //   74: aload 4
        //   76: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	77	0	this	Proxy
        //   0	77	1	paramAccessibilityServiceInfo	AccessibilityServiceInfo
        //   3	68	2	localParcel1	Parcel
        //   7	60	3	localParcel2	Parcel
        //   64	11	4	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   8	14	64	finally
        //   18	29	64	finally
        //   29	47	64	finally
        //   56	61	64	finally
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\accessibilityservice\IAccessibilityServiceConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.accessibilityservice;

import android.os.Bundle;
import android.os.HandlerThread;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.SystemClock;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityInteractionClient;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.IAccessibilityManager;
import android.view.accessibility.IAccessibilityManager.Stub;
import com.android.internal.util.Predicate;
import java.util.List;
import java.util.concurrent.TimeoutException;

public class UiTestAutomationBridge
{
  public static final int ACTIVE_WINDOW_ID = -1;
  private static final int FIND_ACCESSIBILITY_NODE_INFO_PREFETCH_FLAGS = 7;
  private static final String LOG_TAG = UiTestAutomationBridge.class.getSimpleName();
  public static final long ROOT_NODE_ID = AccessibilityNodeInfo.ROOT_NODE_ID;
  private static final int TIMEOUT_REGISTER_SERVICE = 5000;
  public static final int UNDEFINED = -1;
  private volatile int mConnectionId = -1;
  private HandlerThread mHandlerThread;
  private AccessibilityEvent mLastEvent;
  private AccessibilityService.IAccessibilityServiceClientWrapper mListener;
  private final Object mLock = new Object();
  private volatile boolean mUnprocessedEventAvailable;
  private volatile boolean mWaitingForEventDelivery;
  
  private void ensureValidConnection(int paramInt)
  {
    if (paramInt == -1) {
      throw new IllegalStateException("UiAutomationService not connected. Did you call #register()?");
    }
  }
  
  /* Error */
  public void connect()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 87	android/accessibilityservice/UiTestAutomationBridge:isConnected	()Z
    //   4: ifeq +13 -> 17
    //   7: new 73	java/lang/IllegalStateException
    //   10: dup
    //   11: ldc 89
    //   13: invokespecial 78	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   16: athrow
    //   17: aload_0
    //   18: new 91	android/os/HandlerThread
    //   21: dup
    //   22: ldc 93
    //   24: invokespecial 94	android/os/HandlerThread:<init>	(Ljava/lang/String;)V
    //   27: putfield 96	android/accessibilityservice/UiTestAutomationBridge:mHandlerThread	Landroid/os/HandlerThread;
    //   30: aload_0
    //   31: getfield 96	android/accessibilityservice/UiTestAutomationBridge:mHandlerThread	Landroid/os/HandlerThread;
    //   34: iconst_1
    //   35: invokevirtual 100	android/os/HandlerThread:setDaemon	(Z)V
    //   38: aload_0
    //   39: getfield 96	android/accessibilityservice/UiTestAutomationBridge:mHandlerThread	Landroid/os/HandlerThread;
    //   42: invokevirtual 103	android/os/HandlerThread:start	()V
    //   45: aload_0
    //   46: new 105	android/accessibilityservice/AccessibilityService$IAccessibilityServiceClientWrapper
    //   49: dup
    //   50: aconst_null
    //   51: aload_0
    //   52: getfield 96	android/accessibilityservice/UiTestAutomationBridge:mHandlerThread	Landroid/os/HandlerThread;
    //   55: invokevirtual 109	android/os/HandlerThread:getLooper	()Landroid/os/Looper;
    //   58: new 111	android/accessibilityservice/UiTestAutomationBridge$1
    //   61: dup
    //   62: aload_0
    //   63: invokespecial 114	android/accessibilityservice/UiTestAutomationBridge$1:<init>	(Landroid/accessibilityservice/UiTestAutomationBridge;)V
    //   66: invokespecial 117	android/accessibilityservice/AccessibilityService$IAccessibilityServiceClientWrapper:<init>	(Landroid/content/Context;Landroid/os/Looper;Landroid/accessibilityservice/AccessibilityService$Callbacks;)V
    //   69: putfield 119	android/accessibilityservice/UiTestAutomationBridge:mListener	Landroid/accessibilityservice/AccessibilityService$IAccessibilityServiceClientWrapper;
    //   72: ldc 121
    //   74: invokestatic 127	android/os/ServiceManager:getService	(Ljava/lang/String;)Landroid/os/IBinder;
    //   77: invokestatic 133	android/view/accessibility/IAccessibilityManager$Stub:asInterface	(Landroid/os/IBinder;)Landroid/view/accessibility/IAccessibilityManager;
    //   80: astore_1
    //   81: new 135	android/accessibilityservice/AccessibilityServiceInfo
    //   84: dup
    //   85: invokespecial 136	android/accessibilityservice/AccessibilityServiceInfo:<init>	()V
    //   88: astore_2
    //   89: aload_2
    //   90: iconst_m1
    //   91: putfield 139	android/accessibilityservice/AccessibilityServiceInfo:eventTypes	I
    //   94: aload_2
    //   95: bipush 16
    //   97: putfield 142	android/accessibilityservice/AccessibilityServiceInfo:feedbackType	I
    //   100: aload_2
    //   101: iconst_2
    //   102: aload_2
    //   103: getfield 145	android/accessibilityservice/AccessibilityServiceInfo:flags	I
    //   106: ior
    //   107: putfield 145	android/accessibilityservice/AccessibilityServiceInfo:flags	I
    //   110: aload_1
    //   111: aload_0
    //   112: getfield 119	android/accessibilityservice/UiTestAutomationBridge:mListener	Landroid/accessibilityservice/AccessibilityService$IAccessibilityServiceClientWrapper;
    //   115: aload_2
    //   116: invokeinterface 151 3 0
    //   121: aload_0
    //   122: getfield 50	android/accessibilityservice/UiTestAutomationBridge:mLock	Ljava/lang/Object;
    //   125: astore 4
    //   127: aload 4
    //   129: monitorenter
    //   130: invokestatic 157	android/os/SystemClock:uptimeMillis	()J
    //   133: lstore 6
    //   135: aload_0
    //   136: invokevirtual 87	android/accessibilityservice/UiTestAutomationBridge:isConnected	()Z
    //   139: ifeq +19 -> 158
    //   142: aload 4
    //   144: monitorexit
    //   145: return
    //   146: astore_3
    //   147: new 73	java/lang/IllegalStateException
    //   150: dup
    //   151: ldc -97
    //   153: aload_3
    //   154: invokespecial 162	java/lang/IllegalStateException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   157: athrow
    //   158: ldc2_w 163
    //   161: invokestatic 157	android/os/SystemClock:uptimeMillis	()J
    //   164: lload 6
    //   166: lsub
    //   167: lsub
    //   168: lstore 8
    //   170: lload 8
    //   172: lconst_0
    //   173: lcmp
    //   174: ifgt +21 -> 195
    //   177: new 73	java/lang/IllegalStateException
    //   180: dup
    //   181: ldc -97
    //   183: invokespecial 78	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   186: athrow
    //   187: astore 5
    //   189: aload 4
    //   191: monitorexit
    //   192: aload 5
    //   194: athrow
    //   195: aload_0
    //   196: getfield 50	android/accessibilityservice/UiTestAutomationBridge:mLock	Ljava/lang/Object;
    //   199: lload 8
    //   201: invokevirtual 168	java/lang/Object:wait	(J)V
    //   204: goto -69 -> 135
    //   207: astore 10
    //   209: goto -74 -> 135
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	212	0	this	UiTestAutomationBridge
    //   80	31	1	localIAccessibilityManager	IAccessibilityManager
    //   88	28	2	localAccessibilityServiceInfo	AccessibilityServiceInfo
    //   146	8	3	localRemoteException	RemoteException
    //   187	6	5	localObject2	Object
    //   133	32	6	l1	long
    //   168	32	8	l2	long
    //   207	1	10	localInterruptedException	InterruptedException
    // Exception table:
    //   from	to	target	type
    //   110	121	146	android/os/RemoteException
    //   130	135	187	finally
    //   135	145	187	finally
    //   158	170	187	finally
    //   177	187	187	finally
    //   189	192	187	finally
    //   195	204	187	finally
    //   195	204	207	java/lang/InterruptedException
  }
  
  public void disconnect()
  {
    if (!isConnected()) {
      throw new IllegalStateException("Already disconnected.");
    }
    this.mHandlerThread.quit();
    IAccessibilityManager localIAccessibilityManager = IAccessibilityManager.Stub.asInterface(ServiceManager.getService("accessibility"));
    try
    {
      localIAccessibilityManager.unregisterUiTestAutomationService(this.mListener);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e(LOG_TAG, "Error while unregistering UiTestAutomationService", localRemoteException);
    }
  }
  
  public AccessibilityEvent executeCommandAndWaitForAccessibilityEvent(Runnable paramRunnable, Predicate<AccessibilityEvent> paramPredicate, long paramLong)
    throws TimeoutException, Exception
  {
    for (;;)
    {
      long l2;
      synchronized (this.mLock)
      {
        this.mWaitingForEventDelivery = true;
        this.mUnprocessedEventAvailable = false;
        if (this.mLastEvent != null)
        {
          this.mLastEvent.recycle();
          this.mLastEvent = null;
        }
        paramRunnable.run();
        long l1 = SystemClock.uptimeMillis();
        if ((this.mUnprocessedEventAvailable) && (paramPredicate.apply(this.mLastEvent)))
        {
          this.mWaitingForEventDelivery = false;
          this.mUnprocessedEventAvailable = false;
          this.mLock.notifyAll();
          AccessibilityEvent localAccessibilityEvent = this.mLastEvent;
          return localAccessibilityEvent;
        }
        this.mWaitingForEventDelivery = true;
        this.mUnprocessedEventAvailable = false;
        this.mLock.notifyAll();
        l2 = paramLong - (SystemClock.uptimeMillis() - l1);
        if (l2 <= 0L)
        {
          this.mWaitingForEventDelivery = false;
          this.mUnprocessedEventAvailable = false;
          this.mLock.notifyAll();
          throw new TimeoutException("Expacted event not received within: " + paramLong + " ms.");
        }
      }
      try
      {
        this.mLock.wait(l2);
      }
      catch (InterruptedException localInterruptedException) {}
    }
  }
  
  public AccessibilityNodeInfo findAccessibilityNodeInfoByAccessibilityId(int paramInt, long paramLong)
  {
    ensureValidConnection(this.mConnectionId);
    return AccessibilityInteractionClient.getInstance().findAccessibilityNodeInfoByAccessibilityId(this.mConnectionId, paramInt, paramLong, 7);
  }
  
  public AccessibilityNodeInfo findAccessibilityNodeInfoByAccessibilityIdInActiveWindow(long paramLong)
  {
    return findAccessibilityNodeInfoByAccessibilityId(-1, paramLong);
  }
  
  public AccessibilityNodeInfo findAccessibilityNodeInfoByViewId(int paramInt1, long paramLong, int paramInt2)
  {
    int i = this.mConnectionId;
    ensureValidConnection(i);
    return AccessibilityInteractionClient.getInstance().findAccessibilityNodeInfoByViewId(i, paramInt1, paramLong, paramInt2);
  }
  
  public AccessibilityNodeInfo findAccessibilityNodeInfoByViewIdInActiveWindow(int paramInt)
  {
    return findAccessibilityNodeInfoByViewId(-1, ROOT_NODE_ID, paramInt);
  }
  
  public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(int paramInt, long paramLong, String paramString)
  {
    int i = this.mConnectionId;
    ensureValidConnection(i);
    return AccessibilityInteractionClient.getInstance().findAccessibilityNodeInfosByText(i, paramInt, paramLong, paramString);
  }
  
  public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByTextInActiveWindow(String paramString)
  {
    return findAccessibilityNodeInfosByText(-1, ROOT_NODE_ID, paramString);
  }
  
  public AccessibilityEvent getLastAccessibilityEvent()
  {
    return this.mLastEvent;
  }
  
  public AccessibilityNodeInfo getRootAccessibilityNodeInfoInActiveWindow()
  {
    int i = this.mConnectionId;
    ensureValidConnection(i);
    return AccessibilityInteractionClient.getInstance().findAccessibilityNodeInfoByAccessibilityId(i, -1, ROOT_NODE_ID, 4);
  }
  
  public boolean isConnected()
  {
    return this.mConnectionId != -1;
  }
  
  public void onAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {}
  
  public void onInterrupt() {}
  
  public boolean performAccessibilityAction(int paramInt1, long paramLong, int paramInt2, Bundle paramBundle)
  {
    int i = this.mConnectionId;
    ensureValidConnection(i);
    return AccessibilityInteractionClient.getInstance().performAccessibilityAction(i, paramInt1, paramLong, paramInt2, paramBundle);
  }
  
  public boolean performAccessibilityActionInActiveWindow(long paramLong, int paramInt, Bundle paramBundle)
  {
    return performAccessibilityAction(-1, paramLong, paramInt, paramBundle);
  }
  
  public void waitForIdle(long paramLong1, long paramLong2)
  {
    long l1 = SystemClock.uptimeMillis();
    long l2;
    if (this.mLastEvent != null) {
      l2 = this.mLastEvent.getEventTime();
    }
    for (;;)
    {
      synchronized (this.mLock)
      {
        if (SystemClock.uptimeMillis() - l2 > paramLong1)
        {
          return;
          l2 = SystemClock.uptimeMillis();
          continue;
        }
        if (this.mLastEvent != null) {
          l2 = this.mLastEvent.getEventTime();
        }
        if (paramLong2 - (SystemClock.uptimeMillis() - l1) <= 0L) {
          return;
        }
      }
      try
      {
        this.mLock.wait(paramLong1);
      }
      catch (InterruptedException localInterruptedException) {}
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\accessibilityservice\UiTestAutomationBridge.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
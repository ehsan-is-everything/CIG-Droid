package android.content;

import android.database.DatabaseUtils;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.ICancellationSignal;
import android.os.ICancellationSignal.Stub;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import java.util.ArrayList;
import java.util.Iterator;

final class ContentProviderProxy
  implements IContentProvider
{
  private IBinder mRemote;
  
  public ContentProviderProxy(IBinder paramIBinder)
  {
    this.mRemote = paramIBinder;
  }
  
  public ContentProviderResult[] applyBatch(ArrayList<ContentProviderOperation> paramArrayList)
    throws RemoteException, OperationApplicationException
  {
    Parcel localParcel1 = Parcel.obtain();
    Parcel localParcel2 = Parcel.obtain();
    try
    {
      localParcel1.writeInterfaceToken("android.content.IContentProvider");
      localParcel1.writeInt(paramArrayList.size());
      Iterator localIterator = paramArrayList.iterator();
      while (localIterator.hasNext()) {
        ((ContentProviderOperation)localIterator.next()).writeToParcel(localParcel1, 0);
      }
      this.mRemote.transact(20, localParcel1, localParcel2, 0);
    }
    finally
    {
      localParcel1.recycle();
      localParcel2.recycle();
    }
    DatabaseUtils.readExceptionWithOperationApplicationExceptionFromParcel(localParcel2);
    ContentProviderResult[] arrayOfContentProviderResult = (ContentProviderResult[])localParcel2.createTypedArray(ContentProviderResult.CREATOR);
    localParcel1.recycle();
    localParcel2.recycle();
    return arrayOfContentProviderResult;
  }
  
  public IBinder asBinder()
  {
    return this.mRemote;
  }
  
  public int bulkInsert(Uri paramUri, ContentValues[] paramArrayOfContentValues)
    throws RemoteException
  {
    Parcel localParcel1 = Parcel.obtain();
    Parcel localParcel2 = Parcel.obtain();
    try
    {
      localParcel1.writeInterfaceToken("android.content.IContentProvider");
      paramUri.writeToParcel(localParcel1, 0);
      localParcel1.writeTypedArray(paramArrayOfContentValues, 0);
      this.mRemote.transact(13, localParcel1, localParcel2, 0);
      DatabaseUtils.readExceptionFromParcel(localParcel2);
      int i = localParcel2.readInt();
      return i;
    }
    finally
    {
      localParcel1.recycle();
      localParcel2.recycle();
    }
  }
  
  public Bundle call(String paramString1, String paramString2, Bundle paramBundle)
    throws RemoteException
  {
    Parcel localParcel1 = Parcel.obtain();
    Parcel localParcel2 = Parcel.obtain();
    try
    {
      localParcel1.writeInterfaceToken("android.content.IContentProvider");
      localParcel1.writeString(paramString1);
      localParcel1.writeString(paramString2);
      localParcel1.writeBundle(paramBundle);
      this.mRemote.transact(21, localParcel1, localParcel2, 0);
      DatabaseUtils.readExceptionFromParcel(localParcel2);
      Bundle localBundle = localParcel2.readBundle();
      return localBundle;
    }
    finally
    {
      localParcel1.recycle();
      localParcel2.recycle();
    }
  }
  
  public ICancellationSignal createCancellationSignal()
    throws RemoteException
  {
    Parcel localParcel1 = Parcel.obtain();
    Parcel localParcel2 = Parcel.obtain();
    try
    {
      localParcel1.writeInterfaceToken("android.content.IContentProvider");
      this.mRemote.transact(24, localParcel1, localParcel2, 0);
      DatabaseUtils.readExceptionFromParcel(localParcel2);
      ICancellationSignal localICancellationSignal = ICancellationSignal.Stub.asInterface(localParcel2.readStrongBinder());
      return localICancellationSignal;
    }
    finally
    {
      localParcel1.recycle();
      localParcel2.recycle();
    }
  }
  
  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString)
    throws RemoteException
  {
    Parcel localParcel1 = Parcel.obtain();
    Parcel localParcel2 = Parcel.obtain();
    try
    {
      localParcel1.writeInterfaceToken("android.content.IContentProvider");
      paramUri.writeToParcel(localParcel1, 0);
      localParcel1.writeString(paramString);
      localParcel1.writeStringArray(paramArrayOfString);
      this.mRemote.transact(4, localParcel1, localParcel2, 0);
      DatabaseUtils.readExceptionFromParcel(localParcel2);
      int i = localParcel2.readInt();
      return i;
    }
    finally
    {
      localParcel1.recycle();
      localParcel2.recycle();
    }
  }
  
  public String[] getStreamTypes(Uri paramUri, String paramString)
    throws RemoteException
  {
    Parcel localParcel1 = Parcel.obtain();
    Parcel localParcel2 = Parcel.obtain();
    try
    {
      localParcel1.writeInterfaceToken("android.content.IContentProvider");
      paramUri.writeToParcel(localParcel1, 0);
      localParcel1.writeString(paramString);
      this.mRemote.transact(22, localParcel1, localParcel2, 0);
      DatabaseUtils.readExceptionFromParcel(localParcel2);
      String[] arrayOfString = localParcel2.createStringArray();
      return arrayOfString;
    }
    finally
    {
      localParcel1.recycle();
      localParcel2.recycle();
    }
  }
  
  public String getType(Uri paramUri)
    throws RemoteException
  {
    Parcel localParcel1 = Parcel.obtain();
    Parcel localParcel2 = Parcel.obtain();
    try
    {
      localParcel1.writeInterfaceToken("android.content.IContentProvider");
      paramUri.writeToParcel(localParcel1, 0);
      this.mRemote.transact(2, localParcel1, localParcel2, 0);
      DatabaseUtils.readExceptionFromParcel(localParcel2);
      String str = localParcel2.readString();
      return str;
    }
    finally
    {
      localParcel1.recycle();
      localParcel2.recycle();
    }
  }
  
  public Uri insert(Uri paramUri, ContentValues paramContentValues)
    throws RemoteException
  {
    Parcel localParcel1 = Parcel.obtain();
    Parcel localParcel2 = Parcel.obtain();
    try
    {
      localParcel1.writeInterfaceToken("android.content.IContentProvider");
      paramUri.writeToParcel(localParcel1, 0);
      paramContentValues.writeToParcel(localParcel1, 0);
      this.mRemote.transact(3, localParcel1, localParcel2, 0);
      DatabaseUtils.readExceptionFromParcel(localParcel2);
      Uri localUri = (Uri)Uri.CREATOR.createFromParcel(localParcel2);
      return localUri;
    }
    finally
    {
      localParcel1.recycle();
      localParcel2.recycle();
    }
  }
  
  /* Error */
  public android.content.res.AssetFileDescriptor openAssetFile(Uri paramUri, String paramString)
    throws RemoteException, java.io.FileNotFoundException
  {
    // Byte code:
    //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
    //   3: astore_3
    //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
    //   7: astore 4
    //   9: aload_3
    //   10: ldc 29
    //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
    //   15: aload_1
    //   16: aload_3
    //   17: iconst_0
    //   18: invokevirtual 97	android/net/Uri:writeToParcel	(Landroid/os/Parcel;I)V
    //   21: aload_3
    //   22: aload_2
    //   23: invokevirtual 112	android/os/Parcel:writeString	(Ljava/lang/String;)V
    //   26: aload_0
    //   27: getfield 15	android/content/ContentProviderProxy:mRemote	Landroid/os/IBinder;
    //   30: bipush 15
    //   32: aload_3
    //   33: aload 4
    //   35: iconst_0
    //   36: invokeinterface 72 5 0
    //   41: pop
    //   42: aload 4
    //   44: invokestatic 168	android/database/DatabaseUtils:readExceptionWithFileNotFoundExceptionFromParcel	(Landroid/os/Parcel;)V
    //   47: aload 4
    //   49: invokevirtual 107	android/os/Parcel:readInt	()I
    //   52: ifeq +34 -> 86
    //   55: getstatic 171	android/content/res/AssetFileDescriptor:CREATOR	Landroid/os/Parcelable$Creator;
    //   58: aload 4
    //   60: invokeinterface 161 2 0
    //   65: checkcast 170	android/content/res/AssetFileDescriptor
    //   68: astore 8
    //   70: aload 8
    //   72: astore 7
    //   74: aload_3
    //   75: invokevirtual 66	android/os/Parcel:recycle	()V
    //   78: aload 4
    //   80: invokevirtual 66	android/os/Parcel:recycle	()V
    //   83: aload 7
    //   85: areturn
    //   86: aconst_null
    //   87: astore 7
    //   89: goto -15 -> 74
    //   92: astore 5
    //   94: aload_3
    //   95: invokevirtual 66	android/os/Parcel:recycle	()V
    //   98: aload 4
    //   100: invokevirtual 66	android/os/Parcel:recycle	()V
    //   103: aload 5
    //   105: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	106	0	this	ContentProviderProxy
    //   0	106	1	paramUri	Uri
    //   0	106	2	paramString	String
    //   3	92	3	localParcel1	Parcel
    //   7	92	4	localParcel2	Parcel
    //   92	12	5	localObject	Object
    //   72	16	7	localAssetFileDescriptor1	android.content.res.AssetFileDescriptor
    //   68	3	8	localAssetFileDescriptor2	android.content.res.AssetFileDescriptor
    // Exception table:
    //   from	to	target	type
    //   9	70	92	finally
  }
  
  /* Error */
  public android.os.ParcelFileDescriptor openFile(Uri paramUri, String paramString)
    throws RemoteException, java.io.FileNotFoundException
  {
    // Byte code:
    //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
    //   3: astore_3
    //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
    //   7: astore 4
    //   9: aload_3
    //   10: ldc 29
    //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
    //   15: aload_1
    //   16: aload_3
    //   17: iconst_0
    //   18: invokevirtual 97	android/net/Uri:writeToParcel	(Landroid/os/Parcel;I)V
    //   21: aload_3
    //   22: aload_2
    //   23: invokevirtual 112	android/os/Parcel:writeString	(Ljava/lang/String;)V
    //   26: aload_0
    //   27: getfield 15	android/content/ContentProviderProxy:mRemote	Landroid/os/IBinder;
    //   30: bipush 14
    //   32: aload_3
    //   33: aload 4
    //   35: iconst_0
    //   36: invokeinterface 72 5 0
    //   41: pop
    //   42: aload 4
    //   44: invokestatic 168	android/database/DatabaseUtils:readExceptionWithFileNotFoundExceptionFromParcel	(Landroid/os/Parcel;)V
    //   47: aload 4
    //   49: invokevirtual 107	android/os/Parcel:readInt	()I
    //   52: ifeq +26 -> 78
    //   55: aload 4
    //   57: invokevirtual 177	android/os/Parcel:readFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   60: astore 8
    //   62: aload 8
    //   64: astore 7
    //   66: aload_3
    //   67: invokevirtual 66	android/os/Parcel:recycle	()V
    //   70: aload 4
    //   72: invokevirtual 66	android/os/Parcel:recycle	()V
    //   75: aload 7
    //   77: areturn
    //   78: aconst_null
    //   79: astore 7
    //   81: goto -15 -> 66
    //   84: astore 5
    //   86: aload_3
    //   87: invokevirtual 66	android/os/Parcel:recycle	()V
    //   90: aload 4
    //   92: invokevirtual 66	android/os/Parcel:recycle	()V
    //   95: aload 5
    //   97: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	98	0	this	ContentProviderProxy
    //   0	98	1	paramUri	Uri
    //   0	98	2	paramString	String
    //   3	84	3	localParcel1	Parcel
    //   7	84	4	localParcel2	Parcel
    //   84	12	5	localObject	Object
    //   64	16	7	localParcelFileDescriptor1	android.os.ParcelFileDescriptor
    //   60	3	8	localParcelFileDescriptor2	android.os.ParcelFileDescriptor
    // Exception table:
    //   from	to	target	type
    //   9	62	84	finally
  }
  
  /* Error */
  public android.content.res.AssetFileDescriptor openTypedAssetFile(Uri paramUri, String paramString, Bundle paramBundle)
    throws RemoteException, java.io.FileNotFoundException
  {
    // Byte code:
    //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
    //   3: astore 4
    //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
    //   8: astore 5
    //   10: aload 4
    //   12: ldc 29
    //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
    //   17: aload_1
    //   18: aload 4
    //   20: iconst_0
    //   21: invokevirtual 97	android/net/Uri:writeToParcel	(Landroid/os/Parcel;I)V
    //   24: aload 4
    //   26: aload_2
    //   27: invokevirtual 112	android/os/Parcel:writeString	(Ljava/lang/String;)V
    //   30: aload 4
    //   32: aload_3
    //   33: invokevirtual 116	android/os/Parcel:writeBundle	(Landroid/os/Bundle;)V
    //   36: aload_0
    //   37: getfield 15	android/content/ContentProviderProxy:mRemote	Landroid/os/IBinder;
    //   40: bipush 23
    //   42: aload 4
    //   44: aload 5
    //   46: iconst_0
    //   47: invokeinterface 72 5 0
    //   52: pop
    //   53: aload 5
    //   55: invokestatic 168	android/database/DatabaseUtils:readExceptionWithFileNotFoundExceptionFromParcel	(Landroid/os/Parcel;)V
    //   58: aload 5
    //   60: invokevirtual 107	android/os/Parcel:readInt	()I
    //   63: ifeq +35 -> 98
    //   66: getstatic 171	android/content/res/AssetFileDescriptor:CREATOR	Landroid/os/Parcelable$Creator;
    //   69: aload 5
    //   71: invokeinterface 161 2 0
    //   76: checkcast 170	android/content/res/AssetFileDescriptor
    //   79: astore 9
    //   81: aload 9
    //   83: astore 8
    //   85: aload 4
    //   87: invokevirtual 66	android/os/Parcel:recycle	()V
    //   90: aload 5
    //   92: invokevirtual 66	android/os/Parcel:recycle	()V
    //   95: aload 8
    //   97: areturn
    //   98: aconst_null
    //   99: astore 8
    //   101: goto -16 -> 85
    //   104: astore 6
    //   106: aload 4
    //   108: invokevirtual 66	android/os/Parcel:recycle	()V
    //   111: aload 5
    //   113: invokevirtual 66	android/os/Parcel:recycle	()V
    //   116: aload 6
    //   118: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	119	0	this	ContentProviderProxy
    //   0	119	1	paramUri	Uri
    //   0	119	2	paramString	String
    //   0	119	3	paramBundle	Bundle
    //   3	104	4	localParcel1	Parcel
    //   8	104	5	localParcel2	Parcel
    //   104	13	6	localObject	Object
    //   83	17	8	localAssetFileDescriptor1	android.content.res.AssetFileDescriptor
    //   79	3	9	localAssetFileDescriptor2	android.content.res.AssetFileDescriptor
    // Exception table:
    //   from	to	target	type
    //   10	81	104	finally
  }
  
  /* Error */
  public android.database.Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2, ICancellationSignal paramICancellationSignal)
    throws RemoteException
  {
    // Byte code:
    //   0: new 185	android/database/BulkCursorToCursorAdaptor
    //   3: dup
    //   4: invokespecial 186	android/database/BulkCursorToCursorAdaptor:<init>	()V
    //   7: astore 7
    //   9: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
    //   12: astore 8
    //   14: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
    //   17: astore 9
    //   19: aload 8
    //   21: ldc 29
    //   23: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
    //   26: aload_1
    //   27: aload 8
    //   29: iconst_0
    //   30: invokevirtual 97	android/net/Uri:writeToParcel	(Landroid/os/Parcel;I)V
    //   33: iconst_0
    //   34: istore 13
    //   36: aload_2
    //   37: ifnull +7 -> 44
    //   40: aload_2
    //   41: arraylength
    //   42: istore 13
    //   44: aload 8
    //   46: iload 13
    //   48: invokevirtual 43	android/os/Parcel:writeInt	(I)V
    //   51: iconst_0
    //   52: istore 14
    //   54: iload 14
    //   56: iload 13
    //   58: if_icmpge +18 -> 76
    //   61: aload 8
    //   63: aload_2
    //   64: iload 14
    //   66: aaload
    //   67: invokevirtual 112	android/os/Parcel:writeString	(Ljava/lang/String;)V
    //   70: iinc 14 1
    //   73: goto -19 -> 54
    //   76: aload 8
    //   78: aload_3
    //   79: invokevirtual 112	android/os/Parcel:writeString	(Ljava/lang/String;)V
    //   82: aload 4
    //   84: ifnull +196 -> 280
    //   87: aload 4
    //   89: arraylength
    //   90: istore 15
    //   92: aload 8
    //   94: iload 15
    //   96: invokevirtual 43	android/os/Parcel:writeInt	(I)V
    //   99: iconst_0
    //   100: istore 16
    //   102: iload 16
    //   104: iload 15
    //   106: if_icmpge +19 -> 125
    //   109: aload 8
    //   111: aload 4
    //   113: iload 16
    //   115: aaload
    //   116: invokevirtual 112	android/os/Parcel:writeString	(Ljava/lang/String;)V
    //   119: iinc 16 1
    //   122: goto -20 -> 102
    //   125: aload 8
    //   127: aload 5
    //   129: invokevirtual 112	android/os/Parcel:writeString	(Ljava/lang/String;)V
    //   132: aload 8
    //   134: aload 7
    //   136: invokevirtual 190	android/database/BulkCursorToCursorAdaptor:getObserver	()Landroid/database/IContentObserver;
    //   139: invokeinterface 194 1 0
    //   144: invokevirtual 197	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
    //   147: aload 6
    //   149: ifnull +79 -> 228
    //   152: aload 6
    //   154: invokeinterface 200 1 0
    //   159: astore 17
    //   161: aload 8
    //   163: aload 17
    //   165: invokevirtual 197	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
    //   168: aload_0
    //   169: getfield 15	android/content/ContentProviderProxy:mRemote	Landroid/os/IBinder;
    //   172: iconst_1
    //   173: aload 8
    //   175: aload 9
    //   177: iconst_0
    //   178: invokeinterface 72 5 0
    //   183: pop
    //   184: aload 9
    //   186: invokestatic 104	android/database/DatabaseUtils:readExceptionFromParcel	(Landroid/os/Parcel;)V
    //   189: aload 9
    //   191: invokevirtual 107	android/os/Parcel:readInt	()I
    //   194: ifeq +40 -> 234
    //   197: aload 7
    //   199: getstatic 203	android/database/BulkCursorDescriptor:CREATOR	Landroid/os/Parcelable$Creator;
    //   202: aload 9
    //   204: invokeinterface 161 2 0
    //   209: checkcast 202	android/database/BulkCursorDescriptor
    //   212: invokevirtual 207	android/database/BulkCursorToCursorAdaptor:initialize	(Landroid/database/BulkCursorDescriptor;)V
    //   215: aload 8
    //   217: invokevirtual 66	android/os/Parcel:recycle	()V
    //   220: aload 9
    //   222: invokevirtual 66	android/os/Parcel:recycle	()V
    //   225: aload 7
    //   227: areturn
    //   228: aconst_null
    //   229: astore 17
    //   231: goto -70 -> 161
    //   234: aload 7
    //   236: invokevirtual 210	android/database/BulkCursorToCursorAdaptor:close	()V
    //   239: aconst_null
    //   240: astore 7
    //   242: goto -27 -> 215
    //   245: astore 12
    //   247: aload 7
    //   249: invokevirtual 210	android/database/BulkCursorToCursorAdaptor:close	()V
    //   252: aload 12
    //   254: athrow
    //   255: astore 11
    //   257: aload 8
    //   259: invokevirtual 66	android/os/Parcel:recycle	()V
    //   262: aload 9
    //   264: invokevirtual 66	android/os/Parcel:recycle	()V
    //   267: aload 11
    //   269: athrow
    //   270: astore 10
    //   272: aload 7
    //   274: invokevirtual 210	android/database/BulkCursorToCursorAdaptor:close	()V
    //   277: aload 10
    //   279: athrow
    //   280: iconst_0
    //   281: istore 15
    //   283: goto -191 -> 92
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	286	0	this	ContentProviderProxy
    //   0	286	1	paramUri	Uri
    //   0	286	2	paramArrayOfString1	String[]
    //   0	286	3	paramString1	String
    //   0	286	4	paramArrayOfString2	String[]
    //   0	286	5	paramString2	String
    //   0	286	6	paramICancellationSignal	ICancellationSignal
    //   7	266	7	localBulkCursorToCursorAdaptor	android.database.BulkCursorToCursorAdaptor
    //   12	246	8	localParcel1	Parcel
    //   17	246	9	localParcel2	Parcel
    //   270	8	10	localRuntimeException	RuntimeException
    //   255	13	11	localObject	Object
    //   245	8	12	localRemoteException	RemoteException
    //   34	25	13	i	int
    //   52	19	14	j	int
    //   90	192	15	k	int
    //   100	20	16	m	int
    //   159	71	17	localIBinder	IBinder
    // Exception table:
    //   from	to	target	type
    //   19	33	245	android/os/RemoteException
    //   40	44	245	android/os/RemoteException
    //   44	51	245	android/os/RemoteException
    //   61	70	245	android/os/RemoteException
    //   76	82	245	android/os/RemoteException
    //   87	92	245	android/os/RemoteException
    //   92	99	245	android/os/RemoteException
    //   109	119	245	android/os/RemoteException
    //   125	147	245	android/os/RemoteException
    //   152	161	245	android/os/RemoteException
    //   161	215	245	android/os/RemoteException
    //   234	239	245	android/os/RemoteException
    //   19	33	255	finally
    //   40	44	255	finally
    //   44	51	255	finally
    //   61	70	255	finally
    //   76	82	255	finally
    //   87	92	255	finally
    //   92	99	255	finally
    //   109	119	255	finally
    //   125	147	255	finally
    //   152	161	255	finally
    //   161	215	255	finally
    //   234	239	255	finally
    //   247	255	255	finally
    //   272	280	255	finally
    //   19	33	270	java/lang/RuntimeException
    //   40	44	270	java/lang/RuntimeException
    //   44	51	270	java/lang/RuntimeException
    //   61	70	270	java/lang/RuntimeException
    //   76	82	270	java/lang/RuntimeException
    //   87	92	270	java/lang/RuntimeException
    //   92	99	270	java/lang/RuntimeException
    //   109	119	270	java/lang/RuntimeException
    //   125	147	270	java/lang/RuntimeException
    //   152	161	270	java/lang/RuntimeException
    //   161	215	270	java/lang/RuntimeException
    //   234	239	270	java/lang/RuntimeException
  }
  
  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString)
    throws RemoteException
  {
    Parcel localParcel1 = Parcel.obtain();
    Parcel localParcel2 = Parcel.obtain();
    try
    {
      localParcel1.writeInterfaceToken("android.content.IContentProvider");
      paramUri.writeToParcel(localParcel1, 0);
      paramContentValues.writeToParcel(localParcel1, 0);
      localParcel1.writeString(paramString);
      localParcel1.writeStringArray(paramArrayOfString);
      this.mRemote.transact(10, localParcel1, localParcel2, 0);
      DatabaseUtils.readExceptionFromParcel(localParcel2);
      int i = localParcel2.readInt();
      return i;
    }
    finally
    {
      localParcel1.recycle();
      localParcel2.recycle();
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\ContentProviderProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
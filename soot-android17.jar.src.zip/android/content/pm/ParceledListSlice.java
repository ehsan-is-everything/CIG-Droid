package android.content.pm;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.List;

public class ParceledListSlice<T extends Parcelable>
  implements Parcelable
{
  public static final Parcelable.Creator<ParceledListSlice> CREATOR = new Parcelable.Creator()
  {
    public ParceledListSlice createFromParcel(Parcel paramAnonymousParcel)
    {
      int i = 1;
      int k = paramAnonymousParcel.readInt();
      if (paramAnonymousParcel.readInt() == i) {}
      while (k > 0)
      {
        int m = paramAnonymousParcel.readInt();
        int n = paramAnonymousParcel.dataPosition();
        paramAnonymousParcel.setDataPosition(n + m);
        Parcel localParcel = Parcel.obtain();
        localParcel.setDataPosition(0);
        localParcel.appendFrom(paramAnonymousParcel, n, m);
        localParcel.setDataPosition(0);
        return new ParceledListSlice(localParcel, k, i, null);
        int j = 0;
      }
      return new ParceledListSlice();
    }
    
    public ParceledListSlice[] newArray(int paramAnonymousInt)
    {
      return new ParceledListSlice[paramAnonymousInt];
    }
  };
  private static final int MAX_IPC_SIZE = 262144;
  private boolean mIsLastSlice;
  private int mNumItems;
  private Parcel mParcel;
  
  public ParceledListSlice()
  {
    this.mParcel = Parcel.obtain();
  }
  
  private ParceledListSlice(Parcel paramParcel, int paramInt, boolean paramBoolean)
  {
    this.mParcel = paramParcel;
    this.mNumItems = paramInt;
    this.mIsLastSlice = paramBoolean;
  }
  
  public boolean append(T paramT)
  {
    if (this.mParcel == null) {
      throw new IllegalStateException("ParceledListSlice has already been recycled");
    }
    paramT.writeToParcel(this.mParcel, 1);
    this.mNumItems = (1 + this.mNumItems);
    return this.mParcel.dataSize() > 262144;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean isLastSlice()
  {
    return this.mIsLastSlice;
  }
  
  public T populateList(List<T> paramList, Parcelable.Creator<T> paramCreator)
  {
    this.mParcel.setDataPosition(0);
    Parcelable localParcelable = null;
    for (int i = 0; i < this.mNumItems; i++)
    {
      localParcelable = (Parcelable)paramCreator.createFromParcel(this.mParcel);
      paramList.add(localParcelable);
    }
    this.mParcel.recycle();
    this.mParcel = null;
    return localParcelable;
  }
  
  public void setLastSlice(boolean paramBoolean)
  {
    this.mIsLastSlice = paramBoolean;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeInt(this.mNumItems);
    if (this.mIsLastSlice) {}
    for (int i = 1;; i = 0)
    {
      paramParcel.writeInt(i);
      if (this.mNumItems > 0)
      {
        int j = this.mParcel.dataSize();
        paramParcel.writeInt(j);
        paramParcel.appendFrom(this.mParcel, 0, j);
      }
      this.mNumItems = 0;
      this.mParcel.recycle();
      this.mParcel = null;
      return;
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\pm\ParceledListSlice.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.content.pm;

public abstract interface RegisteredServicesCacheListener<V>
{
  public abstract void onServiceChanged(V paramV, int paramInt, boolean paramBoolean);
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\pm\RegisteredServicesCacheListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.content.pm;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.UserHandle;

public class UserInfo
  implements Parcelable
{
  public static final Parcelable.Creator<UserInfo> CREATOR = new Parcelable.Creator()
  {
    public UserInfo createFromParcel(Parcel paramAnonymousParcel)
    {
      return new UserInfo(paramAnonymousParcel, null);
    }
    
    public UserInfo[] newArray(int paramAnonymousInt)
    {
      return new UserInfo[paramAnonymousInt];
    }
  };
  public static final int FLAG_ADMIN = 2;
  public static final int FLAG_GUEST = 4;
  public static final int FLAG_INITIALIZED = 16;
  public static final int FLAG_MASK_USER_TYPE = 63;
  public static final int FLAG_PRIMARY = 1;
  public static final int FLAG_RESTRICTED = 8;
  public long creationTime;
  public int flags;
  public String iconPath;
  public int id;
  public long lastLoggedInTime;
  public String name;
  public boolean partial;
  public int serialNumber;
  
  public UserInfo() {}
  
  public UserInfo(int paramInt1, String paramString, int paramInt2)
  {
    this(paramInt1, paramString, null, paramInt2);
  }
  
  public UserInfo(int paramInt1, String paramString1, String paramString2, int paramInt2)
  {
    this.id = paramInt1;
    this.name = paramString1;
    this.flags = paramInt2;
    this.iconPath = paramString2;
  }
  
  public UserInfo(UserInfo paramUserInfo)
  {
    this.name = paramUserInfo.name;
    this.iconPath = paramUserInfo.iconPath;
    this.id = paramUserInfo.id;
    this.flags = paramUserInfo.flags;
    this.serialNumber = paramUserInfo.serialNumber;
    this.creationTime = paramUserInfo.creationTime;
    this.lastLoggedInTime = paramUserInfo.lastLoggedInTime;
    this.partial = paramUserInfo.partial;
  }
  
  private UserInfo(Parcel paramParcel)
  {
    this.id = paramParcel.readInt();
    this.name = paramParcel.readString();
    this.iconPath = paramParcel.readString();
    this.flags = paramParcel.readInt();
    this.serialNumber = paramParcel.readInt();
    this.creationTime = paramParcel.readLong();
    this.lastLoggedInTime = paramParcel.readLong();
    if (paramParcel.readInt() != 0) {}
    for (boolean bool = true;; bool = false)
    {
      this.partial = bool;
      return;
    }
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public UserHandle getUserHandle()
  {
    return new UserHandle(this.id);
  }
  
  public boolean isAdmin()
  {
    return (0x2 & this.flags) == 2;
  }
  
  public boolean isGuest()
  {
    return (0x4 & this.flags) == 4;
  }
  
  public boolean isPrimary()
  {
    return (0x1 & this.flags) == 1;
  }
  
  public String toString()
  {
    return "UserInfo{" + this.id + ":" + this.name + ":" + Integer.toHexString(this.flags) + "}";
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeInt(this.id);
    paramParcel.writeString(this.name);
    paramParcel.writeString(this.iconPath);
    paramParcel.writeInt(this.flags);
    paramParcel.writeInt(this.serialNumber);
    paramParcel.writeLong(this.creationTime);
    paramParcel.writeLong(this.lastLoggedInTime);
    if (this.partial) {}
    for (int i = 1;; i = 0)
    {
      paramParcel.writeInt(i);
      return;
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\pm\UserInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
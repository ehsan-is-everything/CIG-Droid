package android.content.pm;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.Base64;
import java.util.Arrays;
import java.util.jar.Attributes;

public class ManifestDigest
  implements Parcelable
{
  public static final Parcelable.Creator<ManifestDigest> CREATOR = new Parcelable.Creator()
  {
    public ManifestDigest createFromParcel(Parcel paramAnonymousParcel)
    {
      return new ManifestDigest(paramAnonymousParcel, null);
    }
    
    public ManifestDigest[] newArray(int paramAnonymousInt)
    {
      return new ManifestDigest[paramAnonymousInt];
    }
  };
  private static final String[] DIGEST_TYPES = { "SHA1-Digest", "SHA-Digest", "MD5-Digest" };
  private static final String TO_STRING_PREFIX = "ManifestDigest {mDigest=";
  private final byte[] mDigest;
  
  private ManifestDigest(Parcel paramParcel)
  {
    this.mDigest = paramParcel.createByteArray();
  }
  
  ManifestDigest(byte[] paramArrayOfByte)
  {
    this.mDigest = paramArrayOfByte;
  }
  
  static ManifestDigest fromAttributes(Attributes paramAttributes)
  {
    if (paramAttributes == null) {
      return null;
    }
    for (int i = 0;; i++)
    {
      int j = DIGEST_TYPES.length;
      Object localObject = null;
      if (i < j)
      {
        String str = paramAttributes.getValue(DIGEST_TYPES[i]);
        if (str != null) {
          localObject = str;
        }
      }
      else
      {
        if (localObject == null) {
          break;
        }
        return new ManifestDigest(Base64.decode((String)localObject, 0));
      }
    }
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof ManifestDigest)) {}
    ManifestDigest localManifestDigest;
    do
    {
      return false;
      localManifestDigest = (ManifestDigest)paramObject;
    } while ((this != localManifestDigest) && (!Arrays.equals(this.mDigest, localManifestDigest.mDigest)));
    return true;
  }
  
  public int hashCode()
  {
    return Arrays.hashCode(this.mDigest);
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(1 + ("ManifestDigest {mDigest=".length() + 3 * this.mDigest.length));
    localStringBuilder.append("ManifestDigest {mDigest=");
    int i = this.mDigest.length;
    for (int j = 0; j < i; j++)
    {
      IntegralToString.appendByteAsHex(localStringBuilder, this.mDigest[j], false);
      localStringBuilder.append(',');
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeByteArray(this.mDigest);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\pm\ManifestDigest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.content.pm;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class VerificationParams
  implements Parcelable
{
  public static final Parcelable.Creator<VerificationParams> CREATOR = new Parcelable.Creator()
  {
    public VerificationParams createFromParcel(Parcel paramAnonymousParcel)
    {
      return new VerificationParams(paramAnonymousParcel, null);
    }
    
    public VerificationParams[] newArray(int paramAnonymousInt)
    {
      return new VerificationParams[paramAnonymousInt];
    }
  };
  public static final int NO_UID = -1;
  private static final String TO_STRING_PREFIX = "VerificationParams{";
  private int mInstallerUid;
  private final ManifestDigest mManifestDigest;
  private final Uri mOriginatingURI;
  private final int mOriginatingUid;
  private final Uri mReferrer;
  private final Uri mVerificationURI;
  
  public VerificationParams(Uri paramUri1, Uri paramUri2, Uri paramUri3, int paramInt, ManifestDigest paramManifestDigest)
  {
    this.mVerificationURI = paramUri1;
    this.mOriginatingURI = paramUri2;
    this.mReferrer = paramUri3;
    this.mOriginatingUid = paramInt;
    this.mManifestDigest = paramManifestDigest;
    this.mInstallerUid = -1;
  }
  
  private VerificationParams(Parcel paramParcel)
  {
    this.mVerificationURI = ((Uri)paramParcel.readParcelable(Uri.class.getClassLoader()));
    this.mOriginatingURI = ((Uri)paramParcel.readParcelable(Uri.class.getClassLoader()));
    this.mReferrer = ((Uri)paramParcel.readParcelable(Uri.class.getClassLoader()));
    this.mOriginatingUid = paramParcel.readInt();
    this.mManifestDigest = ((ManifestDigest)paramParcel.readParcelable(ManifestDigest.class.getClassLoader()));
    this.mInstallerUid = paramParcel.readInt();
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    VerificationParams localVerificationParams;
    do
    {
      return true;
      if (!(paramObject instanceof VerificationParams)) {
        return false;
      }
      localVerificationParams = (VerificationParams)paramObject;
      if (this.mVerificationURI == null)
      {
        if (localVerificationParams.mVerificationURI != null) {
          return false;
        }
      }
      else if (!this.mVerificationURI.equals(localVerificationParams.mVerificationURI)) {
        return false;
      }
      if (this.mOriginatingURI == null)
      {
        if (localVerificationParams.mOriginatingURI != null) {
          return false;
        }
      }
      else if (!this.mOriginatingURI.equals(localVerificationParams.mOriginatingURI)) {
        return false;
      }
      if (this.mReferrer == null)
      {
        if (localVerificationParams.mReferrer != null) {
          return false;
        }
      }
      else if (!this.mReferrer.equals(localVerificationParams.mReferrer)) {
        return false;
      }
      if (this.mOriginatingUid != localVerificationParams.mOriginatingUid) {
        return false;
      }
      if (this.mManifestDigest == null)
      {
        if (localVerificationParams.mManifestDigest != null) {
          return false;
        }
      }
      else if (!this.mManifestDigest.equals(localVerificationParams.mManifestDigest)) {
        return false;
      }
    } while (this.mInstallerUid == localVerificationParams.mInstallerUid);
    return false;
  }
  
  public int getInstallerUid()
  {
    return this.mInstallerUid;
  }
  
  public ManifestDigest getManifestDigest()
  {
    return this.mManifestDigest;
  }
  
  public Uri getOriginatingURI()
  {
    return this.mOriginatingURI;
  }
  
  public int getOriginatingUid()
  {
    return this.mOriginatingUid;
  }
  
  public Uri getReferrer()
  {
    return this.mReferrer;
  }
  
  public Uri getVerificationURI()
  {
    return this.mVerificationURI;
  }
  
  public int hashCode()
  {
    int i = 1;
    int j;
    int m;
    label27:
    int i1;
    label46:
    int i2;
    if (this.mVerificationURI == null)
    {
      j = i;
      int k = 3 + j * 5;
      if (this.mOriginatingURI != null) {
        break label98;
      }
      m = i;
      int n = k + m * 7;
      if (this.mReferrer != null) {
        break label110;
      }
      i1 = i;
      i2 = n + i1 * 11 + 13 * this.mOriginatingUid;
      if (this.mManifestDigest != null) {
        break label122;
      }
    }
    for (;;)
    {
      return i2 + i * 17 + 19 * this.mInstallerUid;
      j = this.mVerificationURI.hashCode();
      break;
      label98:
      m = this.mOriginatingURI.hashCode();
      break label27;
      label110:
      i1 = this.mReferrer.hashCode();
      break label46;
      label122:
      i = this.mManifestDigest.hashCode();
    }
  }
  
  public void setInstallerUid(int paramInt)
  {
    this.mInstallerUid = paramInt;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("VerificationParams{");
    localStringBuilder.append("mVerificationURI=");
    localStringBuilder.append(this.mVerificationURI.toString());
    localStringBuilder.append(",mOriginatingURI=");
    localStringBuilder.append(this.mOriginatingURI.toString());
    localStringBuilder.append(",mReferrer=");
    localStringBuilder.append(this.mReferrer.toString());
    localStringBuilder.append(",mOriginatingUid=");
    localStringBuilder.append(this.mOriginatingUid);
    localStringBuilder.append(",mManifestDigest=");
    localStringBuilder.append(this.mManifestDigest.toString());
    localStringBuilder.append(",mInstallerUid=");
    localStringBuilder.append(this.mInstallerUid);
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeParcelable(this.mVerificationURI, 0);
    paramParcel.writeParcelable(this.mOriginatingURI, 0);
    paramParcel.writeParcelable(this.mReferrer, 0);
    paramParcel.writeInt(this.mOriginatingUid);
    paramParcel.writeParcelable(this.mManifestDigest, 0);
    paramParcel.writeInt(this.mInstallerUid);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\pm\VerificationParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
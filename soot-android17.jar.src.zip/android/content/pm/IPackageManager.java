package android.content.pm;

import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import java.util.ArrayList;
import java.util.List;

public abstract interface IPackageManager
  extends IInterface
{
  public abstract void addPackageToPreferred(String paramString)
    throws RemoteException;
  
  public abstract boolean addPermission(PermissionInfo paramPermissionInfo)
    throws RemoteException;
  
  public abstract boolean addPermissionAsync(PermissionInfo paramPermissionInfo)
    throws RemoteException;
  
  public abstract void addPreferredActivity(IntentFilter paramIntentFilter, int paramInt1, ComponentName[] paramArrayOfComponentName, ComponentName paramComponentName, int paramInt2)
    throws RemoteException;
  
  public abstract String[] canonicalToCurrentPackageNames(String[] paramArrayOfString)
    throws RemoteException;
  
  public abstract int checkPermission(String paramString1, String paramString2)
    throws RemoteException;
  
  public abstract int checkSignatures(String paramString1, String paramString2)
    throws RemoteException;
  
  public abstract int checkUidPermission(String paramString, int paramInt)
    throws RemoteException;
  
  public abstract int checkUidSignatures(int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract void clearApplicationUserData(String paramString, IPackageDataObserver paramIPackageDataObserver, int paramInt)
    throws RemoteException;
  
  public abstract void clearPackagePreferredActivities(String paramString)
    throws RemoteException;
  
  public abstract String[] currentToCanonicalPackageNames(String[] paramArrayOfString)
    throws RemoteException;
  
  public abstract void deleteApplicationCacheFiles(String paramString, IPackageDataObserver paramIPackageDataObserver)
    throws RemoteException;
  
  public abstract void deletePackage(String paramString, IPackageDeleteObserver paramIPackageDeleteObserver, int paramInt)
    throws RemoteException;
  
  public abstract void enterSafeMode()
    throws RemoteException;
  
  public abstract void extendVerificationTimeout(int paramInt1, int paramInt2, long paramLong)
    throws RemoteException;
  
  public abstract void finishPackageInstall(int paramInt)
    throws RemoteException;
  
  public abstract void freeStorage(long paramLong, IntentSender paramIntentSender)
    throws RemoteException;
  
  public abstract void freeStorageAndNotify(long paramLong, IPackageDataObserver paramIPackageDataObserver)
    throws RemoteException;
  
  public abstract ActivityInfo getActivityInfo(ComponentName paramComponentName, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract List<PermissionGroupInfo> getAllPermissionGroups(int paramInt)
    throws RemoteException;
  
  public abstract int getApplicationEnabledSetting(String paramString, int paramInt)
    throws RemoteException;
  
  public abstract ApplicationInfo getApplicationInfo(String paramString, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract int getComponentEnabledSetting(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract int getInstallLocation()
    throws RemoteException;
  
  public abstract ParceledListSlice getInstalledApplications(int paramInt1, String paramString, int paramInt2)
    throws RemoteException;
  
  public abstract ParceledListSlice getInstalledPackages(int paramInt1, String paramString, int paramInt2)
    throws RemoteException;
  
  public abstract String getInstallerPackageName(String paramString)
    throws RemoteException;
  
  public abstract InstrumentationInfo getInstrumentationInfo(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract String getNameForUid(int paramInt)
    throws RemoteException;
  
  public abstract int[] getPackageGids(String paramString)
    throws RemoteException;
  
  public abstract PackageInfo getPackageInfo(String paramString, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract void getPackageSizeInfo(String paramString, int paramInt, IPackageStatsObserver paramIPackageStatsObserver)
    throws RemoteException;
  
  public abstract int getPackageUid(String paramString, int paramInt)
    throws RemoteException;
  
  public abstract String[] getPackagesForUid(int paramInt)
    throws RemoteException;
  
  public abstract PermissionGroupInfo getPermissionGroupInfo(String paramString, int paramInt)
    throws RemoteException;
  
  public abstract PermissionInfo getPermissionInfo(String paramString, int paramInt)
    throws RemoteException;
  
  public abstract List<ApplicationInfo> getPersistentApplications(int paramInt)
    throws RemoteException;
  
  public abstract int getPreferredActivities(List<IntentFilter> paramList, List<ComponentName> paramList1, String paramString)
    throws RemoteException;
  
  public abstract List<PackageInfo> getPreferredPackages(int paramInt)
    throws RemoteException;
  
  public abstract ProviderInfo getProviderInfo(ComponentName paramComponentName, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract ActivityInfo getReceiverInfo(ComponentName paramComponentName, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract ServiceInfo getServiceInfo(ComponentName paramComponentName, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract FeatureInfo[] getSystemAvailableFeatures()
    throws RemoteException;
  
  public abstract String[] getSystemSharedLibraryNames()
    throws RemoteException;
  
  public abstract int getUidForSharedUser(String paramString)
    throws RemoteException;
  
  public abstract VerifierDeviceIdentity getVerifierDeviceIdentity()
    throws RemoteException;
  
  public abstract void grantPermission(String paramString1, String paramString2)
    throws RemoteException;
  
  public abstract boolean hasSystemFeature(String paramString)
    throws RemoteException;
  
  public abstract boolean hasSystemUidErrors()
    throws RemoteException;
  
  public abstract int installExistingPackage(String paramString)
    throws RemoteException;
  
  public abstract void installPackage(Uri paramUri, IPackageInstallObserver paramIPackageInstallObserver, int paramInt, String paramString)
    throws RemoteException;
  
  public abstract void installPackageWithVerification(Uri paramUri1, IPackageInstallObserver paramIPackageInstallObserver, int paramInt, String paramString, Uri paramUri2, ManifestDigest paramManifestDigest, ContainerEncryptionParams paramContainerEncryptionParams)
    throws RemoteException;
  
  public abstract void installPackageWithVerificationAndEncryption(Uri paramUri, IPackageInstallObserver paramIPackageInstallObserver, int paramInt, String paramString, VerificationParams paramVerificationParams, ContainerEncryptionParams paramContainerEncryptionParams)
    throws RemoteException;
  
  public abstract boolean isFirstBoot()
    throws RemoteException;
  
  public abstract boolean isPermissionEnforced(String paramString)
    throws RemoteException;
  
  public abstract boolean isProtectedBroadcast(String paramString)
    throws RemoteException;
  
  public abstract boolean isSafeMode()
    throws RemoteException;
  
  public abstract boolean isStorageLow()
    throws RemoteException;
  
  public abstract void movePackage(String paramString, IPackageMoveObserver paramIPackageMoveObserver, int paramInt)
    throws RemoteException;
  
  public abstract PackageCleanItem nextPackageToClean(PackageCleanItem paramPackageCleanItem)
    throws RemoteException;
  
  public abstract void performBootDexOpt()
    throws RemoteException;
  
  public abstract boolean performDexOpt(String paramString)
    throws RemoteException;
  
  public abstract List<ProviderInfo> queryContentProviders(String paramString, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract List<InstrumentationInfo> queryInstrumentation(String paramString, int paramInt)
    throws RemoteException;
  
  public abstract List<ResolveInfo> queryIntentActivities(Intent paramIntent, String paramString, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract List<ResolveInfo> queryIntentActivityOptions(ComponentName paramComponentName, Intent[] paramArrayOfIntent, String[] paramArrayOfString, Intent paramIntent, String paramString, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract List<ResolveInfo> queryIntentReceivers(Intent paramIntent, String paramString, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract List<ResolveInfo> queryIntentServices(Intent paramIntent, String paramString, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract List<PermissionInfo> queryPermissionsByGroup(String paramString, int paramInt)
    throws RemoteException;
  
  public abstract void querySyncProviders(List<String> paramList, List<ProviderInfo> paramList1)
    throws RemoteException;
  
  public abstract void removePackageFromPreferred(String paramString)
    throws RemoteException;
  
  public abstract void removePermission(String paramString)
    throws RemoteException;
  
  public abstract void replacePreferredActivity(IntentFilter paramIntentFilter, int paramInt, ComponentName[] paramArrayOfComponentName, ComponentName paramComponentName)
    throws RemoteException;
  
  public abstract ProviderInfo resolveContentProvider(String paramString, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract ResolveInfo resolveIntent(Intent paramIntent, String paramString, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract ResolveInfo resolveService(Intent paramIntent, String paramString, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract void revokePermission(String paramString1, String paramString2)
    throws RemoteException;
  
  public abstract void setApplicationEnabledSetting(String paramString, int paramInt1, int paramInt2, int paramInt3)
    throws RemoteException;
  
  public abstract void setComponentEnabledSetting(ComponentName paramComponentName, int paramInt1, int paramInt2, int paramInt3)
    throws RemoteException;
  
  public abstract boolean setInstallLocation(int paramInt)
    throws RemoteException;
  
  public abstract void setInstallerPackageName(String paramString1, String paramString2)
    throws RemoteException;
  
  public abstract void setPackageStoppedState(String paramString, boolean paramBoolean, int paramInt)
    throws RemoteException;
  
  public abstract void setPermissionEnforced(String paramString, boolean paramBoolean)
    throws RemoteException;
  
  public abstract void systemReady()
    throws RemoteException;
  
  public abstract void updateExternalMediaStatus(boolean paramBoolean1, boolean paramBoolean2)
    throws RemoteException;
  
  public abstract void verifyPendingInstall(int paramInt1, int paramInt2)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IPackageManager
  {
    private static final String DESCRIPTOR = "android.content.pm.IPackageManager";
    static final int TRANSACTION_addPackageToPreferred = 46;
    static final int TRANSACTION_addPermission = 17;
    static final int TRANSACTION_addPermissionAsync = 75;
    static final int TRANSACTION_addPreferredActivity = 49;
    static final int TRANSACTION_canonicalToCurrentPackageNames = 5;
    static final int TRANSACTION_checkPermission = 15;
    static final int TRANSACTION_checkSignatures = 22;
    static final int TRANSACTION_checkUidPermission = 16;
    static final int TRANSACTION_checkUidSignatures = 23;
    static final int TRANSACTION_clearApplicationUserData = 61;
    static final int TRANSACTION_clearPackagePreferredActivities = 51;
    static final int TRANSACTION_currentToCanonicalPackageNames = 4;
    static final int TRANSACTION_deleteApplicationCacheFiles = 60;
    static final int TRANSACTION_deletePackage = 44;
    static final int TRANSACTION_enterSafeMode = 66;
    static final int TRANSACTION_extendVerificationTimeout = 82;
    static final int TRANSACTION_finishPackageInstall = 42;
    static final int TRANSACTION_freeStorage = 59;
    static final int TRANSACTION_freeStorageAndNotify = 58;
    static final int TRANSACTION_getActivityInfo = 11;
    static final int TRANSACTION_getAllPermissionGroups = 9;
    static final int TRANSACTION_getApplicationEnabledSetting = 56;
    static final int TRANSACTION_getApplicationInfo = 10;
    static final int TRANSACTION_getComponentEnabledSetting = 54;
    static final int TRANSACTION_getInstallLocation = 77;
    static final int TRANSACTION_getInstalledApplications = 34;
    static final int TRANSACTION_getInstalledPackages = 33;
    static final int TRANSACTION_getInstallerPackageName = 45;
    static final int TRANSACTION_getInstrumentationInfo = 39;
    static final int TRANSACTION_getNameForUid = 25;
    static final int TRANSACTION_getPackageGids = 3;
    static final int TRANSACTION_getPackageInfo = 1;
    static final int TRANSACTION_getPackageSizeInfo = 62;
    static final int TRANSACTION_getPackageUid = 2;
    static final int TRANSACTION_getPackagesForUid = 24;
    static final int TRANSACTION_getPermissionGroupInfo = 8;
    static final int TRANSACTION_getPermissionInfo = 6;
    static final int TRANSACTION_getPersistentApplications = 35;
    static final int TRANSACTION_getPreferredActivities = 52;
    static final int TRANSACTION_getPreferredPackages = 48;
    static final int TRANSACTION_getProviderInfo = 14;
    static final int TRANSACTION_getReceiverInfo = 12;
    static final int TRANSACTION_getServiceInfo = 13;
    static final int TRANSACTION_getSystemAvailableFeatures = 64;
    static final int TRANSACTION_getSystemSharedLibraryNames = 63;
    static final int TRANSACTION_getUidForSharedUser = 26;
    static final int TRANSACTION_getVerifierDeviceIdentity = 83;
    static final int TRANSACTION_grantPermission = 19;
    static final int TRANSACTION_hasSystemFeature = 65;
    static final int TRANSACTION_hasSystemUidErrors = 69;
    static final int TRANSACTION_installExistingPackage = 80;
    static final int TRANSACTION_installPackage = 41;
    static final int TRANSACTION_installPackageWithVerification = 78;
    static final int TRANSACTION_installPackageWithVerificationAndEncryption = 79;
    static final int TRANSACTION_isFirstBoot = 84;
    static final int TRANSACTION_isPermissionEnforced = 86;
    static final int TRANSACTION_isProtectedBroadcast = 21;
    static final int TRANSACTION_isSafeMode = 67;
    static final int TRANSACTION_isStorageLow = 87;
    static final int TRANSACTION_movePackage = 74;
    static final int TRANSACTION_nextPackageToClean = 73;
    static final int TRANSACTION_performBootDexOpt = 70;
    static final int TRANSACTION_performDexOpt = 71;
    static final int TRANSACTION_queryContentProviders = 38;
    static final int TRANSACTION_queryInstrumentation = 40;
    static final int TRANSACTION_queryIntentActivities = 28;
    static final int TRANSACTION_queryIntentActivityOptions = 29;
    static final int TRANSACTION_queryIntentReceivers = 30;
    static final int TRANSACTION_queryIntentServices = 32;
    static final int TRANSACTION_queryPermissionsByGroup = 7;
    static final int TRANSACTION_querySyncProviders = 37;
    static final int TRANSACTION_removePackageFromPreferred = 47;
    static final int TRANSACTION_removePermission = 18;
    static final int TRANSACTION_replacePreferredActivity = 50;
    static final int TRANSACTION_resolveContentProvider = 36;
    static final int TRANSACTION_resolveIntent = 27;
    static final int TRANSACTION_resolveService = 31;
    static final int TRANSACTION_revokePermission = 20;
    static final int TRANSACTION_setApplicationEnabledSetting = 55;
    static final int TRANSACTION_setComponentEnabledSetting = 53;
    static final int TRANSACTION_setInstallLocation = 76;
    static final int TRANSACTION_setInstallerPackageName = 43;
    static final int TRANSACTION_setPackageStoppedState = 57;
    static final int TRANSACTION_setPermissionEnforced = 85;
    static final int TRANSACTION_systemReady = 68;
    static final int TRANSACTION_updateExternalMediaStatus = 72;
    static final int TRANSACTION_verifyPendingInstall = 81;
    
    public Stub()
    {
      attachInterface(this, "android.content.pm.IPackageManager");
    }
    
    public static IPackageManager asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.content.pm.IPackageManager");
      if ((localIInterface != null) && ((localIInterface instanceof IPackageManager))) {
        return (IPackageManager)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.content.pm.IPackageManager");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        PackageInfo localPackageInfo = getPackageInfo(paramParcel1.readString(), paramParcel1.readInt(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        if (localPackageInfo != null)
        {
          paramParcel2.writeInt(1);
          localPackageInfo.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          paramParcel2.writeInt(0);
        }
      case 2: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        int i21 = getPackageUid(paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i21);
        return true;
      case 3: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        int[] arrayOfInt = getPackageGids(paramParcel1.readString());
        paramParcel2.writeNoException();
        paramParcel2.writeIntArray(arrayOfInt);
        return true;
      case 4: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        String[] arrayOfString5 = currentToCanonicalPackageNames(paramParcel1.createStringArray());
        paramParcel2.writeNoException();
        paramParcel2.writeStringArray(arrayOfString5);
        return true;
      case 5: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        String[] arrayOfString4 = canonicalToCurrentPackageNames(paramParcel1.createStringArray());
        paramParcel2.writeNoException();
        paramParcel2.writeStringArray(arrayOfString4);
        return true;
      case 6: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        PermissionInfo localPermissionInfo3 = getPermissionInfo(paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        if (localPermissionInfo3 != null)
        {
          paramParcel2.writeInt(1);
          localPermissionInfo3.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          paramParcel2.writeInt(0);
        }
      case 7: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        List localList10 = queryPermissionsByGroup(paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList10);
        return true;
      case 8: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        PermissionGroupInfo localPermissionGroupInfo = getPermissionGroupInfo(paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        if (localPermissionGroupInfo != null)
        {
          paramParcel2.writeInt(1);
          localPermissionGroupInfo.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          paramParcel2.writeInt(0);
        }
      case 9: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        List localList9 = getAllPermissionGroups(paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList9);
        return true;
      case 10: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        ApplicationInfo localApplicationInfo = getApplicationInfo(paramParcel1.readString(), paramParcel1.readInt(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        if (localApplicationInfo != null)
        {
          paramParcel2.writeInt(1);
          localApplicationInfo.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          paramParcel2.writeInt(0);
        }
      case 11: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        ComponentName localComponentName10;
        if (paramParcel1.readInt() != 0)
        {
          localComponentName10 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);
          ActivityInfo localActivityInfo2 = getActivityInfo(localComponentName10, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          if (localActivityInfo2 == null) {
            break label1194;
          }
          paramParcel2.writeInt(1);
          localActivityInfo2.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          localComponentName10 = null;
          break;
          paramParcel2.writeInt(0);
        }
      case 12: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        ComponentName localComponentName9;
        if (paramParcel1.readInt() != 0)
        {
          localComponentName9 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);
          ActivityInfo localActivityInfo1 = getReceiverInfo(localComponentName9, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          if (localActivityInfo1 == null) {
            break label1274;
          }
          paramParcel2.writeInt(1);
          localActivityInfo1.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          localComponentName9 = null;
          break;
          paramParcel2.writeInt(0);
        }
      case 13: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        ComponentName localComponentName8;
        if (paramParcel1.readInt() != 0)
        {
          localComponentName8 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);
          ServiceInfo localServiceInfo = getServiceInfo(localComponentName8, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          if (localServiceInfo == null) {
            break label1354;
          }
          paramParcel2.writeInt(1);
          localServiceInfo.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          localComponentName8 = null;
          break;
          paramParcel2.writeInt(0);
        }
      case 14: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        ComponentName localComponentName7;
        if (paramParcel1.readInt() != 0)
        {
          localComponentName7 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);
          ProviderInfo localProviderInfo2 = getProviderInfo(localComponentName7, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          if (localProviderInfo2 == null) {
            break label1434;
          }
          paramParcel2.writeInt(1);
          localProviderInfo2.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          localComponentName7 = null;
          break;
          paramParcel2.writeInt(0);
        }
      case 15: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        int i20 = checkPermission(paramParcel1.readString(), paramParcel1.readString());
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i20);
        return true;
      case 16: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        int i19 = checkUidPermission(paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i19);
        return true;
      case 17: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        PermissionInfo localPermissionInfo2;
        if (paramParcel1.readInt() != 0)
        {
          localPermissionInfo2 = (PermissionInfo)PermissionInfo.CREATOR.createFromParcel(paramParcel1);
          boolean bool15 = addPermission(localPermissionInfo2);
          paramParcel2.writeNoException();
          if (!bool15) {
            break label1567;
          }
        }
        for (int i18 = 1;; i18 = 0)
        {
          paramParcel2.writeInt(i18);
          return true;
          localPermissionInfo2 = null;
          break;
        }
      case 18: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        removePermission(paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 19: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        grantPermission(paramParcel1.readString(), paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 20: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        revokePermission(paramParcel1.readString(), paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 21: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        boolean bool14 = isProtectedBroadcast(paramParcel1.readString());
        paramParcel2.writeNoException();
        if (bool14) {}
        for (int i17 = 1;; i17 = 0)
        {
          paramParcel2.writeInt(i17);
          return true;
        }
      case 22: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        int i16 = checkSignatures(paramParcel1.readString(), paramParcel1.readString());
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i16);
        return true;
      case 23: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        int i15 = checkUidSignatures(paramParcel1.readInt(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i15);
        return true;
      case 24: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        String[] arrayOfString3 = getPackagesForUid(paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeStringArray(arrayOfString3);
        return true;
      case 25: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        String str6 = getNameForUid(paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeString(str6);
        return true;
      case 26: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        int i14 = getUidForSharedUser(paramParcel1.readString());
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i14);
        return true;
      case 27: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        Intent localIntent6;
        if (paramParcel1.readInt() != 0)
        {
          localIntent6 = (Intent)Intent.CREATOR.createFromParcel(paramParcel1);
          ResolveInfo localResolveInfo2 = resolveIntent(localIntent6, paramParcel1.readString(), paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          if (localResolveInfo2 == null) {
            break label1907;
          }
          paramParcel2.writeInt(1);
          localResolveInfo2.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          localIntent6 = null;
          break;
          paramParcel2.writeInt(0);
        }
      case 28: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        if (paramParcel1.readInt() != 0) {}
        for (Intent localIntent5 = (Intent)Intent.CREATOR.createFromParcel(paramParcel1);; localIntent5 = null)
        {
          List localList8 = queryIntentActivities(localIntent5, paramParcel1.readString(), paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeTypedList(localList8);
          return true;
        }
      case 29: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        ComponentName localComponentName6;
        Intent[] arrayOfIntent;
        String[] arrayOfString2;
        if (paramParcel1.readInt() != 0)
        {
          localComponentName6 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);
          arrayOfIntent = (Intent[])paramParcel1.createTypedArray(Intent.CREATOR);
          arrayOfString2 = paramParcel1.createStringArray();
          if (paramParcel1.readInt() == 0) {
            break label2090;
          }
        }
        for (Intent localIntent4 = (Intent)Intent.CREATOR.createFromParcel(paramParcel1);; localIntent4 = null)
        {
          List localList7 = queryIntentActivityOptions(localComponentName6, arrayOfIntent, arrayOfString2, localIntent4, paramParcel1.readString(), paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeTypedList(localList7);
          return true;
          localComponentName6 = null;
          break;
        }
      case 30: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        if (paramParcel1.readInt() != 0) {}
        for (Intent localIntent3 = (Intent)Intent.CREATOR.createFromParcel(paramParcel1);; localIntent3 = null)
        {
          List localList6 = queryIntentReceivers(localIntent3, paramParcel1.readString(), paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeTypedList(localList6);
          return true;
        }
      case 31: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        Intent localIntent2;
        if (paramParcel1.readInt() != 0)
        {
          localIntent2 = (Intent)Intent.CREATOR.createFromParcel(paramParcel1);
          ResolveInfo localResolveInfo1 = resolveService(localIntent2, paramParcel1.readString(), paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          if (localResolveInfo1 == null) {
            break label2237;
          }
          paramParcel2.writeInt(1);
          localResolveInfo1.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          localIntent2 = null;
          break;
          paramParcel2.writeInt(0);
        }
      case 32: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        if (paramParcel1.readInt() != 0) {}
        for (Intent localIntent1 = (Intent)Intent.CREATOR.createFromParcel(paramParcel1);; localIntent1 = null)
        {
          List localList5 = queryIntentServices(localIntent1, paramParcel1.readString(), paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeTypedList(localList5);
          return true;
        }
      case 33: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        ParceledListSlice localParceledListSlice2 = getInstalledPackages(paramParcel1.readInt(), paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        if (localParceledListSlice2 != null)
        {
          paramParcel2.writeInt(1);
          localParceledListSlice2.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          paramParcel2.writeInt(0);
        }
      case 34: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        ParceledListSlice localParceledListSlice1 = getInstalledApplications(paramParcel1.readInt(), paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        if (localParceledListSlice1 != null)
        {
          paramParcel2.writeInt(1);
          localParceledListSlice1.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          paramParcel2.writeInt(0);
        }
      case 35: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        List localList4 = getPersistentApplications(paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList4);
        return true;
      case 36: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        ProviderInfo localProviderInfo1 = resolveContentProvider(paramParcel1.readString(), paramParcel1.readInt(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        if (localProviderInfo1 != null)
        {
          paramParcel2.writeInt(1);
          localProviderInfo1.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          paramParcel2.writeInt(0);
        }
      case 37: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        ArrayList localArrayList3 = paramParcel1.createStringArrayList();
        ArrayList localArrayList4 = paramParcel1.createTypedArrayList(ProviderInfo.CREATOR);
        querySyncProviders(localArrayList3, localArrayList4);
        paramParcel2.writeNoException();
        paramParcel2.writeStringList(localArrayList3);
        paramParcel2.writeTypedList(localArrayList4);
        return true;
      case 38: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        List localList3 = queryContentProviders(paramParcel1.readString(), paramParcel1.readInt(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList3);
        return true;
      case 39: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        ComponentName localComponentName5;
        if (paramParcel1.readInt() != 0)
        {
          localComponentName5 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);
          InstrumentationInfo localInstrumentationInfo = getInstrumentationInfo(localComponentName5, paramParcel1.readInt());
          paramParcel2.writeNoException();
          if (localInstrumentationInfo == null) {
            break label2654;
          }
          paramParcel2.writeInt(1);
          localInstrumentationInfo.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          localComponentName5 = null;
          break;
          paramParcel2.writeInt(0);
        }
      case 40: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        List localList2 = queryInstrumentation(paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList2);
        return true;
      case 41: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        if (paramParcel1.readInt() != 0) {}
        for (Uri localUri4 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);; localUri4 = null)
        {
          installPackage(localUri4, IPackageInstallObserver.Stub.asInterface(paramParcel1.readStrongBinder()), paramParcel1.readInt(), paramParcel1.readString());
          paramParcel2.writeNoException();
          return true;
        }
      case 42: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        finishPackageInstall(paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 43: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        setInstallerPackageName(paramParcel1.readString(), paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 44: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        deletePackage(paramParcel1.readString(), IPackageDeleteObserver.Stub.asInterface(paramParcel1.readStrongBinder()), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 45: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        String str5 = getInstallerPackageName(paramParcel1.readString());
        paramParcel2.writeNoException();
        paramParcel2.writeString(str5);
        return true;
      case 46: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        addPackageToPreferred(paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 47: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        removePackageFromPreferred(paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 48: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        List localList1 = getPreferredPackages(paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList1);
        return true;
      case 49: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        IntentFilter localIntentFilter2;
        int i13;
        ComponentName[] arrayOfComponentName2;
        if (paramParcel1.readInt() != 0)
        {
          localIntentFilter2 = (IntentFilter)IntentFilter.CREATOR.createFromParcel(paramParcel1);
          i13 = paramParcel1.readInt();
          arrayOfComponentName2 = (ComponentName[])paramParcel1.createTypedArray(ComponentName.CREATOR);
          if (paramParcel1.readInt() == 0) {
            break label3019;
          }
        }
        for (ComponentName localComponentName4 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName4 = null)
        {
          addPreferredActivity(localIntentFilter2, i13, arrayOfComponentName2, localComponentName4, paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
          localIntentFilter2 = null;
          break;
        }
      case 50: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        IntentFilter localIntentFilter1;
        int i12;
        ComponentName[] arrayOfComponentName1;
        if (paramParcel1.readInt() != 0)
        {
          localIntentFilter1 = (IntentFilter)IntentFilter.CREATOR.createFromParcel(paramParcel1);
          i12 = paramParcel1.readInt();
          arrayOfComponentName1 = (ComponentName[])paramParcel1.createTypedArray(ComponentName.CREATOR);
          if (paramParcel1.readInt() == 0) {
            break label3115;
          }
        }
        for (ComponentName localComponentName3 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName3 = null)
        {
          replacePreferredActivity(localIntentFilter1, i12, arrayOfComponentName1, localComponentName3);
          paramParcel2.writeNoException();
          return true;
          localIntentFilter1 = null;
          break;
        }
      case 51: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        clearPackagePreferredActivities(paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 52: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        ArrayList localArrayList1 = new ArrayList();
        ArrayList localArrayList2 = new ArrayList();
        int i11 = getPreferredActivities(localArrayList1, localArrayList2, paramParcel1.readString());
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i11);
        paramParcel2.writeTypedList(localArrayList1);
        paramParcel2.writeTypedList(localArrayList2);
        return true;
      case 53: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName2 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName2 = null)
        {
          setComponentEnabledSetting(localComponentName2, paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 54: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName1 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName1 = null)
        {
          int i10 = getComponentEnabledSetting(localComponentName1, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i10);
          return true;
        }
      case 55: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        setApplicationEnabledSetting(paramParcel1.readString(), paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 56: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        int i9 = getApplicationEnabledSetting(paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i9);
        return true;
      case 57: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        String str4 = paramParcel1.readString();
        if (paramParcel1.readInt() != 0) {}
        for (boolean bool13 = true;; bool13 = false)
        {
          setPackageStoppedState(str4, bool13, paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 58: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        freeStorageAndNotify(paramParcel1.readLong(), IPackageDataObserver.Stub.asInterface(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 59: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        long l = paramParcel1.readLong();
        if (paramParcel1.readInt() != 0) {}
        for (IntentSender localIntentSender = (IntentSender)IntentSender.CREATOR.createFromParcel(paramParcel1);; localIntentSender = null)
        {
          freeStorage(l, localIntentSender);
          paramParcel2.writeNoException();
          return true;
        }
      case 60: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        deleteApplicationCacheFiles(paramParcel1.readString(), IPackageDataObserver.Stub.asInterface(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 61: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        clearApplicationUserData(paramParcel1.readString(), IPackageDataObserver.Stub.asInterface(paramParcel1.readStrongBinder()), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 62: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        getPackageSizeInfo(paramParcel1.readString(), paramParcel1.readInt(), IPackageStatsObserver.Stub.asInterface(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 63: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        String[] arrayOfString1 = getSystemSharedLibraryNames();
        paramParcel2.writeNoException();
        paramParcel2.writeStringArray(arrayOfString1);
        return true;
      case 64: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        FeatureInfo[] arrayOfFeatureInfo = getSystemAvailableFeatures();
        paramParcel2.writeNoException();
        paramParcel2.writeTypedArray(arrayOfFeatureInfo, 1);
        return true;
      case 65: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        boolean bool12 = hasSystemFeature(paramParcel1.readString());
        paramParcel2.writeNoException();
        if (bool12) {}
        for (int i8 = 1;; i8 = 0)
        {
          paramParcel2.writeInt(i8);
          return true;
        }
      case 66: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        enterSafeMode();
        paramParcel2.writeNoException();
        return true;
      case 67: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        boolean bool11 = isSafeMode();
        paramParcel2.writeNoException();
        if (bool11) {}
        for (int i7 = 1;; i7 = 0)
        {
          paramParcel2.writeInt(i7);
          return true;
        }
      case 68: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        systemReady();
        paramParcel2.writeNoException();
        return true;
      case 69: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        boolean bool10 = hasSystemUidErrors();
        paramParcel2.writeNoException();
        if (bool10) {}
        for (int i6 = 1;; i6 = 0)
        {
          paramParcel2.writeInt(i6);
          return true;
        }
      case 70: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        performBootDexOpt();
        paramParcel2.writeNoException();
        return true;
      case 71: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        boolean bool9 = performDexOpt(paramParcel1.readString());
        paramParcel2.writeNoException();
        if (bool9) {}
        for (int i5 = 1;; i5 = 0)
        {
          paramParcel2.writeInt(i5);
          return true;
        }
      case 72: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        boolean bool7;
        if (paramParcel1.readInt() != 0)
        {
          bool7 = true;
          if (paramParcel1.readInt() == 0) {
            break label3899;
          }
        }
        for (boolean bool8 = true;; bool8 = false)
        {
          updateExternalMediaStatus(bool7, bool8);
          paramParcel2.writeNoException();
          return true;
          bool7 = false;
          break;
        }
      case 73: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        PackageCleanItem localPackageCleanItem1;
        if (paramParcel1.readInt() != 0)
        {
          localPackageCleanItem1 = (PackageCleanItem)PackageCleanItem.CREATOR.createFromParcel(paramParcel1);
          PackageCleanItem localPackageCleanItem2 = nextPackageToClean(localPackageCleanItem1);
          paramParcel2.writeNoException();
          if (localPackageCleanItem2 == null) {
            break label3969;
          }
          paramParcel2.writeInt(1);
          localPackageCleanItem2.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          localPackageCleanItem1 = null;
          break;
          paramParcel2.writeInt(0);
        }
      case 74: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        movePackage(paramParcel1.readString(), IPackageMoveObserver.Stub.asInterface(paramParcel1.readStrongBinder()), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 75: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        PermissionInfo localPermissionInfo1;
        if (paramParcel1.readInt() != 0)
        {
          localPermissionInfo1 = (PermissionInfo)PermissionInfo.CREATOR.createFromParcel(paramParcel1);
          boolean bool6 = addPermissionAsync(localPermissionInfo1);
          paramParcel2.writeNoException();
          if (!bool6) {
            break label4069;
          }
        }
        for (int i4 = 1;; i4 = 0)
        {
          paramParcel2.writeInt(i4);
          return true;
          localPermissionInfo1 = null;
          break;
        }
      case 76: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        boolean bool5 = setInstallLocation(paramParcel1.readInt());
        paramParcel2.writeNoException();
        if (bool5) {}
        for (int i3 = 1;; i3 = 0)
        {
          paramParcel2.writeInt(i3);
          return true;
        }
      case 77: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        int i2 = getInstallLocation();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i2);
        return true;
      case 78: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        Uri localUri2;
        IPackageInstallObserver localIPackageInstallObserver2;
        int i1;
        String str3;
        Uri localUri3;
        ManifestDigest localManifestDigest;
        if (paramParcel1.readInt() != 0)
        {
          localUri2 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
          localIPackageInstallObserver2 = IPackageInstallObserver.Stub.asInterface(paramParcel1.readStrongBinder());
          i1 = paramParcel1.readInt();
          str3 = paramParcel1.readString();
          if (paramParcel1.readInt() == 0) {
            break label4282;
          }
          localUri3 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label4288;
          }
          localManifestDigest = (ManifestDigest)ManifestDigest.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label4294;
          }
        }
        for (ContainerEncryptionParams localContainerEncryptionParams2 = (ContainerEncryptionParams)ContainerEncryptionParams.CREATOR.createFromParcel(paramParcel1);; localContainerEncryptionParams2 = null)
        {
          installPackageWithVerification(localUri2, localIPackageInstallObserver2, i1, str3, localUri3, localManifestDigest, localContainerEncryptionParams2);
          paramParcel2.writeNoException();
          return true;
          localUri2 = null;
          break;
          localUri3 = null;
          break label4210;
          localManifestDigest = null;
          break label4231;
        }
      case 79: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        Uri localUri1;
        IPackageInstallObserver localIPackageInstallObserver1;
        int n;
        String str2;
        VerificationParams localVerificationParams;
        if (paramParcel1.readInt() != 0)
        {
          localUri1 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
          localIPackageInstallObserver1 = IPackageInstallObserver.Stub.asInterface(paramParcel1.readStrongBinder());
          n = paramParcel1.readInt();
          str2 = paramParcel1.readString();
          if (paramParcel1.readInt() == 0) {
            break label4418;
          }
          localVerificationParams = (VerificationParams)VerificationParams.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label4424;
          }
        }
        for (ContainerEncryptionParams localContainerEncryptionParams1 = (ContainerEncryptionParams)ContainerEncryptionParams.CREATOR.createFromParcel(paramParcel1);; localContainerEncryptionParams1 = null)
        {
          installPackageWithVerificationAndEncryption(localUri1, localIPackageInstallObserver1, n, str2, localVerificationParams, localContainerEncryptionParams1);
          paramParcel2.writeNoException();
          return true;
          localUri1 = null;
          break;
          localVerificationParams = null;
          break label4369;
        }
      case 80: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        int m = installExistingPackage(paramParcel1.readString());
        paramParcel2.writeNoException();
        paramParcel2.writeInt(m);
        return true;
      case 81: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        verifyPendingInstall(paramParcel1.readInt(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 82: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        extendVerificationTimeout(paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readLong());
        paramParcel2.writeNoException();
        return true;
      case 83: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        VerifierDeviceIdentity localVerifierDeviceIdentity = getVerifierDeviceIdentity();
        paramParcel2.writeNoException();
        if (localVerifierDeviceIdentity != null)
        {
          paramParcel2.writeInt(1);
          localVerifierDeviceIdentity.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          paramParcel2.writeInt(0);
        }
      case 84: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        boolean bool4 = isFirstBoot();
        paramParcel2.writeNoException();
        if (bool4) {}
        for (int k = 1;; k = 0)
        {
          paramParcel2.writeInt(k);
          return true;
        }
      case 85: 
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        String str1 = paramParcel1.readString();
        if (paramParcel1.readInt() != 0) {}
        for (boolean bool3 = true;; bool3 = false)
        {
          setPermissionEnforced(str1, bool3);
          paramParcel2.writeNoException();
          return true;
        }
      case 86: 
        label1194:
        label1274:
        label1354:
        label1434:
        label1567:
        label1907:
        label2090:
        label2237:
        label2654:
        label3019:
        label3115:
        label3899:
        label3969:
        label4069:
        label4210:
        label4231:
        label4282:
        label4288:
        label4294:
        label4369:
        label4418:
        label4424:
        paramParcel1.enforceInterface("android.content.pm.IPackageManager");
        boolean bool2 = isPermissionEnforced(paramParcel1.readString());
        paramParcel2.writeNoException();
        if (bool2) {}
        for (int j = 1;; j = 0)
        {
          paramParcel2.writeInt(j);
          return true;
        }
      }
      paramParcel1.enforceInterface("android.content.pm.IPackageManager");
      boolean bool1 = isStorageLow();
      paramParcel2.writeNoException();
      if (bool1) {}
      for (int i = 1;; i = 0)
      {
        paramParcel2.writeInt(i);
        return true;
      }
    }
    
    private static class Proxy
      implements IPackageManager
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public void addPackageToPreferred(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(46, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean addPermission(PermissionInfo paramPermissionInfo)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
            if (paramPermissionInfo != null)
            {
              localParcel1.writeInt(1);
              paramPermissionInfo.writeToParcel(localParcel1, 0);
              this.mRemote.transact(17, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean addPermissionAsync(PermissionInfo paramPermissionInfo)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
            if (paramPermissionInfo != null)
            {
              localParcel1.writeInt(1);
              paramPermissionInfo.writeToParcel(localParcel1, 0);
              this.mRemote.transact(75, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public void addPreferredActivity(IntentFilter paramIntentFilter, int paramInt1, ComponentName[] paramArrayOfComponentName, ComponentName paramComponentName, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
            if (paramIntentFilter != null)
            {
              localParcel1.writeInt(1);
              paramIntentFilter.writeToParcel(localParcel1, 0);
              localParcel1.writeInt(paramInt1);
              localParcel1.writeTypedArray(paramArrayOfComponentName, 0);
              if (paramComponentName != null)
              {
                localParcel1.writeInt(1);
                paramComponentName.writeToParcel(localParcel1, 0);
                localParcel1.writeInt(paramInt2);
                this.mRemote.transact(49, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            localParcel1.writeInt(0);
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public String[] canonicalToCurrentPackageNames(String[] paramArrayOfString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeStringArray(paramArrayOfString);
          this.mRemote.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String[] arrayOfString = localParcel2.createStringArray();
          return arrayOfString;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public int checkPermission(String paramString1, String paramString2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString1);
          localParcel1.writeString(paramString2);
          this.mRemote.transact(15, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public int checkSignatures(String paramString1, String paramString2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString1);
          localParcel1.writeString(paramString2);
          this.mRemote.transact(22, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public int checkUidPermission(String paramString, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(16, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public int checkUidSignatures(int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          this.mRemote.transact(23, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public void clearApplicationUserData(String paramString, IPackageDataObserver paramIPackageDataObserver, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 4
        //   19: aload_1
        //   20: invokevirtual 33	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   23: aload_2
        //   24: ifnull +57 -> 81
        //   27: aload_2
        //   28: invokeinterface 99 1 0
        //   33: astore 7
        //   35: aload 4
        //   37: aload 7
        //   39: invokevirtual 102	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   42: aload 4
        //   44: iload_3
        //   45: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   48: aload_0
        //   49: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   52: bipush 61
        //   54: aload 4
        //   56: aload 5
        //   58: iconst_0
        //   59: invokeinterface 39 5 0
        //   64: pop
        //   65: aload 5
        //   67: invokevirtual 42	android/os/Parcel:readException	()V
        //   70: aload 5
        //   72: invokevirtual 45	android/os/Parcel:recycle	()V
        //   75: aload 4
        //   77: invokevirtual 45	android/os/Parcel:recycle	()V
        //   80: return
        //   81: aconst_null
        //   82: astore 7
        //   84: goto -49 -> 35
        //   87: astore 6
        //   89: aload 5
        //   91: invokevirtual 45	android/os/Parcel:recycle	()V
        //   94: aload 4
        //   96: invokevirtual 45	android/os/Parcel:recycle	()V
        //   99: aload 6
        //   101: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	102	0	this	Proxy
        //   0	102	1	paramString	String
        //   0	102	2	paramIPackageDataObserver	IPackageDataObserver
        //   0	102	3	paramInt	int
        //   3	92	4	localParcel1	Parcel
        //   8	82	5	localParcel2	Parcel
        //   87	13	6	localObject	Object
        //   33	50	7	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   10	23	87	finally
        //   27	35	87	finally
        //   35	70	87	finally
      }
      
      public void clearPackagePreferredActivities(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(51, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String[] currentToCanonicalPackageNames(String[] paramArrayOfString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeStringArray(paramArrayOfString);
          this.mRemote.transact(4, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String[] arrayOfString = localParcel2.createStringArray();
          return arrayOfString;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public void deleteApplicationCacheFiles(String paramString, IPackageDataObserver paramIPackageDataObserver)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_3
        //   16: aload_1
        //   17: invokevirtual 33	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   20: aload_2
        //   21: ifnull +48 -> 69
        //   24: aload_2
        //   25: invokeinterface 99 1 0
        //   30: astore 6
        //   32: aload_3
        //   33: aload 6
        //   35: invokevirtual 102	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   38: aload_0
        //   39: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   42: bipush 60
        //   44: aload_3
        //   45: aload 4
        //   47: iconst_0
        //   48: invokeinterface 39 5 0
        //   53: pop
        //   54: aload 4
        //   56: invokevirtual 42	android/os/Parcel:readException	()V
        //   59: aload 4
        //   61: invokevirtual 45	android/os/Parcel:recycle	()V
        //   64: aload_3
        //   65: invokevirtual 45	android/os/Parcel:recycle	()V
        //   68: return
        //   69: aconst_null
        //   70: astore 6
        //   72: goto -40 -> 32
        //   75: astore 5
        //   77: aload 4
        //   79: invokevirtual 45	android/os/Parcel:recycle	()V
        //   82: aload_3
        //   83: invokevirtual 45	android/os/Parcel:recycle	()V
        //   86: aload 5
        //   88: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	89	0	this	Proxy
        //   0	89	1	paramString	String
        //   0	89	2	paramIPackageDataObserver	IPackageDataObserver
        //   3	80	3	localParcel1	Parcel
        //   7	71	4	localParcel2	Parcel
        //   75	12	5	localObject	Object
        //   30	41	6	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   9	20	75	finally
        //   24	32	75	finally
        //   32	59	75	finally
      }
      
      /* Error */
      public void deletePackage(String paramString, IPackageDeleteObserver paramIPackageDeleteObserver, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 4
        //   19: aload_1
        //   20: invokevirtual 33	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   23: aload_2
        //   24: ifnull +57 -> 81
        //   27: aload_2
        //   28: invokeinterface 111 1 0
        //   33: astore 7
        //   35: aload 4
        //   37: aload 7
        //   39: invokevirtual 102	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   42: aload 4
        //   44: iload_3
        //   45: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   48: aload_0
        //   49: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   52: bipush 44
        //   54: aload 4
        //   56: aload 5
        //   58: iconst_0
        //   59: invokeinterface 39 5 0
        //   64: pop
        //   65: aload 5
        //   67: invokevirtual 42	android/os/Parcel:readException	()V
        //   70: aload 5
        //   72: invokevirtual 45	android/os/Parcel:recycle	()V
        //   75: aload 4
        //   77: invokevirtual 45	android/os/Parcel:recycle	()V
        //   80: return
        //   81: aconst_null
        //   82: astore 7
        //   84: goto -49 -> 35
        //   87: astore 6
        //   89: aload 5
        //   91: invokevirtual 45	android/os/Parcel:recycle	()V
        //   94: aload 4
        //   96: invokevirtual 45	android/os/Parcel:recycle	()V
        //   99: aload 6
        //   101: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	102	0	this	Proxy
        //   0	102	1	paramString	String
        //   0	102	2	paramIPackageDeleteObserver	IPackageDeleteObserver
        //   0	102	3	paramInt	int
        //   3	92	4	localParcel1	Parcel
        //   8	82	5	localParcel2	Parcel
        //   87	13	6	localObject	Object
        //   33	50	7	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   10	23	87	finally
        //   27	35	87	finally
        //   35	70	87	finally
      }
      
      public void enterSafeMode()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          this.mRemote.transact(66, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void extendVerificationTimeout(int paramInt1, int paramInt2, long paramLong)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          localParcel1.writeLong(paramLong);
          this.mRemote.transact(82, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void finishPackageInstall(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(42, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public void freeStorage(long paramLong, IntentSender paramIntentSender)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 4
        //   19: lload_1
        //   20: invokevirtual 118	android/os/Parcel:writeLong	(J)V
        //   23: aload_3
        //   24: ifnull +49 -> 73
        //   27: aload 4
        //   29: iconst_1
        //   30: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   33: aload_3
        //   34: aload 4
        //   36: iconst_0
        //   37: invokevirtual 124	android/content/IntentSender:writeToParcel	(Landroid/os/Parcel;I)V
        //   40: aload_0
        //   41: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   44: bipush 59
        //   46: aload 4
        //   48: aload 5
        //   50: iconst_0
        //   51: invokeinterface 39 5 0
        //   56: pop
        //   57: aload 5
        //   59: invokevirtual 42	android/os/Parcel:readException	()V
        //   62: aload 5
        //   64: invokevirtual 45	android/os/Parcel:recycle	()V
        //   67: aload 4
        //   69: invokevirtual 45	android/os/Parcel:recycle	()V
        //   72: return
        //   73: aload 4
        //   75: iconst_0
        //   76: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   79: goto -39 -> 40
        //   82: astore 6
        //   84: aload 5
        //   86: invokevirtual 45	android/os/Parcel:recycle	()V
        //   89: aload 4
        //   91: invokevirtual 45	android/os/Parcel:recycle	()V
        //   94: aload 6
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramLong	long
        //   0	97	3	paramIntentSender	IntentSender
        //   3	87	4	localParcel1	Parcel
        //   8	77	5	localParcel2	Parcel
        //   82	13	6	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	23	82	finally
        //   27	40	82	finally
        //   40	62	82	finally
        //   73	79	82	finally
      }
      
      /* Error */
      public void freeStorageAndNotify(long paramLong, IPackageDataObserver paramIPackageDataObserver)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 4
        //   19: lload_1
        //   20: invokevirtual 118	android/os/Parcel:writeLong	(J)V
        //   23: aload_3
        //   24: ifnull +51 -> 75
        //   27: aload_3
        //   28: invokeinterface 99 1 0
        //   33: astore 7
        //   35: aload 4
        //   37: aload 7
        //   39: invokevirtual 102	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   42: aload_0
        //   43: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   46: bipush 58
        //   48: aload 4
        //   50: aload 5
        //   52: iconst_0
        //   53: invokeinterface 39 5 0
        //   58: pop
        //   59: aload 5
        //   61: invokevirtual 42	android/os/Parcel:readException	()V
        //   64: aload 5
        //   66: invokevirtual 45	android/os/Parcel:recycle	()V
        //   69: aload 4
        //   71: invokevirtual 45	android/os/Parcel:recycle	()V
        //   74: return
        //   75: aconst_null
        //   76: astore 7
        //   78: goto -43 -> 35
        //   81: astore 6
        //   83: aload 5
        //   85: invokevirtual 45	android/os/Parcel:recycle	()V
        //   88: aload 4
        //   90: invokevirtual 45	android/os/Parcel:recycle	()V
        //   93: aload 6
        //   95: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	96	0	this	Proxy
        //   0	96	1	paramLong	long
        //   0	96	3	paramIPackageDataObserver	IPackageDataObserver
        //   3	86	4	localParcel1	Parcel
        //   8	76	5	localParcel2	Parcel
        //   81	13	6	localObject	Object
        //   33	44	7	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   10	23	81	finally
        //   27	35	81	finally
        //   35	64	81	finally
      }
      
      public ActivityInfo getActivityInfo(ComponentName paramComponentName, int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
            if (paramComponentName != null)
            {
              localParcel1.writeInt(1);
              paramComponentName.writeToParcel(localParcel1, 0);
              localParcel1.writeInt(paramInt1);
              localParcel1.writeInt(paramInt2);
              this.mRemote.transact(11, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localActivityInfo = (ActivityInfo)ActivityInfo.CREATOR.createFromParcel(localParcel2);
                return localActivityInfo;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            ActivityInfo localActivityInfo = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public List<PermissionGroupInfo> getAllPermissionGroups(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(9, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(PermissionGroupInfo.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public int getApplicationEnabledSetting(String paramString, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(56, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public ApplicationInfo getApplicationInfo(String paramString, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 4
        //   19: aload_1
        //   20: invokevirtual 33	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   23: aload 4
        //   25: iload_2
        //   26: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   29: aload 4
        //   31: iload_3
        //   32: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 10
        //   41: aload 4
        //   43: aload 5
        //   45: iconst_0
        //   46: invokeinterface 39 5 0
        //   51: pop
        //   52: aload 5
        //   54: invokevirtual 42	android/os/Parcel:readException	()V
        //   57: aload 5
        //   59: invokevirtual 61	android/os/Parcel:readInt	()I
        //   62: ifeq +31 -> 93
        //   65: getstatic 155	android/content/pm/ApplicationInfo:CREATOR	Landroid/os/Parcelable$Creator;
        //   68: aload 5
        //   70: invokeinterface 140 2 0
        //   75: checkcast 154	android/content/pm/ApplicationInfo
        //   78: astore 8
        //   80: aload 5
        //   82: invokevirtual 45	android/os/Parcel:recycle	()V
        //   85: aload 4
        //   87: invokevirtual 45	android/os/Parcel:recycle	()V
        //   90: aload 8
        //   92: areturn
        //   93: aconst_null
        //   94: astore 8
        //   96: goto -16 -> 80
        //   99: astore 6
        //   101: aload 5
        //   103: invokevirtual 45	android/os/Parcel:recycle	()V
        //   106: aload 4
        //   108: invokevirtual 45	android/os/Parcel:recycle	()V
        //   111: aload 6
        //   113: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	114	0	this	Proxy
        //   0	114	1	paramString	String
        //   0	114	2	paramInt1	int
        //   0	114	3	paramInt2	int
        //   3	104	4	localParcel1	Parcel
        //   8	94	5	localParcel2	Parcel
        //   99	13	6	localObject	Object
        //   78	17	8	localApplicationInfo	ApplicationInfo
        // Exception table:
        //   from	to	target	type
        //   10	80	99	finally
      }
      
      /* Error */
      public int getComponentEnabledSetting(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +59 -> 75
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 74	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 54
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 39 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 42	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 61	android/os/Parcel:readInt	()I
        //   61: istore 7
        //   63: aload 4
        //   65: invokevirtual 45	android/os/Parcel:recycle	()V
        //   68: aload_3
        //   69: invokevirtual 45	android/os/Parcel:recycle	()V
        //   72: iload 7
        //   74: ireturn
        //   75: aload_3
        //   76: iconst_0
        //   77: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   80: goto -50 -> 30
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 45	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 45	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramComponentName	ComponentName
        //   0	97	2	paramInt	int
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   61	12	7	i	int
        // Exception table:
        //   from	to	target	type
        //   9	15	83	finally
        //   19	30	83	finally
        //   30	63	83	finally
        //   75	80	83	finally
      }
      
      public int getInstallLocation()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          this.mRemote.transact(77, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public ParceledListSlice getInstalledApplications(int paramInt1, String paramString, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 4
        //   19: iload_1
        //   20: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   23: aload 4
        //   25: aload_2
        //   26: invokevirtual 33	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   29: aload 4
        //   31: iload_3
        //   32: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 34
        //   41: aload 4
        //   43: aload 5
        //   45: iconst_0
        //   46: invokeinterface 39 5 0
        //   51: pop
        //   52: aload 5
        //   54: invokevirtual 42	android/os/Parcel:readException	()V
        //   57: aload 5
        //   59: invokevirtual 61	android/os/Parcel:readInt	()I
        //   62: ifeq +31 -> 93
        //   65: getstatic 163	android/content/pm/ParceledListSlice:CREATOR	Landroid/os/Parcelable$Creator;
        //   68: aload 5
        //   70: invokeinterface 140 2 0
        //   75: checkcast 162	android/content/pm/ParceledListSlice
        //   78: astore 8
        //   80: aload 5
        //   82: invokevirtual 45	android/os/Parcel:recycle	()V
        //   85: aload 4
        //   87: invokevirtual 45	android/os/Parcel:recycle	()V
        //   90: aload 8
        //   92: areturn
        //   93: aconst_null
        //   94: astore 8
        //   96: goto -16 -> 80
        //   99: astore 6
        //   101: aload 5
        //   103: invokevirtual 45	android/os/Parcel:recycle	()V
        //   106: aload 4
        //   108: invokevirtual 45	android/os/Parcel:recycle	()V
        //   111: aload 6
        //   113: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	114	0	this	Proxy
        //   0	114	1	paramInt1	int
        //   0	114	2	paramString	String
        //   0	114	3	paramInt2	int
        //   3	104	4	localParcel1	Parcel
        //   8	94	5	localParcel2	Parcel
        //   99	13	6	localObject	Object
        //   78	17	8	localParceledListSlice	ParceledListSlice
        // Exception table:
        //   from	to	target	type
        //   10	80	99	finally
      }
      
      /* Error */
      public ParceledListSlice getInstalledPackages(int paramInt1, String paramString, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 4
        //   19: iload_1
        //   20: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   23: aload 4
        //   25: aload_2
        //   26: invokevirtual 33	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   29: aload 4
        //   31: iload_3
        //   32: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 33
        //   41: aload 4
        //   43: aload 5
        //   45: iconst_0
        //   46: invokeinterface 39 5 0
        //   51: pop
        //   52: aload 5
        //   54: invokevirtual 42	android/os/Parcel:readException	()V
        //   57: aload 5
        //   59: invokevirtual 61	android/os/Parcel:readInt	()I
        //   62: ifeq +31 -> 93
        //   65: getstatic 163	android/content/pm/ParceledListSlice:CREATOR	Landroid/os/Parcelable$Creator;
        //   68: aload 5
        //   70: invokeinterface 140 2 0
        //   75: checkcast 162	android/content/pm/ParceledListSlice
        //   78: astore 8
        //   80: aload 5
        //   82: invokevirtual 45	android/os/Parcel:recycle	()V
        //   85: aload 4
        //   87: invokevirtual 45	android/os/Parcel:recycle	()V
        //   90: aload 8
        //   92: areturn
        //   93: aconst_null
        //   94: astore 8
        //   96: goto -16 -> 80
        //   99: astore 6
        //   101: aload 5
        //   103: invokevirtual 45	android/os/Parcel:recycle	()V
        //   106: aload 4
        //   108: invokevirtual 45	android/os/Parcel:recycle	()V
        //   111: aload 6
        //   113: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	114	0	this	Proxy
        //   0	114	1	paramInt1	int
        //   0	114	2	paramString	String
        //   0	114	3	paramInt2	int
        //   3	104	4	localParcel1	Parcel
        //   8	94	5	localParcel2	Parcel
        //   99	13	6	localObject	Object
        //   78	17	8	localParceledListSlice	ParceledListSlice
        // Exception table:
        //   from	to	target	type
        //   10	80	99	finally
      }
      
      public String getInstallerPackageName(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(45, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str = localParcel2.readString();
          return str;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public InstrumentationInfo getInstrumentationInfo(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
            if (paramComponentName != null)
            {
              localParcel1.writeInt(1);
              paramComponentName.writeToParcel(localParcel1, 0);
              localParcel1.writeInt(paramInt);
              this.mRemote.transact(39, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localInstrumentationInfo = (InstrumentationInfo)InstrumentationInfo.CREATOR.createFromParcel(localParcel2);
                return localInstrumentationInfo;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            InstrumentationInfo localInstrumentationInfo = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.content.pm.IPackageManager";
      }
      
      public String getNameForUid(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(25, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str = localParcel2.readString();
          return str;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public int[] getPackageGids(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(3, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int[] arrayOfInt = localParcel2.createIntArray();
          return arrayOfInt;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public PackageInfo getPackageInfo(String paramString, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 4
        //   19: aload_1
        //   20: invokevirtual 33	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   23: aload 4
        //   25: iload_2
        //   26: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   29: aload 4
        //   31: iload_3
        //   32: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: iconst_1
        //   40: aload 4
        //   42: aload 5
        //   44: iconst_0
        //   45: invokeinterface 39 5 0
        //   50: pop
        //   51: aload 5
        //   53: invokevirtual 42	android/os/Parcel:readException	()V
        //   56: aload 5
        //   58: invokevirtual 61	android/os/Parcel:readInt	()I
        //   61: ifeq +31 -> 92
        //   64: getstatic 189	android/content/pm/PackageInfo:CREATOR	Landroid/os/Parcelable$Creator;
        //   67: aload 5
        //   69: invokeinterface 140 2 0
        //   74: checkcast 188	android/content/pm/PackageInfo
        //   77: astore 8
        //   79: aload 5
        //   81: invokevirtual 45	android/os/Parcel:recycle	()V
        //   84: aload 4
        //   86: invokevirtual 45	android/os/Parcel:recycle	()V
        //   89: aload 8
        //   91: areturn
        //   92: aconst_null
        //   93: astore 8
        //   95: goto -16 -> 79
        //   98: astore 6
        //   100: aload 5
        //   102: invokevirtual 45	android/os/Parcel:recycle	()V
        //   105: aload 4
        //   107: invokevirtual 45	android/os/Parcel:recycle	()V
        //   110: aload 6
        //   112: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	113	0	this	Proxy
        //   0	113	1	paramString	String
        //   0	113	2	paramInt1	int
        //   0	113	3	paramInt2	int
        //   3	103	4	localParcel1	Parcel
        //   8	93	5	localParcel2	Parcel
        //   98	13	6	localObject	Object
        //   77	17	8	localPackageInfo	PackageInfo
        // Exception table:
        //   from	to	target	type
        //   10	79	98	finally
      }
      
      /* Error */
      public void getPackageSizeInfo(String paramString, int paramInt, IPackageStatsObserver paramIPackageStatsObserver)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 4
        //   19: aload_1
        //   20: invokevirtual 33	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   23: aload 4
        //   25: iload_2
        //   26: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   29: aload_3
        //   30: ifnull +51 -> 81
        //   33: aload_3
        //   34: invokeinterface 194 1 0
        //   39: astore 7
        //   41: aload 4
        //   43: aload 7
        //   45: invokevirtual 102	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   48: aload_0
        //   49: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   52: bipush 62
        //   54: aload 4
        //   56: aload 5
        //   58: iconst_0
        //   59: invokeinterface 39 5 0
        //   64: pop
        //   65: aload 5
        //   67: invokevirtual 42	android/os/Parcel:readException	()V
        //   70: aload 5
        //   72: invokevirtual 45	android/os/Parcel:recycle	()V
        //   75: aload 4
        //   77: invokevirtual 45	android/os/Parcel:recycle	()V
        //   80: return
        //   81: aconst_null
        //   82: astore 7
        //   84: goto -43 -> 41
        //   87: astore 6
        //   89: aload 5
        //   91: invokevirtual 45	android/os/Parcel:recycle	()V
        //   94: aload 4
        //   96: invokevirtual 45	android/os/Parcel:recycle	()V
        //   99: aload 6
        //   101: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	102	0	this	Proxy
        //   0	102	1	paramString	String
        //   0	102	2	paramInt	int
        //   0	102	3	paramIPackageStatsObserver	IPackageStatsObserver
        //   3	92	4	localParcel1	Parcel
        //   8	82	5	localParcel2	Parcel
        //   87	13	6	localObject	Object
        //   39	44	7	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   10	29	87	finally
        //   33	41	87	finally
        //   41	70	87	finally
      }
      
      public int getPackageUid(String paramString, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(2, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String[] getPackagesForUid(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(24, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String[] arrayOfString = localParcel2.createStringArray();
          return arrayOfString;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public PermissionGroupInfo getPermissionGroupInfo(String paramString, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_3
        //   16: aload_1
        //   17: invokevirtual 33	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   20: aload_3
        //   21: iload_2
        //   22: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   25: aload_0
        //   26: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   29: bipush 8
        //   31: aload_3
        //   32: aload 4
        //   34: iconst_0
        //   35: invokeinterface 39 5 0
        //   40: pop
        //   41: aload 4
        //   43: invokevirtual 42	android/os/Parcel:readException	()V
        //   46: aload 4
        //   48: invokevirtual 61	android/os/Parcel:readInt	()I
        //   51: ifeq +30 -> 81
        //   54: getstatic 145	android/content/pm/PermissionGroupInfo:CREATOR	Landroid/os/Parcelable$Creator;
        //   57: aload 4
        //   59: invokeinterface 140 2 0
        //   64: checkcast 144	android/content/pm/PermissionGroupInfo
        //   67: astore 7
        //   69: aload 4
        //   71: invokevirtual 45	android/os/Parcel:recycle	()V
        //   74: aload_3
        //   75: invokevirtual 45	android/os/Parcel:recycle	()V
        //   78: aload 7
        //   80: areturn
        //   81: aconst_null
        //   82: astore 7
        //   84: goto -15 -> 69
        //   87: astore 5
        //   89: aload 4
        //   91: invokevirtual 45	android/os/Parcel:recycle	()V
        //   94: aload_3
        //   95: invokevirtual 45	android/os/Parcel:recycle	()V
        //   98: aload 5
        //   100: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	101	0	this	Proxy
        //   0	101	1	paramString	String
        //   0	101	2	paramInt	int
        //   3	92	3	localParcel1	Parcel
        //   7	83	4	localParcel2	Parcel
        //   87	12	5	localObject	Object
        //   67	16	7	localPermissionGroupInfo	PermissionGroupInfo
        // Exception table:
        //   from	to	target	type
        //   9	69	87	finally
      }
      
      /* Error */
      public PermissionInfo getPermissionInfo(String paramString, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_3
        //   16: aload_1
        //   17: invokevirtual 33	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   20: aload_3
        //   21: iload_2
        //   22: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   25: aload_0
        //   26: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   29: bipush 6
        //   31: aload_3
        //   32: aload 4
        //   34: iconst_0
        //   35: invokeinterface 39 5 0
        //   40: pop
        //   41: aload 4
        //   43: invokevirtual 42	android/os/Parcel:readException	()V
        //   46: aload 4
        //   48: invokevirtual 61	android/os/Parcel:readInt	()I
        //   51: ifeq +30 -> 81
        //   54: getstatic 202	android/content/pm/PermissionInfo:CREATOR	Landroid/os/Parcelable$Creator;
        //   57: aload 4
        //   59: invokeinterface 140 2 0
        //   64: checkcast 53	android/content/pm/PermissionInfo
        //   67: astore 7
        //   69: aload 4
        //   71: invokevirtual 45	android/os/Parcel:recycle	()V
        //   74: aload_3
        //   75: invokevirtual 45	android/os/Parcel:recycle	()V
        //   78: aload 7
        //   80: areturn
        //   81: aconst_null
        //   82: astore 7
        //   84: goto -15 -> 69
        //   87: astore 5
        //   89: aload 4
        //   91: invokevirtual 45	android/os/Parcel:recycle	()V
        //   94: aload_3
        //   95: invokevirtual 45	android/os/Parcel:recycle	()V
        //   98: aload 5
        //   100: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	101	0	this	Proxy
        //   0	101	1	paramString	String
        //   0	101	2	paramInt	int
        //   3	92	3	localParcel1	Parcel
        //   7	83	4	localParcel2	Parcel
        //   87	12	5	localObject	Object
        //   67	16	7	localPermissionInfo	PermissionInfo
        // Exception table:
        //   from	to	target	type
        //   9	69	87	finally
      }
      
      public List<ApplicationInfo> getPersistentApplications(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(35, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(ApplicationInfo.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public int getPreferredActivities(List<IntentFilter> paramList, List<ComponentName> paramList1, String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(52, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          localParcel2.readTypedList(paramList, IntentFilter.CREATOR);
          localParcel2.readTypedList(paramList1, ComponentName.CREATOR);
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public List<PackageInfo> getPreferredPackages(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(48, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(PackageInfo.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public ProviderInfo getProviderInfo(ComponentName paramComponentName, int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
            if (paramComponentName != null)
            {
              localParcel1.writeInt(1);
              paramComponentName.writeToParcel(localParcel1, 0);
              localParcel1.writeInt(paramInt1);
              localParcel1.writeInt(paramInt2);
              this.mRemote.transact(14, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localProviderInfo = (ProviderInfo)ProviderInfo.CREATOR.createFromParcel(localParcel2);
                return localProviderInfo;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            ProviderInfo localProviderInfo = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public ActivityInfo getReceiverInfo(ComponentName paramComponentName, int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
            if (paramComponentName != null)
            {
              localParcel1.writeInt(1);
              paramComponentName.writeToParcel(localParcel1, 0);
              localParcel1.writeInt(paramInt1);
              localParcel1.writeInt(paramInt2);
              this.mRemote.transact(12, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localActivityInfo = (ActivityInfo)ActivityInfo.CREATOR.createFromParcel(localParcel2);
                return localActivityInfo;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            ActivityInfo localActivityInfo = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public ServiceInfo getServiceInfo(ComponentName paramComponentName, int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
            if (paramComponentName != null)
            {
              localParcel1.writeInt(1);
              paramComponentName.writeToParcel(localParcel1, 0);
              localParcel1.writeInt(paramInt1);
              localParcel1.writeInt(paramInt2);
              this.mRemote.transact(13, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localServiceInfo = (ServiceInfo)ServiceInfo.CREATOR.createFromParcel(localParcel2);
                return localServiceInfo;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            ServiceInfo localServiceInfo = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public FeatureInfo[] getSystemAvailableFeatures()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          this.mRemote.transact(64, localParcel1, localParcel2, 0);
          localParcel2.readException();
          FeatureInfo[] arrayOfFeatureInfo = (FeatureInfo[])localParcel2.createTypedArray(FeatureInfo.CREATOR);
          return arrayOfFeatureInfo;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String[] getSystemSharedLibraryNames()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          this.mRemote.transact(63, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String[] arrayOfString = localParcel2.createStringArray();
          return arrayOfString;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public int getUidForSharedUser(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(26, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public VerifierDeviceIdentity getVerifierDeviceIdentity()
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_1
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_2
        //   8: aload_1
        //   9: ldc 27
        //   11: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_0
        //   15: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   18: bipush 83
        //   20: aload_1
        //   21: aload_2
        //   22: iconst_0
        //   23: invokeinterface 39 5 0
        //   28: pop
        //   29: aload_2
        //   30: invokevirtual 42	android/os/Parcel:readException	()V
        //   33: aload_2
        //   34: invokevirtual 61	android/os/Parcel:readInt	()I
        //   37: ifeq +28 -> 65
        //   40: getstatic 242	android/content/pm/VerifierDeviceIdentity:CREATOR	Landroid/os/Parcelable$Creator;
        //   43: aload_2
        //   44: invokeinterface 140 2 0
        //   49: checkcast 241	android/content/pm/VerifierDeviceIdentity
        //   52: astore 5
        //   54: aload_2
        //   55: invokevirtual 45	android/os/Parcel:recycle	()V
        //   58: aload_1
        //   59: invokevirtual 45	android/os/Parcel:recycle	()V
        //   62: aload 5
        //   64: areturn
        //   65: aconst_null
        //   66: astore 5
        //   68: goto -14 -> 54
        //   71: astore_3
        //   72: aload_2
        //   73: invokevirtual 45	android/os/Parcel:recycle	()V
        //   76: aload_1
        //   77: invokevirtual 45	android/os/Parcel:recycle	()V
        //   80: aload_3
        //   81: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	82	0	this	Proxy
        //   3	74	1	localParcel1	Parcel
        //   7	66	2	localParcel2	Parcel
        //   71	10	3	localObject	Object
        //   52	15	5	localVerifierDeviceIdentity	VerifierDeviceIdentity
        // Exception table:
        //   from	to	target	type
        //   8	54	71	finally
      }
      
      public void grantPermission(String paramString1, String paramString2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString1);
          localParcel1.writeString(paramString2);
          this.mRemote.transact(19, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean hasSystemFeature(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(65, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean hasSystemUidErrors()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          this.mRemote.transact(69, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public int installExistingPackage(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(80, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void installPackage(Uri paramUri, IPackageInstallObserver paramIPackageInstallObserver, int paramInt, String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
            if (paramUri != null)
            {
              localParcel1.writeInt(1);
              paramUri.writeToParcel(localParcel1, 0);
              if (paramIPackageInstallObserver != null)
              {
                localIBinder = paramIPackageInstallObserver.asBinder();
                localParcel1.writeStrongBinder(localIBinder);
                localParcel1.writeInt(paramInt);
                localParcel1.writeString(paramString);
                this.mRemote.transact(41, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            IBinder localIBinder = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public void installPackageWithVerification(Uri paramUri1, IPackageInstallObserver paramIPackageInstallObserver, int paramInt, String paramString, Uri paramUri2, ManifestDigest paramManifestDigest, ContainerEncryptionParams paramContainerEncryptionParams)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
            if (paramUri1 != null)
            {
              localParcel1.writeInt(1);
              paramUri1.writeToParcel(localParcel1, 0);
              if (paramIPackageInstallObserver != null)
              {
                localIBinder = paramIPackageInstallObserver.asBinder();
                localParcel1.writeStrongBinder(localIBinder);
                localParcel1.writeInt(paramInt);
                localParcel1.writeString(paramString);
                if (paramUri2 == null) {
                  break label186;
                }
                localParcel1.writeInt(1);
                paramUri2.writeToParcel(localParcel1, 0);
                if (paramManifestDigest == null) {
                  break label195;
                }
                localParcel1.writeInt(1);
                paramManifestDigest.writeToParcel(localParcel1, 0);
                if (paramContainerEncryptionParams == null) {
                  break label204;
                }
                localParcel1.writeInt(1);
                paramContainerEncryptionParams.writeToParcel(localParcel1, 0);
                this.mRemote.transact(78, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            IBinder localIBinder = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          continue;
          label186:
          localParcel1.writeInt(0);
          continue;
          label195:
          localParcel1.writeInt(0);
          continue;
          label204:
          localParcel1.writeInt(0);
        }
      }
      
      public void installPackageWithVerificationAndEncryption(Uri paramUri, IPackageInstallObserver paramIPackageInstallObserver, int paramInt, String paramString, VerificationParams paramVerificationParams, ContainerEncryptionParams paramContainerEncryptionParams)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
            if (paramUri != null)
            {
              localParcel1.writeInt(1);
              paramUri.writeToParcel(localParcel1, 0);
              if (paramIPackageInstallObserver != null)
              {
                localIBinder = paramIPackageInstallObserver.asBinder();
                localParcel1.writeStrongBinder(localIBinder);
                localParcel1.writeInt(paramInt);
                localParcel1.writeString(paramString);
                if (paramVerificationParams == null) {
                  break label167;
                }
                localParcel1.writeInt(1);
                paramVerificationParams.writeToParcel(localParcel1, 0);
                if (paramContainerEncryptionParams == null) {
                  break label176;
                }
                localParcel1.writeInt(1);
                paramContainerEncryptionParams.writeToParcel(localParcel1, 0);
                this.mRemote.transact(79, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            IBinder localIBinder = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          continue;
          label167:
          localParcel1.writeInt(0);
          continue;
          label176:
          localParcel1.writeInt(0);
        }
      }
      
      public boolean isFirstBoot()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          this.mRemote.transact(84, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean isPermissionEnforced(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(86, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean isProtectedBroadcast(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(21, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean isSafeMode()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          this.mRemote.transact(67, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean isStorageLow()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          this.mRemote.transact(87, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public void movePackage(String paramString, IPackageMoveObserver paramIPackageMoveObserver, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 4
        //   19: aload_1
        //   20: invokevirtual 33	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   23: aload_2
        //   24: ifnull +57 -> 81
        //   27: aload_2
        //   28: invokeinterface 280 1 0
        //   33: astore 7
        //   35: aload 4
        //   37: aload 7
        //   39: invokevirtual 102	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   42: aload 4
        //   44: iload_3
        //   45: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   48: aload_0
        //   49: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   52: bipush 74
        //   54: aload 4
        //   56: aload 5
        //   58: iconst_0
        //   59: invokeinterface 39 5 0
        //   64: pop
        //   65: aload 5
        //   67: invokevirtual 42	android/os/Parcel:readException	()V
        //   70: aload 5
        //   72: invokevirtual 45	android/os/Parcel:recycle	()V
        //   75: aload 4
        //   77: invokevirtual 45	android/os/Parcel:recycle	()V
        //   80: return
        //   81: aconst_null
        //   82: astore 7
        //   84: goto -49 -> 35
        //   87: astore 6
        //   89: aload 5
        //   91: invokevirtual 45	android/os/Parcel:recycle	()V
        //   94: aload 4
        //   96: invokevirtual 45	android/os/Parcel:recycle	()V
        //   99: aload 6
        //   101: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	102	0	this	Proxy
        //   0	102	1	paramString	String
        //   0	102	2	paramIPackageMoveObserver	IPackageMoveObserver
        //   0	102	3	paramInt	int
        //   3	92	4	localParcel1	Parcel
        //   8	82	5	localParcel2	Parcel
        //   87	13	6	localObject	Object
        //   33	50	7	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   10	23	87	finally
        //   27	35	87	finally
        //   35	70	87	finally
      }
      
      public PackageCleanItem nextPackageToClean(PackageCleanItem paramPackageCleanItem)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
            if (paramPackageCleanItem != null)
            {
              localParcel1.writeInt(1);
              paramPackageCleanItem.writeToParcel(localParcel1, 0);
              this.mRemote.transact(73, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localPackageCleanItem = (PackageCleanItem)PackageCleanItem.CREATOR.createFromParcel(localParcel2);
                return localPackageCleanItem;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            PackageCleanItem localPackageCleanItem = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public void performBootDexOpt()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          this.mRemote.transact(70, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean performDexOpt(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(71, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public List<ProviderInfo> queryContentProviders(String paramString, int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          this.mRemote.transact(38, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(ProviderInfo.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public List<InstrumentationInfo> queryInstrumentation(String paramString, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(40, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(InstrumentationInfo.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public List<ResolveInfo> queryIntentActivities(Intent paramIntent, String paramString, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 5
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 6
        //   10: aload 5
        //   12: ldc 27
        //   14: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +80 -> 98
        //   21: aload 5
        //   23: iconst_1
        //   24: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 5
        //   30: iconst_0
        //   31: invokevirtual 297	android/content/Intent:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 5
        //   36: aload_2
        //   37: invokevirtual 33	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   40: aload 5
        //   42: iload_3
        //   43: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   46: aload 5
        //   48: iload 4
        //   50: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   53: aload_0
        //   54: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   57: bipush 28
        //   59: aload 5
        //   61: aload 6
        //   63: iconst_0
        //   64: invokeinterface 39 5 0
        //   69: pop
        //   70: aload 6
        //   72: invokevirtual 42	android/os/Parcel:readException	()V
        //   75: aload 6
        //   77: getstatic 300	android/content/pm/ResolveInfo:CREATOR	Landroid/os/Parcelable$Creator;
        //   80: invokevirtual 149	android/os/Parcel:createTypedArrayList	(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;
        //   83: astore 9
        //   85: aload 6
        //   87: invokevirtual 45	android/os/Parcel:recycle	()V
        //   90: aload 5
        //   92: invokevirtual 45	android/os/Parcel:recycle	()V
        //   95: aload 9
        //   97: areturn
        //   98: aload 5
        //   100: iconst_0
        //   101: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   104: goto -70 -> 34
        //   107: astore 7
        //   109: aload 6
        //   111: invokevirtual 45	android/os/Parcel:recycle	()V
        //   114: aload 5
        //   116: invokevirtual 45	android/os/Parcel:recycle	()V
        //   119: aload 7
        //   121: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	122	0	this	Proxy
        //   0	122	1	paramIntent	Intent
        //   0	122	2	paramString	String
        //   0	122	3	paramInt1	int
        //   0	122	4	paramInt2	int
        //   3	112	5	localParcel1	Parcel
        //   8	102	6	localParcel2	Parcel
        //   107	13	7	localObject	Object
        //   83	13	9	localArrayList	ArrayList
        // Exception table:
        //   from	to	target	type
        //   10	17	107	finally
        //   21	34	107	finally
        //   34	85	107	finally
        //   98	104	107	finally
      }
      
      public List<ResolveInfo> queryIntentActivityOptions(ComponentName paramComponentName, Intent[] paramArrayOfIntent, String[] paramArrayOfString, Intent paramIntent, String paramString, int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
            if (paramComponentName != null)
            {
              localParcel1.writeInt(1);
              paramComponentName.writeToParcel(localParcel1, 0);
              localParcel1.writeTypedArray(paramArrayOfIntent, 0);
              localParcel1.writeStringArray(paramArrayOfString);
              if (paramIntent != null)
              {
                localParcel1.writeInt(1);
                paramIntent.writeToParcel(localParcel1, 0);
                localParcel1.writeString(paramString);
                localParcel1.writeInt(paramInt1);
                localParcel1.writeInt(paramInt2);
                this.mRemote.transact(29, localParcel1, localParcel2, 0);
                localParcel2.readException();
                ArrayList localArrayList = localParcel2.createTypedArrayList(ResolveInfo.CREATOR);
                return localArrayList;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            localParcel1.writeInt(0);
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      /* Error */
      public List<ResolveInfo> queryIntentReceivers(Intent paramIntent, String paramString, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 5
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 6
        //   10: aload 5
        //   12: ldc 27
        //   14: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +80 -> 98
        //   21: aload 5
        //   23: iconst_1
        //   24: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 5
        //   30: iconst_0
        //   31: invokevirtual 297	android/content/Intent:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 5
        //   36: aload_2
        //   37: invokevirtual 33	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   40: aload 5
        //   42: iload_3
        //   43: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   46: aload 5
        //   48: iload 4
        //   50: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   53: aload_0
        //   54: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   57: bipush 30
        //   59: aload 5
        //   61: aload 6
        //   63: iconst_0
        //   64: invokeinterface 39 5 0
        //   69: pop
        //   70: aload 6
        //   72: invokevirtual 42	android/os/Parcel:readException	()V
        //   75: aload 6
        //   77: getstatic 300	android/content/pm/ResolveInfo:CREATOR	Landroid/os/Parcelable$Creator;
        //   80: invokevirtual 149	android/os/Parcel:createTypedArrayList	(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;
        //   83: astore 9
        //   85: aload 6
        //   87: invokevirtual 45	android/os/Parcel:recycle	()V
        //   90: aload 5
        //   92: invokevirtual 45	android/os/Parcel:recycle	()V
        //   95: aload 9
        //   97: areturn
        //   98: aload 5
        //   100: iconst_0
        //   101: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   104: goto -70 -> 34
        //   107: astore 7
        //   109: aload 6
        //   111: invokevirtual 45	android/os/Parcel:recycle	()V
        //   114: aload 5
        //   116: invokevirtual 45	android/os/Parcel:recycle	()V
        //   119: aload 7
        //   121: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	122	0	this	Proxy
        //   0	122	1	paramIntent	Intent
        //   0	122	2	paramString	String
        //   0	122	3	paramInt1	int
        //   0	122	4	paramInt2	int
        //   3	112	5	localParcel1	Parcel
        //   8	102	6	localParcel2	Parcel
        //   107	13	7	localObject	Object
        //   83	13	9	localArrayList	ArrayList
        // Exception table:
        //   from	to	target	type
        //   10	17	107	finally
        //   21	34	107	finally
        //   34	85	107	finally
        //   98	104	107	finally
      }
      
      /* Error */
      public List<ResolveInfo> queryIntentServices(Intent paramIntent, String paramString, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 5
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 6
        //   10: aload 5
        //   12: ldc 27
        //   14: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +80 -> 98
        //   21: aload 5
        //   23: iconst_1
        //   24: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 5
        //   30: iconst_0
        //   31: invokevirtual 297	android/content/Intent:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 5
        //   36: aload_2
        //   37: invokevirtual 33	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   40: aload 5
        //   42: iload_3
        //   43: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   46: aload 5
        //   48: iload 4
        //   50: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   53: aload_0
        //   54: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   57: bipush 32
        //   59: aload 5
        //   61: aload 6
        //   63: iconst_0
        //   64: invokeinterface 39 5 0
        //   69: pop
        //   70: aload 6
        //   72: invokevirtual 42	android/os/Parcel:readException	()V
        //   75: aload 6
        //   77: getstatic 300	android/content/pm/ResolveInfo:CREATOR	Landroid/os/Parcelable$Creator;
        //   80: invokevirtual 149	android/os/Parcel:createTypedArrayList	(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;
        //   83: astore 9
        //   85: aload 6
        //   87: invokevirtual 45	android/os/Parcel:recycle	()V
        //   90: aload 5
        //   92: invokevirtual 45	android/os/Parcel:recycle	()V
        //   95: aload 9
        //   97: areturn
        //   98: aload 5
        //   100: iconst_0
        //   101: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   104: goto -70 -> 34
        //   107: astore 7
        //   109: aload 6
        //   111: invokevirtual 45	android/os/Parcel:recycle	()V
        //   114: aload 5
        //   116: invokevirtual 45	android/os/Parcel:recycle	()V
        //   119: aload 7
        //   121: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	122	0	this	Proxy
        //   0	122	1	paramIntent	Intent
        //   0	122	2	paramString	String
        //   0	122	3	paramInt1	int
        //   0	122	4	paramInt2	int
        //   3	112	5	localParcel1	Parcel
        //   8	102	6	localParcel2	Parcel
        //   107	13	7	localObject	Object
        //   83	13	9	localArrayList	ArrayList
        // Exception table:
        //   from	to	target	type
        //   10	17	107	finally
        //   21	34	107	finally
        //   34	85	107	finally
        //   98	104	107	finally
      }
      
      public List<PermissionInfo> queryPermissionsByGroup(String paramString, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(7, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(PermissionInfo.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void querySyncProviders(List<String> paramList, List<ProviderInfo> paramList1)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeStringList(paramList);
          localParcel1.writeTypedList(paramList1);
          this.mRemote.transact(37, localParcel1, localParcel2, 0);
          localParcel2.readException();
          localParcel2.readStringList(paramList);
          localParcel2.readTypedList(paramList1, ProviderInfo.CREATOR);
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void removePackageFromPreferred(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(47, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void removePermission(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(18, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void replacePreferredActivity(IntentFilter paramIntentFilter, int paramInt, ComponentName[] paramArrayOfComponentName, ComponentName paramComponentName)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
            if (paramIntentFilter != null)
            {
              localParcel1.writeInt(1);
              paramIntentFilter.writeToParcel(localParcel1, 0);
              localParcel1.writeInt(paramInt);
              localParcel1.writeTypedArray(paramArrayOfComponentName, 0);
              if (paramComponentName != null)
              {
                localParcel1.writeInt(1);
                paramComponentName.writeToParcel(localParcel1, 0);
                this.mRemote.transact(50, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            localParcel1.writeInt(0);
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      /* Error */
      public ProviderInfo resolveContentProvider(String paramString, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 4
        //   19: aload_1
        //   20: invokevirtual 33	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   23: aload 4
        //   25: iload_2
        //   26: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   29: aload 4
        //   31: iload_3
        //   32: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 36
        //   41: aload 4
        //   43: aload 5
        //   45: iconst_0
        //   46: invokeinterface 39 5 0
        //   51: pop
        //   52: aload 5
        //   54: invokevirtual 42	android/os/Parcel:readException	()V
        //   57: aload 5
        //   59: invokevirtual 61	android/os/Parcel:readInt	()I
        //   62: ifeq +31 -> 93
        //   65: getstatic 217	android/content/pm/ProviderInfo:CREATOR	Landroid/os/Parcelable$Creator;
        //   68: aload 5
        //   70: invokeinterface 140 2 0
        //   75: checkcast 216	android/content/pm/ProviderInfo
        //   78: astore 8
        //   80: aload 5
        //   82: invokevirtual 45	android/os/Parcel:recycle	()V
        //   85: aload 4
        //   87: invokevirtual 45	android/os/Parcel:recycle	()V
        //   90: aload 8
        //   92: areturn
        //   93: aconst_null
        //   94: astore 8
        //   96: goto -16 -> 80
        //   99: astore 6
        //   101: aload 5
        //   103: invokevirtual 45	android/os/Parcel:recycle	()V
        //   106: aload 4
        //   108: invokevirtual 45	android/os/Parcel:recycle	()V
        //   111: aload 6
        //   113: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	114	0	this	Proxy
        //   0	114	1	paramString	String
        //   0	114	2	paramInt1	int
        //   0	114	3	paramInt2	int
        //   3	104	4	localParcel1	Parcel
        //   8	94	5	localParcel2	Parcel
        //   99	13	6	localObject	Object
        //   78	17	8	localProviderInfo	ProviderInfo
        // Exception table:
        //   from	to	target	type
        //   10	80	99	finally
      }
      
      public ResolveInfo resolveIntent(Intent paramIntent, String paramString, int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
            if (paramIntent != null)
            {
              localParcel1.writeInt(1);
              paramIntent.writeToParcel(localParcel1, 0);
              localParcel1.writeString(paramString);
              localParcel1.writeInt(paramInt1);
              localParcel1.writeInt(paramInt2);
              this.mRemote.transact(27, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localResolveInfo = (ResolveInfo)ResolveInfo.CREATOR.createFromParcel(localParcel2);
                return localResolveInfo;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            ResolveInfo localResolveInfo = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public ResolveInfo resolveService(Intent paramIntent, String paramString, int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
            if (paramIntent != null)
            {
              localParcel1.writeInt(1);
              paramIntent.writeToParcel(localParcel1, 0);
              localParcel1.writeString(paramString);
              localParcel1.writeInt(paramInt1);
              localParcel1.writeInt(paramInt2);
              this.mRemote.transact(31, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localResolveInfo = (ResolveInfo)ResolveInfo.CREATOR.createFromParcel(localParcel2);
                return localResolveInfo;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            ResolveInfo localResolveInfo = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public void revokePermission(String paramString1, String paramString2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString1);
          localParcel1.writeString(paramString2);
          this.mRemote.transact(20, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void setApplicationEnabledSetting(String paramString, int paramInt1, int paramInt2, int paramInt3)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          localParcel1.writeInt(paramInt3);
          this.mRemote.transact(55, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public void setComponentEnabledSetting(ComponentName paramComponentName, int paramInt1, int paramInt2, int paramInt3)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 5
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 6
        //   10: aload 5
        //   12: ldc 27
        //   14: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +68 -> 86
        //   21: aload 5
        //   23: iconst_1
        //   24: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 5
        //   30: iconst_0
        //   31: invokevirtual 74	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 5
        //   36: iload_2
        //   37: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   40: aload 5
        //   42: iload_3
        //   43: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   46: aload 5
        //   48: iload 4
        //   50: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   53: aload_0
        //   54: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   57: bipush 53
        //   59: aload 5
        //   61: aload 6
        //   63: iconst_0
        //   64: invokeinterface 39 5 0
        //   69: pop
        //   70: aload 6
        //   72: invokevirtual 42	android/os/Parcel:readException	()V
        //   75: aload 6
        //   77: invokevirtual 45	android/os/Parcel:recycle	()V
        //   80: aload 5
        //   82: invokevirtual 45	android/os/Parcel:recycle	()V
        //   85: return
        //   86: aload 5
        //   88: iconst_0
        //   89: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   92: goto -58 -> 34
        //   95: astore 7
        //   97: aload 6
        //   99: invokevirtual 45	android/os/Parcel:recycle	()V
        //   102: aload 5
        //   104: invokevirtual 45	android/os/Parcel:recycle	()V
        //   107: aload 7
        //   109: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	110	0	this	Proxy
        //   0	110	1	paramComponentName	ComponentName
        //   0	110	2	paramInt1	int
        //   0	110	3	paramInt2	int
        //   0	110	4	paramInt3	int
        //   3	100	5	localParcel1	Parcel
        //   8	90	6	localParcel2	Parcel
        //   95	13	7	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	95	finally
        //   21	34	95	finally
        //   34	75	95	finally
        //   86	92	95	finally
      }
      
      public boolean setInstallLocation(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(76, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void setInstallerPackageName(String paramString1, String paramString2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString1);
          localParcel1.writeString(paramString2);
          this.mRemote.transact(43, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void setPackageStoppedState(String paramString, boolean paramBoolean, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          int i = 0;
          if (paramBoolean) {
            i = 1;
          }
          localParcel1.writeInt(i);
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(57, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void setPermissionEnforced(String paramString, boolean paramBoolean)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeString(paramString);
          int i = 0;
          if (paramBoolean) {
            i = 1;
          }
          localParcel1.writeInt(i);
          this.mRemote.transact(85, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void systemReady()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          this.mRemote.transact(68, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public void updateExternalMediaStatus(boolean paramBoolean1, boolean paramBoolean2)
        throws RemoteException
      {
        // Byte code:
        //   0: iconst_1
        //   1: istore_3
        //   2: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   5: astore 4
        //   7: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   10: astore 5
        //   12: aload 4
        //   14: ldc 27
        //   16: invokevirtual 30	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   19: iload_1
        //   20: ifeq +56 -> 76
        //   23: iload_3
        //   24: istore 7
        //   26: aload 4
        //   28: iload 7
        //   30: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   33: iload_2
        //   34: ifeq +48 -> 82
        //   37: aload 4
        //   39: iload_3
        //   40: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   43: aload_0
        //   44: getfield 15	android/content/pm/IPackageManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   47: bipush 72
        //   49: aload 4
        //   51: aload 5
        //   53: iconst_0
        //   54: invokeinterface 39 5 0
        //   59: pop
        //   60: aload 5
        //   62: invokevirtual 42	android/os/Parcel:readException	()V
        //   65: aload 5
        //   67: invokevirtual 45	android/os/Parcel:recycle	()V
        //   70: aload 4
        //   72: invokevirtual 45	android/os/Parcel:recycle	()V
        //   75: return
        //   76: iconst_0
        //   77: istore 7
        //   79: goto -53 -> 26
        //   82: iconst_0
        //   83: istore_3
        //   84: goto -47 -> 37
        //   87: astore 6
        //   89: aload 5
        //   91: invokevirtual 45	android/os/Parcel:recycle	()V
        //   94: aload 4
        //   96: invokevirtual 45	android/os/Parcel:recycle	()V
        //   99: aload 6
        //   101: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	102	0	this	Proxy
        //   0	102	1	paramBoolean1	boolean
        //   0	102	2	paramBoolean2	boolean
        //   1	83	3	i	int
        //   5	90	4	localParcel1	Parcel
        //   10	80	5	localParcel2	Parcel
        //   87	13	6	localObject	Object
        //   24	54	7	j	int
        // Exception table:
        //   from	to	target	type
        //   12	19	87	finally
        //   26	33	87	finally
        //   37	65	87	finally
      }
      
      public void verifyPendingInstall(int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.pm.IPackageManager");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          this.mRemote.transact(81, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\pm\IPackageManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
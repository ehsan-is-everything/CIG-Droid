package android.content.pm;

import java.util.HashSet;

public class PackageUserState
{
  public HashSet<String> disabledComponents;
  public int enabled;
  public HashSet<String> enabledComponents;
  public boolean installed;
  public boolean notLaunched;
  public boolean stopped;
  
  public PackageUserState()
  {
    this.installed = true;
    this.enabled = 0;
  }
  
  public PackageUserState(PackageUserState paramPackageUserState)
  {
    this.installed = paramPackageUserState.installed;
    this.stopped = paramPackageUserState.stopped;
    this.notLaunched = paramPackageUserState.notLaunched;
    this.enabled = paramPackageUserState.enabled;
    if (paramPackageUserState.disabledComponents != null) {}
    for (HashSet localHashSet1 = new HashSet(paramPackageUserState.disabledComponents);; localHashSet1 = null)
    {
      this.disabledComponents = localHashSet1;
      HashSet localHashSet2 = paramPackageUserState.enabledComponents;
      HashSet localHashSet3 = null;
      if (localHashSet2 != null) {
        localHashSet3 = new HashSet(paramPackageUserState.enabledComponents);
      }
      this.enabledComponents = localHashSet3;
      return;
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\pm\PackageUserState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
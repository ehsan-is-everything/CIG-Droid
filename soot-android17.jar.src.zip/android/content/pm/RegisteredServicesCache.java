package android.content.pm;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.os.Environment;
import android.os.Handler;
import android.os.UserHandle;
import android.util.AtomicFile;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Slog;
import android.util.SparseArray;
import android.util.Xml;
import com.android.internal.util.FastXmlSerializer;
import com.google.android.collect.Lists;
import com.google.android.collect.Maps;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

public abstract class RegisteredServicesCache<V>
{
  private static final String TAG = "PackageManager";
  private final String mAttributesName;
  public final Context mContext;
  private final BroadcastReceiver mExternalReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      RegisteredServicesCache.this.generateServicesMap(0);
    }
  };
  private Handler mHandler;
  private final String mInterfaceName;
  private RegisteredServicesCacheListener<V> mListener;
  private final String mMetaDataName;
  private final BroadcastReceiver mPackageReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      int i = paramAnonymousIntent.getIntExtra("android.intent.extra.UID", -1);
      if (i != -1) {
        RegisteredServicesCache.this.generateServicesMap(UserHandle.getUserId(i));
      }
    }
  };
  private final AtomicFile mPersistentServicesFile;
  private boolean mPersistentServicesFileDidNotExist;
  private final XmlSerializerAndParser<V> mSerializerAndParser;
  private final Object mServicesLock = new Object();
  private final SparseArray<UserServices<V>> mUserServices = new SparseArray();
  
  public RegisteredServicesCache(Context paramContext, String paramString1, String paramString2, String paramString3, XmlSerializerAndParser<V> paramXmlSerializerAndParser)
  {
    this.mContext = paramContext;
    this.mInterfaceName = paramString1;
    this.mMetaDataName = paramString2;
    this.mAttributesName = paramString3;
    this.mSerializerAndParser = paramXmlSerializerAndParser;
    this.mPersistentServicesFile = new AtomicFile(new File(new File(new File(Environment.getDataDirectory(), "system"), "registered_services"), paramString1 + ".xml"));
    readPersistentServicesLocked();
    IntentFilter localIntentFilter1 = new IntentFilter();
    localIntentFilter1.addAction("android.intent.action.PACKAGE_ADDED");
    localIntentFilter1.addAction("android.intent.action.PACKAGE_CHANGED");
    localIntentFilter1.addAction("android.intent.action.PACKAGE_REMOVED");
    localIntentFilter1.addDataScheme("package");
    this.mContext.registerReceiverAsUser(this.mPackageReceiver, UserHandle.ALL, localIntentFilter1, null, null);
    IntentFilter localIntentFilter2 = new IntentFilter();
    localIntentFilter2.addAction("android.intent.action.EXTERNAL_APPLICATIONS_AVAILABLE");
    localIntentFilter2.addAction("android.intent.action.EXTERNAL_APPLICATIONS_UNAVAILABLE");
    this.mContext.registerReceiver(this.mExternalReceiver, localIntentFilter2);
  }
  
  private boolean containsType(ArrayList<ServiceInfo<V>> paramArrayList, V paramV)
  {
    int i = 0;
    int j = paramArrayList.size();
    while (i < j)
    {
      if (((ServiceInfo)paramArrayList.get(i)).type.equals(paramV)) {
        return true;
      }
      i++;
    }
    return false;
  }
  
  private boolean containsTypeAndUid(ArrayList<ServiceInfo<V>> paramArrayList, V paramV, int paramInt)
  {
    int i = 0;
    int j = paramArrayList.size();
    while (i < j)
    {
      ServiceInfo localServiceInfo = (ServiceInfo)paramArrayList.get(i);
      if ((localServiceInfo.type.equals(paramV)) && (localServiceInfo.uid == paramInt)) {
        return true;
      }
      i++;
    }
    return false;
  }
  
  private UserServices<V> findOrCreateUserLocked(int paramInt)
  {
    UserServices localUserServices = (UserServices)this.mUserServices.get(paramInt);
    if (localUserServices == null)
    {
      localUserServices = new UserServices(null);
      this.mUserServices.put(paramInt, localUserServices);
    }
    return localUserServices;
  }
  
  private void generateServicesMap(int paramInt)
  {
    Slog.d("PackageManager", "generateServicesMap() for " + paramInt);
    PackageManager localPackageManager = this.mContext.getPackageManager();
    ArrayList localArrayList1 = new ArrayList();
    Iterator localIterator1 = localPackageManager.queryIntentServicesAsUser(new Intent(this.mInterfaceName), 128, paramInt).iterator();
    while (localIterator1.hasNext())
    {
      ResolveInfo localResolveInfo = (ResolveInfo)localIterator1.next();
      try
      {
        localServiceInfo2 = parseServiceInfo(localResolveInfo);
        if (localServiceInfo2 == null) {
          Log.w("PackageManager", "Unable to load service info " + localResolveInfo.toString());
        }
      }
      catch (XmlPullParserException localXmlPullParserException)
      {
        ServiceInfo localServiceInfo2;
        Log.w("PackageManager", "Unable to load service info " + localResolveInfo.toString(), localXmlPullParserException);
        continue;
        localArrayList1.add(localServiceInfo2);
      }
      catch (IOException localIOException)
      {
        Log.w("PackageManager", "Unable to load service info " + localResolveInfo.toString(), localIOException);
      }
    }
    UserServices localUserServices;
    StringBuilder localStringBuilder;
    for (;;)
    {
      ServiceInfo localServiceInfo1;
      Integer localInteger;
      synchronized (this.mServicesLock)
      {
        localUserServices = findOrCreateUserLocked(paramInt);
        if (localUserServices.services == null)
        {
          i = 1;
          if (i == 0) {
            break label423;
          }
          localUserServices.services = Maps.newHashMap();
          localStringBuilder = new StringBuilder();
          Iterator localIterator2 = localArrayList1.iterator();
          if (!localIterator2.hasNext()) {
            break;
          }
          localServiceInfo1 = (ServiceInfo)localIterator2.next();
          localInteger = (Integer)localUserServices.persistentServices.get(localServiceInfo1.type);
          if (localInteger != null) {
            break label436;
          }
          localStringBuilder.append("  New service added: ").append(localServiceInfo1).append("\n");
          localUserServices.services.put(localServiceInfo1.type, localServiceInfo1);
          localUserServices.persistentServices.put(localServiceInfo1.type, Integer.valueOf(localServiceInfo1.uid));
          if ((this.mPersistentServicesFileDidNotExist) && (i != 0)) {
            continue;
          }
          notifyListener(localServiceInfo1.type, paramInt, false);
        }
      }
      int i = 0;
      continue;
      label423:
      localUserServices.services.clear();
      continue;
      label436:
      if (localInteger.intValue() == localServiceInfo1.uid)
      {
        if (Log.isLoggable("PackageManager", 2)) {
          localStringBuilder.append("  Existing service (nop): ").append(localServiceInfo1).append("\n");
        }
        localUserServices.services.put(localServiceInfo1.type, localServiceInfo1);
      }
      else
      {
        if ((inSystemImage(localServiceInfo1.uid)) || (!containsTypeAndUid(localArrayList1, localServiceInfo1.type, localInteger.intValue())))
        {
          if (inSystemImage(localServiceInfo1.uid)) {
            localStringBuilder.append("  System service replacing existing: ").append(localServiceInfo1).append("\n");
          }
          for (;;)
          {
            localUserServices.services.put(localServiceInfo1.type, localServiceInfo1);
            localUserServices.persistentServices.put(localServiceInfo1.type, Integer.valueOf(localServiceInfo1.uid));
            notifyListener(localServiceInfo1.type, paramInt, false);
            break;
            localStringBuilder.append("  Existing service replacing a removed service: ").append(localServiceInfo1).append("\n");
          }
        }
        localStringBuilder.append("  Existing service with new uid ignored: ").append(localServiceInfo1).append("\n");
      }
    }
    ArrayList localArrayList2 = Lists.newArrayList();
    Iterator localIterator3 = localUserServices.persistentServices.keySet().iterator();
    while (localIterator3.hasNext())
    {
      Object localObject4 = localIterator3.next();
      if (!containsType(localArrayList1, localObject4)) {
        localArrayList2.add(localObject4);
      }
    }
    Iterator localIterator4 = localArrayList2.iterator();
    while (localIterator4.hasNext())
    {
      Object localObject3 = localIterator4.next();
      localUserServices.persistentServices.remove(localObject3);
      localStringBuilder.append("  Service removed: ").append(localObject3).append("\n");
      notifyListener(localObject3, paramInt, true);
    }
    if (localStringBuilder.length() > 0)
    {
      if (Log.isLoggable("PackageManager", 2)) {
        Log.d("PackageManager", "generateServicesMap(" + this.mInterfaceName + "): " + localArrayList1.size() + " services:\n" + localStringBuilder);
      }
      writePersistentServicesLocked();
    }
    for (;;)
    {
      return;
      if (Log.isLoggable("PackageManager", 2)) {
        Log.d("PackageManager", "generateServicesMap(" + this.mInterfaceName + "): " + localArrayList1.size() + " services unchanged");
      }
    }
  }
  
  private boolean inSystemImage(int paramInt)
  {
    String[] arrayOfString = this.mContext.getPackageManager().getPackagesForUid(paramInt);
    int i = arrayOfString.length;
    for (int j = 0;; j++)
    {
      boolean bool = false;
      String str;
      if (j < i) {
        str = arrayOfString[j];
      }
      try
      {
        int k = this.mContext.getPackageManager().getPackageInfo(str, 0).applicationInfo.flags;
        if ((k & 0x1) != 0)
        {
          bool = true;
          return bool;
        }
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        return false;
      }
    }
  }
  
  private void notifyListener(final V paramV, final int paramInt, final boolean paramBoolean)
  {
    StringBuilder localStringBuilder;
    if (Log.isLoggable("PackageManager", 2))
    {
      localStringBuilder = new StringBuilder().append("notifyListener: ").append(paramV).append(" is ");
      if (!paramBoolean) {
        break label81;
      }
    }
    final RegisteredServicesCacheListener localRegisteredServicesCacheListener;
    Handler localHandler;
    for (String str = "removed";; str = "added")
    {
      Log.d("PackageManager", str);
      label81:
      try
      {
        localRegisteredServicesCacheListener = this.mListener;
        localHandler = this.mHandler;
        if (localRegisteredServicesCacheListener != null) {
          break;
        }
        return;
      }
      finally {}
    }
    localHandler.post(new Runnable()
    {
      public void run()
      {
        localRegisteredServicesCacheListener.onServiceChanged(paramV, paramInt, paramBoolean);
      }
    });
  }
  
  private ServiceInfo<V> parseServiceInfo(ResolveInfo paramResolveInfo)
    throws XmlPullParserException, IOException
  {
    ServiceInfo localServiceInfo = paramResolveInfo.serviceInfo;
    ComponentName localComponentName = new ComponentName(localServiceInfo.packageName, localServiceInfo.name);
    PackageManager localPackageManager = this.mContext.getPackageManager();
    XmlResourceParser localXmlResourceParser = null;
    try
    {
      localXmlResourceParser = localServiceInfo.loadXmlMetaData(localPackageManager, this.mMetaDataName);
      if (localXmlResourceParser == null) {
        throw new XmlPullParserException("No " + this.mMetaDataName + " meta-data");
      }
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      throw new XmlPullParserException("Unable to load resources for pacakge " + localServiceInfo.packageName);
    }
    finally
    {
      if (localXmlResourceParser != null) {
        localXmlResourceParser.close();
      }
    }
    AttributeSet localAttributeSet = Xml.asAttributeSet(localXmlResourceParser);
    int i;
    do
    {
      i = localXmlResourceParser.next();
    } while ((i != 1) && (i != 2));
    String str = localXmlResourceParser.getName();
    if (!this.mAttributesName.equals(str)) {
      throw new XmlPullParserException("Meta-data does not start with " + this.mAttributesName + " tag");
    }
    Object localObject2 = parseServiceAttributes(localPackageManager.getResourcesForApplication(localServiceInfo.applicationInfo), localServiceInfo.packageName, localAttributeSet);
    Object localObject3;
    if (localObject2 == null)
    {
      localObject3 = null;
      if (localXmlResourceParser != null) {
        localXmlResourceParser.close();
      }
    }
    do
    {
      return (ServiceInfo<V>)localObject3;
      localObject3 = new ServiceInfo(localObject2, localComponentName, paramResolveInfo.serviceInfo.applicationInfo.uid);
    } while (localXmlResourceParser == null);
    localXmlResourceParser.close();
    return (ServiceInfo<V>)localObject3;
  }
  
  private void readPersistentServicesLocked()
  {
    this.mUserServices.clear();
    if (this.mSerializerAndParser == null) {}
    FileInputStream localFileInputStream;
    for (;;)
    {
      return;
      localFileInputStream = null;
      try
      {
        if (!this.mPersistentServicesFile.getBaseFile().exists()) {}
        for (boolean bool1 = true;; bool1 = false)
        {
          this.mPersistentServicesFileDidNotExist = bool1;
          boolean bool2 = this.mPersistentServicesFileDidNotExist;
          if (!bool2) {
            break label65;
          }
          if (0 == 0) {
            break;
          }
          try
          {
            throw null;
          }
          catch (IOException localIOException4)
          {
            return;
          }
        }
        label65:
        localFileInputStream = this.mPersistentServicesFile.openRead();
        XmlPullParser localXmlPullParser = Xml.newPullParser();
        localXmlPullParser.setInput(localFileInputStream, null);
        for (int i = localXmlPullParser.getEventType(); i != 2; i = localXmlPullParser.next()) {}
        int j;
        label139:
        Object localObject2;
        if ("services".equals(localXmlPullParser.getName()))
        {
          j = localXmlPullParser.next();
          if ((j != 2) || (localXmlPullParser.getDepth() != 2) || (!"service".equals(localXmlPullParser.getName()))) {
            break label243;
          }
          localObject2 = this.mSerializerAndParser.createFromXml(localXmlPullParser);
          if (localObject2 != null) {
            break label202;
          }
        }
        while (localFileInputStream != null)
        {
          try
          {
            localFileInputStream.close();
            return;
          }
          catch (IOException localIOException3)
          {
            return;
          }
          label202:
          int m = Integer.parseInt(localXmlPullParser.getAttributeValue(null, "uid"));
          findOrCreateUserLocked(UserHandle.getUserId(m)).persistentServices.put(localObject2, Integer.valueOf(m));
          label243:
          int k = localXmlPullParser.next();
          j = k;
          if (j != 1) {
            break label139;
          }
        }
      }
      catch (Exception localException)
      {
        Log.w("PackageManager", "Error reading persistent services, starting from scratch", localException);
        if (localFileInputStream != null) {
          try
          {
            localFileInputStream.close();
            return;
          }
          catch (IOException localIOException2)
          {
            return;
          }
        }
      }
      finally
      {
        if (localFileInputStream == null) {}
      }
    }
    try
    {
      localFileInputStream.close();
      throw ((Throwable)localObject1);
    }
    catch (IOException localIOException1)
    {
      for (;;) {}
    }
  }
  
  private void writePersistentServicesLocked()
  {
    if (this.mSerializerAndParser == null) {
      return;
    }
    FileOutputStream localFileOutputStream = null;
    FastXmlSerializer localFastXmlSerializer;
    for (;;)
    {
      int i;
      try
      {
        localFileOutputStream = this.mPersistentServicesFile.startWrite();
        localFastXmlSerializer = new FastXmlSerializer();
        localFastXmlSerializer.setOutput(localFileOutputStream, "utf-8");
        localFastXmlSerializer.startDocument(null, Boolean.valueOf(true));
        localFastXmlSerializer.setFeature("http://xmlpull.org/v1/doc/features.html#indent-output", true);
        localFastXmlSerializer.startTag(null, "services");
        i = 0;
        if (i >= this.mUserServices.size()) {
          break label240;
        }
        Iterator localIterator = ((UserServices)this.mUserServices.valueAt(i)).persistentServices.entrySet().iterator();
        if (!localIterator.hasNext()) {
          break label234;
        }
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        localFastXmlSerializer.startTag(null, "service");
        localFastXmlSerializer.attribute(null, "uid", Integer.toString(((Integer)localEntry.getValue()).intValue()));
        this.mSerializerAndParser.writeAsXml(localEntry.getKey(), localFastXmlSerializer);
        localFastXmlSerializer.endTag(null, "service");
        continue;
        if (localFileOutputStream == null) {
          break;
        }
      }
      catch (IOException localIOException)
      {
        Log.w("PackageManager", "Error writing accounts", localIOException);
      }
      this.mPersistentServicesFile.failWrite(localFileOutputStream);
      return;
      label234:
      i++;
    }
    label240:
    localFastXmlSerializer.endTag(null, "services");
    localFastXmlSerializer.endDocument();
    this.mPersistentServicesFile.finishWrite(localFileOutputStream);
  }
  
  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString, int paramInt)
  {
    synchronized (this.mServicesLock)
    {
      UserServices localUserServices = findOrCreateUserLocked(paramInt);
      if (localUserServices.services != null)
      {
        paramPrintWriter.println("RegisteredServicesCache: " + localUserServices.services.size() + " services");
        Iterator localIterator = localUserServices.services.values().iterator();
        if (!localIterator.hasNext()) {
          break label146;
        }
        ServiceInfo localServiceInfo = (ServiceInfo)localIterator.next();
        paramPrintWriter.println("  " + localServiceInfo);
      }
    }
    paramPrintWriter.println("RegisteredServicesCache: services not loaded");
    label146:
  }
  
  public Collection<ServiceInfo<V>> getAllServices(int paramInt)
  {
    synchronized (this.mServicesLock)
    {
      UserServices localUserServices = findOrCreateUserLocked(paramInt);
      if (localUserServices.services == null) {
        generateServicesMap(paramInt);
      }
      Collection localCollection = Collections.unmodifiableCollection(new ArrayList(localUserServices.services.values()));
      return localCollection;
    }
  }
  
  public RegisteredServicesCacheListener<V> getListener()
  {
    try
    {
      RegisteredServicesCacheListener localRegisteredServicesCacheListener = this.mListener;
      return localRegisteredServicesCacheListener;
    }
    finally {}
  }
  
  public ServiceInfo<V> getServiceInfo(V paramV, int paramInt)
  {
    synchronized (this.mServicesLock)
    {
      UserServices localUserServices = findOrCreateUserLocked(paramInt);
      if (localUserServices.services == null) {
        generateServicesMap(paramInt);
      }
      ServiceInfo localServiceInfo = (ServiceInfo)localUserServices.services.get(paramV);
      return localServiceInfo;
    }
  }
  
  public void invalidateCache(int paramInt)
  {
    synchronized (this.mServicesLock)
    {
      findOrCreateUserLocked(paramInt).services = null;
      return;
    }
  }
  
  public abstract V parseServiceAttributes(Resources paramResources, String paramString, AttributeSet paramAttributeSet);
  
  public void setListener(RegisteredServicesCacheListener<V> paramRegisteredServicesCacheListener, Handler paramHandler)
  {
    if (paramHandler == null) {
      paramHandler = new Handler(this.mContext.getMainLooper());
    }
    try
    {
      this.mHandler = paramHandler;
      this.mListener = paramRegisteredServicesCacheListener;
      return;
    }
    finally {}
  }
  
  public static class ServiceInfo<V>
  {
    public final ComponentName componentName;
    public final V type;
    public final int uid;
    
    public ServiceInfo(V paramV, ComponentName paramComponentName, int paramInt)
    {
      this.type = paramV;
      this.componentName = paramComponentName;
      this.uid = paramInt;
    }
    
    public String toString()
    {
      return "ServiceInfo: " + this.type + ", " + this.componentName + ", uid " + this.uid;
    }
  }
  
  private static class UserServices<V>
  {
    public final Map<V, Integer> persistentServices = Maps.newHashMap();
    public Map<V, RegisteredServicesCache.ServiceInfo<V>> services = null;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\pm\RegisteredServicesCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.content.pm;

import android.content.res.XmlResourceParser;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import android.util.Printer;
import java.text.Collator;
import java.util.Comparator;

public class PackageItemInfo
{
  public int icon;
  public int labelRes;
  public int logo;
  public Bundle metaData;
  public String name;
  public CharSequence nonLocalizedLabel;
  public String packageName;
  
  public PackageItemInfo() {}
  
  public PackageItemInfo(PackageItemInfo paramPackageItemInfo)
  {
    this.name = paramPackageItemInfo.name;
    if (this.name != null) {
      this.name = this.name.trim();
    }
    this.packageName = paramPackageItemInfo.packageName;
    this.labelRes = paramPackageItemInfo.labelRes;
    this.nonLocalizedLabel = paramPackageItemInfo.nonLocalizedLabel;
    if (this.nonLocalizedLabel != null) {
      this.nonLocalizedLabel = this.nonLocalizedLabel.toString().trim();
    }
    this.icon = paramPackageItemInfo.icon;
    this.logo = paramPackageItemInfo.logo;
    this.metaData = paramPackageItemInfo.metaData;
  }
  
  protected PackageItemInfo(Parcel paramParcel)
  {
    this.name = paramParcel.readString();
    this.packageName = paramParcel.readString();
    this.labelRes = paramParcel.readInt();
    this.nonLocalizedLabel = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.icon = paramParcel.readInt();
    this.logo = paramParcel.readInt();
    this.metaData = paramParcel.readBundle();
  }
  
  protected void dumpBack(Printer paramPrinter, String paramString) {}
  
  protected void dumpFront(Printer paramPrinter, String paramString)
  {
    if (this.name != null) {
      paramPrinter.println(paramString + "name=" + this.name);
    }
    paramPrinter.println(paramString + "packageName=" + this.packageName);
    if ((this.labelRes != 0) || (this.nonLocalizedLabel != null) || (this.icon != 0)) {
      paramPrinter.println(paramString + "labelRes=0x" + Integer.toHexString(this.labelRes) + " nonLocalizedLabel=" + this.nonLocalizedLabel + " icon=0x" + Integer.toHexString(this.icon));
    }
  }
  
  protected ApplicationInfo getApplicationInfo()
  {
    return null;
  }
  
  protected Drawable loadDefaultIcon(PackageManager paramPackageManager)
  {
    return paramPackageManager.getDefaultActivityIcon();
  }
  
  protected Drawable loadDefaultLogo(PackageManager paramPackageManager)
  {
    return null;
  }
  
  public Drawable loadIcon(PackageManager paramPackageManager)
  {
    if (this.icon != 0)
    {
      Drawable localDrawable = paramPackageManager.getDrawable(this.packageName, this.icon, getApplicationInfo());
      if (localDrawable != null) {
        return localDrawable;
      }
    }
    return loadDefaultIcon(paramPackageManager);
  }
  
  public CharSequence loadLabel(PackageManager paramPackageManager)
  {
    if (this.nonLocalizedLabel != null) {
      return this.nonLocalizedLabel;
    }
    if (this.labelRes != 0)
    {
      CharSequence localCharSequence = paramPackageManager.getText(this.packageName, this.labelRes, getApplicationInfo());
      if (localCharSequence != null) {
        return localCharSequence.toString().trim();
      }
    }
    if (this.name != null) {
      return this.name;
    }
    return this.packageName;
  }
  
  public Drawable loadLogo(PackageManager paramPackageManager)
  {
    if (this.logo != 0)
    {
      Drawable localDrawable = paramPackageManager.getDrawable(this.packageName, this.logo, getApplicationInfo());
      if (localDrawable != null) {
        return localDrawable;
      }
    }
    return loadDefaultLogo(paramPackageManager);
  }
  
  public XmlResourceParser loadXmlMetaData(PackageManager paramPackageManager, String paramString)
  {
    if (this.metaData != null)
    {
      int i = this.metaData.getInt(paramString);
      if (i != 0) {
        return paramPackageManager.getXml(this.packageName, i, getApplicationInfo());
      }
    }
    return null;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeString(this.name);
    paramParcel.writeString(this.packageName);
    paramParcel.writeInt(this.labelRes);
    TextUtils.writeToParcel(this.nonLocalizedLabel, paramParcel, paramInt);
    paramParcel.writeInt(this.icon);
    paramParcel.writeInt(this.logo);
    paramParcel.writeBundle(this.metaData);
  }
  
  public static class DisplayNameComparator
    implements Comparator<PackageItemInfo>
  {
    private PackageManager mPM;
    private final Collator sCollator = Collator.getInstance();
    
    public DisplayNameComparator(PackageManager paramPackageManager)
    {
      this.mPM = paramPackageManager;
    }
    
    public final int compare(PackageItemInfo paramPackageItemInfo1, PackageItemInfo paramPackageItemInfo2)
    {
      Object localObject1 = paramPackageItemInfo1.loadLabel(this.mPM);
      if (localObject1 == null) {
        localObject1 = paramPackageItemInfo1.name;
      }
      Object localObject2 = paramPackageItemInfo2.loadLabel(this.mPM);
      if (localObject2 == null) {
        localObject2 = paramPackageItemInfo2.name;
      }
      return this.sCollator.compare(localObject1.toString(), localObject2.toString());
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\pm\PackageItemInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
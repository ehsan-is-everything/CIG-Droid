package android.content.pm;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.crypto.Mac;

public class MacAuthenticatedInputStream
  extends FilterInputStream
{
  private final Mac mMac;
  
  public MacAuthenticatedInputStream(InputStream paramInputStream, Mac paramMac)
  {
    super(paramInputStream);
    this.mMac = paramMac;
  }
  
  public boolean isTagEqual(byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte = this.mMac.doFinal();
    if ((paramArrayOfByte == null) || (arrayOfByte == null) || (paramArrayOfByte.length != arrayOfByte.length)) {}
    int i;
    do
    {
      return false;
      i = 0;
      for (int j = 0; j < paramArrayOfByte.length; j++) {
        i |= paramArrayOfByte[j] ^ arrayOfByte[j];
      }
    } while (i != 0);
    return true;
  }
  
  public int read()
    throws IOException
  {
    int i = super.read();
    if (i >= 0) {
      this.mMac.update((byte)i);
    }
    return i;
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = super.read(paramArrayOfByte, paramInt1, paramInt2);
    if (i > 0) {
      this.mMac.update(paramArrayOfByte, paramInt1, i);
    }
    return i;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\pm\MacAuthenticatedInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
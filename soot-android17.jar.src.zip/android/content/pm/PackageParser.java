package android.content.pm;

import android.content.ComponentName;
import android.content.IntentFilter;
import android.content.IntentFilter.MalformedMimeTypeException;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.PatternMatcher;
import android.os.UserHandle;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Slog;
import android.util.TypedValue;
import com.android.internal.R.styleable;
import com.android.internal.util.XmlUtils;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FilterInputStream;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.Manifest;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class PackageParser
{
  private static final String ANDROID_MANIFEST_FILENAME = "AndroidManifest.xml";
  private static final String ANDROID_RESOURCES = "http://schemas.android.com/apk/res/android";
  private static final boolean DEBUG_BACKUP = false;
  private static final boolean DEBUG_JAR = false;
  private static final boolean DEBUG_PARSER = false;
  public static final NewPermissionInfo[] NEW_PERMISSIONS;
  public static final int PARSE_CHATTY = 2;
  private static final int PARSE_DEFAULT_INSTALL_LOCATION = -1;
  public static final int PARSE_FORWARD_LOCK = 16;
  public static final int PARSE_IGNORE_PROCESSES = 8;
  public static final int PARSE_IS_SYSTEM = 1;
  public static final int PARSE_IS_SYSTEM_DIR = 64;
  public static final int PARSE_MUST_BE_APK = 4;
  public static final int PARSE_ON_SDCARD = 32;
  private static final boolean RIGID_PARSER = false;
  private static final String SDK_CODENAME;
  private static final int SDK_VERSION = 0;
  public static final SplitPermissionInfo[] SPLIT_PERMISSIONS;
  private static final String TAG = "PackageParser";
  private static WeakReference<byte[]> mReadBuffer;
  private static final Object mSync;
  private static boolean sCompatibilityModeEnabled;
  private String mArchiveSourcePath;
  private boolean mOnlyCoreApps;
  private ParseComponentArgs mParseActivityAliasArgs;
  private ParseComponentArgs mParseActivityArgs;
  private int mParseError = 1;
  private ParsePackageItemArgs mParseInstrumentationArgs;
  private ParseComponentArgs mParseProviderArgs;
  private ParseComponentArgs mParseServiceArgs;
  private String[] mSeparateProcesses;
  
  static
  {
    NewPermissionInfo[] arrayOfNewPermissionInfo = new NewPermissionInfo[2];
    arrayOfNewPermissionInfo[0] = new NewPermissionInfo("android.permission.WRITE_EXTERNAL_STORAGE", 4, 0);
    arrayOfNewPermissionInfo[1] = new NewPermissionInfo("android.permission.READ_PHONE_STATE", 4, 0);
    NEW_PERMISSIONS = arrayOfNewPermissionInfo;
    SplitPermissionInfo[] arrayOfSplitPermissionInfo = new SplitPermissionInfo[3];
    arrayOfSplitPermissionInfo[0] = new SplitPermissionInfo("android.permission.WRITE_EXTERNAL_STORAGE", new String[] { "android.permission.READ_EXTERNAL_STORAGE" }, 10001);
    arrayOfSplitPermissionInfo[1] = new SplitPermissionInfo("android.permission.READ_CONTACTS", new String[] { "android.permission.READ_CALL_LOG" }, 16);
    arrayOfSplitPermissionInfo[2] = new SplitPermissionInfo("android.permission.WRITE_CONTACTS", new String[] { "android.permission.WRITE_CALL_LOG" }, 16);
    SPLIT_PERMISSIONS = arrayOfSplitPermissionInfo;
    SDK_VERSION = Build.VERSION.SDK_INT;
    if ("REL".equals(Build.VERSION.CODENAME)) {}
    for (String str = null;; str = Build.VERSION.CODENAME)
    {
      SDK_CODENAME = str;
      mSync = new Object();
      sCompatibilityModeEnabled = true;
      return;
    }
  }
  
  public PackageParser(String paramString)
  {
    this.mArchiveSourcePath = paramString;
  }
  
  private static String buildClassName(String paramString, CharSequence paramCharSequence, String[] paramArrayOfString)
  {
    if ((paramCharSequence == null) || (paramCharSequence.length() <= 0))
    {
      paramArrayOfString[0] = ("Empty class name in package " + paramString);
      return null;
    }
    String str = paramCharSequence.toString();
    int i = str.charAt(0);
    if (i == 46) {
      return (paramString + str).intern();
    }
    if (str.indexOf('.') < 0)
    {
      StringBuilder localStringBuilder = new StringBuilder(paramString);
      localStringBuilder.append('.');
      localStringBuilder.append(str);
      return localStringBuilder.toString().intern();
    }
    if ((i >= 97) && (i <= 122)) {
      return str.intern();
    }
    paramArrayOfString[0] = ("Bad class name " + str + " in package " + paramString);
    return null;
  }
  
  private static String buildCompoundName(String paramString1, CharSequence paramCharSequence, String paramString2, String[] paramArrayOfString)
  {
    String str1 = paramCharSequence.toString();
    int i = str1.charAt(0);
    if ((paramString1 != null) && (i == 58))
    {
      if (str1.length() < 2)
      {
        paramArrayOfString[0] = ("Bad " + paramString2 + " name " + str1 + " in package " + paramString1 + ": must be at least two characters");
        return null;
      }
      String str3 = validateName(str1.substring(1), false);
      if (str3 != null)
      {
        paramArrayOfString[0] = ("Invalid " + paramString2 + " name " + str1 + " in package " + paramString1 + ": " + str3);
        return null;
      }
      return (paramString1 + str1).intern();
    }
    String str2 = validateName(str1, true);
    if ((str2 != null) && (!"system".equals(str1)))
    {
      paramArrayOfString[0] = ("Invalid " + paramString2 + " name " + str1 + " in package " + paramString1 + ": " + str2);
      return null;
    }
    return str1.intern();
  }
  
  private static String buildProcessName(String paramString1, String paramString2, CharSequence paramCharSequence, int paramInt, String[] paramArrayOfString1, String[] paramArrayOfString2)
  {
    if (((paramInt & 0x8) != 0) && (!"system".equals(paramCharSequence))) {
      if (paramString2 == null) {}
    }
    do
    {
      return paramString2;
      return paramString1;
      if (paramArrayOfString1 != null) {
        for (int i = -1 + paramArrayOfString1.length; i >= 0; i--)
        {
          String str = paramArrayOfString1[i];
          if ((str.equals(paramString1)) || (str.equals(paramString2)) || (str.equals(paramCharSequence))) {
            return paramString1;
          }
        }
      }
    } while ((paramCharSequence == null) || (paramCharSequence.length() <= 0));
    return buildCompoundName(paramString1, paramCharSequence, "process", paramArrayOfString2);
  }
  
  private static String buildTaskAffinityName(String paramString1, String paramString2, CharSequence paramCharSequence, String[] paramArrayOfString)
  {
    if (paramCharSequence == null) {
      return paramString2;
    }
    if (paramCharSequence.length() <= 0) {
      return null;
    }
    return buildCompoundName(paramString1, paramCharSequence, "taskAffinity", paramArrayOfString);
  }
  
  private static boolean checkUseInstalled(int paramInt, PackageUserState paramPackageUserState)
  {
    return (paramPackageUserState.installed) || ((paramInt & 0x2000) != 0);
  }
  
  private static boolean copyNeeded(int paramInt1, Package paramPackage, PackageUserState paramPackageUserState, Bundle paramBundle, int paramInt2)
  {
    if (paramInt2 != 0) {}
    label87:
    label91:
    for (;;)
    {
      return true;
      if (paramPackageUserState.enabled != 0) {
        if (paramPackageUserState.enabled != 1) {
          break label87;
        }
      }
      for (int i = 1;; i = 0)
      {
        if (paramPackage.applicationInfo.enabled != i) {
          break label91;
        }
        if ((!paramPackageUserState.installed) || (paramPackageUserState.stopped) || (((paramInt1 & 0x80) != 0) && ((paramBundle != null) || (paramPackage.mAppMetaData != null))) || (((paramInt1 & 0x400) != 0) && (paramPackage.usesLibraryFiles != null))) {
          break;
        }
        return false;
      }
    }
  }
  
  public static final ActivityInfo generateActivityInfo(Activity paramActivity, int paramInt1, PackageUserState paramPackageUserState, int paramInt2)
  {
    if (paramActivity == null) {}
    while (!checkUseInstalled(paramInt1, paramPackageUserState)) {
      return null;
    }
    if (!copyNeeded(paramInt1, paramActivity.owner, paramPackageUserState, paramActivity.metaData, paramInt2)) {
      return paramActivity.info;
    }
    ActivityInfo localActivityInfo = new ActivityInfo(paramActivity.info);
    localActivityInfo.metaData = paramActivity.metaData;
    localActivityInfo.applicationInfo = generateApplicationInfo(paramActivity.owner, paramInt1, paramPackageUserState, paramInt2);
    return localActivityInfo;
  }
  
  public static ApplicationInfo generateApplicationInfo(Package paramPackage, int paramInt, PackageUserState paramPackageUserState)
  {
    return generateApplicationInfo(paramPackage, paramInt, paramPackageUserState, UserHandle.getCallingUserId());
  }
  
  public static ApplicationInfo generateApplicationInfo(Package paramPackage, int paramInt1, PackageUserState paramPackageUserState, int paramInt2)
  {
    if (paramPackage == null) {}
    while (!checkUseInstalled(paramInt1, paramPackageUserState)) {
      return null;
    }
    if (!copyNeeded(paramInt1, paramPackage, paramPackageUserState, null, paramInt2))
    {
      if (!sCompatibilityModeEnabled) {
        paramPackage.applicationInfo.disableCompatibilityMode();
      }
      ApplicationInfo localApplicationInfo2 = paramPackage.applicationInfo;
      localApplicationInfo2.flags = (0x800000 | localApplicationInfo2.flags);
      if (paramPackageUserState.enabled == 1) {}
      for (paramPackage.applicationInfo.enabled = true;; paramPackage.applicationInfo.enabled = false) {
        do
        {
          paramPackage.applicationInfo.enabledSetting = paramPackageUserState.enabled;
          return paramPackage.applicationInfo;
        } while ((paramPackageUserState.enabled != 2) && (paramPackageUserState.enabled != 3));
      }
    }
    ApplicationInfo localApplicationInfo1 = new ApplicationInfo(paramPackage.applicationInfo);
    if (paramInt2 != 0)
    {
      localApplicationInfo1.uid = UserHandle.getUid(paramInt2, localApplicationInfo1.uid);
      localApplicationInfo1.dataDir = PackageManager.getDataDirForUser(paramInt2, localApplicationInfo1.packageName);
    }
    if ((paramInt1 & 0x80) != 0) {
      localApplicationInfo1.metaData = paramPackage.mAppMetaData;
    }
    if ((paramInt1 & 0x400) != 0) {
      localApplicationInfo1.sharedLibraryFiles = paramPackage.usesLibraryFiles;
    }
    if (!sCompatibilityModeEnabled) {
      localApplicationInfo1.disableCompatibilityMode();
    }
    if (paramPackageUserState.stopped)
    {
      localApplicationInfo1.flags = (0x200000 | localApplicationInfo1.flags);
      if (!paramPackageUserState.installed) {
        break label292;
      }
      localApplicationInfo1.flags = (0x800000 | localApplicationInfo1.flags);
      label249:
      if (paramPackageUserState.enabled != 1) {
        break label309;
      }
    }
    for (localApplicationInfo1.enabled = true;; localApplicationInfo1.enabled = false) {
      label292:
      label309:
      do
      {
        localApplicationInfo1.enabledSetting = paramPackageUserState.enabled;
        return localApplicationInfo1;
        localApplicationInfo1.flags = (0xFFDFFFFF & localApplicationInfo1.flags);
        break;
        localApplicationInfo1.flags = (0xFF7FFFFF & localApplicationInfo1.flags);
        break label249;
      } while ((paramPackageUserState.enabled != 2) && (paramPackageUserState.enabled != 3));
    }
  }
  
  public static final InstrumentationInfo generateInstrumentationInfo(Instrumentation paramInstrumentation, int paramInt)
  {
    if (paramInstrumentation == null) {
      return null;
    }
    if ((paramInt & 0x80) == 0) {
      return paramInstrumentation.info;
    }
    InstrumentationInfo localInstrumentationInfo = new InstrumentationInfo(paramInstrumentation.info);
    localInstrumentationInfo.metaData = paramInstrumentation.metaData;
    return localInstrumentationInfo;
  }
  
  public static PackageInfo generatePackageInfo(Package paramPackage, int[] paramArrayOfInt, int paramInt, long paramLong1, long paramLong2, HashSet<String> paramHashSet, PackageUserState paramPackageUserState)
  {
    return generatePackageInfo(paramPackage, paramArrayOfInt, paramInt, paramLong1, paramLong2, paramHashSet, paramPackageUserState, UserHandle.getCallingUserId());
  }
  
  public static PackageInfo generatePackageInfo(Package paramPackage, int[] paramArrayOfInt, int paramInt1, long paramLong1, long paramLong2, HashSet<String> paramHashSet, PackageUserState paramPackageUserState, int paramInt2)
  {
    if (!checkUseInstalled(paramInt1, paramPackageUserState))
    {
      localPackageInfo = null;
      return localPackageInfo;
    }
    PackageInfo localPackageInfo = new PackageInfo();
    localPackageInfo.packageName = paramPackage.packageName;
    localPackageInfo.versionCode = paramPackage.mVersionCode;
    localPackageInfo.versionName = paramPackage.mVersionName;
    localPackageInfo.sharedUserId = paramPackage.mSharedUserId;
    localPackageInfo.sharedUserLabel = paramPackage.mSharedUserLabel;
    localPackageInfo.applicationInfo = generateApplicationInfo(paramPackage, paramInt1, paramPackageUserState, paramInt2);
    localPackageInfo.installLocation = paramPackage.installLocation;
    localPackageInfo.firstInstallTime = paramLong1;
    localPackageInfo.lastUpdateTime = paramLong2;
    if ((paramInt1 & 0x100) != 0) {
      localPackageInfo.gids = paramArrayOfInt;
    }
    int i28;
    if ((paramInt1 & 0x4000) != 0)
    {
      int i27 = paramPackage.configPreferences.size();
      if (i27 > 0)
      {
        localPackageInfo.configPreferences = new ConfigurationInfo[i27];
        paramPackage.configPreferences.toArray(localPackageInfo.configPreferences);
      }
      if (paramPackage.reqFeatures == null) {
        break label336;
      }
      i28 = paramPackage.reqFeatures.size();
      label180:
      if (i28 > 0)
      {
        localPackageInfo.reqFeatures = new FeatureInfo[i28];
        paramPackage.reqFeatures.toArray(localPackageInfo.reqFeatures);
      }
    }
    int i21;
    label246:
    int i24;
    int i25;
    label252:
    int i26;
    if ((paramInt1 & 0x1) != 0)
    {
      i21 = paramPackage.activities.size();
      if (i21 > 0) {
        if ((paramInt1 & 0x200) != 0)
        {
          localPackageInfo.activities = new ActivityInfo[i21];
          i24 = 0;
          i25 = 0;
          if (i24 >= i21) {
            break label398;
          }
          if ((!((Activity)paramPackage.activities.get(i24)).info.enabled) && ((paramInt1 & 0x200) == 0)) {
            break label1320;
          }
          ActivityInfo[] arrayOfActivityInfo2 = localPackageInfo.activities;
          i26 = i25 + 1;
          arrayOfActivityInfo2[i25] = generateActivityInfo((Activity)paramPackage.activities.get(i24), paramInt1, paramPackageUserState, paramInt2);
        }
      }
    }
    for (;;)
    {
      i24++;
      i25 = i26;
      break label252;
      label336:
      i28 = 0;
      break label180;
      int i22 = 0;
      for (int i23 = 0; i23 < i21; i23++) {
        if (((Activity)paramPackage.activities.get(i23)).info.enabled) {
          i22++;
        }
      }
      localPackageInfo.activities = new ActivityInfo[i22];
      break label246;
      label398:
      int i15;
      label436:
      int i18;
      int i19;
      label442:
      int i20;
      if ((paramInt1 & 0x2) != 0)
      {
        i15 = paramPackage.receivers.size();
        if (i15 > 0) {
          if ((paramInt1 & 0x200) != 0)
          {
            localPackageInfo.receivers = new ActivityInfo[i15];
            i18 = 0;
            i19 = 0;
            if (i18 >= i15) {
              break label582;
            }
            if ((!((Activity)paramPackage.receivers.get(i18)).info.enabled) && ((paramInt1 & 0x200) == 0)) {
              break label1313;
            }
            ActivityInfo[] arrayOfActivityInfo1 = localPackageInfo.receivers;
            i20 = i19 + 1;
            arrayOfActivityInfo1[i19] = generateActivityInfo((Activity)paramPackage.receivers.get(i18), paramInt1, paramPackageUserState, paramInt2);
          }
        }
      }
      for (;;)
      {
        i18++;
        i19 = i20;
        break label442;
        int i16 = 0;
        for (int i17 = 0; i17 < i15; i17++) {
          if (((Activity)paramPackage.receivers.get(i17)).info.enabled) {
            i16++;
          }
        }
        localPackageInfo.receivers = new ActivityInfo[i16];
        break label436;
        label582:
        int i9;
        label620:
        int i12;
        int i13;
        label626:
        int i14;
        if ((paramInt1 & 0x4) != 0)
        {
          i9 = paramPackage.services.size();
          if (i9 > 0) {
            if ((paramInt1 & 0x200) != 0)
            {
              localPackageInfo.services = new ServiceInfo[i9];
              i12 = 0;
              i13 = 0;
              if (i12 >= i9) {
                break label766;
              }
              if ((!((Service)paramPackage.services.get(i12)).info.enabled) && ((paramInt1 & 0x200) == 0)) {
                break label1306;
              }
              ServiceInfo[] arrayOfServiceInfo = localPackageInfo.services;
              i14 = i13 + 1;
              arrayOfServiceInfo[i13] = generateServiceInfo((Service)paramPackage.services.get(i12), paramInt1, paramPackageUserState, paramInt2);
            }
          }
        }
        for (;;)
        {
          i12++;
          i13 = i14;
          break label626;
          int i10 = 0;
          for (int i11 = 0; i11 < i9; i11++) {
            if (((Service)paramPackage.services.get(i11)).info.enabled) {
              i10++;
            }
          }
          localPackageInfo.services = new ServiceInfo[i10];
          break label620;
          label766:
          int i3;
          label805:
          int i6;
          int i7;
          label811:
          int i8;
          if ((paramInt1 & 0x8) != 0)
          {
            i3 = paramPackage.providers.size();
            if (i3 > 0) {
              if ((paramInt1 & 0x200) != 0)
              {
                localPackageInfo.providers = new ProviderInfo[i3];
                i6 = 0;
                i7 = 0;
                if (i6 >= i3) {
                  break label951;
                }
                if ((!((Provider)paramPackage.providers.get(i6)).info.enabled) && ((paramInt1 & 0x200) == 0)) {
                  break label1299;
                }
                ProviderInfo[] arrayOfProviderInfo = localPackageInfo.providers;
                i8 = i7 + 1;
                arrayOfProviderInfo[i7] = generateProviderInfo((Provider)paramPackage.providers.get(i6), paramInt1, paramPackageUserState, paramInt2);
              }
            }
          }
          for (;;)
          {
            i6++;
            i7 = i8;
            break label811;
            int i4 = 0;
            for (int i5 = 0; i5 < i3; i5++) {
              if (((Provider)paramPackage.providers.get(i5)).info.enabled) {
                i4++;
              }
            }
            localPackageInfo.providers = new ProviderInfo[i4];
            break label805;
            label951:
            if ((paramInt1 & 0x10) != 0)
            {
              int i1 = paramPackage.instrumentation.size();
              if (i1 > 0)
              {
                localPackageInfo.instrumentation = new InstrumentationInfo[i1];
                for (int i2 = 0; i2 < i1; i2++) {
                  localPackageInfo.instrumentation[i2] = generateInstrumentationInfo((Instrumentation)paramPackage.instrumentation.get(i2), paramInt1);
                }
              }
            }
            if ((paramInt1 & 0x1000) != 0)
            {
              int j = paramPackage.permissions.size();
              if (j > 0)
              {
                localPackageInfo.permissions = new PermissionInfo[j];
                for (int n = 0; n < j; n++) {
                  localPackageInfo.permissions[n] = generatePermissionInfo((Permission)paramPackage.permissions.get(n), paramInt1);
                }
              }
              int k = paramPackage.requestedPermissions.size();
              if (k > 0)
              {
                localPackageInfo.requestedPermissions = new String[k];
                localPackageInfo.requestedPermissionsFlags = new int[k];
                for (int m = 0; m < k; m++)
                {
                  String str = (String)paramPackage.requestedPermissions.get(m);
                  localPackageInfo.requestedPermissions[m] = str;
                  if (((Boolean)paramPackage.requestedPermissionsRequired.get(m)).booleanValue())
                  {
                    int[] arrayOfInt2 = localPackageInfo.requestedPermissionsFlags;
                    arrayOfInt2[m] = (0x1 | arrayOfInt2[m]);
                  }
                  if ((paramHashSet != null) && (paramHashSet.contains(str)))
                  {
                    int[] arrayOfInt1 = localPackageInfo.requestedPermissionsFlags;
                    arrayOfInt1[m] = (0x2 | arrayOfInt1[m]);
                  }
                }
              }
            }
            if ((paramInt1 & 0x40) == 0) {
              break;
            }
            if (paramPackage.mSignatures != null) {}
            for (int i = paramPackage.mSignatures.length; i > 0; i = 0)
            {
              localPackageInfo.signatures = new Signature[i];
              System.arraycopy(paramPackage.mSignatures, 0, localPackageInfo.signatures, 0, i);
              return localPackageInfo;
            }
            break;
            label1299:
            i8 = i7;
          }
          label1306:
          i14 = i13;
        }
        label1313:
        i20 = i19;
      }
      label1320:
      i26 = i25;
    }
  }
  
  public static final PermissionGroupInfo generatePermissionGroupInfo(PermissionGroup paramPermissionGroup, int paramInt)
  {
    if (paramPermissionGroup == null) {
      return null;
    }
    if ((paramInt & 0x80) == 0) {
      return paramPermissionGroup.info;
    }
    PermissionGroupInfo localPermissionGroupInfo = new PermissionGroupInfo(paramPermissionGroup.info);
    localPermissionGroupInfo.metaData = paramPermissionGroup.metaData;
    return localPermissionGroupInfo;
  }
  
  public static final PermissionInfo generatePermissionInfo(Permission paramPermission, int paramInt)
  {
    if (paramPermission == null) {
      return null;
    }
    if ((paramInt & 0x80) == 0) {
      return paramPermission.info;
    }
    PermissionInfo localPermissionInfo = new PermissionInfo(paramPermission.info);
    localPermissionInfo.metaData = paramPermission.metaData;
    return localPermissionInfo;
  }
  
  public static final ProviderInfo generateProviderInfo(Provider paramProvider, int paramInt1, PackageUserState paramPackageUserState, int paramInt2)
  {
    if (paramProvider == null) {
      return null;
    }
    if (!checkUseInstalled(paramInt1, paramPackageUserState)) {
      return null;
    }
    if ((!copyNeeded(paramInt1, paramProvider.owner, paramPackageUserState, paramProvider.metaData, paramInt2)) && (((paramInt1 & 0x800) != 0) || (paramProvider.info.uriPermissionPatterns == null))) {
      return paramProvider.info;
    }
    ProviderInfo localProviderInfo = new ProviderInfo(paramProvider.info);
    localProviderInfo.metaData = paramProvider.metaData;
    if ((paramInt1 & 0x800) == 0) {
      localProviderInfo.uriPermissionPatterns = null;
    }
    localProviderInfo.applicationInfo = generateApplicationInfo(paramProvider.owner, paramInt1, paramPackageUserState, paramInt2);
    return localProviderInfo;
  }
  
  public static final ServiceInfo generateServiceInfo(Service paramService, int paramInt1, PackageUserState paramPackageUserState, int paramInt2)
  {
    if (paramService == null) {}
    while (!checkUseInstalled(paramInt1, paramPackageUserState)) {
      return null;
    }
    if (!copyNeeded(paramInt1, paramService.owner, paramPackageUserState, paramService.metaData, paramInt2)) {
      return paramService.info;
    }
    ServiceInfo localServiceInfo = new ServiceInfo(paramService.info);
    localServiceInfo.metaData = paramService.metaData;
    localServiceInfo.applicationInfo = generateApplicationInfo(paramService.owner, paramInt1, paramPackageUserState, paramInt2);
    return localServiceInfo;
  }
  
  private static final boolean isPackageFilename(String paramString)
  {
    return paramString.endsWith(".apk");
  }
  
  private Certificate[] loadCertificates(JarFile paramJarFile, JarEntry paramJarEntry, byte[] paramArrayOfByte)
  {
    try
    {
      BufferedInputStream localBufferedInputStream = new BufferedInputStream(paramJarFile.getInputStream(paramJarEntry));
      while (localBufferedInputStream.read(paramArrayOfByte, 0, paramArrayOfByte.length) != -1) {}
      localBufferedInputStream.close();
      Object localObject = null;
      if (paramJarEntry != null)
      {
        Certificate[] arrayOfCertificate = paramJarEntry.getCertificates();
        localObject = arrayOfCertificate;
      }
      return (Certificate[])localObject;
    }
    catch (IOException localIOException)
    {
      Slog.w("PackageParser", "Exception reading " + paramJarEntry.getName() + " in " + paramJarFile.getName(), localIOException);
      return null;
    }
    catch (RuntimeException localRuntimeException)
    {
      Slog.w("PackageParser", "Exception reading " + paramJarEntry.getName() + " in " + paramJarFile.getName(), localRuntimeException);
    }
    return null;
  }
  
  private Activity parseActivity(Package paramPackage, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, int paramInt, String[] paramArrayOfString, boolean paramBoolean1, boolean paramBoolean2)
    throws XmlPullParserException, IOException
  {
    TypedArray localTypedArray = paramResources.obtainAttributes(paramAttributeSet, R.styleable.AndroidManifestActivity);
    if (this.mParseActivityArgs == null) {
      this.mParseActivityArgs = new ParseComponentArgs(paramPackage, paramArrayOfString, 3, 1, 2, 23, this.mSeparateProcesses, 7, 17, 5);
    }
    ParseComponentArgs localParseComponentArgs = this.mParseActivityArgs;
    String str1;
    Activity localActivity;
    if (paramBoolean1)
    {
      str1 = "<receiver>";
      localParseComponentArgs.tag = str1;
      this.mParseActivityArgs.sa = localTypedArray;
      this.mParseActivityArgs.flags = paramInt;
      localActivity = new Activity(this.mParseActivityArgs, new ActivityInfo());
      if (paramArrayOfString[0] == null) {
        break label133;
      }
      localTypedArray.recycle();
      localActivity = null;
    }
    label133:
    boolean bool1;
    label561:
    label1048:
    label1089:
    label1095:
    label1116:
    label1511:
    do
    {
      return localActivity;
      str1 = "<activity>";
      break;
      bool1 = localTypedArray.hasValue(6);
      if (bool1) {
        localActivity.info.exported = localTypedArray.getBoolean(6, false);
      }
      localActivity.info.theme = localTypedArray.getResourceId(0, 0);
      localActivity.info.uiOptions = localTypedArray.getInt(26, localActivity.info.applicationInfo.uiOptions);
      String str2 = localTypedArray.getNonConfigurationString(27, 0);
      String str3;
      boolean bool2;
      if (str2 != null)
      {
        String str6 = buildClassName(localActivity.info.packageName, str2, paramArrayOfString);
        if (paramArrayOfString[0] == null) {
          localActivity.info.parentActivityName = str6;
        }
      }
      else
      {
        str3 = localTypedArray.getNonConfigurationString(4, 0);
        if (str3 != null) {
          break label1048;
        }
        localActivity.info.permission = paramPackage.applicationInfo.permission;
        String str5 = localTypedArray.getNonConfigurationString(8, 0);
        localActivity.info.taskAffinity = buildTaskAffinityName(paramPackage.applicationInfo.packageName, paramPackage.applicationInfo.taskAffinity, str5, paramArrayOfString);
        localActivity.info.flags = 0;
        if (localTypedArray.getBoolean(9, false))
        {
          ActivityInfo localActivityInfo16 = localActivity.info;
          localActivityInfo16.flags = (0x1 | localActivityInfo16.flags);
        }
        if (localTypedArray.getBoolean(10, false))
        {
          ActivityInfo localActivityInfo15 = localActivity.info;
          localActivityInfo15.flags = (0x2 | localActivityInfo15.flags);
        }
        if (localTypedArray.getBoolean(11, false))
        {
          ActivityInfo localActivityInfo14 = localActivity.info;
          localActivityInfo14.flags = (0x4 | localActivityInfo14.flags);
        }
        if (localTypedArray.getBoolean(21, false))
        {
          ActivityInfo localActivityInfo13 = localActivity.info;
          localActivityInfo13.flags = (0x80 | localActivityInfo13.flags);
        }
        if (localTypedArray.getBoolean(18, false))
        {
          ActivityInfo localActivityInfo12 = localActivity.info;
          localActivityInfo12.flags = (0x8 | localActivityInfo12.flags);
        }
        if (localTypedArray.getBoolean(12, false))
        {
          ActivityInfo localActivityInfo11 = localActivity.info;
          localActivityInfo11.flags = (0x10 | localActivityInfo11.flags);
        }
        if (localTypedArray.getBoolean(13, false))
        {
          ActivityInfo localActivityInfo10 = localActivity.info;
          localActivityInfo10.flags = (0x20 | localActivityInfo10.flags);
        }
        if ((0x20 & paramPackage.applicationInfo.flags) == 0) {
          break label1089;
        }
        bool2 = true;
        if (localTypedArray.getBoolean(19, bool2))
        {
          ActivityInfo localActivityInfo9 = localActivity.info;
          localActivityInfo9.flags = (0x40 | localActivityInfo9.flags);
        }
        if (localTypedArray.getBoolean(22, false))
        {
          ActivityInfo localActivityInfo8 = localActivity.info;
          localActivityInfo8.flags = (0x100 | localActivityInfo8.flags);
        }
        if (localTypedArray.getBoolean(29, false))
        {
          ActivityInfo localActivityInfo7 = localActivity.info;
          localActivityInfo7.flags = (0x400 | localActivityInfo7.flags);
        }
        if (localTypedArray.getBoolean(24, false))
        {
          ActivityInfo localActivityInfo6 = localActivity.info;
          localActivityInfo6.flags = (0x800 | localActivityInfo6.flags);
        }
        if (paramBoolean1) {
          break label1095;
        }
        if (localTypedArray.getBoolean(25, paramBoolean2))
        {
          ActivityInfo localActivityInfo5 = localActivity.info;
          localActivityInfo5.flags = (0x200 | localActivityInfo5.flags);
        }
        localActivity.info.launchMode = localTypedArray.getInt(14, 0);
        localActivity.info.screenOrientation = localTypedArray.getInt(15, -1);
        localActivity.info.configChanges = localTypedArray.getInt(16, 0);
        localActivity.info.softInputMode = localTypedArray.getInt(20, 0);
      }
      for (;;)
      {
        if (paramBoolean1)
        {
          if (localTypedArray.getBoolean(28, false))
          {
            ActivityInfo localActivityInfo4 = localActivity.info;
            localActivityInfo4.flags = (0x40000000 | localActivityInfo4.flags);
            if (localActivity.info.exported)
            {
              Slog.w("PackageParser", "Activity exported request ignored due to singleUser: " + localActivity.className + " at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
              localActivity.info.exported = false;
            }
            bool1 = true;
          }
          if (localTypedArray.getBoolean(30, false))
          {
            ActivityInfo localActivityInfo3 = localActivity.info;
            localActivityInfo3.flags = (0x20000000 | localActivityInfo3.flags);
          }
        }
        localTypedArray.recycle();
        if ((paramBoolean1) && ((0x10000000 & paramPackage.applicationInfo.flags) != 0) && (localActivity.info.processName == paramPackage.packageName)) {
          paramArrayOfString[0] = "Heavy-weight applications can not have receivers in main process";
        }
        if (paramArrayOfString[0] == null) {
          break label1116;
        }
        return null;
        Log.e("PackageParser", "Activity " + localActivity.info.name + " specified invalid parentActivityName " + str2);
        paramArrayOfString[0] = null;
        break;
        ActivityInfo localActivityInfo1 = localActivity.info;
        if (str3.length() > 0) {}
        for (String str4 = str3.toString().intern();; str4 = null)
        {
          localActivityInfo1.permission = str4;
          break;
        }
        bool2 = false;
        break label561;
        localActivity.info.launchMode = 0;
        localActivity.info.configChanges = 0;
      }
      int i = paramXmlPullParser.getDepth();
      Bundle localBundle;
      do
      {
        for (;;)
        {
          int j = paramXmlPullParser.next();
          if ((j == 1) || ((j == 3) && (paramXmlPullParser.getDepth() <= i))) {
            break label1511;
          }
          if ((j != 3) && (j != 4))
          {
            if (!paramXmlPullParser.getName().equals("intent-filter")) {
              break;
            }
            ActivityIntentInfo localActivityIntentInfo = new ActivityIntentInfo(localActivity);
            if (!paramBoolean1) {}
            for (boolean bool4 = true; !parseIntent(paramResources, paramXmlPullParser, paramAttributeSet, paramInt, localActivityIntentInfo, paramArrayOfString, bool4); bool4 = false) {
              return null;
            }
            if (localActivityIntentInfo.countActions() == 0) {
              Slog.w("PackageParser", "No actions in intent filter at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
            } else {
              localActivity.intents.add(localActivityIntentInfo);
            }
          }
        }
        if (!paramXmlPullParser.getName().equals("meta-data")) {
          break;
        }
        localBundle = parseMetaData(paramResources, paramXmlPullParser, paramAttributeSet, localActivity.metaData, paramArrayOfString);
        localActivity.metaData = localBundle;
      } while (localBundle != null);
      return null;
      Slog.w("PackageParser", "Problem in package " + this.mArchiveSourcePath + ":");
      if (paramBoolean1) {
        Slog.w("PackageParser", "Unknown element under <receiver>: " + paramXmlPullParser.getName() + " at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
      }
      for (;;)
      {
        XmlUtils.skipCurrentTag(paramXmlPullParser);
        break;
        Slog.w("PackageParser", "Unknown element under <activity>: " + paramXmlPullParser.getName() + " at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
      }
    } while (bool1);
    ActivityInfo localActivityInfo2 = localActivity.info;
    if (localActivity.intents.size() > 0) {}
    for (boolean bool3 = true;; bool3 = false)
    {
      localActivityInfo2.exported = bool3;
      return localActivity;
    }
  }
  
  private Activity parseActivityAlias(Package paramPackage, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, int paramInt, String[] paramArrayOfString)
    throws XmlPullParserException, IOException
  {
    TypedArray localTypedArray = paramResources.obtainAttributes(paramAttributeSet, R.styleable.AndroidManifestActivityAlias);
    String str1 = localTypedArray.getNonConfigurationString(7, 0);
    Activity localActivity1;
    if (str1 == null)
    {
      paramArrayOfString[0] = "<activity-alias> does not specify android:targetActivity";
      localTypedArray.recycle();
      localActivity1 = null;
    }
    boolean bool1;
    label634:
    label686:
    do
    {
      return localActivity1;
      String str2 = buildClassName(paramPackage.applicationInfo.packageName, str1, paramArrayOfString);
      if (str2 == null)
      {
        localTypedArray.recycle();
        return null;
      }
      if (this.mParseActivityAliasArgs == null)
      {
        this.mParseActivityAliasArgs = new ParseComponentArgs(paramPackage, paramArrayOfString, 2, 0, 1, 8, this.mSeparateProcesses, 0, 6, 4);
        this.mParseActivityAliasArgs.tag = "<activity-alias>";
      }
      this.mParseActivityAliasArgs.sa = localTypedArray;
      this.mParseActivityAliasArgs.flags = paramInt;
      int i = paramPackage.activities.size();
      Object localObject;
      for (int j = 0;; j++)
      {
        int k = j;
        localObject = null;
        if (k < i)
        {
          Activity localActivity2 = (Activity)paramPackage.activities.get(j);
          if (str2.equals(localActivity2.info.name)) {
            localObject = localActivity2;
          }
        }
        else
        {
          if (localObject != null) {
            break;
          }
          paramArrayOfString[0] = ("<activity-alias> target activity " + str2 + " not found in manifest");
          localTypedArray.recycle();
          return null;
        }
      }
      ActivityInfo localActivityInfo1 = new ActivityInfo();
      localActivityInfo1.targetActivity = str2;
      localActivityInfo1.configChanges = ((Activity)localObject).info.configChanges;
      localActivityInfo1.flags = ((Activity)localObject).info.flags;
      localActivityInfo1.icon = ((Activity)localObject).info.icon;
      localActivityInfo1.logo = ((Activity)localObject).info.logo;
      localActivityInfo1.labelRes = ((Activity)localObject).info.labelRes;
      localActivityInfo1.nonLocalizedLabel = ((Activity)localObject).info.nonLocalizedLabel;
      localActivityInfo1.launchMode = ((Activity)localObject).info.launchMode;
      localActivityInfo1.processName = ((Activity)localObject).info.processName;
      if (localActivityInfo1.descriptionRes == 0) {
        localActivityInfo1.descriptionRes = ((Activity)localObject).info.descriptionRes;
      }
      localActivityInfo1.screenOrientation = ((Activity)localObject).info.screenOrientation;
      localActivityInfo1.taskAffinity = ((Activity)localObject).info.taskAffinity;
      localActivityInfo1.theme = ((Activity)localObject).info.theme;
      localActivityInfo1.softInputMode = ((Activity)localObject).info.softInputMode;
      localActivityInfo1.uiOptions = ((Activity)localObject).info.uiOptions;
      localActivityInfo1.parentActivityName = ((Activity)localObject).info.parentActivityName;
      localActivity1 = new Activity(this.mParseActivityAliasArgs, localActivityInfo1);
      if (paramArrayOfString[0] != null)
      {
        localTypedArray.recycle();
        return null;
      }
      bool1 = localTypedArray.hasValue(5);
      if (bool1) {
        localActivity1.info.exported = localTypedArray.getBoolean(5, false);
      }
      String str3 = localTypedArray.getNonConfigurationString(3, 0);
      String str6;
      String str4;
      if (str3 != null)
      {
        ActivityInfo localActivityInfo3 = localActivity1.info;
        if (str3.length() > 0)
        {
          str6 = str3.toString().intern();
          localActivityInfo3.permission = str6;
        }
      }
      else
      {
        str4 = localTypedArray.getNonConfigurationString(9, 0);
        if (str4 != null)
        {
          String str5 = buildClassName(localActivity1.info.packageName, str4, paramArrayOfString);
          if (paramArrayOfString[0] != null) {
            break label634;
          }
          localActivity1.info.parentActivityName = str5;
        }
      }
      for (;;)
      {
        localTypedArray.recycle();
        if (paramArrayOfString[0] == null) {
          break label686;
        }
        return null;
        str6 = null;
        break;
        Log.e("PackageParser", "Activity alias " + localActivity1.info.name + " specified invalid parentActivityName " + str4);
        paramArrayOfString[0] = null;
      }
      int m = paramXmlPullParser.getDepth();
      for (;;)
      {
        int n = paramXmlPullParser.next();
        if ((n == 1) || ((n == 3) && (paramXmlPullParser.getDepth() <= m))) {
          break;
        }
        if ((n != 3) && (n != 4)) {
          if (paramXmlPullParser.getName().equals("intent-filter"))
          {
            ActivityIntentInfo localActivityIntentInfo = new ActivityIntentInfo(localActivity1);
            if (!parseIntent(paramResources, paramXmlPullParser, paramAttributeSet, paramInt, localActivityIntentInfo, paramArrayOfString, true)) {
              return null;
            }
            if (localActivityIntentInfo.countActions() == 0) {
              Slog.w("PackageParser", "No actions in intent filter at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
            } else {
              localActivity1.intents.add(localActivityIntentInfo);
            }
          }
          else if (paramXmlPullParser.getName().equals("meta-data"))
          {
            Bundle localBundle = parseMetaData(paramResources, paramXmlPullParser, paramAttributeSet, localActivity1.metaData, paramArrayOfString);
            localActivity1.metaData = localBundle;
            if (localBundle == null) {
              return null;
            }
          }
          else
          {
            Slog.w("PackageParser", "Unknown element under <activity-alias>: " + paramXmlPullParser.getName() + " at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
            XmlUtils.skipCurrentTag(paramXmlPullParser);
          }
        }
      }
    } while (bool1);
    ActivityInfo localActivityInfo2 = localActivity1.info;
    if (localActivity1.intents.size() > 0) {}
    for (boolean bool2 = true;; bool2 = false)
    {
      localActivityInfo2.exported = bool2;
      return localActivity1;
    }
  }
  
  private boolean parseAllMetaData(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, String paramString, Component paramComponent, String[] paramArrayOfString)
    throws XmlPullParserException, IOException
  {
    int i = paramXmlPullParser.getDepth();
    for (;;)
    {
      int j = paramXmlPullParser.next();
      if ((j == 1) || ((j == 3) && (paramXmlPullParser.getDepth() <= i))) {
        break;
      }
      if ((j != 3) && (j != 4)) {
        if (paramXmlPullParser.getName().equals("meta-data"))
        {
          Bundle localBundle = parseMetaData(paramResources, paramXmlPullParser, paramAttributeSet, paramComponent.metaData, paramArrayOfString);
          paramComponent.metaData = localBundle;
          if (localBundle == null) {
            return false;
          }
        }
        else
        {
          Slog.w("PackageParser", "Unknown element under " + paramString + ": " + paramXmlPullParser.getName() + " at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
          XmlUtils.skipCurrentTag(paramXmlPullParser);
        }
      }
    }
    return true;
  }
  
  private boolean parseApplication(Package paramPackage, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, int paramInt, String[] paramArrayOfString)
    throws XmlPullParserException, IOException
  {
    ApplicationInfo localApplicationInfo = paramPackage.applicationInfo;
    String str1 = paramPackage.applicationInfo.packageName;
    TypedArray localTypedArray1 = paramResources.obtainAttributes(paramAttributeSet, R.styleable.AndroidManifestApplication);
    String str2 = localTypedArray1.getNonConfigurationString(3, 0);
    if (str2 != null)
    {
      localApplicationInfo.className = buildClassName(str1, str2, paramArrayOfString);
      if (localApplicationInfo.className == null)
      {
        localTypedArray1.recycle();
        this.mParseError = -108;
        return false;
      }
    }
    String str3 = localTypedArray1.getNonConfigurationString(4, 0);
    if (str3 != null) {
      localApplicationInfo.manageSpaceActivityName = buildClassName(str1, str3, paramArrayOfString);
    }
    if (localTypedArray1.getBoolean(17, true))
    {
      localApplicationInfo.flags = (0x8000 | localApplicationInfo.flags);
      String str10 = localTypedArray1.getNonConfigurationString(16, 0);
      if (str10 != null)
      {
        localApplicationInfo.backupAgentName = buildClassName(str1, str10, paramArrayOfString);
        if (localTypedArray1.getBoolean(18, true)) {
          localApplicationInfo.flags = (0x10000 | localApplicationInfo.flags);
        }
        if (localTypedArray1.getBoolean(21, false)) {
          localApplicationInfo.flags = (0x20000 | localApplicationInfo.flags);
        }
      }
    }
    TypedValue localTypedValue = localTypedArray1.peekValue(1);
    if (localTypedValue != null)
    {
      int k = localTypedValue.resourceId;
      localApplicationInfo.labelRes = k;
      if (k == 0) {
        localApplicationInfo.nonLocalizedLabel = localTypedValue.coerceToString();
      }
    }
    localApplicationInfo.icon = localTypedArray1.getResourceId(2, 0);
    localApplicationInfo.logo = localTypedArray1.getResourceId(22, 0);
    localApplicationInfo.theme = localTypedArray1.getResourceId(0, 0);
    localApplicationInfo.descriptionRes = localTypedArray1.getResourceId(13, 0);
    if (((paramInt & 0x1) != 0) && (localTypedArray1.getBoolean(8, false))) {
      localApplicationInfo.flags = (0x8 | localApplicationInfo.flags);
    }
    if (localTypedArray1.getBoolean(10, false)) {
      localApplicationInfo.flags = (0x2 | localApplicationInfo.flags);
    }
    if (localTypedArray1.getBoolean(20, false)) {
      localApplicationInfo.flags = (0x4000 | localApplicationInfo.flags);
    }
    boolean bool1;
    boolean bool2;
    String str5;
    label579:
    String str6;
    if (paramPackage.applicationInfo.targetSdkVersion >= 14)
    {
      bool1 = true;
      bool2 = localTypedArray1.getBoolean(23, bool1);
      if (localTypedArray1.getBoolean(7, true)) {
        localApplicationInfo.flags = (0x4 | localApplicationInfo.flags);
      }
      if (localTypedArray1.getBoolean(14, false)) {
        localApplicationInfo.flags = (0x20 | localApplicationInfo.flags);
      }
      if (localTypedArray1.getBoolean(5, true)) {
        localApplicationInfo.flags = (0x40 | localApplicationInfo.flags);
      }
      if (localTypedArray1.getBoolean(15, false)) {
        localApplicationInfo.flags = (0x100 | localApplicationInfo.flags);
      }
      if (localTypedArray1.getBoolean(24, false)) {
        localApplicationInfo.flags = (0x100000 | localApplicationInfo.flags);
      }
      if (localTypedArray1.getBoolean(26, false)) {
        localApplicationInfo.flags = (0x400000 | localApplicationInfo.flags);
      }
      String str4 = localTypedArray1.getNonConfigurationString(6, 0);
      if ((str4 == null) || (str4.length() <= 0)) {
        break label735;
      }
      str5 = str4.intern();
      localApplicationInfo.permission = str5;
      if (paramPackage.applicationInfo.targetSdkVersion < 8) {
        break label741;
      }
      str6 = localTypedArray1.getNonConfigurationString(12, 0);
      label608:
      localApplicationInfo.taskAffinity = buildTaskAffinityName(localApplicationInfo.packageName, localApplicationInfo.packageName, str6, paramArrayOfString);
      if (paramArrayOfString[0] == null) {
        if (paramPackage.applicationInfo.targetSdkVersion < 8) {
          break label753;
        }
      }
    }
    label735:
    label741:
    label753:
    for (String str9 = localTypedArray1.getNonConfigurationString(11, 0);; str9 = localTypedArray1.getNonResourceString(11))
    {
      localApplicationInfo.processName = buildProcessName(localApplicationInfo.packageName, null, str9, paramInt, this.mSeparateProcesses, paramArrayOfString);
      localApplicationInfo.enabled = localTypedArray1.getBoolean(9, true);
      localApplicationInfo.uiOptions = localTypedArray1.getInt(25, 0);
      localTypedArray1.recycle();
      if (paramArrayOfString[0] == null) {
        break label765;
      }
      this.mParseError = -108;
      return false;
      bool1 = false;
      break;
      str5 = null;
      break label579;
      str6 = localTypedArray1.getNonResourceString(12);
      break label608;
    }
    label765:
    int i = paramXmlPullParser.getDepth();
    for (;;)
    {
      int j = paramXmlPullParser.next();
      if ((j == 1) || ((j == 3) && (paramXmlPullParser.getDepth() <= i))) {
        break;
      }
      if ((j != 3) && (j != 4))
      {
        String str7 = paramXmlPullParser.getName();
        if (str7.equals("activity"))
        {
          Activity localActivity3 = parseActivity(paramPackage, paramResources, paramXmlPullParser, paramAttributeSet, paramInt, paramArrayOfString, false, bool2);
          if (localActivity3 == null)
          {
            this.mParseError = -108;
            return false;
          }
          paramPackage.activities.add(localActivity3);
        }
        else if (str7.equals("receiver"))
        {
          Activity localActivity2 = parseActivity(paramPackage, paramResources, paramXmlPullParser, paramAttributeSet, paramInt, paramArrayOfString, true, false);
          if (localActivity2 == null)
          {
            this.mParseError = -108;
            return false;
          }
          paramPackage.receivers.add(localActivity2);
        }
        else if (str7.equals("service"))
        {
          Service localService = parseService(paramPackage, paramResources, paramXmlPullParser, paramAttributeSet, paramInt, paramArrayOfString);
          if (localService == null)
          {
            this.mParseError = -108;
            return false;
          }
          paramPackage.services.add(localService);
        }
        else if (str7.equals("provider"))
        {
          Provider localProvider = parseProvider(paramPackage, paramResources, paramXmlPullParser, paramAttributeSet, paramInt, paramArrayOfString);
          if (localProvider == null)
          {
            this.mParseError = -108;
            return false;
          }
          paramPackage.providers.add(localProvider);
        }
        else if (str7.equals("activity-alias"))
        {
          Activity localActivity1 = parseActivityAlias(paramPackage, paramResources, paramXmlPullParser, paramAttributeSet, paramInt, paramArrayOfString);
          if (localActivity1 == null)
          {
            this.mParseError = -108;
            return false;
          }
          paramPackage.activities.add(localActivity1);
        }
        else if (paramXmlPullParser.getName().equals("meta-data"))
        {
          Bundle localBundle = parseMetaData(paramResources, paramXmlPullParser, paramAttributeSet, paramPackage.mAppMetaData, paramArrayOfString);
          paramPackage.mAppMetaData = localBundle;
          if (localBundle == null)
          {
            this.mParseError = -108;
            return false;
          }
        }
        else
        {
          if (str7.equals("uses-library"))
          {
            TypedArray localTypedArray2 = paramResources.obtainAttributes(paramAttributeSet, R.styleable.AndroidManifestUsesLibrary);
            String str8 = localTypedArray2.getNonResourceString(0);
            boolean bool3 = localTypedArray2.getBoolean(1, true);
            localTypedArray2.recycle();
            if (str8 != null)
            {
              if (!bool3) {
                break label1243;
              }
              if (paramPackage.usesLibraries == null) {
                paramPackage.usesLibraries = new ArrayList();
              }
              if (!paramPackage.usesLibraries.contains(str8)) {
                paramPackage.usesLibraries.add(str8.intern());
              }
            }
            for (;;)
            {
              XmlUtils.skipCurrentTag(paramXmlPullParser);
              break;
              label1243:
              if (paramPackage.usesOptionalLibraries == null) {
                paramPackage.usesOptionalLibraries = new ArrayList();
              }
              if (!paramPackage.usesOptionalLibraries.contains(str8)) {
                paramPackage.usesOptionalLibraries.add(str8.intern());
              }
            }
          }
          if (str7.equals("uses-package"))
          {
            XmlUtils.skipCurrentTag(paramXmlPullParser);
          }
          else
          {
            Slog.w("PackageParser", "Unknown element under <application>: " + str7 + " at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
            XmlUtils.skipCurrentTag(paramXmlPullParser);
          }
        }
      }
    }
    return true;
  }
  
  private Instrumentation parseInstrumentation(Package paramPackage, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, String[] paramArrayOfString)
    throws XmlPullParserException, IOException
  {
    TypedArray localTypedArray = paramResources.obtainAttributes(paramAttributeSet, R.styleable.AndroidManifestInstrumentation);
    if (this.mParseInstrumentationArgs == null)
    {
      this.mParseInstrumentationArgs = new ParsePackageItemArgs(paramPackage, paramArrayOfString, 2, 0, 1, 6);
      this.mParseInstrumentationArgs.tag = "<instrumentation>";
    }
    this.mParseInstrumentationArgs.sa = localTypedArray;
    Instrumentation localInstrumentation = new Instrumentation(this.mParseInstrumentationArgs, new InstrumentationInfo());
    if (paramArrayOfString[0] != null)
    {
      localTypedArray.recycle();
      this.mParseError = -108;
      return null;
    }
    String str1 = localTypedArray.getNonResourceString(3);
    InstrumentationInfo localInstrumentationInfo = localInstrumentation.info;
    if (str1 != null) {}
    for (String str2 = str1.intern();; str2 = null)
    {
      localInstrumentationInfo.targetPackage = str2;
      localInstrumentation.info.handleProfiling = localTypedArray.getBoolean(4, false);
      localInstrumentation.info.functionalTest = localTypedArray.getBoolean(5, false);
      localTypedArray.recycle();
      if (localInstrumentation.info.targetPackage != null) {
        break;
      }
      paramArrayOfString[0] = "<instrumentation> does not specify targetPackage";
      this.mParseError = -108;
      return null;
    }
    if (!parseAllMetaData(paramResources, paramXmlPullParser, paramAttributeSet, "<instrumentation>", localInstrumentation, paramArrayOfString))
    {
      this.mParseError = -108;
      return null;
    }
    paramPackage.instrumentation.add(localInstrumentation);
    return localInstrumentation;
  }
  
  private boolean parseIntent(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, int paramInt, IntentInfo paramIntentInfo, String[] paramArrayOfString, boolean paramBoolean)
    throws XmlPullParserException, IOException
  {
    TypedArray localTypedArray1 = paramResources.obtainAttributes(paramAttributeSet, R.styleable.AndroidManifestIntentFilter);
    paramIntentInfo.setPriority(localTypedArray1.getInt(2, 0));
    TypedValue localTypedValue = localTypedArray1.peekValue(0);
    if (localTypedValue != null)
    {
      int k = localTypedValue.resourceId;
      paramIntentInfo.labelRes = k;
      if (k == 0) {
        paramIntentInfo.nonLocalizedLabel = localTypedValue.coerceToString();
      }
    }
    paramIntentInfo.icon = localTypedArray1.getResourceId(1, 0);
    paramIntentInfo.logo = localTypedArray1.getResourceId(3, 0);
    localTypedArray1.recycle();
    int i = paramXmlPullParser.getDepth();
    for (;;)
    {
      int j = paramXmlPullParser.next();
      if ((j == 1) || ((j == 3) && (paramXmlPullParser.getDepth() <= i))) {
        break;
      }
      if ((j != 3) && (j != 4))
      {
        String str1 = paramXmlPullParser.getName();
        if (str1.equals("action"))
        {
          String str10 = paramAttributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "name");
          if ((str10 == null) || (str10 == ""))
          {
            paramArrayOfString[0] = "No value supplied for <android:name>";
            return false;
          }
          XmlUtils.skipCurrentTag(paramXmlPullParser);
          paramIntentInfo.addAction(str10);
        }
        else if (str1.equals("category"))
        {
          String str9 = paramAttributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "name");
          if ((str9 == null) || (str9 == ""))
          {
            paramArrayOfString[0] = "No value supplied for <android:name>";
            return false;
          }
          XmlUtils.skipCurrentTag(paramXmlPullParser);
          paramIntentInfo.addCategory(str9);
        }
        else if (str1.equals("data"))
        {
          TypedArray localTypedArray2 = paramResources.obtainAttributes(paramAttributeSet, R.styleable.AndroidManifestData);
          String str2 = localTypedArray2.getNonConfigurationString(0, 0);
          if (str2 != null) {}
          try
          {
            paramIntentInfo.addDataType(str2);
            String str3 = localTypedArray2.getNonConfigurationString(1, 0);
            if (str3 != null) {
              paramIntentInfo.addDataScheme(str3);
            }
            String str4 = localTypedArray2.getNonConfigurationString(2, 0);
            String str5 = localTypedArray2.getNonConfigurationString(3, 0);
            if (str4 != null) {
              paramIntentInfo.addDataAuthority(str4, str5);
            }
            String str6 = localTypedArray2.getNonConfigurationString(4, 0);
            if (str6 != null) {
              paramIntentInfo.addDataPath(str6, 0);
            }
            String str7 = localTypedArray2.getNonConfigurationString(5, 0);
            if (str7 != null) {
              paramIntentInfo.addDataPath(str7, 1);
            }
            String str8 = localTypedArray2.getNonConfigurationString(6, 0);
            if (str8 != null) {
              paramIntentInfo.addDataPath(str8, 2);
            }
            localTypedArray2.recycle();
            XmlUtils.skipCurrentTag(paramXmlPullParser);
          }
          catch (IntentFilter.MalformedMimeTypeException localMalformedMimeTypeException)
          {
            paramArrayOfString[0] = localMalformedMimeTypeException.toString();
            localTypedArray2.recycle();
            return false;
          }
        }
        else
        {
          Slog.w("PackageParser", "Unknown element under <intent-filter>: " + paramXmlPullParser.getName() + " at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
          XmlUtils.skipCurrentTag(paramXmlPullParser);
        }
      }
    }
    paramIntentInfo.hasDefault = paramIntentInfo.hasCategory("android.intent.category.DEFAULT");
    return true;
  }
  
  private Bundle parseMetaData(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Bundle paramBundle, String[] paramArrayOfString)
    throws XmlPullParserException, IOException
  {
    TypedArray localTypedArray = paramResources.obtainAttributes(paramAttributeSet, R.styleable.AndroidManifestMetaData);
    if (paramBundle == null) {
      paramBundle = new Bundle();
    }
    String str1 = localTypedArray.getNonConfigurationString(0, 0);
    if (str1 == null)
    {
      paramArrayOfString[0] = "<meta-data> requires an android:name attribute";
      localTypedArray.recycle();
      return null;
    }
    String str2 = str1.intern();
    TypedValue localTypedValue1 = localTypedArray.peekValue(2);
    if ((localTypedValue1 != null) && (localTypedValue1.resourceId != 0)) {
      paramBundle.putInt(str2, localTypedValue1.resourceId);
    }
    for (;;)
    {
      localTypedArray.recycle();
      XmlUtils.skipCurrentTag(paramXmlPullParser);
      return paramBundle;
      TypedValue localTypedValue2 = localTypedArray.peekValue(1);
      if (localTypedValue2 != null)
      {
        if (localTypedValue2.type == 3)
        {
          CharSequence localCharSequence = localTypedValue2.coerceToString();
          String str3 = null;
          if (localCharSequence != null) {
            str3 = localCharSequence.toString().intern();
          }
          paramBundle.putString(str2, str3);
        }
        else
        {
          if (localTypedValue2.type == 18)
          {
            if (localTypedValue2.data != 0) {}
            for (boolean bool = true;; bool = false)
            {
              paramBundle.putBoolean(str2, bool);
              break;
            }
          }
          if ((localTypedValue2.type >= 16) && (localTypedValue2.type <= 31)) {
            paramBundle.putInt(str2, localTypedValue2.data);
          } else if (localTypedValue2.type == 4) {
            paramBundle.putFloat(str2, localTypedValue2.getFloat());
          } else {
            Slog.w("PackageParser", "<meta-data> only supports string, integer, float, color, boolean, and resource reference types: " + paramXmlPullParser.getName() + " at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
          }
        }
      }
      else
      {
        paramArrayOfString[0] = "<meta-data> requires an android:value or android:resource attribute";
        paramBundle = null;
      }
    }
  }
  
  private Package parsePackage(Resources paramResources, XmlResourceParser paramXmlResourceParser, int paramInt, String[] paramArrayOfString)
    throws XmlPullParserException, IOException
  {
    this.mParseInstrumentationArgs = null;
    this.mParseActivityArgs = null;
    this.mParseServiceArgs = null;
    this.mParseProviderArgs = null;
    String str1 = parsePackageName(paramXmlResourceParser, paramXmlResourceParser, paramInt, paramArrayOfString);
    Package localPackage;
    if (str1 == null)
    {
      this.mParseError = -106;
      localPackage = null;
    }
    int i2;
    label1062:
    label1164:
    label1174:
    label1208:
    label1271:
    label1400:
    label2228:
    label2309:
    do
    {
      return localPackage;
      if ((this.mOnlyCoreApps) && (!paramXmlResourceParser.getAttributeBooleanValue(null, "coreApp", false)))
      {
        this.mParseError = 1;
        return null;
      }
      localPackage = new Package(str1);
      int i = 0;
      TypedArray localTypedArray1 = paramResources.obtainAttributes(paramXmlResourceParser, R.styleable.AndroidManifest);
      localPackage.mVersionCode = localTypedArray1.getInteger(1, 0);
      localPackage.mVersionName = localTypedArray1.getNonConfigurationString(2, 0);
      if (localPackage.mVersionName != null) {
        localPackage.mVersionName = localPackage.mVersionName.intern();
      }
      String str2 = localTypedArray1.getNonConfigurationString(0, 0);
      if ((str2 != null) && (str2.length() > 0))
      {
        String str15 = validateName(str2, true);
        if ((str15 != null) && (!"android".equals(str1)))
        {
          paramArrayOfString[0] = ("<manifest> specifies bad sharedUserId name \"" + str2 + "\": " + str15);
          this.mParseError = -107;
          return null;
        }
        localPackage.mSharedUserId = str2.intern();
        localPackage.mSharedUserLabel = localTypedArray1.getResourceId(3, 0);
      }
      localTypedArray1.recycle();
      localPackage.installLocation = localTypedArray1.getInteger(4, -1);
      localPackage.applicationInfo.installLocation = localPackage.installLocation;
      if ((paramInt & 0x10) != 0)
      {
        ApplicationInfo localApplicationInfo8 = localPackage.applicationInfo;
        localApplicationInfo8.flags = (0x20000000 | localApplicationInfo8.flags);
      }
      if ((paramInt & 0x20) != 0)
      {
        ApplicationInfo localApplicationInfo7 = localPackage.applicationInfo;
        localApplicationInfo7.flags = (0x40000 | localApplicationInfo7.flags);
      }
      int j = 1;
      int k = 1;
      int m = 1;
      int n = 1;
      int i1 = 1;
      i2 = 1;
      int i3 = paramXmlResourceParser.getDepth();
      for (;;)
      {
        int i4 = paramXmlResourceParser.next();
        if ((i4 == 1) || ((i4 == 3) && (paramXmlResourceParser.getDepth() <= i3))) {
          break;
        }
        if ((i4 != 3) && (i4 != 4))
        {
          String str6 = paramXmlResourceParser.getName();
          if (str6.equals("application"))
          {
            if (i != 0)
            {
              Slog.w("PackageParser", "<manifest> has more than one <application>");
              XmlUtils.skipCurrentTag(paramXmlResourceParser);
            }
            else
            {
              i = 1;
              if (!parseApplication(localPackage, paramResources, paramXmlResourceParser, paramXmlResourceParser, paramInt, paramArrayOfString)) {
                return null;
              }
            }
          }
          else if (str6.equals("permission-group"))
          {
            if (parsePermissionGroup(localPackage, paramInt, paramResources, paramXmlResourceParser, paramXmlResourceParser, paramArrayOfString) == null) {
              return null;
            }
          }
          else if (str6.equals("permission"))
          {
            if (parsePermission(localPackage, paramResources, paramXmlResourceParser, paramXmlResourceParser, paramArrayOfString) == null) {
              return null;
            }
          }
          else if (str6.equals("permission-tree"))
          {
            if (parsePermissionTree(localPackage, paramResources, paramXmlResourceParser, paramXmlResourceParser, paramArrayOfString) == null) {
              return null;
            }
          }
          else if (str6.equals("uses-permission"))
          {
            TypedArray localTypedArray9 = paramResources.obtainAttributes(paramXmlResourceParser, R.styleable.AndroidManifestUsesPermission);
            String str14 = localTypedArray9.getNonResourceString(0);
            localTypedArray9.recycle();
            if ((str14 != null) && (!localPackage.requestedPermissions.contains(str14)))
            {
              localPackage.requestedPermissions.add(str14.intern());
              localPackage.requestedPermissionsRequired.add(Boolean.TRUE);
            }
            XmlUtils.skipCurrentTag(paramXmlResourceParser);
          }
          else if (str6.equals("uses-configuration"))
          {
            ConfigurationInfo localConfigurationInfo1 = new ConfigurationInfo();
            TypedArray localTypedArray2 = paramResources.obtainAttributes(paramXmlResourceParser, R.styleable.AndroidManifestUsesConfiguration);
            localConfigurationInfo1.reqTouchScreen = localTypedArray2.getInt(0, 0);
            localConfigurationInfo1.reqKeyboardType = localTypedArray2.getInt(1, 0);
            if (localTypedArray2.getBoolean(2, false)) {
              localConfigurationInfo1.reqInputFeatures = (0x1 | localConfigurationInfo1.reqInputFeatures);
            }
            localConfigurationInfo1.reqNavigation = localTypedArray2.getInt(3, 0);
            if (localTypedArray2.getBoolean(4, false)) {
              localConfigurationInfo1.reqInputFeatures = (0x2 | localConfigurationInfo1.reqInputFeatures);
            }
            localTypedArray2.recycle();
            localPackage.configPreferences.add(localConfigurationInfo1);
            XmlUtils.skipCurrentTag(paramXmlResourceParser);
          }
          else if (str6.equals("uses-feature"))
          {
            FeatureInfo localFeatureInfo = new FeatureInfo();
            TypedArray localTypedArray3 = paramResources.obtainAttributes(paramXmlResourceParser, R.styleable.AndroidManifestUsesFeature);
            localFeatureInfo.name = localTypedArray3.getNonResourceString(0);
            if (localFeatureInfo.name == null) {
              localFeatureInfo.reqGlEsVersion = localTypedArray3.getInt(1, 0);
            }
            if (localTypedArray3.getBoolean(2, true)) {
              localFeatureInfo.flags = (0x1 | localFeatureInfo.flags);
            }
            localTypedArray3.recycle();
            if (localPackage.reqFeatures == null) {
              localPackage.reqFeatures = new ArrayList();
            }
            localPackage.reqFeatures.add(localFeatureInfo);
            if (localFeatureInfo.name == null)
            {
              ConfigurationInfo localConfigurationInfo2 = new ConfigurationInfo();
              localConfigurationInfo2.reqGlEsVersion = localFeatureInfo.reqGlEsVersion;
              localPackage.configPreferences.add(localConfigurationInfo2);
            }
            XmlUtils.skipCurrentTag(paramXmlResourceParser);
          }
          else
          {
            if (str6.equals("uses-sdk"))
            {
              int i12;
              if (SDK_VERSION > 0)
              {
                TypedArray localTypedArray8 = paramResources.obtainAttributes(paramXmlResourceParser, R.styleable.AndroidManifestUsesSdk);
                TypedValue localTypedValue1 = localTypedArray8.peekValue(0);
                String str10 = null;
                int i11 = 0;
                String str11 = null;
                i12 = 0;
                TypedValue localTypedValue2;
                if (localTypedValue1 != null)
                {
                  if ((localTypedValue1.type == 3) && (localTypedValue1.string != null))
                  {
                    str10 = localTypedValue1.string.toString();
                    str11 = str10;
                  }
                }
                else
                {
                  localTypedValue2 = localTypedArray8.peekValue(1);
                  if (localTypedValue2 != null)
                  {
                    if ((localTypedValue2.type != 3) || (localTypedValue2.string == null)) {
                      break label1164;
                    }
                    str10 = localTypedValue2.string.toString();
                    str11 = str10;
                  }
                  localTypedArray8.recycle();
                  if (str10 == null) {
                    break label1208;
                  }
                  String str13 = SDK_CODENAME;
                  if (str10.equals(str13)) {
                    break label1271;
                  }
                  if (SDK_CODENAME == null) {
                    break label1174;
                  }
                  paramArrayOfString[0] = ("Requires development platform " + str10 + " (current platform is " + SDK_CODENAME + ")");
                }
                for (;;)
                {
                  this.mParseError = -12;
                  return null;
                  i11 = localTypedValue1.data;
                  i12 = i11;
                  str10 = null;
                  str11 = null;
                  break;
                  i12 = localTypedValue2.data;
                  break label1062;
                  paramArrayOfString[0] = ("Requires development platform " + str10 + " but this is a release platform.");
                }
                int i13 = SDK_VERSION;
                if (i11 > i13)
                {
                  paramArrayOfString[0] = ("Requires newer sdk version #" + i11 + " (current version is #" + SDK_VERSION + ")");
                  this.mParseError = -12;
                  return null;
                }
                if (str11 == null) {
                  break label1400;
                }
                String str12 = SDK_CODENAME;
                if (!str11.equals(str12))
                {
                  if (SDK_CODENAME != null) {
                    paramArrayOfString[0] = ("Requires development platform " + str11 + " (current platform is " + SDK_CODENAME + ")");
                  }
                  for (;;)
                  {
                    this.mParseError = -12;
                    return null;
                    paramArrayOfString[0] = ("Requires development platform " + str11 + " but this is a release platform.");
                  }
                }
              }
              for (localPackage.applicationInfo.targetSdkVersion = 10000;; localPackage.applicationInfo.targetSdkVersion = i12)
              {
                XmlUtils.skipCurrentTag(paramXmlResourceParser);
                break;
              }
            }
            if (str6.equals("supports-screens"))
            {
              TypedArray localTypedArray7 = paramResources.obtainAttributes(paramXmlResourceParser, R.styleable.AndroidManifestSupportsScreens);
              localPackage.applicationInfo.requiresSmallestWidthDp = localTypedArray7.getInteger(6, 0);
              localPackage.applicationInfo.compatibleWidthLimitDp = localTypedArray7.getInteger(7, 0);
              localPackage.applicationInfo.largestWidthLimitDp = localTypedArray7.getInteger(8, 0);
              j = localTypedArray7.getInteger(1, j);
              k = localTypedArray7.getInteger(2, k);
              m = localTypedArray7.getInteger(3, m);
              n = localTypedArray7.getInteger(5, n);
              i1 = localTypedArray7.getInteger(4, i1);
              i2 = localTypedArray7.getInteger(0, i2);
              localTypedArray7.recycle();
              XmlUtils.skipCurrentTag(paramXmlResourceParser);
            }
            else if (str6.equals("protected-broadcast"))
            {
              TypedArray localTypedArray6 = paramResources.obtainAttributes(paramXmlResourceParser, R.styleable.AndroidManifestProtectedBroadcast);
              String str9 = localTypedArray6.getNonResourceString(0);
              localTypedArray6.recycle();
              if ((str9 != null) && ((paramInt & 0x1) != 0))
              {
                if (localPackage.protectedBroadcasts == null) {
                  localPackage.protectedBroadcasts = new ArrayList();
                }
                if (!localPackage.protectedBroadcasts.contains(str9)) {
                  localPackage.protectedBroadcasts.add(str9.intern());
                }
              }
              XmlUtils.skipCurrentTag(paramXmlResourceParser);
            }
            else if (str6.equals("instrumentation"))
            {
              if (parseInstrumentation(localPackage, paramResources, paramXmlResourceParser, paramXmlResourceParser, paramArrayOfString) == null) {
                return null;
              }
            }
            else if (str6.equals("original-package"))
            {
              TypedArray localTypedArray5 = paramResources.obtainAttributes(paramXmlResourceParser, R.styleable.AndroidManifestOriginalPackage);
              String str8 = localTypedArray5.getNonConfigurationString(0, 0);
              if (!localPackage.packageName.equals(str8))
              {
                if (localPackage.mOriginalPackages == null)
                {
                  localPackage.mOriginalPackages = new ArrayList();
                  localPackage.mRealPackage = localPackage.packageName;
                }
                localPackage.mOriginalPackages.add(str8);
              }
              localTypedArray5.recycle();
              XmlUtils.skipCurrentTag(paramXmlResourceParser);
            }
            else if (str6.equals("adopt-permissions"))
            {
              TypedArray localTypedArray4 = paramResources.obtainAttributes(paramXmlResourceParser, R.styleable.AndroidManifestOriginalPackage);
              String str7 = localTypedArray4.getNonConfigurationString(0, 0);
              localTypedArray4.recycle();
              if (str7 != null)
              {
                if (localPackage.mAdoptPermissions == null) {
                  localPackage.mAdoptPermissions = new ArrayList();
                }
                localPackage.mAdoptPermissions.add(str7);
              }
              XmlUtils.skipCurrentTag(paramXmlResourceParser);
            }
            else if (str6.equals("uses-gl-texture"))
            {
              XmlUtils.skipCurrentTag(paramXmlResourceParser);
            }
            else if (str6.equals("compatible-screens"))
            {
              XmlUtils.skipCurrentTag(paramXmlResourceParser);
            }
            else if (str6.equals("eat-comment"))
            {
              XmlUtils.skipCurrentTag(paramXmlResourceParser);
            }
            else
            {
              Slog.w("PackageParser", "Unknown element under <manifest>: " + paramXmlResourceParser.getName() + " at " + this.mArchiveSourcePath + " " + paramXmlResourceParser.getPositionDescription());
              XmlUtils.skipCurrentTag(paramXmlResourceParser);
            }
          }
        }
      }
      if ((i == 0) && (localPackage.instrumentation.size() == 0))
      {
        paramArrayOfString[0] = "<manifest> does not contain an <application> or <instrumentation>";
        this.mParseError = -109;
      }
      int i5 = NEW_PERMISSIONS.length;
      StringBuilder localStringBuilder = null;
      int i6 = 0;
      NewPermissionInfo localNewPermissionInfo;
      SplitPermissionInfo localSplitPermissionInfo;
      if (i6 < i5)
      {
        localNewPermissionInfo = NEW_PERMISSIONS[i6];
        if (localPackage.applicationInfo.targetSdkVersion < localNewPermissionInfo.sdkVersion) {}
      }
      else
      {
        if (localStringBuilder != null) {
          Slog.i("PackageParser", localStringBuilder.toString());
        }
        int i7 = SPLIT_PERMISSIONS.length;
        for (int i8 = 0;; i8++)
        {
          if (i8 >= i7) {
            break label2309;
          }
          localSplitPermissionInfo = SPLIT_PERMISSIONS[i8];
          if ((localPackage.applicationInfo.targetSdkVersion < localSplitPermissionInfo.targetSdk) && (localPackage.requestedPermissions.contains(localSplitPermissionInfo.rootPerm))) {
            break;
          }
        }
      }
      if (!localPackage.requestedPermissions.contains(localNewPermissionInfo.name))
      {
        if (localStringBuilder != null) {
          break label2228;
        }
        localStringBuilder = new StringBuilder(128);
        String str4 = localPackage.packageName;
        localStringBuilder.append(str4);
        localStringBuilder.append(": compat added ");
      }
      for (;;)
      {
        String str5 = localNewPermissionInfo.name;
        localStringBuilder.append(str5);
        localPackage.requestedPermissions.add(localNewPermissionInfo.name);
        localPackage.requestedPermissionsRequired.add(Boolean.TRUE);
        i6++;
        break;
        localStringBuilder.append(' ');
      }
      for (int i9 = 0;; i9++)
      {
        int i10 = localSplitPermissionInfo.newPerms.length;
        if (i9 >= i10) {
          break;
        }
        String str3 = localSplitPermissionInfo.newPerms[i9];
        if (!localPackage.requestedPermissions.contains(str3))
        {
          localPackage.requestedPermissions.add(str3);
          localPackage.requestedPermissionsRequired.add(Boolean.TRUE);
        }
      }
      if ((j < 0) || ((j > 0) && (localPackage.applicationInfo.targetSdkVersion >= 4)))
      {
        ApplicationInfo localApplicationInfo1 = localPackage.applicationInfo;
        localApplicationInfo1.flags = (0x200 | localApplicationInfo1.flags);
      }
      if (k != 0)
      {
        ApplicationInfo localApplicationInfo6 = localPackage.applicationInfo;
        localApplicationInfo6.flags = (0x400 | localApplicationInfo6.flags);
      }
      if ((m < 0) || ((m > 0) && (localPackage.applicationInfo.targetSdkVersion >= 4)))
      {
        ApplicationInfo localApplicationInfo2 = localPackage.applicationInfo;
        localApplicationInfo2.flags = (0x800 | localApplicationInfo2.flags);
      }
      if ((n < 0) || ((n > 0) && (localPackage.applicationInfo.targetSdkVersion >= 9)))
      {
        ApplicationInfo localApplicationInfo3 = localPackage.applicationInfo;
        localApplicationInfo3.flags = (0x80000 | localApplicationInfo3.flags);
      }
      if ((i1 < 0) || ((i1 > 0) && (localPackage.applicationInfo.targetSdkVersion >= 4)))
      {
        ApplicationInfo localApplicationInfo4 = localPackage.applicationInfo;
        localApplicationInfo4.flags = (0x1000 | localApplicationInfo4.flags);
      }
    } while ((i2 >= 0) && ((i2 <= 0) || (localPackage.applicationInfo.targetSdkVersion < 4)));
    ApplicationInfo localApplicationInfo5 = localPackage.applicationInfo;
    localApplicationInfo5.flags = (0x2000 | localApplicationInfo5.flags);
    return localPackage;
  }
  
  private boolean parsePackageItemInfo(Package paramPackage, PackageItemInfo paramPackageItemInfo, String[] paramArrayOfString, String paramString, TypedArray paramTypedArray, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    String str = paramTypedArray.getNonConfigurationString(paramInt1, 0);
    if (str == null)
    {
      paramArrayOfString[0] = (paramString + " does not specify android:name");
      return false;
    }
    paramPackageItemInfo.name = buildClassName(paramPackage.applicationInfo.packageName, str, paramArrayOfString);
    if (paramPackageItemInfo.name == null) {
      return false;
    }
    int i = paramTypedArray.getResourceId(paramInt3, 0);
    if (i != 0)
    {
      paramPackageItemInfo.icon = i;
      paramPackageItemInfo.nonLocalizedLabel = null;
    }
    int j = paramTypedArray.getResourceId(paramInt4, 0);
    if (j != 0) {
      paramPackageItemInfo.logo = j;
    }
    TypedValue localTypedValue = paramTypedArray.peekValue(paramInt2);
    if (localTypedValue != null)
    {
      int k = localTypedValue.resourceId;
      paramPackageItemInfo.labelRes = k;
      if (k == 0) {
        paramPackageItemInfo.nonLocalizedLabel = localTypedValue.coerceToString();
      }
    }
    paramPackageItemInfo.packageName = paramPackage.packageName;
    return true;
  }
  
  private static PackageLite parsePackageLite(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, int paramInt, String[] paramArrayOfString)
    throws IOException, XmlPullParserException
  {
    int i;
    do
    {
      i = paramXmlPullParser.next();
    } while ((i != 2) && (i != 1));
    if (i != 2)
    {
      paramArrayOfString[0] = "No start tag found";
      return null;
    }
    if (!paramXmlPullParser.getName().equals("manifest"))
    {
      paramArrayOfString[0] = "No <manifest> tag";
      return null;
    }
    String str1 = paramAttributeSet.getAttributeValue(null, "package");
    if ((str1 == null) || (str1.length() == 0))
    {
      paramArrayOfString[0] = "<manifest> does not specify package";
      return null;
    }
    String str2 = validateName(str1, true);
    if ((str2 != null) && (!"android".equals(str1)))
    {
      paramArrayOfString[0] = ("<manifest> specifies bad package name \"" + str1 + "\": " + str2);
      return null;
    }
    int j = -1;
    int k = 0;
    int m = 0;
    ArrayList localArrayList;
    for (int n = 0;; n++)
    {
      String str3;
      if (n < paramAttributeSet.getAttributeCount())
      {
        str3 = paramAttributeSet.getAttributeName(n);
        if (!str3.equals("installLocation")) {
          break label336;
        }
        j = paramAttributeSet.getAttributeIntValue(n, -1);
        m++;
      }
      while (m >= 2)
      {
        int i1 = 1 + paramXmlPullParser.getDepth();
        localArrayList = new ArrayList();
        for (;;)
        {
          int i2 = paramXmlPullParser.next();
          if ((i2 == 1) || ((i2 == 3) && (paramXmlPullParser.getDepth() < i1))) {
            break;
          }
          if ((i2 != 3) && (i2 != 4) && (paramXmlPullParser.getDepth() == i1) && ("package-verifier".equals(paramXmlPullParser.getName())))
          {
            VerifierInfo localVerifierInfo = parseVerifier(paramResources, paramXmlPullParser, paramAttributeSet, paramInt, paramArrayOfString);
            if (localVerifierInfo != null) {
              localArrayList.add(localVerifierInfo);
            }
          }
        }
        label336:
        if (str3.equals("versionCode"))
        {
          k = paramAttributeSet.getAttributeIntValue(n, 0);
          m++;
        }
      }
    }
    return new PackageLite(str1.intern(), k, j, localArrayList);
  }
  
  public static PackageLite parsePackageLite(String paramString, int paramInt)
  {
    PackageLite localPackageLite1;
    for (;;)
    {
      AssetManager localAssetManager;
      XmlResourceParser localXmlResourceParser;
      try
      {
        localAssetManager = new AssetManager();
      }
      catch (Exception localException1)
      {
        int i;
        DisplayMetrics localDisplayMetrics;
        Resources localResources;
        String[] arrayOfString;
        PackageLite localPackageLite2;
        label126:
        localAssetManager = null;
        label165:
        if (localAssetManager != null) {
          localAssetManager.close();
        }
        Slog.w("PackageParser", "Unable to read AndroidManifest.xml of " + paramString, localException1);
        return null;
      }
      for (;;)
      {
        try
        {
          localAssetManager.setConfiguration(0, 0, null, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Build.VERSION.RESOURCES_SDK_INT);
          i = localAssetManager.addAssetPath(paramString);
          if (i == 0) {
            return null;
          }
          localDisplayMetrics = new DisplayMetrics();
          localDisplayMetrics.setToDefaults();
          localResources = new Resources(localAssetManager, localDisplayMetrics, null);
          localXmlResourceParser = localAssetManager.openXmlResourceParser(i, "AndroidManifest.xml");
          arrayOfString = new String[1];
        }
        catch (Exception localException2)
        {
          break label165;
        }
        try
        {
          localPackageLite2 = parsePackageLite(localResources, localXmlResourceParser, localXmlResourceParser, paramInt, arrayOfString);
          localPackageLite1 = localPackageLite2;
        }
        catch (IOException localIOException)
        {
          Slog.w("PackageParser", paramString, localIOException);
          if (localXmlResourceParser == null) {
            continue;
          }
          localXmlResourceParser.close();
          localPackageLite1 = null;
          if (localAssetManager == null) {
            break label126;
          }
          localAssetManager.close();
          localPackageLite1 = null;
          break label126;
        }
        catch (XmlPullParserException localXmlPullParserException)
        {
          Slog.w("PackageParser", paramString, localXmlPullParserException);
          if (localXmlResourceParser == null) {
            continue;
          }
          localXmlResourceParser.close();
          localPackageLite1 = null;
          if (localAssetManager == null) {
            break label126;
          }
          localAssetManager.close();
          localPackageLite1 = null;
          break label126;
        }
        finally
        {
          if (localXmlResourceParser == null) {
            continue;
          }
          localXmlResourceParser.close();
          if (localAssetManager == null) {
            continue;
          }
          localAssetManager.close();
        }
      }
    }
    if (localPackageLite1 == null)
    {
      Slog.e("PackageParser", "parsePackageLite error: " + arrayOfString[0]);
      return null;
    }
    return localPackageLite1;
  }
  
  private static String parsePackageName(XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, int paramInt, String[] paramArrayOfString)
    throws IOException, XmlPullParserException
  {
    int i;
    do
    {
      i = paramXmlPullParser.next();
    } while ((i != 2) && (i != 1));
    if (i != 2)
    {
      paramArrayOfString[0] = "No start tag found";
      return null;
    }
    if (!paramXmlPullParser.getName().equals("manifest"))
    {
      paramArrayOfString[0] = "No <manifest> tag";
      return null;
    }
    String str1 = paramAttributeSet.getAttributeValue(null, "package");
    if ((str1 == null) || (str1.length() == 0))
    {
      paramArrayOfString[0] = "<manifest> does not specify package";
      return null;
    }
    String str2 = validateName(str1, true);
    if ((str2 != null) && (!"android".equals(str1)))
    {
      paramArrayOfString[0] = ("<manifest> specifies bad package name \"" + str1 + "\": " + str2);
      return null;
    }
    return str1.intern();
  }
  
  private Permission parsePermission(Package paramPackage, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, String[] paramArrayOfString)
    throws XmlPullParserException, IOException
  {
    Permission localPermission = new Permission(paramPackage);
    TypedArray localTypedArray = paramResources.obtainAttributes(paramAttributeSet, R.styleable.AndroidManifestPermission);
    if (!parsePackageItemInfo(paramPackage, localPermission.info, paramArrayOfString, "<permission>", localTypedArray, 2, 0, 1, 6))
    {
      localTypedArray.recycle();
      this.mParseError = -108;
      return null;
    }
    localPermission.info.group = localTypedArray.getNonResourceString(4);
    if (localPermission.info.group != null) {
      localPermission.info.group = localPermission.info.group.intern();
    }
    localPermission.info.descriptionRes = localTypedArray.getResourceId(5, 0);
    localPermission.info.protectionLevel = localTypedArray.getInt(3, 0);
    localPermission.info.flags = localTypedArray.getInt(7, 0);
    localTypedArray.recycle();
    if (localPermission.info.protectionLevel == -1)
    {
      paramArrayOfString[0] = "<permission> does not specify protectionLevel";
      this.mParseError = -108;
      return null;
    }
    localPermission.info.protectionLevel = PermissionInfo.fixProtectionLevel(localPermission.info.protectionLevel);
    if (((0xF0 & localPermission.info.protectionLevel) != 0) && ((0xF & localPermission.info.protectionLevel) != 2))
    {
      paramArrayOfString[0] = "<permission>  protectionLevel specifies a flag but is not based on signature type";
      this.mParseError = -108;
      return null;
    }
    if (!parseAllMetaData(paramResources, paramXmlPullParser, paramAttributeSet, "<permission>", localPermission, paramArrayOfString))
    {
      this.mParseError = -108;
      return null;
    }
    paramPackage.permissions.add(localPermission);
    return localPermission;
  }
  
  private PermissionGroup parsePermissionGroup(Package paramPackage, int paramInt, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, String[] paramArrayOfString)
    throws XmlPullParserException, IOException
  {
    PermissionGroup localPermissionGroup = new PermissionGroup(paramPackage);
    TypedArray localTypedArray = paramResources.obtainAttributes(paramAttributeSet, R.styleable.AndroidManifestPermissionGroup);
    if (!parsePackageItemInfo(paramPackage, localPermissionGroup.info, paramArrayOfString, "<permission-group>", localTypedArray, 2, 0, 1, 5))
    {
      localTypedArray.recycle();
      this.mParseError = -108;
      return null;
    }
    localPermissionGroup.info.descriptionRes = localTypedArray.getResourceId(4, 0);
    localPermissionGroup.info.flags = localTypedArray.getInt(6, 0);
    localPermissionGroup.info.priority = localTypedArray.getInt(3, 0);
    if ((localPermissionGroup.info.priority > 0) && ((paramInt & 0x1) == 0)) {
      localPermissionGroup.info.priority = 0;
    }
    localTypedArray.recycle();
    if (!parseAllMetaData(paramResources, paramXmlPullParser, paramAttributeSet, "<permission-group>", localPermissionGroup, paramArrayOfString))
    {
      this.mParseError = -108;
      return null;
    }
    paramPackage.permissionGroups.add(localPermissionGroup);
    return localPermissionGroup;
  }
  
  private Permission parsePermissionTree(Package paramPackage, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, String[] paramArrayOfString)
    throws XmlPullParserException, IOException
  {
    Permission localPermission = new Permission(paramPackage);
    TypedArray localTypedArray = paramResources.obtainAttributes(paramAttributeSet, R.styleable.AndroidManifestPermissionTree);
    if (!parsePackageItemInfo(paramPackage, localPermission.info, paramArrayOfString, "<permission-tree>", localTypedArray, 2, 0, 1, 3))
    {
      localTypedArray.recycle();
      this.mParseError = -108;
      return null;
    }
    localTypedArray.recycle();
    int i = localPermission.info.name.indexOf('.');
    if (i > 0) {
      i = localPermission.info.name.indexOf('.', i + 1);
    }
    if (i < 0)
    {
      paramArrayOfString[0] = ("<permission-tree> name has less than three segments: " + localPermission.info.name);
      this.mParseError = -108;
      return null;
    }
    localPermission.info.descriptionRes = 0;
    localPermission.info.protectionLevel = 0;
    localPermission.tree = true;
    if (!parseAllMetaData(paramResources, paramXmlPullParser, paramAttributeSet, "<permission-tree>", localPermission, paramArrayOfString))
    {
      this.mParseError = -108;
      return null;
    }
    paramPackage.permissions.add(localPermission);
    return localPermission;
  }
  
  private Provider parseProvider(Package paramPackage, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, int paramInt, String[] paramArrayOfString)
    throws XmlPullParserException, IOException
  {
    TypedArray localTypedArray = paramResources.obtainAttributes(paramAttributeSet, R.styleable.AndroidManifestProvider);
    if (this.mParseProviderArgs == null)
    {
      this.mParseProviderArgs = new ParseComponentArgs(paramPackage, paramArrayOfString, 2, 0, 1, 15, this.mSeparateProcesses, 8, 14, 6);
      this.mParseProviderArgs.tag = "<provider>";
    }
    this.mParseProviderArgs.sa = localTypedArray;
    this.mParseProviderArgs.flags = paramInt;
    Provider localProvider = new Provider(this.mParseProviderArgs, new ProviderInfo());
    if (paramArrayOfString[0] != null)
    {
      localTypedArray.recycle();
      localProvider = null;
    }
    label555:
    do
    {
      return localProvider;
      int i = paramPackage.applicationInfo.targetSdkVersion;
      boolean bool = false;
      if (i < 17) {
        bool = true;
      }
      localProvider.info.exported = localTypedArray.getBoolean(7, bool);
      String str1 = localTypedArray.getNonConfigurationString(10, 0);
      localProvider.info.isSyncable = localTypedArray.getBoolean(11, false);
      String str2 = localTypedArray.getNonConfigurationString(3, 0);
      String str3 = localTypedArray.getNonConfigurationString(4, 0);
      if (str3 == null) {
        str3 = str2;
      }
      String str5;
      if (str3 == null)
      {
        localProvider.info.readPermission = paramPackage.applicationInfo.permission;
        str5 = localTypedArray.getNonConfigurationString(5, 0);
        if (str5 == null) {
          str5 = str2;
        }
        if (str5 == null)
        {
          localProvider.info.writePermission = paramPackage.applicationInfo.permission;
          localProvider.info.grantUriPermissions = localTypedArray.getBoolean(13, false);
          localProvider.info.multiprocess = localTypedArray.getBoolean(9, false);
          localProvider.info.initOrder = localTypedArray.getInt(12, 0);
          localProvider.info.flags = 0;
          if (localTypedArray.getBoolean(16, false))
          {
            ProviderInfo localProviderInfo3 = localProvider.info;
            localProviderInfo3.flags = (0x40000000 | localProviderInfo3.flags);
            if (localProvider.info.exported)
            {
              Slog.w("PackageParser", "Provider exported request ignored due to singleUser: " + localProvider.className + " at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
              localProvider.info.exported = false;
            }
          }
          localTypedArray.recycle();
          if (((0x10000000 & paramPackage.applicationInfo.flags) == 0) || (localProvider.info.processName != paramPackage.packageName)) {
            break label555;
          }
          paramArrayOfString[0] = "Heavy-weight applications can not have providers in main process";
          return null;
        }
      }
      else
      {
        ProviderInfo localProviderInfo1 = localProvider.info;
        if (str3.length() > 0) {}
        for (String str4 = str3.toString().intern();; str4 = null)
        {
          localProviderInfo1.readPermission = str4;
          break;
        }
      }
      ProviderInfo localProviderInfo2 = localProvider.info;
      if (str5.length() > 0) {}
      for (String str6 = str5.toString().intern();; str6 = null)
      {
        localProviderInfo2.writePermission = str6;
        break;
      }
      if (str1 == null)
      {
        paramArrayOfString[0] = "<provider> does not include authorities attribute";
        return null;
      }
      localProvider.info.authority = str1.intern();
    } while (parseProviderTags(paramResources, paramXmlPullParser, paramAttributeSet, localProvider, paramArrayOfString));
    return null;
  }
  
  private boolean parseProviderTags(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Provider paramProvider, String[] paramArrayOfString)
    throws XmlPullParserException, IOException
  {
    int i = paramXmlPullParser.getDepth();
    for (;;)
    {
      int j = paramXmlPullParser.next();
      if ((j == 1) || ((j == 3) && (paramXmlPullParser.getDepth() <= i))) {
        break;
      }
      if ((j != 3) && (j != 4)) {
        if (paramXmlPullParser.getName().equals("meta-data"))
        {
          Bundle localBundle = parseMetaData(paramResources, paramXmlPullParser, paramAttributeSet, paramProvider.metaData, paramArrayOfString);
          paramProvider.metaData = localBundle;
          if (localBundle == null) {
            return false;
          }
        }
        else if (paramXmlPullParser.getName().equals("grant-uri-permission"))
        {
          TypedArray localTypedArray2 = paramResources.obtainAttributes(paramAttributeSet, R.styleable.AndroidManifestGrantUriPermission);
          String str7 = localTypedArray2.getNonConfigurationString(0, 0);
          PatternMatcher localPatternMatcher = null;
          if (str7 != null) {
            localPatternMatcher = new PatternMatcher(str7, 0);
          }
          String str8 = localTypedArray2.getNonConfigurationString(1, 0);
          if (str8 != null) {
            localPatternMatcher = new PatternMatcher(str8, 1);
          }
          String str9 = localTypedArray2.getNonConfigurationString(2, 0);
          if (str9 != null) {
            localPatternMatcher = new PatternMatcher(str9, 2);
          }
          localTypedArray2.recycle();
          if (localPatternMatcher != null)
          {
            if (paramProvider.info.uriPermissionPatterns == null)
            {
              paramProvider.info.uriPermissionPatterns = new PatternMatcher[1];
              paramProvider.info.uriPermissionPatterns[0] = localPatternMatcher;
            }
            for (;;)
            {
              paramProvider.info.grantUriPermissions = true;
              XmlUtils.skipCurrentTag(paramXmlPullParser);
              break;
              int n = paramProvider.info.uriPermissionPatterns.length;
              PatternMatcher[] arrayOfPatternMatcher = new PatternMatcher[n + 1];
              System.arraycopy(paramProvider.info.uriPermissionPatterns, 0, arrayOfPatternMatcher, 0, n);
              arrayOfPatternMatcher[n] = localPatternMatcher;
              paramProvider.info.uriPermissionPatterns = arrayOfPatternMatcher;
            }
          }
          Slog.w("PackageParser", "Unknown element under <path-permission>: " + paramXmlPullParser.getName() + " at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
          XmlUtils.skipCurrentTag(paramXmlPullParser);
        }
        else if (paramXmlPullParser.getName().equals("path-permission"))
        {
          TypedArray localTypedArray1 = paramResources.obtainAttributes(paramAttributeSet, R.styleable.AndroidManifestPathPermission);
          String str1 = localTypedArray1.getNonConfigurationString(0, 0);
          String str2 = localTypedArray1.getNonConfigurationString(1, 0);
          if (str2 == null) {
            str2 = str1;
          }
          String str3 = localTypedArray1.getNonConfigurationString(2, 0);
          if (str3 == null) {
            str3 = str1;
          }
          int k = 0;
          if (str2 != null)
          {
            str2 = str2.intern();
            k = 1;
          }
          if (str3 != null)
          {
            str3 = str3.intern();
            k = 1;
          }
          if (k == 0)
          {
            Slog.w("PackageParser", "No readPermission or writePermssion for <path-permission>: " + paramXmlPullParser.getName() + " at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
            XmlUtils.skipCurrentTag(paramXmlPullParser);
          }
          else
          {
            String str4 = localTypedArray1.getNonConfigurationString(3, 0);
            PathPermission localPathPermission = null;
            if (str4 != null) {
              localPathPermission = new PathPermission(str4, 0, str2, str3);
            }
            String str5 = localTypedArray1.getNonConfigurationString(4, 0);
            if (str5 != null) {
              localPathPermission = new PathPermission(str5, 1, str2, str3);
            }
            String str6 = localTypedArray1.getNonConfigurationString(5, 0);
            if (str6 != null) {
              localPathPermission = new PathPermission(str6, 2, str2, str3);
            }
            localTypedArray1.recycle();
            if (localPathPermission != null)
            {
              if (paramProvider.info.pathPermissions == null)
              {
                paramProvider.info.pathPermissions = new PathPermission[1];
                paramProvider.info.pathPermissions[0] = localPathPermission;
              }
              for (;;)
              {
                XmlUtils.skipCurrentTag(paramXmlPullParser);
                break;
                int m = paramProvider.info.pathPermissions.length;
                PathPermission[] arrayOfPathPermission = new PathPermission[m + 1];
                System.arraycopy(paramProvider.info.pathPermissions, 0, arrayOfPathPermission, 0, m);
                arrayOfPathPermission[m] = localPathPermission;
                paramProvider.info.pathPermissions = arrayOfPathPermission;
              }
            }
            Slog.w("PackageParser", "No path, pathPrefix, or pathPattern for <path-permission>: " + paramXmlPullParser.getName() + " at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
            XmlUtils.skipCurrentTag(paramXmlPullParser);
          }
        }
        else
        {
          Slog.w("PackageParser", "Unknown element under <provider>: " + paramXmlPullParser.getName() + " at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
          XmlUtils.skipCurrentTag(paramXmlPullParser);
        }
      }
    }
    return true;
  }
  
  private Service parseService(Package paramPackage, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, int paramInt, String[] paramArrayOfString)
    throws XmlPullParserException, IOException
  {
    TypedArray localTypedArray = paramResources.obtainAttributes(paramAttributeSet, R.styleable.AndroidManifestService);
    if (this.mParseServiceArgs == null)
    {
      this.mParseServiceArgs = new ParseComponentArgs(paramPackage, paramArrayOfString, 2, 0, 1, 8, this.mSeparateProcesses, 6, 7, 4);
      this.mParseServiceArgs.tag = "<service>";
    }
    this.mParseServiceArgs.sa = localTypedArray;
    this.mParseServiceArgs.flags = paramInt;
    Service localService = new Service(this.mParseServiceArgs, new ServiceInfo());
    if (paramArrayOfString[0] != null)
    {
      localTypedArray.recycle();
      localService = null;
    }
    boolean bool1;
    do
    {
      return localService;
      bool1 = localTypedArray.hasValue(5);
      if (bool1) {
        localService.info.exported = localTypedArray.getBoolean(5, false);
      }
      String str1 = localTypedArray.getNonConfigurationString(3, 0);
      if (str1 == null)
      {
        localService.info.permission = paramPackage.applicationInfo.permission;
        localService.info.flags = 0;
        if (localTypedArray.getBoolean(9, false))
        {
          ServiceInfo localServiceInfo5 = localService.info;
          localServiceInfo5.flags = (0x1 | localServiceInfo5.flags);
        }
        if (localTypedArray.getBoolean(10, false))
        {
          ServiceInfo localServiceInfo4 = localService.info;
          localServiceInfo4.flags = (0x2 | localServiceInfo4.flags);
        }
        if (localTypedArray.getBoolean(11, false))
        {
          ServiceInfo localServiceInfo3 = localService.info;
          localServiceInfo3.flags = (0x40000000 | localServiceInfo3.flags);
          if (localService.info.exported)
          {
            Slog.w("PackageParser", "Service exported request ignored due to singleUser: " + localService.className + " at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
            localService.info.exported = false;
          }
          bool1 = true;
        }
        localTypedArray.recycle();
        if (((0x10000000 & paramPackage.applicationInfo.flags) != 0) && (localService.info.processName == paramPackage.packageName))
        {
          paramArrayOfString[0] = "Heavy-weight applications can not have services in main process";
          return null;
        }
      }
      else
      {
        ServiceInfo localServiceInfo1 = localService.info;
        if (str1.length() > 0) {}
        for (String str2 = str1.toString().intern();; str2 = null)
        {
          localServiceInfo1.permission = str2;
          break;
        }
      }
      int i = paramXmlPullParser.getDepth();
      for (;;)
      {
        int j = paramXmlPullParser.next();
        if ((j == 1) || ((j == 3) && (paramXmlPullParser.getDepth() <= i))) {
          break;
        }
        if ((j != 3) && (j != 4)) {
          if (paramXmlPullParser.getName().equals("intent-filter"))
          {
            ServiceIntentInfo localServiceIntentInfo = new ServiceIntentInfo(localService);
            if (!parseIntent(paramResources, paramXmlPullParser, paramAttributeSet, paramInt, localServiceIntentInfo, paramArrayOfString, false)) {
              return null;
            }
            localService.intents.add(localServiceIntentInfo);
          }
          else if (paramXmlPullParser.getName().equals("meta-data"))
          {
            Bundle localBundle = parseMetaData(paramResources, paramXmlPullParser, paramAttributeSet, localService.metaData, paramArrayOfString);
            localService.metaData = localBundle;
            if (localBundle == null) {
              return null;
            }
          }
          else
          {
            Slog.w("PackageParser", "Unknown element under <service>: " + paramXmlPullParser.getName() + " at " + this.mArchiveSourcePath + " " + paramXmlPullParser.getPositionDescription());
            XmlUtils.skipCurrentTag(paramXmlPullParser);
          }
        }
      }
    } while (bool1);
    ServiceInfo localServiceInfo2 = localService.info;
    if (localService.intents.size() > 0) {}
    for (boolean bool2 = true;; bool2 = false)
    {
      localServiceInfo2.exported = bool2;
      return localService;
    }
  }
  
  /* Error */
  private static VerifierInfo parseVerifier(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, int paramInt, String[] paramArrayOfString)
    throws XmlPullParserException, IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_2
    //   2: getstatic 1464	com/android/internal/R$styleable:AndroidManifestPackageVerifier	[I
    //   5: invokevirtual 611	android/content/res/Resources:obtainAttributes	(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   8: astore 5
    //   10: aload 5
    //   12: iconst_0
    //   13: invokevirtual 864	android/content/res/TypedArray:getNonResourceString	(I)Ljava/lang/String;
    //   16: astore 6
    //   18: aload 5
    //   20: iconst_1
    //   21: invokevirtual 864	android/content/res/TypedArray:getNonResourceString	(I)Ljava/lang/String;
    //   24: astore 7
    //   26: aload 5
    //   28: invokevirtual 641	android/content/res/TypedArray:recycle	()V
    //   31: aload 6
    //   33: ifnull +11 -> 44
    //   36: aload 6
    //   38: invokevirtual 176	java/lang/String:length	()I
    //   41: ifne +14 -> 55
    //   44: ldc 43
    //   46: ldc_w 1466
    //   49: invokestatic 1213	android/util/Slog:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   52: pop
    //   53: aconst_null
    //   54: areturn
    //   55: aload 7
    //   57: ifnonnull +36 -> 93
    //   60: ldc 43
    //   62: new 141	java/lang/StringBuilder
    //   65: dup
    //   66: invokespecial 142	java/lang/StringBuilder:<init>	()V
    //   69: ldc_w 1468
    //   72: invokevirtual 148	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   75: aload 6
    //   77: invokevirtual 148	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: ldc_w 1470
    //   83: invokevirtual 148	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   86: invokevirtual 152	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   89: invokestatic 1213	android/util/Slog:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   92: pop
    //   93: new 1472	java/security/spec/X509EncodedKeySpec
    //   96: dup
    //   97: aload 7
    //   99: iconst_0
    //   100: invokestatic 1478	android/util/Base64:decode	(Ljava/lang/String;I)[B
    //   103: invokespecial 1481	java/security/spec/X509EncodedKeySpec:<init>	([B)V
    //   106: astore 9
    //   108: new 1483	android/content/pm/VerifierInfo
    //   111: dup
    //   112: aload 6
    //   114: ldc_w 1485
    //   117: invokestatic 1491	java/security/KeyFactory:getInstance	(Ljava/lang/String;)Ljava/security/KeyFactory;
    //   120: aload 9
    //   122: invokevirtual 1495	java/security/KeyFactory:generatePublic	(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;
    //   125: invokespecial 1498	android/content/pm/VerifierInfo:<init>	(Ljava/lang/String;Ljava/security/PublicKey;)V
    //   128: astore 10
    //   130: aload 10
    //   132: areturn
    //   133: astore 16
    //   135: ldc 43
    //   137: ldc_w 1500
    //   140: invokestatic 1503	android/util/Log:wtf	(Ljava/lang/String;Ljava/lang/String;)I
    //   143: pop
    //   144: aconst_null
    //   145: areturn
    //   146: astore 18
    //   148: ldc 43
    //   150: new 141	java/lang/StringBuilder
    //   153: dup
    //   154: invokespecial 142	java/lang/StringBuilder:<init>	()V
    //   157: ldc_w 1505
    //   160: invokevirtual 148	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   163: aload 6
    //   165: invokevirtual 148	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   168: ldc_w 1507
    //   171: invokevirtual 148	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   174: invokevirtual 152	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   177: invokestatic 1213	android/util/Slog:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   180: pop
    //   181: aconst_null
    //   182: areturn
    //   183: astore 11
    //   185: new 1483	android/content/pm/VerifierInfo
    //   188: dup
    //   189: aload 6
    //   191: ldc_w 1509
    //   194: invokestatic 1491	java/security/KeyFactory:getInstance	(Ljava/lang/String;)Ljava/security/KeyFactory;
    //   197: aload 9
    //   199: invokevirtual 1495	java/security/KeyFactory:generatePublic	(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;
    //   202: invokespecial 1498	android/content/pm/VerifierInfo:<init>	(Ljava/lang/String;Ljava/security/PublicKey;)V
    //   205: astore 12
    //   207: aload 12
    //   209: areturn
    //   210: astore 14
    //   212: ldc 43
    //   214: ldc_w 1511
    //   217: invokestatic 1503	android/util/Log:wtf	(Ljava/lang/String;Ljava/lang/String;)I
    //   220: pop
    //   221: aconst_null
    //   222: areturn
    //   223: astore 13
    //   225: aconst_null
    //   226: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	227	0	paramResources	Resources
    //   0	227	1	paramXmlPullParser	XmlPullParser
    //   0	227	2	paramAttributeSet	AttributeSet
    //   0	227	3	paramInt	int
    //   0	227	4	paramArrayOfString	String[]
    //   8	19	5	localTypedArray	TypedArray
    //   16	174	6	str1	String
    //   24	74	7	str2	String
    //   106	92	9	localX509EncodedKeySpec	java.security.spec.X509EncodedKeySpec
    //   128	3	10	localVerifierInfo1	VerifierInfo
    //   183	1	11	localInvalidKeySpecException1	java.security.spec.InvalidKeySpecException
    //   205	3	12	localVerifierInfo2	VerifierInfo
    //   223	1	13	localInvalidKeySpecException2	java.security.spec.InvalidKeySpecException
    //   210	1	14	localNoSuchAlgorithmException1	java.security.NoSuchAlgorithmException
    //   133	1	16	localNoSuchAlgorithmException2	java.security.NoSuchAlgorithmException
    //   146	1	18	localIllegalArgumentException	IllegalArgumentException
    // Exception table:
    //   from	to	target	type
    //   108	130	133	java/security/NoSuchAlgorithmException
    //   93	108	146	java/lang/IllegalArgumentException
    //   108	130	183	java/security/spec/InvalidKeySpecException
    //   185	207	210	java/security/NoSuchAlgorithmException
    //   185	207	223	java/security/spec/InvalidKeySpecException
  }
  
  public static void setCompatibilityModeEnabled(boolean paramBoolean)
  {
    sCompatibilityModeEnabled = paramBoolean;
  }
  
  public static Signature stringToSignature(String paramString)
  {
    int i = paramString.length();
    byte[] arrayOfByte = new byte[i];
    for (int j = 0; j < i; j++) {
      arrayOfByte[j] = ((byte)paramString.charAt(j));
    }
    return new Signature(arrayOfByte);
  }
  
  private static String validateName(String paramString, boolean paramBoolean)
  {
    int i = paramString.length();
    int j = 0;
    int k = 1;
    int m = 0;
    if (m < i)
    {
      char c = paramString.charAt(m);
      if (((c >= 'a') && (c <= 'z')) || ((c >= 'A') && (c <= 'Z'))) {}
      for (k = 0;; k = 1)
      {
        do
        {
          m++;
          break;
        } while ((k == 0) && (((c >= '0') && (c <= '9')) || (c == '_')));
        if (c != '.') {
          break label105;
        }
        j = 1;
      }
      label105:
      return "bad character '" + c + "'";
    }
    if ((j != 0) || (!paramBoolean)) {
      return null;
    }
    return "must have at least one '.' separator";
  }
  
  public boolean collectCertificates(Package paramPackage, int paramInt)
  {
    paramPackage.mSignatures = null;
    WeakReference localWeakReference;
    byte[] arrayOfByte;
    synchronized (mSync)
    {
      localWeakReference = mReadBuffer;
      arrayOfByte = null;
      if (localWeakReference != null)
      {
        mReadBuffer = null;
        arrayOfByte = (byte[])localWeakReference.get();
      }
      if (arrayOfByte == null)
      {
        arrayOfByte = new byte[' '];
        localWeakReference = new WeakReference(arrayOfByte);
      }
    }
    for (;;)
    {
      Object localObject3;
      Certificate[] arrayOfCertificate;
      int k;
      int m;
      try
      {
        JarFile localJarFile = new JarFile(this.mArchiveSourcePath);
        localObject3 = null;
        if ((paramInt & 0x1) != 0)
        {
          JarEntry localJarEntry1 = localJarFile.getJarEntry("AndroidManifest.xml");
          localObject3 = loadCertificates(localJarFile, localJarEntry1, arrayOfByte);
          if (localObject3 == null)
          {
            Slog.e("PackageParser", "Package " + paramPackage.packageName + " has no certificates at entry " + localJarEntry1.getName() + "; ignoring!");
            localJarFile.close();
            this.mParseError = -103;
            return false;
            localObject2 = finally;
            throw ((Throwable)localObject2);
          }
        }
        else
        {
          Enumeration localEnumeration = localJarFile.entries();
          Manifest localManifest = localJarFile.getManifest();
          if (localEnumeration.hasMoreElements())
          {
            JarEntry localJarEntry2 = (JarEntry)localEnumeration.nextElement();
            if (localJarEntry2.isDirectory()) {
              continue;
            }
            String str = localJarEntry2.getName();
            if (str.startsWith("META-INF/")) {
              continue;
            }
            if ("AndroidManifest.xml".equals(str)) {
              paramPackage.manifestDigest = ManifestDigest.fromAttributes(localManifest.getAttributes(str));
            }
            arrayOfCertificate = loadCertificates(localJarFile, localJarEntry2, arrayOfByte);
            if (arrayOfCertificate != null) {
              break label735;
            }
            Slog.e("PackageParser", "Package " + paramPackage.packageName + " has no certificates at entry " + localJarEntry2.getName() + "; ignoring!");
            localJarFile.close();
            this.mParseError = -103;
            return false;
            if (k >= localObject3.length) {
              continue;
            }
            m = 0;
            int n = arrayOfCertificate.length;
            int i1 = 0;
            if (m < n)
            {
              if ((localObject3[k] == null) || (!localObject3[k].equals(arrayOfCertificate[m]))) {
                break label753;
              }
              i1 = 1;
            }
            if ((i1 != 0) && (localObject3.length == arrayOfCertificate.length)) {
              break label759;
            }
            Slog.e("PackageParser", "Package " + paramPackage.packageName + " has mismatched certificates at entry " + localJarEntry2.getName() + "; ignoring!");
            localJarFile.close();
            this.mParseError = -104;
            return false;
          }
        }
        localJarFile.close();
        synchronized (mSync)
        {
          mReadBuffer = localWeakReference;
          if ((localObject3 != null) && (localObject3.length > 0))
          {
            int i = localObject3.length;
            paramPackage.mSignatures = new Signature[localObject3.length];
            int j = 0;
            if (j >= i) {
              break label733;
            }
            paramPackage.mSignatures[j] = new Signature(localObject3[j].getEncoded());
            j++;
          }
        }
        return true;
      }
      catch (CertificateEncodingException localCertificateEncodingException)
      {
        Slog.w("PackageParser", "Exception reading " + this.mArchiveSourcePath, localCertificateEncodingException);
        this.mParseError = -105;
        return false;
        Slog.e("PackageParser", "Package " + paramPackage.packageName + " has no certificates; ignoring!");
        this.mParseError = -103;
        return false;
      }
      catch (IOException localIOException)
      {
        Slog.w("PackageParser", "Exception reading " + this.mArchiveSourcePath, localIOException);
        this.mParseError = -105;
        return false;
      }
      catch (RuntimeException localRuntimeException)
      {
        Slog.w("PackageParser", "Exception reading " + this.mArchiveSourcePath, localRuntimeException);
        this.mParseError = -102;
        return false;
      }
      label733:
      label735:
      if (localObject3 == null)
      {
        localObject3 = arrayOfCertificate;
      }
      else
      {
        k = 0;
        continue;
        label753:
        m++;
        continue;
        label759:
        k++;
      }
    }
  }
  
  public int getParseError()
  {
    return this.mParseError;
  }
  
  public Package parsePackage(File paramFile, String paramString, DisplayMetrics paramDisplayMetrics, int paramInt)
  {
    this.mParseError = 1;
    this.mArchiveSourcePath = paramFile.getPath();
    if (!paramFile.isFile())
    {
      Slog.w("PackageParser", "Skipping dir: " + this.mArchiveSourcePath);
      this.mParseError = -100;
      return null;
    }
    if ((!isPackageFilename(paramFile.getName())) && ((paramInt & 0x4) != 0))
    {
      if ((paramInt & 0x1) == 0) {
        Slog.w("PackageParser", "Skipping non-package file: " + this.mArchiveSourcePath);
      }
      this.mParseError = -100;
      return null;
    }
    localObject1 = null;
    int i = 1;
    for (;;)
    {
      try
      {
        localAssetManager = new AssetManager();
        int j;
        XmlResourceParser localXmlResourceParser2;
        try
        {
          j = localAssetManager.addAssetPath(this.mArchiveSourcePath);
          if (j != 0) {
            localResources = new Resources(localAssetManager, paramDisplayMetrics, null);
          }
        }
        catch (Exception localException1) {}
      }
      catch (Exception localException2)
      {
        XmlResourceParser localXmlResourceParser1;
        String[] arrayOfString;
        Object localObject2;
        Package localPackage2;
        Package localPackage1;
        String str;
        AssetManager localAssetManager = null;
        localObject1 = null;
        continue;
      }
      try
      {
        localAssetManager.setConfiguration(0, 0, null, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Build.VERSION.RESOURCES_SDK_INT);
        localXmlResourceParser2 = localAssetManager.openXmlResourceParser(j, "AndroidManifest.xml");
        localXmlResourceParser1 = localXmlResourceParser2;
        i = 0;
        localObject1 = localResources;
        if (i == 0) {
          continue;
        }
        if (localAssetManager != null) {
          localAssetManager.close();
        }
        this.mParseError = -101;
        return null;
      }
      catch (Exception localException3)
      {
        localObject1 = localResources;
        continue;
      }
      Slog.w("PackageParser", "Failed adding asset path:" + this.mArchiveSourcePath);
      localXmlResourceParser1 = null;
      localObject1 = null;
      continue;
      Slog.w("PackageParser", "Unable to read AndroidManifest.xml of " + this.mArchiveSourcePath, localException1);
      localXmlResourceParser1 = null;
    }
    arrayOfString = new String[1];
    localObject2 = null;
    try
    {
      localPackage2 = parsePackage((Resources)localObject1, localXmlResourceParser1, paramInt, arrayOfString);
      localPackage1 = localPackage2;
    }
    catch (Exception localException4)
    {
      for (;;)
      {
        localObject2 = localException4;
        this.mParseError = -102;
        localPackage1 = null;
        continue;
        Slog.w("PackageParser", this.mArchiveSourcePath + " (at " + localXmlResourceParser1.getPositionDescription() + "): " + arrayOfString[0]);
      }
      localXmlResourceParser1.close();
      localAssetManager.close();
      localPackage1.mPath = paramString;
      str = this.mArchiveSourcePath;
      localPackage1.mScanPath = str;
      localPackage1.mSignatures = null;
      return localPackage1;
    }
    if (localPackage1 == null)
    {
      if ((!this.mOnlyCoreApps) || (this.mParseError != 1))
      {
        if (localObject2 == null) {
          break label418;
        }
        Slog.w("PackageParser", this.mArchiveSourcePath, (Throwable)localObject2);
        if (this.mParseError == 1) {
          this.mParseError = -108;
        }
      }
      localXmlResourceParser1.close();
      localAssetManager.close();
      return null;
    }
  }
  
  public void setOnlyCoreApps(boolean paramBoolean)
  {
    this.mOnlyCoreApps = paramBoolean;
  }
  
  public void setSeparateProcesses(String[] paramArrayOfString)
  {
    this.mSeparateProcesses = paramArrayOfString;
  }
  
  public static final class Activity
    extends PackageParser.Component<PackageParser.ActivityIntentInfo>
  {
    public final ActivityInfo info;
    
    public Activity(PackageParser.ParseComponentArgs paramParseComponentArgs, ActivityInfo paramActivityInfo)
    {
      super(paramActivityInfo);
      this.info = paramActivityInfo;
      this.info.applicationInfo = paramParseComponentArgs.owner.applicationInfo;
    }
    
    public void setPackageName(String paramString)
    {
      super.setPackageName(paramString);
      this.info.packageName = paramString;
    }
    
    public String toString()
    {
      return "Activity{" + Integer.toHexString(System.identityHashCode(this)) + " " + getComponentShortName() + "}";
    }
  }
  
  public static final class ActivityIntentInfo
    extends PackageParser.IntentInfo
  {
    public final PackageParser.Activity activity;
    
    public ActivityIntentInfo(PackageParser.Activity paramActivity)
    {
      this.activity = paramActivity;
    }
    
    public String toString()
    {
      return "ActivityIntentInfo{" + Integer.toHexString(System.identityHashCode(this)) + " " + this.activity.info.name + "}";
    }
  }
  
  public static class Component<II extends PackageParser.IntentInfo>
  {
    public final String className;
    ComponentName componentName;
    String componentShortName;
    public final ArrayList<II> intents;
    public Bundle metaData;
    public final PackageParser.Package owner;
    
    public Component(Component<II> paramComponent)
    {
      this.owner = paramComponent.owner;
      this.intents = paramComponent.intents;
      this.className = paramComponent.className;
      this.componentName = paramComponent.componentName;
      this.componentShortName = paramComponent.componentShortName;
    }
    
    public Component(PackageParser.Package paramPackage)
    {
      this.owner = paramPackage;
      this.intents = null;
      this.className = null;
    }
    
    public Component(PackageParser.ParseComponentArgs paramParseComponentArgs, ComponentInfo paramComponentInfo)
    {
      this(paramParseComponentArgs, paramComponentInfo);
      if (paramParseComponentArgs.outError[0] != null) {
        return;
      }
      if (paramParseComponentArgs.processRes != 0) {
        if (this.owner.applicationInfo.targetSdkVersion < 8) {
          break label131;
        }
      }
      label131:
      for (String str = paramParseComponentArgs.sa.getNonConfigurationString(paramParseComponentArgs.processRes, 0);; str = paramParseComponentArgs.sa.getNonResourceString(paramParseComponentArgs.processRes))
      {
        paramComponentInfo.processName = PackageParser.buildProcessName(this.owner.applicationInfo.packageName, this.owner.applicationInfo.processName, str, paramParseComponentArgs.flags, paramParseComponentArgs.sepProcesses, paramParseComponentArgs.outError);
        if (paramParseComponentArgs.descriptionRes != 0) {
          paramComponentInfo.descriptionRes = paramParseComponentArgs.sa.getResourceId(paramParseComponentArgs.descriptionRes, 0);
        }
        paramComponentInfo.enabled = paramParseComponentArgs.sa.getBoolean(paramParseComponentArgs.enabledRes, true);
        return;
      }
    }
    
    public Component(PackageParser.ParsePackageItemArgs paramParsePackageItemArgs, PackageItemInfo paramPackageItemInfo)
    {
      this.owner = paramParsePackageItemArgs.owner;
      this.intents = new ArrayList(0);
      String str = paramParsePackageItemArgs.sa.getNonConfigurationString(paramParsePackageItemArgs.nameRes, 0);
      if (str == null)
      {
        this.className = null;
        paramParsePackageItemArgs.outError[0] = (paramParsePackageItemArgs.tag + " does not specify android:name");
        return;
      }
      paramPackageItemInfo.name = PackageParser.buildClassName(this.owner.applicationInfo.packageName, str, paramParsePackageItemArgs.outError);
      if (paramPackageItemInfo.name == null)
      {
        this.className = null;
        paramParsePackageItemArgs.outError[0] = (paramParsePackageItemArgs.tag + " does not have valid android:name");
        return;
      }
      this.className = paramPackageItemInfo.name;
      int i = paramParsePackageItemArgs.sa.getResourceId(paramParsePackageItemArgs.iconRes, 0);
      if (i != 0)
      {
        paramPackageItemInfo.icon = i;
        paramPackageItemInfo.nonLocalizedLabel = null;
      }
      int j = paramParsePackageItemArgs.sa.getResourceId(paramParsePackageItemArgs.logoRes, 0);
      if (j != 0) {
        paramPackageItemInfo.logo = j;
      }
      TypedValue localTypedValue = paramParsePackageItemArgs.sa.peekValue(paramParsePackageItemArgs.labelRes);
      if (localTypedValue != null)
      {
        int k = localTypedValue.resourceId;
        paramPackageItemInfo.labelRes = k;
        if (k == 0) {
          paramPackageItemInfo.nonLocalizedLabel = localTypedValue.coerceToString();
        }
      }
      paramPackageItemInfo.packageName = this.owner.packageName;
    }
    
    public ComponentName getComponentName()
    {
      if (this.componentName != null) {
        return this.componentName;
      }
      if (this.className != null) {
        this.componentName = new ComponentName(this.owner.applicationInfo.packageName, this.className);
      }
      return this.componentName;
    }
    
    public String getComponentShortName()
    {
      if (this.componentShortName != null) {
        return this.componentShortName;
      }
      ComponentName localComponentName = getComponentName();
      if (localComponentName != null) {
        this.componentShortName = localComponentName.flattenToShortString();
      }
      return this.componentShortName;
    }
    
    public void setPackageName(String paramString)
    {
      this.componentName = null;
      this.componentShortName = null;
    }
  }
  
  public static final class Instrumentation
    extends PackageParser.Component
  {
    public final InstrumentationInfo info;
    
    public Instrumentation(PackageParser.ParsePackageItemArgs paramParsePackageItemArgs, InstrumentationInfo paramInstrumentationInfo)
    {
      super(paramInstrumentationInfo);
      this.info = paramInstrumentationInfo;
    }
    
    public void setPackageName(String paramString)
    {
      super.setPackageName(paramString);
      this.info.packageName = paramString;
    }
    
    public String toString()
    {
      return "Instrumentation{" + Integer.toHexString(System.identityHashCode(this)) + " " + getComponentShortName() + "}";
    }
  }
  
  public static class IntentInfo
    extends IntentFilter
  {
    public boolean hasDefault;
    public int icon;
    public int labelRes;
    public int logo;
    public CharSequence nonLocalizedLabel;
  }
  
  public static class NewPermissionInfo
  {
    public final int fileVersion;
    public final String name;
    public final int sdkVersion;
    
    public NewPermissionInfo(String paramString, int paramInt1, int paramInt2)
    {
      this.name = paramString;
      this.sdkVersion = paramInt1;
      this.fileVersion = paramInt2;
    }
  }
  
  public static final class Package
  {
    public final ArrayList<PackageParser.Activity> activities = new ArrayList(0);
    public final ApplicationInfo applicationInfo = new ApplicationInfo();
    public final ArrayList<ConfigurationInfo> configPreferences = new ArrayList();
    public int installLocation;
    public final ArrayList<PackageParser.Instrumentation> instrumentation = new ArrayList(0);
    public ArrayList<String> mAdoptPermissions = null;
    public Bundle mAppMetaData = null;
    public boolean mDidDexOpt;
    public Object mExtras;
    public boolean mOperationPending;
    public ArrayList<String> mOriginalPackages = null;
    public String mPath;
    public int mPreferredOrder = 0;
    public String mRealPackage = null;
    public String mScanPath;
    public String mSharedUserId;
    public int mSharedUserLabel;
    public Signature[] mSignatures;
    public int mVersionCode;
    public String mVersionName;
    public ManifestDigest manifestDigest;
    public String packageName;
    public final ArrayList<PackageParser.PermissionGroup> permissionGroups = new ArrayList(0);
    public final ArrayList<PackageParser.Permission> permissions = new ArrayList(0);
    public ArrayList<String> protectedBroadcasts;
    public final ArrayList<PackageParser.Provider> providers = new ArrayList(0);
    public final ArrayList<PackageParser.Activity> receivers = new ArrayList(0);
    public ArrayList<FeatureInfo> reqFeatures = null;
    public final ArrayList<String> requestedPermissions = new ArrayList();
    public final ArrayList<Boolean> requestedPermissionsRequired = new ArrayList();
    public final ArrayList<PackageParser.Service> services = new ArrayList(0);
    public ArrayList<String> usesLibraries = null;
    public String[] usesLibraryFiles = null;
    public ArrayList<String> usesOptionalLibraries = null;
    
    public Package(String paramString)
    {
      this.packageName = paramString;
      this.applicationInfo.packageName = paramString;
      this.applicationInfo.uid = -1;
    }
    
    public boolean hasComponentClassName(String paramString)
    {
      for (int i = -1 + this.activities.size(); i >= 0; i--) {
        if (paramString.equals(((PackageParser.Activity)this.activities.get(i)).className)) {
          return true;
        }
      }
      for (int j = -1 + this.receivers.size(); j >= 0; j--) {
        if (paramString.equals(((PackageParser.Activity)this.receivers.get(j)).className)) {
          return true;
        }
      }
      for (int k = -1 + this.providers.size(); k >= 0; k--) {
        if (paramString.equals(((PackageParser.Provider)this.providers.get(k)).className)) {
          return true;
        }
      }
      for (int m = -1 + this.services.size(); m >= 0; m--) {
        if (paramString.equals(((PackageParser.Service)this.services.get(m)).className)) {
          return true;
        }
      }
      for (int n = -1 + this.instrumentation.size(); n >= 0; n--) {
        if (paramString.equals(((PackageParser.Instrumentation)this.instrumentation.get(n)).className)) {
          return true;
        }
      }
      return false;
    }
    
    public void setPackageName(String paramString)
    {
      this.packageName = paramString;
      this.applicationInfo.packageName = paramString;
      for (int i = -1 + this.permissions.size(); i >= 0; i--) {
        ((PackageParser.Permission)this.permissions.get(i)).setPackageName(paramString);
      }
      for (int j = -1 + this.permissionGroups.size(); j >= 0; j--) {
        ((PackageParser.PermissionGroup)this.permissionGroups.get(j)).setPackageName(paramString);
      }
      for (int k = -1 + this.activities.size(); k >= 0; k--) {
        ((PackageParser.Activity)this.activities.get(k)).setPackageName(paramString);
      }
      for (int m = -1 + this.receivers.size(); m >= 0; m--) {
        ((PackageParser.Activity)this.receivers.get(m)).setPackageName(paramString);
      }
      for (int n = -1 + this.providers.size(); n >= 0; n--) {
        ((PackageParser.Provider)this.providers.get(n)).setPackageName(paramString);
      }
      for (int i1 = -1 + this.services.size(); i1 >= 0; i1--) {
        ((PackageParser.Service)this.services.get(i1)).setPackageName(paramString);
      }
      for (int i2 = -1 + this.instrumentation.size(); i2 >= 0; i2--) {
        ((PackageParser.Instrumentation)this.instrumentation.get(i2)).setPackageName(paramString);
      }
    }
    
    public String toString()
    {
      return "Package{" + Integer.toHexString(System.identityHashCode(this)) + " " + this.packageName + "}";
    }
  }
  
  public static class PackageLite
  {
    public final int installLocation;
    public final String packageName;
    public final VerifierInfo[] verifiers;
    public final int versionCode;
    
    public PackageLite(String paramString, int paramInt1, int paramInt2, List<VerifierInfo> paramList)
    {
      this.packageName = paramString;
      this.versionCode = paramInt1;
      this.installLocation = paramInt2;
      this.verifiers = ((VerifierInfo[])paramList.toArray(new VerifierInfo[paramList.size()]));
    }
  }
  
  static class ParseComponentArgs
    extends PackageParser.ParsePackageItemArgs
  {
    final int descriptionRes;
    final int enabledRes;
    int flags;
    final int processRes;
    final String[] sepProcesses;
    
    ParseComponentArgs(PackageParser.Package paramPackage, String[] paramArrayOfString1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, String[] paramArrayOfString2, int paramInt5, int paramInt6, int paramInt7)
    {
      super(paramArrayOfString1, paramInt1, paramInt2, paramInt3, paramInt4);
      this.sepProcesses = paramArrayOfString2;
      this.processRes = paramInt5;
      this.descriptionRes = paramInt6;
      this.enabledRes = paramInt7;
    }
  }
  
  static class ParsePackageItemArgs
  {
    final int iconRes;
    final int labelRes;
    final int logoRes;
    final int nameRes;
    final String[] outError;
    final PackageParser.Package owner;
    TypedArray sa;
    String tag;
    
    ParsePackageItemArgs(PackageParser.Package paramPackage, String[] paramArrayOfString, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      this.owner = paramPackage;
      this.outError = paramArrayOfString;
      this.nameRes = paramInt1;
      this.labelRes = paramInt2;
      this.iconRes = paramInt3;
      this.logoRes = paramInt4;
    }
  }
  
  public static final class Permission
    extends PackageParser.Component<PackageParser.IntentInfo>
  {
    public PackageParser.PermissionGroup group;
    public final PermissionInfo info;
    public boolean tree;
    
    public Permission(PackageParser.Package paramPackage)
    {
      super();
      this.info = new PermissionInfo();
    }
    
    public Permission(PackageParser.Package paramPackage, PermissionInfo paramPermissionInfo)
    {
      super();
      this.info = paramPermissionInfo;
    }
    
    public void setPackageName(String paramString)
    {
      super.setPackageName(paramString);
      this.info.packageName = paramString;
    }
    
    public String toString()
    {
      return "Permission{" + Integer.toHexString(System.identityHashCode(this)) + " " + this.info.name + "}";
    }
  }
  
  public static final class PermissionGroup
    extends PackageParser.Component<PackageParser.IntentInfo>
  {
    public final PermissionGroupInfo info;
    
    public PermissionGroup(PackageParser.Package paramPackage)
    {
      super();
      this.info = new PermissionGroupInfo();
    }
    
    public PermissionGroup(PackageParser.Package paramPackage, PermissionGroupInfo paramPermissionGroupInfo)
    {
      super();
      this.info = paramPermissionGroupInfo;
    }
    
    public void setPackageName(String paramString)
    {
      super.setPackageName(paramString);
      this.info.packageName = paramString;
    }
    
    public String toString()
    {
      return "PermissionGroup{" + Integer.toHexString(System.identityHashCode(this)) + " " + this.info.name + "}";
    }
  }
  
  public static final class Provider
    extends PackageParser.Component
  {
    public final ProviderInfo info;
    public boolean syncable;
    
    public Provider(PackageParser.ParseComponentArgs paramParseComponentArgs, ProviderInfo paramProviderInfo)
    {
      super(paramProviderInfo);
      this.info = paramProviderInfo;
      this.info.applicationInfo = paramParseComponentArgs.owner.applicationInfo;
      this.syncable = false;
    }
    
    public Provider(Provider paramProvider)
    {
      super();
      this.info = paramProvider.info;
      this.syncable = paramProvider.syncable;
    }
    
    public void setPackageName(String paramString)
    {
      super.setPackageName(paramString);
      this.info.packageName = paramString;
    }
    
    public String toString()
    {
      return "Provider{" + Integer.toHexString(System.identityHashCode(this)) + " " + this.info.name + "}";
    }
  }
  
  public static final class Service
    extends PackageParser.Component<PackageParser.ServiceIntentInfo>
  {
    public final ServiceInfo info;
    
    public Service(PackageParser.ParseComponentArgs paramParseComponentArgs, ServiceInfo paramServiceInfo)
    {
      super(paramServiceInfo);
      this.info = paramServiceInfo;
      this.info.applicationInfo = paramParseComponentArgs.owner.applicationInfo;
    }
    
    public void setPackageName(String paramString)
    {
      super.setPackageName(paramString);
      this.info.packageName = paramString;
    }
    
    public String toString()
    {
      return "Service{" + Integer.toHexString(System.identityHashCode(this)) + " " + getComponentShortName() + "}";
    }
  }
  
  public static final class ServiceIntentInfo
    extends PackageParser.IntentInfo
  {
    public final PackageParser.Service service;
    
    public ServiceIntentInfo(PackageParser.Service paramService)
    {
      this.service = paramService;
    }
    
    public String toString()
    {
      return "ServiceIntentInfo{" + Integer.toHexString(System.identityHashCode(this)) + " " + this.service.info.name + "}";
    }
  }
  
  public static class SplitPermissionInfo
  {
    public final String[] newPerms;
    public final String rootPerm;
    public final int targetSdk;
    
    public SplitPermissionInfo(String paramString, String[] paramArrayOfString, int paramInt)
    {
      this.rootPerm = paramString;
      this.newPerms = paramArrayOfString;
      this.targetSdk = paramInt;
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\pm\PackageParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
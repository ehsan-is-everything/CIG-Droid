package android.content.pm;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

public class LimitedLengthInputStream
  extends FilterInputStream
{
  private final long mEnd;
  private long mOffset;
  
  public LimitedLengthInputStream(InputStream paramInputStream, long paramLong1, long paramLong2)
    throws IOException
  {
    super(paramInputStream);
    if (paramInputStream == null) {
      throw new IOException("in == null");
    }
    if (paramLong1 < 0L) {
      throw new IOException("offset < 0");
    }
    if (paramLong2 < 0L) {
      throw new IOException("length < 0");
    }
    if (paramLong2 > Long.MAX_VALUE - paramLong1) {
      throw new IOException("offset + length > Long.MAX_VALUE");
    }
    this.mEnd = (paramLong1 + paramLong2);
    skip(paramLong1);
    this.mOffset = paramLong1;
  }
  
  /* Error */
  public int read()
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 35	android/content/pm/LimitedLengthInputStream:mOffset	J
    //   6: lstore_2
    //   7: aload_0
    //   8: getfield 29	android/content/pm/LimitedLengthInputStream:mEnd	J
    //   11: lstore 4
    //   13: lload_2
    //   14: lload 4
    //   16: lcmp
    //   17: iflt +11 -> 28
    //   20: iconst_m1
    //   21: istore 7
    //   23: aload_0
    //   24: monitorexit
    //   25: iload 7
    //   27: ireturn
    //   28: aload_0
    //   29: lconst_1
    //   30: aload_0
    //   31: getfield 35	android/content/pm/LimitedLengthInputStream:mOffset	J
    //   34: ladd
    //   35: putfield 35	android/content/pm/LimitedLengthInputStream:mOffset	J
    //   38: aload_0
    //   39: invokespecial 39	java/io/FilterInputStream:read	()I
    //   42: istore 6
    //   44: iload 6
    //   46: istore 7
    //   48: goto -25 -> 23
    //   51: astore_1
    //   52: aload_0
    //   53: monitorexit
    //   54: aload_1
    //   55: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	56	0	this	LimitedLengthInputStream
    //   51	4	1	localObject	Object
    //   6	8	2	l1	long
    //   11	4	4	l2	long
    //   42	3	6	i	int
    //   21	26	7	j	int
    // Exception table:
    //   from	to	target	type
    //   2	13	51	finally
    //   28	44	51	finally
  }
  
  public int read(byte[] paramArrayOfByte)
    throws IOException
  {
    return read(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    if (this.mOffset >= this.mEnd) {
      return -1;
    }
    Arrays.checkOffsetAndCount(paramArrayOfByte.length, paramInt1, paramInt2);
    if (this.mOffset > Long.MAX_VALUE - paramInt2) {
      throw new IOException("offset out of bounds: " + this.mOffset + " + " + paramInt2);
    }
    if (this.mOffset + paramInt2 > this.mEnd) {
      paramInt2 = (int)(this.mEnd - this.mOffset);
    }
    int i = super.read(paramArrayOfByte, paramInt1, paramInt2);
    this.mOffset += i;
    return i;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\pm\LimitedLengthInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
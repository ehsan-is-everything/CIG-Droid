package android.content.pm;

import android.os.Parcel;
import android.os.Parcelable.Creator;

public class PackageCleanItem
{
  public static final Parcelable.Creator<PackageCleanItem> CREATOR = new Parcelable.Creator()
  {
    public PackageCleanItem createFromParcel(Parcel paramAnonymousParcel)
    {
      return new PackageCleanItem(paramAnonymousParcel, null);
    }
    
    public PackageCleanItem[] newArray(int paramAnonymousInt)
    {
      return new PackageCleanItem[paramAnonymousInt];
    }
  };
  public final boolean andCode;
  public final String packageName;
  public final int userId;
  
  public PackageCleanItem(int paramInt, String paramString, boolean paramBoolean)
  {
    this.userId = paramInt;
    this.packageName = paramString;
    this.andCode = paramBoolean;
  }
  
  private PackageCleanItem(Parcel paramParcel)
  {
    this.userId = paramParcel.readInt();
    this.packageName = paramParcel.readString();
    if (paramParcel.readInt() != 0) {}
    for (boolean bool = true;; bool = false)
    {
      this.andCode = bool;
      return;
    }
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    for (;;)
    {
      return true;
      if (paramObject != null) {
        try
        {
          PackageCleanItem localPackageCleanItem = (PackageCleanItem)paramObject;
          if ((this.userId == localPackageCleanItem.userId) && (this.packageName.equals(localPackageCleanItem.packageName)))
          {
            boolean bool1 = this.andCode;
            boolean bool2 = localPackageCleanItem.andCode;
            if (bool1 == bool2) {}
          }
          else
          {
            return false;
          }
        }
        catch (ClassCastException localClassCastException) {}
      }
    }
    return false;
  }
  
  public int hashCode()
  {
    int i = 31 * (31 * (527 + this.userId) + this.packageName.hashCode());
    if (this.andCode) {}
    for (int j = 1;; j = 0) {
      return i + j;
    }
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeInt(this.userId);
    paramParcel.writeString(this.packageName);
    if (this.andCode) {}
    for (int i = 1;; i = 0)
    {
      paramParcel.writeInt(i);
      return;
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\pm\PackageCleanItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.content;

import android.accounts.Account;
import android.accounts.AccountAndUser;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteQueryBuilder;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.Parcel;
import android.os.Process;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.AtomicFile;
import android.util.Log;
import android.util.Pair;
import android.util.SparseArray;
import com.android.internal.util.ArrayUtils;
import com.android.internal.util.FastXmlSerializer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlSerializer;

public class SyncStorageEngine
  extends Handler
{
  private static final int ACCOUNTS_VERSION = 2;
  private static final boolean DEBUG_FILE = false;
  private static final long DEFAULT_POLL_FREQUENCY_SECONDS = 86400L;
  public static final String[] EVENTS = { "START", "STOP" };
  public static final int EVENT_START = 0;
  public static final int EVENT_STOP = 1;
  public static final int MAX_HISTORY = 100;
  public static final String MESG_CANCELED = "canceled";
  public static final String MESG_SUCCESS = "success";
  static final long MILLIS_IN_4WEEKS = 2419200000L;
  private static final int MSG_WRITE_STATISTICS = 2;
  private static final int MSG_WRITE_STATUS = 1;
  public static final long NOT_IN_BACKOFF_MODE = -1L;
  private static final int PENDING_FINISH_TO_WRITE = 4;
  public static final int PENDING_OPERATION_VERSION = 2;
  public static final String[] SOURCES;
  public static final int SOURCE_LOCAL = 1;
  public static final int SOURCE_PERIODIC = 4;
  public static final int SOURCE_POLL = 2;
  public static final int SOURCE_SERVER = 0;
  public static final int SOURCE_USER = 3;
  public static final int STATISTICS_FILE_END = 0;
  public static final int STATISTICS_FILE_ITEM = 101;
  public static final int STATISTICS_FILE_ITEM_OLD = 100;
  public static final int STATUS_FILE_END = 0;
  public static final int STATUS_FILE_ITEM = 100;
  public static final Intent SYNC_CONNECTION_SETTING_CHANGED_INTENT = new Intent("com.android.sync.SYNC_CONN_STATUS_CHANGED");
  private static final boolean SYNC_ENABLED_DEFAULT = false;
  private static final String TAG = "SyncManager";
  private static final long WRITE_STATISTICS_DELAY = 1800000L;
  private static final long WRITE_STATUS_DELAY = 600000L;
  private static final String XML_ATTR_ENABLED = "enabled";
  private static final String XML_ATTR_LISTEN_FOR_TICKLES = "listen-for-tickles";
  private static final String XML_ATTR_NEXT_AUTHORITY_ID = "nextAuthorityId";
  private static final String XML_ATTR_SYNC_RANDOM_OFFSET = "offsetInSeconds";
  private static final String XML_ATTR_USER = "user";
  private static final String XML_TAG_LISTEN_FOR_TICKLES = "listenForTickles";
  private static HashMap<String, String> sAuthorityRenames;
  private static volatile SyncStorageEngine sSyncStorageEngine = null;
  private final AtomicFile mAccountInfoFile;
  private final HashMap<AccountAndUser, AccountInfo> mAccounts = new HashMap();
  private final SparseArray<AuthorityInfo> mAuthorities = new SparseArray();
  private final Calendar mCal;
  private final RemoteCallbackList<ISyncStatusObserver> mChangeListeners = new RemoteCallbackList();
  private final Context mContext;
  private final SparseArray<ArrayList<SyncInfo>> mCurrentSyncs = new SparseArray();
  private final DayStats[] mDayStats = new DayStats[28];
  private boolean mDefaultMasterSyncAutomatically;
  private SparseArray<Boolean> mMasterSyncAutomatically = new SparseArray();
  private int mNextAuthorityId = 0;
  private int mNextHistoryId = 0;
  private int mNumPendingFinished = 0;
  private final AtomicFile mPendingFile;
  private final ArrayList<PendingOperation> mPendingOperations = new ArrayList();
  private final AtomicFile mStatisticsFile;
  private final AtomicFile mStatusFile;
  private final ArrayList<SyncHistoryItem> mSyncHistory = new ArrayList();
  private int mSyncRandomOffset;
  private OnSyncRequestListener mSyncRequestListener;
  private final SparseArray<SyncStatusInfo> mSyncStatus = new SparseArray();
  private int mYear;
  private int mYearInDays;
  
  static
  {
    SOURCES = new String[] { "SERVER", "LOCAL", "POLL", "USER", "PERIODIC" };
    sAuthorityRenames = new HashMap();
    sAuthorityRenames.put("contacts", "com.android.contacts");
    sAuthorityRenames.put("calendar", "com.android.calendar");
  }
  
  private SyncStorageEngine(Context paramContext, File paramFile)
  {
    this.mContext = paramContext;
    sSyncStorageEngine = this;
    this.mCal = Calendar.getInstance(TimeZone.getTimeZone("GMT+0"));
    this.mDefaultMasterSyncAutomatically = this.mContext.getResources().getBoolean(17891396);
    File localFile = new File(new File(paramFile, "system"), "sync");
    localFile.mkdirs();
    this.mAccountInfoFile = new AtomicFile(new File(localFile, "accounts.xml"));
    this.mStatusFile = new AtomicFile(new File(localFile, "status.bin"));
    this.mPendingFile = new AtomicFile(new File(localFile, "pending.bin"));
    this.mStatisticsFile = new AtomicFile(new File(localFile, "stats.bin"));
    readAccountInfoLocked();
    readStatusLocked();
    readPendingOperationsLocked();
    readStatisticsLocked();
    readAndDeleteLegacyAccountInfoLocked();
    writeAccountInfoLocked();
    writeStatusLocked();
    writePendingOperationsLocked();
    writeStatisticsLocked();
  }
  
  private void appendPendingOperationLocked(PendingOperation paramPendingOperation)
  {
    try
    {
      FileOutputStream localFileOutputStream = this.mPendingFile.openAppend();
      try
      {
        Parcel localParcel;
        localFileOutputStream.close();
        throw ((Throwable)localObject);
      }
      catch (IOException localIOException2)
      {
        for (;;) {}
      }
    }
    catch (IOException localIOException3)
    {
      for (;;)
      {
        try
        {
          localParcel = Parcel.obtain();
          writePendingOperationLocked(paramPendingOperation, localParcel);
          localFileOutputStream.write(localParcel.marshall());
          localParcel.recycle();
        }
        catch (IOException localIOException3)
        {
          localIOException3 = localIOException3;
          Log.w("SyncManager", "Error writing pending operations", localIOException3);
          localFileOutputStream.close();
          return;
        }
        finally {}
        try
        {
          localFileOutputStream.close();
          return;
        }
        catch (IOException localIOException4)
        {
          return;
        }
      }
      localIOException1 = localIOException1;
      writePendingOperationsLocked();
      return;
    }
  }
  
  public static boolean equals(Bundle paramBundle1, Bundle paramBundle2)
  {
    if (paramBundle1.size() != paramBundle2.size()) {
      return false;
    }
    if (paramBundle1.isEmpty()) {
      return true;
    }
    Iterator localIterator = paramBundle1.keySet().iterator();
    for (;;)
    {
      if (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        if (!paramBundle2.containsKey(str)) {
          break;
        }
        if (!paramBundle1.get(str).equals(paramBundle2.get(str))) {
          return false;
        }
      }
    }
    return true;
  }
  
  private static byte[] flattenBundle(Bundle paramBundle)
  {
    Parcel localParcel = Parcel.obtain();
    try
    {
      paramBundle.writeToParcel(localParcel, 0);
      byte[] arrayOfByte = localParcel.marshall();
      return arrayOfByte;
    }
    finally
    {
      localParcel.recycle();
    }
  }
  
  private AuthorityInfo getAuthorityLocked(Account paramAccount, int paramInt, String paramString1, String paramString2)
  {
    AccountAndUser localAccountAndUser = new AccountAndUser(paramAccount, paramInt);
    AccountInfo localAccountInfo = (AccountInfo)this.mAccounts.get(localAccountAndUser);
    AuthorityInfo localAuthorityInfo;
    if (localAccountInfo == null)
    {
      if ((paramString2 != null) && (Log.isLoggable("SyncManager", 2))) {
        Log.v("SyncManager", paramString2 + ": unknown account " + localAccountAndUser);
      }
      localAuthorityInfo = null;
    }
    do
    {
      return localAuthorityInfo;
      localAuthorityInfo = (AuthorityInfo)localAccountInfo.authorities.get(paramString1);
    } while (localAuthorityInfo != null);
    if ((paramString2 != null) && (Log.isLoggable("SyncManager", 2))) {
      Log.v("SyncManager", paramString2 + ": unknown authority " + paramString1);
    }
    return null;
  }
  
  private int getCurrentDayLocked()
  {
    this.mCal.setTimeInMillis(System.currentTimeMillis());
    int i = this.mCal.get(6);
    if (this.mYear != this.mCal.get(1))
    {
      this.mYear = this.mCal.get(1);
      this.mCal.clear();
      this.mCal.set(1, this.mYear);
      this.mYearInDays = ((int)(this.mCal.getTimeInMillis() / 86400000L));
    }
    return i + this.mYearInDays;
  }
  
  static int getIntColumn(Cursor paramCursor, String paramString)
  {
    return paramCursor.getInt(paramCursor.getColumnIndex(paramString));
  }
  
  static long getLongColumn(Cursor paramCursor, String paramString)
  {
    return paramCursor.getLong(paramCursor.getColumnIndex(paramString));
  }
  
  private AuthorityInfo getOrCreateAuthorityLocked(Account paramAccount, int paramInt1, String paramString, int paramInt2, boolean paramBoolean)
  {
    AccountAndUser localAccountAndUser = new AccountAndUser(paramAccount, paramInt1);
    AccountInfo localAccountInfo = (AccountInfo)this.mAccounts.get(localAccountAndUser);
    if (localAccountInfo == null)
    {
      localAccountInfo = new AccountInfo(localAccountAndUser);
      this.mAccounts.put(localAccountAndUser, localAccountInfo);
    }
    AuthorityInfo localAuthorityInfo = (AuthorityInfo)localAccountInfo.authorities.get(paramString);
    if (localAuthorityInfo == null)
    {
      if (paramInt2 < 0)
      {
        paramInt2 = this.mNextAuthorityId;
        this.mNextAuthorityId = (1 + this.mNextAuthorityId);
        paramBoolean = true;
      }
      if (Log.isLoggable("SyncManager", 2)) {
        Log.v("SyncManager", "created a new AuthorityInfo for " + paramAccount + ", user " + paramInt1 + ", provider " + paramString);
      }
      localAuthorityInfo = new AuthorityInfo(paramAccount, paramInt1, paramString, paramInt2);
      localAccountInfo.authorities.put(paramString, localAuthorityInfo);
      this.mAuthorities.put(paramInt2, localAuthorityInfo);
      if (paramBoolean) {
        writeAccountInfoLocked();
      }
    }
    return localAuthorityInfo;
  }
  
  private SyncStatusInfo getOrCreateSyncStatusLocked(int paramInt)
  {
    SyncStatusInfo localSyncStatusInfo = (SyncStatusInfo)this.mSyncStatus.get(paramInt);
    if (localSyncStatusInfo == null)
    {
      localSyncStatusInfo = new SyncStatusInfo(paramInt);
      this.mSyncStatus.put(paramInt, localSyncStatusInfo);
    }
    return localSyncStatusInfo;
  }
  
  public static SyncStorageEngine getSingleton()
  {
    if (sSyncStorageEngine == null) {
      throw new IllegalStateException("not initialized");
    }
    return sSyncStorageEngine;
  }
  
  public static void init(Context paramContext)
  {
    if (sSyncStorageEngine != null) {
      return;
    }
    sSyncStorageEngine = new SyncStorageEngine(paramContext, Environment.getSecureDataDirectory());
  }
  
  private boolean maybeMigrateSettingsForRenamedAuthorities()
  {
    boolean bool = false;
    ArrayList localArrayList = new ArrayList();
    int i = this.mAuthorities.size();
    int j = 0;
    if (j < i)
    {
      AuthorityInfo localAuthorityInfo2 = (AuthorityInfo)this.mAuthorities.valueAt(j);
      String str = (String)sAuthorityRenames.get(localAuthorityInfo2.authority);
      if (str == null) {}
      for (;;)
      {
        j++;
        break;
        localArrayList.add(localAuthorityInfo2);
        if ((localAuthorityInfo2.enabled) && (getAuthorityLocked(localAuthorityInfo2.account, localAuthorityInfo2.userId, str, "cleanup") == null))
        {
          getOrCreateAuthorityLocked(localAuthorityInfo2.account, localAuthorityInfo2.userId, str, -1, false).enabled = true;
          bool = true;
        }
      }
    }
    Iterator localIterator = localArrayList.iterator();
    while (localIterator.hasNext())
    {
      AuthorityInfo localAuthorityInfo1 = (AuthorityInfo)localIterator.next();
      removeAuthorityLocked(localAuthorityInfo1.account, localAuthorityInfo1.userId, localAuthorityInfo1.authority, false);
      bool = true;
    }
    return bool;
  }
  
  public static SyncStorageEngine newTestInstance(Context paramContext)
  {
    return new SyncStorageEngine(paramContext, paramContext.getFilesDir());
  }
  
  private AuthorityInfo parseAuthority(XmlPullParser paramXmlPullParser, int paramInt)
  {
    int i = -1;
    try
    {
      int m = Integer.parseInt(paramXmlPullParser.getAttributeValue(null, "id"));
      i = m;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      for (;;)
      {
        String str5;
        Log.e("SyncManager", "error parsing the id of the authority", localNumberFormatException);
      }
    }
    catch (NullPointerException localNullPointerException)
    {
      String str1;
      String str2;
      String str3;
      String str4;
      for (;;)
      {
        String str6;
        Log.e("SyncManager", "the id of the authority is null", localNullPointerException);
        continue;
        int j = Integer.parseInt(str6);
        continue;
        boolean bool = false;
      }
      if ((str3 != null) && (!Boolean.parseBoolean(str3))) {
        break label295;
      }
      for (int k = 1;; k = 0)
      {
        localAuthorityInfo.syncable = k;
        return localAuthorityInfo;
      }
      Log.w("SyncManager", "Failure adding authority: account=" + str4 + " auth=" + str1 + " enabled=" + str2 + " syncable=" + str3);
    }
    AuthorityInfo localAuthorityInfo = null;
    if (i >= 0)
    {
      str1 = paramXmlPullParser.getAttributeValue(null, "authority");
      str2 = paramXmlPullParser.getAttributeValue(null, "enabled");
      str3 = paramXmlPullParser.getAttributeValue(null, "syncable");
      str4 = paramXmlPullParser.getAttributeValue(null, "account");
      str5 = paramXmlPullParser.getAttributeValue(null, "type");
      str6 = paramXmlPullParser.getAttributeValue(null, "user");
      if (str6 == null)
      {
        j = 0;
        if (str5 == null)
        {
          str5 = "com.google";
          str3 = "unknown";
        }
        localAuthorityInfo = (AuthorityInfo)this.mAuthorities.get(i);
        if (localAuthorityInfo == null)
        {
          localAuthorityInfo = getOrCreateAuthorityLocked(new Account(str4, str5), j, str1, i, false);
          if (paramInt > 0) {
            localAuthorityInfo.periodicSyncs.clear();
          }
        }
        if (localAuthorityInfo == null) {
          break label301;
        }
        if ((str2 != null) && (!Boolean.parseBoolean(str2))) {
          break label263;
        }
        bool = true;
        localAuthorityInfo.enabled = bool;
        if (!"unknown".equals(str3)) {
          break label269;
        }
        localAuthorityInfo.syncable = -1;
      }
    }
    else
    {
      return localAuthorityInfo;
    }
    label263:
    label269:
    label295:
    label301:
    return localAuthorityInfo;
  }
  
  private void parseExtra(XmlPullParser paramXmlPullParser, Pair<Bundle, Long> paramPair)
  {
    Bundle localBundle = (Bundle)paramPair.first;
    String str1 = paramXmlPullParser.getAttributeValue(null, "name");
    String str2 = paramXmlPullParser.getAttributeValue(null, "type");
    String str3 = paramXmlPullParser.getAttributeValue(null, "value1");
    String str4 = paramXmlPullParser.getAttributeValue(null, "value2");
    try
    {
      if ("long".equals(str2))
      {
        localBundle.putLong(str1, Long.parseLong(str3));
        return;
      }
      if ("integer".equals(str2))
      {
        localBundle.putInt(str1, Integer.parseInt(str3));
        return;
      }
    }
    catch (NumberFormatException localNumberFormatException)
    {
      Log.e("SyncManager", "error parsing bundle value", localNumberFormatException);
      return;
      if ("double".equals(str2))
      {
        localBundle.putDouble(str1, Double.parseDouble(str3));
        return;
      }
    }
    catch (NullPointerException localNullPointerException)
    {
      Log.e("SyncManager", "error parsing bundle value", localNullPointerException);
      return;
    }
    if ("float".equals(str2))
    {
      localBundle.putFloat(str1, Float.parseFloat(str3));
      return;
    }
    if ("boolean".equals(str2))
    {
      localBundle.putBoolean(str1, Boolean.parseBoolean(str3));
      return;
    }
    if ("string".equals(str2))
    {
      localBundle.putString(str1, str3);
      return;
    }
    if ("account".equals(str2)) {
      localBundle.putParcelable(str1, new Account(str3, str4));
    }
  }
  
  private void parseListenForTickles(XmlPullParser paramXmlPullParser)
  {
    String str1 = paramXmlPullParser.getAttributeValue(null, "user");
    try
    {
      int j = Integer.parseInt(str1);
      i = j;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      for (;;)
      {
        String str2;
        Log.e("SyncManager", "error parsing the user for listen-for-tickles", localNumberFormatException);
        i = 0;
      }
    }
    catch (NullPointerException localNullPointerException)
    {
      for (;;)
      {
        Log.e("SyncManager", "the user in listen-for-tickles is null", localNullPointerException);
        int i = 0;
        continue;
        boolean bool = false;
      }
    }
    str2 = paramXmlPullParser.getAttributeValue(null, "enabled");
    if ((str2 == null) || (Boolean.parseBoolean(str2)))
    {
      bool = true;
      this.mMasterSyncAutomatically.put(i, Boolean.valueOf(bool));
      return;
    }
  }
  
  private Pair<Bundle, Long> parsePeriodicSync(XmlPullParser paramXmlPullParser, AuthorityInfo paramAuthorityInfo)
  {
    Bundle localBundle = new Bundle();
    String str = paramXmlPullParser.getAttributeValue(null, "period");
    try
    {
      long l = Long.parseLong(str);
      Pair localPair = Pair.create(localBundle, Long.valueOf(l));
      paramAuthorityInfo.periodicSyncs.add(localPair);
      return localPair;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      Log.e("SyncManager", "error parsing the period of a periodic sync", localNumberFormatException);
      return null;
    }
    catch (NullPointerException localNullPointerException)
    {
      Log.e("SyncManager", "the period of a periodic sync is null", localNullPointerException);
    }
    return null;
  }
  
  /* Error */
  private void readAccountInfoLocked()
  {
    // Byte code:
    //   0: iconst_m1
    //   1: istore_1
    //   2: aconst_null
    //   3: astore_2
    //   4: aload_0
    //   5: getfield 270	android/content/SyncStorageEngine:mAccountInfoFile	Landroid/util/AtomicFile;
    //   8: invokevirtual 741	android/util/AtomicFile:openRead	()Ljava/io/FileInputStream;
    //   11: astore_2
    //   12: invokestatic 747	android/util/Xml:newPullParser	()Lorg/xmlpull/v1/XmlPullParser;
    //   15: astore 11
    //   17: aload 11
    //   19: aload_2
    //   20: aconst_null
    //   21: invokeinterface 751 3 0
    //   26: aload 11
    //   28: invokeinterface 754 1 0
    //   33: istore 12
    //   35: iload 12
    //   37: iconst_2
    //   38: if_icmpeq +15 -> 53
    //   41: aload 11
    //   43: invokeinterface 756 1 0
    //   48: istore 12
    //   50: goto -15 -> 35
    //   53: ldc_w 758
    //   56: aload 11
    //   58: invokeinterface 761 1 0
    //   63: invokevirtual 617	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   66: ifeq +258 -> 324
    //   69: aload 11
    //   71: aconst_null
    //   72: ldc 70
    //   74: invokeinterface 587 3 0
    //   79: astore 15
    //   81: aload 11
    //   83: aconst_null
    //   84: ldc_w 763
    //   87: invokeinterface 587 3 0
    //   92: astore 16
    //   94: aload 16
    //   96: ifnonnull +256 -> 352
    //   99: iconst_0
    //   100: istore 18
    //   102: aload 11
    //   104: aconst_null
    //   105: ldc 73
    //   107: invokeinterface 587 3 0
    //   112: astore 19
    //   114: aload 19
    //   116: ifnonnull +258 -> 374
    //   119: iconst_0
    //   120: istore 34
    //   122: aload_0
    //   123: aload_0
    //   124: getfield 205	android/content/SyncStorageEngine:mNextAuthorityId	I
    //   127: iload 34
    //   129: invokestatic 769	java/lang/Math:max	(II)I
    //   132: putfield 205	android/content/SyncStorageEngine:mNextAuthorityId	I
    //   135: aload 11
    //   137: aconst_null
    //   138: ldc 76
    //   140: invokeinterface 587 3 0
    //   145: astore 21
    //   147: aload 21
    //   149: ifnonnull +239 -> 388
    //   152: iconst_0
    //   153: istore 32
    //   155: aload_0
    //   156: iload 32
    //   158: putfield 771	android/content/SyncStorageEngine:mSyncRandomOffset	I
    //   161: aload_0
    //   162: getfield 771	android/content/SyncStorageEngine:mSyncRandomOffset	I
    //   165: ifne +23 -> 188
    //   168: aload_0
    //   169: new 773	java/util/Random
    //   172: dup
    //   173: invokestatic 450	java/lang/System:currentTimeMillis	()J
    //   176: invokespecial 775	java/util/Random:<init>	(J)V
    //   179: ldc_w 776
    //   182: invokevirtual 779	java/util/Random:nextInt	(I)I
    //   185: putfield 771	android/content/SyncStorageEngine:mSyncRandomOffset	I
    //   188: aload_0
    //   189: getfield 215	android/content/SyncStorageEngine:mMasterSyncAutomatically	Landroid/util/SparseArray;
    //   192: astore 23
    //   194: aload 15
    //   196: ifnull +450 -> 646
    //   199: aload 15
    //   201: invokestatic 616	java/lang/Boolean:parseBoolean	(Ljava/lang/String;)Z
    //   204: ifeq +247 -> 451
    //   207: goto +439 -> 646
    //   210: aload 23
    //   212: iconst_0
    //   213: iload 24
    //   215: invokestatic 715	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
    //   218: invokevirtual 510	android/util/SparseArray:put	(ILjava/lang/Object;)V
    //   221: aload 11
    //   223: invokeinterface 756 1 0
    //   228: istore 25
    //   230: aconst_null
    //   231: astore 26
    //   233: aconst_null
    //   234: astore 27
    //   236: iload 25
    //   238: iconst_2
    //   239: if_icmpne +66 -> 305
    //   242: aload 11
    //   244: invokeinterface 761 1 0
    //   249: astore 28
    //   251: aload 11
    //   253: invokeinterface 782 1 0
    //   258: iconst_2
    //   259: if_icmpne +255 -> 514
    //   262: ldc_w 593
    //   265: aload 28
    //   267: invokevirtual 617	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   270: ifeq +187 -> 457
    //   273: aload_0
    //   274: aload 11
    //   276: iload 18
    //   278: invokespecial 784	android/content/SyncStorageEngine:parseAuthority	(Lorg/xmlpull/v1/XmlPullParser;I)Landroid/content/SyncStorageEngine$AuthorityInfo;
    //   281: astore 26
    //   283: aload 26
    //   285: getfield 787	android/content/SyncStorageEngine$AuthorityInfo:ident	I
    //   288: istore 30
    //   290: aconst_null
    //   291: astore 27
    //   293: iload 30
    //   295: iload_1
    //   296: if_icmple +9 -> 305
    //   299: aload 26
    //   301: getfield 787	android/content/SyncStorageEngine$AuthorityInfo:ident	I
    //   304: istore_1
    //   305: aload 11
    //   307: invokeinterface 756 1 0
    //   312: istore 29
    //   314: iload 29
    //   316: istore 25
    //   318: iload 25
    //   320: iconst_1
    //   321: if_icmpne -85 -> 236
    //   324: aload_0
    //   325: iload_1
    //   326: iconst_1
    //   327: iadd
    //   328: aload_0
    //   329: getfield 205	android/content/SyncStorageEngine:mNextAuthorityId	I
    //   332: invokestatic 769	java/lang/Math:max	(II)I
    //   335: putfield 205	android/content/SyncStorageEngine:mNextAuthorityId	I
    //   338: aload_2
    //   339: ifnull +7 -> 346
    //   342: aload_2
    //   343: invokevirtual 790	java/io/FileInputStream:close	()V
    //   346: aload_0
    //   347: invokespecial 792	android/content/SyncStorageEngine:maybeMigrateSettingsForRenamedAuthorities	()Z
    //   350: pop
    //   351: return
    //   352: aload 16
    //   354: invokestatic 592	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   357: istore 35
    //   359: iload 35
    //   361: istore 18
    //   363: goto -261 -> 102
    //   366: astore 17
    //   368: iconst_0
    //   369: istore 18
    //   371: goto -269 -> 102
    //   374: aload 19
    //   376: invokestatic 592	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   379: istore 33
    //   381: iload 33
    //   383: istore 34
    //   385: goto -263 -> 122
    //   388: aload 21
    //   390: invokestatic 592	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   393: istore 31
    //   395: iload 31
    //   397: istore 32
    //   399: goto -244 -> 155
    //   402: astore 22
    //   404: aload_0
    //   405: iconst_0
    //   406: putfield 771	android/content/SyncStorageEngine:mSyncRandomOffset	I
    //   409: goto -248 -> 161
    //   412: astore 9
    //   414: ldc 58
    //   416: ldc_w 794
    //   419: aload 9
    //   421: invokestatic 351	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   424: pop
    //   425: aload_0
    //   426: iload_1
    //   427: iconst_1
    //   428: iadd
    //   429: aload_0
    //   430: getfield 205	android/content/SyncStorageEngine:mNextAuthorityId	I
    //   433: invokestatic 769	java/lang/Math:max	(II)I
    //   436: putfield 205	android/content/SyncStorageEngine:mNextAuthorityId	I
    //   439: aload_2
    //   440: ifnull -89 -> 351
    //   443: aload_2
    //   444: invokevirtual 790	java/io/FileInputStream:close	()V
    //   447: return
    //   448: astore 7
    //   450: return
    //   451: iconst_0
    //   452: istore 24
    //   454: goto -244 -> 210
    //   457: ldc 82
    //   459: aload 28
    //   461: invokevirtual 617	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   464: ifeq -159 -> 305
    //   467: aload_0
    //   468: aload 11
    //   470: invokespecial 796	android/content/SyncStorageEngine:parseListenForTickles	(Lorg/xmlpull/v1/XmlPullParser;)V
    //   473: goto -168 -> 305
    //   476: astore 5
    //   478: aload_2
    //   479: ifnonnull +138 -> 617
    //   482: ldc 58
    //   484: ldc_w 798
    //   487: invokestatic 801	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   490: pop
    //   491: aload_0
    //   492: iload_1
    //   493: iconst_1
    //   494: iadd
    //   495: aload_0
    //   496: getfield 205	android/content/SyncStorageEngine:mNextAuthorityId	I
    //   499: invokestatic 769	java/lang/Math:max	(II)I
    //   502: putfield 205	android/content/SyncStorageEngine:mNextAuthorityId	I
    //   505: aload_2
    //   506: ifnull -155 -> 351
    //   509: aload_2
    //   510: invokevirtual 790	java/io/FileInputStream:close	()V
    //   513: return
    //   514: aload 11
    //   516: invokeinterface 782 1 0
    //   521: iconst_3
    //   522: if_icmpne +32 -> 554
    //   525: ldc_w 803
    //   528: aload 28
    //   530: invokevirtual 617	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   533: ifeq -228 -> 305
    //   536: aload 26
    //   538: ifnull -233 -> 305
    //   541: aload_0
    //   542: aload 11
    //   544: aload 26
    //   546: invokespecial 805	android/content/SyncStorageEngine:parsePeriodicSync	(Lorg/xmlpull/v1/XmlPullParser;Landroid/content/SyncStorageEngine$AuthorityInfo;)Landroid/util/Pair;
    //   549: astore 27
    //   551: goto -246 -> 305
    //   554: aload 11
    //   556: invokeinterface 782 1 0
    //   561: iconst_4
    //   562: if_icmpne -257 -> 305
    //   565: aload 27
    //   567: ifnull -262 -> 305
    //   570: ldc_w 807
    //   573: aload 28
    //   575: invokevirtual 617	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   578: ifeq -273 -> 305
    //   581: aload_0
    //   582: aload 11
    //   584: aload 27
    //   586: invokespecial 809	android/content/SyncStorageEngine:parseExtra	(Lorg/xmlpull/v1/XmlPullParser;Landroid/util/Pair;)V
    //   589: goto -284 -> 305
    //   592: astore_3
    //   593: aload_0
    //   594: iload_1
    //   595: iconst_1
    //   596: iadd
    //   597: aload_0
    //   598: getfield 205	android/content/SyncStorageEngine:mNextAuthorityId	I
    //   601: invokestatic 769	java/lang/Math:max	(II)I
    //   604: putfield 205	android/content/SyncStorageEngine:mNextAuthorityId	I
    //   607: aload_2
    //   608: ifnull +7 -> 615
    //   611: aload_2
    //   612: invokevirtual 790	java/io/FileInputStream:close	()V
    //   615: aload_3
    //   616: athrow
    //   617: ldc 58
    //   619: ldc_w 794
    //   622: aload 5
    //   624: invokestatic 351	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   627: pop
    //   628: goto -137 -> 491
    //   631: astore 4
    //   633: goto -18 -> 615
    //   636: astore 14
    //   638: goto -292 -> 346
    //   641: astore 20
    //   643: goto -508 -> 135
    //   646: iconst_1
    //   647: istore 24
    //   649: goto -439 -> 210
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	652	0	this	SyncStorageEngine
    //   1	596	1	i	int
    //   3	609	2	localFileInputStream	java.io.FileInputStream
    //   592	24	3	localObject	Object
    //   631	1	4	localIOException1	IOException
    //   476	147	5	localIOException2	IOException
    //   448	1	7	localIOException3	IOException
    //   412	8	9	localXmlPullParserException	org.xmlpull.v1.XmlPullParserException
    //   15	568	11	localXmlPullParser	XmlPullParser
    //   33	16	12	j	int
    //   636	1	14	localIOException4	IOException
    //   79	121	15	str1	String
    //   92	261	16	str2	String
    //   366	1	17	localNumberFormatException1	NumberFormatException
    //   100	270	18	k	int
    //   112	263	19	str3	String
    //   641	1	20	localNumberFormatException2	NumberFormatException
    //   145	244	21	str4	String
    //   402	1	22	localNumberFormatException3	NumberFormatException
    //   192	19	23	localSparseArray	SparseArray
    //   213	435	24	bool	boolean
    //   228	94	25	m	int
    //   231	314	26	localAuthorityInfo	AuthorityInfo
    //   234	351	27	localPair	Pair
    //   249	325	28	str5	String
    //   312	3	29	n	int
    //   288	9	30	i1	int
    //   393	3	31	i2	int
    //   153	245	32	i3	int
    //   379	3	33	i4	int
    //   120	264	34	i5	int
    //   357	3	35	i6	int
    // Exception table:
    //   from	to	target	type
    //   352	359	366	java/lang/NumberFormatException
    //   155	161	402	java/lang/NumberFormatException
    //   388	395	402	java/lang/NumberFormatException
    //   4	35	412	org/xmlpull/v1/XmlPullParserException
    //   41	50	412	org/xmlpull/v1/XmlPullParserException
    //   53	94	412	org/xmlpull/v1/XmlPullParserException
    //   102	114	412	org/xmlpull/v1/XmlPullParserException
    //   122	135	412	org/xmlpull/v1/XmlPullParserException
    //   135	147	412	org/xmlpull/v1/XmlPullParserException
    //   155	161	412	org/xmlpull/v1/XmlPullParserException
    //   161	188	412	org/xmlpull/v1/XmlPullParserException
    //   188	194	412	org/xmlpull/v1/XmlPullParserException
    //   199	207	412	org/xmlpull/v1/XmlPullParserException
    //   210	230	412	org/xmlpull/v1/XmlPullParserException
    //   242	290	412	org/xmlpull/v1/XmlPullParserException
    //   299	305	412	org/xmlpull/v1/XmlPullParserException
    //   305	314	412	org/xmlpull/v1/XmlPullParserException
    //   352	359	412	org/xmlpull/v1/XmlPullParserException
    //   374	381	412	org/xmlpull/v1/XmlPullParserException
    //   388	395	412	org/xmlpull/v1/XmlPullParserException
    //   404	409	412	org/xmlpull/v1/XmlPullParserException
    //   457	473	412	org/xmlpull/v1/XmlPullParserException
    //   514	536	412	org/xmlpull/v1/XmlPullParserException
    //   541	551	412	org/xmlpull/v1/XmlPullParserException
    //   554	565	412	org/xmlpull/v1/XmlPullParserException
    //   570	589	412	org/xmlpull/v1/XmlPullParserException
    //   443	447	448	java/io/IOException
    //   509	513	448	java/io/IOException
    //   4	35	476	java/io/IOException
    //   41	50	476	java/io/IOException
    //   53	94	476	java/io/IOException
    //   102	114	476	java/io/IOException
    //   122	135	476	java/io/IOException
    //   135	147	476	java/io/IOException
    //   155	161	476	java/io/IOException
    //   161	188	476	java/io/IOException
    //   188	194	476	java/io/IOException
    //   199	207	476	java/io/IOException
    //   210	230	476	java/io/IOException
    //   242	290	476	java/io/IOException
    //   299	305	476	java/io/IOException
    //   305	314	476	java/io/IOException
    //   352	359	476	java/io/IOException
    //   374	381	476	java/io/IOException
    //   388	395	476	java/io/IOException
    //   404	409	476	java/io/IOException
    //   457	473	476	java/io/IOException
    //   514	536	476	java/io/IOException
    //   541	551	476	java/io/IOException
    //   554	565	476	java/io/IOException
    //   570	589	476	java/io/IOException
    //   4	35	592	finally
    //   41	50	592	finally
    //   53	94	592	finally
    //   102	114	592	finally
    //   122	135	592	finally
    //   135	147	592	finally
    //   155	161	592	finally
    //   161	188	592	finally
    //   188	194	592	finally
    //   199	207	592	finally
    //   210	230	592	finally
    //   242	290	592	finally
    //   299	305	592	finally
    //   305	314	592	finally
    //   352	359	592	finally
    //   374	381	592	finally
    //   388	395	592	finally
    //   404	409	592	finally
    //   414	425	592	finally
    //   457	473	592	finally
    //   482	491	592	finally
    //   514	536	592	finally
    //   541	551	592	finally
    //   554	565	592	finally
    //   570	589	592	finally
    //   617	628	592	finally
    //   611	615	631	java/io/IOException
    //   342	346	636	java/io/IOException
    //   122	135	641	java/lang/NumberFormatException
    //   374	381	641	java/lang/NumberFormatException
  }
  
  private void readAndDeleteLegacyAccountInfoLocked()
  {
    File localFile = this.mContext.getDatabasePath("syncmanager.db");
    if (!localFile.exists()) {}
    do
    {
      return;
      String str1 = localFile.getPath();
      try
      {
        SQLiteDatabase localSQLiteDatabase2 = SQLiteDatabase.openDatabase(str1, null, 1);
        localSQLiteDatabase1 = localSQLiteDatabase2;
      }
      catch (SQLiteException localSQLiteException)
      {
        for (;;)
        {
          int i;
          SQLiteQueryBuilder localSQLiteQueryBuilder1;
          HashMap localHashMap;
          Cursor localCursor1;
          String str6;
          AuthorityInfo localAuthorityInfo2;
          int k;
          SyncStatusInfo localSyncStatusInfo;
          int m;
          int i7;
          long l1;
          int n;
          int i1;
          int i2;
          int i3;
          int i4;
          int i5;
          long l2;
          int i6;
          long l3;
          String str8;
          boolean bool3;
          SQLiteQueryBuilder localSQLiteQueryBuilder2;
          Cursor localCursor2;
          SQLiteDatabase localSQLiteDatabase1 = null;
        }
      }
    } while (localSQLiteDatabase1 == null);
    if (localSQLiteDatabase1.getVersion() >= 11)
    {
      i = 1;
      localSQLiteQueryBuilder1 = new SQLiteQueryBuilder();
      localSQLiteQueryBuilder1.setTables("stats, status");
      localHashMap = new HashMap();
      localHashMap.put("_id", "status._id as _id");
      localHashMap.put("account", "stats.account as account");
      if (i != 0) {
        localHashMap.put("account_type", "stats.account_type as account_type");
      }
      localHashMap.put("authority", "stats.authority as authority");
      localHashMap.put("totalElapsedTime", "totalElapsedTime");
      localHashMap.put("numSyncs", "numSyncs");
      localHashMap.put("numSourceLocal", "numSourceLocal");
      localHashMap.put("numSourcePoll", "numSourcePoll");
      localHashMap.put("numSourceServer", "numSourceServer");
      localHashMap.put("numSourceUser", "numSourceUser");
      localHashMap.put("lastSuccessSource", "lastSuccessSource");
      localHashMap.put("lastSuccessTime", "lastSuccessTime");
      localHashMap.put("lastFailureSource", "lastFailureSource");
      localHashMap.put("lastFailureTime", "lastFailureTime");
      localHashMap.put("lastFailureMesg", "lastFailureMesg");
      localHashMap.put("pending", "pending");
      localSQLiteQueryBuilder1.setProjectionMap(localHashMap);
      localSQLiteQueryBuilder1.appendWhere("stats._id = status.stats_id");
      localCursor1 = localSQLiteQueryBuilder1.query(localSQLiteDatabase1, null, null, null, null, null, null);
      label307:
      label360:
      do
      {
        if (!localCursor1.moveToNext()) {
          break label750;
        }
        String str5 = localCursor1.getString(localCursor1.getColumnIndex("account"));
        if (i == 0) {
          break;
        }
        str6 = localCursor1.getString(localCursor1.getColumnIndex("account_type"));
        if (str6 == null) {
          str6 = "com.google";
        }
        String str7 = localCursor1.getString(localCursor1.getColumnIndex("authority"));
        localAuthorityInfo2 = getOrCreateAuthorityLocked(new Account(str5, str6), 0, str7, -1, false);
      } while (localAuthorityInfo2 == null);
      k = this.mSyncStatus.size();
      localSyncStatusInfo = null;
      do
      {
        m = 0;
        if (k <= 0) {
          break;
        }
        k--;
        localSyncStatusInfo = (SyncStatusInfo)this.mSyncStatus.valueAt(k);
      } while (localSyncStatusInfo.authorityId != localAuthorityInfo2.ident);
      m = 1;
      if (m == 0)
      {
        i7 = localAuthorityInfo2.ident;
        localSyncStatusInfo = new SyncStatusInfo(i7);
        this.mSyncStatus.put(localAuthorityInfo2.ident, localSyncStatusInfo);
      }
      l1 = getLongColumn(localCursor1, "totalElapsedTime");
      localSyncStatusInfo.totalElapsedTime = l1;
      n = getIntColumn(localCursor1, "numSyncs");
      localSyncStatusInfo.numSyncs = n;
      i1 = getIntColumn(localCursor1, "numSourceLocal");
      localSyncStatusInfo.numSourceLocal = i1;
      i2 = getIntColumn(localCursor1, "numSourcePoll");
      localSyncStatusInfo.numSourcePoll = i2;
      i3 = getIntColumn(localCursor1, "numSourceServer");
      localSyncStatusInfo.numSourceServer = i3;
      i4 = getIntColumn(localCursor1, "numSourceUser");
      localSyncStatusInfo.numSourceUser = i4;
      localSyncStatusInfo.numSourcePeriodic = 0;
      i5 = getIntColumn(localCursor1, "lastSuccessSource");
      localSyncStatusInfo.lastSuccessSource = i5;
      l2 = getLongColumn(localCursor1, "lastSuccessTime");
      localSyncStatusInfo.lastSuccessTime = l2;
      i6 = getIntColumn(localCursor1, "lastFailureSource");
      localSyncStatusInfo.lastFailureSource = i6;
      l3 = getLongColumn(localCursor1, "lastFailureTime");
      localSyncStatusInfo.lastFailureTime = l3;
      str8 = localCursor1.getString(localCursor1.getColumnIndex("lastFailureMesg"));
      localSyncStatusInfo.lastFailureMesg = str8;
      if (getIntColumn(localCursor1, "pending") == 0) {
        break label744;
      }
    }
    label744:
    for (bool3 = true;; bool3 = false)
    {
      localSyncStatusInfo.pending = bool3;
      break label307;
      i = 0;
      break;
      str6 = null;
      break label360;
    }
    label750:
    localCursor1.close();
    localSQLiteQueryBuilder2 = new SQLiteQueryBuilder();
    localSQLiteQueryBuilder2.setTables("settings");
    localCursor2 = localSQLiteQueryBuilder2.query(localSQLiteDatabase1, null, null, null, null, null, null);
    while (localCursor2.moveToNext())
    {
      String str2 = localCursor2.getString(localCursor2.getColumnIndex("name"));
      String str3 = localCursor2.getString(localCursor2.getColumnIndex("value"));
      if (str2 != null)
      {
        if (str2.equals("listen_for_tickles"))
        {
          if ((str3 == null) || (Boolean.parseBoolean(str3))) {}
          for (boolean bool2 = true;; bool2 = false)
          {
            setMasterSyncAutomatically(bool2, 0);
            break;
          }
        }
        if (str2.startsWith("sync_provider_"))
        {
          String str4 = str2.substring("sync_provider_".length(), str2.length());
          int j = this.mAuthorities.size();
          label923:
          AuthorityInfo localAuthorityInfo1;
          while (j > 0)
          {
            j--;
            localAuthorityInfo1 = (AuthorityInfo)this.mAuthorities.valueAt(j);
            if (localAuthorityInfo1.authority.equals(str4)) {
              if ((str3 != null) && (!Boolean.parseBoolean(str3))) {
                break label990;
              }
            }
          }
          label990:
          for (boolean bool1 = true;; bool1 = false)
          {
            localAuthorityInfo1.enabled = bool1;
            localAuthorityInfo1.syncable = 1;
            break label923;
            break;
          }
        }
      }
    }
    localCursor2.close();
    localSQLiteDatabase1.close();
    new File(str1).delete();
  }
  
  private void readPendingOperationsLocked()
  {
    for (;;)
    {
      try
      {
        byte[] arrayOfByte1 = this.mPendingFile.readFully();
        Parcel localParcel = Parcel.obtain();
        localParcel.unmarshall(arrayOfByte1, 0, arrayOfByte1.length);
        localParcel.setDataPosition(0);
        int i = localParcel.dataSize();
        if (localParcel.dataPosition() >= i) {
          break;
        }
        int j = localParcel.readInt();
        if ((j != 2) && (j != 1))
        {
          Log.w("SyncManager", "Unknown pending operation version " + j + "; dropping all ops");
          return;
        }
        int k = localParcel.readInt();
        int m = localParcel.readInt();
        byte[] arrayOfByte2 = localParcel.createByteArray();
        if (j != 2) {
          break label241;
        }
        if (localParcel.readInt() != 0)
        {
          bool = true;
          AuthorityInfo localAuthorityInfo = (AuthorityInfo)this.mAuthorities.get(k);
          if (localAuthorityInfo == null) {
            continue;
          }
          if (arrayOfByte2 == null) {
            break label247;
          }
          localBundle = unflattenBundle(arrayOfByte2);
          PendingOperation localPendingOperation = new PendingOperation(localAuthorityInfo.account, localAuthorityInfo.userId, m, localAuthorityInfo.authority, localBundle, bool);
          localPendingOperation.authorityId = k;
          localPendingOperation.flatExtras = arrayOfByte2;
          this.mPendingOperations.add(localPendingOperation);
          continue;
        }
        bool = false;
      }
      catch (IOException localIOException)
      {
        Log.i("SyncManager", "No initial pending operations");
        return;
      }
      continue;
      label241:
      boolean bool = false;
      continue;
      label247:
      Bundle localBundle = new Bundle();
    }
  }
  
  private void readStatisticsLocked()
  {
    try
    {
      byte[] arrayOfByte = this.mStatisticsFile.readFully();
      Parcel localParcel = Parcel.obtain();
      localParcel.unmarshall(arrayOfByte, 0, arrayOfByte.length);
      localParcel.setDataPosition(0);
      int i = 0;
      int j;
      for (;;)
      {
        j = localParcel.readInt();
        if (j == 0) {
          break label186;
        }
        if ((j != 101) && (j != 100)) {
          break;
        }
        int k = localParcel.readInt();
        if (j == 100) {
          k = 14245 + (k - 2009);
        }
        DayStats localDayStats = new DayStats(k);
        localDayStats.successCount = localParcel.readInt();
        localDayStats.successTime = localParcel.readLong();
        localDayStats.failureCount = localParcel.readInt();
        localDayStats.failureTime = localParcel.readLong();
        if (i < this.mDayStats.length)
        {
          this.mDayStats[i] = localDayStats;
          i++;
        }
      }
      Log.w("SyncManager", "Unknown stats token: " + j);
      label186:
      return;
    }
    catch (IOException localIOException)
    {
      Log.i("SyncManager", "No initial statistics");
    }
  }
  
  private void readStatusLocked()
  {
    int i;
    try
    {
      byte[] arrayOfByte = this.mStatusFile.readFully();
      Parcel localParcel = Parcel.obtain();
      localParcel.unmarshall(arrayOfByte, 0, arrayOfByte.length);
      localParcel.setDataPosition(0);
      for (;;)
      {
        i = localParcel.readInt();
        if (i == 0) {
          break;
        }
        if (i != 100) {
          break label107;
        }
        SyncStatusInfo localSyncStatusInfo = new SyncStatusInfo(localParcel);
        if (this.mAuthorities.indexOfKey(localSyncStatusInfo.authorityId) >= 0)
        {
          localSyncStatusInfo.pending = false;
          this.mSyncStatus.put(localSyncStatusInfo.authorityId, localSyncStatusInfo);
        }
      }
      return;
    }
    catch (IOException localIOException)
    {
      Log.i("SyncManager", "No initial status");
    }
    label107:
    Log.w("SyncManager", "Unknown status token: " + i);
  }
  
  private void removeAuthorityLocked(Account paramAccount, int paramInt, String paramString, boolean paramBoolean)
  {
    AccountInfo localAccountInfo = (AccountInfo)this.mAccounts.get(new AccountAndUser(paramAccount, paramInt));
    if (localAccountInfo != null)
    {
      AuthorityInfo localAuthorityInfo = (AuthorityInfo)localAccountInfo.authorities.remove(paramString);
      if (localAuthorityInfo != null)
      {
        this.mAuthorities.remove(localAuthorityInfo.ident);
        if (paramBoolean) {
          writeAccountInfoLocked();
        }
      }
    }
  }
  
  private void reportChange(int paramInt)
  {
    synchronized (this.mAuthorities)
    {
      int i = this.mChangeListeners.beginBroadcast();
      int j = i;
      for (localObject3 = null; j > 0; localObject3 = localObject4)
      {
        label23:
        j--;
        try
        {
          if ((paramInt & ((Integer)this.mChangeListeners.getBroadcastCookie(j)).intValue()) == 0) {
            break label23;
          }
          if (localObject3 != null) {
            break label201;
          }
          localObject4 = new ArrayList(j);
        }
        finally
        {
          for (;;)
          {
            int k;
            continue;
            Object localObject4 = localObject3;
          }
        }
        ((ArrayList)localObject4).add(this.mChangeListeners.getBroadcastItem(j));
      }
      this.mChangeListeners.finishBroadcast();
      if (Log.isLoggable("SyncManager", 2)) {
        Log.v("SyncManager", "reportChange " + paramInt + " to: " + localObject3);
      }
      if (localObject3 != null)
      {
        k = ((ArrayList)localObject3).size();
        for (;;)
        {
          if (k > 0)
          {
            k--;
            try
            {
              ((ISyncStatusObserver)((ArrayList)localObject3).get(k)).onStatusChanged(paramInt);
            }
            catch (RemoteException localRemoteException) {}
          }
        }
      }
    }
  }
  
  private void requestSync(Account paramAccount, int paramInt, String paramString, Bundle paramBundle)
  {
    if ((Process.myUid() == 1000) && (this.mSyncRequestListener != null))
    {
      this.mSyncRequestListener.onSyncRequest(paramAccount, paramInt, paramString, paramBundle);
      return;
    }
    ContentResolver.requestSync(paramAccount, paramString, paramBundle);
  }
  
  private static Bundle unflattenBundle(byte[] paramArrayOfByte)
  {
    localParcel = Parcel.obtain();
    try
    {
      localParcel.unmarshall(paramArrayOfByte, 0, paramArrayOfByte.length);
      localParcel.setDataPosition(0);
      Bundle localBundle2 = localParcel.readBundle();
      localBundle1 = localBundle2;
    }
    catch (RuntimeException localRuntimeException)
    {
      for (;;)
      {
        Bundle localBundle1 = new Bundle();
      }
    }
    finally
    {
      localParcel.recycle();
    }
    localParcel.recycle();
    return localBundle1;
  }
  
  private void updateOrRemovePeriodicSync(Account paramAccount, int paramInt, String paramString, Bundle paramBundle, long paramLong, boolean paramBoolean)
  {
    if (paramLong <= 0L) {
      paramLong = 0L;
    }
    if (paramBundle == null) {
      paramBundle = new Bundle();
    }
    if (Log.isLoggable("SyncManager", 2)) {
      Log.v("SyncManager", "addOrRemovePeriodicSync: " + paramAccount + ", user " + paramInt + ", provider " + paramString + " -> period " + paramLong + ", extras " + paramBundle);
    }
    SparseArray localSparseArray = this.mAuthorities;
    try
    {
      localAuthorityInfo = getOrCreateAuthorityLocked(paramAccount, paramInt, paramString, -1, false);
      if (paramBoolean)
      {
        k = 0;
        int m = localAuthorityInfo.periodicSyncs.size();
        n = 0;
        if (k < m)
        {
          Pair localPair = (Pair)localAuthorityInfo.periodicSyncs.get(k);
          if (!equals((Bundle)localPair.first, paramBundle)) {
            break label317;
          }
          long l = ((Long)localPair.second).longValue();
          if (l != paramLong) {}
        }
      }
    }
    finally
    {
      AuthorityInfo localAuthorityInfo;
      int k;
      int n;
      ArrayList localArrayList1;
      Long localLong1;
      ArrayList localArrayList2;
      Long localLong2;
      writeAccountInfoLocked();
      writeStatusLocked();
    }
    try
    {
      writeAccountInfoLocked();
      writeStatusLocked();
      return;
    }
    finally {}
    localArrayList1 = localAuthorityInfo.periodicSyncs;
    localLong1 = Long.valueOf(paramLong);
    localArrayList1.set(k, Pair.create(paramBundle, localLong1));
    n = 1;
    if (n == 0)
    {
      localArrayList2 = localAuthorityInfo.periodicSyncs;
      localLong2 = Long.valueOf(paramLong);
      localArrayList2.add(Pair.create(paramBundle, localLong2));
      getOrCreateSyncStatusLocked(localAuthorityInfo.ident).setPeriodicSyncTime(-1 + localAuthorityInfo.periodicSyncs.size(), 0L);
    }
    label317:
    int i;
    do
    {
      writeAccountInfoLocked();
      writeStatusLocked();
      reportChange(1);
      return;
      k++;
      break;
      SyncStatusInfo localSyncStatusInfo = (SyncStatusInfo)this.mSyncStatus.get(localAuthorityInfo.ident);
      i = 0;
      Iterator localIterator = localAuthorityInfo.periodicSyncs.iterator();
      int j = 0;
      while (localIterator.hasNext()) {
        if (equals((Bundle)((Pair)localIterator.next()).first, paramBundle))
        {
          localIterator.remove();
          i = 1;
          if (localSyncStatusInfo != null) {
            localSyncStatusInfo.removePeriodicSyncTime(j);
          }
        }
        else
        {
          j++;
        }
      }
    } while (i != 0);
    writeAccountInfoLocked();
    writeStatusLocked();
  }
  
  private void writeAccountInfoLocked()
  {
    FileOutputStream localFileOutputStream = null;
    FastXmlSerializer localFastXmlSerializer;
    int n;
    label407:
    label417:
    Object localObject;
    try
    {
      localFileOutputStream = this.mAccountInfoFile.startWrite();
      localFastXmlSerializer = new FastXmlSerializer();
      localFastXmlSerializer.setOutput(localFileOutputStream, "utf-8");
      localFastXmlSerializer.startDocument(null, Boolean.valueOf(true));
      localFastXmlSerializer.setFeature("http://xmlpull.org/v1/doc/features.html#indent-output", true);
      localFastXmlSerializer.startTag(null, "accounts");
      localFastXmlSerializer.attribute(null, "version", Integer.toString(2));
      localFastXmlSerializer.attribute(null, "nextAuthorityId", Integer.toString(this.mNextAuthorityId));
      localFastXmlSerializer.attribute(null, "offsetInSeconds", Integer.toString(this.mSyncRandomOffset));
      int i = this.mMasterSyncAutomatically.size();
      for (int j = 0; j < i; j++)
      {
        int k = this.mMasterSyncAutomatically.keyAt(j);
        Boolean localBoolean = (Boolean)this.mMasterSyncAutomatically.valueAt(j);
        localFastXmlSerializer.startTag(null, "listenForTickles");
        localFastXmlSerializer.attribute(null, "user", Integer.toString(k));
        localFastXmlSerializer.attribute(null, "enabled", Boolean.toString(localBoolean.booleanValue()));
        localFastXmlSerializer.endTag(null, "listenForTickles");
      }
      int m = this.mAuthorities.size();
      n = 0;
      if (n < m)
      {
        AuthorityInfo localAuthorityInfo = (AuthorityInfo)this.mAuthorities.valueAt(n);
        localFastXmlSerializer.startTag(null, "authority");
        localFastXmlSerializer.attribute(null, "id", Integer.toString(localAuthorityInfo.ident));
        localFastXmlSerializer.attribute(null, "account", localAuthorityInfo.account.name);
        localFastXmlSerializer.attribute(null, "user", Integer.toString(localAuthorityInfo.userId));
        localFastXmlSerializer.attribute(null, "type", localAuthorityInfo.account.type);
        localFastXmlSerializer.attribute(null, "authority", localAuthorityInfo.authority);
        localFastXmlSerializer.attribute(null, "enabled", Boolean.toString(localAuthorityInfo.enabled));
        if (localAuthorityInfo.syncable < 0)
        {
          localFastXmlSerializer.attribute(null, "syncable", "unknown");
          Iterator localIterator1 = localAuthorityInfo.periodicSyncs.iterator();
          if (localIterator1.hasNext())
          {
            Pair localPair = (Pair)localIterator1.next();
            localFastXmlSerializer.startTag(null, "periodicSync");
            localFastXmlSerializer.attribute(null, "period", Long.toString(((Long)localPair.second).longValue()));
            Bundle localBundle = (Bundle)localPair.first;
            Iterator localIterator2 = localBundle.keySet().iterator();
            for (;;)
            {
              if (!localIterator2.hasNext()) {
                break label947;
              }
              String str = (String)localIterator2.next();
              localFastXmlSerializer.startTag(null, "extra");
              localFastXmlSerializer.attribute(null, "name", str);
              localObject = localBundle.get(str);
              if (!(localObject instanceof Long)) {
                break;
              }
              localFastXmlSerializer.attribute(null, "type", "long");
              localFastXmlSerializer.attribute(null, "value1", localObject.toString());
              label596:
              localFastXmlSerializer.endTag(null, "extra");
            }
          }
        }
        else
        {
          if (localAuthorityInfo.syncable == 0) {
            break label1008;
          }
        }
      }
    }
    catch (IOException localIOException)
    {
      Log.w("SyncManager", "Error writing accounts", localIOException);
      if (localFileOutputStream != null) {
        this.mAccountInfoFile.failWrite(localFileOutputStream);
      }
      return;
    }
    label947:
    label1008:
    for (boolean bool = true;; bool = false)
    {
      localFastXmlSerializer.attribute(null, "syncable", Boolean.toString(bool));
      break label407;
      if ((localObject instanceof Integer))
      {
        localFastXmlSerializer.attribute(null, "type", "integer");
        localFastXmlSerializer.attribute(null, "value1", localObject.toString());
        break label596;
      }
      if ((localObject instanceof Boolean))
      {
        localFastXmlSerializer.attribute(null, "type", "boolean");
        localFastXmlSerializer.attribute(null, "value1", localObject.toString());
        break label596;
      }
      if ((localObject instanceof Float))
      {
        localFastXmlSerializer.attribute(null, "type", "float");
        localFastXmlSerializer.attribute(null, "value1", localObject.toString());
        break label596;
      }
      if ((localObject instanceof Double))
      {
        localFastXmlSerializer.attribute(null, "type", "double");
        localFastXmlSerializer.attribute(null, "value1", localObject.toString());
        break label596;
      }
      if ((localObject instanceof String))
      {
        localFastXmlSerializer.attribute(null, "type", "string");
        localFastXmlSerializer.attribute(null, "value1", localObject.toString());
        break label596;
      }
      if (!(localObject instanceof Account)) {
        break label596;
      }
      localFastXmlSerializer.attribute(null, "type", "account");
      localFastXmlSerializer.attribute(null, "value1", ((Account)localObject).name);
      localFastXmlSerializer.attribute(null, "value2", ((Account)localObject).type);
      break label596;
      localFastXmlSerializer.endTag(null, "periodicSync");
      break label417;
      localFastXmlSerializer.endTag(null, "authority");
      n++;
      break;
      localFastXmlSerializer.endTag(null, "accounts");
      localFastXmlSerializer.endDocument();
      this.mAccountInfoFile.finishWrite(localFileOutputStream);
      return;
    }
  }
  
  private void writePendingOperationLocked(PendingOperation paramPendingOperation, Parcel paramParcel)
  {
    paramParcel.writeInt(2);
    paramParcel.writeInt(paramPendingOperation.authorityId);
    paramParcel.writeInt(paramPendingOperation.syncSource);
    if ((paramPendingOperation.flatExtras == null) && (paramPendingOperation.extras != null)) {
      paramPendingOperation.flatExtras = flattenBundle(paramPendingOperation.extras);
    }
    paramParcel.writeByteArray(paramPendingOperation.flatExtras);
    if (paramPendingOperation.expedited) {}
    for (int i = 1;; i = 0)
    {
      paramParcel.writeInt(i);
      return;
    }
  }
  
  private void writePendingOperationsLocked()
  {
    int i = this.mPendingOperations.size();
    FileOutputStream localFileOutputStream = null;
    if (i == 0) {}
    try
    {
      this.mPendingFile.truncate();
      return;
    }
    catch (IOException localIOException)
    {
      Parcel localParcel;
      int j;
      Log.w("SyncManager", "Error writing pending operations", localIOException);
      if (localFileOutputStream == null) {
        return;
      }
      this.mPendingFile.failWrite(localFileOutputStream);
    }
    localFileOutputStream = this.mPendingFile.startWrite();
    localParcel = Parcel.obtain();
    for (j = 0; j < i; j++) {
      writePendingOperationLocked((PendingOperation)this.mPendingOperations.get(j), localParcel);
    }
    localFileOutputStream.write(localParcel.marshall());
    localParcel.recycle();
    this.mPendingFile.finishWrite(localFileOutputStream);
    return;
  }
  
  private void writeStatisticsLocked()
  {
    removeMessages(2);
    FileOutputStream localFileOutputStream = null;
    try
    {
      localFileOutputStream = this.mStatisticsFile.startWrite();
      Parcel localParcel = Parcel.obtain();
      int i = this.mDayStats.length;
      for (int j = 0;; j++)
      {
        DayStats localDayStats;
        if (j < i)
        {
          localDayStats = this.mDayStats[j];
          if (localDayStats != null) {}
        }
        else
        {
          localParcel.writeInt(0);
          localFileOutputStream.write(localParcel.marshall());
          localParcel.recycle();
          this.mStatisticsFile.finishWrite(localFileOutputStream);
          return;
        }
        localParcel.writeInt(101);
        localParcel.writeInt(localDayStats.day);
        localParcel.writeInt(localDayStats.successCount);
        localParcel.writeLong(localDayStats.successTime);
        localParcel.writeInt(localDayStats.failureCount);
        localParcel.writeLong(localDayStats.failureTime);
      }
      return;
    }
    catch (IOException localIOException)
    {
      Log.w("SyncManager", "Error writing stats", localIOException);
      if (localFileOutputStream != null) {
        this.mStatisticsFile.failWrite(localFileOutputStream);
      }
    }
  }
  
  private void writeStatusLocked()
  {
    removeMessages(1);
    FileOutputStream localFileOutputStream = null;
    try
    {
      localFileOutputStream = this.mStatusFile.startWrite();
      Parcel localParcel = Parcel.obtain();
      int i = this.mSyncStatus.size();
      for (int j = 0; j < i; j++)
      {
        SyncStatusInfo localSyncStatusInfo = (SyncStatusInfo)this.mSyncStatus.valueAt(j);
        localParcel.writeInt(100);
        localSyncStatusInfo.writeToParcel(localParcel, 0);
      }
      localParcel.writeInt(0);
      localFileOutputStream.write(localParcel.marshall());
      localParcel.recycle();
      this.mStatusFile.finishWrite(localFileOutputStream);
      return;
    }
    catch (IOException localIOException)
    {
      do
      {
        Log.w("SyncManager", "Error writing status", localIOException);
      } while (localFileOutputStream == null);
      this.mStatusFile.failWrite(localFileOutputStream);
    }
  }
  
  public SyncInfo addActiveSync(SyncManager.ActiveSyncContext paramActiveSyncContext)
  {
    synchronized (this.mAuthorities)
    {
      if (Log.isLoggable("SyncManager", 2)) {
        Log.v("SyncManager", "setActiveSync: account=" + paramActiveSyncContext.mSyncOperation.account + " auth=" + paramActiveSyncContext.mSyncOperation.authority + " src=" + paramActiveSyncContext.mSyncOperation.syncSource + " extras=" + paramActiveSyncContext.mSyncOperation.extras);
      }
      AuthorityInfo localAuthorityInfo = getOrCreateAuthorityLocked(paramActiveSyncContext.mSyncOperation.account, paramActiveSyncContext.mSyncOperation.userId, paramActiveSyncContext.mSyncOperation.authority, -1, true);
      SyncInfo localSyncInfo = new SyncInfo(localAuthorityInfo.ident, localAuthorityInfo.account, localAuthorityInfo.authority, paramActiveSyncContext.mStartTime);
      getCurrentSyncs(localAuthorityInfo.userId).add(localSyncInfo);
      reportActiveChange();
      return localSyncInfo;
    }
  }
  
  public void addPeriodicSync(Account paramAccount, int paramInt, String paramString, Bundle paramBundle, long paramLong)
  {
    updateOrRemovePeriodicSync(paramAccount, paramInt, paramString, paramBundle, paramLong, true);
  }
  
  public void addStatusChangeListener(int paramInt, ISyncStatusObserver paramISyncStatusObserver)
  {
    synchronized (this.mAuthorities)
    {
      this.mChangeListeners.register(paramISyncStatusObserver, Integer.valueOf(paramInt));
      return;
    }
  }
  
  public void clearAllBackoffs(SyncQueue paramSyncQueue)
  {
    int i = 0;
    synchronized (this.mAuthorities)
    {
      try
      {
        Iterator localIterator1 = this.mAccounts.values().iterator();
        while (localIterator1.hasNext())
        {
          AccountInfo localAccountInfo = (AccountInfo)localIterator1.next();
          Iterator localIterator2 = localAccountInfo.authorities.values().iterator();
          while (localIterator2.hasNext())
          {
            AuthorityInfo localAuthorityInfo = (AuthorityInfo)localIterator2.next();
            if ((localAuthorityInfo.backoffTime != -1L) || (localAuthorityInfo.backoffDelay != -1L))
            {
              if (Log.isLoggable("SyncManager", 2)) {
                Log.v("SyncManager", "clearAllBackoffs: authority:" + localAuthorityInfo.authority + " account:" + localAccountInfo.accountAndUser.account.name + " user:" + localAccountInfo.accountAndUser.userId + " backoffTime was: " + localAuthorityInfo.backoffTime + " backoffDelay was: " + localAuthorityInfo.backoffDelay);
              }
              localAuthorityInfo.backoffTime = -1L;
              localAuthorityInfo.backoffDelay = -1L;
              paramSyncQueue.onBackoffChanged(localAccountInfo.accountAndUser.account, localAccountInfo.accountAndUser.userId, localAuthorityInfo.authority, 0L);
              i = 1;
            }
          }
        }
        if (i != 0) {
          reportChange(1);
        }
        return;
      }
      finally {}
    }
  }
  
  public void clearAndReadState()
  {
    synchronized (this.mAuthorities)
    {
      this.mAuthorities.clear();
      this.mAccounts.clear();
      this.mPendingOperations.clear();
      this.mSyncStatus.clear();
      this.mSyncHistory.clear();
      readAccountInfoLocked();
      readStatusLocked();
      readPendingOperationsLocked();
      readStatisticsLocked();
      readAndDeleteLegacyAccountInfoLocked();
      writeAccountInfoLocked();
      writeStatusLocked();
      writePendingOperationsLocked();
      writeStatisticsLocked();
      return;
    }
  }
  
  public boolean deleteFromPending(PendingOperation paramPendingOperation)
  {
    for (;;)
    {
      int j;
      synchronized (this.mAuthorities)
      {
        if (Log.isLoggable("SyncManager", 2)) {
          Log.v("SyncManager", "deleteFromPending: account=" + paramPendingOperation.account + " user=" + paramPendingOperation.userId + " auth=" + paramPendingOperation.authority + " src=" + paramPendingOperation.syncSource + " extras=" + paramPendingOperation.extras);
        }
        boolean bool1 = this.mPendingOperations.remove(paramPendingOperation);
        bool2 = false;
        if (bool1)
        {
          if ((this.mPendingOperations.size() == 0) || (this.mNumPendingFinished >= 4))
          {
            writePendingOperationsLocked();
            this.mNumPendingFinished = 0;
            AuthorityInfo localAuthorityInfo = getAuthorityLocked(paramPendingOperation.account, paramPendingOperation.userId, paramPendingOperation.authority, "deleteFromPending");
            if (localAuthorityInfo == null) {
              break label358;
            }
            if (Log.isLoggable("SyncManager", 2)) {
              Log.v("SyncManager", "removing - " + localAuthorityInfo);
            }
            int i = this.mPendingOperations.size();
            j = 0;
            int k = 0;
            if (j < i)
            {
              PendingOperation localPendingOperation = (PendingOperation)this.mPendingOperations.get(j);
              if ((!localPendingOperation.account.equals(paramPendingOperation.account)) || (!localPendingOperation.authority.equals(paramPendingOperation.authority)) || (localPendingOperation.userId != paramPendingOperation.userId)) {
                break label352;
              }
              k = 1;
            }
            if (k != 0) {
              break label358;
            }
            if (Log.isLoggable("SyncManager", 2)) {
              Log.v("SyncManager", "no more pending!");
            }
            getOrCreateSyncStatusLocked(localAuthorityInfo.ident).pending = false;
            break label358;
          }
        }
        else
        {
          reportChange(2);
          return bool2;
        }
        this.mNumPendingFinished = (1 + this.mNumPendingFinished);
      }
      label352:
      j++;
      continue;
      label358:
      boolean bool2 = true;
    }
  }
  
  public void doDatabaseCleanup(Account[] paramArrayOfAccount, int paramInt)
  {
    SparseArray localSparseArray2;
    for (;;)
    {
      Iterator localIterator1;
      synchronized (this.mAuthorities)
      {
        if (Log.isLoggable("SyncManager", 2)) {
          Log.w("SyncManager", "Updating for new accounts...");
        }
        localSparseArray2 = new SparseArray();
        localIterator1 = this.mAccounts.values().iterator();
        if (!localIterator1.hasNext()) {
          break;
        }
        AccountInfo localAccountInfo = (AccountInfo)localIterator1.next();
        if ((ArrayUtils.contains(paramArrayOfAccount, localAccountInfo.accountAndUser.account)) || (localAccountInfo.accountAndUser.userId != paramInt)) {
          continue;
        }
        if (Log.isLoggable("SyncManager", 2)) {
          Log.w("SyncManager", "Account removed: " + localAccountInfo.accountAndUser);
        }
        Iterator localIterator2 = localAccountInfo.authorities.values().iterator();
        if (localIterator2.hasNext())
        {
          AuthorityInfo localAuthorityInfo = (AuthorityInfo)localIterator2.next();
          localSparseArray2.put(localAuthorityInfo.ident, localAuthorityInfo);
        }
      }
      localIterator1.remove();
    }
    int i = localSparseArray2.size();
    if (i > 0)
    {
      while (i > 0)
      {
        i--;
        int j = localSparseArray2.keyAt(i);
        this.mAuthorities.remove(j);
        int k = this.mSyncStatus.size();
        while (k > 0)
        {
          k--;
          if (this.mSyncStatus.keyAt(k) == j) {
            this.mSyncStatus.remove(this.mSyncStatus.keyAt(k));
          }
        }
        int m = this.mSyncHistory.size();
        while (m > 0)
        {
          m--;
          if (((SyncHistoryItem)this.mSyncHistory.get(m)).authorityId == j) {
            this.mSyncHistory.remove(m);
          }
        }
      }
      writeAccountInfoLocked();
      writeStatusLocked();
      writePendingOperationsLocked();
      writeStatisticsLocked();
    }
  }
  
  public ArrayList<AuthorityInfo> getAuthorities()
  {
    synchronized (this.mAuthorities)
    {
      int i = this.mAuthorities.size();
      ArrayList localArrayList = new ArrayList(i);
      for (int j = 0; j < i; j++) {
        localArrayList.add(new AuthorityInfo((AuthorityInfo)this.mAuthorities.valueAt(j)));
      }
      return localArrayList;
    }
  }
  
  public AuthorityInfo getAuthority(int paramInt)
  {
    synchronized (this.mAuthorities)
    {
      AuthorityInfo localAuthorityInfo = (AuthorityInfo)this.mAuthorities.get(paramInt);
      return localAuthorityInfo;
    }
  }
  
  public Pair<Long, Long> getBackoff(Account paramAccount, int paramInt, String paramString)
  {
    synchronized (this.mAuthorities)
    {
      AuthorityInfo localAuthorityInfo = getAuthorityLocked(paramAccount, paramInt, paramString, "getBackoff");
      if ((localAuthorityInfo == null) || (localAuthorityInfo.backoffTime < 0L)) {
        return null;
      }
      Pair localPair = Pair.create(Long.valueOf(localAuthorityInfo.backoffTime), Long.valueOf(localAuthorityInfo.backoffDelay));
      return localPair;
    }
  }
  
  public List<SyncInfo> getCurrentSyncs(int paramInt)
  {
    synchronized (this.mAuthorities)
    {
      ArrayList localArrayList = (ArrayList)this.mCurrentSyncs.get(paramInt);
      if (localArrayList == null)
      {
        localArrayList = new ArrayList();
        this.mCurrentSyncs.put(paramInt, localArrayList);
      }
      return localArrayList;
    }
  }
  
  public DayStats[] getDayStatistics()
  {
    synchronized (this.mAuthorities)
    {
      DayStats[] arrayOfDayStats = new DayStats[this.mDayStats.length];
      System.arraycopy(this.mDayStats, 0, arrayOfDayStats, 0, arrayOfDayStats.length);
      return arrayOfDayStats;
    }
  }
  
  public long getDelayUntilTime(Account paramAccount, int paramInt, String paramString)
  {
    synchronized (this.mAuthorities)
    {
      AuthorityInfo localAuthorityInfo = getAuthorityLocked(paramAccount, paramInt, paramString, "getDelayUntil");
      if (localAuthorityInfo == null) {
        return 0L;
      }
      long l = localAuthorityInfo.delayUntil;
      return l;
    }
  }
  
  public int getIsSyncable(Account paramAccount, int paramInt, String paramString)
  {
    SparseArray localSparseArray = this.mAuthorities;
    if (paramAccount != null) {
      try
      {
        AuthorityInfo localAuthorityInfo2 = getAuthorityLocked(paramAccount, paramInt, paramString, "getIsSyncable");
        if (localAuthorityInfo2 == null) {
          return -1;
        }
        int k = localAuthorityInfo2.syncable;
        return k;
      }
      finally {}
    }
    int i = this.mAuthorities.size();
    while (i > 0)
    {
      i--;
      AuthorityInfo localAuthorityInfo1 = (AuthorityInfo)this.mAuthorities.valueAt(i);
      if (localAuthorityInfo1.authority.equals(paramString))
      {
        int j = localAuthorityInfo1.syncable;
        return j;
      }
    }
    return -1;
  }
  
  public boolean getMasterSyncAutomatically(int paramInt)
  {
    synchronized (this.mAuthorities)
    {
      Boolean localBoolean = (Boolean)this.mMasterSyncAutomatically.get(paramInt);
      if (localBoolean == null)
      {
        bool = this.mDefaultMasterSyncAutomatically;
        return bool;
      }
      boolean bool = localBoolean.booleanValue();
    }
  }
  
  public AuthorityInfo getOrCreateAuthority(Account paramAccount, int paramInt, String paramString)
  {
    synchronized (this.mAuthorities)
    {
      AuthorityInfo localAuthorityInfo = getOrCreateAuthorityLocked(paramAccount, paramInt, paramString, -1, true);
      return localAuthorityInfo;
    }
  }
  
  public SyncStatusInfo getOrCreateSyncStatus(AuthorityInfo paramAuthorityInfo)
  {
    synchronized (this.mAuthorities)
    {
      SyncStatusInfo localSyncStatusInfo = getOrCreateSyncStatusLocked(paramAuthorityInfo.ident);
      return localSyncStatusInfo;
    }
  }
  
  public int getPendingOperationCount()
  {
    synchronized (this.mAuthorities)
    {
      int i = this.mPendingOperations.size();
      return i;
    }
  }
  
  public ArrayList<PendingOperation> getPendingOperations()
  {
    synchronized (this.mAuthorities)
    {
      ArrayList localArrayList = new ArrayList(this.mPendingOperations);
      return localArrayList;
    }
  }
  
  public List<PeriodicSync> getPeriodicSyncs(Account paramAccount, int paramInt, String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    synchronized (this.mAuthorities)
    {
      AuthorityInfo localAuthorityInfo = getAuthorityLocked(paramAccount, paramInt, paramString, "getPeriodicSyncs");
      if (localAuthorityInfo != null)
      {
        Iterator localIterator = localAuthorityInfo.periodicSyncs.iterator();
        if (localIterator.hasNext())
        {
          Pair localPair = (Pair)localIterator.next();
          localArrayList.add(new PeriodicSync(paramAccount, paramString, (Bundle)localPair.first, ((Long)localPair.second).longValue()));
        }
      }
    }
    return localArrayList;
  }
  
  public SyncStatusInfo getStatusByAccountAndAuthority(Account paramAccount, int paramInt, String paramString)
  {
    if ((paramAccount == null) || (paramString == null)) {
      throw new IllegalArgumentException();
    }
    for (;;)
    {
      int j;
      synchronized (this.mAuthorities)
      {
        int i = this.mSyncStatus.size();
        j = 0;
        if (j < i)
        {
          SyncStatusInfo localSyncStatusInfo = (SyncStatusInfo)this.mSyncStatus.valueAt(j);
          AuthorityInfo localAuthorityInfo = (AuthorityInfo)this.mAuthorities.get(localSyncStatusInfo.authorityId);
          if ((localAuthorityInfo != null) && (localAuthorityInfo.authority.equals(paramString)) && (localAuthorityInfo.userId == paramInt) && (paramAccount.equals(localAuthorityInfo.account))) {
            return localSyncStatusInfo;
          }
        }
        else
        {
          return null;
        }
      }
      j++;
    }
  }
  
  public boolean getSyncAutomatically(Account paramAccount, int paramInt, String paramString)
  {
    boolean bool = true;
    SparseArray localSparseArray = this.mAuthorities;
    if (paramAccount != null) {}
    for (;;)
    {
      try
      {
        AuthorityInfo localAuthorityInfo2 = getAuthorityLocked(paramAccount, paramInt, paramString, "getSyncAutomatically");
        if ((localAuthorityInfo2 == null) || (!localAuthorityInfo2.enabled)) {
          break label126;
        }
        return bool;
      }
      finally {}
      int i = this.mAuthorities.size();
      if (i > 0)
      {
        i--;
        AuthorityInfo localAuthorityInfo1 = (AuthorityInfo)this.mAuthorities.valueAt(i);
        if ((localAuthorityInfo1.authority.equals(paramString)) && (localAuthorityInfo1.userId == paramInt) && (localAuthorityInfo1.enabled)) {
          return bool;
        }
      }
      else
      {
        return false;
        label126:
        bool = false;
      }
    }
  }
  
  public ArrayList<SyncHistoryItem> getSyncHistory()
  {
    synchronized (this.mAuthorities)
    {
      int i = this.mSyncHistory.size();
      ArrayList localArrayList = new ArrayList(i);
      for (int j = 0; j < i; j++) {
        localArrayList.add(this.mSyncHistory.get(j));
      }
      return localArrayList;
    }
  }
  
  public int getSyncRandomOffset()
  {
    return this.mSyncRandomOffset;
  }
  
  public ArrayList<SyncStatusInfo> getSyncStatus()
  {
    synchronized (this.mAuthorities)
    {
      int i = this.mSyncStatus.size();
      ArrayList localArrayList = new ArrayList(i);
      for (int j = 0; j < i; j++) {
        localArrayList.add(this.mSyncStatus.valueAt(j));
      }
      return localArrayList;
    }
  }
  
  public void handleMessage(Message paramMessage)
  {
    if (paramMessage.what == 1) {
      synchronized (this.mAuthorities)
      {
        writeStatusLocked();
        return;
      }
    }
    if (paramMessage.what == 2) {
      synchronized (this.mAuthorities)
      {
        writeStatisticsLocked();
        return;
      }
    }
  }
  
  public PendingOperation insertIntoPending(PendingOperation paramPendingOperation)
  {
    AuthorityInfo localAuthorityInfo;
    PendingOperation localPendingOperation;
    synchronized (this.mAuthorities)
    {
      if (Log.isLoggable("SyncManager", 2)) {
        Log.v("SyncManager", "insertIntoPending: account=" + paramPendingOperation.account + " user=" + paramPendingOperation.userId + " auth=" + paramPendingOperation.authority + " src=" + paramPendingOperation.syncSource + " extras=" + paramPendingOperation.extras);
      }
      localAuthorityInfo = getOrCreateAuthorityLocked(paramPendingOperation.account, paramPendingOperation.userId, paramPendingOperation.authority, -1, true);
      if (localAuthorityInfo == null) {
        return null;
      }
      localPendingOperation = new PendingOperation(paramPendingOperation);
    }
    try
    {
      localPendingOperation.authorityId = localAuthorityInfo.ident;
      this.mPendingOperations.add(localPendingOperation);
      appendPendingOperationLocked(localPendingOperation);
      getOrCreateSyncStatusLocked(localAuthorityInfo.ident).pending = true;
      reportChange(2);
      return localPendingOperation;
    }
    finally {}
    localObject1 = finally;
    throw ((Throwable)localObject1);
  }
  
  public long insertStartSyncEvent(Account paramAccount, int paramInt1, String paramString, long paramLong, int paramInt2, boolean paramBoolean)
  {
    SyncHistoryItem localSyncHistoryItem;
    synchronized (this.mAuthorities)
    {
      if (Log.isLoggable("SyncManager", 2)) {
        Log.v("SyncManager", "insertStartSyncEvent: account=" + paramAccount + "user=" + paramInt1 + " auth=" + paramString + " source=" + paramInt2);
      }
      AuthorityInfo localAuthorityInfo = getAuthorityLocked(paramAccount, paramInt1, paramString, "insertStartSyncEvent");
      if (localAuthorityInfo == null) {
        return -1L;
      }
      localSyncHistoryItem = new SyncHistoryItem();
      localSyncHistoryItem.initialization = paramBoolean;
      localSyncHistoryItem.authorityId = localAuthorityInfo.ident;
      int i = this.mNextHistoryId;
      this.mNextHistoryId = (i + 1);
      localSyncHistoryItem.historyId = i;
      if (this.mNextHistoryId < 0) {
        this.mNextHistoryId = 0;
      }
      localSyncHistoryItem.eventTime = paramLong;
      localSyncHistoryItem.source = paramInt2;
      localSyncHistoryItem.event = 0;
      this.mSyncHistory.add(0, localSyncHistoryItem);
      if (this.mSyncHistory.size() > 100) {
        this.mSyncHistory.remove(-1 + this.mSyncHistory.size());
      }
    }
    long l = localSyncHistoryItem.historyId;
    if (Log.isLoggable("SyncManager", 2)) {
      Log.v("SyncManager", "returning historyId " + l);
    }
    reportChange(8);
    return l;
  }
  
  public boolean isSyncActive(Account paramAccount, int paramInt, String paramString)
  {
    synchronized (this.mAuthorities)
    {
      Iterator localIterator = getCurrentSyncs(paramInt).iterator();
      while (localIterator.hasNext())
      {
        AuthorityInfo localAuthorityInfo = getAuthority(((SyncInfo)localIterator.next()).authorityId);
        if ((localAuthorityInfo != null) && (localAuthorityInfo.account.equals(paramAccount)) && (localAuthorityInfo.authority.equals(paramString)) && (localAuthorityInfo.userId == paramInt)) {
          return true;
        }
      }
      return false;
    }
  }
  
  public boolean isSyncPending(Account paramAccount, int paramInt, String paramString)
  {
    for (;;)
    {
      int j;
      synchronized (this.mAuthorities)
      {
        int i = this.mSyncStatus.size();
        j = 0;
        if (j < i)
        {
          SyncStatusInfo localSyncStatusInfo = (SyncStatusInfo)this.mSyncStatus.valueAt(j);
          AuthorityInfo localAuthorityInfo = (AuthorityInfo)this.mAuthorities.get(localSyncStatusInfo.authorityId);
          if ((localAuthorityInfo != null) && (paramInt == localAuthorityInfo.userId) && ((paramAccount == null) || (localAuthorityInfo.account.equals(paramAccount))) && (localAuthorityInfo.authority.equals(paramString)) && (localSyncStatusInfo.pending)) {
            return true;
          }
        }
        else
        {
          return false;
        }
      }
      j++;
    }
  }
  
  public void removeActiveSync(SyncInfo paramSyncInfo, int paramInt)
  {
    synchronized (this.mAuthorities)
    {
      if (Log.isLoggable("SyncManager", 2)) {
        Log.v("SyncManager", "removeActiveSync: account=" + paramSyncInfo.account + " user=" + paramInt + " auth=" + paramSyncInfo.authority);
      }
      getCurrentSyncs(paramInt).remove(paramSyncInfo);
      reportActiveChange();
      return;
    }
  }
  
  public void removeAuthority(Account paramAccount, int paramInt, String paramString)
  {
    synchronized (this.mAuthorities)
    {
      removeAuthorityLocked(paramAccount, paramInt, paramString, true);
      return;
    }
  }
  
  public void removePeriodicSync(Account paramAccount, int paramInt, String paramString, Bundle paramBundle)
  {
    updateOrRemovePeriodicSync(paramAccount, paramInt, paramString, paramBundle, 0L, false);
  }
  
  public void removeStatusChangeListener(ISyncStatusObserver paramISyncStatusObserver)
  {
    synchronized (this.mAuthorities)
    {
      this.mChangeListeners.unregister(paramISyncStatusObserver);
      return;
    }
  }
  
  public void reportActiveChange()
  {
    reportChange(4);
  }
  
  public void setBackoff(Account paramAccount, int paramInt, String paramString, long paramLong1, long paramLong2)
  {
    if (Log.isLoggable("SyncManager", 2)) {
      Log.v("SyncManager", "setBackoff: " + paramAccount + ", provider " + paramString + ", user " + paramInt + " -> nextSyncTime " + paramLong1 + ", nextDelay " + paramLong2);
    }
    int i = 0;
    SparseArray localSparseArray = this.mAuthorities;
    if ((paramAccount == null) || (paramString == null)) {}
    try
    {
      Iterator localIterator1 = this.mAccounts.values().iterator();
      while (localIterator1.hasNext())
      {
        AccountInfo localAccountInfo = (AccountInfo)localIterator1.next();
        if ((paramAccount == null) || (paramAccount.equals(localAccountInfo.accountAndUser.account)) || (paramInt == localAccountInfo.accountAndUser.userId))
        {
          Iterator localIterator2 = localAccountInfo.authorities.values().iterator();
          while (localIterator2.hasNext())
          {
            AuthorityInfo localAuthorityInfo1 = (AuthorityInfo)localIterator2.next();
            if (((paramString == null) || (paramString.equals(localAuthorityInfo1.authority))) && ((localAuthorityInfo1.backoffTime != paramLong1) || (localAuthorityInfo1.backoffDelay != paramLong2)))
            {
              localAuthorityInfo1.backoffTime = paramLong1;
              localAuthorityInfo1.backoffDelay = paramLong2;
              i = 1;
            }
          }
          continue;
          AuthorityInfo localAuthorityInfo2 = getOrCreateAuthorityLocked(paramAccount, paramInt, paramString, -1, true);
          if ((localAuthorityInfo2.backoffTime == paramLong1) && (localAuthorityInfo2.backoffDelay == paramLong2)) {
            return;
          }
          localAuthorityInfo2.backoffTime = paramLong1;
          localAuthorityInfo2.backoffDelay = paramLong2;
          i = 1;
        }
      }
      if (i != 0)
      {
        reportChange(1);
        return;
      }
    }
    finally {}
  }
  
  public void setDelayUntilTime(Account paramAccount, int paramInt, String paramString, long paramLong)
  {
    if (Log.isLoggable("SyncManager", 2)) {
      Log.v("SyncManager", "setDelayUntil: " + paramAccount + ", provider " + paramString + ", user " + paramInt + " -> delayUntil " + paramLong);
    }
    synchronized (this.mAuthorities)
    {
      AuthorityInfo localAuthorityInfo = getOrCreateAuthorityLocked(paramAccount, paramInt, paramString, -1, true);
      if (localAuthorityInfo.delayUntil == paramLong) {
        return;
      }
      localAuthorityInfo.delayUntil = paramLong;
      reportChange(1);
      return;
    }
  }
  
  public void setIsSyncable(Account paramAccount, int paramInt1, String paramString, int paramInt2)
  {
    if (paramInt2 > 1) {
      paramInt2 = 1;
    }
    for (;;)
    {
      Log.d("SyncManager", "setIsSyncable: " + paramAccount + ", provider " + paramString + ", user " + paramInt1 + " -> " + paramInt2);
      synchronized (this.mAuthorities)
      {
        AuthorityInfo localAuthorityInfo = getOrCreateAuthorityLocked(paramAccount, paramInt1, paramString, -1, false);
        if (localAuthorityInfo.syncable == paramInt2)
        {
          Log.d("SyncManager", "setIsSyncable: already set to " + paramInt2 + ", doing nothing");
          return;
        }
        localAuthorityInfo.syncable = paramInt2;
        writeAccountInfoLocked();
        if (paramInt2 > 0) {
          requestSync(paramAccount, paramInt1, paramString, new Bundle());
        }
        reportChange(1);
        return;
      }
      if (paramInt2 < -1) {
        paramInt2 = -1;
      }
    }
  }
  
  public void setMasterSyncAutomatically(boolean paramBoolean, int paramInt)
  {
    synchronized (this.mAuthorities)
    {
      Boolean localBoolean = (Boolean)this.mMasterSyncAutomatically.get(paramInt);
      if ((localBoolean != null) && (localBoolean.booleanValue() == paramBoolean)) {
        return;
      }
      this.mMasterSyncAutomatically.put(paramInt, Boolean.valueOf(paramBoolean));
      writeAccountInfoLocked();
      if (paramBoolean) {
        requestSync(null, paramInt, null, new Bundle());
      }
      reportChange(1);
      this.mContext.sendBroadcast(SYNC_CONNECTION_SETTING_CHANGED_INTENT);
      return;
    }
  }
  
  protected void setOnSyncRequestListener(OnSyncRequestListener paramOnSyncRequestListener)
  {
    if (this.mSyncRequestListener == null) {
      this.mSyncRequestListener = paramOnSyncRequestListener;
    }
  }
  
  public void setSyncAutomatically(Account paramAccount, int paramInt, String paramString, boolean paramBoolean)
  {
    Log.d("SyncManager", "setSyncAutomatically:  provider " + paramString + ", user " + paramInt + " -> " + paramBoolean);
    synchronized (this.mAuthorities)
    {
      AuthorityInfo localAuthorityInfo = getOrCreateAuthorityLocked(paramAccount, paramInt, paramString, -1, false);
      if (localAuthorityInfo.enabled == paramBoolean)
      {
        Log.d("SyncManager", "setSyncAutomatically: already set to " + paramBoolean + ", doing nothing");
        return;
      }
      localAuthorityInfo.enabled = paramBoolean;
      writeAccountInfoLocked();
      if (paramBoolean) {
        requestSync(paramAccount, paramInt, paramString, new Bundle());
      }
      reportChange(1);
      return;
    }
  }
  
  public void stopSyncEvent(long paramLong1, long paramLong2, String paramString, long paramLong3, long paramLong4)
  {
    for (;;)
    {
      SyncHistoryItem localSyncHistoryItem;
      SyncStatusInfo localSyncStatusInfo;
      int j;
      int k;
      DayStats localDayStats2;
      long l;
      int m;
      synchronized (this.mAuthorities)
      {
        if (Log.isLoggable("SyncManager", 2)) {
          Log.v("SyncManager", "stopSyncEvent: historyId=" + paramLong1);
        }
        int i = this.mSyncHistory.size();
        localSyncHistoryItem = null;
        if (i > 0)
        {
          i--;
          localSyncHistoryItem = (SyncHistoryItem)this.mSyncHistory.get(i);
          if (localSyncHistoryItem.historyId != paramLong1) {
            break label728;
          }
        }
        if (localSyncHistoryItem == null)
        {
          Log.w("SyncManager", "stopSyncEvent: no history for id " + paramLong1);
          return;
        }
        localSyncHistoryItem.elapsedTime = paramLong2;
        localSyncHistoryItem.event = 1;
        localSyncHistoryItem.mesg = paramString;
        localSyncHistoryItem.downstreamActivity = paramLong3;
        localSyncHistoryItem.upstreamActivity = paramLong4;
        localSyncStatusInfo = getOrCreateSyncStatusLocked(localSyncHistoryItem.authorityId);
        localSyncStatusInfo.numSyncs = (1 + localSyncStatusInfo.numSyncs);
        localSyncStatusInfo.totalElapsedTime = (paramLong2 + localSyncStatusInfo.totalElapsedTime);
        switch (localSyncHistoryItem.source)
        {
        default: 
          j = 0;
          k = getCurrentDayLocked();
          if (this.mDayStats[0] != null) {
            break;
          }
          this.mDayStats[0] = new DayStats(k);
          localDayStats2 = this.mDayStats[0];
          l = paramLong2 + localSyncHistoryItem.eventTime;
          if (!"success".equals(paramString)) {
            break label575;
          }
          if (localSyncStatusInfo.lastSuccessTime == 0L) {
            break label731;
          }
          boolean bool3 = localSyncStatusInfo.lastFailureTime < 0L;
          m = 0;
          if (bool3) {
            break label731;
          }
          localSyncStatusInfo.lastSuccessTime = l;
          localSyncStatusInfo.lastSuccessSource = localSyncHistoryItem.source;
          localSyncStatusInfo.lastFailureTime = 0L;
          localSyncStatusInfo.lastFailureSource = -1;
          localSyncStatusInfo.lastFailureMesg = null;
          localSyncStatusInfo.initialFailureTime = 0L;
          localDayStats2.successCount = (1 + localDayStats2.successCount);
          localDayStats2.successTime = (paramLong2 + localDayStats2.successTime);
          if (m == 0) {
            break label680;
          }
          writeStatusLocked();
          if (j == 0) {
            break label704;
          }
          writeStatisticsLocked();
          reportChange(8);
          return;
        case 1: 
          localSyncStatusInfo.numSourceLocal = (1 + localSyncStatusInfo.numSourceLocal);
        }
      }
      localSyncStatusInfo.numSourcePoll = (1 + localSyncStatusInfo.numSourcePoll);
      continue;
      localSyncStatusInfo.numSourceUser = (1 + localSyncStatusInfo.numSourceUser);
      continue;
      localSyncStatusInfo.numSourceServer = (1 + localSyncStatusInfo.numSourceServer);
      continue;
      localSyncStatusInfo.numSourcePeriodic = (1 + localSyncStatusInfo.numSourcePeriodic);
      continue;
      if (k != this.mDayStats[0].day)
      {
        System.arraycopy(this.mDayStats, 0, this.mDayStats, 1, -1 + this.mDayStats.length);
        this.mDayStats[0] = new DayStats(k);
        j = 1;
      }
      else
      {
        DayStats localDayStats1 = this.mDayStats[0];
        j = 0;
        if (localDayStats1 == null)
        {
          j = 0;
          continue;
          label575:
          boolean bool1 = "canceled".equals(paramString);
          m = 0;
          if (!bool1)
          {
            boolean bool2 = localSyncStatusInfo.lastFailureTime < 0L;
            m = 0;
            if (!bool2) {
              m = 1;
            }
            localSyncStatusInfo.lastFailureTime = l;
            localSyncStatusInfo.lastFailureSource = localSyncHistoryItem.source;
            localSyncStatusInfo.lastFailureMesg = paramString;
            if (localSyncStatusInfo.initialFailureTime == 0L) {
              localSyncStatusInfo.initialFailureTime = l;
            }
            localDayStats2.failureCount = (1 + localDayStats2.failureCount);
            localDayStats2.failureTime = (paramLong2 + localDayStats2.failureTime);
            continue;
            label680:
            if (!hasMessages(1))
            {
              sendMessageDelayed(obtainMessage(1), 600000L);
              continue;
              label704:
              if (!hasMessages(2))
              {
                sendMessageDelayed(obtainMessage(2), 1800000L);
                continue;
                label728:
                continue;
                label731:
                m = 1;
              }
            }
          }
        }
      }
    }
  }
  
  public void writeAllState()
  {
    synchronized (this.mAuthorities)
    {
      if (this.mNumPendingFinished > 0) {
        writePendingOperationsLocked();
      }
      writeStatusLocked();
      writeStatisticsLocked();
      return;
    }
  }
  
  static class AccountInfo
  {
    final AccountAndUser accountAndUser;
    final HashMap<String, SyncStorageEngine.AuthorityInfo> authorities = new HashMap();
    
    AccountInfo(AccountAndUser paramAccountAndUser)
    {
      this.accountAndUser = paramAccountAndUser;
    }
  }
  
  public static class AuthorityInfo
  {
    final Account account;
    final String authority;
    long backoffDelay;
    long backoffTime;
    long delayUntil;
    boolean enabled;
    final int ident;
    final ArrayList<Pair<Bundle, Long>> periodicSyncs;
    int syncable;
    final int userId;
    
    AuthorityInfo(Account paramAccount, int paramInt1, String paramString, int paramInt2)
    {
      this.account = paramAccount;
      this.userId = paramInt1;
      this.authority = paramString;
      this.ident = paramInt2;
      this.enabled = false;
      this.syncable = -1;
      this.backoffTime = -1L;
      this.backoffDelay = -1L;
      this.periodicSyncs = new ArrayList();
      this.periodicSyncs.add(Pair.create(new Bundle(), Long.valueOf(86400L)));
    }
    
    AuthorityInfo(AuthorityInfo paramAuthorityInfo)
    {
      this.account = paramAuthorityInfo.account;
      this.userId = paramAuthorityInfo.userId;
      this.authority = paramAuthorityInfo.authority;
      this.ident = paramAuthorityInfo.ident;
      this.enabled = paramAuthorityInfo.enabled;
      this.syncable = paramAuthorityInfo.syncable;
      this.backoffTime = paramAuthorityInfo.backoffTime;
      this.backoffDelay = paramAuthorityInfo.backoffDelay;
      this.delayUntil = paramAuthorityInfo.delayUntil;
      this.periodicSyncs = new ArrayList();
      Iterator localIterator = paramAuthorityInfo.periodicSyncs.iterator();
      while (localIterator.hasNext())
      {
        Pair localPair = (Pair)localIterator.next();
        this.periodicSyncs.add(Pair.create(new Bundle((Bundle)localPair.first), localPair.second));
      }
    }
  }
  
  public static class DayStats
  {
    public final int day;
    public int failureCount;
    public long failureTime;
    public int successCount;
    public long successTime;
    
    public DayStats(int paramInt)
    {
      this.day = paramInt;
    }
  }
  
  static abstract interface OnSyncRequestListener
  {
    public abstract void onSyncRequest(Account paramAccount, int paramInt, String paramString, Bundle paramBundle);
  }
  
  public static class PendingOperation
  {
    final Account account;
    final String authority;
    int authorityId;
    final boolean expedited;
    final Bundle extras;
    byte[] flatExtras;
    final int syncSource;
    final int userId;
    
    PendingOperation(Account paramAccount, int paramInt1, int paramInt2, String paramString, Bundle paramBundle, boolean paramBoolean)
    {
      this.account = paramAccount;
      this.userId = paramInt1;
      this.syncSource = paramInt2;
      this.authority = paramString;
      if (paramBundle != null) {
        paramBundle = new Bundle(paramBundle);
      }
      this.extras = paramBundle;
      this.expedited = paramBoolean;
      this.authorityId = -1;
    }
    
    PendingOperation(PendingOperation paramPendingOperation)
    {
      this.account = paramPendingOperation.account;
      this.userId = paramPendingOperation.userId;
      this.syncSource = paramPendingOperation.syncSource;
      this.authority = paramPendingOperation.authority;
      this.extras = paramPendingOperation.extras;
      this.authorityId = paramPendingOperation.authorityId;
      this.expedited = paramPendingOperation.expedited;
    }
  }
  
  public static class SyncHistoryItem
  {
    int authorityId;
    long downstreamActivity;
    long elapsedTime;
    int event;
    long eventTime;
    int historyId;
    boolean initialization;
    String mesg;
    int source;
    long upstreamActivity;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\SyncStorageEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
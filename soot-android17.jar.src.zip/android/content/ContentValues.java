package android.content;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public final class ContentValues
  implements Parcelable
{
  public static final Parcelable.Creator<ContentValues> CREATOR = new Parcelable.Creator()
  {
    public ContentValues createFromParcel(Parcel paramAnonymousParcel)
    {
      return new ContentValues(paramAnonymousParcel.readHashMap(null), null);
    }
    
    public ContentValues[] newArray(int paramAnonymousInt)
    {
      return new ContentValues[paramAnonymousInt];
    }
  };
  public static final String TAG = "ContentValues";
  private HashMap<String, Object> mValues;
  
  public ContentValues()
  {
    this.mValues = new HashMap(8);
  }
  
  public ContentValues(int paramInt)
  {
    this.mValues = new HashMap(paramInt, 1.0F);
  }
  
  public ContentValues(ContentValues paramContentValues)
  {
    this.mValues = new HashMap(paramContentValues.mValues);
  }
  
  private ContentValues(HashMap<String, Object> paramHashMap)
  {
    this.mValues = paramHashMap;
  }
  
  public void clear()
  {
    this.mValues.clear();
  }
  
  public boolean containsKey(String paramString)
  {
    return this.mValues.containsKey(paramString);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof ContentValues)) {
      return false;
    }
    return this.mValues.equals(((ContentValues)paramObject).mValues);
  }
  
  public Object get(String paramString)
  {
    return this.mValues.get(paramString);
  }
  
  public Boolean getAsBoolean(String paramString)
  {
    Object localObject = this.mValues.get(paramString);
    try
    {
      Boolean localBoolean = (Boolean)localObject;
      return localBoolean;
    }
    catch (ClassCastException localClassCastException)
    {
      if ((localObject instanceof CharSequence)) {
        return Boolean.valueOf(localObject.toString());
      }
      if ((localObject instanceof Number))
      {
        if (((Number)localObject).intValue() != 0) {}
        for (boolean bool = true;; bool = false) {
          return Boolean.valueOf(bool);
        }
      }
      Log.e("ContentValues", "Cannot cast value for " + paramString + " to a Boolean: " + localObject, localClassCastException);
    }
    return null;
  }
  
  public Byte getAsByte(String paramString)
  {
    Object localObject = this.mValues.get(paramString);
    if (localObject != null) {}
    for (;;)
    {
      try
      {
        Byte localByte3 = Byte.valueOf(((Number)localObject).byteValue());
        localByte1 = localByte3;
        return localByte1;
      }
      catch (ClassCastException localClassCastException)
      {
        Byte localByte1;
        if (!(localObject instanceof CharSequence)) {
          continue;
        }
        try
        {
          Byte localByte2 = Byte.valueOf(localObject.toString());
          return localByte2;
        }
        catch (NumberFormatException localNumberFormatException)
        {
          Log.e("ContentValues", "Cannot parse Byte value for " + localObject + " at key " + paramString);
          return null;
        }
        Log.e("ContentValues", "Cannot cast value for " + paramString + " to a Byte: " + localObject, localClassCastException);
      }
      localByte1 = null;
    }
    return null;
  }
  
  public byte[] getAsByteArray(String paramString)
  {
    Object localObject = this.mValues.get(paramString);
    if ((localObject instanceof byte[])) {
      return (byte[])localObject;
    }
    return null;
  }
  
  public Double getAsDouble(String paramString)
  {
    Object localObject = this.mValues.get(paramString);
    if (localObject != null) {}
    for (;;)
    {
      try
      {
        Double localDouble3 = Double.valueOf(((Number)localObject).doubleValue());
        localDouble1 = localDouble3;
        return localDouble1;
      }
      catch (ClassCastException localClassCastException)
      {
        Double localDouble1;
        if (!(localObject instanceof CharSequence)) {
          continue;
        }
        try
        {
          Double localDouble2 = Double.valueOf(localObject.toString());
          return localDouble2;
        }
        catch (NumberFormatException localNumberFormatException)
        {
          Log.e("ContentValues", "Cannot parse Double value for " + localObject + " at key " + paramString);
          return null;
        }
        Log.e("ContentValues", "Cannot cast value for " + paramString + " to a Double: " + localObject, localClassCastException);
      }
      localDouble1 = null;
    }
    return null;
  }
  
  public Float getAsFloat(String paramString)
  {
    Object localObject = this.mValues.get(paramString);
    if (localObject != null) {}
    for (;;)
    {
      try
      {
        Float localFloat3 = Float.valueOf(((Number)localObject).floatValue());
        localFloat1 = localFloat3;
        return localFloat1;
      }
      catch (ClassCastException localClassCastException)
      {
        Float localFloat1;
        if (!(localObject instanceof CharSequence)) {
          continue;
        }
        try
        {
          Float localFloat2 = Float.valueOf(localObject.toString());
          return localFloat2;
        }
        catch (NumberFormatException localNumberFormatException)
        {
          Log.e("ContentValues", "Cannot parse Float value for " + localObject + " at key " + paramString);
          return null;
        }
        Log.e("ContentValues", "Cannot cast value for " + paramString + " to a Float: " + localObject, localClassCastException);
      }
      localFloat1 = null;
    }
    return null;
  }
  
  public Integer getAsInteger(String paramString)
  {
    Object localObject = this.mValues.get(paramString);
    if (localObject != null) {}
    for (;;)
    {
      try
      {
        Integer localInteger3 = Integer.valueOf(((Number)localObject).intValue());
        localInteger1 = localInteger3;
        return localInteger1;
      }
      catch (ClassCastException localClassCastException)
      {
        Integer localInteger1;
        if (!(localObject instanceof CharSequence)) {
          continue;
        }
        try
        {
          Integer localInteger2 = Integer.valueOf(localObject.toString());
          return localInteger2;
        }
        catch (NumberFormatException localNumberFormatException)
        {
          Log.e("ContentValues", "Cannot parse Integer value for " + localObject + " at key " + paramString);
          return null;
        }
        Log.e("ContentValues", "Cannot cast value for " + paramString + " to a Integer: " + localObject, localClassCastException);
      }
      localInteger1 = null;
    }
    return null;
  }
  
  public Long getAsLong(String paramString)
  {
    Object localObject = this.mValues.get(paramString);
    if (localObject != null) {}
    for (;;)
    {
      try
      {
        Long localLong3 = Long.valueOf(((Number)localObject).longValue());
        localLong1 = localLong3;
        return localLong1;
      }
      catch (ClassCastException localClassCastException)
      {
        Long localLong1;
        if (!(localObject instanceof CharSequence)) {
          continue;
        }
        try
        {
          Long localLong2 = Long.valueOf(localObject.toString());
          return localLong2;
        }
        catch (NumberFormatException localNumberFormatException)
        {
          Log.e("ContentValues", "Cannot parse Long value for " + localObject + " at key " + paramString);
          return null;
        }
        Log.e("ContentValues", "Cannot cast value for " + paramString + " to a Long: " + localObject, localClassCastException);
      }
      localLong1 = null;
    }
    return null;
  }
  
  public Short getAsShort(String paramString)
  {
    Object localObject = this.mValues.get(paramString);
    if (localObject != null) {}
    for (;;)
    {
      try
      {
        Short localShort3 = Short.valueOf(((Number)localObject).shortValue());
        localShort1 = localShort3;
        return localShort1;
      }
      catch (ClassCastException localClassCastException)
      {
        Short localShort1;
        if (!(localObject instanceof CharSequence)) {
          continue;
        }
        try
        {
          Short localShort2 = Short.valueOf(localObject.toString());
          return localShort2;
        }
        catch (NumberFormatException localNumberFormatException)
        {
          Log.e("ContentValues", "Cannot parse Short value for " + localObject + " at key " + paramString);
          return null;
        }
        Log.e("ContentValues", "Cannot cast value for " + paramString + " to a Short: " + localObject, localClassCastException);
      }
      localShort1 = null;
    }
    return null;
  }
  
  public String getAsString(String paramString)
  {
    Object localObject = this.mValues.get(paramString);
    if (localObject != null) {
      return localObject.toString();
    }
    return null;
  }
  
  @Deprecated
  public ArrayList<String> getStringArrayList(String paramString)
  {
    return (ArrayList)this.mValues.get(paramString);
  }
  
  public int hashCode()
  {
    return this.mValues.hashCode();
  }
  
  public Set<String> keySet()
  {
    return this.mValues.keySet();
  }
  
  public void put(String paramString, Boolean paramBoolean)
  {
    this.mValues.put(paramString, paramBoolean);
  }
  
  public void put(String paramString, Byte paramByte)
  {
    this.mValues.put(paramString, paramByte);
  }
  
  public void put(String paramString, Double paramDouble)
  {
    this.mValues.put(paramString, paramDouble);
  }
  
  public void put(String paramString, Float paramFloat)
  {
    this.mValues.put(paramString, paramFloat);
  }
  
  public void put(String paramString, Integer paramInteger)
  {
    this.mValues.put(paramString, paramInteger);
  }
  
  public void put(String paramString, Long paramLong)
  {
    this.mValues.put(paramString, paramLong);
  }
  
  public void put(String paramString, Short paramShort)
  {
    this.mValues.put(paramString, paramShort);
  }
  
  public void put(String paramString1, String paramString2)
  {
    this.mValues.put(paramString1, paramString2);
  }
  
  public void put(String paramString, byte[] paramArrayOfByte)
  {
    this.mValues.put(paramString, paramArrayOfByte);
  }
  
  public void putAll(ContentValues paramContentValues)
  {
    this.mValues.putAll(paramContentValues.mValues);
  }
  
  public void putNull(String paramString)
  {
    this.mValues.put(paramString, null);
  }
  
  @Deprecated
  public void putStringArrayList(String paramString, ArrayList<String> paramArrayList)
  {
    this.mValues.put(paramString, paramArrayList);
  }
  
  public void remove(String paramString)
  {
    this.mValues.remove(paramString);
  }
  
  public int size()
  {
    return this.mValues.size();
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    Iterator localIterator = this.mValues.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str1 = (String)localIterator.next();
      String str2 = getAsString(str1);
      if (localStringBuilder.length() > 0) {
        localStringBuilder.append(" ");
      }
      localStringBuilder.append(str1 + "=" + str2);
    }
    return localStringBuilder.toString();
  }
  
  public Set<Map.Entry<String, Object>> valueSet()
  {
    return this.mValues.entrySet();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeMap(this.mValues);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\ContentValues.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.content;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public final class ComponentName
  implements Parcelable, Cloneable, Comparable<ComponentName>
{
  public static final Parcelable.Creator<ComponentName> CREATOR = new Parcelable.Creator()
  {
    public ComponentName createFromParcel(Parcel paramAnonymousParcel)
    {
      return new ComponentName(paramAnonymousParcel);
    }
    
    public ComponentName[] newArray(int paramAnonymousInt)
    {
      return new ComponentName[paramAnonymousInt];
    }
  };
  private final String mClass;
  private final String mPackage;
  
  public ComponentName(Context paramContext, Class<?> paramClass)
  {
    this.mPackage = paramContext.getPackageName();
    this.mClass = paramClass.getName();
  }
  
  public ComponentName(Context paramContext, String paramString)
  {
    if (paramString == null) {
      throw new NullPointerException("class name is null");
    }
    this.mPackage = paramContext.getPackageName();
    this.mClass = paramString;
  }
  
  public ComponentName(Parcel paramParcel)
  {
    this.mPackage = paramParcel.readString();
    if (this.mPackage == null) {
      throw new NullPointerException("package name is null");
    }
    this.mClass = paramParcel.readString();
    if (this.mClass == null) {
      throw new NullPointerException("class name is null");
    }
  }
  
  private ComponentName(String paramString, Parcel paramParcel)
  {
    this.mPackage = paramString;
    this.mClass = paramParcel.readString();
  }
  
  public ComponentName(String paramString1, String paramString2)
  {
    if (paramString1 == null) {
      throw new NullPointerException("package name is null");
    }
    if (paramString2 == null) {
      throw new NullPointerException("class name is null");
    }
    this.mPackage = paramString1;
    this.mClass = paramString2;
  }
  
  public static ComponentName readFromParcel(Parcel paramParcel)
  {
    String str = paramParcel.readString();
    if (str != null) {
      return new ComponentName(str, paramParcel);
    }
    return null;
  }
  
  public static ComponentName unflattenFromString(String paramString)
  {
    int i = paramString.indexOf('/');
    if ((i < 0) || (i + 1 >= paramString.length())) {
      return null;
    }
    String str1 = paramString.substring(0, i);
    String str2 = paramString.substring(i + 1);
    if ((str2.length() > 0) && (str2.charAt(0) == '.')) {
      str2 = str1 + str2;
    }
    return new ComponentName(str1, str2);
  }
  
  public static void writeToParcel(ComponentName paramComponentName, Parcel paramParcel)
  {
    if (paramComponentName != null)
    {
      paramComponentName.writeToParcel(paramParcel, 0);
      return;
    }
    paramParcel.writeString(null);
  }
  
  public ComponentName clone()
  {
    return new ComponentName(this.mPackage, this.mClass);
  }
  
  public int compareTo(ComponentName paramComponentName)
  {
    int i = this.mPackage.compareTo(paramComponentName.mPackage);
    if (i != 0) {
      return i;
    }
    return this.mClass.compareTo(paramComponentName.mClass);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    boolean bool1 = false;
    if (paramObject != null) {}
    try
    {
      ComponentName localComponentName = (ComponentName)paramObject;
      boolean bool2 = this.mPackage.equals(localComponentName.mPackage);
      bool1 = false;
      if (bool2)
      {
        boolean bool3 = this.mClass.equals(localComponentName.mClass);
        bool1 = false;
        if (bool3) {
          bool1 = true;
        }
      }
      return bool1;
    }
    catch (ClassCastException localClassCastException) {}
    return false;
  }
  
  public String flattenToShortString()
  {
    return this.mPackage + "/" + getShortClassName();
  }
  
  public String flattenToString()
  {
    return this.mPackage + "/" + this.mClass;
  }
  
  public String getClassName()
  {
    return this.mClass;
  }
  
  public String getPackageName()
  {
    return this.mPackage;
  }
  
  public String getShortClassName()
  {
    if (this.mClass.startsWith(this.mPackage))
    {
      int i = this.mPackage.length();
      int j = this.mClass.length();
      if ((j > i) && (this.mClass.charAt(i) == '.')) {
        return this.mClass.substring(i, j);
      }
    }
    return this.mClass;
  }
  
  public int hashCode()
  {
    return this.mPackage.hashCode() + this.mClass.hashCode();
  }
  
  public String toShortString()
  {
    return "{" + this.mPackage + "/" + this.mClass + "}";
  }
  
  public String toString()
  {
    return "ComponentInfo{" + this.mPackage + "/" + this.mClass + "}";
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeString(this.mPackage);
    paramParcel.writeString(this.mClass);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\ComponentName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
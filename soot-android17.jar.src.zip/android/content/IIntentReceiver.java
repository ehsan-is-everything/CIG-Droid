package android.content;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface IIntentReceiver
  extends IInterface
{
  public abstract void performReceive(Intent paramIntent, int paramInt1, String paramString, Bundle paramBundle, boolean paramBoolean1, boolean paramBoolean2, int paramInt2)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IIntentReceiver
  {
    private static final String DESCRIPTOR = "android.content.IIntentReceiver";
    static final int TRANSACTION_performReceive = 1;
    
    public Stub()
    {
      attachInterface(this, "android.content.IIntentReceiver");
    }
    
    public static IIntentReceiver asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.content.IIntentReceiver");
      if ((localIInterface != null) && ((localIInterface instanceof IIntentReceiver))) {
        return (IIntentReceiver)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.content.IIntentReceiver");
        return true;
      }
      paramParcel1.enforceInterface("android.content.IIntentReceiver");
      Intent localIntent;
      int i;
      String str;
      Bundle localBundle;
      label106:
      boolean bool1;
      if (paramParcel1.readInt() != 0)
      {
        localIntent = (Intent)Intent.CREATOR.createFromParcel(paramParcel1);
        i = paramParcel1.readInt();
        str = paramParcel1.readString();
        if (paramParcel1.readInt() == 0) {
          break label154;
        }
        localBundle = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
        if (paramParcel1.readInt() == 0) {
          break label160;
        }
        bool1 = true;
        label116:
        if (paramParcel1.readInt() == 0) {
          break label166;
        }
      }
      label154:
      label160:
      label166:
      for (boolean bool2 = true;; bool2 = false)
      {
        performReceive(localIntent, i, str, localBundle, bool1, bool2, paramParcel1.readInt());
        return true;
        localIntent = null;
        break;
        localBundle = null;
        break label106;
        bool1 = false;
        break label116;
      }
    }
    
    private static class Proxy
      implements IIntentReceiver
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.content.IIntentReceiver";
      }
      
      public void performReceive(Intent paramIntent, int paramInt1, String paramString, Bundle paramBundle, boolean paramBoolean1, boolean paramBoolean2, int paramInt2)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel.writeInterfaceToken("android.content.IIntentReceiver");
            if (paramIntent != null)
            {
              localParcel.writeInt(1);
              paramIntent.writeToParcel(localParcel, 0);
              localParcel.writeInt(paramInt1);
              localParcel.writeString(paramString);
              if (paramBundle != null)
              {
                localParcel.writeInt(1);
                paramBundle.writeToParcel(localParcel, 0);
                break label153;
                localParcel.writeInt(j);
                if (!paramBoolean2) {
                  break label147;
                }
                label78:
                localParcel.writeInt(i);
                localParcel.writeInt(paramInt2);
                this.mRemote.transact(1, localParcel, null, 1);
              }
            }
            else
            {
              localParcel.writeInt(0);
              continue;
            }
            localParcel.writeInt(0);
          }
          finally
          {
            localParcel.recycle();
          }
          label147:
          label153:
          while (!paramBoolean1)
          {
            j = 0;
            break;
            i = 0;
            break label78;
          }
          int j = i;
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\IIntentReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
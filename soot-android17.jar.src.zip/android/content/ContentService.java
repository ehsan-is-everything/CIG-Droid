package android.content;

import android.accounts.Account;
import android.app.ActivityManager;
import android.database.IContentObserver;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IBinder.DeathRecipient;
import android.os.Parcel;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.UserHandle;
import android.util.Log;
import android.util.SparseIntArray;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class ContentService
  extends IContentService.Stub
{
  private static final String TAG = "ContentService";
  private Context mContext;
  private boolean mFactoryTest;
  private final ObserverNode mRootNode = new ObserverNode("");
  private SyncManager mSyncManager = null;
  private final Object mSyncManagerLock = new Object();
  
  ContentService(Context paramContext, boolean paramBoolean)
  {
    this.mContext = paramContext;
    this.mFactoryTest = paramBoolean;
  }
  
  private SyncManager getSyncManager()
  {
    synchronized (this.mSyncManagerLock)
    {
      try
      {
        if (this.mSyncManager == null) {
          this.mSyncManager = new SyncManager(this.mContext, this.mFactoryTest);
        }
        SyncManager localSyncManager = this.mSyncManager;
        return localSyncManager;
      }
      catch (SQLiteException localSQLiteException)
      {
        for (;;)
        {
          Log.e("ContentService", "Can't create SyncManager", localSQLiteException);
        }
      }
    }
  }
  
  public static ContentService main(Context paramContext, boolean paramBoolean)
  {
    ContentService localContentService = new ContentService(paramContext, paramBoolean);
    ServiceManager.addService("content", localContentService);
    return localContentService;
  }
  
  public void addPeriodicSync(Account paramAccount, String paramString, Bundle paramBundle, long paramLong)
  {
    this.mContext.enforceCallingOrSelfPermission("android.permission.WRITE_SYNC_SETTINGS", "no permission to write the sync settings");
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    try
    {
      getSyncManager().getSyncStorageEngine().addPeriodicSync(paramAccount, i, paramString, paramBundle, paramLong);
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public void addStatusChangeListener(int paramInt, ISyncStatusObserver paramISyncStatusObserver)
  {
    long l = clearCallingIdentity();
    try
    {
      SyncManager localSyncManager = getSyncManager();
      if ((localSyncManager != null) && (paramISyncStatusObserver != null)) {
        localSyncManager.getSyncStorageEngine().addStatusChangeListener(paramInt, paramISyncStatusObserver);
      }
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public void cancelSync(Account paramAccount, String paramString)
  {
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    try
    {
      SyncManager localSyncManager = getSyncManager();
      if (localSyncManager != null)
      {
        localSyncManager.clearScheduledSyncOperations(paramAccount, i, paramString);
        localSyncManager.cancelActiveSync(paramAccount, i, paramString);
      }
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  /* Error */
  protected void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 41	android/content/ContentService:mContext	Landroid/content/Context;
    //   6: ldc 124
    //   8: ldc 126
    //   10: invokevirtual 82	android/content/Context:enforceCallingOrSelfPermission	(Ljava/lang/String;Ljava/lang/String;)V
    //   13: invokestatic 92	android/content/ContentService:clearCallingIdentity	()J
    //   16: lstore 5
    //   18: aload_0
    //   19: getfield 34	android/content/ContentService:mSyncManager	Landroid/content/SyncManager;
    //   22: ifnonnull +108 -> 130
    //   25: aload_2
    //   26: ldc -128
    //   28: invokevirtual 133	java/io/PrintWriter:println	(Ljava/lang/String;)V
    //   31: aload_2
    //   32: invokevirtual 135	java/io/PrintWriter:println	()V
    //   35: aload_2
    //   36: ldc -119
    //   38: invokevirtual 133	java/io/PrintWriter:println	(Ljava/lang/String;)V
    //   41: aload_0
    //   42: getfield 32	android/content/ContentService:mRootNode	Landroid/content/ContentService$ObserverNode;
    //   45: astore 8
    //   47: aload 8
    //   49: monitorenter
    //   50: iconst_2
    //   51: newarray <illegal type>
    //   53: astore 10
    //   55: new 139	android/util/SparseIntArray
    //   58: dup
    //   59: invokespecial 140	android/util/SparseIntArray:<init>	()V
    //   62: astore 11
    //   64: aload_0
    //   65: getfield 32	android/content/ContentService:mRootNode	Landroid/content/ContentService$ObserverNode;
    //   68: aload_1
    //   69: aload_2
    //   70: aload_3
    //   71: ldc 27
    //   73: ldc -114
    //   75: aload 10
    //   77: aload 11
    //   79: invokevirtual 146	android/content/ContentService$ObserverNode:dumpLocked	(Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[ILandroid/util/SparseIntArray;)V
    //   82: aload_2
    //   83: invokevirtual 135	java/io/PrintWriter:println	()V
    //   86: new 148	java/util/ArrayList
    //   89: dup
    //   90: invokespecial 149	java/util/ArrayList:<init>	()V
    //   93: astore 12
    //   95: iconst_0
    //   96: istore 13
    //   98: iload 13
    //   100: aload 11
    //   102: invokevirtual 152	android/util/SparseIntArray:size	()I
    //   105: if_icmpge +54 -> 159
    //   108: aload 12
    //   110: aload 11
    //   112: iload 13
    //   114: invokevirtual 156	android/util/SparseIntArray:keyAt	(I)I
    //   117: invokestatic 162	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   120: invokevirtual 166	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   123: pop
    //   124: iinc 13 1
    //   127: goto -29 -> 98
    //   130: aload_0
    //   131: getfield 34	android/content/ContentService:mSyncManager	Landroid/content/SyncManager;
    //   134: aload_1
    //   135: aload_2
    //   136: invokevirtual 169	android/content/SyncManager:dump	(Ljava/io/FileDescriptor;Ljava/io/PrintWriter;)V
    //   139: goto -108 -> 31
    //   142: astore 7
    //   144: lload 5
    //   146: invokestatic 107	android/content/ContentService:restoreCallingIdentity	(J)V
    //   149: aload 7
    //   151: athrow
    //   152: astore 4
    //   154: aload_0
    //   155: monitorexit
    //   156: aload 4
    //   158: athrow
    //   159: aload 12
    //   161: new 171	android/content/ContentService$1
    //   164: dup
    //   165: aload_0
    //   166: aload 11
    //   168: invokespecial 174	android/content/ContentService$1:<init>	(Landroid/content/ContentService;Landroid/util/SparseIntArray;)V
    //   171: invokestatic 180	java/util/Collections:sort	(Ljava/util/List;Ljava/util/Comparator;)V
    //   174: iconst_0
    //   175: istore 14
    //   177: iload 14
    //   179: aload 12
    //   181: invokevirtual 181	java/util/ArrayList:size	()I
    //   184: if_icmpge +59 -> 243
    //   187: aload 12
    //   189: iload 14
    //   191: invokevirtual 185	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   194: checkcast 158	java/lang/Integer
    //   197: invokevirtual 188	java/lang/Integer:intValue	()I
    //   200: istore 15
    //   202: aload_2
    //   203: ldc -66
    //   205: invokevirtual 193	java/io/PrintWriter:print	(Ljava/lang/String;)V
    //   208: aload_2
    //   209: iload 15
    //   211: invokevirtual 196	java/io/PrintWriter:print	(I)V
    //   214: aload_2
    //   215: ldc -58
    //   217: invokevirtual 193	java/io/PrintWriter:print	(Ljava/lang/String;)V
    //   220: aload_2
    //   221: aload 11
    //   223: iload 15
    //   225: invokevirtual 200	android/util/SparseIntArray:get	(I)I
    //   228: invokevirtual 196	java/io/PrintWriter:print	(I)V
    //   231: aload_2
    //   232: ldc -54
    //   234: invokevirtual 133	java/io/PrintWriter:println	(Ljava/lang/String;)V
    //   237: iinc 14 1
    //   240: goto -63 -> 177
    //   243: aload_2
    //   244: invokevirtual 135	java/io/PrintWriter:println	()V
    //   247: aload_2
    //   248: ldc -52
    //   250: invokevirtual 193	java/io/PrintWriter:print	(Ljava/lang/String;)V
    //   253: aload_2
    //   254: aload 10
    //   256: iconst_0
    //   257: iaload
    //   258: invokevirtual 206	java/io/PrintWriter:println	(I)V
    //   261: aload_2
    //   262: ldc -48
    //   264: invokevirtual 193	java/io/PrintWriter:print	(Ljava/lang/String;)V
    //   267: aload_2
    //   268: aload 10
    //   270: iconst_1
    //   271: iaload
    //   272: invokevirtual 206	java/io/PrintWriter:println	(I)V
    //   275: aload 8
    //   277: monitorexit
    //   278: lload 5
    //   280: invokestatic 107	android/content/ContentService:restoreCallingIdentity	(J)V
    //   283: aload_0
    //   284: monitorexit
    //   285: return
    //   286: astore 9
    //   288: aload 8
    //   290: monitorexit
    //   291: aload 9
    //   293: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	294	0	this	ContentService
    //   0	294	1	paramFileDescriptor	FileDescriptor
    //   0	294	2	paramPrintWriter	PrintWriter
    //   0	294	3	paramArrayOfString	String[]
    //   152	5	4	localObject1	Object
    //   16	263	5	l	long
    //   142	8	7	localObject2	Object
    //   286	6	9	localObject3	Object
    //   53	216	10	arrayOfInt	int[]
    //   62	160	11	localSparseIntArray	SparseIntArray
    //   93	95	12	localArrayList	ArrayList
    //   96	29	13	i	int
    //   175	63	14	j	int
    //   200	24	15	k	int
    // Exception table:
    //   from	to	target	type
    //   18	31	142	finally
    //   31	50	142	finally
    //   130	139	142	finally
    //   291	294	142	finally
    //   2	18	152	finally
    //   144	152	152	finally
    //   278	283	152	finally
    //   50	95	286	finally
    //   98	124	286	finally
    //   159	174	286	finally
    //   177	237	286	finally
    //   243	278	286	finally
    //   288	291	286	finally
  }
  
  public List<SyncInfo> getCurrentSyncs()
  {
    this.mContext.enforceCallingOrSelfPermission("android.permission.READ_SYNC_STATS", "no permission to read the sync stats");
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    try
    {
      List localList = getSyncManager().getSyncStorageEngine().getCurrentSyncs(i);
      return localList;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public int getIsSyncable(Account paramAccount, String paramString)
  {
    this.mContext.enforceCallingOrSelfPermission("android.permission.READ_SYNC_SETTINGS", "no permission to read the sync settings");
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    try
    {
      SyncManager localSyncManager = getSyncManager();
      if (localSyncManager != null)
      {
        int j = localSyncManager.getSyncStorageEngine().getIsSyncable(paramAccount, i, paramString);
        return j;
      }
      return -1;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public boolean getMasterSyncAutomatically()
  {
    this.mContext.enforceCallingOrSelfPermission("android.permission.READ_SYNC_SETTINGS", "no permission to read the sync settings");
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    try
    {
      SyncManager localSyncManager = getSyncManager();
      if (localSyncManager != null)
      {
        boolean bool = localSyncManager.getSyncStorageEngine().getMasterSyncAutomatically(i);
        return bool;
      }
      return false;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public List<PeriodicSync> getPeriodicSyncs(Account paramAccount, String paramString)
  {
    this.mContext.enforceCallingOrSelfPermission("android.permission.READ_SYNC_SETTINGS", "no permission to read the sync settings");
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    try
    {
      List localList = getSyncManager().getSyncStorageEngine().getPeriodicSyncs(paramAccount, i, paramString);
      return localList;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public SyncAdapterType[] getSyncAdapterTypes()
  {
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    try
    {
      SyncAdapterType[] arrayOfSyncAdapterType = getSyncManager().getSyncAdapterTypes(i);
      return arrayOfSyncAdapterType;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public boolean getSyncAutomatically(Account paramAccount, String paramString)
  {
    this.mContext.enforceCallingOrSelfPermission("android.permission.READ_SYNC_SETTINGS", "no permission to read the sync settings");
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    try
    {
      SyncManager localSyncManager = getSyncManager();
      if (localSyncManager != null)
      {
        boolean bool = localSyncManager.getSyncStorageEngine().getSyncAutomatically(paramAccount, i, paramString);
        return bool;
      }
      return false;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public SyncStatusInfo getSyncStatus(Account paramAccount, String paramString)
  {
    this.mContext.enforceCallingOrSelfPermission("android.permission.READ_SYNC_STATS", "no permission to read the sync stats");
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    try
    {
      SyncManager localSyncManager = getSyncManager();
      if (localSyncManager != null)
      {
        SyncStatusInfo localSyncStatusInfo = localSyncManager.getSyncStorageEngine().getStatusByAccountAndAuthority(paramAccount, i, paramString);
        return localSyncStatusInfo;
      }
      return null;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public boolean isSyncActive(Account paramAccount, String paramString)
  {
    this.mContext.enforceCallingOrSelfPermission("android.permission.READ_SYNC_STATS", "no permission to read the sync stats");
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    try
    {
      SyncManager localSyncManager = getSyncManager();
      if (localSyncManager != null)
      {
        boolean bool = localSyncManager.getSyncStorageEngine().isSyncActive(paramAccount, i, paramString);
        return bool;
      }
      return false;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public boolean isSyncPending(Account paramAccount, String paramString)
  {
    this.mContext.enforceCallingOrSelfPermission("android.permission.READ_SYNC_STATS", "no permission to read the sync stats");
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    try
    {
      SyncManager localSyncManager = getSyncManager();
      if (localSyncManager != null)
      {
        boolean bool = localSyncManager.getSyncStorageEngine().isSyncPending(paramAccount, i, paramString);
        return bool;
      }
      return false;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public void notifyChange(Uri paramUri, IContentObserver paramIContentObserver, boolean paramBoolean1, boolean paramBoolean2)
  {
    notifyChange(paramUri, paramIContentObserver, paramBoolean1, paramBoolean2, UserHandle.getCallingUserId());
  }
  
  public void notifyChange(Uri paramUri, IContentObserver paramIContentObserver, boolean paramBoolean1, boolean paramBoolean2, int paramInt)
  {
    if (Log.isLoggable("ContentService", 2)) {
      Log.v("ContentService", "Notifying update of " + paramUri + " for user " + paramInt + " from observer " + paramIContentObserver + ", syncToNetwork " + paramBoolean2);
    }
    int i = UserHandle.getCallingUserId();
    if (paramInt != i) {
      this.mContext.enforceCallingOrSelfPermission("android.permission.INTERACT_ACROSS_USERS_FULL", "no permission to notify other users");
    }
    if (paramInt < 0)
    {
      if (paramInt != -2) {
        break label256;
      }
      paramInt = ActivityManager.getCurrentUser();
    }
    long l;
    for (;;)
    {
      l = clearCallingIdentity();
      try
      {
        ArrayList localArrayList1 = new ArrayList();
        for (;;)
        {
          ObserverCall localObserverCall;
          synchronized (this.mRootNode)
          {
            this.mRootNode.collectObserversLocked(paramUri, 0, paramIContentObserver, paramBoolean1, paramInt, localArrayList1);
            int j = localArrayList1.size();
            int k = 0;
            if (k >= j) {
              break label422;
            }
            localObserverCall = (ObserverCall)localArrayList1.get(k);
            label256:
            try
            {
              localObserverCall.mObserver.onChange(localObserverCall.mSelfChange, paramUri);
              if (Log.isLoggable("ContentService", 2)) {
                Log.v("ContentService", "Notified " + localObserverCall.mObserver + " of " + "update at " + paramUri);
              }
              k++;
            }
            catch (RemoteException localRemoteException) {}
            if (paramInt == -1) {
              break;
            }
            throw new InvalidParameterException("Bad user handle for notifyChange: " + paramInt);
          }
          synchronized (this.mRootNode)
          {
            Log.w("ContentService", "Found dead observer, removing");
            localIBinder = localObserverCall.mObserver.asBinder();
            localArrayList2 = localObserverCall.mNode.mObservers;
            m = localArrayList2.size();
            n = 0;
            if (n < m)
            {
              if (((ContentService.ObserverNode.ObserverEntry)localArrayList2.get(n)).observer.asBinder() != localIBinder) {
                break label456;
              }
              localArrayList2.remove(n);
              n--;
              m--;
            }
          }
        }
      }
      finally
      {
        restoreCallingIdentity(l);
      }
    }
    for (;;)
    {
      IBinder localIBinder;
      ArrayList localArrayList2;
      int m;
      int n;
      label422:
      if (paramBoolean2)
      {
        SyncManager localSyncManager = getSyncManager();
        if (localSyncManager != null) {
          localSyncManager.scheduleLocalSync(null, i, paramUri.getAuthority());
        }
      }
      restoreCallingIdentity(l);
      return;
      label456:
      n++;
    }
  }
  
  public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
    throws RemoteException
  {
    try
    {
      boolean bool = super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      return bool;
    }
    catch (RuntimeException localRuntimeException)
    {
      if (!(localRuntimeException instanceof SecurityException)) {
        Log.e("ContentService", "Content Service Crash", localRuntimeException);
      }
      throw localRuntimeException;
    }
  }
  
  public void registerContentObserver(Uri paramUri, boolean paramBoolean, IContentObserver paramIContentObserver)
  {
    registerContentObserver(paramUri, paramBoolean, paramIContentObserver, UserHandle.getCallingUserId());
  }
  
  public void registerContentObserver(Uri paramUri, boolean paramBoolean, IContentObserver paramIContentObserver, int paramInt)
  {
    if ((paramIContentObserver == null) || (paramUri == null)) {
      throw new IllegalArgumentException("You must pass a valid uri and observer");
    }
    if (UserHandle.getCallingUserId() != paramInt) {
      this.mContext.enforceCallingOrSelfPermission("android.permission.INTERACT_ACROSS_USERS_FULL", "no permission to observe other users' provider view");
    }
    if (paramInt < 0)
    {
      if (paramInt != -2) {
        break label92;
      }
      paramInt = ActivityManager.getCurrentUser();
    }
    synchronized (this.mRootNode)
    {
      label92:
      do
      {
        this.mRootNode.addObserverLocked(paramUri, paramIContentObserver, paramBoolean, this.mRootNode, Binder.getCallingUid(), Binder.getCallingPid(), paramInt);
        return;
      } while (paramInt == -1);
      throw new InvalidParameterException("Bad user handle for registerContentObserver: " + paramInt);
    }
  }
  
  public void removePeriodicSync(Account paramAccount, String paramString, Bundle paramBundle)
  {
    this.mContext.enforceCallingOrSelfPermission("android.permission.WRITE_SYNC_SETTINGS", "no permission to write the sync settings");
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    try
    {
      getSyncManager().getSyncStorageEngine().removePeriodicSync(paramAccount, i, paramString, paramBundle);
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public void removeStatusChangeListener(ISyncStatusObserver paramISyncStatusObserver)
  {
    long l = clearCallingIdentity();
    try
    {
      SyncManager localSyncManager = getSyncManager();
      if ((localSyncManager != null) && (paramISyncStatusObserver != null)) {
        localSyncManager.getSyncStorageEngine().removeStatusChangeListener(paramISyncStatusObserver);
      }
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public void requestSync(Account paramAccount, String paramString, Bundle paramBundle)
  {
    ContentResolver.validateSyncExtrasBundle(paramBundle);
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    try
    {
      SyncManager localSyncManager = getSyncManager();
      if (localSyncManager != null) {
        localSyncManager.scheduleSync(paramAccount, i, paramString, paramBundle, 0L, false);
      }
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public void setIsSyncable(Account paramAccount, String paramString, int paramInt)
  {
    this.mContext.enforceCallingOrSelfPermission("android.permission.WRITE_SYNC_SETTINGS", "no permission to write the sync settings");
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    try
    {
      SyncManager localSyncManager = getSyncManager();
      if (localSyncManager != null) {
        localSyncManager.getSyncStorageEngine().setIsSyncable(paramAccount, i, paramString, paramInt);
      }
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public void setMasterSyncAutomatically(boolean paramBoolean)
  {
    this.mContext.enforceCallingOrSelfPermission("android.permission.WRITE_SYNC_SETTINGS", "no permission to write the sync settings");
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    try
    {
      SyncManager localSyncManager = getSyncManager();
      if (localSyncManager != null) {
        localSyncManager.getSyncStorageEngine().setMasterSyncAutomatically(paramBoolean, i);
      }
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public void setSyncAutomatically(Account paramAccount, String paramString, boolean paramBoolean)
  {
    this.mContext.enforceCallingOrSelfPermission("android.permission.WRITE_SYNC_SETTINGS", "no permission to write the sync settings");
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    try
    {
      SyncManager localSyncManager = getSyncManager();
      if (localSyncManager != null) {
        localSyncManager.getSyncStorageEngine().setSyncAutomatically(paramAccount, i, paramString, paramBoolean);
      }
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public void systemReady()
  {
    getSyncManager();
  }
  
  public void unregisterContentObserver(IContentObserver paramIContentObserver)
  {
    if (paramIContentObserver == null) {
      throw new IllegalArgumentException("You must pass a valid observer");
    }
    synchronized (this.mRootNode)
    {
      this.mRootNode.removeObserverLocked(paramIContentObserver);
      return;
    }
  }
  
  public static final class ObserverCall
  {
    final ContentService.ObserverNode mNode;
    final IContentObserver mObserver;
    final boolean mSelfChange;
    
    ObserverCall(ContentService.ObserverNode paramObserverNode, IContentObserver paramIContentObserver, boolean paramBoolean)
    {
      this.mNode = paramObserverNode;
      this.mObserver = paramIContentObserver;
      this.mSelfChange = paramBoolean;
    }
  }
  
  public static final class ObserverNode
  {
    public static final int DELETE_TYPE = 2;
    public static final int INSERT_TYPE = 0;
    public static final int UPDATE_TYPE = 1;
    private ArrayList<ObserverNode> mChildren = new ArrayList();
    private String mName;
    private ArrayList<ObserverEntry> mObservers = new ArrayList();
    
    public ObserverNode(String paramString)
    {
      this.mName = paramString;
    }
    
    private void addObserverLocked(Uri paramUri, int paramInt1, IContentObserver paramIContentObserver, boolean paramBoolean, Object paramObject, int paramInt2, int paramInt3, int paramInt4)
    {
      if (paramInt1 == countUriSegments(paramUri))
      {
        this.mObservers.add(new ObserverEntry(paramIContentObserver, paramBoolean, paramObject, paramInt2, paramInt3, paramInt4));
        return;
      }
      String str = getUriSegment(paramUri, paramInt1);
      if (str == null) {
        throw new IllegalArgumentException("Invalid Uri (" + paramUri + ") used for observer");
      }
      int i = this.mChildren.size();
      for (int j = 0; j < i; j++)
      {
        ObserverNode localObserverNode2 = (ObserverNode)this.mChildren.get(j);
        if (localObserverNode2.mName.equals(str))
        {
          localObserverNode2.addObserverLocked(paramUri, paramInt1 + 1, paramIContentObserver, paramBoolean, paramObject, paramInt2, paramInt3, paramInt4);
          return;
        }
      }
      ObserverNode localObserverNode1 = new ObserverNode(str);
      this.mChildren.add(localObserverNode1);
      localObserverNode1.addObserverLocked(paramUri, paramInt1 + 1, paramIContentObserver, paramBoolean, paramObject, paramInt2, paramInt3, paramInt4);
    }
    
    private void collectMyObserversLocked(boolean paramBoolean1, IContentObserver paramIContentObserver, boolean paramBoolean2, int paramInt, ArrayList<ContentService.ObserverCall> paramArrayList)
    {
      int i = this.mObservers.size();
      IBinder localIBinder;
      int j;
      label19:
      ObserverEntry localObserverEntry;
      boolean bool;
      if (paramIContentObserver == null)
      {
        localIBinder = null;
        j = 0;
        if (j >= i) {
          return;
        }
        localObserverEntry = (ObserverEntry)this.mObservers.get(j);
        if (localObserverEntry.observer.asBinder() != localIBinder) {
          break label84;
        }
        bool = true;
        label58:
        if ((!bool) || (paramBoolean2)) {
          break label90;
        }
      }
      for (;;)
      {
        j++;
        break label19;
        localIBinder = paramIContentObserver.asBinder();
        break;
        label84:
        bool = false;
        break label58;
        label90:
        if (((paramInt == -1) || (localObserverEntry.userHandle == -1) || (paramInt == localObserverEntry.userHandle)) && ((paramBoolean1) || ((!paramBoolean1) && (localObserverEntry.notifyForDescendants)))) {
          paramArrayList.add(new ContentService.ObserverCall(this, localObserverEntry.observer, bool));
        }
      }
    }
    
    private int countUriSegments(Uri paramUri)
    {
      if (paramUri == null) {
        return 0;
      }
      return 1 + paramUri.getPathSegments().size();
    }
    
    private String getUriSegment(Uri paramUri, int paramInt)
    {
      if (paramUri != null)
      {
        if (paramInt == 0) {
          return paramUri.getAuthority();
        }
        return (String)paramUri.getPathSegments().get(paramInt - 1);
      }
      return null;
    }
    
    public void addObserverLocked(Uri paramUri, IContentObserver paramIContentObserver, boolean paramBoolean, Object paramObject, int paramInt1, int paramInt2, int paramInt3)
    {
      addObserverLocked(paramUri, 0, paramIContentObserver, paramBoolean, paramObject, paramInt1, paramInt2, paramInt3);
    }
    
    public void collectObserversLocked(Uri paramUri, int paramInt1, IContentObserver paramIContentObserver, boolean paramBoolean, int paramInt2, ArrayList<ContentService.ObserverCall> paramArrayList)
    {
      Object localObject = null;
      int i = countUriSegments(paramUri);
      int j;
      if (paramInt1 >= i)
      {
        collectMyObserversLocked(true, paramIContentObserver, paramBoolean, paramInt2, paramArrayList);
        j = this.mChildren.size();
      }
      for (int k = 0;; k++) {
        if (k < j)
        {
          ObserverNode localObserverNode = (ObserverNode)this.mChildren.get(k);
          if ((localObject == null) || (localObserverNode.mName.equals(localObject)))
          {
            localObserverNode.collectObserversLocked(paramUri, paramInt1 + 1, paramIContentObserver, paramBoolean, paramInt2, paramArrayList);
            if (localObject == null) {}
          }
        }
        else
        {
          return;
          localObject = null;
          if (paramInt1 >= i) {
            break;
          }
          localObject = getUriSegment(paramUri, paramInt1);
          collectMyObserversLocked(false, paramIContentObserver, paramBoolean, paramInt2, paramArrayList);
          break;
        }
      }
    }
    
    public void dumpLocked(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString, String paramString1, String paramString2, int[] paramArrayOfInt, SparseIntArray paramSparseIntArray)
    {
      int i = this.mObservers.size();
      String str = null;
      if (i > 0)
      {
        if ("".equals(paramString1)) {}
        for (str = this.mName;; str = paramString1 + "/" + this.mName) {
          for (int k = 0; k < this.mObservers.size(); k++)
          {
            paramArrayOfInt[1] = (1 + paramArrayOfInt[1]);
            ((ObserverEntry)this.mObservers.get(k)).dumpLocked(paramFileDescriptor, paramPrintWriter, paramArrayOfString, str, paramString2, paramSparseIntArray);
          }
        }
      }
      if (this.mChildren.size() > 0)
      {
        if (str == null) {
          if (!"".equals(paramString1)) {
            break label208;
          }
        }
        label208:
        for (str = this.mName;; str = paramString1 + "/" + this.mName) {
          for (int j = 0; j < this.mChildren.size(); j++)
          {
            paramArrayOfInt[0] = (1 + paramArrayOfInt[0]);
            ((ObserverNode)this.mChildren.get(j)).dumpLocked(paramFileDescriptor, paramPrintWriter, paramArrayOfString, str, paramString2, paramArrayOfInt, paramSparseIntArray);
          }
        }
      }
    }
    
    public boolean removeObserverLocked(IContentObserver paramIContentObserver)
    {
      int i = this.mChildren.size();
      for (int j = 0; j < i; j++) {
        if (((ObserverNode)this.mChildren.get(j)).removeObserverLocked(paramIContentObserver))
        {
          this.mChildren.remove(j);
          j--;
          i--;
        }
      }
      IBinder localIBinder = paramIContentObserver.asBinder();
      int k = this.mObservers.size();
      for (int m = 0;; m++) {
        if (m < k)
        {
          ObserverEntry localObserverEntry = (ObserverEntry)this.mObservers.get(m);
          if (localObserverEntry.observer.asBinder() == localIBinder)
          {
            this.mObservers.remove(m);
            localIBinder.unlinkToDeath(localObserverEntry, 0);
          }
        }
        else
        {
          if ((this.mChildren.size() != 0) || (this.mObservers.size() != 0)) {
            break;
          }
          return true;
        }
      }
      return false;
    }
    
    private class ObserverEntry
      implements IBinder.DeathRecipient
    {
      public final boolean notifyForDescendants;
      public final IContentObserver observer;
      private final Object observersLock;
      public final int pid;
      public final int uid;
      private final int userHandle;
      
      public ObserverEntry(IContentObserver paramIContentObserver, boolean paramBoolean, Object paramObject, int paramInt1, int paramInt2, int paramInt3)
      {
        this.observersLock = paramObject;
        this.observer = paramIContentObserver;
        this.uid = paramInt1;
        this.pid = paramInt2;
        this.userHandle = paramInt3;
        this.notifyForDescendants = paramBoolean;
        try
        {
          this.observer.asBinder().linkToDeath(this, 0);
          return;
        }
        catch (RemoteException localRemoteException)
        {
          binderDied();
        }
      }
      
      public void binderDied()
      {
        synchronized (this.observersLock)
        {
          ContentService.ObserverNode.this.removeObserverLocked(this.observer);
          return;
        }
      }
      
      public void dumpLocked(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString, String paramString1, String paramString2, SparseIntArray paramSparseIntArray)
      {
        paramSparseIntArray.put(this.pid, 1 + paramSparseIntArray.get(this.pid));
        paramPrintWriter.print(paramString2);
        paramPrintWriter.print(paramString1);
        paramPrintWriter.print(": pid=");
        paramPrintWriter.print(this.pid);
        paramPrintWriter.print(" uid=");
        paramPrintWriter.print(this.uid);
        paramPrintWriter.print(" user=");
        paramPrintWriter.print(this.userHandle);
        paramPrintWriter.print(" target=");
        if (this.observer != null) {}
        for (IBinder localIBinder = this.observer.asBinder();; localIBinder = null)
        {
          paramPrintWriter.println(Integer.toHexString(System.identityHashCode(localIBinder)));
          return;
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\ContentService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.content;

import android.net.Uri;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class UriMatcher
{
  private static final int EXACT = 0;
  public static final int NO_MATCH = -1;
  private static final int NUMBER = 1;
  static final Pattern PATH_SPLIT_PATTERN = Pattern.compile("/");
  private static final int TEXT = 2;
  private ArrayList<UriMatcher> mChildren;
  private int mCode;
  private String mText;
  private int mWhich;
  
  private UriMatcher()
  {
    this.mCode = -1;
    this.mWhich = -1;
    this.mChildren = new ArrayList();
    this.mText = null;
  }
  
  public UriMatcher(int paramInt)
  {
    this.mCode = paramInt;
    this.mWhich = -1;
    this.mChildren = new ArrayList();
    this.mText = null;
  }
  
  public void addURI(String paramString1, String paramString2, int paramInt)
  {
    if (paramInt < 0) {
      throw new IllegalArgumentException("code " + paramInt + " is invalid: it must be positive");
    }
    String[] arrayOfString;
    int i;
    label59:
    Object localObject;
    int j;
    label65:
    String str;
    label80:
    int m;
    label97:
    UriMatcher localUriMatcher1;
    if (paramString2 != null)
    {
      arrayOfString = PATH_SPLIT_PATTERN.split(paramString2);
      if (arrayOfString == null) {
        break label199;
      }
      i = arrayOfString.length;
      localObject = this;
      j = -1;
      if (j >= i) {
        break label249;
      }
      if (j >= 0) {
        break label205;
      }
      str = paramString1;
      ArrayList localArrayList = ((UriMatcher)localObject).mChildren;
      int k = localArrayList.size();
      m = 0;
      if (m < k)
      {
        UriMatcher localUriMatcher2 = (UriMatcher)localArrayList.get(m);
        if (!str.equals(localUriMatcher2.mText)) {
          break label215;
        }
        localObject = localUriMatcher2;
      }
      if (m == k)
      {
        localUriMatcher1 = new UriMatcher();
        if (!str.equals("#")) {
          break label221;
        }
        localUriMatcher1.mWhich = 1;
      }
    }
    for (;;)
    {
      localUriMatcher1.mText = str;
      ((UriMatcher)localObject).mChildren.add(localUriMatcher1);
      localObject = localUriMatcher1;
      j++;
      break label65;
      arrayOfString = null;
      break;
      label199:
      i = 0;
      break label59;
      label205:
      str = arrayOfString[j];
      break label80;
      label215:
      m++;
      break label97;
      label221:
      if (str.equals("*")) {
        localUriMatcher1.mWhich = 2;
      } else {
        localUriMatcher1.mWhich = 0;
      }
    }
    label249:
    ((UriMatcher)localObject).mCode = paramInt;
  }
  
  public int match(Uri paramUri)
  {
    List localList = paramUri.getPathSegments();
    int i = localList.size();
    Object localObject = this;
    if ((i == 0) && (paramUri.getAuthority() == null)) {
      return this.mCode;
    }
    label69:
    label226:
    label246:
    for (int j = -1;; j++)
    {
      if (j < i) {
        if (j >= 0) {
          break label69;
        }
      }
      ArrayList localArrayList;
      for (String str = paramUri.getAuthority();; str = (String)localList.get(j))
      {
        localArrayList = ((UriMatcher)localObject).mChildren;
        if (localArrayList != null) {
          break;
        }
        return ((UriMatcher)localObject).mCode;
      }
      localObject = null;
      int k = localArrayList.size();
      for (int m = 0;; m++)
      {
        UriMatcher localUriMatcher;
        if (m < k)
        {
          localUriMatcher = (UriMatcher)localArrayList.get(m);
          switch (localUriMatcher.mWhich)
          {
          }
        }
        while (localObject != null)
        {
          if (localObject != null) {
            break label246;
          }
          return -1;
          if (localUriMatcher.mText.equals(str))
          {
            localObject = localUriMatcher;
            continue;
            int n = str.length();
            for (int i1 = 0;; i1++)
            {
              if (i1 >= n) {
                break label226;
              }
              int i2 = str.charAt(i1);
              if ((i2 < 48) || (i2 > 57)) {
                break;
              }
            }
            localObject = localUriMatcher;
            continue;
            localObject = localUriMatcher;
          }
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\UriMatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
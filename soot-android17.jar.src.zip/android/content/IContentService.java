package android.content;

import android.accounts.Account;
import android.database.IContentObserver;
import android.database.IContentObserver.Stub;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import java.util.ArrayList;
import java.util.List;

public abstract interface IContentService
  extends IInterface
{
  public abstract void addPeriodicSync(Account paramAccount, String paramString, Bundle paramBundle, long paramLong)
    throws RemoteException;
  
  public abstract void addStatusChangeListener(int paramInt, ISyncStatusObserver paramISyncStatusObserver)
    throws RemoteException;
  
  public abstract void cancelSync(Account paramAccount, String paramString)
    throws RemoteException;
  
  public abstract List<SyncInfo> getCurrentSyncs()
    throws RemoteException;
  
  public abstract int getIsSyncable(Account paramAccount, String paramString)
    throws RemoteException;
  
  public abstract boolean getMasterSyncAutomatically()
    throws RemoteException;
  
  public abstract List<PeriodicSync> getPeriodicSyncs(Account paramAccount, String paramString)
    throws RemoteException;
  
  public abstract SyncAdapterType[] getSyncAdapterTypes()
    throws RemoteException;
  
  public abstract boolean getSyncAutomatically(Account paramAccount, String paramString)
    throws RemoteException;
  
  public abstract SyncStatusInfo getSyncStatus(Account paramAccount, String paramString)
    throws RemoteException;
  
  public abstract boolean isSyncActive(Account paramAccount, String paramString)
    throws RemoteException;
  
  public abstract boolean isSyncPending(Account paramAccount, String paramString)
    throws RemoteException;
  
  public abstract void notifyChange(Uri paramUri, IContentObserver paramIContentObserver, boolean paramBoolean1, boolean paramBoolean2, int paramInt)
    throws RemoteException;
  
  public abstract void registerContentObserver(Uri paramUri, boolean paramBoolean, IContentObserver paramIContentObserver, int paramInt)
    throws RemoteException;
  
  public abstract void removePeriodicSync(Account paramAccount, String paramString, Bundle paramBundle)
    throws RemoteException;
  
  public abstract void removeStatusChangeListener(ISyncStatusObserver paramISyncStatusObserver)
    throws RemoteException;
  
  public abstract void requestSync(Account paramAccount, String paramString, Bundle paramBundle)
    throws RemoteException;
  
  public abstract void setIsSyncable(Account paramAccount, String paramString, int paramInt)
    throws RemoteException;
  
  public abstract void setMasterSyncAutomatically(boolean paramBoolean)
    throws RemoteException;
  
  public abstract void setSyncAutomatically(Account paramAccount, String paramString, boolean paramBoolean)
    throws RemoteException;
  
  public abstract void unregisterContentObserver(IContentObserver paramIContentObserver)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IContentService
  {
    private static final String DESCRIPTOR = "android.content.IContentService";
    static final int TRANSACTION_addPeriodicSync = 9;
    static final int TRANSACTION_addStatusChangeListener = 20;
    static final int TRANSACTION_cancelSync = 5;
    static final int TRANSACTION_getCurrentSyncs = 16;
    static final int TRANSACTION_getIsSyncable = 11;
    static final int TRANSACTION_getMasterSyncAutomatically = 14;
    static final int TRANSACTION_getPeriodicSyncs = 8;
    static final int TRANSACTION_getSyncAdapterTypes = 17;
    static final int TRANSACTION_getSyncAutomatically = 6;
    static final int TRANSACTION_getSyncStatus = 18;
    static final int TRANSACTION_isSyncActive = 15;
    static final int TRANSACTION_isSyncPending = 19;
    static final int TRANSACTION_notifyChange = 3;
    static final int TRANSACTION_registerContentObserver = 2;
    static final int TRANSACTION_removePeriodicSync = 10;
    static final int TRANSACTION_removeStatusChangeListener = 21;
    static final int TRANSACTION_requestSync = 4;
    static final int TRANSACTION_setIsSyncable = 12;
    static final int TRANSACTION_setMasterSyncAutomatically = 13;
    static final int TRANSACTION_setSyncAutomatically = 7;
    static final int TRANSACTION_unregisterContentObserver = 1;
    
    public Stub()
    {
      attachInterface(this, "android.content.IContentService");
    }
    
    public static IContentService asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.content.IContentService");
      if ((localIInterface != null) && ((localIInterface instanceof IContentService))) {
        return (IContentService)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.content.IContentService");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.content.IContentService");
        unregisterContentObserver(IContentObserver.Stub.asInterface(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 2: 
        paramParcel1.enforceInterface("android.content.IContentService");
        Uri localUri2;
        if (paramParcel1.readInt() != 0)
        {
          localUri2 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label297;
          }
        }
        for (boolean bool9 = true;; bool9 = false)
        {
          registerContentObserver(localUri2, bool9, IContentObserver.Stub.asInterface(paramParcel1.readStrongBinder()), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
          localUri2 = null;
          break;
        }
      case 3: 
        paramParcel1.enforceInterface("android.content.IContentService");
        Uri localUri1;
        IContentObserver localIContentObserver;
        boolean bool7;
        if (paramParcel1.readInt() != 0)
        {
          localUri1 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
          localIContentObserver = IContentObserver.Stub.asInterface(paramParcel1.readStrongBinder());
          if (paramParcel1.readInt() == 0) {
            break label387;
          }
          bool7 = true;
          if (paramParcel1.readInt() == 0) {
            break label393;
          }
        }
        for (boolean bool8 = true;; bool8 = false)
        {
          notifyChange(localUri1, localIContentObserver, bool7, bool8, paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
          localUri1 = null;
          break;
          bool7 = false;
          break label349;
        }
      case 4: 
        paramParcel1.enforceInterface("android.content.IContentService");
        Account localAccount12;
        String str4;
        if (paramParcel1.readInt() != 0)
        {
          localAccount12 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          str4 = paramParcel1.readString();
          if (paramParcel1.readInt() == 0) {
            break label475;
          }
        }
        for (Bundle localBundle3 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);; localBundle3 = null)
        {
          requestSync(localAccount12, str4, localBundle3);
          paramParcel2.writeNoException();
          return true;
          localAccount12 = null;
          break;
        }
      case 5: 
        paramParcel1.enforceInterface("android.content.IContentService");
        if (paramParcel1.readInt() != 0) {}
        for (Account localAccount11 = (Account)Account.CREATOR.createFromParcel(paramParcel1);; localAccount11 = null)
        {
          cancelSync(localAccount11, paramParcel1.readString());
          paramParcel2.writeNoException();
          return true;
        }
      case 6: 
        paramParcel1.enforceInterface("android.content.IContentService");
        Account localAccount10;
        if (paramParcel1.readInt() != 0)
        {
          localAccount10 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          boolean bool6 = getSyncAutomatically(localAccount10, paramParcel1.readString());
          paramParcel2.writeNoException();
          if (!bool6) {
            break label595;
          }
        }
        for (int n = 1;; n = 0)
        {
          paramParcel2.writeInt(n);
          return true;
          localAccount10 = null;
          break;
        }
      case 7: 
        paramParcel1.enforceInterface("android.content.IContentService");
        Account localAccount9;
        String str3;
        if (paramParcel1.readInt() != 0)
        {
          localAccount9 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          str3 = paramParcel1.readString();
          if (paramParcel1.readInt() == 0) {
            break label666;
          }
        }
        for (boolean bool5 = true;; bool5 = false)
        {
          setSyncAutomatically(localAccount9, str3, bool5);
          paramParcel2.writeNoException();
          return true;
          localAccount9 = null;
          break;
        }
      case 8: 
        paramParcel1.enforceInterface("android.content.IContentService");
        if (paramParcel1.readInt() != 0) {}
        for (Account localAccount8 = (Account)Account.CREATOR.createFromParcel(paramParcel1);; localAccount8 = null)
        {
          List localList2 = getPeriodicSyncs(localAccount8, paramParcel1.readString());
          paramParcel2.writeNoException();
          paramParcel2.writeTypedList(localList2);
          return true;
        }
      case 9: 
        paramParcel1.enforceInterface("android.content.IContentService");
        Account localAccount7;
        String str2;
        if (paramParcel1.readInt() != 0)
        {
          localAccount7 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          str2 = paramParcel1.readString();
          if (paramParcel1.readInt() == 0) {
            break label813;
          }
        }
        for (Bundle localBundle2 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);; localBundle2 = null)
        {
          long l = paramParcel1.readLong();
          addPeriodicSync(localAccount7, str2, localBundle2, l);
          paramParcel2.writeNoException();
          return true;
          localAccount7 = null;
          break;
        }
      case 10: 
        paramParcel1.enforceInterface("android.content.IContentService");
        Account localAccount6;
        String str1;
        if (paramParcel1.readInt() != 0)
        {
          localAccount6 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          str1 = paramParcel1.readString();
          if (paramParcel1.readInt() == 0) {
            break label895;
          }
        }
        for (Bundle localBundle1 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);; localBundle1 = null)
        {
          removePeriodicSync(localAccount6, str1, localBundle1);
          paramParcel2.writeNoException();
          return true;
          localAccount6 = null;
          break;
        }
      case 11: 
        paramParcel1.enforceInterface("android.content.IContentService");
        if (paramParcel1.readInt() != 0) {}
        for (Account localAccount5 = (Account)Account.CREATOR.createFromParcel(paramParcel1);; localAccount5 = null)
        {
          int m = getIsSyncable(localAccount5, paramParcel1.readString());
          paramParcel2.writeNoException();
          paramParcel2.writeInt(m);
          return true;
        }
      case 12: 
        paramParcel1.enforceInterface("android.content.IContentService");
        if (paramParcel1.readInt() != 0) {}
        for (Account localAccount4 = (Account)Account.CREATOR.createFromParcel(paramParcel1);; localAccount4 = null)
        {
          setIsSyncable(localAccount4, paramParcel1.readString(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 13: 
        paramParcel1.enforceInterface("android.content.IContentService");
        if (paramParcel1.readInt() != 0) {}
        for (boolean bool4 = true;; bool4 = false)
        {
          setMasterSyncAutomatically(bool4);
          paramParcel2.writeNoException();
          return true;
        }
      case 14: 
        paramParcel1.enforceInterface("android.content.IContentService");
        boolean bool3 = getMasterSyncAutomatically();
        paramParcel2.writeNoException();
        if (bool3) {}
        for (int k = 1;; k = 0)
        {
          paramParcel2.writeInt(k);
          return true;
        }
      case 15: 
        paramParcel1.enforceInterface("android.content.IContentService");
        Account localAccount3;
        if (paramParcel1.readInt() != 0)
        {
          localAccount3 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          boolean bool2 = isSyncActive(localAccount3, paramParcel1.readString());
          paramParcel2.writeNoException();
          if (!bool2) {
            break label1148;
          }
        }
        for (int j = 1;; j = 0)
        {
          paramParcel2.writeInt(j);
          return true;
          localAccount3 = null;
          break;
        }
      case 16: 
        paramParcel1.enforceInterface("android.content.IContentService");
        List localList1 = getCurrentSyncs();
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList1);
        return true;
      case 17: 
        paramParcel1.enforceInterface("android.content.IContentService");
        SyncAdapterType[] arrayOfSyncAdapterType = getSyncAdapterTypes();
        paramParcel2.writeNoException();
        paramParcel2.writeTypedArray(arrayOfSyncAdapterType, 1);
        return true;
      case 18: 
        paramParcel1.enforceInterface("android.content.IContentService");
        Account localAccount2;
        if (paramParcel1.readInt() != 0)
        {
          localAccount2 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          SyncStatusInfo localSyncStatusInfo = getSyncStatus(localAccount2, paramParcel1.readString());
          paramParcel2.writeNoException();
          if (localSyncStatusInfo == null) {
            break label1271;
          }
          paramParcel2.writeInt(1);
          localSyncStatusInfo.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          localAccount2 = null;
          break;
          paramParcel2.writeInt(0);
        }
      case 19: 
        paramParcel1.enforceInterface("android.content.IContentService");
        Account localAccount1;
        if (paramParcel1.readInt() != 0)
        {
          localAccount1 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          boolean bool1 = isSyncPending(localAccount1, paramParcel1.readString());
          paramParcel2.writeNoException();
          if (!bool1) {
            break label1344;
          }
        }
        for (int i = 1;; i = 0)
        {
          paramParcel2.writeInt(i);
          return true;
          localAccount1 = null;
          break;
        }
      case 20: 
        label297:
        label349:
        label387:
        label393:
        label475:
        label595:
        label666:
        label813:
        label895:
        label1148:
        label1271:
        label1344:
        paramParcel1.enforceInterface("android.content.IContentService");
        addStatusChangeListener(paramParcel1.readInt(), ISyncStatusObserver.Stub.asInterface(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      }
      paramParcel1.enforceInterface("android.content.IContentService");
      removeStatusChangeListener(ISyncStatusObserver.Stub.asInterface(paramParcel1.readStrongBinder()));
      paramParcel2.writeNoException();
      return true;
    }
    
    private static class Proxy
      implements IContentService
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public void addPeriodicSync(Account paramAccount, String paramString, Bundle paramBundle, long paramLong)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.IContentService");
            if (paramAccount != null)
            {
              localParcel1.writeInt(1);
              paramAccount.writeToParcel(localParcel1, 0);
              localParcel1.writeString(paramString);
              if (paramBundle != null)
              {
                localParcel1.writeInt(1);
                paramBundle.writeToParcel(localParcel1, 0);
                localParcel1.writeLong(paramLong);
                this.mRemote.transact(9, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            localParcel1.writeInt(0);
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      /* Error */
      public void addStatusChangeListener(int paramInt, ISyncStatusObserver paramISyncStatusObserver)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_3
        //   16: iload_1
        //   17: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   20: aload_2
        //   21: ifnull +48 -> 69
        //   24: aload_2
        //   25: invokeinterface 71 1 0
        //   30: astore 6
        //   32: aload_3
        //   33: aload 6
        //   35: invokevirtual 74	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   38: aload_0
        //   39: getfield 15	android/content/IContentService$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   42: bipush 20
        //   44: aload_3
        //   45: aload 4
        //   47: iconst_0
        //   48: invokeinterface 57 5 0
        //   53: pop
        //   54: aload 4
        //   56: invokevirtual 60	android/os/Parcel:readException	()V
        //   59: aload 4
        //   61: invokevirtual 63	android/os/Parcel:recycle	()V
        //   64: aload_3
        //   65: invokevirtual 63	android/os/Parcel:recycle	()V
        //   68: return
        //   69: aconst_null
        //   70: astore 6
        //   72: goto -40 -> 32
        //   75: astore 5
        //   77: aload 4
        //   79: invokevirtual 63	android/os/Parcel:recycle	()V
        //   82: aload_3
        //   83: invokevirtual 63	android/os/Parcel:recycle	()V
        //   86: aload 5
        //   88: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	89	0	this	Proxy
        //   0	89	1	paramInt	int
        //   0	89	2	paramISyncStatusObserver	ISyncStatusObserver
        //   3	80	3	localParcel1	Parcel
        //   7	71	4	localParcel2	Parcel
        //   75	12	5	localObject	Object
        //   30	41	6	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   9	20	75	finally
        //   24	32	75	finally
        //   32	59	75	finally
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      /* Error */
      public void cancelSync(Account paramAccount, String paramString)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +49 -> 65
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 41	android/accounts/Account:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: aload_2
        //   32: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   35: aload_0
        //   36: getfield 15	android/content/IContentService$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: iconst_5
        //   40: aload_3
        //   41: aload 4
        //   43: iconst_0
        //   44: invokeinterface 57 5 0
        //   49: pop
        //   50: aload 4
        //   52: invokevirtual 60	android/os/Parcel:readException	()V
        //   55: aload 4
        //   57: invokevirtual 63	android/os/Parcel:recycle	()V
        //   60: aload_3
        //   61: invokevirtual 63	android/os/Parcel:recycle	()V
        //   64: return
        //   65: aload_3
        //   66: iconst_0
        //   67: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   70: goto -40 -> 30
        //   73: astore 5
        //   75: aload 4
        //   77: invokevirtual 63	android/os/Parcel:recycle	()V
        //   80: aload_3
        //   81: invokevirtual 63	android/os/Parcel:recycle	()V
        //   84: aload 5
        //   86: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	87	0	this	Proxy
        //   0	87	1	paramAccount	Account
        //   0	87	2	paramString	String
        //   3	78	3	localParcel1	Parcel
        //   7	69	4	localParcel2	Parcel
        //   73	12	5	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   9	15	73	finally
        //   19	30	73	finally
        //   30	55	73	finally
        //   65	70	73	finally
      }
      
      public List<SyncInfo> getCurrentSyncs()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.IContentService");
          this.mRemote.transact(16, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(SyncInfo.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.content.IContentService";
      }
      
      /* Error */
      public int getIsSyncable(Account paramAccount, String paramString)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +59 -> 75
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 41	android/accounts/Account:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: aload_2
        //   32: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   35: aload_0
        //   36: getfield 15	android/content/IContentService$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 11
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 57 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 60	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 96	android/os/Parcel:readInt	()I
        //   61: istore 7
        //   63: aload 4
        //   65: invokevirtual 63	android/os/Parcel:recycle	()V
        //   68: aload_3
        //   69: invokevirtual 63	android/os/Parcel:recycle	()V
        //   72: iload 7
        //   74: ireturn
        //   75: aload_3
        //   76: iconst_0
        //   77: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   80: goto -50 -> 30
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 63	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 63	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramAccount	Account
        //   0	97	2	paramString	String
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   61	12	7	i	int
        // Exception table:
        //   from	to	target	type
        //   9	15	83	finally
        //   19	30	83	finally
        //   30	63	83	finally
        //   75	80	83	finally
      }
      
      public boolean getMasterSyncAutomatically()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.IContentService");
          this.mRemote.transact(14, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public List<PeriodicSync> getPeriodicSyncs(Account paramAccount, String paramString)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +62 -> 78
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 41	android/accounts/Account:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: aload_2
        //   32: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   35: aload_0
        //   36: getfield 15	android/content/IContentService$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 8
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 57 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 60	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: getstatic 103	android/content/PeriodicSync:CREATOR	Landroid/os/Parcelable$Creator;
        //   61: invokevirtual 88	android/os/Parcel:createTypedArrayList	(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;
        //   64: astore 7
        //   66: aload 4
        //   68: invokevirtual 63	android/os/Parcel:recycle	()V
        //   71: aload_3
        //   72: invokevirtual 63	android/os/Parcel:recycle	()V
        //   75: aload 7
        //   77: areturn
        //   78: aload_3
        //   79: iconst_0
        //   80: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   83: goto -53 -> 30
        //   86: astore 5
        //   88: aload 4
        //   90: invokevirtual 63	android/os/Parcel:recycle	()V
        //   93: aload_3
        //   94: invokevirtual 63	android/os/Parcel:recycle	()V
        //   97: aload 5
        //   99: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	100	0	this	Proxy
        //   0	100	1	paramAccount	Account
        //   0	100	2	paramString	String
        //   3	91	3	localParcel1	Parcel
        //   7	82	4	localParcel2	Parcel
        //   86	12	5	localObject	Object
        //   64	12	7	localArrayList	ArrayList
        // Exception table:
        //   from	to	target	type
        //   9	15	86	finally
        //   19	30	86	finally
        //   30	66	86	finally
        //   78	83	86	finally
      }
      
      public SyncAdapterType[] getSyncAdapterTypes()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.IContentService");
          this.mRemote.transact(17, localParcel1, localParcel2, 0);
          localParcel2.readException();
          SyncAdapterType[] arrayOfSyncAdapterType = (SyncAdapterType[])localParcel2.createTypedArray(SyncAdapterType.CREATOR);
          return arrayOfSyncAdapterType;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean getSyncAutomatically(Account paramAccount, String paramString)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.IContentService");
            if (paramAccount != null)
            {
              localParcel1.writeInt(1);
              paramAccount.writeToParcel(localParcel1, 0);
              localParcel1.writeString(paramString);
              this.mRemote.transact(6, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public SyncStatusInfo getSyncStatus(Account paramAccount, String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.IContentService");
            if (paramAccount != null)
            {
              localParcel1.writeInt(1);
              paramAccount.writeToParcel(localParcel1, 0);
              localParcel1.writeString(paramString);
              this.mRemote.transact(18, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localSyncStatusInfo = (SyncStatusInfo)SyncStatusInfo.CREATOR.createFromParcel(localParcel2);
                return localSyncStatusInfo;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            SyncStatusInfo localSyncStatusInfo = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean isSyncActive(Account paramAccount, String paramString)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.IContentService");
            if (paramAccount != null)
            {
              localParcel1.writeInt(1);
              paramAccount.writeToParcel(localParcel1, 0);
              localParcel1.writeString(paramString);
              this.mRemote.transact(15, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean isSyncPending(Account paramAccount, String paramString)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.IContentService");
            if (paramAccount != null)
            {
              localParcel1.writeInt(1);
              paramAccount.writeToParcel(localParcel1, 0);
              localParcel1.writeString(paramString);
              this.mRemote.transact(19, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public void notifyChange(Uri paramUri, IContentObserver paramIContentObserver, boolean paramBoolean1, boolean paramBoolean2, int paramInt)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.IContentService");
            if (paramUri != null)
            {
              localParcel1.writeInt(1);
              paramUri.writeToParcel(localParcel1, 0);
              if (paramIContentObserver != null)
              {
                localIBinder = paramIContentObserver.asBinder();
                localParcel1.writeStrongBinder(localIBinder);
                if (!paramBoolean1) {
                  break label152;
                }
                j = i;
                localParcel1.writeInt(j);
                if (!paramBoolean2) {
                  break label158;
                }
                localParcel1.writeInt(i);
                localParcel1.writeInt(paramInt);
                this.mRemote.transact(3, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            IBinder localIBinder = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          continue;
          label152:
          int j = 0;
          continue;
          label158:
          i = 0;
        }
      }
      
      public void registerContentObserver(Uri paramUri, boolean paramBoolean, IContentObserver paramIContentObserver, int paramInt)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          IBinder localIBinder;
          try
          {
            localParcel1.writeInterfaceToken("android.content.IContentService");
            if (paramUri != null)
            {
              localParcel1.writeInt(1);
              paramUri.writeToParcel(localParcel1, 0);
              break label141;
              localParcel1.writeInt(i);
              if (paramIContentObserver != null)
              {
                localIBinder = paramIContentObserver.asBinder();
                label59:
                localParcel1.writeStrongBinder(localIBinder);
                localParcel1.writeInt(paramInt);
                this.mRemote.transact(2, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localParcel1.writeInt(0);
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          label141:
          do
          {
            i = 0;
            break;
            localIBinder = null;
            break label59;
          } while (!paramBoolean);
        }
      }
      
      public void removePeriodicSync(Account paramAccount, String paramString, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.IContentService");
            if (paramAccount != null)
            {
              localParcel1.writeInt(1);
              paramAccount.writeToParcel(localParcel1, 0);
              localParcel1.writeString(paramString);
              if (paramBundle != null)
              {
                localParcel1.writeInt(1);
                paramBundle.writeToParcel(localParcel1, 0);
                this.mRemote.transact(10, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            localParcel1.writeInt(0);
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      /* Error */
      public void removeStatusChangeListener(ISyncStatusObserver paramISyncStatusObserver)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +45 -> 60
        //   18: aload_1
        //   19: invokeinterface 71 1 0
        //   24: astore 5
        //   26: aload_2
        //   27: aload 5
        //   29: invokevirtual 74	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   32: aload_0
        //   33: getfield 15	android/content/IContentService$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   36: bipush 21
        //   38: aload_2
        //   39: aload_3
        //   40: iconst_0
        //   41: invokeinterface 57 5 0
        //   46: pop
        //   47: aload_3
        //   48: invokevirtual 60	android/os/Parcel:readException	()V
        //   51: aload_3
        //   52: invokevirtual 63	android/os/Parcel:recycle	()V
        //   55: aload_2
        //   56: invokevirtual 63	android/os/Parcel:recycle	()V
        //   59: return
        //   60: aconst_null
        //   61: astore 5
        //   63: goto -37 -> 26
        //   66: astore 4
        //   68: aload_3
        //   69: invokevirtual 63	android/os/Parcel:recycle	()V
        //   72: aload_2
        //   73: invokevirtual 63	android/os/Parcel:recycle	()V
        //   76: aload 4
        //   78: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	79	0	this	Proxy
        //   0	79	1	paramISyncStatusObserver	ISyncStatusObserver
        //   3	70	2	localParcel1	Parcel
        //   7	62	3	localParcel2	Parcel
        //   66	11	4	localObject	Object
        //   24	38	5	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   8	14	66	finally
        //   18	26	66	finally
        //   26	51	66	finally
      }
      
      public void requestSync(Account paramAccount, String paramString, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.IContentService");
            if (paramAccount != null)
            {
              localParcel1.writeInt(1);
              paramAccount.writeToParcel(localParcel1, 0);
              localParcel1.writeString(paramString);
              if (paramBundle != null)
              {
                localParcel1.writeInt(1);
                paramBundle.writeToParcel(localParcel1, 0);
                this.mRemote.transact(4, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            localParcel1.writeInt(0);
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      /* Error */
      public void setIsSyncable(Account paramAccount, String paramString, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +61 -> 79
        //   21: aload 4
        //   23: iconst_1
        //   24: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 4
        //   30: iconst_0
        //   31: invokevirtual 41	android/accounts/Account:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 4
        //   36: aload_2
        //   37: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   40: aload 4
        //   42: iload_3
        //   43: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   46: aload_0
        //   47: getfield 15	android/content/IContentService$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   50: bipush 12
        //   52: aload 4
        //   54: aload 5
        //   56: iconst_0
        //   57: invokeinterface 57 5 0
        //   62: pop
        //   63: aload 5
        //   65: invokevirtual 60	android/os/Parcel:readException	()V
        //   68: aload 5
        //   70: invokevirtual 63	android/os/Parcel:recycle	()V
        //   73: aload 4
        //   75: invokevirtual 63	android/os/Parcel:recycle	()V
        //   78: return
        //   79: aload 4
        //   81: iconst_0
        //   82: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   85: goto -51 -> 34
        //   88: astore 6
        //   90: aload 5
        //   92: invokevirtual 63	android/os/Parcel:recycle	()V
        //   95: aload 4
        //   97: invokevirtual 63	android/os/Parcel:recycle	()V
        //   100: aload 6
        //   102: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	103	0	this	Proxy
        //   0	103	1	paramAccount	Account
        //   0	103	2	paramString	String
        //   0	103	3	paramInt	int
        //   3	93	4	localParcel1	Parcel
        //   8	83	5	localParcel2	Parcel
        //   88	13	6	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	88	finally
        //   21	34	88	finally
        //   34	68	88	finally
        //   79	85	88	finally
      }
      
      public void setMasterSyncAutomatically(boolean paramBoolean)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.content.IContentService");
          int i = 0;
          if (paramBoolean) {
            i = 1;
          }
          localParcel1.writeInt(i);
          this.mRemote.transact(13, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void setSyncAutomatically(Account paramAccount, String paramString, boolean paramBoolean)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.content.IContentService");
            if (paramAccount != null)
            {
              localParcel1.writeInt(1);
              paramAccount.writeToParcel(localParcel1, 0);
              localParcel1.writeString(paramString);
              if (paramBoolean)
              {
                localParcel1.writeInt(i);
                this.mRemote.transact(7, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            i = 0;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      /* Error */
      public void unregisterContentObserver(IContentObserver paramIContentObserver)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +44 -> 59
        //   18: aload_1
        //   19: invokeinterface 137 1 0
        //   24: astore 5
        //   26: aload_2
        //   27: aload 5
        //   29: invokevirtual 74	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   32: aload_0
        //   33: getfield 15	android/content/IContentService$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   36: iconst_1
        //   37: aload_2
        //   38: aload_3
        //   39: iconst_0
        //   40: invokeinterface 57 5 0
        //   45: pop
        //   46: aload_3
        //   47: invokevirtual 60	android/os/Parcel:readException	()V
        //   50: aload_3
        //   51: invokevirtual 63	android/os/Parcel:recycle	()V
        //   54: aload_2
        //   55: invokevirtual 63	android/os/Parcel:recycle	()V
        //   58: return
        //   59: aconst_null
        //   60: astore 5
        //   62: goto -36 -> 26
        //   65: astore 4
        //   67: aload_3
        //   68: invokevirtual 63	android/os/Parcel:recycle	()V
        //   71: aload_2
        //   72: invokevirtual 63	android/os/Parcel:recycle	()V
        //   75: aload 4
        //   77: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	78	0	this	Proxy
        //   0	78	1	paramIContentObserver	IContentObserver
        //   3	69	2	localParcel1	Parcel
        //   7	61	3	localParcel2	Parcel
        //   65	11	4	localObject	Object
        //   24	37	5	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   8	14	65	finally
        //   18	26	65	finally
        //   26	50	65	finally
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\IContentService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
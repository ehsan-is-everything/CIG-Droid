package android.content;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.Html;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.URLSpan;
import java.util.ArrayList;

public class ClipData
  implements Parcelable
{
  public static final Parcelable.Creator<ClipData> CREATOR = new Parcelable.Creator()
  {
    public ClipData createFromParcel(Parcel paramAnonymousParcel)
    {
      return new ClipData(paramAnonymousParcel);
    }
    
    public ClipData[] newArray(int paramAnonymousInt)
    {
      return new ClipData[paramAnonymousInt];
    }
  };
  static final String[] MIMETYPES_TEXT_HTML;
  static final String[] MIMETYPES_TEXT_INTENT;
  static final String[] MIMETYPES_TEXT_PLAIN = { "text/plain" };
  static final String[] MIMETYPES_TEXT_URILIST;
  final ClipDescription mClipDescription;
  final Bitmap mIcon;
  final ArrayList<Item> mItems;
  
  static
  {
    MIMETYPES_TEXT_HTML = new String[] { "text/html" };
    MIMETYPES_TEXT_URILIST = new String[] { "text/uri-list" };
    MIMETYPES_TEXT_INTENT = new String[] { "text/vnd.android.intent" };
  }
  
  public ClipData(ClipData paramClipData)
  {
    this.mClipDescription = paramClipData.mClipDescription;
    this.mIcon = paramClipData.mIcon;
    this.mItems = new ArrayList(paramClipData.mItems);
  }
  
  public ClipData(ClipDescription paramClipDescription, Item paramItem)
  {
    this.mClipDescription = paramClipDescription;
    if (paramItem == null) {
      throw new NullPointerException("item is null");
    }
    this.mIcon = null;
    this.mItems = new ArrayList();
    this.mItems.add(paramItem);
  }
  
  ClipData(Parcel paramParcel)
  {
    this.mClipDescription = new ClipDescription(paramParcel);
    int j;
    label57:
    CharSequence localCharSequence;
    String str;
    Intent localIntent;
    if (paramParcel.readInt() != 0)
    {
      this.mIcon = ((Bitmap)Bitmap.CREATOR.createFromParcel(paramParcel));
      this.mItems = new ArrayList();
      int i = paramParcel.readInt();
      j = 0;
      if (j >= i) {
        return;
      }
      localCharSequence = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
      str = paramParcel.readString();
      if (paramParcel.readInt() == 0) {
        break label161;
      }
      localIntent = (Intent)Intent.CREATOR.createFromParcel(paramParcel);
      label103:
      if (paramParcel.readInt() == 0) {
        break label167;
      }
    }
    label161:
    label167:
    for (Uri localUri = (Uri)Uri.CREATOR.createFromParcel(paramParcel);; localUri = null)
    {
      this.mItems.add(new Item(localCharSequence, str, localIntent, localUri));
      j++;
      break label57;
      this.mIcon = null;
      break;
      localIntent = null;
      break label103;
    }
  }
  
  public ClipData(CharSequence paramCharSequence, String[] paramArrayOfString, Item paramItem)
  {
    this.mClipDescription = new ClipDescription(paramCharSequence, paramArrayOfString);
    if (paramItem == null) {
      throw new NullPointerException("item is null");
    }
    this.mIcon = null;
    this.mItems = new ArrayList();
    this.mItems.add(paramItem);
  }
  
  public static ClipData newHtmlText(CharSequence paramCharSequence1, CharSequence paramCharSequence2, String paramString)
  {
    Item localItem = new Item(paramCharSequence2, paramString);
    return new ClipData(paramCharSequence1, MIMETYPES_TEXT_HTML, localItem);
  }
  
  public static ClipData newIntent(CharSequence paramCharSequence, Intent paramIntent)
  {
    Item localItem = new Item(paramIntent);
    return new ClipData(paramCharSequence, MIMETYPES_TEXT_INTENT, localItem);
  }
  
  public static ClipData newPlainText(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    Item localItem = new Item(paramCharSequence2);
    return new ClipData(paramCharSequence1, MIMETYPES_TEXT_PLAIN, localItem);
  }
  
  public static ClipData newRawUri(CharSequence paramCharSequence, Uri paramUri)
  {
    Item localItem = new Item(paramUri);
    return new ClipData(paramCharSequence, MIMETYPES_TEXT_URILIST, localItem);
  }
  
  public static ClipData newUri(ContentResolver paramContentResolver, CharSequence paramCharSequence, Uri paramUri)
  {
    int i = 2;
    Item localItem = new Item(paramUri);
    boolean bool = "content".equals(paramUri.getScheme());
    Object localObject = null;
    String str;
    if (bool)
    {
      str = paramContentResolver.getType(paramUri);
      localObject = paramContentResolver.getStreamTypes(paramUri, "*/*");
      if (localObject != null) {
        break label98;
      }
      if (str != null)
      {
        localObject = new String[i];
        localObject[0] = str;
        localObject[1] = "text/uri-list";
      }
    }
    if (localObject == null) {
      localObject = MIMETYPES_TEXT_URILIST;
    }
    return new ClipData(paramCharSequence, (String[])localObject, localItem);
    label98:
    int j = localObject.length;
    if (str != null) {}
    for (;;)
    {
      String[] arrayOfString = new String[i + j];
      int k = 0;
      if (str != null)
      {
        arrayOfString[0] = str;
        k = 0 + 1;
      }
      System.arraycopy(localObject, 0, arrayOfString, k, localObject.length);
      arrayOfString[(k + localObject.length)] = "text/uri-list";
      localObject = arrayOfString;
      break;
      i = 1;
    }
  }
  
  public void addItem(Item paramItem)
  {
    if (paramItem == null) {
      throw new NullPointerException("item is null");
    }
    this.mItems.add(paramItem);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public ClipDescription getDescription()
  {
    return this.mClipDescription;
  }
  
  public Bitmap getIcon()
  {
    return this.mIcon;
  }
  
  public Item getItemAt(int paramInt)
  {
    return (Item)this.mItems.get(paramInt);
  }
  
  public int getItemCount()
  {
    return this.mItems.size();
  }
  
  public void toShortString(StringBuilder paramStringBuilder)
  {
    int i;
    if (this.mClipDescription != null) {
      if (!this.mClipDescription.toShortString(paramStringBuilder)) {
        i = 1;
      }
    }
    for (;;)
    {
      if (this.mIcon != null)
      {
        if (i == 0) {
          paramStringBuilder.append(' ');
        }
        i = 0;
        paramStringBuilder.append("I:");
        paramStringBuilder.append(this.mIcon.getWidth());
        paramStringBuilder.append('x');
        paramStringBuilder.append(this.mIcon.getHeight());
      }
      int j = 0;
      while (j < this.mItems.size())
      {
        if (i == 0) {
          paramStringBuilder.append(' ');
        }
        paramStringBuilder.append('{');
        ((Item)this.mItems.get(j)).toShortString(paramStringBuilder);
        paramStringBuilder.append('}');
        j++;
        i = 0;
      }
      i = 0;
      continue;
      i = 1;
    }
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(128);
    localStringBuilder.append("ClipData { ");
    toShortString(localStringBuilder);
    localStringBuilder.append(" }");
    return localStringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    this.mClipDescription.writeToParcel(paramParcel, paramInt);
    int j;
    if (this.mIcon != null)
    {
      paramParcel.writeInt(1);
      this.mIcon.writeToParcel(paramParcel, paramInt);
      int i = this.mItems.size();
      paramParcel.writeInt(i);
      j = 0;
      label46:
      if (j >= i) {
        return;
      }
      Item localItem = (Item)this.mItems.get(j);
      TextUtils.writeToParcel(localItem.mText, paramParcel, paramInt);
      paramParcel.writeString(localItem.mHtmlText);
      if (localItem.mIntent == null) {
        break label145;
      }
      paramParcel.writeInt(1);
      localItem.mIntent.writeToParcel(paramParcel, paramInt);
      label108:
      if (localItem.mUri == null) {
        break label153;
      }
      paramParcel.writeInt(1);
      localItem.mUri.writeToParcel(paramParcel, paramInt);
    }
    for (;;)
    {
      j++;
      break label46;
      paramParcel.writeInt(0);
      break;
      label145:
      paramParcel.writeInt(0);
      break label108;
      label153:
      paramParcel.writeInt(0);
    }
  }
  
  public static class Item
  {
    final String mHtmlText;
    final Intent mIntent;
    final CharSequence mText;
    final Uri mUri;
    
    public Item(Intent paramIntent)
    {
      this.mText = null;
      this.mHtmlText = null;
      this.mIntent = paramIntent;
      this.mUri = null;
    }
    
    public Item(Uri paramUri)
    {
      this.mText = null;
      this.mHtmlText = null;
      this.mIntent = null;
      this.mUri = paramUri;
    }
    
    public Item(CharSequence paramCharSequence)
    {
      this.mText = paramCharSequence;
      this.mHtmlText = null;
      this.mIntent = null;
      this.mUri = null;
    }
    
    public Item(CharSequence paramCharSequence, Intent paramIntent, Uri paramUri)
    {
      this.mText = paramCharSequence;
      this.mHtmlText = null;
      this.mIntent = paramIntent;
      this.mUri = paramUri;
    }
    
    public Item(CharSequence paramCharSequence, String paramString)
    {
      this.mText = paramCharSequence;
      this.mHtmlText = paramString;
      this.mIntent = null;
      this.mUri = null;
    }
    
    public Item(CharSequence paramCharSequence, String paramString, Intent paramIntent, Uri paramUri)
    {
      if ((paramString != null) && (paramCharSequence == null)) {
        throw new IllegalArgumentException("Plain text must be supplied if HTML text is supplied");
      }
      this.mText = paramCharSequence;
      this.mHtmlText = paramString;
      this.mIntent = paramIntent;
      this.mUri = paramUri;
    }
    
    /* Error */
    private CharSequence coerceToHtmlOrStyledText(Context paramContext, boolean paramBoolean)
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 25	android/content/ClipData$Item:mUri	Landroid/net/Uri;
      //   4: ifnull +457 -> 461
      //   7: aload_1
      //   8: invokevirtual 51	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
      //   11: aload_0
      //   12: getfield 25	android/content/ClipData$Item:mUri	Landroid/net/Uri;
      //   15: ldc 53
      //   17: invokevirtual 59	android/content/ContentResolver:getStreamTypes	(Landroid/net/Uri;Ljava/lang/String;)[Ljava/lang/String;
      //   20: astore_3
      //   21: iconst_0
      //   22: istore 4
      //   24: iconst_0
      //   25: istore 5
      //   27: aload_3
      //   28: ifnull +58 -> 86
      //   31: aload_3
      //   32: arraylength
      //   33: istore 35
      //   35: iconst_0
      //   36: istore 36
      //   38: iload 36
      //   40: iload 35
      //   42: if_icmpge +44 -> 86
      //   45: aload_3
      //   46: iload 36
      //   48: aaload
      //   49: astore 37
      //   51: ldc 61
      //   53: aload 37
      //   55: invokevirtual 67	java/lang/String:equals	(Ljava/lang/Object;)Z
      //   58: ifeq +12 -> 70
      //   61: iconst_1
      //   62: istore 4
      //   64: iinc 36 1
      //   67: goto -29 -> 38
      //   70: aload 37
      //   72: ldc 69
      //   74: invokevirtual 73	java/lang/String:startsWith	(Ljava/lang/String;)Z
      //   77: ifeq -13 -> 64
      //   80: iconst_1
      //   81: istore 5
      //   83: goto -19 -> 64
      //   86: iload 4
      //   88: ifne +8 -> 96
      //   91: iload 5
      //   93: ifeq +114 -> 207
      //   96: aconst_null
      //   97: astore 6
      //   99: aload_1
      //   100: invokevirtual 51	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
      //   103: astore 16
      //   105: aload_0
      //   106: getfield 25	android/content/ClipData$Item:mUri	Landroid/net/Uri;
      //   109: astore 17
      //   111: iload 4
      //   113: ifeq +114 -> 227
      //   116: ldc 61
      //   118: astore 18
      //   120: aload 16
      //   122: aload 17
      //   124: aload 18
      //   126: aconst_null
      //   127: invokevirtual 77	android/content/ContentResolver:openTypedAssetFileDescriptor	(Landroid/net/Uri;Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/res/AssetFileDescriptor;
      //   130: invokevirtual 83	android/content/res/AssetFileDescriptor:createInputStream	()Ljava/io/FileInputStream;
      //   133: astore 6
      //   135: new 85	java/io/InputStreamReader
      //   138: dup
      //   139: aload 6
      //   141: ldc 87
      //   143: invokespecial 90	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;Ljava/lang/String;)V
      //   146: astore 19
      //   148: new 92	java/lang/StringBuilder
      //   151: dup
      //   152: sipush 128
      //   155: invokespecial 95	java/lang/StringBuilder:<init>	(I)V
      //   158: astore 20
      //   160: sipush 8192
      //   163: newarray <illegal type>
      //   165: astore 21
      //   167: aload 19
      //   169: aload 21
      //   171: invokevirtual 99	java/io/InputStreamReader:read	([C)I
      //   174: istore 22
      //   176: iload 22
      //   178: ifle +56 -> 234
      //   181: aload 20
      //   183: aload 21
      //   185: iconst_0
      //   186: iload 22
      //   188: invokevirtual 103	java/lang/StringBuilder:append	([CII)Ljava/lang/StringBuilder;
      //   191: pop
      //   192: goto -25 -> 167
      //   195: astore 14
      //   197: aload 6
      //   199: ifnull +8 -> 207
      //   202: aload 6
      //   204: invokevirtual 108	java/io/FileInputStream:close	()V
      //   207: iload_2
      //   208: ifeq +241 -> 449
      //   211: aload_0
      //   212: aload_0
      //   213: getfield 25	android/content/ClipData$Item:mUri	Landroid/net/Uri;
      //   216: invokevirtual 114	android/net/Uri:toString	()Ljava/lang/String;
      //   219: invokespecial 118	android/content/ClipData$Item:uriToStyledText	(Ljava/lang/String;)Ljava/lang/CharSequence;
      //   222: astore 12
      //   224: aload 12
      //   226: areturn
      //   227: ldc 120
      //   229: astore 18
      //   231: goto -111 -> 120
      //   234: aload 20
      //   236: invokevirtual 121	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   239: astore 24
      //   241: aload 24
      //   243: astore 12
      //   245: iload 4
      //   247: ifeq +92 -> 339
      //   250: iload_2
      //   251: ifeq +59 -> 310
      //   254: aload 12
      //   256: invokestatic 127	android/text/Html:fromHtml	(Ljava/lang/String;)Landroid/text/Spanned;
      //   259: astore 32
      //   261: aload 32
      //   263: astore 33
      //   265: aload 33
      //   267: ifnull +16 -> 283
      //   270: aload 6
      //   272: ifnull +8 -> 280
      //   275: aload 6
      //   277: invokevirtual 108	java/io/FileInputStream:close	()V
      //   280: aload 33
      //   282: areturn
      //   283: aload 12
      //   285: astore 33
      //   287: goto -17 -> 270
      //   290: astore 30
      //   292: aload 6
      //   294: ifnull -70 -> 224
      //   297: aload 6
      //   299: invokevirtual 108	java/io/FileInputStream:close	()V
      //   302: aload 12
      //   304: areturn
      //   305: astore 31
      //   307: aload 12
      //   309: areturn
      //   310: aload 12
      //   312: invokevirtual 128	java/lang/String:toString	()Ljava/lang/String;
      //   315: astore 28
      //   317: aload 28
      //   319: astore 12
      //   321: aload 6
      //   323: ifnull -99 -> 224
      //   326: aload 6
      //   328: invokevirtual 108	java/io/FileInputStream:close	()V
      //   331: aload 12
      //   333: areturn
      //   334: astore 29
      //   336: aload 12
      //   338: areturn
      //   339: iload_2
      //   340: ifeq +21 -> 361
      //   343: aload 6
      //   345: ifnull -121 -> 224
      //   348: aload 6
      //   350: invokevirtual 108	java/io/FileInputStream:close	()V
      //   353: aload 12
      //   355: areturn
      //   356: astore 27
      //   358: aload 12
      //   360: areturn
      //   361: aload 12
      //   363: invokestatic 132	android/text/Html:escapeHtml	(Ljava/lang/CharSequence;)Ljava/lang/String;
      //   366: astore 25
      //   368: aload 25
      //   370: astore 12
      //   372: aload 6
      //   374: ifnull -150 -> 224
      //   377: aload 6
      //   379: invokevirtual 108	java/io/FileInputStream:close	()V
      //   382: aload 12
      //   384: areturn
      //   385: astore 26
      //   387: aload 12
      //   389: areturn
      //   390: astore 9
      //   392: ldc -122
      //   394: ldc -120
      //   396: aload 9
      //   398: invokestatic 142	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   401: pop
      //   402: aload 9
      //   404: invokevirtual 143	java/io/IOException:toString	()Ljava/lang/String;
      //   407: invokestatic 132	android/text/Html:escapeHtml	(Ljava/lang/CharSequence;)Ljava/lang/String;
      //   410: astore 11
      //   412: aload 11
      //   414: astore 12
      //   416: aload 6
      //   418: ifnull -194 -> 224
      //   421: aload 6
      //   423: invokevirtual 108	java/io/FileInputStream:close	()V
      //   426: aload 12
      //   428: areturn
      //   429: astore 13
      //   431: aload 12
      //   433: areturn
      //   434: astore 7
      //   436: aload 6
      //   438: ifnull +8 -> 446
      //   441: aload 6
      //   443: invokevirtual 108	java/io/FileInputStream:close	()V
      //   446: aload 7
      //   448: athrow
      //   449: aload_0
      //   450: aload_0
      //   451: getfield 25	android/content/ClipData$Item:mUri	Landroid/net/Uri;
      //   454: invokevirtual 114	android/net/Uri:toString	()Ljava/lang/String;
      //   457: invokespecial 147	android/content/ClipData$Item:uriToHtml	(Ljava/lang/String;)Ljava/lang/String;
      //   460: areturn
      //   461: aload_0
      //   462: getfield 23	android/content/ClipData$Item:mIntent	Landroid/content/Intent;
      //   465: ifnull +33 -> 498
      //   468: iload_2
      //   469: ifeq +16 -> 485
      //   472: aload_0
      //   473: aload_0
      //   474: getfield 23	android/content/ClipData$Item:mIntent	Landroid/content/Intent;
      //   477: iconst_1
      //   478: invokevirtual 153	android/content/Intent:toUri	(I)Ljava/lang/String;
      //   481: invokespecial 118	android/content/ClipData$Item:uriToStyledText	(Ljava/lang/String;)Ljava/lang/CharSequence;
      //   484: areturn
      //   485: aload_0
      //   486: aload_0
      //   487: getfield 23	android/content/ClipData$Item:mIntent	Landroid/content/Intent;
      //   490: iconst_1
      //   491: invokevirtual 153	android/content/Intent:toUri	(I)Ljava/lang/String;
      //   494: invokespecial 147	android/content/ClipData$Item:uriToHtml	(Ljava/lang/String;)Ljava/lang/String;
      //   497: areturn
      //   498: ldc -101
      //   500: areturn
      //   501: astore 34
      //   503: goto -223 -> 280
      //   506: astore 15
      //   508: goto -301 -> 207
      //   511: astore 8
      //   513: goto -67 -> 446
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	516	0	this	Item
      //   0	516	1	paramContext	Context
      //   0	516	2	paramBoolean	boolean
      //   20	26	3	arrayOfString	String[]
      //   22	224	4	i	int
      //   25	67	5	j	int
      //   97	345	6	localFileInputStream	java.io.FileInputStream
      //   434	13	7	localObject1	Object
      //   511	1	8	localIOException1	java.io.IOException
      //   390	13	9	localIOException2	java.io.IOException
      //   410	3	11	str1	String
      //   222	210	12	localObject2	Object
      //   429	1	13	localIOException3	java.io.IOException
      //   195	1	14	localFileNotFoundException	java.io.FileNotFoundException
      //   506	1	15	localIOException4	java.io.IOException
      //   103	18	16	localContentResolver	ContentResolver
      //   109	14	17	localUri	Uri
      //   118	112	18	str2	String
      //   146	22	19	localInputStreamReader	java.io.InputStreamReader
      //   158	77	20	localStringBuilder	StringBuilder
      //   165	19	21	arrayOfChar	char[]
      //   174	13	22	k	int
      //   239	3	24	str3	String
      //   366	3	25	str4	String
      //   385	1	26	localIOException5	java.io.IOException
      //   356	1	27	localIOException6	java.io.IOException
      //   315	3	28	str5	String
      //   334	1	29	localIOException7	java.io.IOException
      //   290	1	30	localRuntimeException	RuntimeException
      //   305	1	31	localIOException8	java.io.IOException
      //   259	3	32	localSpanned	Spanned
      //   263	23	33	localObject3	Object
      //   501	1	34	localIOException9	java.io.IOException
      //   33	10	35	m	int
      //   36	29	36	n	int
      //   49	22	37	str6	String
      // Exception table:
      //   from	to	target	type
      //   99	111	195	java/io/FileNotFoundException
      //   120	167	195	java/io/FileNotFoundException
      //   167	176	195	java/io/FileNotFoundException
      //   181	192	195	java/io/FileNotFoundException
      //   234	241	195	java/io/FileNotFoundException
      //   254	261	195	java/io/FileNotFoundException
      //   310	317	195	java/io/FileNotFoundException
      //   361	368	195	java/io/FileNotFoundException
      //   254	261	290	java/lang/RuntimeException
      //   297	302	305	java/io/IOException
      //   326	331	334	java/io/IOException
      //   348	353	356	java/io/IOException
      //   377	382	385	java/io/IOException
      //   99	111	390	java/io/IOException
      //   120	167	390	java/io/IOException
      //   167	176	390	java/io/IOException
      //   181	192	390	java/io/IOException
      //   234	241	390	java/io/IOException
      //   254	261	390	java/io/IOException
      //   310	317	390	java/io/IOException
      //   361	368	390	java/io/IOException
      //   421	426	429	java/io/IOException
      //   99	111	434	finally
      //   120	167	434	finally
      //   167	176	434	finally
      //   181	192	434	finally
      //   234	241	434	finally
      //   254	261	434	finally
      //   310	317	434	finally
      //   361	368	434	finally
      //   392	412	434	finally
      //   275	280	501	java/io/IOException
      //   202	207	506	java/io/IOException
      //   441	446	511	java/io/IOException
    }
    
    private String uriToHtml(String paramString)
    {
      StringBuilder localStringBuilder = new StringBuilder(256);
      localStringBuilder.append("<a href=\"");
      localStringBuilder.append(Html.escapeHtml(paramString));
      localStringBuilder.append("\">");
      localStringBuilder.append(Html.escapeHtml(paramString));
      localStringBuilder.append("</a>");
      return localStringBuilder.toString();
    }
    
    private CharSequence uriToStyledText(String paramString)
    {
      SpannableStringBuilder localSpannableStringBuilder = new SpannableStringBuilder();
      localSpannableStringBuilder.append(paramString);
      localSpannableStringBuilder.setSpan(new URLSpan(paramString), 0, localSpannableStringBuilder.length(), 33);
      return localSpannableStringBuilder;
    }
    
    public String coerceToHtmlText(Context paramContext)
    {
      String str1 = getHtmlText();
      if (str1 != null) {
        return str1;
      }
      CharSequence localCharSequence1 = getText();
      if (localCharSequence1 != null)
      {
        if ((localCharSequence1 instanceof Spanned)) {
          return Html.toHtml((Spanned)localCharSequence1);
        }
        return Html.escapeHtml(localCharSequence1);
      }
      CharSequence localCharSequence2 = coerceToHtmlOrStyledText(paramContext, false);
      if (localCharSequence2 != null) {}
      for (String str2 = localCharSequence2.toString();; str2 = null) {
        return str2;
      }
    }
    
    public CharSequence coerceToStyledText(Context paramContext)
    {
      CharSequence localCharSequence = getText();
      if ((localCharSequence instanceof Spanned)) {}
      do
      {
        return localCharSequence;
        String str = getHtmlText();
        if (str != null) {
          try
          {
            Spanned localSpanned = Html.fromHtml(str);
            if (localSpanned != null) {
              return localSpanned;
            }
          }
          catch (RuntimeException localRuntimeException) {}
        }
      } while (localCharSequence != null);
      return coerceToHtmlOrStyledText(paramContext, true);
    }
    
    /* Error */
    public CharSequence coerceToText(Context paramContext)
    {
      // Byte code:
      //   0: aload_0
      //   1: invokevirtual 190	android/content/ClipData$Item:getText	()Ljava/lang/CharSequence;
      //   4: astore_2
      //   5: aload_2
      //   6: ifnull +5 -> 11
      //   9: aload_2
      //   10: areturn
      //   11: aload_0
      //   12: invokevirtual 206	android/content/ClipData$Item:getUri	()Landroid/net/Uri;
      //   15: astore_3
      //   16: aload_3
      //   17: ifnull +178 -> 195
      //   20: aconst_null
      //   21: astore 5
      //   23: aload_1
      //   24: invokevirtual 51	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
      //   27: aload_3
      //   28: ldc 53
      //   30: aconst_null
      //   31: invokevirtual 77	android/content/ContentResolver:openTypedAssetFileDescriptor	(Landroid/net/Uri;Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/res/AssetFileDescriptor;
      //   34: invokevirtual 83	android/content/res/AssetFileDescriptor:createInputStream	()Ljava/io/FileInputStream;
      //   37: astore 5
      //   39: new 85	java/io/InputStreamReader
      //   42: dup
      //   43: aload 5
      //   45: ldc 87
      //   47: invokespecial 90	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;Ljava/lang/String;)V
      //   50: astore 14
      //   52: new 92	java/lang/StringBuilder
      //   55: dup
      //   56: sipush 128
      //   59: invokespecial 95	java/lang/StringBuilder:<init>	(I)V
      //   62: astore 15
      //   64: sipush 8192
      //   67: newarray <illegal type>
      //   69: astore 16
      //   71: aload 14
      //   73: aload 16
      //   75: invokevirtual 99	java/io/InputStreamReader:read	([C)I
      //   78: istore 17
      //   80: iload 17
      //   82: ifle +34 -> 116
      //   85: aload 15
      //   87: aload 16
      //   89: iconst_0
      //   90: iload 17
      //   92: invokevirtual 103	java/lang/StringBuilder:append	([CII)Ljava/lang/StringBuilder;
      //   95: pop
      //   96: goto -25 -> 71
      //   99: astore 12
      //   101: aload 5
      //   103: ifnull +8 -> 111
      //   106: aload 5
      //   108: invokevirtual 108	java/io/FileInputStream:close	()V
      //   111: aload_3
      //   112: invokevirtual 114	android/net/Uri:toString	()Ljava/lang/String;
      //   115: areturn
      //   116: aload 15
      //   118: invokevirtual 121	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   121: astore 19
      //   123: aload 19
      //   125: astore_2
      //   126: aload 5
      //   128: ifnull -119 -> 9
      //   131: aload 5
      //   133: invokevirtual 108	java/io/FileInputStream:close	()V
      //   136: aload_2
      //   137: areturn
      //   138: astore 20
      //   140: aload_2
      //   141: areturn
      //   142: astore 8
      //   144: ldc -122
      //   146: ldc -120
      //   148: aload 8
      //   150: invokestatic 142	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   153: pop
      //   154: aload 8
      //   156: invokevirtual 143	java/io/IOException:toString	()Ljava/lang/String;
      //   159: astore 10
      //   161: aload 10
      //   163: astore_2
      //   164: aload 5
      //   166: ifnull -157 -> 9
      //   169: aload 5
      //   171: invokevirtual 108	java/io/FileInputStream:close	()V
      //   174: aload_2
      //   175: areturn
      //   176: astore 11
      //   178: aload_2
      //   179: areturn
      //   180: astore 6
      //   182: aload 5
      //   184: ifnull +8 -> 192
      //   187: aload 5
      //   189: invokevirtual 108	java/io/FileInputStream:close	()V
      //   192: aload 6
      //   194: athrow
      //   195: aload_0
      //   196: invokevirtual 210	android/content/ClipData$Item:getIntent	()Landroid/content/Intent;
      //   199: astore 4
      //   201: aload 4
      //   203: ifnull +10 -> 213
      //   206: aload 4
      //   208: iconst_1
      //   209: invokevirtual 153	android/content/Intent:toUri	(I)Ljava/lang/String;
      //   212: areturn
      //   213: ldc -101
      //   215: areturn
      //   216: astore 13
      //   218: goto -107 -> 111
      //   221: astore 7
      //   223: goto -31 -> 192
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	226	0	this	Item
      //   0	226	1	paramContext	Context
      //   4	175	2	localObject1	Object
      //   15	97	3	localUri	Uri
      //   199	8	4	localIntent	Intent
      //   21	167	5	localFileInputStream	java.io.FileInputStream
      //   180	13	6	localObject2	Object
      //   221	1	7	localIOException1	java.io.IOException
      //   142	13	8	localIOException2	java.io.IOException
      //   159	3	10	str1	String
      //   176	1	11	localIOException3	java.io.IOException
      //   99	1	12	localFileNotFoundException	java.io.FileNotFoundException
      //   216	1	13	localIOException4	java.io.IOException
      //   50	22	14	localInputStreamReader	java.io.InputStreamReader
      //   62	55	15	localStringBuilder	StringBuilder
      //   69	19	16	arrayOfChar	char[]
      //   78	13	17	i	int
      //   121	3	19	str2	String
      //   138	1	20	localIOException5	java.io.IOException
      // Exception table:
      //   from	to	target	type
      //   23	71	99	java/io/FileNotFoundException
      //   71	80	99	java/io/FileNotFoundException
      //   85	96	99	java/io/FileNotFoundException
      //   116	123	99	java/io/FileNotFoundException
      //   131	136	138	java/io/IOException
      //   23	71	142	java/io/IOException
      //   71	80	142	java/io/IOException
      //   85	96	142	java/io/IOException
      //   116	123	142	java/io/IOException
      //   169	174	176	java/io/IOException
      //   23	71	180	finally
      //   71	80	180	finally
      //   85	96	180	finally
      //   116	123	180	finally
      //   144	161	180	finally
      //   106	111	216	java/io/IOException
      //   187	192	221	java/io/IOException
    }
    
    public String getHtmlText()
    {
      return this.mHtmlText;
    }
    
    public Intent getIntent()
    {
      return this.mIntent;
    }
    
    public CharSequence getText()
    {
      return this.mText;
    }
    
    public Uri getUri()
    {
      return this.mUri;
    }
    
    public void toShortString(StringBuilder paramStringBuilder)
    {
      if (this.mHtmlText != null)
      {
        paramStringBuilder.append("H:");
        paramStringBuilder.append(this.mHtmlText);
        return;
      }
      if (this.mText != null)
      {
        paramStringBuilder.append("T:");
        paramStringBuilder.append(this.mText);
        return;
      }
      if (this.mUri != null)
      {
        paramStringBuilder.append("U:");
        paramStringBuilder.append(this.mUri);
        return;
      }
      if (this.mIntent != null)
      {
        paramStringBuilder.append("I:");
        this.mIntent.toShortString(paramStringBuilder, true, true, true, true);
        return;
      }
      paramStringBuilder.append("NULL");
    }
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder(128);
      localStringBuilder.append("ClipData.Item { ");
      toShortString(localStringBuilder);
      localStringBuilder.append(" }");
      return localStringBuilder.toString();
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\ClipData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
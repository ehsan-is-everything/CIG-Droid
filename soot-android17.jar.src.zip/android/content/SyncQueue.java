package android.content;

import android.accounts.Account;
import android.content.pm.RegisteredServicesCache.ServiceInfo;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.format.DateUtils;
import android.util.Log;
import android.util.Pair;
import com.google.android.collect.Maps;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class SyncQueue
{
  private static final String TAG = "SyncManager";
  private final HashMap<String, SyncOperation> mOperationsMap = Maps.newHashMap();
  private final SyncAdaptersCache mSyncAdapters;
  private final SyncStorageEngine mSyncStorageEngine;
  
  public SyncQueue(SyncStorageEngine paramSyncStorageEngine, SyncAdaptersCache paramSyncAdaptersCache)
  {
    this.mSyncStorageEngine = paramSyncStorageEngine;
    this.mSyncAdapters = paramSyncAdaptersCache;
  }
  
  private boolean add(SyncOperation paramSyncOperation, SyncStorageEngine.PendingOperation paramPendingOperation)
  {
    String str = paramSyncOperation.key;
    SyncOperation localSyncOperation = (SyncOperation)this.mOperationsMap.get(str);
    if (localSyncOperation != null)
    {
      boolean bool2;
      if (localSyncOperation.expedited == paramSyncOperation.expedited)
      {
        long l = Math.min(localSyncOperation.earliestRunTime, paramSyncOperation.earliestRunTime);
        boolean bool3 = localSyncOperation.earliestRunTime < l;
        bool2 = false;
        if (bool3)
        {
          localSyncOperation.earliestRunTime = l;
          bool2 = true;
        }
      }
      boolean bool1;
      do
      {
        return bool2;
        bool1 = paramSyncOperation.expedited;
        bool2 = false;
      } while (!bool1);
      localSyncOperation.expedited = true;
      return true;
    }
    paramSyncOperation.pendingOperation = paramPendingOperation;
    if (paramSyncOperation.pendingOperation == null)
    {
      SyncStorageEngine.PendingOperation localPendingOperation1 = new SyncStorageEngine.PendingOperation(paramSyncOperation.account, paramSyncOperation.userId, paramSyncOperation.syncSource, paramSyncOperation.authority, paramSyncOperation.extras, paramSyncOperation.expedited);
      SyncStorageEngine.PendingOperation localPendingOperation2 = this.mSyncStorageEngine.insertIntoPending(localPendingOperation1);
      if (localPendingOperation2 == null) {
        throw new IllegalStateException("error adding pending sync operation " + paramSyncOperation);
      }
      paramSyncOperation.pendingOperation = localPendingOperation2;
    }
    this.mOperationsMap.put(str, paramSyncOperation);
    return true;
  }
  
  public boolean add(SyncOperation paramSyncOperation)
  {
    return add(paramSyncOperation, null);
  }
  
  public void addPendingOperations(int paramInt)
  {
    Iterator localIterator = this.mSyncStorageEngine.getPendingOperations().iterator();
    while (localIterator.hasNext())
    {
      SyncStorageEngine.PendingOperation localPendingOperation = (SyncStorageEngine.PendingOperation)localIterator.next();
      if (localPendingOperation.userId == paramInt)
      {
        Pair localPair = this.mSyncStorageEngine.getBackoff(localPendingOperation.account, localPendingOperation.userId, localPendingOperation.authority);
        RegisteredServicesCache.ServiceInfo localServiceInfo = this.mSyncAdapters.getServiceInfo(SyncAdapterType.newKey(localPendingOperation.authority, localPendingOperation.account.type), localPendingOperation.userId);
        if (localServiceInfo == null)
        {
          Log.w("SyncManager", "Missing sync adapter info for authority " + localPendingOperation.authority + ", userId " + localPendingOperation.userId);
        }
        else
        {
          Account localAccount = localPendingOperation.account;
          int i = localPendingOperation.userId;
          int j = localPendingOperation.syncSource;
          String str = localPendingOperation.authority;
          Bundle localBundle = localPendingOperation.extras;
          if (localPair != null) {}
          for (long l = ((Long)localPair.first).longValue();; l = 0L)
          {
            SyncOperation localSyncOperation = new SyncOperation(localAccount, i, j, str, localBundle, 0L, l, this.mSyncStorageEngine.getDelayUntilTime(localPendingOperation.account, localPendingOperation.userId, localPendingOperation.authority), ((SyncAdapterType)localServiceInfo.type).allowParallelSyncs());
            localSyncOperation.expedited = localPendingOperation.expedited;
            localSyncOperation.pendingOperation = localPendingOperation;
            add(localSyncOperation, localPendingOperation);
            break;
          }
        }
      }
    }
  }
  
  public void dump(StringBuilder paramStringBuilder)
  {
    long l = SystemClock.elapsedRealtime();
    paramStringBuilder.append("SyncQueue: ").append(this.mOperationsMap.size()).append(" operation(s)\n");
    Iterator localIterator = this.mOperationsMap.values().iterator();
    if (localIterator.hasNext())
    {
      SyncOperation localSyncOperation = (SyncOperation)localIterator.next();
      paramStringBuilder.append("  ");
      if (localSyncOperation.effectiveRunTime <= l) {
        paramStringBuilder.append("READY");
      }
      for (;;)
      {
        paramStringBuilder.append(" - ");
        paramStringBuilder.append(localSyncOperation.dump(false)).append("\n");
        break;
        paramStringBuilder.append(DateUtils.formatElapsedTime((localSyncOperation.effectiveRunTime - l) / 1000L));
      }
    }
  }
  
  public Collection<SyncOperation> getOperations()
  {
    return this.mOperationsMap.values();
  }
  
  public void onBackoffChanged(Account paramAccount, int paramInt, String paramString, long paramLong)
  {
    Iterator localIterator = this.mOperationsMap.values().iterator();
    while (localIterator.hasNext())
    {
      SyncOperation localSyncOperation = (SyncOperation)localIterator.next();
      if ((localSyncOperation.account.equals(paramAccount)) && (localSyncOperation.authority.equals(paramString)) && (localSyncOperation.userId == paramInt))
      {
        localSyncOperation.backoff = Long.valueOf(paramLong);
        localSyncOperation.updateEffectiveRunTime();
      }
    }
  }
  
  public void onDelayUntilTimeChanged(Account paramAccount, String paramString, long paramLong)
  {
    Iterator localIterator = this.mOperationsMap.values().iterator();
    while (localIterator.hasNext())
    {
      SyncOperation localSyncOperation = (SyncOperation)localIterator.next();
      if ((localSyncOperation.account.equals(paramAccount)) && (localSyncOperation.authority.equals(paramString)))
      {
        localSyncOperation.delayUntil = paramLong;
        localSyncOperation.updateEffectiveRunTime();
      }
    }
  }
  
  public void remove(Account paramAccount, int paramInt, String paramString)
  {
    Iterator localIterator = this.mOperationsMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      SyncOperation localSyncOperation = (SyncOperation)((Map.Entry)localIterator.next()).getValue();
      if (((paramAccount == null) || (localSyncOperation.account.equals(paramAccount))) && ((paramString == null) || (localSyncOperation.authority.equals(paramString))) && (paramInt == localSyncOperation.userId))
      {
        localIterator.remove();
        if (!this.mSyncStorageEngine.deleteFromPending(localSyncOperation.pendingOperation))
        {
          String str = "unable to find pending row for " + localSyncOperation;
          Log.e("SyncManager", str, new IllegalStateException(str));
        }
      }
    }
  }
  
  public void remove(SyncOperation paramSyncOperation)
  {
    SyncOperation localSyncOperation = (SyncOperation)this.mOperationsMap.remove(paramSyncOperation.key);
    if (localSyncOperation == null) {}
    while (this.mSyncStorageEngine.deleteFromPending(localSyncOperation.pendingOperation)) {
      return;
    }
    String str = "unable to find pending row for " + localSyncOperation;
    Log.e("SyncManager", str, new IllegalStateException(str));
  }
  
  public void removeUser(int paramInt)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator1 = this.mOperationsMap.values().iterator();
    while (localIterator1.hasNext())
    {
      SyncOperation localSyncOperation = (SyncOperation)localIterator1.next();
      if (localSyncOperation.userId == paramInt) {
        localArrayList.add(localSyncOperation);
      }
    }
    Iterator localIterator2 = localArrayList.iterator();
    while (localIterator2.hasNext()) {
      remove((SyncOperation)localIterator2.next());
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\SyncQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
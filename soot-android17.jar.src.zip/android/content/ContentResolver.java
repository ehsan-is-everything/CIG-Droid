package android.content;

import android.accounts.Account;
import android.app.ActivityManagerNative;
import android.app.AppGlobals;
import android.app.IActivityManager;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.AssetFileDescriptor;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.database.ContentObserver;
import android.database.CrossProcessCursorWrapper;
import android.database.Cursor;
import android.database.IContentObserver;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.DeadObjectException;
import android.os.ICancellationSignal;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.SystemClock;
import android.os.UserHandle;
import android.text.TextUtils;
import android.util.EventLog;
import android.util.Log;
import dalvik.system.CloseGuard;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;

public abstract class ContentResolver
{
  public static final String CONTENT_SERVICE_NAME = "content";
  public static final String CURSOR_DIR_BASE_TYPE = "vnd.android.cursor.dir";
  public static final String CURSOR_ITEM_BASE_TYPE = "vnd.android.cursor.item";
  public static final String SCHEME_ANDROID_RESOURCE = "android.resource";
  public static final String SCHEME_CONTENT = "content";
  public static final String SCHEME_FILE = "file";
  private static final int SLOW_THRESHOLD_MILLIS = 500;
  public static final int SYNC_ERROR_AUTHENTICATION = 2;
  public static final int SYNC_ERROR_CONFLICT = 5;
  public static final int SYNC_ERROR_INTERNAL = 8;
  public static final int SYNC_ERROR_IO = 3;
  public static final int SYNC_ERROR_PARSE = 4;
  public static final int SYNC_ERROR_SYNC_ALREADY_IN_PROGRESS = 1;
  public static final int SYNC_ERROR_TOO_MANY_DELETIONS = 6;
  public static final int SYNC_ERROR_TOO_MANY_RETRIES = 7;
  @Deprecated
  public static final String SYNC_EXTRAS_ACCOUNT = "account";
  public static final String SYNC_EXTRAS_DISCARD_LOCAL_DELETIONS = "discard_deletions";
  public static final String SYNC_EXTRAS_DO_NOT_RETRY = "do_not_retry";
  public static final String SYNC_EXTRAS_EXPEDITED = "expedited";
  @Deprecated
  public static final String SYNC_EXTRAS_FORCE = "force";
  public static final String SYNC_EXTRAS_IGNORE_BACKOFF = "ignore_backoff";
  public static final String SYNC_EXTRAS_IGNORE_SETTINGS = "ignore_settings";
  public static final String SYNC_EXTRAS_INITIALIZE = "initialize";
  public static final String SYNC_EXTRAS_MANUAL = "force";
  public static final String SYNC_EXTRAS_OVERRIDE_TOO_MANY_DELETIONS = "deletions_override";
  public static final String SYNC_EXTRAS_UPLOAD = "upload";
  public static final int SYNC_OBSERVER_TYPE_ACTIVE = 4;
  public static final int SYNC_OBSERVER_TYPE_ALL = Integer.MAX_VALUE;
  public static final int SYNC_OBSERVER_TYPE_PENDING = 2;
  public static final int SYNC_OBSERVER_TYPE_SETTINGS = 1;
  public static final int SYNC_OBSERVER_TYPE_STATUS = 8;
  private static final String TAG = "ContentResolver";
  private static IContentService sContentService;
  private final Context mContext;
  private final Random mRandom = new Random();
  
  public ContentResolver(Context paramContext)
  {
    this.mContext = paramContext;
  }
  
  public static void addPeriodicSync(Account paramAccount, String paramString, Bundle paramBundle, long paramLong)
  {
    validateSyncExtrasBundle(paramBundle);
    if (paramAccount == null) {
      throw new IllegalArgumentException("account must not be null");
    }
    if (paramString == null) {
      throw new IllegalArgumentException("authority must not be null");
    }
    if ((paramBundle.getBoolean("force", false)) || (paramBundle.getBoolean("do_not_retry", false)) || (paramBundle.getBoolean("ignore_backoff", false)) || (paramBundle.getBoolean("ignore_settings", false)) || (paramBundle.getBoolean("initialize", false)) || (paramBundle.getBoolean("force", false)) || (paramBundle.getBoolean("expedited", false))) {
      throw new IllegalArgumentException("illegal extras were set");
    }
    try
    {
      getContentService().addPeriodicSync(paramAccount, paramString, paramBundle, paramLong);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public static Object addStatusChangeListener(int paramInt, SyncStatusObserver paramSyncStatusObserver)
  {
    if (paramSyncStatusObserver == null) {
      throw new IllegalArgumentException("you passed in a null callback");
    }
    try
    {
      ISyncStatusObserver.Stub local1 = new ISyncStatusObserver.Stub()
      {
        public void onStatusChanged(int paramAnonymousInt)
          throws RemoteException
        {
          this.val$callback.onStatusChanged(paramAnonymousInt);
        }
      };
      getContentService().addStatusChangeListener(paramInt, local1);
      return local1;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("the ContentService should always be reachable", localRemoteException);
    }
  }
  
  public static void cancelSync(Account paramAccount, String paramString)
  {
    try
    {
      getContentService().cancelSync(paramAccount, paramString);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public static IContentService getContentService()
  {
    if (sContentService != null) {
      return sContentService;
    }
    sContentService = IContentService.Stub.asInterface(ServiceManager.getService("content"));
    return sContentService;
  }
  
  @Deprecated
  public static SyncInfo getCurrentSync()
  {
    try
    {
      List localList = getContentService().getCurrentSyncs();
      if (localList.isEmpty()) {
        return null;
      }
      SyncInfo localSyncInfo = (SyncInfo)localList.get(0);
      return localSyncInfo;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("the ContentService should always be reachable", localRemoteException);
    }
  }
  
  public static List<SyncInfo> getCurrentSyncs()
  {
    try
    {
      List localList = getContentService().getCurrentSyncs();
      return localList;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("the ContentService should always be reachable", localRemoteException);
    }
  }
  
  public static int getIsSyncable(Account paramAccount, String paramString)
  {
    try
    {
      int i = getContentService().getIsSyncable(paramAccount, paramString);
      return i;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("the ContentService should always be reachable", localRemoteException);
    }
  }
  
  public static boolean getMasterSyncAutomatically()
  {
    try
    {
      boolean bool = getContentService().getMasterSyncAutomatically();
      return bool;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("the ContentService should always be reachable", localRemoteException);
    }
  }
  
  public static List<PeriodicSync> getPeriodicSyncs(Account paramAccount, String paramString)
  {
    if (paramAccount == null) {
      throw new IllegalArgumentException("account must not be null");
    }
    if (paramString == null) {
      throw new IllegalArgumentException("authority must not be null");
    }
    try
    {
      List localList = getContentService().getPeriodicSyncs(paramAccount, paramString);
      return localList;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("the ContentService should always be reachable", localRemoteException);
    }
  }
  
  public static SyncAdapterType[] getSyncAdapterTypes()
  {
    try
    {
      SyncAdapterType[] arrayOfSyncAdapterType = getContentService().getSyncAdapterTypes();
      return arrayOfSyncAdapterType;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("the ContentService should always be reachable", localRemoteException);
    }
  }
  
  public static boolean getSyncAutomatically(Account paramAccount, String paramString)
  {
    try
    {
      boolean bool = getContentService().getSyncAutomatically(paramAccount, paramString);
      return bool;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("the ContentService should always be reachable", localRemoteException);
    }
  }
  
  public static SyncStatusInfo getSyncStatus(Account paramAccount, String paramString)
  {
    try
    {
      SyncStatusInfo localSyncStatusInfo = getContentService().getSyncStatus(paramAccount, paramString);
      return localSyncStatusInfo;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("the ContentService should always be reachable", localRemoteException);
    }
  }
  
  public static boolean isSyncActive(Account paramAccount, String paramString)
  {
    try
    {
      boolean bool = getContentService().isSyncActive(paramAccount, paramString);
      return bool;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("the ContentService should always be reachable", localRemoteException);
    }
  }
  
  public static boolean isSyncPending(Account paramAccount, String paramString)
  {
    try
    {
      boolean bool = getContentService().isSyncPending(paramAccount, paramString);
      return bool;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("the ContentService should always be reachable", localRemoteException);
    }
  }
  
  private void maybeLogQueryToEventLog(long paramLong, Uri paramUri, String[] paramArrayOfString, String paramString1, String paramString2)
  {
    int i = samplePercentForDuration(paramLong);
    if (i < 100) {}
    StringBuilder localStringBuilder;
    synchronized (this.mRandom)
    {
      if (this.mRandom.nextInt(100) >= i) {
        return;
      }
      localStringBuilder = new StringBuilder(100);
      if (paramArrayOfString != null)
      {
        int j = 0;
        if (j < paramArrayOfString.length)
        {
          if (j != 0) {
            localStringBuilder.append('/');
          }
          localStringBuilder.append(paramArrayOfString[j]);
          j++;
        }
      }
    }
    String str = AppGlobals.getInitialPackage();
    Object[] arrayOfObject = new Object[7];
    arrayOfObject[0] = paramUri.toString();
    arrayOfObject[1] = localStringBuilder.toString();
    if (paramString1 != null)
    {
      arrayOfObject[2] = paramString1;
      if (paramString2 == null) {
        break label207;
      }
      label154:
      arrayOfObject[3] = paramString2;
      arrayOfObject[4] = Long.valueOf(paramLong);
      if (str == null) {
        break label215;
      }
    }
    for (;;)
    {
      arrayOfObject[5] = str;
      arrayOfObject[6] = Integer.valueOf(i);
      EventLog.writeEvent(52002, arrayOfObject);
      return;
      paramString1 = "";
      break;
      label207:
      paramString2 = "";
      break label154;
      label215:
      str = "";
    }
  }
  
  private void maybeLogUpdateToEventLog(long paramLong, Uri paramUri, String paramString1, String paramString2)
  {
    int i = samplePercentForDuration(paramLong);
    if (i < 100) {}
    for (;;)
    {
      synchronized (this.mRandom)
      {
        if (this.mRandom.nextInt(100) >= i) {
          return;
        }
        str = AppGlobals.getInitialPackage();
        Object[] arrayOfObject = new Object[6];
        arrayOfObject[0] = paramUri.toString();
        arrayOfObject[1] = paramString1;
        if (paramString2 != null)
        {
          arrayOfObject[2] = paramString2;
          arrayOfObject[3] = Long.valueOf(paramLong);
          if (str == null) {
            break label135;
          }
          arrayOfObject[4] = str;
          arrayOfObject[5] = Integer.valueOf(i);
          EventLog.writeEvent(52003, arrayOfObject);
          return;
        }
      }
      paramString2 = "";
      continue;
      label135:
      String str = "";
    }
  }
  
  public static int modeToMode(Uri paramUri, String paramString)
    throws FileNotFoundException
  {
    if ("r".equals(paramString)) {
      return 268435456;
    }
    if (("w".equals(paramString)) || ("wt".equals(paramString))) {
      return 738197504;
    }
    if ("wa".equals(paramString)) {
      return 704643072;
    }
    if ("rw".equals(paramString)) {
      return 939524096;
    }
    if ("rwt".equals(paramString)) {
      return 1006632960;
    }
    throw new FileNotFoundException("Bad mode for " + paramUri + ": " + paramString);
  }
  
  public static void removePeriodicSync(Account paramAccount, String paramString, Bundle paramBundle)
  {
    validateSyncExtrasBundle(paramBundle);
    if (paramAccount == null) {
      throw new IllegalArgumentException("account must not be null");
    }
    if (paramString == null) {
      throw new IllegalArgumentException("authority must not be null");
    }
    try
    {
      getContentService().removePeriodicSync(paramAccount, paramString, paramBundle);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("the ContentService should always be reachable", localRemoteException);
    }
  }
  
  public static void removeStatusChangeListener(Object paramObject)
  {
    if (paramObject == null) {
      throw new IllegalArgumentException("you passed in a null handle");
    }
    try
    {
      getContentService().removeStatusChangeListener((ISyncStatusObserver.Stub)paramObject);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public static void requestSync(Account paramAccount, String paramString, Bundle paramBundle)
  {
    validateSyncExtrasBundle(paramBundle);
    try
    {
      getContentService().requestSync(paramAccount, paramString, paramBundle);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  private int samplePercentForDuration(long paramLong)
  {
    if (paramLong >= 500L) {
      return 100;
    }
    return 1 + (int)(100L * paramLong / 500L);
  }
  
  public static void setIsSyncable(Account paramAccount, String paramString, int paramInt)
  {
    try
    {
      getContentService().setIsSyncable(paramAccount, paramString, paramInt);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public static void setMasterSyncAutomatically(boolean paramBoolean)
  {
    try
    {
      getContentService().setMasterSyncAutomatically(paramBoolean);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public static void setSyncAutomatically(Account paramAccount, String paramString, boolean paramBoolean)
  {
    try
    {
      getContentService().setSyncAutomatically(paramAccount, paramString, paramBoolean);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public static void validateSyncExtrasBundle(Bundle paramBundle)
  {
    try
    {
      Iterator localIterator = paramBundle.keySet().iterator();
      while (localIterator.hasNext())
      {
        Object localObject = paramBundle.get((String)localIterator.next());
        if ((localObject != null) && (!(localObject instanceof Long)) && (!(localObject instanceof Integer)) && (!(localObject instanceof Boolean)) && (!(localObject instanceof Float)) && (!(localObject instanceof Double)) && (!(localObject instanceof String)) && (!(localObject instanceof Account))) {
          throw new IllegalArgumentException("unexpected value type: " + localObject.getClass().getName());
        }
      }
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw localIllegalArgumentException;
    }
    catch (RuntimeException localRuntimeException)
    {
      throw new IllegalArgumentException("error unparceling Bundle", localRuntimeException);
    }
  }
  
  public final ContentProviderClient acquireContentProviderClient(Uri paramUri)
  {
    IContentProvider localIContentProvider = acquireProvider(paramUri);
    if (localIContentProvider != null) {
      return new ContentProviderClient(this, localIContentProvider, true);
    }
    return null;
  }
  
  public final ContentProviderClient acquireContentProviderClient(String paramString)
  {
    IContentProvider localIContentProvider = acquireProvider(paramString);
    if (localIContentProvider != null) {
      return new ContentProviderClient(this, localIContentProvider, true);
    }
    return null;
  }
  
  protected IContentProvider acquireExistingProvider(Context paramContext, String paramString)
  {
    return acquireProvider(paramContext, paramString);
  }
  
  public final IContentProvider acquireExistingProvider(Uri paramUri)
  {
    if (!"content".equals(paramUri.getScheme())) {}
    while (paramUri.getAuthority() == null) {
      return null;
    }
    return acquireExistingProvider(this.mContext, paramUri.getAuthority());
  }
  
  protected abstract IContentProvider acquireProvider(Context paramContext, String paramString);
  
  public final IContentProvider acquireProvider(Uri paramUri)
  {
    if (!"content".equals(paramUri.getScheme())) {}
    while (paramUri.getAuthority() == null) {
      return null;
    }
    return acquireProvider(this.mContext, paramUri.getAuthority());
  }
  
  public final IContentProvider acquireProvider(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    return acquireProvider(this.mContext, paramString);
  }
  
  public final ContentProviderClient acquireUnstableContentProviderClient(Uri paramUri)
  {
    IContentProvider localIContentProvider = acquireUnstableProvider(paramUri);
    if (localIContentProvider != null) {
      return new ContentProviderClient(this, localIContentProvider, false);
    }
    return null;
  }
  
  public final ContentProviderClient acquireUnstableContentProviderClient(String paramString)
  {
    IContentProvider localIContentProvider = acquireUnstableProvider(paramString);
    if (localIContentProvider != null) {
      return new ContentProviderClient(this, localIContentProvider, false);
    }
    return null;
  }
  
  protected abstract IContentProvider acquireUnstableProvider(Context paramContext, String paramString);
  
  public final IContentProvider acquireUnstableProvider(Uri paramUri)
  {
    if (!"content".equals(paramUri.getScheme())) {}
    while (paramUri.getAuthority() == null) {
      return null;
    }
    return acquireUnstableProvider(this.mContext, paramUri.getAuthority());
  }
  
  public final IContentProvider acquireUnstableProvider(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    return acquireUnstableProvider(this.mContext, paramString);
  }
  
  public ContentProviderResult[] applyBatch(String paramString, ArrayList<ContentProviderOperation> paramArrayList)
    throws RemoteException, OperationApplicationException
  {
    ContentProviderClient localContentProviderClient = acquireContentProviderClient(paramString);
    if (localContentProviderClient == null) {
      throw new IllegalArgumentException("Unknown authority " + paramString);
    }
    try
    {
      ContentProviderResult[] arrayOfContentProviderResult = localContentProviderClient.applyBatch(paramArrayList);
      return arrayOfContentProviderResult;
    }
    finally
    {
      localContentProviderClient.release();
    }
  }
  
  public final int bulkInsert(Uri paramUri, ContentValues[] paramArrayOfContentValues)
  {
    IContentProvider localIContentProvider = acquireProvider(paramUri);
    if (localIContentProvider == null) {
      throw new IllegalArgumentException("Unknown URL " + paramUri);
    }
    try
    {
      long l = SystemClock.uptimeMillis();
      int i = localIContentProvider.bulkInsert(paramUri, paramArrayOfContentValues);
      maybeLogUpdateToEventLog(SystemClock.uptimeMillis() - l, paramUri, "bulkinsert", null);
      releaseProvider(localIContentProvider);
      return i;
    }
    catch (RemoteException localRemoteException)
    {
      localRemoteException = localRemoteException;
      releaseProvider(localIContentProvider);
      return 0;
    }
    finally
    {
      localObject = finally;
      releaseProvider(localIContentProvider);
      throw ((Throwable)localObject);
    }
  }
  
  public final Bundle call(Uri paramUri, String paramString1, String paramString2, Bundle paramBundle)
  {
    if (paramUri == null) {
      throw new NullPointerException("uri == null");
    }
    if (paramString1 == null) {
      throw new NullPointerException("method == null");
    }
    IContentProvider localIContentProvider = acquireProvider(paramUri);
    if (localIContentProvider == null) {
      throw new IllegalArgumentException("Unknown URI " + paramUri);
    }
    try
    {
      Bundle localBundle = localIContentProvider.call(paramString1, paramString2, paramBundle);
      releaseProvider(localIContentProvider);
      return localBundle;
    }
    catch (RemoteException localRemoteException)
    {
      localRemoteException = localRemoteException;
      releaseProvider(localIContentProvider);
      return null;
    }
    finally
    {
      localObject = finally;
      releaseProvider(localIContentProvider);
      throw ((Throwable)localObject);
    }
  }
  
  @Deprecated
  public void cancelSync(Uri paramUri)
  {
    if (paramUri != null) {}
    for (String str = paramUri.getAuthority();; str = null)
    {
      cancelSync(null, str);
      return;
    }
  }
  
  public final int delete(Uri paramUri, String paramString, String[] paramArrayOfString)
  {
    IContentProvider localIContentProvider = acquireProvider(paramUri);
    if (localIContentProvider == null) {
      throw new IllegalArgumentException("Unknown URL " + paramUri);
    }
    try
    {
      long l = SystemClock.uptimeMillis();
      int i = localIContentProvider.delete(paramUri, paramString, paramArrayOfString);
      maybeLogUpdateToEventLog(SystemClock.uptimeMillis() - l, paramUri, "delete", paramString);
      releaseProvider(localIContentProvider);
      return i;
    }
    catch (RemoteException localRemoteException)
    {
      localRemoteException = localRemoteException;
      releaseProvider(localIContentProvider);
      return -1;
    }
    finally
    {
      localObject = finally;
      releaseProvider(localIContentProvider);
      throw ((Throwable)localObject);
    }
  }
  
  public OpenResourceIdResult getResourceId(Uri paramUri)
    throws FileNotFoundException
  {
    String str = paramUri.getAuthority();
    if (TextUtils.isEmpty(str)) {
      throw new FileNotFoundException("No authority: " + paramUri);
    }
    Resources localResources;
    List localList;
    try
    {
      localResources = this.mContext.getPackageManager().getResourcesForApplication(str);
      localList = paramUri.getPathSegments();
      if (localList == null) {
        throw new FileNotFoundException("No path: " + paramUri);
      }
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      throw new FileNotFoundException("No package found for authority: " + paramUri);
    }
    int i = localList.size();
    if (i == 1) {}
    int j;
    for (;;)
    {
      try
      {
        int k = Integer.parseInt((String)localList.get(0));
        j = k;
        if (j != 0) {
          break;
        }
        throw new FileNotFoundException("No resource found for: " + paramUri);
      }
      catch (NumberFormatException localNumberFormatException)
      {
        throw new FileNotFoundException("Single path segment is not a resource ID: " + paramUri);
      }
      if (i == 2) {
        j = localResources.getIdentifier((String)localList.get(1), (String)localList.get(0), str);
      } else {
        throw new FileNotFoundException("More than two path segments: " + paramUri);
      }
    }
    OpenResourceIdResult localOpenResourceIdResult = new OpenResourceIdResult();
    localOpenResourceIdResult.r = localResources;
    localOpenResourceIdResult.id = j;
    return localOpenResourceIdResult;
  }
  
  public String[] getStreamTypes(Uri paramUri, String paramString)
  {
    IContentProvider localIContentProvider = acquireProvider(paramUri);
    if (localIContentProvider == null) {
      return null;
    }
    try
    {
      String[] arrayOfString = localIContentProvider.getStreamTypes(paramUri, paramString);
      releaseProvider(localIContentProvider);
      return arrayOfString;
    }
    catch (RemoteException localRemoteException)
    {
      localRemoteException = localRemoteException;
      releaseProvider(localIContentProvider);
      return null;
    }
    finally
    {
      localObject = finally;
      releaseProvider(localIContentProvider);
      throw ((Throwable)localObject);
    }
  }
  
  public final String getType(Uri paramUri)
  {
    IContentProvider localIContentProvider = acquireExistingProvider(paramUri);
    if (localIContentProvider != null) {}
    boolean bool;
    do
    {
      try
      {
        String str3 = localIContentProvider.getType(paramUri);
        str1 = str3;
        return str1;
      }
      catch (RemoteException localRemoteException2)
      {
        return null;
      }
      catch (Exception localException2)
      {
        Log.w("ContentResolver", "Failed to get type for: " + paramUri + " (" + localException2.getMessage() + ")");
        return null;
      }
      finally
      {
        releaseProvider(localIContentProvider);
      }
      bool = "content".equals(paramUri.getScheme());
      String str1 = null;
    } while (!bool);
    try
    {
      String str2 = ActivityManagerNative.getDefault().getProviderMimeType(paramUri, UserHandle.myUserId());
      return str2;
    }
    catch (RemoteException localRemoteException1)
    {
      return null;
    }
    catch (Exception localException1)
    {
      Log.w("ContentResolver", "Failed to get type for: " + paramUri + " (" + localException1.getMessage() + ")");
    }
    return null;
  }
  
  public final Uri insert(Uri paramUri, ContentValues paramContentValues)
  {
    IContentProvider localIContentProvider = acquireProvider(paramUri);
    if (localIContentProvider == null) {
      throw new IllegalArgumentException("Unknown URL " + paramUri);
    }
    try
    {
      long l = SystemClock.uptimeMillis();
      Uri localUri = localIContentProvider.insert(paramUri, paramContentValues);
      maybeLogUpdateToEventLog(SystemClock.uptimeMillis() - l, paramUri, "insert", null);
      releaseProvider(localIContentProvider);
      return localUri;
    }
    catch (RemoteException localRemoteException)
    {
      localRemoteException = localRemoteException;
      releaseProvider(localIContentProvider);
      return null;
    }
    finally
    {
      localObject = finally;
      releaseProvider(localIContentProvider);
      throw ((Throwable)localObject);
    }
  }
  
  public void notifyChange(Uri paramUri, ContentObserver paramContentObserver)
  {
    notifyChange(paramUri, paramContentObserver, true);
  }
  
  public void notifyChange(Uri paramUri, ContentObserver paramContentObserver, boolean paramBoolean)
  {
    notifyChange(paramUri, paramContentObserver, paramBoolean, UserHandle.getCallingUserId());
  }
  
  public void notifyChange(Uri paramUri, ContentObserver paramContentObserver, boolean paramBoolean, int paramInt)
  {
    try
    {
      IContentService localIContentService = getContentService();
      Object localObject;
      if (paramContentObserver == null)
      {
        localObject = null;
        if ((paramContentObserver == null) || (!paramContentObserver.deliverSelfNotifications())) {
          break label55;
        }
      }
      label55:
      for (boolean bool = true;; bool = false)
      {
        localIContentService.notifyChange(paramUri, (IContentObserver)localObject, bool, paramBoolean, paramInt);
        return;
        IContentObserver localIContentObserver = paramContentObserver.getContentObserver();
        localObject = localIContentObserver;
        break;
      }
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  /* Error */
  public final AssetFileDescriptor openAssetFileDescriptor(Uri paramUri, String paramString)
    throws FileNotFoundException
  {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual 407	android/net/Uri:getScheme	()Ljava/lang/String;
    //   4: astore_3
    //   5: ldc 17
    //   7: aload_3
    //   8: invokevirtual 285	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   11: ifeq +100 -> 111
    //   14: ldc_w 279
    //   17: aload_2
    //   18: invokevirtual 285	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   21: ifne +31 -> 52
    //   24: new 277	java/io/FileNotFoundException
    //   27: dup
    //   28: new 228	java/lang/StringBuilder
    //   31: dup
    //   32: invokespecial 301	java/lang/StringBuilder:<init>	()V
    //   35: ldc_w 619
    //   38: invokevirtual 238	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   41: aload_1
    //   42: invokevirtual 306	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   45: invokevirtual 250	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   48: invokespecial 309	java/io/FileNotFoundException:<init>	(Ljava/lang/String;)V
    //   51: athrow
    //   52: aload_0
    //   53: aload_1
    //   54: invokevirtual 621	android/content/ContentResolver:getResourceId	(Landroid/net/Uri;)Landroid/content/ContentResolver$OpenResourceIdResult;
    //   57: astore 24
    //   59: aload 24
    //   61: getfield 537	android/content/ContentResolver$OpenResourceIdResult:r	Landroid/content/res/Resources;
    //   64: aload 24
    //   66: getfield 540	android/content/ContentResolver$OpenResourceIdResult:id	I
    //   69: invokevirtual 625	android/content/res/Resources:openRawResourceFd	(I)Landroid/content/res/AssetFileDescriptor;
    //   72: astore 26
    //   74: aload 26
    //   76: astore 16
    //   78: aload 16
    //   80: areturn
    //   81: astore 25
    //   83: new 277	java/io/FileNotFoundException
    //   86: dup
    //   87: new 228	java/lang/StringBuilder
    //   90: dup
    //   91: invokespecial 301	java/lang/StringBuilder:<init>	()V
    //   94: ldc_w 627
    //   97: invokevirtual 238	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   100: aload_1
    //   101: invokevirtual 306	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   104: invokevirtual 250	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   107: invokespecial 309	java/io/FileNotFoundException:<init>	(Ljava/lang/String;)V
    //   110: athrow
    //   111: ldc 21
    //   113: aload_3
    //   114: invokevirtual 285	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   117: ifeq +34 -> 151
    //   120: new 629	android/content/res/AssetFileDescriptor
    //   123: dup
    //   124: new 631	java/io/File
    //   127: dup
    //   128: aload_1
    //   129: invokevirtual 634	android/net/Uri:getPath	()Ljava/lang/String;
    //   132: invokespecial 635	java/io/File:<init>	(Ljava/lang/String;)V
    //   135: aload_1
    //   136: aload_2
    //   137: invokestatic 637	android/content/ContentResolver:modeToMode	(Landroid/net/Uri;Ljava/lang/String;)I
    //   140: invokestatic 643	android/os/ParcelFileDescriptor:open	(Ljava/io/File;I)Landroid/os/ParcelFileDescriptor;
    //   143: lconst_0
    //   144: ldc2_w 644
    //   147: invokespecial 648	android/content/res/AssetFileDescriptor:<init>	(Landroid/os/ParcelFileDescriptor;JJ)V
    //   150: areturn
    //   151: ldc_w 279
    //   154: aload_2
    //   155: invokevirtual 285	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   158: ifeq +13 -> 171
    //   161: aload_0
    //   162: aload_1
    //   163: ldc_w 650
    //   166: aconst_null
    //   167: invokevirtual 654	android/content/ContentResolver:openTypedAssetFileDescriptor	(Landroid/net/Uri;Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/res/AssetFileDescriptor;
    //   170: areturn
    //   171: aload_0
    //   172: aload_1
    //   173: invokevirtual 416	android/content/ContentResolver:acquireUnstableProvider	(Landroid/net/Uri;)Landroid/content/IContentProvider;
    //   176: astore 4
    //   178: aload 4
    //   180: ifnonnull +31 -> 211
    //   183: new 277	java/io/FileNotFoundException
    //   186: dup
    //   187: new 228	java/lang/StringBuilder
    //   190: dup
    //   191: invokespecial 301	java/lang/StringBuilder:<init>	()V
    //   194: ldc_w 656
    //   197: invokevirtual 238	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   200: aload_1
    //   201: invokevirtual 306	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   204: invokevirtual 250	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   207: invokespecial 309	java/io/FileNotFoundException:<init>	(Ljava/lang/String;)V
    //   210: athrow
    //   211: aconst_null
    //   212: astore 5
    //   214: aload 4
    //   216: aload_1
    //   217: aload_2
    //   218: invokeinterface 659 3 0
    //   223: astore 21
    //   225: aload 21
    //   227: astore 13
    //   229: aconst_null
    //   230: astore 5
    //   232: aload 13
    //   234: ifnonnull +186 -> 420
    //   237: iconst_0
    //   238: ifeq +9 -> 247
    //   241: aload_0
    //   242: aconst_null
    //   243: invokevirtual 456	android/content/ContentResolver:releaseProvider	(Landroid/content/IContentProvider;)Z
    //   246: pop
    //   247: aconst_null
    //   248: astore 16
    //   250: aload 4
    //   252: ifnull -174 -> 78
    //   255: aload_0
    //   256: aload 4
    //   258: invokevirtual 662	android/content/ContentResolver:releaseUnstableProvider	(Landroid/content/IContentProvider;)Z
    //   261: pop
    //   262: aconst_null
    //   263: areturn
    //   264: astore 11
    //   266: aload_0
    //   267: aload 4
    //   269: invokevirtual 666	android/content/ContentResolver:unstableProviderDied	(Landroid/content/IContentProvider;)V
    //   272: aload_0
    //   273: aload_1
    //   274: invokevirtual 391	android/content/ContentResolver:acquireProvider	(Landroid/net/Uri;)Landroid/content/IContentProvider;
    //   277: astore 5
    //   279: aload 5
    //   281: ifnonnull +90 -> 371
    //   284: new 277	java/io/FileNotFoundException
    //   287: dup
    //   288: new 228	java/lang/StringBuilder
    //   291: dup
    //   292: invokespecial 301	java/lang/StringBuilder:<init>	()V
    //   295: ldc_w 656
    //   298: invokevirtual 238	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   301: aload_1
    //   302: invokevirtual 306	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   305: invokevirtual 250	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   308: invokespecial 309	java/io/FileNotFoundException:<init>	(Ljava/lang/String;)V
    //   311: athrow
    //   312: astore 10
    //   314: new 277	java/io/FileNotFoundException
    //   317: dup
    //   318: new 228	java/lang/StringBuilder
    //   321: dup
    //   322: invokespecial 301	java/lang/StringBuilder:<init>	()V
    //   325: ldc_w 668
    //   328: invokevirtual 238	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   331: aload_1
    //   332: invokevirtual 306	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   335: invokevirtual 250	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   338: invokespecial 309	java/io/FileNotFoundException:<init>	(Ljava/lang/String;)V
    //   341: athrow
    //   342: astore 7
    //   344: aload 5
    //   346: ifnull +10 -> 356
    //   349: aload_0
    //   350: aload 5
    //   352: invokevirtual 456	android/content/ContentResolver:releaseProvider	(Landroid/content/IContentProvider;)Z
    //   355: pop
    //   356: aload 4
    //   358: ifnull +10 -> 368
    //   361: aload_0
    //   362: aload 4
    //   364: invokevirtual 662	android/content/ContentResolver:releaseUnstableProvider	(Landroid/content/IContentProvider;)Z
    //   367: pop
    //   368: aload 7
    //   370: athrow
    //   371: aload 5
    //   373: aload_1
    //   374: aload_2
    //   375: invokeinterface 659 3 0
    //   380: astore 12
    //   382: aload 12
    //   384: astore 13
    //   386: aload 13
    //   388: ifnonnull +32 -> 420
    //   391: aload 5
    //   393: ifnull +10 -> 403
    //   396: aload_0
    //   397: aload 5
    //   399: invokevirtual 456	android/content/ContentResolver:releaseProvider	(Landroid/content/IContentProvider;)Z
    //   402: pop
    //   403: aconst_null
    //   404: astore 16
    //   406: aload 4
    //   408: ifnull -330 -> 78
    //   411: aload_0
    //   412: aload 4
    //   414: invokevirtual 662	android/content/ContentResolver:releaseUnstableProvider	(Landroid/content/IContentProvider;)Z
    //   417: pop
    //   418: aconst_null
    //   419: areturn
    //   420: aload 5
    //   422: ifnonnull +10 -> 432
    //   425: aload_0
    //   426: aload_1
    //   427: invokevirtual 391	android/content/ContentResolver:acquireProvider	(Landroid/net/Uri;)Landroid/content/IContentProvider;
    //   430: astore 5
    //   432: aload_0
    //   433: aload 4
    //   435: invokevirtual 662	android/content/ContentResolver:releaseUnstableProvider	(Landroid/content/IContentProvider;)Z
    //   438: pop
    //   439: new 670	android/content/ContentResolver$ParcelFileDescriptorInner
    //   442: dup
    //   443: aload_0
    //   444: aload 13
    //   446: invokevirtual 674	android/content/res/AssetFileDescriptor:getParcelFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   449: aload 5
    //   451: invokespecial 677	android/content/ContentResolver$ParcelFileDescriptorInner:<init>	(Landroid/content/ContentResolver;Landroid/os/ParcelFileDescriptor;Landroid/content/IContentProvider;)V
    //   454: astore 15
    //   456: aconst_null
    //   457: astore 5
    //   459: new 629	android/content/res/AssetFileDescriptor
    //   462: dup
    //   463: aload 15
    //   465: aload 13
    //   467: invokevirtual 680	android/content/res/AssetFileDescriptor:getStartOffset	()J
    //   470: aload 13
    //   472: invokevirtual 683	android/content/res/AssetFileDescriptor:getDeclaredLength	()J
    //   475: invokespecial 648	android/content/res/AssetFileDescriptor:<init>	(Landroid/os/ParcelFileDescriptor;JJ)V
    //   478: astore 16
    //   480: iconst_0
    //   481: ifeq +9 -> 490
    //   484: aload_0
    //   485: aconst_null
    //   486: invokevirtual 456	android/content/ContentResolver:releaseProvider	(Landroid/content/IContentProvider;)Z
    //   489: pop
    //   490: aload 4
    //   492: ifnull -414 -> 78
    //   495: aload_0
    //   496: aload 4
    //   498: invokevirtual 662	android/content/ContentResolver:releaseUnstableProvider	(Landroid/content/IContentProvider;)Z
    //   501: pop
    //   502: aload 16
    //   504: areturn
    //   505: astore 6
    //   507: aload 6
    //   509: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	510	0	this	ContentResolver
    //   0	510	1	paramUri	Uri
    //   0	510	2	paramString	String
    //   4	110	3	str	String
    //   176	321	4	localIContentProvider1	IContentProvider
    //   212	246	5	localIContentProvider2	IContentProvider
    //   505	3	6	localFileNotFoundException	FileNotFoundException
    //   342	27	7	localObject1	Object
    //   312	1	10	localRemoteException	RemoteException
    //   264	1	11	localDeadObjectException	DeadObjectException
    //   380	3	12	localAssetFileDescriptor1	AssetFileDescriptor
    //   227	244	13	localObject2	Object
    //   454	10	15	localParcelFileDescriptorInner	ParcelFileDescriptorInner
    //   76	427	16	localAssetFileDescriptor2	AssetFileDescriptor
    //   223	3	21	localAssetFileDescriptor3	AssetFileDescriptor
    //   57	8	24	localOpenResourceIdResult	OpenResourceIdResult
    //   81	1	25	localNotFoundException	Resources.NotFoundException
    //   72	3	26	localAssetFileDescriptor4	AssetFileDescriptor
    // Exception table:
    //   from	to	target	type
    //   59	74	81	android/content/res/Resources$NotFoundException
    //   214	225	264	android/os/DeadObjectException
    //   214	225	312	android/os/RemoteException
    //   266	279	312	android/os/RemoteException
    //   284	312	312	android/os/RemoteException
    //   371	382	312	android/os/RemoteException
    //   425	432	312	android/os/RemoteException
    //   432	456	312	android/os/RemoteException
    //   459	480	312	android/os/RemoteException
    //   214	225	342	finally
    //   266	279	342	finally
    //   284	312	342	finally
    //   314	342	342	finally
    //   371	382	342	finally
    //   425	432	342	finally
    //   432	456	342	finally
    //   459	480	342	finally
    //   507	510	342	finally
    //   214	225	505	java/io/FileNotFoundException
    //   266	279	505	java/io/FileNotFoundException
    //   284	312	505	java/io/FileNotFoundException
    //   371	382	505	java/io/FileNotFoundException
    //   425	432	505	java/io/FileNotFoundException
    //   432	456	505	java/io/FileNotFoundException
    //   459	480	505	java/io/FileNotFoundException
  }
  
  public final ParcelFileDescriptor openFileDescriptor(Uri paramUri, String paramString)
    throws FileNotFoundException
  {
    AssetFileDescriptor localAssetFileDescriptor = openAssetFileDescriptor(paramUri, paramString);
    if (localAssetFileDescriptor == null) {
      return null;
    }
    if (localAssetFileDescriptor.getDeclaredLength() < 0L) {
      return localAssetFileDescriptor.getParcelFileDescriptor();
    }
    try
    {
      localAssetFileDescriptor.close();
      throw new FileNotFoundException("Not a whole file");
    }
    catch (IOException localIOException)
    {
      for (;;) {}
    }
  }
  
  public final InputStream openInputStream(Uri paramUri)
    throws FileNotFoundException
  {
    String str = paramUri.getScheme();
    if ("android.resource".equals(str))
    {
      OpenResourceIdResult localOpenResourceIdResult = getResourceId(paramUri);
      try
      {
        InputStream localInputStream = localOpenResourceIdResult.r.openRawResource(localOpenResourceIdResult.id);
        return localInputStream;
      }
      catch (Resources.NotFoundException localNotFoundException)
      {
        throw new FileNotFoundException("Resource does not exist: " + paramUri);
      }
    }
    if ("file".equals(str)) {
      return new FileInputStream(paramUri.getPath());
    }
    AssetFileDescriptor localAssetFileDescriptor = openAssetFileDescriptor(paramUri, "r");
    if (localAssetFileDescriptor != null) {}
    for (;;)
    {
      try
      {
        FileInputStream localFileInputStream2 = localAssetFileDescriptor.createInputStream();
        localFileInputStream1 = localFileInputStream2;
        return localFileInputStream1;
      }
      catch (IOException localIOException)
      {
        FileInputStream localFileInputStream1;
        throw new FileNotFoundException("Unable to create stream");
      }
      localFileInputStream1 = null;
    }
  }
  
  public final OutputStream openOutputStream(Uri paramUri)
    throws FileNotFoundException
  {
    return openOutputStream(paramUri, "w");
  }
  
  public final OutputStream openOutputStream(Uri paramUri, String paramString)
    throws FileNotFoundException
  {
    AssetFileDescriptor localAssetFileDescriptor = openAssetFileDescriptor(paramUri, paramString);
    if (localAssetFileDescriptor != null) {}
    try
    {
      FileOutputStream localFileOutputStream = localAssetFileDescriptor.createOutputStream();
      return localFileOutputStream;
    }
    catch (IOException localIOException)
    {
      throw new FileNotFoundException("Unable to create stream");
    }
    return null;
  }
  
  /* Error */
  public final AssetFileDescriptor openTypedAssetFileDescriptor(Uri paramUri, String paramString, Bundle paramBundle)
    throws FileNotFoundException
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual 416	android/content/ContentResolver:acquireUnstableProvider	(Landroid/net/Uri;)Landroid/content/IContentProvider;
    //   5: astore 4
    //   7: aload 4
    //   9: ifnonnull +31 -> 40
    //   12: new 277	java/io/FileNotFoundException
    //   15: dup
    //   16: new 228	java/lang/StringBuilder
    //   19: dup
    //   20: invokespecial 301	java/lang/StringBuilder:<init>	()V
    //   23: ldc_w 656
    //   26: invokevirtual 238	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   29: aload_1
    //   30: invokevirtual 306	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   33: invokevirtual 250	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   36: invokespecial 309	java/io/FileNotFoundException:<init>	(Ljava/lang/String;)V
    //   39: athrow
    //   40: aconst_null
    //   41: astore 5
    //   43: aload 4
    //   45: aload_1
    //   46: aload_2
    //   47: aload_3
    //   48: invokeinterface 721 4 0
    //   53: astore 21
    //   55: aload 21
    //   57: astore 13
    //   59: aconst_null
    //   60: astore 5
    //   62: aload 13
    //   64: ifnonnull +188 -> 252
    //   67: iconst_0
    //   68: ifeq +9 -> 77
    //   71: aload_0
    //   72: aconst_null
    //   73: invokevirtual 456	android/content/ContentResolver:releaseProvider	(Landroid/content/IContentProvider;)Z
    //   76: pop
    //   77: aconst_null
    //   78: astore 16
    //   80: aload 4
    //   82: ifnull +10 -> 92
    //   85: aload_0
    //   86: aload 4
    //   88: invokevirtual 662	android/content/ContentResolver:releaseUnstableProvider	(Landroid/content/IContentProvider;)Z
    //   91: pop
    //   92: aload 16
    //   94: areturn
    //   95: astore 11
    //   97: aload_0
    //   98: aload 4
    //   100: invokevirtual 666	android/content/ContentResolver:unstableProviderDied	(Landroid/content/IContentProvider;)V
    //   103: aload_0
    //   104: aload_1
    //   105: invokevirtual 391	android/content/ContentResolver:acquireProvider	(Landroid/net/Uri;)Landroid/content/IContentProvider;
    //   108: astore 5
    //   110: aload 5
    //   112: ifnonnull +90 -> 202
    //   115: new 277	java/io/FileNotFoundException
    //   118: dup
    //   119: new 228	java/lang/StringBuilder
    //   122: dup
    //   123: invokespecial 301	java/lang/StringBuilder:<init>	()V
    //   126: ldc_w 656
    //   129: invokevirtual 238	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   132: aload_1
    //   133: invokevirtual 306	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   136: invokevirtual 250	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   139: invokespecial 309	java/io/FileNotFoundException:<init>	(Ljava/lang/String;)V
    //   142: athrow
    //   143: astore 10
    //   145: new 277	java/io/FileNotFoundException
    //   148: dup
    //   149: new 228	java/lang/StringBuilder
    //   152: dup
    //   153: invokespecial 301	java/lang/StringBuilder:<init>	()V
    //   156: ldc_w 668
    //   159: invokevirtual 238	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   162: aload_1
    //   163: invokevirtual 306	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   166: invokevirtual 250	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   169: invokespecial 309	java/io/FileNotFoundException:<init>	(Ljava/lang/String;)V
    //   172: athrow
    //   173: astore 7
    //   175: aload 5
    //   177: ifnull +10 -> 187
    //   180: aload_0
    //   181: aload 5
    //   183: invokevirtual 456	android/content/ContentResolver:releaseProvider	(Landroid/content/IContentProvider;)Z
    //   186: pop
    //   187: aload 4
    //   189: ifnull +10 -> 199
    //   192: aload_0
    //   193: aload 4
    //   195: invokevirtual 662	android/content/ContentResolver:releaseUnstableProvider	(Landroid/content/IContentProvider;)Z
    //   198: pop
    //   199: aload 7
    //   201: athrow
    //   202: aload 5
    //   204: aload_1
    //   205: aload_2
    //   206: aload_3
    //   207: invokeinterface 721 4 0
    //   212: astore 12
    //   214: aload 12
    //   216: astore 13
    //   218: aload 13
    //   220: ifnonnull +32 -> 252
    //   223: aload 5
    //   225: ifnull +10 -> 235
    //   228: aload_0
    //   229: aload 5
    //   231: invokevirtual 456	android/content/ContentResolver:releaseProvider	(Landroid/content/IContentProvider;)Z
    //   234: pop
    //   235: aconst_null
    //   236: astore 16
    //   238: aload 4
    //   240: ifnull -148 -> 92
    //   243: aload_0
    //   244: aload 4
    //   246: invokevirtual 662	android/content/ContentResolver:releaseUnstableProvider	(Landroid/content/IContentProvider;)Z
    //   249: pop
    //   250: aconst_null
    //   251: areturn
    //   252: aload 5
    //   254: ifnonnull +10 -> 264
    //   257: aload_0
    //   258: aload_1
    //   259: invokevirtual 391	android/content/ContentResolver:acquireProvider	(Landroid/net/Uri;)Landroid/content/IContentProvider;
    //   262: astore 5
    //   264: aload_0
    //   265: aload 4
    //   267: invokevirtual 662	android/content/ContentResolver:releaseUnstableProvider	(Landroid/content/IContentProvider;)Z
    //   270: pop
    //   271: new 670	android/content/ContentResolver$ParcelFileDescriptorInner
    //   274: dup
    //   275: aload_0
    //   276: aload 13
    //   278: invokevirtual 674	android/content/res/AssetFileDescriptor:getParcelFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   281: aload 5
    //   283: invokespecial 677	android/content/ContentResolver$ParcelFileDescriptorInner:<init>	(Landroid/content/ContentResolver;Landroid/os/ParcelFileDescriptor;Landroid/content/IContentProvider;)V
    //   286: astore 15
    //   288: aconst_null
    //   289: astore 5
    //   291: new 629	android/content/res/AssetFileDescriptor
    //   294: dup
    //   295: aload 15
    //   297: aload 13
    //   299: invokevirtual 680	android/content/res/AssetFileDescriptor:getStartOffset	()J
    //   302: aload 13
    //   304: invokevirtual 683	android/content/res/AssetFileDescriptor:getDeclaredLength	()J
    //   307: invokespecial 648	android/content/res/AssetFileDescriptor:<init>	(Landroid/os/ParcelFileDescriptor;JJ)V
    //   310: astore 16
    //   312: iconst_0
    //   313: ifeq +9 -> 322
    //   316: aload_0
    //   317: aconst_null
    //   318: invokevirtual 456	android/content/ContentResolver:releaseProvider	(Landroid/content/IContentProvider;)Z
    //   321: pop
    //   322: aload 4
    //   324: ifnull -232 -> 92
    //   327: aload_0
    //   328: aload 4
    //   330: invokevirtual 662	android/content/ContentResolver:releaseUnstableProvider	(Landroid/content/IContentProvider;)Z
    //   333: pop
    //   334: aload 16
    //   336: areturn
    //   337: astore 6
    //   339: aload 6
    //   341: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	342	0	this	ContentResolver
    //   0	342	1	paramUri	Uri
    //   0	342	2	paramString	String
    //   0	342	3	paramBundle	Bundle
    //   5	324	4	localIContentProvider1	IContentProvider
    //   41	249	5	localIContentProvider2	IContentProvider
    //   337	3	6	localFileNotFoundException	FileNotFoundException
    //   173	27	7	localObject1	Object
    //   143	1	10	localRemoteException	RemoteException
    //   95	1	11	localDeadObjectException	DeadObjectException
    //   212	3	12	localAssetFileDescriptor1	AssetFileDescriptor
    //   57	246	13	localObject2	Object
    //   286	10	15	localParcelFileDescriptorInner	ParcelFileDescriptorInner
    //   78	257	16	localAssetFileDescriptor2	AssetFileDescriptor
    //   53	3	21	localAssetFileDescriptor3	AssetFileDescriptor
    // Exception table:
    //   from	to	target	type
    //   43	55	95	android/os/DeadObjectException
    //   43	55	143	android/os/RemoteException
    //   97	110	143	android/os/RemoteException
    //   115	143	143	android/os/RemoteException
    //   202	214	143	android/os/RemoteException
    //   257	264	143	android/os/RemoteException
    //   264	288	143	android/os/RemoteException
    //   291	312	143	android/os/RemoteException
    //   43	55	173	finally
    //   97	110	173	finally
    //   115	143	173	finally
    //   145	173	173	finally
    //   202	214	173	finally
    //   257	264	173	finally
    //   264	288	173	finally
    //   291	312	173	finally
    //   339	342	173	finally
    //   43	55	337	java/io/FileNotFoundException
    //   97	110	337	java/io/FileNotFoundException
    //   115	143	337	java/io/FileNotFoundException
    //   202	214	337	java/io/FileNotFoundException
    //   257	264	337	java/io/FileNotFoundException
    //   264	288	337	java/io/FileNotFoundException
    //   291	312	337	java/io/FileNotFoundException
  }
  
  public final Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    return query(paramUri, paramArrayOfString1, paramString1, paramArrayOfString2, paramString2, null);
  }
  
  public final Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2, CancellationSignal paramCancellationSignal)
  {
    IContentProvider localIContentProvider1 = acquireUnstableProvider(paramUri);
    Object localObject3;
    if (localIContentProvider1 == null) {
      localObject3 = null;
    }
    for (;;)
    {
      return (Cursor)localObject3;
      Object localObject1 = null;
      try
      {
        long l = SystemClock.uptimeMillis();
        ICancellationSignal localICancellationSignal1 = null;
        localObject1 = null;
        if (paramCancellationSignal != null)
        {
          paramCancellationSignal.throwIfCanceled();
          localICancellationSignal1 = localIContentProvider1.createCancellationSignal();
          paramCancellationSignal.setRemote(localICancellationSignal1);
        }
        try
        {
          Cursor localCursor2 = localIContentProvider1.query(paramUri, paramArrayOfString1, paramString1, paramArrayOfString2, paramString2, localICancellationSignal1);
          localCursor1 = localCursor2;
          if (localCursor1 == null)
          {
            if (localIContentProvider1 != null) {
              releaseUnstableProvider(localIContentProvider1);
            }
            localObject3 = null;
            if (localObject1 == null) {
              continue;
            }
            releaseProvider((IContentProvider)localObject1);
            return null;
          }
        }
        catch (DeadObjectException localDeadObjectException)
        {
          Cursor localCursor1;
          for (;;)
          {
            unstableProviderDied(localIContentProvider1);
            IContentProvider localIContentProvider2 = acquireProvider(paramUri);
            localObject1 = localIContentProvider2;
            if (localObject1 == null)
            {
              if (localIContentProvider1 != null) {
                releaseUnstableProvider(localIContentProvider1);
              }
              localObject3 = null;
              if (localObject1 == null) {
                break;
              }
              releaseProvider((IContentProvider)localObject1);
              return null;
            }
            ICancellationSignal localICancellationSignal2 = localICancellationSignal1;
            localCursor1 = ((IContentProvider)localObject1).query(paramUri, paramArrayOfString1, paramString1, paramArrayOfString2, paramString2, localICancellationSignal2);
          }
          localCursor1.getCount();
          maybeLogQueryToEventLog(SystemClock.uptimeMillis() - l, paramUri, paramArrayOfString1, paramString1, paramString2);
          if (localObject1 != null) {}
          IContentProvider localIContentProvider3;
          for (Object localObject4 = localObject1;; localObject4 = localIContentProvider3)
          {
            localObject3 = new CursorWrapperInner(localCursor1, (IContentProvider)localObject4);
            if (localIContentProvider1 != null) {
              releaseUnstableProvider(localIContentProvider1);
            }
            if (0 == 0) {
              break;
            }
            releaseProvider(null);
            return (Cursor)localObject3;
            localIContentProvider3 = acquireProvider(paramUri);
          }
        }
      }
      catch (RemoteException localRemoteException)
      {
        if (localIContentProvider1 != null) {
          releaseUnstableProvider(localIContentProvider1);
        }
        localObject3 = null;
        if (localObject1 == null) {
          continue;
        }
        releaseProvider((IContentProvider)localObject1);
        return null;
      }
      finally
      {
        if (localIContentProvider1 != null) {
          releaseUnstableProvider(localIContentProvider1);
        }
        if (localObject1 != null) {
          releaseProvider((IContentProvider)localObject1);
        }
      }
    }
  }
  
  public final void registerContentObserver(Uri paramUri, boolean paramBoolean, ContentObserver paramContentObserver)
  {
    registerContentObserver(paramUri, paramBoolean, paramContentObserver, UserHandle.myUserId());
  }
  
  public final void registerContentObserver(Uri paramUri, boolean paramBoolean, ContentObserver paramContentObserver, int paramInt)
  {
    try
    {
      getContentService().registerContentObserver(paramUri, paramBoolean, paramContentObserver.getContentObserver(), paramInt);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public abstract boolean releaseProvider(IContentProvider paramIContentProvider);
  
  public abstract boolean releaseUnstableProvider(IContentProvider paramIContentProvider);
  
  @Deprecated
  public void startSync(Uri paramUri, Bundle paramBundle)
  {
    Account localAccount = null;
    if (paramBundle != null)
    {
      String str2 = paramBundle.getString("account");
      boolean bool = TextUtils.isEmpty(str2);
      localAccount = null;
      if (!bool) {
        localAccount = new Account(str2, "com.google");
      }
      paramBundle.remove("account");
    }
    if (paramUri != null) {}
    for (String str1 = paramUri.getAuthority();; str1 = null)
    {
      requestSync(localAccount, str1, paramBundle);
      return;
    }
  }
  
  public final void unregisterContentObserver(ContentObserver paramContentObserver)
  {
    try
    {
      IContentObserver localIContentObserver = paramContentObserver.releaseContentObserver();
      if (localIContentObserver != null) {
        getContentService().unregisterContentObserver(localIContentObserver);
      }
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public abstract void unstableProviderDied(IContentProvider paramIContentProvider);
  
  public final int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString)
  {
    IContentProvider localIContentProvider = acquireProvider(paramUri);
    if (localIContentProvider == null) {
      throw new IllegalArgumentException("Unknown URI " + paramUri);
    }
    try
    {
      long l = SystemClock.uptimeMillis();
      int i = localIContentProvider.update(paramUri, paramContentValues, paramString, paramArrayOfString);
      maybeLogUpdateToEventLog(SystemClock.uptimeMillis() - l, paramUri, "update", paramString);
      releaseProvider(localIContentProvider);
      return i;
    }
    catch (RemoteException localRemoteException)
    {
      localRemoteException = localRemoteException;
      releaseProvider(localIContentProvider);
      return -1;
    }
    finally
    {
      localObject = finally;
      releaseProvider(localIContentProvider);
      throw ((Throwable)localObject);
    }
  }
  
  private final class CursorWrapperInner
    extends CrossProcessCursorWrapper
  {
    public static final String TAG = "CursorWrapperInner";
    private final CloseGuard mCloseGuard = CloseGuard.get();
    private final IContentProvider mContentProvider;
    private boolean mProviderReleased;
    
    CursorWrapperInner(Cursor paramCursor, IContentProvider paramIContentProvider)
    {
      super();
      this.mContentProvider = paramIContentProvider;
      this.mCloseGuard.open("close");
    }
    
    public void close()
    {
      super.close();
      ContentResolver.this.releaseProvider(this.mContentProvider);
      this.mProviderReleased = true;
      if (this.mCloseGuard != null) {
        this.mCloseGuard.close();
      }
    }
    
    protected void finalize()
      throws Throwable
    {
      try
      {
        if (this.mCloseGuard != null) {
          this.mCloseGuard.warnIfOpen();
        }
        if ((!this.mProviderReleased) && (this.mContentProvider != null))
        {
          Log.w("CursorWrapperInner", "Cursor finalized without prior close()");
          ContentResolver.this.releaseProvider(this.mContentProvider);
        }
        return;
      }
      finally
      {
        super.finalize();
      }
    }
  }
  
  public class OpenResourceIdResult
  {
    public int id;
    public Resources r;
    
    public OpenResourceIdResult() {}
  }
  
  private final class ParcelFileDescriptorInner
    extends ParcelFileDescriptor
  {
    private final IContentProvider mContentProvider;
    private boolean mReleaseProviderFlag = false;
    
    ParcelFileDescriptorInner(ParcelFileDescriptor paramParcelFileDescriptor, IContentProvider paramIContentProvider)
    {
      super();
      this.mContentProvider = paramIContentProvider;
    }
    
    public void close()
      throws IOException
    {
      if (!this.mReleaseProviderFlag)
      {
        super.close();
        ContentResolver.this.releaseProvider(this.mContentProvider);
        this.mReleaseProviderFlag = true;
      }
    }
    
    protected void finalize()
      throws Throwable
    {
      if (!this.mReleaseProviderFlag) {
        close();
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\ContentResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
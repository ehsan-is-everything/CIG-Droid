package android.content.res;

import java.io.File;
import java.io.IOException;

public class ObbScanner
{
  public static ObbInfo getObbInfo(String paramString)
    throws IOException
  {
    if (paramString == null) {
      throw new IllegalArgumentException("file path cannot be null");
    }
    File localFile = new File(paramString);
    if (!localFile.exists()) {
      throw new IllegalArgumentException("OBB file does not exist: " + paramString);
    }
    String str = localFile.getCanonicalPath();
    ObbInfo localObbInfo = new ObbInfo();
    localObbInfo.filename = str;
    getObbInfo_native(str, localObbInfo);
    return localObbInfo;
  }
  
  private static native void getObbInfo_native(String paramString, ObbInfo paramObbInfo)
    throws IOException;
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\res\ObbScanner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
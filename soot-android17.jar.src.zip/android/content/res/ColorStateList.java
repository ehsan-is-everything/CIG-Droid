package android.content.res;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.StateSet;
import android.util.Xml;
import com.android.internal.util.ArrayUtils;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class ColorStateList
  implements Parcelable
{
  public static final Parcelable.Creator<ColorStateList> CREATOR = new Parcelable.Creator()
  {
    public ColorStateList createFromParcel(Parcel paramAnonymousParcel)
    {
      int i = paramAnonymousParcel.readInt();
      int[][] arrayOfInt = new int[i][];
      for (int j = 0; j < i; j++) {
        arrayOfInt[j] = paramAnonymousParcel.createIntArray();
      }
      return new ColorStateList(arrayOfInt, paramAnonymousParcel.createIntArray());
    }
    
    public ColorStateList[] newArray(int paramAnonymousInt)
    {
      return new ColorStateList[paramAnonymousInt];
    }
  };
  private static final int[][] EMPTY = { new int[0] };
  private static final SparseArray<WeakReference<ColorStateList>> sCache = new SparseArray();
  private int[] mColors;
  private int mDefaultColor = -65536;
  private int[][] mStateSpecs;
  
  private ColorStateList() {}
  
  public ColorStateList(int[][] paramArrayOfInt, int[] paramArrayOfInt1)
  {
    this.mStateSpecs = paramArrayOfInt;
    this.mColors = paramArrayOfInt1;
    if (paramArrayOfInt.length > 0)
    {
      this.mDefaultColor = paramArrayOfInt1[0];
      for (int i = 0; i < paramArrayOfInt.length; i++) {
        if (paramArrayOfInt[i].length == 0) {
          this.mDefaultColor = paramArrayOfInt1[i];
        }
      }
    }
  }
  
  public static ColorStateList createFromXml(Resources paramResources, XmlPullParser paramXmlPullParser)
    throws XmlPullParserException, IOException
  {
    AttributeSet localAttributeSet = Xml.asAttributeSet(paramXmlPullParser);
    int i;
    do
    {
      i = paramXmlPullParser.next();
    } while ((i != 2) && (i != 1));
    if (i != 2) {
      throw new XmlPullParserException("No start tag found");
    }
    return createFromXmlInner(paramResources, paramXmlPullParser, localAttributeSet);
  }
  
  private static ColorStateList createFromXmlInner(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet)
    throws XmlPullParserException, IOException
  {
    String str = paramXmlPullParser.getName();
    if (str.equals("selector"))
    {
      ColorStateList localColorStateList = new ColorStateList();
      localColorStateList.inflate(paramResources, paramXmlPullParser, paramAttributeSet);
      return localColorStateList;
    }
    throw new XmlPullParserException(paramXmlPullParser.getPositionDescription() + ": invalid drawable tag " + str);
  }
  
  private void inflate(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet)
    throws XmlPullParserException, IOException
  {
    int i = 1 + paramXmlPullParser.getDepth();
    int j = 20;
    int k = 0;
    Object localObject1 = new int[j];
    Object localObject2 = new int[j][];
    int i1;
    int i2;
    int i3;
    int[] arrayOfInt2;
    int i5;
    int i6;
    int i7;
    for (;;)
    {
      int m = paramXmlPullParser.next();
      if (m == 1) {
        break label389;
      }
      int n = paramXmlPullParser.getDepth();
      if ((n < i) && (m == 3)) {
        break label389;
      }
      if ((m == 2) && (n <= i) && (paramXmlPullParser.getName().equals("item")))
      {
        i1 = 0;
        i2 = -65536;
        i3 = 0;
        int i4 = paramAttributeSet.getAttributeCount();
        arrayOfInt2 = new int[i4];
        i5 = 0;
        i6 = 0;
        if (i5 < i4)
        {
          i7 = paramAttributeSet.getAttributeNameResource(i5);
          if (i7 != 0) {
            break;
          }
        }
        int[] arrayOfInt3 = StateSet.trimStateSet(arrayOfInt2, i6);
        if (i1 == 0) {
          break label352;
        }
        i2 = paramResources.getColor(i1);
        label166:
        if ((k == 0) || (arrayOfInt3.length == 0)) {
          this.mDefaultColor = i2;
        }
        if (k + 1 >= j)
        {
          j = ArrayUtils.idealIntArraySize(k + 1);
          int[] arrayOfInt4 = new int[j];
          System.arraycopy(localObject1, 0, arrayOfInt4, 0, k);
          int[][] arrayOfInt5 = new int[j][];
          System.arraycopy(localObject2, 0, arrayOfInt5, 0, k);
          localObject1 = arrayOfInt4;
          localObject2 = arrayOfInt5;
        }
        localObject1[k] = i2;
        localObject2[k] = arrayOfInt3;
        k++;
      }
    }
    int i8;
    if (i7 == 16843173)
    {
      i1 = paramAttributeSet.getAttributeResourceValue(i5, 0);
      if (i1 != 0) {
        break label437;
      }
      i2 = paramAttributeSet.getAttributeIntValue(i5, i2);
      i3 = 1;
      i8 = i6;
    }
    for (;;)
    {
      i5++;
      i6 = i8;
      break;
      i8 = i6 + 1;
      if (paramAttributeSet.getAttributeBooleanValue(i5, false)) {}
      for (;;)
      {
        arrayOfInt2[i6] = i7;
        break;
        i7 = -i7;
      }
      label352:
      if (i3 != 0) {
        break label166;
      }
      throw new XmlPullParserException(paramXmlPullParser.getPositionDescription() + ": <item> tag requires a 'android:color' attribute.");
      label389:
      this.mColors = new int[k];
      this.mStateSpecs = new int[k][];
      System.arraycopy(localObject1, 0, this.mColors, 0, k);
      int[][] arrayOfInt1 = this.mStateSpecs;
      System.arraycopy(localObject2, 0, arrayOfInt1, 0, k);
      return;
      label437:
      i8 = i6;
    }
  }
  
  public static ColorStateList valueOf(int paramInt)
  {
    for (;;)
    {
      synchronized (sCache)
      {
        WeakReference localWeakReference = (WeakReference)sCache.get(paramInt);
        if (localWeakReference != null)
        {
          localColorStateList1 = (ColorStateList)localWeakReference.get();
          if (localColorStateList1 != null) {
            return localColorStateList1;
          }
          ColorStateList localColorStateList2 = new ColorStateList(EMPTY, new int[] { paramInt });
          sCache.put(paramInt, new WeakReference(localColorStateList2));
          return localColorStateList2;
        }
      }
      ColorStateList localColorStateList1 = null;
    }
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public int getColorForState(int[] paramArrayOfInt, int paramInt)
  {
    int i = this.mStateSpecs.length;
    for (int j = 0;; j++) {
      if (j < i)
      {
        if (StateSet.stateSetMatches(this.mStateSpecs[j], paramArrayOfInt)) {
          paramInt = this.mColors[j];
        }
      }
      else {
        return paramInt;
      }
    }
  }
  
  public int getDefaultColor()
  {
    return this.mDefaultColor;
  }
  
  public boolean isStateful()
  {
    return this.mStateSpecs.length > 1;
  }
  
  public String toString()
  {
    return "ColorStateList{mStateSpecs=" + Arrays.deepToString(this.mStateSpecs) + "mColors=" + Arrays.toString(this.mColors) + "mDefaultColor=" + this.mDefaultColor + '}';
  }
  
  public ColorStateList withAlpha(int paramInt)
  {
    int[] arrayOfInt = new int[this.mColors.length];
    int i = arrayOfInt.length;
    for (int j = 0; j < i; j++) {
      arrayOfInt[j] = (0xFFFFFF & this.mColors[j] | paramInt << 24);
    }
    return new ColorStateList(this.mStateSpecs, arrayOfInt);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    int i = this.mStateSpecs.length;
    paramParcel.writeInt(i);
    for (int j = 0; j < i; j++) {
      paramParcel.writeIntArray(this.mStateSpecs[j]);
    }
    paramParcel.writeIntArray(this.mColors);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\res\ColorStateList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
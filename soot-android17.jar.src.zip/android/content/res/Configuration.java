package android.content.res;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import java.util.Locale;

public final class Configuration
  implements Parcelable, Comparable<Configuration>
{
  public static final Parcelable.Creator<Configuration> CREATOR = new Parcelable.Creator()
  {
    public Configuration createFromParcel(Parcel paramAnonymousParcel)
    {
      return new Configuration(paramAnonymousParcel, null);
    }
    
    public Configuration[] newArray(int paramAnonymousInt)
    {
      return new Configuration[paramAnonymousInt];
    }
  };
  public static final int DENSITY_DPI_UNDEFINED = 0;
  public static final Configuration EMPTY = new Configuration();
  public static final int HARDKEYBOARDHIDDEN_NO = 1;
  public static final int HARDKEYBOARDHIDDEN_UNDEFINED = 0;
  public static final int HARDKEYBOARDHIDDEN_YES = 2;
  public static final int KEYBOARDHIDDEN_NO = 1;
  public static final int KEYBOARDHIDDEN_SOFT = 3;
  public static final int KEYBOARDHIDDEN_UNDEFINED = 0;
  public static final int KEYBOARDHIDDEN_YES = 2;
  public static final int KEYBOARD_12KEY = 3;
  public static final int KEYBOARD_NOKEYS = 1;
  public static final int KEYBOARD_QWERTY = 2;
  public static final int KEYBOARD_UNDEFINED = 0;
  public static final int NAVIGATIONHIDDEN_NO = 1;
  public static final int NAVIGATIONHIDDEN_UNDEFINED = 0;
  public static final int NAVIGATIONHIDDEN_YES = 2;
  public static final int NAVIGATION_DPAD = 2;
  public static final int NAVIGATION_NONAV = 1;
  public static final int NAVIGATION_TRACKBALL = 3;
  public static final int NAVIGATION_UNDEFINED = 0;
  public static final int NAVIGATION_WHEEL = 4;
  public static final int ORIENTATION_LANDSCAPE = 2;
  public static final int ORIENTATION_PORTRAIT = 1;
  @Deprecated
  public static final int ORIENTATION_SQUARE = 3;
  public static final int ORIENTATION_UNDEFINED = 0;
  public static final int SCREENLAYOUT_COMPAT_NEEDED = 268435456;
  public static final int SCREENLAYOUT_LAYOUTDIR_LTR = 64;
  public static final int SCREENLAYOUT_LAYOUTDIR_MASK = 192;
  public static final int SCREENLAYOUT_LAYOUTDIR_RTL = 128;
  public static final int SCREENLAYOUT_LAYOUTDIR_SHIFT = 6;
  public static final int SCREENLAYOUT_LAYOUTDIR_UNDEFINED = 0;
  public static final int SCREENLAYOUT_LONG_MASK = 48;
  public static final int SCREENLAYOUT_LONG_NO = 16;
  public static final int SCREENLAYOUT_LONG_UNDEFINED = 0;
  public static final int SCREENLAYOUT_LONG_YES = 32;
  public static final int SCREENLAYOUT_SIZE_LARGE = 3;
  public static final int SCREENLAYOUT_SIZE_MASK = 15;
  public static final int SCREENLAYOUT_SIZE_NORMAL = 2;
  public static final int SCREENLAYOUT_SIZE_SMALL = 1;
  public static final int SCREENLAYOUT_SIZE_UNDEFINED = 0;
  public static final int SCREENLAYOUT_SIZE_XLARGE = 4;
  public static final int SCREENLAYOUT_UNDEFINED = 0;
  public static final int SCREEN_HEIGHT_DP_UNDEFINED = 0;
  public static final int SCREEN_WIDTH_DP_UNDEFINED = 0;
  public static final int SMALLEST_SCREEN_WIDTH_DP_UNDEFINED = 0;
  public static final int TOUCHSCREEN_FINGER = 3;
  public static final int TOUCHSCREEN_NOTOUCH = 1;
  @Deprecated
  public static final int TOUCHSCREEN_STYLUS = 2;
  public static final int TOUCHSCREEN_UNDEFINED = 0;
  public static final int UI_MODE_NIGHT_MASK = 48;
  public static final int UI_MODE_NIGHT_NO = 16;
  public static final int UI_MODE_NIGHT_UNDEFINED = 0;
  public static final int UI_MODE_NIGHT_YES = 32;
  public static final int UI_MODE_TYPE_APPLIANCE = 5;
  public static final int UI_MODE_TYPE_CAR = 3;
  public static final int UI_MODE_TYPE_DESK = 2;
  public static final int UI_MODE_TYPE_MASK = 15;
  public static final int UI_MODE_TYPE_NORMAL = 1;
  public static final int UI_MODE_TYPE_TELEVISION = 4;
  public static final int UI_MODE_TYPE_UNDEFINED;
  public int compatScreenHeightDp;
  public int compatScreenWidthDp;
  public int compatSmallestScreenWidthDp;
  public int densityDpi;
  public float fontScale;
  public int hardKeyboardHidden;
  public int keyboard;
  public int keyboardHidden;
  public Locale locale;
  public int mcc;
  public int mnc;
  public int navigation;
  public int navigationHidden;
  public int orientation;
  public int screenHeightDp;
  public int screenLayout;
  public int screenWidthDp;
  public int seq;
  public int smallestScreenWidthDp;
  public int touchscreen;
  public int uiMode;
  public boolean userSetLocale;
  
  public Configuration()
  {
    setToDefaults();
  }
  
  public Configuration(Configuration paramConfiguration)
  {
    setTo(paramConfiguration);
  }
  
  private Configuration(Parcel paramParcel)
  {
    readFromParcel(paramParcel);
  }
  
  private static int getScreenLayoutNoDirection(int paramInt)
  {
    return paramInt & 0xFF3F;
  }
  
  public static boolean needNewResources(int paramInt1, int paramInt2)
  {
    return (paramInt1 & (0x40000000 | paramInt2)) != 0;
  }
  
  public static int reduceScreenLayout(int paramInt1, int paramInt2, int paramInt3)
  {
    int i;
    int k;
    int j;
    if (paramInt2 < 470)
    {
      i = 1;
      k = 0;
      j = 0;
    }
    for (;;)
    {
      if (k == 0) {
        paramInt1 = 0x10 | paramInt1 & 0xFFFFFFCF;
      }
      if (j != 0) {
        paramInt1 |= 0x10000000;
      }
      if (i < (paramInt1 & 0xF)) {
        paramInt1 = i | paramInt1 & 0xFFFFFFF0;
      }
      return paramInt1;
      if ((paramInt2 >= 960) && (paramInt3 >= 720))
      {
        i = 4;
        label71:
        if ((paramInt3 <= 321) && (paramInt2 <= 570)) {
          break label129;
        }
      }
      label129:
      for (j = 1;; j = 0)
      {
        if (paramInt2 * 3 / 5 < paramInt3 - 1) {
          break label135;
        }
        k = 1;
        break;
        if ((paramInt2 >= 640) && (paramInt3 >= 480))
        {
          i = 3;
          break label71;
        }
        i = 2;
        break label71;
      }
      label135:
      k = 0;
    }
  }
  
  public static int resetScreenLayout(int paramInt)
  {
    return 0x24 | 0xEFFFFFC0 & paramInt;
  }
  
  public int compareTo(Configuration paramConfiguration)
  {
    float f1 = this.fontScale;
    float f2 = paramConfiguration.fontScale;
    int i;
    if (f1 < f2) {
      i = -1;
    }
    do
    {
      do
      {
        do
        {
          do
          {
            do
            {
              do
              {
                do
                {
                  do
                  {
                    do
                    {
                      do
                      {
                        do
                        {
                          do
                          {
                            do
                            {
                              do
                              {
                                do
                                {
                                  do
                                  {
                                    do
                                    {
                                      return i;
                                      if (f1 > f2) {
                                        return 1;
                                      }
                                      i = this.mcc - paramConfiguration.mcc;
                                    } while (i != 0);
                                    i = this.mnc - paramConfiguration.mnc;
                                  } while (i != 0);
                                  if (this.locale == null)
                                  {
                                    if (paramConfiguration.locale == null) {
                                      break;
                                    }
                                    return 1;
                                  }
                                  if (paramConfiguration.locale == null) {
                                    return -1;
                                  }
                                  i = this.locale.getLanguage().compareTo(paramConfiguration.locale.getLanguage());
                                } while (i != 0);
                                i = this.locale.getCountry().compareTo(paramConfiguration.locale.getCountry());
                              } while (i != 0);
                              i = this.locale.getVariant().compareTo(paramConfiguration.locale.getVariant());
                            } while (i != 0);
                            i = this.touchscreen - paramConfiguration.touchscreen;
                          } while (i != 0);
                          i = this.keyboard - paramConfiguration.keyboard;
                        } while (i != 0);
                        i = this.keyboardHidden - paramConfiguration.keyboardHidden;
                      } while (i != 0);
                      i = this.hardKeyboardHidden - paramConfiguration.hardKeyboardHidden;
                    } while (i != 0);
                    i = this.navigation - paramConfiguration.navigation;
                  } while (i != 0);
                  i = this.navigationHidden - paramConfiguration.navigationHidden;
                } while (i != 0);
                i = this.orientation - paramConfiguration.orientation;
              } while (i != 0);
              i = this.screenLayout - paramConfiguration.screenLayout;
            } while (i != 0);
            i = this.uiMode - paramConfiguration.uiMode;
          } while (i != 0);
          i = this.screenWidthDp - paramConfiguration.screenWidthDp;
        } while (i != 0);
        i = this.screenHeightDp - paramConfiguration.screenHeightDp;
      } while (i != 0);
      i = this.smallestScreenWidthDp - paramConfiguration.smallestScreenWidthDp;
    } while (i != 0);
    return this.densityDpi - paramConfiguration.densityDpi;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public int diff(Configuration paramConfiguration)
  {
    boolean bool1 = paramConfiguration.fontScale < 0.0F;
    int i = 0;
    if (bool1)
    {
      boolean bool2 = this.fontScale < paramConfiguration.fontScale;
      i = 0;
      if (bool2) {
        i = 0x0 | 0x40000000;
      }
    }
    if ((paramConfiguration.mcc != 0) && (this.mcc != paramConfiguration.mcc)) {
      i |= 0x1;
    }
    if ((paramConfiguration.mnc != 0) && (this.mnc != paramConfiguration.mnc)) {
      i |= 0x2;
    }
    if ((paramConfiguration.locale != null) && ((this.locale == null) || (!this.locale.equals(paramConfiguration.locale)))) {
      i = 0x2000 | i | 0x4;
    }
    if ((paramConfiguration.touchscreen != 0) && (this.touchscreen != paramConfiguration.touchscreen)) {
      i |= 0x8;
    }
    if ((paramConfiguration.keyboard != 0) && (this.keyboard != paramConfiguration.keyboard)) {
      i |= 0x10;
    }
    if ((paramConfiguration.keyboardHidden != 0) && (this.keyboardHidden != paramConfiguration.keyboardHidden)) {
      i |= 0x20;
    }
    if ((paramConfiguration.hardKeyboardHidden != 0) && (this.hardKeyboardHidden != paramConfiguration.hardKeyboardHidden)) {
      i |= 0x20;
    }
    if ((paramConfiguration.navigation != 0) && (this.navigation != paramConfiguration.navigation)) {
      i |= 0x40;
    }
    if ((paramConfiguration.navigationHidden != 0) && (this.navigationHidden != paramConfiguration.navigationHidden)) {
      i |= 0x20;
    }
    if ((paramConfiguration.orientation != 0) && (this.orientation != paramConfiguration.orientation)) {
      i |= 0x80;
    }
    if ((getScreenLayoutNoDirection(paramConfiguration.screenLayout) != 0) && (getScreenLayoutNoDirection(this.screenLayout) != getScreenLayoutNoDirection(paramConfiguration.screenLayout))) {
      i |= 0x100;
    }
    if ((paramConfiguration.uiMode != 0) && (this.uiMode != paramConfiguration.uiMode)) {
      i |= 0x200;
    }
    if ((paramConfiguration.screenWidthDp != 0) && (this.screenWidthDp != paramConfiguration.screenWidthDp)) {
      i |= 0x400;
    }
    if ((paramConfiguration.screenHeightDp != 0) && (this.screenHeightDp != paramConfiguration.screenHeightDp)) {
      i |= 0x400;
    }
    if ((paramConfiguration.smallestScreenWidthDp != 0) && (this.smallestScreenWidthDp != paramConfiguration.smallestScreenWidthDp)) {
      i |= 0x800;
    }
    if ((paramConfiguration.densityDpi != 0) && (this.densityDpi != paramConfiguration.densityDpi)) {
      i |= 0x1000;
    }
    return i;
  }
  
  public boolean equals(Configuration paramConfiguration)
  {
    boolean bool = true;
    if (paramConfiguration == null) {
      bool = false;
    }
    while ((paramConfiguration == this) || (compareTo(paramConfiguration) == 0)) {
      return bool;
    }
    return false;
  }
  
  public boolean equals(Object paramObject)
  {
    try
    {
      boolean bool = equals((Configuration)paramObject);
      return bool;
    }
    catch (ClassCastException localClassCastException) {}
    return false;
  }
  
  public int getLayoutDirection()
  {
    return -1 + ((0xC0 & this.screenLayout) >> 6);
  }
  
  public int hashCode()
  {
    int i = 31 * (31 * (31 * (527 + Float.floatToIntBits(this.fontScale)) + this.mcc) + this.mnc);
    if (this.locale != null) {}
    for (int j = this.locale.hashCode();; j = 0) {
      return 31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (i + j) + this.touchscreen) + this.keyboard) + this.keyboardHidden) + this.hardKeyboardHidden) + this.navigation) + this.navigationHidden) + this.orientation) + this.screenLayout) + this.uiMode) + this.screenWidthDp) + this.screenHeightDp) + this.smallestScreenWidthDp) + this.densityDpi;
    }
  }
  
  public boolean isLayoutSizeAtLeast(int paramInt)
  {
    int i = 0xF & this.screenLayout;
    if (i == 0) {}
    while (i < paramInt) {
      return false;
    }
    return true;
  }
  
  public boolean isOtherSeqNewer(Configuration paramConfiguration)
  {
    boolean bool = true;
    if (paramConfiguration == null) {
      bool = false;
    }
    int i;
    do
    {
      do
      {
        return bool;
      } while ((paramConfiguration.seq == 0) || (this.seq == 0));
      i = paramConfiguration.seq - this.seq;
      if (i > 65536) {
        return false;
      }
    } while (i > 0);
    return false;
  }
  
  @Deprecated
  public void makeDefault()
  {
    setToDefaults();
  }
  
  public void readFromParcel(Parcel paramParcel)
  {
    int i = 1;
    this.fontScale = paramParcel.readFloat();
    this.mcc = paramParcel.readInt();
    this.mnc = paramParcel.readInt();
    if (paramParcel.readInt() != 0) {
      this.locale = new Locale(paramParcel.readString(), paramParcel.readString(), paramParcel.readString());
    }
    if (paramParcel.readInt() == i) {}
    for (;;)
    {
      this.userSetLocale = i;
      this.touchscreen = paramParcel.readInt();
      this.keyboard = paramParcel.readInt();
      this.keyboardHidden = paramParcel.readInt();
      this.hardKeyboardHidden = paramParcel.readInt();
      this.navigation = paramParcel.readInt();
      this.navigationHidden = paramParcel.readInt();
      this.orientation = paramParcel.readInt();
      this.screenLayout = paramParcel.readInt();
      this.uiMode = paramParcel.readInt();
      this.screenWidthDp = paramParcel.readInt();
      this.screenHeightDp = paramParcel.readInt();
      this.smallestScreenWidthDp = paramParcel.readInt();
      this.densityDpi = paramParcel.readInt();
      this.compatScreenWidthDp = paramParcel.readInt();
      this.compatScreenHeightDp = paramParcel.readInt();
      this.compatSmallestScreenWidthDp = paramParcel.readInt();
      this.seq = paramParcel.readInt();
      return;
      i = 0;
    }
  }
  
  public void setLayoutDirection(Locale paramLocale)
  {
    int i = 1 + TextUtils.getLayoutDirectionFromLocale(paramLocale);
    this.screenLayout = (0xFF3F & this.screenLayout | i << 6);
  }
  
  public void setLocale(Locale paramLocale)
  {
    this.locale = paramLocale;
    this.userSetLocale = true;
    setLayoutDirection(this.locale);
  }
  
  public void setTo(Configuration paramConfiguration)
  {
    this.fontScale = paramConfiguration.fontScale;
    this.mcc = paramConfiguration.mcc;
    this.mnc = paramConfiguration.mnc;
    if (paramConfiguration.locale != null) {
      this.locale = ((Locale)paramConfiguration.locale.clone());
    }
    this.userSetLocale = paramConfiguration.userSetLocale;
    this.touchscreen = paramConfiguration.touchscreen;
    this.keyboard = paramConfiguration.keyboard;
    this.keyboardHidden = paramConfiguration.keyboardHidden;
    this.hardKeyboardHidden = paramConfiguration.hardKeyboardHidden;
    this.navigation = paramConfiguration.navigation;
    this.navigationHidden = paramConfiguration.navigationHidden;
    this.orientation = paramConfiguration.orientation;
    this.screenLayout = paramConfiguration.screenLayout;
    this.uiMode = paramConfiguration.uiMode;
    this.screenWidthDp = paramConfiguration.screenWidthDp;
    this.screenHeightDp = paramConfiguration.screenHeightDp;
    this.smallestScreenWidthDp = paramConfiguration.smallestScreenWidthDp;
    this.densityDpi = paramConfiguration.densityDpi;
    this.compatScreenWidthDp = paramConfiguration.compatScreenWidthDp;
    this.compatScreenHeightDp = paramConfiguration.compatScreenHeightDp;
    this.compatSmallestScreenWidthDp = paramConfiguration.compatSmallestScreenWidthDp;
    this.seq = paramConfiguration.seq;
  }
  
  public void setToDefaults()
  {
    this.fontScale = 1.0F;
    this.mnc = 0;
    this.mcc = 0;
    this.locale = null;
    this.userSetLocale = false;
    this.touchscreen = 0;
    this.keyboard = 0;
    this.keyboardHidden = 0;
    this.hardKeyboardHidden = 0;
    this.navigation = 0;
    this.navigationHidden = 0;
    this.orientation = 0;
    this.screenLayout = 0;
    this.uiMode = 0;
    this.compatScreenWidthDp = 0;
    this.screenWidthDp = 0;
    this.compatScreenHeightDp = 0;
    this.screenHeightDp = 0;
    this.compatSmallestScreenWidthDp = 0;
    this.smallestScreenWidthDp = 0;
    this.densityDpi = 0;
    this.seq = 0;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(128);
    localStringBuilder.append("{");
    localStringBuilder.append(this.fontScale);
    localStringBuilder.append(" ");
    if (this.mcc != 0)
    {
      localStringBuilder.append(this.mcc);
      localStringBuilder.append("mcc");
      if (this.mnc == 0) {
        break label956;
      }
      localStringBuilder.append(this.mnc);
      localStringBuilder.append("mnc");
      label84:
      if (this.locale == null) {
        break label967;
      }
      localStringBuilder.append(" ");
      localStringBuilder.append(this.locale);
      label108:
      int i = 0xC0 & this.screenLayout;
      switch (i)
      {
      default: 
        localStringBuilder.append(" layoutDir=");
        localStringBuilder.append(i >> 6);
        label174:
        if (this.smallestScreenWidthDp != 0)
        {
          localStringBuilder.append(" sw");
          localStringBuilder.append(this.smallestScreenWidthDp);
          localStringBuilder.append("dp");
          label206:
          if (this.screenWidthDp == 0) {
            break label1022;
          }
          localStringBuilder.append(" w");
          localStringBuilder.append(this.screenWidthDp);
          localStringBuilder.append("dp");
          label238:
          if (this.screenHeightDp == 0) {
            break label1033;
          }
          localStringBuilder.append(" h");
          localStringBuilder.append(this.screenHeightDp);
          localStringBuilder.append("dp");
          label270:
          if (this.densityDpi == 0) {
            break label1044;
          }
          localStringBuilder.append(" ");
          localStringBuilder.append(this.densityDpi);
          localStringBuilder.append("dpi");
          label302:
          switch (0xF & this.screenLayout)
          {
          default: 
            localStringBuilder.append(" layoutSize=");
            localStringBuilder.append(0xF & this.screenLayout);
            label364:
            switch (0x30 & this.screenLayout)
            {
            default: 
              localStringBuilder.append(" layoutLong=");
              localStringBuilder.append(0x30 & this.screenLayout);
            case 16: 
              label424:
              switch (this.orientation)
              {
              default: 
                localStringBuilder.append(" orien=");
                localStringBuilder.append(this.orientation);
                label473:
                switch (0xF & this.uiMode)
                {
                default: 
                  localStringBuilder.append(" uimode=");
                  localStringBuilder.append(0xF & this.uiMode);
                case 1: 
                  label540:
                  switch (0x30 & this.uiMode)
                  {
                  default: 
                    localStringBuilder.append(" night=");
                    localStringBuilder.append(0x30 & this.uiMode);
                  case 16: 
                    label600:
                    switch (this.touchscreen)
                    {
                    default: 
                      localStringBuilder.append(" touch=");
                      localStringBuilder.append(this.touchscreen);
                      label653:
                      switch (this.keyboard)
                      {
                      default: 
                        localStringBuilder.append(" keys=");
                        localStringBuilder.append(this.keyboard);
                        label705:
                        switch (this.keyboardHidden)
                        {
                        default: 
                          localStringBuilder.append("/");
                          localStringBuilder.append(this.keyboardHidden);
                          label757:
                          switch (this.hardKeyboardHidden)
                          {
                          default: 
                            localStringBuilder.append("/");
                            localStringBuilder.append(this.hardKeyboardHidden);
                            label805:
                            switch (this.navigation)
                            {
                            default: 
                              localStringBuilder.append(" nav=");
                              localStringBuilder.append(this.navigation);
                              label861:
                              switch (this.navigationHidden)
                              {
                              default: 
                                localStringBuilder.append("/");
                                localStringBuilder.append(this.navigationHidden);
                              }
                              break;
                            }
                            break;
                          }
                          break;
                        }
                        break;
                      }
                      break;
                    }
                    break;
                  }
                  break;
                }
                break;
              }
              break;
            }
            break;
          }
        }
        break;
      }
    }
    for (;;)
    {
      if (this.seq != 0)
      {
        localStringBuilder.append(" s.");
        localStringBuilder.append(this.seq);
      }
      localStringBuilder.append('}');
      return localStringBuilder.toString();
      localStringBuilder.append("?mcc");
      break;
      label956:
      localStringBuilder.append("?mnc");
      break label84;
      label967:
      localStringBuilder.append(" ?locale");
      break label108;
      localStringBuilder.append(" ?layoutDir");
      break label174;
      localStringBuilder.append(" ldltr");
      break label174;
      localStringBuilder.append(" ldrtl");
      break label174;
      localStringBuilder.append(" ?swdp");
      break label206;
      label1022:
      localStringBuilder.append(" ?wdp");
      break label238;
      label1033:
      localStringBuilder.append(" ?hdp");
      break label270;
      label1044:
      localStringBuilder.append(" ?density");
      break label302;
      localStringBuilder.append(" ?lsize");
      break label364;
      localStringBuilder.append(" smll");
      break label364;
      localStringBuilder.append(" nrml");
      break label364;
      localStringBuilder.append(" lrg");
      break label364;
      localStringBuilder.append(" xlrg");
      break label364;
      localStringBuilder.append(" ?long");
      break label424;
      localStringBuilder.append(" long");
      break label424;
      localStringBuilder.append(" ?orien");
      break label473;
      localStringBuilder.append(" land");
      break label473;
      localStringBuilder.append(" port");
      break label473;
      localStringBuilder.append(" ?uimode");
      break label540;
      localStringBuilder.append(" desk");
      break label540;
      localStringBuilder.append(" car");
      break label540;
      localStringBuilder.append(" television");
      break label540;
      localStringBuilder.append(" appliance");
      break label540;
      localStringBuilder.append(" ?night");
      break label600;
      localStringBuilder.append(" night");
      break label600;
      localStringBuilder.append(" ?touch");
      break label653;
      localStringBuilder.append(" -touch");
      break label653;
      localStringBuilder.append(" stylus");
      break label653;
      localStringBuilder.append(" finger");
      break label653;
      localStringBuilder.append(" ?keyb");
      break label705;
      localStringBuilder.append(" -keyb");
      break label705;
      localStringBuilder.append(" qwerty");
      break label705;
      localStringBuilder.append(" 12key");
      break label705;
      localStringBuilder.append("/?");
      break label757;
      localStringBuilder.append("/v");
      break label757;
      localStringBuilder.append("/h");
      break label757;
      localStringBuilder.append("/s");
      break label757;
      localStringBuilder.append("/?");
      break label805;
      localStringBuilder.append("/v");
      break label805;
      localStringBuilder.append("/h");
      break label805;
      localStringBuilder.append(" ?nav");
      break label861;
      localStringBuilder.append(" -nav");
      break label861;
      localStringBuilder.append(" dpad");
      break label861;
      localStringBuilder.append(" tball");
      break label861;
      localStringBuilder.append(" wheel");
      break label861;
      localStringBuilder.append("/?");
      continue;
      localStringBuilder.append("/v");
      continue;
      localStringBuilder.append("/h");
    }
  }
  
  public int updateFrom(Configuration paramConfiguration)
  {
    boolean bool1 = paramConfiguration.fontScale < 0.0F;
    int i = 0;
    if (bool1)
    {
      boolean bool2 = this.fontScale < paramConfiguration.fontScale;
      i = 0;
      if (bool2)
      {
        i = 0x0 | 0x40000000;
        this.fontScale = paramConfiguration.fontScale;
      }
    }
    if ((paramConfiguration.mcc != 0) && (this.mcc != paramConfiguration.mcc))
    {
      i |= 0x1;
      this.mcc = paramConfiguration.mcc;
    }
    if ((paramConfiguration.mnc != 0) && (this.mnc != paramConfiguration.mnc))
    {
      i |= 0x2;
      this.mnc = paramConfiguration.mnc;
    }
    Locale localLocale;
    if ((paramConfiguration.locale != null) && ((this.locale == null) || (!this.locale.equals(paramConfiguration.locale))))
    {
      int j = i | 0x4;
      if (paramConfiguration.locale != null)
      {
        localLocale = (Locale)paramConfiguration.locale.clone();
        this.locale = localLocale;
        i = j | 0x2000;
        setLayoutDirection(this.locale);
      }
    }
    else
    {
      if ((paramConfiguration.userSetLocale) && ((!this.userSetLocale) || ((i & 0x4) != 0)))
      {
        this.userSetLocale = true;
        i |= 0x4;
      }
      if ((paramConfiguration.touchscreen != 0) && (this.touchscreen != paramConfiguration.touchscreen))
      {
        i |= 0x8;
        this.touchscreen = paramConfiguration.touchscreen;
      }
      if ((paramConfiguration.keyboard != 0) && (this.keyboard != paramConfiguration.keyboard))
      {
        i |= 0x10;
        this.keyboard = paramConfiguration.keyboard;
      }
      if ((paramConfiguration.keyboardHidden != 0) && (this.keyboardHidden != paramConfiguration.keyboardHidden))
      {
        i |= 0x20;
        this.keyboardHidden = paramConfiguration.keyboardHidden;
      }
      if ((paramConfiguration.hardKeyboardHidden != 0) && (this.hardKeyboardHidden != paramConfiguration.hardKeyboardHidden))
      {
        i |= 0x20;
        this.hardKeyboardHidden = paramConfiguration.hardKeyboardHidden;
      }
      if ((paramConfiguration.navigation != 0) && (this.navigation != paramConfiguration.navigation))
      {
        i |= 0x40;
        this.navigation = paramConfiguration.navigation;
      }
      if ((paramConfiguration.navigationHidden != 0) && (this.navigationHidden != paramConfiguration.navigationHidden))
      {
        i |= 0x20;
        this.navigationHidden = paramConfiguration.navigationHidden;
      }
      if ((paramConfiguration.orientation != 0) && (this.orientation != paramConfiguration.orientation))
      {
        i |= 0x80;
        this.orientation = paramConfiguration.orientation;
      }
      if ((getScreenLayoutNoDirection(paramConfiguration.screenLayout) != 0) && (getScreenLayoutNoDirection(this.screenLayout) != getScreenLayoutNoDirection(paramConfiguration.screenLayout)))
      {
        i |= 0x100;
        if ((0xC0 & paramConfiguration.screenLayout) != 0) {
          break label741;
        }
      }
    }
    label741:
    for (this.screenLayout = (0xC0 & this.screenLayout | paramConfiguration.screenLayout);; this.screenLayout = paramConfiguration.screenLayout)
    {
      if ((paramConfiguration.uiMode != 0) && (this.uiMode != paramConfiguration.uiMode))
      {
        i |= 0x200;
        if ((0xF & paramConfiguration.uiMode) != 0) {
          this.uiMode = (0xFFFFFFF0 & this.uiMode | 0xF & paramConfiguration.uiMode);
        }
        if ((0x30 & paramConfiguration.uiMode) != 0) {
          this.uiMode = (0xFFFFFFCF & this.uiMode | 0x30 & paramConfiguration.uiMode);
        }
      }
      if ((paramConfiguration.screenWidthDp != 0) && (this.screenWidthDp != paramConfiguration.screenWidthDp))
      {
        i |= 0x400;
        this.screenWidthDp = paramConfiguration.screenWidthDp;
      }
      if ((paramConfiguration.screenHeightDp != 0) && (this.screenHeightDp != paramConfiguration.screenHeightDp))
      {
        i |= 0x400;
        this.screenHeightDp = paramConfiguration.screenHeightDp;
      }
      if (paramConfiguration.smallestScreenWidthDp != 0)
      {
        i |= 0x400;
        this.smallestScreenWidthDp = paramConfiguration.smallestScreenWidthDp;
      }
      if (paramConfiguration.densityDpi != 0)
      {
        i |= 0x1000;
        this.densityDpi = paramConfiguration.densityDpi;
      }
      if (paramConfiguration.compatScreenWidthDp != 0) {
        this.compatScreenWidthDp = paramConfiguration.compatScreenWidthDp;
      }
      if (paramConfiguration.compatScreenHeightDp != 0) {
        this.compatScreenHeightDp = paramConfiguration.compatScreenHeightDp;
      }
      if (paramConfiguration.compatSmallestScreenWidthDp != 0) {
        this.compatSmallestScreenWidthDp = paramConfiguration.compatSmallestScreenWidthDp;
      }
      if (paramConfiguration.seq != 0) {
        this.seq = paramConfiguration.seq;
      }
      return i;
      localLocale = null;
      break;
    }
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeFloat(this.fontScale);
    paramParcel.writeInt(this.mcc);
    paramParcel.writeInt(this.mnc);
    if (this.locale == null)
    {
      paramParcel.writeInt(0);
      if (!this.userSetLocale) {
        break label226;
      }
      paramParcel.writeInt(1);
    }
    for (;;)
    {
      paramParcel.writeInt(this.touchscreen);
      paramParcel.writeInt(this.keyboard);
      paramParcel.writeInt(this.keyboardHidden);
      paramParcel.writeInt(this.hardKeyboardHidden);
      paramParcel.writeInt(this.navigation);
      paramParcel.writeInt(this.navigationHidden);
      paramParcel.writeInt(this.orientation);
      paramParcel.writeInt(this.screenLayout);
      paramParcel.writeInt(this.uiMode);
      paramParcel.writeInt(this.screenWidthDp);
      paramParcel.writeInt(this.screenHeightDp);
      paramParcel.writeInt(this.smallestScreenWidthDp);
      paramParcel.writeInt(this.densityDpi);
      paramParcel.writeInt(this.compatScreenWidthDp);
      paramParcel.writeInt(this.compatScreenHeightDp);
      paramParcel.writeInt(this.compatSmallestScreenWidthDp);
      paramParcel.writeInt(this.seq);
      return;
      paramParcel.writeInt(1);
      paramParcel.writeString(this.locale.getLanguage());
      paramParcel.writeString(this.locale.getCountry());
      paramParcel.writeString(this.locale.getVariant());
      break;
      label226:
      paramParcel.writeInt(0);
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\res\Configuration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
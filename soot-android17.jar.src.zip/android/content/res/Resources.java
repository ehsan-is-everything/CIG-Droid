package android.content.res;

import android.graphics.Movie;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.LongSparseArray;
import android.util.TypedValue;
import com.android.internal.R.styleable;
import com.android.internal.util.XmlUtils;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import libcore.icu.NativePluralRules;
import org.xmlpull.v1.XmlPullParserException;

public class Resources
{
  private static final boolean DEBUG_ATTRIBUTES_CACHE = false;
  private static final boolean DEBUG_CONFIG = false;
  private static final boolean DEBUG_LOAD = false;
  private static final int ID_OTHER = 16777220;
  static final String TAG = "Resources";
  private static final boolean TRACE_FOR_MISS_PRELOAD;
  private static final boolean TRACE_FOR_PRELOAD;
  private static final Object mSync = new Object();
  static Resources mSystem = null;
  private static boolean sPreloaded;
  private static final LongSparseArray<Drawable.ConstantState> sPreloadedColorDrawables = new LongSparseArray();
  private static final LongSparseArray<ColorStateList> sPreloadedColorStateLists;
  private static int sPreloadedDensity;
  private static final LongSparseArray<Drawable.ConstantState> sPreloadedDrawables = new LongSparseArray();
  final AssetManager mAssets;
  TypedArray mCachedStyledAttributes = null;
  private final int[] mCachedXmlBlockIds = { 0, 0, 0, 0 };
  private final XmlBlock[] mCachedXmlBlocks = new XmlBlock[4];
  private final LongSparseArray<WeakReference<Drawable.ConstantState>> mColorDrawableCache = new LongSparseArray();
  private final LongSparseArray<WeakReference<ColorStateList>> mColorStateListCache = new LongSparseArray();
  private CompatibilityInfo mCompatibilityInfo;
  private final Configuration mConfiguration = new Configuration();
  private final LongSparseArray<WeakReference<Drawable.ConstantState>> mDrawableCache = new LongSparseArray();
  private int mLastCachedXmlBlockIndex = -1;
  RuntimeException mLastRetrievedAttrs = null;
  final DisplayMetrics mMetrics = new DisplayMetrics();
  private NativePluralRules mPluralRule;
  private boolean mPreloading;
  final Configuration mTmpConfig = new Configuration();
  final TypedValue mTmpValue = new TypedValue();
  
  static
  {
    sPreloadedColorStateLists = new LongSparseArray();
  }
  
  private Resources()
  {
    this.mAssets = AssetManager.getSystem();
    this.mConfiguration.setToDefaults();
    this.mMetrics.setToDefaults();
    updateConfiguration(null, null);
    this.mAssets.ensureStringBlocks();
    this.mCompatibilityInfo = CompatibilityInfo.DEFAULT_COMPATIBILITY_INFO;
  }
  
  public Resources(AssetManager paramAssetManager, DisplayMetrics paramDisplayMetrics, Configuration paramConfiguration)
  {
    this(paramAssetManager, paramDisplayMetrics, paramConfiguration, null);
  }
  
  public Resources(AssetManager paramAssetManager, DisplayMetrics paramDisplayMetrics, Configuration paramConfiguration, CompatibilityInfo paramCompatibilityInfo)
  {
    this.mAssets = paramAssetManager;
    this.mMetrics.setToDefaults();
    this.mCompatibilityInfo = paramCompatibilityInfo;
    updateConfiguration(paramConfiguration, paramDisplayMetrics);
    paramAssetManager.ensureStringBlocks();
  }
  
  private static int attrForQuantityCode(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return 16777220;
    case 0: 
      return 16777221;
    case 1: 
      return 16777222;
    case 2: 
      return 16777223;
    case 3: 
      return 16777224;
    }
    return 16777225;
  }
  
  private void clearDrawableCache(LongSparseArray<WeakReference<Drawable.ConstantState>> paramLongSparseArray, int paramInt)
  {
    int i = paramLongSparseArray.size();
    for (int j = 0; j < i; j++)
    {
      WeakReference localWeakReference = (WeakReference)paramLongSparseArray.valueAt(j);
      if (localWeakReference != null)
      {
        Drawable.ConstantState localConstantState = (Drawable.ConstantState)localWeakReference.get();
        if ((localConstantState != null) && (Configuration.needNewResources(paramInt, localConstantState.getChangingConfigurations()))) {
          paramLongSparseArray.setValueAt(j, null);
        }
      }
    }
  }
  
  private ColorStateList getCachedColorStateList(long paramLong)
  {
    synchronized (this.mTmpValue)
    {
      WeakReference localWeakReference = (WeakReference)this.mColorStateListCache.get(paramLong);
      if (localWeakReference != null)
      {
        ColorStateList localColorStateList = (ColorStateList)localWeakReference.get();
        if (localColorStateList != null) {
          return localColorStateList;
        }
        this.mColorStateListCache.delete(paramLong);
      }
      return null;
    }
  }
  
  private Drawable getCachedDrawable(LongSparseArray<WeakReference<Drawable.ConstantState>> paramLongSparseArray, long paramLong)
  {
    synchronized (this.mTmpValue)
    {
      WeakReference localWeakReference = (WeakReference)paramLongSparseArray.get(paramLong);
      if (localWeakReference != null)
      {
        Drawable.ConstantState localConstantState = (Drawable.ConstantState)localWeakReference.get();
        if (localConstantState != null)
        {
          Drawable localDrawable = localConstantState.newDrawable(this);
          return localDrawable;
        }
        paramLongSparseArray.delete(paramLong);
      }
      return null;
    }
  }
  
  private TypedArray getCachedStyledAttributes(int paramInt)
  {
    synchronized (this.mTmpValue)
    {
      TypedArray localTypedArray1 = this.mCachedStyledAttributes;
      if (localTypedArray1 != null)
      {
        this.mCachedStyledAttributes = null;
        localTypedArray1.mLength = paramInt;
        int i = paramInt * 6;
        if (localTypedArray1.mData.length >= i) {
          return localTypedArray1;
        }
        localTypedArray1.mData = new int[i];
        localTypedArray1.mIndices = new int[paramInt + 1];
        return localTypedArray1;
      }
    }
    TypedArray localTypedArray2 = new TypedArray(this, new int[paramInt * 6], new int[paramInt + 1], paramInt);
    return localTypedArray2;
  }
  
  private NativePluralRules getPluralRule()
  {
    synchronized (mSync)
    {
      if (this.mPluralRule == null) {
        this.mPluralRule = NativePluralRules.forLocale(this.mConfiguration.locale);
      }
      NativePluralRules localNativePluralRules = this.mPluralRule;
      return localNativePluralRules;
    }
  }
  
  public static Resources getSystem()
  {
    synchronized (mSync)
    {
      Resources localResources = mSystem;
      if (localResources == null)
      {
        localResources = new Resources();
        mSystem = localResources;
      }
      return localResources;
    }
  }
  
  public static int selectDefaultTheme(int paramInt1, int paramInt2)
  {
    return selectSystemTheme(paramInt1, paramInt2, 16973829, 16973931, 16974120);
  }
  
  public static int selectSystemTheme(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    if (paramInt1 != 0) {
      return paramInt1;
    }
    if (paramInt2 < 11) {
      return paramInt3;
    }
    if (paramInt2 < 14) {
      return paramInt4;
    }
    return paramInt5;
  }
  
  private static String stringForQuantityCode(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return "other";
    case 0: 
      return "zero";
    case 1: 
      return "one";
    case 2: 
      return "two";
    case 3: 
      return "few";
    }
    return "many";
  }
  
  public static void updateSystemConfiguration(Configuration paramConfiguration, DisplayMetrics paramDisplayMetrics)
  {
    updateSystemConfiguration(paramConfiguration, paramDisplayMetrics, null);
  }
  
  public static void updateSystemConfiguration(Configuration paramConfiguration, DisplayMetrics paramDisplayMetrics, CompatibilityInfo paramCompatibilityInfo)
  {
    if (mSystem != null) {
      mSystem.updateConfiguration(paramConfiguration, paramDisplayMetrics, paramCompatibilityInfo);
    }
  }
  
  private boolean verifyPreloadConfig(TypedValue paramTypedValue, String paramString)
  {
    if ((0xBFFFEFFF & paramTypedValue.changingConfigurations) != 0)
    {
      try
      {
        String str2 = getResourceName(paramTypedValue.resourceId);
        str1 = str2;
      }
      catch (NotFoundException localNotFoundException)
      {
        for (;;)
        {
          String str1 = "?";
        }
      }
      Log.w("Resources", "Preloaded " + paramString + " resource #0x" + Integer.toHexString(paramTypedValue.resourceId) + " (" + str1 + ") that varies with configuration!!");
      return false;
    }
    return true;
  }
  
  public final void finishPreloading()
  {
    if (this.mPreloading)
    {
      this.mPreloading = false;
      flushLayoutCache();
    }
  }
  
  public final void flushLayoutCache()
  {
    synchronized (this.mCachedXmlBlockIds)
    {
      int i = this.mCachedXmlBlockIds.length;
      for (int j = 0; j < i; j++)
      {
        this.mCachedXmlBlockIds[j] = 0;
        XmlBlock localXmlBlock = this.mCachedXmlBlocks[j];
        if (localXmlBlock != null) {
          localXmlBlock.close();
        }
        this.mCachedXmlBlocks[j] = null;
      }
      return;
    }
  }
  
  public XmlResourceParser getAnimation(int paramInt)
    throws Resources.NotFoundException
  {
    return loadXmlResourceParser(paramInt, "anim");
  }
  
  public final AssetManager getAssets()
  {
    return this.mAssets;
  }
  
  public boolean getBoolean(int paramInt)
    throws Resources.NotFoundException
  {
    for (boolean bool = true;; bool = false) {
      synchronized (this.mTmpValue)
      {
        TypedValue localTypedValue2 = this.mTmpValue;
        getValue(paramInt, localTypedValue2, true);
        if ((localTypedValue2.type >= 16) && (localTypedValue2.type <= 31))
        {
          if (localTypedValue2.data != 0) {
            return bool;
          }
        }
        else {
          throw new NotFoundException("Resource ID #0x" + Integer.toHexString(paramInt) + " type #0x" + Integer.toHexString(localTypedValue2.type) + " is not valid");
        }
      }
    }
  }
  
  public int getColor(int paramInt)
    throws Resources.NotFoundException
  {
    TypedValue localTypedValue2;
    synchronized (this.mTmpValue)
    {
      localTypedValue2 = this.mTmpValue;
      getValue(paramInt, localTypedValue2, true);
      if ((localTypedValue2.type >= 16) && (localTypedValue2.type <= 31))
      {
        int j = localTypedValue2.data;
        return j;
      }
      if (localTypedValue2.type == 3)
      {
        int i = loadColorStateList(this.mTmpValue, paramInt).getDefaultColor();
        return i;
      }
    }
    throw new NotFoundException("Resource ID #0x" + Integer.toHexString(paramInt) + " type #0x" + Integer.toHexString(localTypedValue2.type) + " is not valid");
  }
  
  public ColorStateList getColorStateList(int paramInt)
    throws Resources.NotFoundException
  {
    synchronized (this.mTmpValue)
    {
      TypedValue localTypedValue2 = this.mTmpValue;
      getValue(paramInt, localTypedValue2, true);
      ColorStateList localColorStateList = loadColorStateList(localTypedValue2, paramInt);
      return localColorStateList;
    }
  }
  
  public CompatibilityInfo getCompatibilityInfo()
  {
    if (this.mCompatibilityInfo != null) {
      return this.mCompatibilityInfo;
    }
    return CompatibilityInfo.DEFAULT_COMPATIBILITY_INFO;
  }
  
  public Configuration getConfiguration()
  {
    return this.mConfiguration;
  }
  
  public float getDimension(int paramInt)
    throws Resources.NotFoundException
  {
    synchronized (this.mTmpValue)
    {
      TypedValue localTypedValue2 = this.mTmpValue;
      getValue(paramInt, localTypedValue2, true);
      if (localTypedValue2.type == 5)
      {
        float f = TypedValue.complexToDimension(localTypedValue2.data, this.mMetrics);
        return f;
      }
      throw new NotFoundException("Resource ID #0x" + Integer.toHexString(paramInt) + " type #0x" + Integer.toHexString(localTypedValue2.type) + " is not valid");
    }
  }
  
  public int getDimensionPixelOffset(int paramInt)
    throws Resources.NotFoundException
  {
    synchronized (this.mTmpValue)
    {
      TypedValue localTypedValue2 = this.mTmpValue;
      getValue(paramInt, localTypedValue2, true);
      if (localTypedValue2.type == 5)
      {
        int i = TypedValue.complexToDimensionPixelOffset(localTypedValue2.data, this.mMetrics);
        return i;
      }
      throw new NotFoundException("Resource ID #0x" + Integer.toHexString(paramInt) + " type #0x" + Integer.toHexString(localTypedValue2.type) + " is not valid");
    }
  }
  
  public int getDimensionPixelSize(int paramInt)
    throws Resources.NotFoundException
  {
    synchronized (this.mTmpValue)
    {
      TypedValue localTypedValue2 = this.mTmpValue;
      getValue(paramInt, localTypedValue2, true);
      if (localTypedValue2.type == 5)
      {
        int i = TypedValue.complexToDimensionPixelSize(localTypedValue2.data, this.mMetrics);
        return i;
      }
      throw new NotFoundException("Resource ID #0x" + Integer.toHexString(paramInt) + " type #0x" + Integer.toHexString(localTypedValue2.type) + " is not valid");
    }
  }
  
  public DisplayMetrics getDisplayMetrics()
  {
    return this.mMetrics;
  }
  
  public Drawable getDrawable(int paramInt)
    throws Resources.NotFoundException
  {
    synchronized (this.mTmpValue)
    {
      TypedValue localTypedValue2 = this.mTmpValue;
      getValue(paramInt, localTypedValue2, true);
      Drawable localDrawable = loadDrawable(localTypedValue2, paramInt);
      return localDrawable;
    }
  }
  
  public Drawable getDrawableForDensity(int paramInt1, int paramInt2)
    throws Resources.NotFoundException
  {
    synchronized (this.mTmpValue)
    {
      TypedValue localTypedValue2 = this.mTmpValue;
      getValueForDensity(paramInt1, paramInt2, localTypedValue2, true);
      if ((localTypedValue2.density > 0) && (localTypedValue2.density != 65535))
      {
        if (localTypedValue2.density == paramInt2) {
          localTypedValue2.density = this.mMetrics.densityDpi;
        }
      }
      else
      {
        Drawable localDrawable = loadDrawable(localTypedValue2, paramInt1);
        return localDrawable;
      }
      localTypedValue2.density = (localTypedValue2.density * this.mMetrics.densityDpi / paramInt2);
    }
  }
  
  public float getFraction(int paramInt1, int paramInt2, int paramInt3)
  {
    synchronized (this.mTmpValue)
    {
      TypedValue localTypedValue2 = this.mTmpValue;
      getValue(paramInt1, localTypedValue2, true);
      if (localTypedValue2.type == 6)
      {
        float f = TypedValue.complexToFraction(localTypedValue2.data, paramInt2, paramInt3);
        return f;
      }
      throw new NotFoundException("Resource ID #0x" + Integer.toHexString(paramInt1) + " type #0x" + Integer.toHexString(localTypedValue2.type) + " is not valid");
    }
  }
  
  public int getIdentifier(String paramString1, String paramString2, String paramString3)
  {
    try
    {
      int i = Integer.parseInt(paramString1);
      return i;
    }
    catch (Exception localException) {}
    return this.mAssets.getResourceIdentifier(paramString1, paramString2, paramString3);
  }
  
  public int[] getIntArray(int paramInt)
    throws Resources.NotFoundException
  {
    int[] arrayOfInt = this.mAssets.getArrayIntResource(paramInt);
    if (arrayOfInt != null) {
      return arrayOfInt;
    }
    throw new NotFoundException("Int array resource ID #0x" + Integer.toHexString(paramInt));
  }
  
  public int getInteger(int paramInt)
    throws Resources.NotFoundException
  {
    synchronized (this.mTmpValue)
    {
      TypedValue localTypedValue2 = this.mTmpValue;
      getValue(paramInt, localTypedValue2, true);
      if ((localTypedValue2.type >= 16) && (localTypedValue2.type <= 31))
      {
        int i = localTypedValue2.data;
        return i;
      }
      throw new NotFoundException("Resource ID #0x" + Integer.toHexString(paramInt) + " type #0x" + Integer.toHexString(localTypedValue2.type) + " is not valid");
    }
  }
  
  public XmlResourceParser getLayout(int paramInt)
    throws Resources.NotFoundException
  {
    return loadXmlResourceParser(paramInt, "layout");
  }
  
  public Movie getMovie(int paramInt)
    throws Resources.NotFoundException
  {
    InputStream localInputStream = openRawResource(paramInt);
    Movie localMovie = Movie.decodeStream(localInputStream);
    try
    {
      localInputStream.close();
      return localMovie;
    }
    catch (IOException localIOException) {}
    return localMovie;
  }
  
  public String getQuantityString(int paramInt1, int paramInt2)
    throws Resources.NotFoundException
  {
    return getQuantityText(paramInt1, paramInt2).toString();
  }
  
  public String getQuantityString(int paramInt1, int paramInt2, Object... paramVarArgs)
    throws Resources.NotFoundException
  {
    String str = getQuantityText(paramInt1, paramInt2).toString();
    return String.format(this.mConfiguration.locale, str, paramVarArgs);
  }
  
  public CharSequence getQuantityText(int paramInt1, int paramInt2)
    throws Resources.NotFoundException
  {
    NativePluralRules localNativePluralRules = getPluralRule();
    CharSequence localCharSequence1 = this.mAssets.getResourceBagText(paramInt1, attrForQuantityCode(localNativePluralRules.quantityForInt(paramInt2)));
    if (localCharSequence1 != null) {
      return localCharSequence1;
    }
    CharSequence localCharSequence2 = this.mAssets.getResourceBagText(paramInt1, 16777220);
    if (localCharSequence2 != null) {
      return localCharSequence2;
    }
    throw new NotFoundException("Plural resource ID #0x" + Integer.toHexString(paramInt1) + " quantity=" + paramInt2 + " item=" + stringForQuantityCode(localNativePluralRules.quantityForInt(paramInt2)));
  }
  
  public String getResourceEntryName(int paramInt)
    throws Resources.NotFoundException
  {
    String str = this.mAssets.getResourceEntryName(paramInt);
    if (str != null) {
      return str;
    }
    throw new NotFoundException("Unable to find resource ID #0x" + Integer.toHexString(paramInt));
  }
  
  public String getResourceName(int paramInt)
    throws Resources.NotFoundException
  {
    String str = this.mAssets.getResourceName(paramInt);
    if (str != null) {
      return str;
    }
    throw new NotFoundException("Unable to find resource ID #0x" + Integer.toHexString(paramInt));
  }
  
  public String getResourcePackageName(int paramInt)
    throws Resources.NotFoundException
  {
    String str = this.mAssets.getResourcePackageName(paramInt);
    if (str != null) {
      return str;
    }
    throw new NotFoundException("Unable to find resource ID #0x" + Integer.toHexString(paramInt));
  }
  
  public String getResourceTypeName(int paramInt)
    throws Resources.NotFoundException
  {
    String str = this.mAssets.getResourceTypeName(paramInt);
    if (str != null) {
      return str;
    }
    throw new NotFoundException("Unable to find resource ID #0x" + Integer.toHexString(paramInt));
  }
  
  public String getString(int paramInt)
    throws Resources.NotFoundException
  {
    CharSequence localCharSequence = getText(paramInt);
    if (localCharSequence != null) {
      return localCharSequence.toString();
    }
    throw new NotFoundException("String resource ID #0x" + Integer.toHexString(paramInt));
  }
  
  public String getString(int paramInt, Object... paramVarArgs)
    throws Resources.NotFoundException
  {
    String str = getString(paramInt);
    return String.format(this.mConfiguration.locale, str, paramVarArgs);
  }
  
  public String[] getStringArray(int paramInt)
    throws Resources.NotFoundException
  {
    String[] arrayOfString = this.mAssets.getResourceStringArray(paramInt);
    if (arrayOfString != null) {
      return arrayOfString;
    }
    throw new NotFoundException("String array resource ID #0x" + Integer.toHexString(paramInt));
  }
  
  public CharSequence getText(int paramInt)
    throws Resources.NotFoundException
  {
    CharSequence localCharSequence = this.mAssets.getResourceText(paramInt);
    if (localCharSequence != null) {
      return localCharSequence;
    }
    throw new NotFoundException("String resource ID #0x" + Integer.toHexString(paramInt));
  }
  
  public CharSequence getText(int paramInt, CharSequence paramCharSequence)
  {
    if (paramInt != 0) {}
    for (CharSequence localCharSequence = this.mAssets.getResourceText(paramInt); localCharSequence != null; localCharSequence = null) {
      return localCharSequence;
    }
    return paramCharSequence;
  }
  
  public CharSequence[] getTextArray(int paramInt)
    throws Resources.NotFoundException
  {
    CharSequence[] arrayOfCharSequence = this.mAssets.getResourceTextArray(paramInt);
    if (arrayOfCharSequence != null) {
      return arrayOfCharSequence;
    }
    throw new NotFoundException("Text array resource ID #0x" + Integer.toHexString(paramInt));
  }
  
  public void getValue(int paramInt, TypedValue paramTypedValue, boolean paramBoolean)
    throws Resources.NotFoundException
  {
    if (this.mAssets.getResourceValue(paramInt, 0, paramTypedValue, paramBoolean)) {
      return;
    }
    throw new NotFoundException("Resource ID #0x" + Integer.toHexString(paramInt));
  }
  
  public void getValue(String paramString, TypedValue paramTypedValue, boolean paramBoolean)
    throws Resources.NotFoundException
  {
    int i = getIdentifier(paramString, "string", null);
    if (i != 0)
    {
      getValue(i, paramTypedValue, paramBoolean);
      return;
    }
    throw new NotFoundException("String resource name " + paramString);
  }
  
  public void getValueForDensity(int paramInt1, int paramInt2, TypedValue paramTypedValue, boolean paramBoolean)
    throws Resources.NotFoundException
  {
    if (this.mAssets.getResourceValue(paramInt1, paramInt2, paramTypedValue, paramBoolean)) {
      return;
    }
    throw new NotFoundException("Resource ID #0x" + Integer.toHexString(paramInt1));
  }
  
  public XmlResourceParser getXml(int paramInt)
    throws Resources.NotFoundException
  {
    return loadXmlResourceParser(paramInt, "xml");
  }
  
  ColorStateList loadColorStateList(TypedValue paramTypedValue, int paramInt)
    throws Resources.NotFoundException
  {
    long l = paramTypedValue.assetCookie << 32 | paramTypedValue.data;
    if ((paramTypedValue.type >= 28) && (paramTypedValue.type <= 31))
    {
      ColorStateList localColorStateList4 = (ColorStateList)sPreloadedColorStateLists.get(l);
      if (localColorStateList4 != null) {
        return localColorStateList4;
      }
      ColorStateList localColorStateList5 = ColorStateList.valueOf(paramTypedValue.data);
      if ((this.mPreloading) && (verifyPreloadConfig(paramTypedValue, "color"))) {
        sPreloadedColorStateLists.put(l, localColorStateList5);
      }
      return localColorStateList5;
    }
    ColorStateList localColorStateList1 = getCachedColorStateList(l);
    if (localColorStateList1 != null) {
      return localColorStateList1;
    }
    ColorStateList localColorStateList2 = (ColorStateList)sPreloadedColorStateLists.get(l);
    if (localColorStateList2 != null) {
      return localColorStateList2;
    }
    if (paramTypedValue.string == null) {
      throw new NotFoundException("Resource is not a ColorStateList (color or path): " + paramTypedValue);
    }
    String str = paramTypedValue.string.toString();
    if (str.endsWith(".xml")) {}
    for (;;)
    {
      ColorStateList localColorStateList3;
      try
      {
        XmlResourceParser localXmlResourceParser = loadXmlResourceParser(str, paramInt, paramTypedValue.assetCookie, "colorstatelist");
        localColorStateList3 = ColorStateList.createFromXml(this, localXmlResourceParser);
        localXmlResourceParser.close();
        if (localColorStateList3 != null)
        {
          if (!this.mPreloading) {
            break label352;
          }
          if (verifyPreloadConfig(paramTypedValue, "color")) {
            sPreloadedColorStateLists.put(l, localColorStateList3);
          }
        }
        return localColorStateList3;
      }
      catch (Exception localException)
      {
        NotFoundException localNotFoundException = new NotFoundException("File " + str + " from color state list resource ID #0x" + Integer.toHexString(paramInt));
        localNotFoundException.initCause(localException);
        throw localNotFoundException;
      }
      throw new NotFoundException("File " + str + " from drawable resource ID #0x" + Integer.toHexString(paramInt) + ": .xml extension required");
      label352:
      synchronized (this.mTmpValue)
      {
        this.mColorStateListCache.put(l, new WeakReference(localColorStateList3));
      }
    }
  }
  
  Drawable loadDrawable(TypedValue paramTypedValue, int paramInt)
    throws Resources.NotFoundException
  {
    int i = paramTypedValue.type;
    int j = 0;
    if (i >= 28)
    {
      int k = paramTypedValue.type;
      j = 0;
      if (k <= 31) {
        j = 1;
      }
    }
    long l;
    if (j != 0)
    {
      l = paramTypedValue.data;
      if (j == 0) {
        break label93;
      }
    }
    Object localObject1;
    label93:
    for (LongSparseArray localLongSparseArray = this.mColorDrawableCache;; localLongSparseArray = this.mDrawableCache)
    {
      localObject1 = getCachedDrawable(localLongSparseArray, l);
      if (localObject1 == null) {
        break label102;
      }
      return (Drawable)localObject1;
      l = paramTypedValue.assetCookie << 32 | paramTypedValue.data;
      break;
    }
    label102:
    Drawable.ConstantState localConstantState1;
    label133:
    Drawable.ConstantState localConstantState2;
    if (j != 0)
    {
      localConstantState1 = (Drawable.ConstantState)sPreloadedColorDrawables.get(l);
      if (localConstantState1 == null) {
        break label230;
      }
      localObject1 = localConstantState1.newDrawable(this);
      if (localObject1 != null)
      {
        ((Drawable)localObject1).setChangingConfigurations(paramTypedValue.changingConfigurations);
        localConstantState2 = ((Drawable)localObject1).getConstantState();
        if (localConstantState2 != null)
        {
          if (!this.mPreloading) {
            break label503;
          }
          if (verifyPreloadConfig(paramTypedValue, "drawable"))
          {
            if (j == 0) {
              break label490;
            }
            sPreloadedColorDrawables.put(l, localConstantState2);
          }
        }
      }
    }
    for (;;)
    {
      return (Drawable)localObject1;
      if (sPreloadedDensity == this.mConfiguration.densityDpi)
      {
        localConstantState1 = (Drawable.ConstantState)sPreloadedDrawables.get(l);
        break;
      }
      localConstantState1 = null;
      break;
      label230:
      if (j != 0) {
        localObject1 = new ColorDrawable(paramTypedValue.data);
      }
      if (localObject1 != null) {
        break label133;
      }
      if (paramTypedValue.string == null) {
        throw new NotFoundException("Resource is not a Drawable (color or path): " + paramTypedValue);
      }
      String str = paramTypedValue.string.toString();
      if (str.endsWith(".xml")) {
        try
        {
          XmlResourceParser localXmlResourceParser = loadXmlResourceParser(str, paramInt, paramTypedValue.assetCookie, "drawable");
          localObject1 = Drawable.createFromXml(this, localXmlResourceParser);
          localXmlResourceParser.close();
        }
        catch (Exception localException2)
        {
          NotFoundException localNotFoundException2 = new NotFoundException("File " + str + " from drawable resource ID #0x" + Integer.toHexString(paramInt));
          localNotFoundException2.initCause(localException2);
          throw localNotFoundException2;
        }
      }
      try
      {
        InputStream localInputStream = this.mAssets.openNonAsset(paramTypedValue.assetCookie, str, 2);
        localObject1 = Drawable.createFromResourceStream(this, paramTypedValue, localInputStream, str, null);
        localInputStream.close();
      }
      catch (Exception localException1)
      {
        NotFoundException localNotFoundException1 = new NotFoundException("File " + str + " from drawable resource ID #0x" + Integer.toHexString(paramInt));
        localNotFoundException1.initCause(localException1);
        throw localNotFoundException1;
      }
      label490:
      sPreloadedDrawables.put(l, localConstantState2);
    }
    label503:
    TypedValue localTypedValue = this.mTmpValue;
    if (j != 0) {}
    for (;;)
    {
      try
      {
        this.mColorDrawableCache.put(l, new WeakReference(localConstantState2));
        break;
      }
      finally {}
      this.mDrawableCache.put(l, new WeakReference(localConstantState2));
    }
  }
  
  XmlResourceParser loadXmlResourceParser(int paramInt, String paramString)
    throws Resources.NotFoundException
  {
    synchronized (this.mTmpValue)
    {
      TypedValue localTypedValue2 = this.mTmpValue;
      getValue(paramInt, localTypedValue2, true);
      if (localTypedValue2.type == 3)
      {
        XmlResourceParser localXmlResourceParser = loadXmlResourceParser(localTypedValue2.string.toString(), paramInt, localTypedValue2.assetCookie, paramString);
        return localXmlResourceParser;
      }
      throw new NotFoundException("Resource ID #0x" + Integer.toHexString(paramInt) + " type #0x" + Integer.toHexString(localTypedValue2.type) + " is not valid");
    }
  }
  
  XmlResourceParser loadXmlResourceParser(String paramString1, int paramInt1, int paramInt2, String paramString2)
    throws Resources.NotFoundException
  {
    if (paramInt1 != 0) {}
    for (;;)
    {
      int j;
      try
      {
        synchronized (this.mCachedXmlBlockIds)
        {
          int i = this.mCachedXmlBlockIds.length;
          j = 0;
          if (j < i)
          {
            if (this.mCachedXmlBlockIds[j] != paramInt1) {
              break label277;
            }
            XmlResourceParser localXmlResourceParser1 = this.mCachedXmlBlocks[j].newParser();
            return localXmlResourceParser1;
          }
          XmlBlock localXmlBlock1 = this.mAssets.openXmlBlockAsset(paramInt2, paramString1);
          if (localXmlBlock1 != null)
          {
            int k = 1 + this.mLastCachedXmlBlockIndex;
            if (k >= i) {
              k = 0;
            }
            this.mLastCachedXmlBlockIndex = k;
            XmlBlock localXmlBlock2 = this.mCachedXmlBlocks[k];
            if (localXmlBlock2 != null) {
              localXmlBlock2.close();
            }
            this.mCachedXmlBlockIds[k] = paramInt1;
            this.mCachedXmlBlocks[k] = localXmlBlock1;
            XmlResourceParser localXmlResourceParser2 = localXmlBlock1.newParser();
            return localXmlResourceParser2;
          }
        }
      }
      catch (Exception localException)
      {
        NotFoundException localNotFoundException = new NotFoundException("File " + paramString1 + " from xml type " + paramString2 + " resource ID #0x" + Integer.toHexString(paramInt1));
        localNotFoundException.initCause(localException);
        throw localNotFoundException;
      }
      throw new NotFoundException("File " + paramString1 + " from xml type " + paramString2 + " resource ID #0x" + Integer.toHexString(paramInt1));
      label277:
      j++;
    }
  }
  
  public final Theme newTheme()
  {
    return new Theme();
  }
  
  public TypedArray obtainAttributes(AttributeSet paramAttributeSet, int[] paramArrayOfInt)
  {
    TypedArray localTypedArray = getCachedStyledAttributes(paramArrayOfInt.length);
    XmlBlock.Parser localParser = (XmlBlock.Parser)paramAttributeSet;
    this.mAssets.retrieveAttributes(localParser.mParseState, paramArrayOfInt, localTypedArray.mData, localTypedArray.mIndices);
    localTypedArray.mRsrcs = paramArrayOfInt;
    localTypedArray.mXml = localParser;
    return localTypedArray;
  }
  
  public TypedArray obtainTypedArray(int paramInt)
    throws Resources.NotFoundException
  {
    int i = this.mAssets.getArraySize(paramInt);
    if (i < 0) {
      throw new NotFoundException("Array resource ID #0x" + Integer.toHexString(paramInt));
    }
    TypedArray localTypedArray = getCachedStyledAttributes(i);
    localTypedArray.mLength = this.mAssets.retrieveArray(paramInt, localTypedArray.mData);
    localTypedArray.mIndices[0] = 0;
    return localTypedArray;
  }
  
  public InputStream openRawResource(int paramInt)
    throws Resources.NotFoundException
  {
    synchronized (this.mTmpValue)
    {
      InputStream localInputStream = openRawResource(paramInt, this.mTmpValue);
      return localInputStream;
    }
  }
  
  public InputStream openRawResource(int paramInt, TypedValue paramTypedValue)
    throws Resources.NotFoundException
  {
    getValue(paramInt, paramTypedValue, true);
    try
    {
      InputStream localInputStream = this.mAssets.openNonAsset(paramTypedValue.assetCookie, paramTypedValue.string.toString(), 2);
      return localInputStream;
    }
    catch (Exception localException)
    {
      NotFoundException localNotFoundException = new NotFoundException("File " + paramTypedValue.string.toString() + " from drawable resource ID #0x" + Integer.toHexString(paramInt));
      localNotFoundException.initCause(localException);
      throw localNotFoundException;
    }
  }
  
  public AssetFileDescriptor openRawResourceFd(int paramInt)
    throws Resources.NotFoundException
  {
    synchronized (this.mTmpValue)
    {
      TypedValue localTypedValue2 = this.mTmpValue;
      getValue(paramInt, localTypedValue2, true);
      try
      {
        AssetFileDescriptor localAssetFileDescriptor = this.mAssets.openNonAssetFd(localTypedValue2.assetCookie, localTypedValue2.string.toString());
        return localAssetFileDescriptor;
      }
      catch (Exception localException)
      {
        NotFoundException localNotFoundException = new NotFoundException("File " + localTypedValue2.string.toString() + " from drawable resource ID #0x" + Integer.toHexString(paramInt));
        localNotFoundException.initCause(localException);
        throw localNotFoundException;
      }
    }
  }
  
  public void parseBundleExtra(String paramString, AttributeSet paramAttributeSet, Bundle paramBundle)
    throws XmlPullParserException
  {
    int i = 1;
    TypedArray localTypedArray = obtainAttributes(paramAttributeSet, R.styleable.Extra);
    String str = localTypedArray.getString(0);
    if (str == null)
    {
      localTypedArray.recycle();
      throw new XmlPullParserException("<" + paramString + "> requires an android:name attribute at " + paramAttributeSet.getPositionDescription());
    }
    TypedValue localTypedValue = localTypedArray.peekValue(i);
    if (localTypedValue != null)
    {
      if (localTypedValue.type == 3) {
        paramBundle.putCharSequence(str, localTypedValue.coerceToString());
      }
      for (;;)
      {
        localTypedArray.recycle();
        return;
        if (localTypedValue.type == 18)
        {
          if (localTypedValue.data != 0) {}
          for (;;)
          {
            paramBundle.putBoolean(str, i);
            break;
            int j = 0;
          }
        }
        if ((localTypedValue.type >= 16) && (localTypedValue.type <= 31))
        {
          paramBundle.putInt(str, localTypedValue.data);
        }
        else
        {
          if (localTypedValue.type != 4) {
            break;
          }
          paramBundle.putFloat(str, localTypedValue.getFloat());
        }
      }
      localTypedArray.recycle();
      throw new XmlPullParserException("<" + paramString + "> only supports string, integer, float, color, and boolean at " + paramAttributeSet.getPositionDescription());
    }
    localTypedArray.recycle();
    throw new XmlPullParserException("<" + paramString + "> requires an android:value or android:resource attribute at " + paramAttributeSet.getPositionDescription());
  }
  
  public void parseBundleExtras(XmlResourceParser paramXmlResourceParser, Bundle paramBundle)
    throws XmlPullParserException, IOException
  {
    int i = paramXmlResourceParser.getDepth();
    for (;;)
    {
      int j = paramXmlResourceParser.next();
      if ((j == 1) || ((j == 3) && (paramXmlResourceParser.getDepth() <= i))) {
        break;
      }
      if ((j != 3) && (j != 4)) {
        if (paramXmlResourceParser.getName().equals("extra"))
        {
          parseBundleExtra("extra", paramXmlResourceParser, paramBundle);
          XmlUtils.skipCurrentTag(paramXmlResourceParser);
        }
        else
        {
          XmlUtils.skipCurrentTag(paramXmlResourceParser);
        }
      }
    }
  }
  
  public void setCompatibilityInfo(CompatibilityInfo paramCompatibilityInfo)
  {
    this.mCompatibilityInfo = paramCompatibilityInfo;
    updateConfiguration(this.mConfiguration, this.mMetrics);
  }
  
  public final void startPreloading()
  {
    synchronized (mSync)
    {
      if (sPreloaded) {
        throw new IllegalStateException("Resources already preloaded");
      }
    }
    sPreloaded = true;
    this.mPreloading = true;
    sPreloadedDensity = DisplayMetrics.DENSITY_DEVICE;
    this.mConfiguration.densityDpi = sPreloadedDensity;
    updateConfiguration(null, null);
  }
  
  public void updateConfiguration(Configuration paramConfiguration, DisplayMetrics paramDisplayMetrics)
  {
    updateConfiguration(paramConfiguration, paramDisplayMetrics, null);
  }
  
  /* Error */
  public void updateConfiguration(Configuration paramConfiguration, DisplayMetrics paramDisplayMetrics, CompatibilityInfo paramCompatibilityInfo)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 81	android/content/res/Resources:mTmpValue	Landroid/util/TypedValue;
    //   4: astore 4
    //   6: aload 4
    //   8: monitorenter
    //   9: aload_3
    //   10: ifnull +8 -> 18
    //   13: aload_0
    //   14: aload_3
    //   15: putfield 137	android/content/res/Resources:mCompatibilityInfo	Landroid/content/res/CompatibilityInfo;
    //   18: aload_2
    //   19: ifnull +11 -> 30
    //   22: aload_0
    //   23: getfield 111	android/content/res/Resources:mMetrics	Landroid/util/DisplayMetrics;
    //   26: aload_2
    //   27: invokevirtual 776	android/util/DisplayMetrics:setTo	(Landroid/util/DisplayMetrics;)V
    //   30: aload_0
    //   31: getfield 137	android/content/res/Resources:mCompatibilityInfo	Landroid/content/res/CompatibilityInfo;
    //   34: ifnull +14 -> 48
    //   37: aload_0
    //   38: getfield 137	android/content/res/Resources:mCompatibilityInfo	Landroid/content/res/CompatibilityInfo;
    //   41: aload_0
    //   42: getfield 111	android/content/res/Resources:mMetrics	Landroid/util/DisplayMetrics;
    //   45: invokevirtual 779	android/content/res/CompatibilityInfo:applyToDisplayMetrics	(Landroid/util/DisplayMetrics;)V
    //   48: ldc_w 780
    //   51: istore 6
    //   53: aload_1
    //   54: ifnull +109 -> 163
    //   57: aload_0
    //   58: getfield 86	android/content/res/Resources:mTmpConfig	Landroid/content/res/Configuration;
    //   61: aload_1
    //   62: invokevirtual 783	android/content/res/Configuration:setTo	(Landroid/content/res/Configuration;)V
    //   65: aload_1
    //   66: getfield 602	android/content/res/Configuration:densityDpi	I
    //   69: istore 7
    //   71: iload 7
    //   73: ifne +12 -> 85
    //   76: aload_0
    //   77: getfield 111	android/content/res/Resources:mMetrics	Landroid/util/DisplayMetrics;
    //   80: getfield 786	android/util/DisplayMetrics:noncompatDensityDpi	I
    //   83: istore 7
    //   85: aload_0
    //   86: getfield 137	android/content/res/Resources:mCompatibilityInfo	Landroid/content/res/CompatibilityInfo;
    //   89: ifnull +24 -> 113
    //   92: aload_0
    //   93: getfield 137	android/content/res/Resources:mCompatibilityInfo	Landroid/content/res/CompatibilityInfo;
    //   96: astore 15
    //   98: aload_0
    //   99: getfield 86	android/content/res/Resources:mTmpConfig	Landroid/content/res/Configuration;
    //   102: astore 16
    //   104: aload 15
    //   106: iload 7
    //   108: aload 16
    //   110: invokevirtual 790	android/content/res/CompatibilityInfo:applyToConfiguration	(ILandroid/content/res/Configuration;)V
    //   113: aload_0
    //   114: getfield 86	android/content/res/Resources:mTmpConfig	Landroid/content/res/Configuration;
    //   117: getfield 222	android/content/res/Configuration:locale	Ljava/util/Locale;
    //   120: ifnonnull +27 -> 147
    //   123: aload_0
    //   124: getfield 86	android/content/res/Resources:mTmpConfig	Landroid/content/res/Configuration;
    //   127: invokestatic 796	java/util/Locale:getDefault	()Ljava/util/Locale;
    //   130: putfield 222	android/content/res/Configuration:locale	Ljava/util/Locale;
    //   133: aload_0
    //   134: getfield 86	android/content/res/Resources:mTmpConfig	Landroid/content/res/Configuration;
    //   137: aload_0
    //   138: getfield 86	android/content/res/Resources:mTmpConfig	Landroid/content/res/Configuration;
    //   141: getfield 222	android/content/res/Configuration:locale	Ljava/util/Locale;
    //   144: invokevirtual 800	android/content/res/Configuration:setLayoutDirection	(Ljava/util/Locale;)V
    //   147: aload_0
    //   148: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   151: aload_0
    //   152: getfield 86	android/content/res/Resources:mTmpConfig	Landroid/content/res/Configuration;
    //   155: invokevirtual 804	android/content/res/Configuration:updateFrom	(Landroid/content/res/Configuration;)I
    //   158: invokestatic 809	android/content/pm/ActivityInfo:activityInfoConfigToNative	(I)I
    //   161: istore 6
    //   163: aload_0
    //   164: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   167: getfield 222	android/content/res/Configuration:locale	Ljava/util/Locale;
    //   170: ifnonnull +27 -> 197
    //   173: aload_0
    //   174: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   177: invokestatic 796	java/util/Locale:getDefault	()Ljava/util/Locale;
    //   180: putfield 222	android/content/res/Configuration:locale	Ljava/util/Locale;
    //   183: aload_0
    //   184: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   187: aload_0
    //   188: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   191: getfield 222	android/content/res/Configuration:locale	Ljava/util/Locale;
    //   194: invokevirtual 800	android/content/res/Configuration:setLayoutDirection	(Ljava/util/Locale;)V
    //   197: aload_0
    //   198: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   201: getfield 602	android/content/res/Configuration:densityDpi	I
    //   204: ifeq +36 -> 240
    //   207: aload_0
    //   208: getfield 111	android/content/res/Resources:mMetrics	Landroid/util/DisplayMetrics;
    //   211: aload_0
    //   212: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   215: getfield 602	android/content/res/Configuration:densityDpi	I
    //   218: putfield 394	android/util/DisplayMetrics:densityDpi	I
    //   221: aload_0
    //   222: getfield 111	android/content/res/Resources:mMetrics	Landroid/util/DisplayMetrics;
    //   225: ldc_w 810
    //   228: aload_0
    //   229: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   232: getfield 602	android/content/res/Configuration:densityDpi	I
    //   235: i2f
    //   236: fmul
    //   237: putfield 813	android/util/DisplayMetrics:density	F
    //   240: aload_0
    //   241: getfield 111	android/content/res/Resources:mMetrics	Landroid/util/DisplayMetrics;
    //   244: aload_0
    //   245: getfield 111	android/content/res/Resources:mMetrics	Landroid/util/DisplayMetrics;
    //   248: getfield 813	android/util/DisplayMetrics:density	F
    //   251: aload_0
    //   252: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   255: getfield 816	android/content/res/Configuration:fontScale	F
    //   258: fmul
    //   259: putfield 819	android/util/DisplayMetrics:scaledDensity	F
    //   262: aload_0
    //   263: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   266: getfield 222	android/content/res/Configuration:locale	Ljava/util/Locale;
    //   269: astore 8
    //   271: aconst_null
    //   272: astore 9
    //   274: aload 8
    //   276: ifnull +64 -> 340
    //   279: aload_0
    //   280: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   283: getfield 222	android/content/res/Configuration:locale	Ljava/util/Locale;
    //   286: invokevirtual 822	java/util/Locale:getLanguage	()Ljava/lang/String;
    //   289: astore 9
    //   291: aload_0
    //   292: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   295: getfield 222	android/content/res/Configuration:locale	Ljava/util/Locale;
    //   298: invokevirtual 825	java/util/Locale:getCountry	()Ljava/lang/String;
    //   301: ifnull +39 -> 340
    //   304: new 275	java/lang/StringBuilder
    //   307: dup
    //   308: invokespecial 276	java/lang/StringBuilder:<init>	()V
    //   311: aload 9
    //   313: invokevirtual 282	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   316: ldc_w 827
    //   319: invokevirtual 282	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   322: aload_0
    //   323: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   326: getfield 222	android/content/res/Configuration:locale	Ljava/util/Locale;
    //   329: invokevirtual 825	java/util/Locale:getCountry	()Ljava/lang/String;
    //   332: invokevirtual 282	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   335: invokevirtual 297	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   338: astore 9
    //   340: aload_0
    //   341: getfield 111	android/content/res/Resources:mMetrics	Landroid/util/DisplayMetrics;
    //   344: getfield 830	android/util/DisplayMetrics:widthPixels	I
    //   347: aload_0
    //   348: getfield 111	android/content/res/Resources:mMetrics	Landroid/util/DisplayMetrics;
    //   351: getfield 833	android/util/DisplayMetrics:heightPixels	I
    //   354: if_icmplt +216 -> 570
    //   357: aload_0
    //   358: getfield 111	android/content/res/Resources:mMetrics	Landroid/util/DisplayMetrics;
    //   361: getfield 830	android/util/DisplayMetrics:widthPixels	I
    //   364: istore 10
    //   366: aload_0
    //   367: getfield 111	android/content/res/Resources:mMetrics	Landroid/util/DisplayMetrics;
    //   370: getfield 833	android/util/DisplayMetrics:heightPixels	I
    //   373: istore 11
    //   375: aload_0
    //   376: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   379: getfield 836	android/content/res/Configuration:keyboardHidden	I
    //   382: istore 12
    //   384: iload 12
    //   386: iconst_1
    //   387: if_icmpne +17 -> 404
    //   390: aload_0
    //   391: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   394: getfield 839	android/content/res/Configuration:hardKeyboardHidden	I
    //   397: iconst_2
    //   398: if_icmpne +6 -> 404
    //   401: iconst_3
    //   402: istore 12
    //   404: aload_0
    //   405: getfield 119	android/content/res/Resources:mAssets	Landroid/content/res/AssetManager;
    //   408: aload_0
    //   409: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   412: getfield 842	android/content/res/Configuration:mcc	I
    //   415: aload_0
    //   416: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   419: getfield 845	android/content/res/Configuration:mnc	I
    //   422: aload 9
    //   424: aload_0
    //   425: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   428: getfield 848	android/content/res/Configuration:orientation	I
    //   431: aload_0
    //   432: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   435: getfield 851	android/content/res/Configuration:touchscreen	I
    //   438: aload_0
    //   439: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   442: getfield 602	android/content/res/Configuration:densityDpi	I
    //   445: aload_0
    //   446: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   449: getfield 854	android/content/res/Configuration:keyboard	I
    //   452: iload 12
    //   454: aload_0
    //   455: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   458: getfield 857	android/content/res/Configuration:navigation	I
    //   461: iload 10
    //   463: iload 11
    //   465: aload_0
    //   466: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   469: getfield 860	android/content/res/Configuration:smallestScreenWidthDp	I
    //   472: aload_0
    //   473: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   476: getfield 863	android/content/res/Configuration:screenWidthDp	I
    //   479: aload_0
    //   480: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   483: getfield 866	android/content/res/Configuration:screenHeightDp	I
    //   486: aload_0
    //   487: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   490: getfield 869	android/content/res/Configuration:screenLayout	I
    //   493: aload_0
    //   494: getfield 106	android/content/res/Resources:mConfiguration	Landroid/content/res/Configuration;
    //   497: getfield 872	android/content/res/Configuration:uiMode	I
    //   500: getstatic 877	android/os/Build$VERSION:RESOURCES_SDK_INT	I
    //   503: invokevirtual 881	android/content/res/AssetManager:setConfiguration	(IILjava/lang/String;IIIIIIIIIIIIII)V
    //   506: aload_0
    //   507: aload_0
    //   508: getfield 88	android/content/res/Resources:mDrawableCache	Landroid/util/LongSparseArray;
    //   511: iload 6
    //   513: invokespecial 883	android/content/res/Resources:clearDrawableCache	(Landroid/util/LongSparseArray;I)V
    //   516: aload_0
    //   517: aload_0
    //   518: getfield 92	android/content/res/Resources:mColorDrawableCache	Landroid/util/LongSparseArray;
    //   521: iload 6
    //   523: invokespecial 883	android/content/res/Resources:clearDrawableCache	(Landroid/util/LongSparseArray;I)V
    //   526: aload_0
    //   527: getfield 90	android/content/res/Resources:mColorStateListCache	Landroid/util/LongSparseArray;
    //   530: invokevirtual 886	android/util/LongSparseArray:clear	()V
    //   533: aload_0
    //   534: invokevirtual 311	android/content/res/Resources:flushLayoutCache	()V
    //   537: aload 4
    //   539: monitorexit
    //   540: getstatic 65	android/content/res/Resources:mSync	Ljava/lang/Object;
    //   543: astore 13
    //   545: aload 13
    //   547: monitorenter
    //   548: aload_0
    //   549: getfield 218	android/content/res/Resources:mPluralRule	Llibcore/icu/NativePluralRules;
    //   552: ifnull +14 -> 566
    //   555: aload_0
    //   556: aload_1
    //   557: getfield 222	android/content/res/Configuration:locale	Ljava/util/Locale;
    //   560: invokestatic 228	libcore/icu/NativePluralRules:forLocale	(Ljava/util/Locale;)Llibcore/icu/NativePluralRules;
    //   563: putfield 218	android/content/res/Resources:mPluralRule	Llibcore/icu/NativePluralRules;
    //   566: aload 13
    //   568: monitorexit
    //   569: return
    //   570: aload_0
    //   571: getfield 111	android/content/res/Resources:mMetrics	Landroid/util/DisplayMetrics;
    //   574: getfield 833	android/util/DisplayMetrics:heightPixels	I
    //   577: istore 10
    //   579: aload_0
    //   580: getfield 111	android/content/res/Resources:mMetrics	Landroid/util/DisplayMetrics;
    //   583: getfield 830	android/util/DisplayMetrics:widthPixels	I
    //   586: istore 11
    //   588: goto -213 -> 375
    //   591: astore 5
    //   593: aload 4
    //   595: monitorexit
    //   596: aload 5
    //   598: athrow
    //   599: astore 14
    //   601: aload 13
    //   603: monitorexit
    //   604: aload 14
    //   606: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	607	0	this	Resources
    //   0	607	1	paramConfiguration	Configuration
    //   0	607	2	paramDisplayMetrics	DisplayMetrics
    //   0	607	3	paramCompatibilityInfo	CompatibilityInfo
    //   4	590	4	localTypedValue	TypedValue
    //   591	6	5	localObject1	Object
    //   51	471	6	i	int
    //   69	38	7	j	int
    //   269	6	8	localLocale	java.util.Locale
    //   272	151	9	str	String
    //   364	214	10	k	int
    //   373	214	11	m	int
    //   382	71	12	n	int
    //   599	6	14	localObject3	Object
    //   96	9	15	localCompatibilityInfo	CompatibilityInfo
    //   102	7	16	localConfiguration	Configuration
    // Exception table:
    //   from	to	target	type
    //   13	18	591	finally
    //   22	30	591	finally
    //   30	48	591	finally
    //   57	71	591	finally
    //   76	85	591	finally
    //   85	113	591	finally
    //   113	147	591	finally
    //   147	163	591	finally
    //   163	197	591	finally
    //   197	240	591	finally
    //   240	271	591	finally
    //   279	340	591	finally
    //   340	375	591	finally
    //   375	384	591	finally
    //   390	401	591	finally
    //   404	540	591	finally
    //   570	588	591	finally
    //   593	596	591	finally
    //   548	566	599	finally
    //   566	569	599	finally
    //   601	604	599	finally
  }
  
  public static class NotFoundException
    extends RuntimeException
  {
    public NotFoundException() {}
    
    public NotFoundException(String paramString)
    {
      super();
    }
  }
  
  public final class Theme
  {
    private final AssetManager mAssets = Resources.this.mAssets;
    private final int mTheme = this.mAssets.createTheme();
    
    Theme() {}
    
    public void applyStyle(int paramInt, boolean paramBoolean)
    {
      AssetManager.applyThemeStyle(this.mTheme, paramInt, paramBoolean);
    }
    
    public void dump(int paramInt, String paramString1, String paramString2)
    {
      AssetManager.dumpTheme(this.mTheme, paramInt, paramString1, paramString2);
    }
    
    protected void finalize()
      throws Throwable
    {
      super.finalize();
      this.mAssets.releaseTheme(this.mTheme);
    }
    
    public TypedArray obtainStyledAttributes(int paramInt, int[] paramArrayOfInt)
      throws Resources.NotFoundException
    {
      int i = paramArrayOfInt.length;
      TypedArray localTypedArray = Resources.this.getCachedStyledAttributes(i);
      localTypedArray.mRsrcs = paramArrayOfInt;
      AssetManager.applyStyle(this.mTheme, 0, paramInt, 0, paramArrayOfInt, localTypedArray.mData, localTypedArray.mIndices);
      return localTypedArray;
    }
    
    public TypedArray obtainStyledAttributes(AttributeSet paramAttributeSet, int[] paramArrayOfInt, int paramInt1, int paramInt2)
    {
      int i = paramArrayOfInt.length;
      TypedArray localTypedArray = Resources.this.getCachedStyledAttributes(i);
      XmlBlock.Parser localParser = (XmlBlock.Parser)paramAttributeSet;
      int j = this.mTheme;
      if (localParser != null) {}
      for (int k = localParser.mParseState;; k = 0)
      {
        AssetManager.applyStyle(j, paramInt1, paramInt2, k, paramArrayOfInt, localTypedArray.mData, localTypedArray.mIndices);
        localTypedArray.mRsrcs = paramArrayOfInt;
        localTypedArray.mXml = localParser;
        return localTypedArray;
      }
    }
    
    public TypedArray obtainStyledAttributes(int[] paramArrayOfInt)
    {
      int i = paramArrayOfInt.length;
      TypedArray localTypedArray = Resources.this.getCachedStyledAttributes(i);
      localTypedArray.mRsrcs = paramArrayOfInt;
      AssetManager.applyStyle(this.mTheme, 0, 0, 0, paramArrayOfInt, localTypedArray.mData, localTypedArray.mIndices);
      return localTypedArray;
    }
    
    public boolean resolveAttribute(int paramInt, TypedValue paramTypedValue, boolean paramBoolean)
    {
      return this.mAssets.getThemeValue(this.mTheme, paramInt, paramTypedValue, paramBoolean);
    }
    
    public void setTo(Theme paramTheme)
    {
      AssetManager.copyTheme(this.mTheme, paramTheme.mTheme);
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\res\Resources.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
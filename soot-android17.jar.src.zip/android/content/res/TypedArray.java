package android.content.res;

import android.graphics.drawable.Drawable;
import android.util.Log;
import android.util.TypedValue;
import com.android.internal.util.XmlUtils;
import java.util.Arrays;

public class TypedArray
{
  int[] mData;
  int[] mIndices;
  int mLength;
  private final Resources mResources;
  int[] mRsrcs;
  TypedValue mValue = new TypedValue();
  XmlBlock.Parser mXml;
  
  TypedArray(Resources paramResources, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt)
  {
    this.mResources = paramResources;
    this.mData = paramArrayOfInt1;
    this.mIndices = paramArrayOfInt2;
    this.mLength = paramInt;
  }
  
  private boolean getValueAt(int paramInt, TypedValue paramTypedValue)
  {
    int[] arrayOfInt = this.mData;
    int i = arrayOfInt[(paramInt + 0)];
    if (i == 0) {
      return false;
    }
    paramTypedValue.type = i;
    paramTypedValue.data = arrayOfInt[(paramInt + 1)];
    paramTypedValue.assetCookie = arrayOfInt[(paramInt + 2)];
    paramTypedValue.resourceId = arrayOfInt[(paramInt + 3)];
    paramTypedValue.changingConfigurations = arrayOfInt[(paramInt + 4)];
    paramTypedValue.density = arrayOfInt[(paramInt + 5)];
    if (i == 3) {}
    for (CharSequence localCharSequence = loadStringValueAt(paramInt);; localCharSequence = null)
    {
      paramTypedValue.string = localCharSequence;
      return true;
    }
  }
  
  private CharSequence loadStringValueAt(int paramInt)
  {
    int[] arrayOfInt = this.mData;
    int i = arrayOfInt[(paramInt + 2)];
    if (i < 0)
    {
      if (this.mXml != null) {
        return this.mXml.getPooledString(arrayOfInt[(paramInt + 1)]);
      }
      return null;
    }
    return this.mResources.mAssets.getPooledString(i, arrayOfInt[(paramInt + 1)]);
  }
  
  public boolean getBoolean(int paramInt, boolean paramBoolean)
  {
    int i = paramInt * 6;
    int[] arrayOfInt = this.mData;
    int j = arrayOfInt[(i + 0)];
    if (j == 0) {
      return paramBoolean;
    }
    if ((j >= 16) && (j <= 31))
    {
      if (arrayOfInt[(i + 1)] != 0) {}
      for (boolean bool = true;; bool = false) {
        return bool;
      }
    }
    TypedValue localTypedValue = this.mValue;
    if (getValueAt(i, localTypedValue))
    {
      Log.w("Resources", "Converting to boolean: " + localTypedValue);
      return XmlUtils.convertValueToBoolean(localTypedValue.coerceToString(), paramBoolean);
    }
    Log.w("Resources", "getBoolean of bad type: 0x" + Integer.toHexString(j));
    return paramBoolean;
  }
  
  public int getColor(int paramInt1, int paramInt2)
  {
    int i = paramInt1 * 6;
    int[] arrayOfInt = this.mData;
    int j = arrayOfInt[(i + 0)];
    if (j == 0) {}
    TypedValue localTypedValue;
    do
    {
      return paramInt2;
      if ((j >= 16) && (j <= 31)) {
        return arrayOfInt[(i + 1)];
      }
      if (j != 3) {
        break;
      }
      localTypedValue = this.mValue;
    } while (!getValueAt(i, localTypedValue));
    return this.mResources.loadColorStateList(localTypedValue, localTypedValue.resourceId).getDefaultColor();
    throw new UnsupportedOperationException("Can't convert to color: type=0x" + Integer.toHexString(j));
  }
  
  public ColorStateList getColorStateList(int paramInt)
  {
    TypedValue localTypedValue = this.mValue;
    if (getValueAt(paramInt * 6, localTypedValue)) {
      return this.mResources.loadColorStateList(localTypedValue, localTypedValue.resourceId);
    }
    return null;
  }
  
  public float getDimension(int paramInt, float paramFloat)
  {
    int i = paramInt * 6;
    int[] arrayOfInt = this.mData;
    int j = arrayOfInt[(i + 0)];
    if (j == 0) {
      return paramFloat;
    }
    if (j == 5) {
      return TypedValue.complexToDimension(arrayOfInt[(i + 1)], this.mResources.mMetrics);
    }
    throw new UnsupportedOperationException("Can't convert to dimension: type=0x" + Integer.toHexString(j));
  }
  
  public int getDimensionPixelOffset(int paramInt1, int paramInt2)
  {
    int i = paramInt1 * 6;
    int[] arrayOfInt = this.mData;
    int j = arrayOfInt[(i + 0)];
    if (j == 0) {
      return paramInt2;
    }
    if (j == 5) {
      return TypedValue.complexToDimensionPixelOffset(arrayOfInt[(i + 1)], this.mResources.mMetrics);
    }
    throw new UnsupportedOperationException("Can't convert to dimension: type=0x" + Integer.toHexString(j));
  }
  
  public int getDimensionPixelSize(int paramInt1, int paramInt2)
  {
    int i = paramInt1 * 6;
    int[] arrayOfInt = this.mData;
    int j = arrayOfInt[(i + 0)];
    if (j == 0) {
      return paramInt2;
    }
    if (j == 5) {
      return TypedValue.complexToDimensionPixelSize(arrayOfInt[(i + 1)], this.mResources.mMetrics);
    }
    throw new UnsupportedOperationException("Can't convert to dimension: type=0x" + Integer.toHexString(j));
  }
  
  public Drawable getDrawable(int paramInt)
  {
    TypedValue localTypedValue = this.mValue;
    if (getValueAt(paramInt * 6, localTypedValue)) {
      return this.mResources.loadDrawable(localTypedValue, localTypedValue.resourceId);
    }
    return null;
  }
  
  public float getFloat(int paramInt, float paramFloat)
  {
    int i = paramInt * 6;
    int[] arrayOfInt = this.mData;
    int j = arrayOfInt[(i + 0)];
    if (j == 0) {
      return paramFloat;
    }
    if (j == 4) {
      return Float.intBitsToFloat(arrayOfInt[(i + 1)]);
    }
    if ((j >= 16) && (j <= 31)) {
      return arrayOfInt[(i + 1)];
    }
    TypedValue localTypedValue = this.mValue;
    if (getValueAt(i, localTypedValue))
    {
      Log.w("Resources", "Converting to float: " + localTypedValue);
      CharSequence localCharSequence = localTypedValue.coerceToString();
      if (localCharSequence != null) {
        return Float.parseFloat(localCharSequence.toString());
      }
    }
    Log.w("Resources", "getFloat of bad type: 0x" + Integer.toHexString(j));
    return paramFloat;
  }
  
  public float getFraction(int paramInt1, int paramInt2, int paramInt3, float paramFloat)
  {
    int i = paramInt1 * 6;
    int[] arrayOfInt = this.mData;
    int j = arrayOfInt[(i + 0)];
    if (j == 0) {
      return paramFloat;
    }
    if (j == 6) {
      return TypedValue.complexToFraction(arrayOfInt[(i + 1)], paramInt2, paramInt3);
    }
    throw new UnsupportedOperationException("Can't convert to fraction: type=0x" + Integer.toHexString(j));
  }
  
  public int getIndex(int paramInt)
  {
    return this.mIndices[(paramInt + 1)];
  }
  
  public int getIndexCount()
  {
    return this.mIndices[0];
  }
  
  public int getInt(int paramInt1, int paramInt2)
  {
    int i = paramInt1 * 6;
    int[] arrayOfInt = this.mData;
    int j = arrayOfInt[(i + 0)];
    if (j == 0) {
      return paramInt2;
    }
    if ((j >= 16) && (j <= 31)) {
      return arrayOfInt[(i + 1)];
    }
    TypedValue localTypedValue = this.mValue;
    if (getValueAt(i, localTypedValue))
    {
      Log.w("Resources", "Converting to int: " + localTypedValue);
      return XmlUtils.convertValueToInt(localTypedValue.coerceToString(), paramInt2);
    }
    Log.w("Resources", "getInt of bad type: 0x" + Integer.toHexString(j));
    return paramInt2;
  }
  
  public int getInteger(int paramInt1, int paramInt2)
  {
    int i = paramInt1 * 6;
    int[] arrayOfInt = this.mData;
    int j = arrayOfInt[(i + 0)];
    if (j == 0) {
      return paramInt2;
    }
    if ((j >= 16) && (j <= 31)) {
      return arrayOfInt[(i + 1)];
    }
    throw new UnsupportedOperationException("Can't convert to integer: type=0x" + Integer.toHexString(j));
  }
  
  public int getLayoutDimension(int paramInt1, int paramInt2)
  {
    int i = paramInt1 * 6;
    int[] arrayOfInt = this.mData;
    int j = arrayOfInt[(i + 0)];
    if ((j >= 16) && (j <= 31)) {
      paramInt2 = arrayOfInt[(i + 1)];
    }
    while (j != 5) {
      return paramInt2;
    }
    return TypedValue.complexToDimensionPixelSize(arrayOfInt[(i + 1)], this.mResources.mMetrics);
  }
  
  public int getLayoutDimension(int paramInt, String paramString)
  {
    int i = paramInt * 6;
    int[] arrayOfInt = this.mData;
    int j = arrayOfInt[(i + 0)];
    if ((j >= 16) && (j <= 31)) {
      return arrayOfInt[(i + 1)];
    }
    if (j == 5) {
      return TypedValue.complexToDimensionPixelSize(arrayOfInt[(i + 1)], this.mResources.mMetrics);
    }
    throw new RuntimeException(getPositionDescription() + ": You must supply a " + paramString + " attribute.");
  }
  
  public String getNonConfigurationString(int paramInt1, int paramInt2)
  {
    int i = paramInt1 * 6;
    int[] arrayOfInt = this.mData;
    int j = arrayOfInt[(i + 0)];
    if ((arrayOfInt[(i + 4)] & (paramInt2 ^ 0xFFFFFFFF)) != 0) {}
    CharSequence localCharSequence;
    do
    {
      do
      {
        return null;
      } while (j == 0);
      if (j == 3) {
        return loadStringValueAt(i).toString();
      }
      TypedValue localTypedValue = this.mValue;
      if (!getValueAt(i, localTypedValue)) {
        break;
      }
      Log.w("Resources", "Converting to string: " + localTypedValue);
      localCharSequence = localTypedValue.coerceToString();
    } while (localCharSequence == null);
    return localCharSequence.toString();
    Log.w("Resources", "getString of bad type: 0x" + Integer.toHexString(j));
    return null;
  }
  
  public String getNonResourceString(int paramInt)
  {
    int i = paramInt * 6;
    int[] arrayOfInt = this.mData;
    if ((arrayOfInt[(i + 0)] == 3) && (arrayOfInt[(i + 2)] < 0)) {
      return this.mXml.getPooledString(arrayOfInt[(i + 1)]).toString();
    }
    return null;
  }
  
  public String getPositionDescription()
  {
    if (this.mXml != null) {
      return this.mXml.getPositionDescription();
    }
    return "<internal>";
  }
  
  public int getResourceId(int paramInt1, int paramInt2)
  {
    int i = paramInt1 * 6;
    int[] arrayOfInt = this.mData;
    if (arrayOfInt[(i + 0)] != 0)
    {
      int j = arrayOfInt[(i + 3)];
      if (j != 0) {
        return j;
      }
    }
    return paramInt2;
  }
  
  public Resources getResources()
  {
    return this.mResources;
  }
  
  public String getString(int paramInt)
  {
    int i = paramInt * 6;
    int j = this.mData[(i + 0)];
    if (j == 0) {}
    CharSequence localCharSequence;
    do
    {
      return null;
      if (j == 3) {
        return loadStringValueAt(i).toString();
      }
      TypedValue localTypedValue = this.mValue;
      if (!getValueAt(i, localTypedValue)) {
        break;
      }
      Log.w("Resources", "Converting to string: " + localTypedValue);
      localCharSequence = localTypedValue.coerceToString();
    } while (localCharSequence == null);
    return localCharSequence.toString();
    Log.w("Resources", "getString of bad type: 0x" + Integer.toHexString(j));
    return null;
  }
  
  public CharSequence getText(int paramInt)
  {
    int i = paramInt * 6;
    int j = this.mData[(i + 0)];
    if (j == 0) {
      return null;
    }
    if (j == 3) {
      return loadStringValueAt(i);
    }
    TypedValue localTypedValue = this.mValue;
    if (getValueAt(i, localTypedValue))
    {
      Log.w("Resources", "Converting to string: " + localTypedValue);
      return localTypedValue.coerceToString();
    }
    Log.w("Resources", "getString of bad type: 0x" + Integer.toHexString(j));
    return null;
  }
  
  public CharSequence[] getTextArray(int paramInt)
  {
    TypedValue localTypedValue = this.mValue;
    if (getValueAt(paramInt * 6, localTypedValue)) {
      return this.mResources.getTextArray(localTypedValue.resourceId);
    }
    return null;
  }
  
  public boolean getValue(int paramInt, TypedValue paramTypedValue)
  {
    return getValueAt(paramInt * 6, paramTypedValue);
  }
  
  public boolean hasValue(int paramInt)
  {
    int i = paramInt * 6;
    return this.mData[(i + 0)] != 0;
  }
  
  public int length()
  {
    return this.mLength;
  }
  
  public TypedValue peekValue(int paramInt)
  {
    TypedValue localTypedValue = this.mValue;
    if (getValueAt(paramInt * 6, localTypedValue)) {
      return localTypedValue;
    }
    return null;
  }
  
  public void recycle()
  {
    synchronized (this.mResources.mTmpValue)
    {
      TypedArray localTypedArray = this.mResources.mCachedStyledAttributes;
      if ((localTypedArray == null) || (localTypedArray.mData.length < this.mData.length))
      {
        this.mXml = null;
        this.mResources.mCachedStyledAttributes = this;
      }
      return;
    }
  }
  
  public String toString()
  {
    return Arrays.toString(this.mData);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\res\TypedArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
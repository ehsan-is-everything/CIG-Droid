package android.content.res;

import android.os.ParcelFileDescriptor;
import android.util.TypedValue;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

public final class AssetManager
{
  public static final int ACCESS_BUFFER = 3;
  public static final int ACCESS_RANDOM = 1;
  public static final int ACCESS_STREAMING = 2;
  public static final int ACCESS_UNKNOWN = 0;
  private static final boolean DEBUG_REFS = false;
  static final int STYLE_ASSET_COOKIE = 2;
  static final int STYLE_CHANGING_CONFIGURATIONS = 4;
  static final int STYLE_DATA = 1;
  static final int STYLE_DENSITY = 5;
  static final int STYLE_NUM_ENTRIES = 6;
  static final int STYLE_RESOURCE_ID = 3;
  static final int STYLE_TYPE = 0;
  private static final String TAG = "AssetManager";
  private static final boolean localLOGV;
  private static final Object sSync = new Object();
  static AssetManager sSystem = null;
  private int mNObject;
  private int mNumRefs = 1;
  private int mObject;
  private final long[] mOffsets = new long[2];
  private boolean mOpen = true;
  private HashMap<Integer, RuntimeException> mRefStacks;
  private StringBlock[] mStringBlocks = null;
  private final TypedValue mValue = new TypedValue();
  
  public AssetManager()
  {
    try
    {
      init();
      ensureSystemAssets();
      return;
    }
    finally {}
  }
  
  private AssetManager(boolean paramBoolean)
  {
    init();
  }
  
  static final native boolean applyStyle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  static final native void applyThemeStyle(int paramInt1, int paramInt2, boolean paramBoolean);
  
  static final native void copyTheme(int paramInt1, int paramInt2);
  
  private final void decRefsLocked(int paramInt)
  {
    this.mNumRefs = (-1 + this.mNumRefs);
    if (this.mNumRefs == 0) {
      destroy();
    }
  }
  
  private final native void deleteTheme(int paramInt);
  
  private final native void destroy();
  
  private final native void destroyAsset(int paramInt);
  
  static final native void dumpTheme(int paramInt1, int paramInt2, String paramString1, String paramString2);
  
  private static void ensureSystemAssets()
  {
    synchronized (sSync)
    {
      if (sSystem == null)
      {
        AssetManager localAssetManager = new AssetManager(true);
        localAssetManager.makeStringBlocks(false);
        sSystem = localAssetManager;
      }
      return;
    }
  }
  
  private final native int[] getArrayStringInfo(int paramInt);
  
  private final native String[] getArrayStringResource(int paramInt);
  
  public static final native String getAssetAllocations();
  
  private final native long getAssetLength(int paramInt);
  
  private final native long getAssetRemainingLength(int paramInt);
  
  public static final native int getGlobalAssetCount();
  
  public static final native int getGlobalAssetManagerCount();
  
  private final native int getNativeStringBlock(int paramInt);
  
  private final native int getStringBlockCount();
  
  public static AssetManager getSystem()
  {
    ensureSystemAssets();
    return sSystem;
  }
  
  private final void incRefsLocked(int paramInt)
  {
    this.mNumRefs = (1 + this.mNumRefs);
  }
  
  private final native void init();
  
  private final native int loadResourceBagValue(int paramInt1, int paramInt2, TypedValue paramTypedValue, boolean paramBoolean);
  
  private final native int loadResourceValue(int paramInt, short paramShort, TypedValue paramTypedValue, boolean paramBoolean);
  
  static final native int loadThemeAttributeValue(int paramInt1, int paramInt2, TypedValue paramTypedValue, boolean paramBoolean);
  
  private final native int newTheme();
  
  private final native int openAsset(String paramString, int paramInt);
  
  private final native ParcelFileDescriptor openAssetFd(String paramString, long[] paramArrayOfLong)
    throws IOException;
  
  private native ParcelFileDescriptor openNonAssetFdNative(int paramInt, String paramString, long[] paramArrayOfLong)
    throws IOException;
  
  private final native int openNonAssetNative(int paramInt1, String paramString, int paramInt2);
  
  private final native int openXmlAssetNative(int paramInt, String paramString);
  
  private final native int readAsset(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3);
  
  private final native int readAssetChar(int paramInt);
  
  private final native long seekAsset(int paramInt1, long paramLong, int paramInt2);
  
  public final native int addAssetPath(String paramString);
  
  public final int[] addAssetPaths(String[] paramArrayOfString)
  {
    int[] arrayOfInt;
    if (paramArrayOfString == null) {
      arrayOfInt = null;
    }
    for (;;)
    {
      return arrayOfInt;
      arrayOfInt = new int[paramArrayOfString.length];
      for (int i = 0; i < paramArrayOfString.length; i++) {
        arrayOfInt[i] = addAssetPath(paramArrayOfString[i]);
      }
    }
  }
  
  public void close()
  {
    try
    {
      if (this.mOpen)
      {
        this.mOpen = false;
        decRefsLocked(hashCode());
      }
      return;
    }
    finally {}
  }
  
  final int createTheme()
  {
    try
    {
      if (!this.mOpen) {
        throw new RuntimeException("Assetmanager has been closed");
      }
    }
    finally {}
    int i = newTheme();
    incRefsLocked(i);
    return i;
  }
  
  final void ensureStringBlocks()
  {
    if (this.mStringBlocks == null) {
      try
      {
        if (this.mStringBlocks == null) {
          makeStringBlocks(true);
        }
        return;
      }
      finally {}
    }
  }
  
  protected void finalize()
    throws Throwable
  {
    try
    {
      destroy();
      return;
    }
    finally
    {
      super.finalize();
    }
  }
  
  final native int[] getArrayIntResource(int paramInt);
  
  final native int getArraySize(int paramInt);
  
  public final native String getCookieName(int paramInt);
  
  public final native String[] getLocales();
  
  final CharSequence getPooledString(int paramInt1, int paramInt2)
  {
    return this.mStringBlocks[(paramInt1 - 1)].get(paramInt2);
  }
  
  final CharSequence getResourceBagText(int paramInt1, int paramInt2)
  {
    try
    {
      TypedValue localTypedValue = this.mValue;
      int i = loadResourceBagValue(paramInt1, paramInt2, localTypedValue, true);
      if (i >= 0)
      {
        if (localTypedValue.type == 3)
        {
          CharSequence localCharSequence2 = this.mStringBlocks[i].get(localTypedValue.data);
          return localCharSequence2;
        }
        CharSequence localCharSequence1 = localTypedValue.coerceToString();
        return localCharSequence1;
      }
    }
    finally {}
    return null;
  }
  
  final native String getResourceEntryName(int paramInt);
  
  final native int getResourceIdentifier(String paramString1, String paramString2, String paramString3);
  
  final native String getResourceName(int paramInt);
  
  final native String getResourcePackageName(int paramInt);
  
  final String[] getResourceStringArray(int paramInt)
  {
    return getArrayStringResource(paramInt);
  }
  
  final CharSequence getResourceText(int paramInt)
  {
    try
    {
      TypedValue localTypedValue = this.mValue;
      int i = loadResourceValue(paramInt, (short)0, localTypedValue, true);
      if (i >= 0)
      {
        if (localTypedValue.type == 3)
        {
          CharSequence localCharSequence2 = this.mStringBlocks[i].get(localTypedValue.data);
          return localCharSequence2;
        }
        CharSequence localCharSequence1 = localTypedValue.coerceToString();
        return localCharSequence1;
      }
    }
    finally {}
    return null;
  }
  
  final CharSequence[] getResourceTextArray(int paramInt)
  {
    int[] arrayOfInt = getArrayStringInfo(paramInt);
    int i = arrayOfInt.length;
    CharSequence[] arrayOfCharSequence = new CharSequence[i / 2];
    int j = 0;
    int k = 0;
    if (j < i)
    {
      int m = arrayOfInt[j];
      int n = arrayOfInt[(j + 1)];
      if (n >= 0) {}
      for (CharSequence localCharSequence = this.mStringBlocks[m].get(n);; localCharSequence = null)
      {
        arrayOfCharSequence[k] = localCharSequence;
        j += 2;
        k++;
        break;
      }
    }
    return arrayOfCharSequence;
  }
  
  final native String getResourceTypeName(int paramInt);
  
  final boolean getResourceValue(int paramInt1, int paramInt2, TypedValue paramTypedValue, boolean paramBoolean)
  {
    int i = loadResourceValue(paramInt1, (short)paramInt2, paramTypedValue, paramBoolean);
    if (i >= 0)
    {
      if (paramTypedValue.type != 3) {
        return true;
      }
      paramTypedValue.string = this.mStringBlocks[i].get(paramTypedValue.data);
      return true;
    }
    return false;
  }
  
  final boolean getThemeValue(int paramInt1, int paramInt2, TypedValue paramTypedValue, boolean paramBoolean)
  {
    int i = loadThemeAttributeValue(paramInt1, paramInt2, paramTypedValue, paramBoolean);
    if (i >= 0)
    {
      if (paramTypedValue.type != 3) {
        return true;
      }
      StringBlock[] arrayOfStringBlock = this.mStringBlocks;
      if (arrayOfStringBlock == null)
      {
        ensureStringBlocks();
        arrayOfStringBlock = this.mStringBlocks;
      }
      paramTypedValue.string = arrayOfStringBlock[i].get(paramTypedValue.data);
      return true;
    }
    return false;
  }
  
  public final native boolean isUpToDate();
  
  public final native String[] list(String paramString)
    throws IOException;
  
  final void makeStringBlocks(boolean paramBoolean)
  {
    int i;
    int k;
    if (paramBoolean)
    {
      i = sSystem.mStringBlocks.length;
      int j = getStringBlockCount();
      this.mStringBlocks = new StringBlock[j];
      k = 0;
      label28:
      if (k >= j) {
        return;
      }
      if (k >= i) {
        break label67;
      }
      this.mStringBlocks[k] = sSystem.mStringBlocks[k];
    }
    for (;;)
    {
      k++;
      break label28;
      i = 0;
      break;
      label67:
      this.mStringBlocks[k] = new StringBlock(getNativeStringBlock(k), true);
    }
  }
  
  public final InputStream open(String paramString)
    throws IOException
  {
    return open(paramString, 2);
  }
  
  public final InputStream open(String paramString, int paramInt)
    throws IOException
  {
    try
    {
      if (!this.mOpen) {
        throw new RuntimeException("Assetmanager has been closed");
      }
    }
    finally {}
    int i = openAsset(paramString, paramInt);
    if (i != 0)
    {
      AssetInputStream localAssetInputStream = new AssetInputStream(i, null);
      incRefsLocked(localAssetInputStream.hashCode());
      return localAssetInputStream;
    }
    throw new FileNotFoundException("Asset file: " + paramString);
  }
  
  public final AssetFileDescriptor openFd(String paramString)
    throws IOException
  {
    try
    {
      if (!this.mOpen) {
        throw new RuntimeException("Assetmanager has been closed");
      }
    }
    finally {}
    ParcelFileDescriptor localParcelFileDescriptor = openAssetFd(paramString, this.mOffsets);
    if (localParcelFileDescriptor != null)
    {
      AssetFileDescriptor localAssetFileDescriptor = new AssetFileDescriptor(localParcelFileDescriptor, this.mOffsets[0], this.mOffsets[1]);
      return localAssetFileDescriptor;
    }
    throw new FileNotFoundException("Asset file: " + paramString);
  }
  
  public final InputStream openNonAsset(int paramInt, String paramString)
    throws IOException
  {
    return openNonAsset(paramInt, paramString, 2);
  }
  
  public final InputStream openNonAsset(int paramInt1, String paramString, int paramInt2)
    throws IOException
  {
    try
    {
      if (!this.mOpen) {
        throw new RuntimeException("Assetmanager has been closed");
      }
    }
    finally {}
    int i = openNonAssetNative(paramInt1, paramString, paramInt2);
    if (i != 0)
    {
      AssetInputStream localAssetInputStream = new AssetInputStream(i, null);
      incRefsLocked(localAssetInputStream.hashCode());
      return localAssetInputStream;
    }
    throw new FileNotFoundException("Asset absolute file: " + paramString);
  }
  
  public final InputStream openNonAsset(String paramString)
    throws IOException
  {
    return openNonAsset(0, paramString, 2);
  }
  
  public final InputStream openNonAsset(String paramString, int paramInt)
    throws IOException
  {
    return openNonAsset(0, paramString, paramInt);
  }
  
  public final AssetFileDescriptor openNonAssetFd(int paramInt, String paramString)
    throws IOException
  {
    try
    {
      if (!this.mOpen) {
        throw new RuntimeException("Assetmanager has been closed");
      }
    }
    finally {}
    ParcelFileDescriptor localParcelFileDescriptor = openNonAssetFdNative(paramInt, paramString, this.mOffsets);
    if (localParcelFileDescriptor != null)
    {
      AssetFileDescriptor localAssetFileDescriptor = new AssetFileDescriptor(localParcelFileDescriptor, this.mOffsets[0], this.mOffsets[1]);
      return localAssetFileDescriptor;
    }
    throw new FileNotFoundException("Asset absolute file: " + paramString);
  }
  
  public final AssetFileDescriptor openNonAssetFd(String paramString)
    throws IOException
  {
    return openNonAssetFd(0, paramString);
  }
  
  final XmlBlock openXmlBlockAsset(int paramInt, String paramString)
    throws IOException
  {
    try
    {
      if (!this.mOpen) {
        throw new RuntimeException("Assetmanager has been closed");
      }
    }
    finally {}
    int i = openXmlAssetNative(paramInt, paramString);
    if (i != 0)
    {
      XmlBlock localXmlBlock = new XmlBlock(this, i);
      incRefsLocked(localXmlBlock.hashCode());
      return localXmlBlock;
    }
    throw new FileNotFoundException("Asset XML file: " + paramString);
  }
  
  final XmlBlock openXmlBlockAsset(String paramString)
    throws IOException
  {
    return openXmlBlockAsset(0, paramString);
  }
  
  public final XmlResourceParser openXmlResourceParser(int paramInt, String paramString)
    throws IOException
  {
    XmlBlock localXmlBlock = openXmlBlockAsset(paramInt, paramString);
    XmlResourceParser localXmlResourceParser = localXmlBlock.newParser();
    localXmlBlock.close();
    return localXmlResourceParser;
  }
  
  public final XmlResourceParser openXmlResourceParser(String paramString)
    throws IOException
  {
    return openXmlResourceParser(0, paramString);
  }
  
  final void releaseTheme(int paramInt)
  {
    try
    {
      deleteTheme(paramInt);
      decRefsLocked(paramInt);
      return;
    }
    finally {}
  }
  
  final native int retrieveArray(int paramInt, int[] paramArrayOfInt);
  
  final native boolean retrieveAttributes(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  public final native void setConfiguration(int paramInt1, int paramInt2, String paramString, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, int paramInt14, int paramInt15, int paramInt16);
  
  public final native void setLocale(String paramString);
  
  void xmlBlockGone(int paramInt)
  {
    try
    {
      decRefsLocked(paramInt);
      return;
    }
    finally {}
  }
  
  public final class AssetInputStream
    extends InputStream
  {
    private int mAsset;
    private long mLength;
    private long mMarkPos;
    
    private AssetInputStream(int paramInt)
    {
      this.mAsset = paramInt;
      this.mLength = AssetManager.this.getAssetLength(paramInt);
    }
    
    public final int available()
      throws IOException
    {
      long l = AssetManager.this.getAssetRemainingLength(this.mAsset);
      if (l > 2147483647L) {
        return Integer.MAX_VALUE;
      }
      return (int)l;
    }
    
    public final void close()
      throws IOException
    {
      synchronized (AssetManager.this)
      {
        if (this.mAsset != 0)
        {
          AssetManager.this.destroyAsset(this.mAsset);
          this.mAsset = 0;
          AssetManager.this.decRefsLocked(hashCode());
        }
        return;
      }
    }
    
    protected void finalize()
      throws Throwable
    {
      close();
    }
    
    public final int getAssetInt()
    {
      return this.mAsset;
    }
    
    public final void mark(int paramInt)
    {
      this.mMarkPos = AssetManager.this.seekAsset(this.mAsset, 0L, 0);
    }
    
    public final boolean markSupported()
    {
      return true;
    }
    
    public final int read()
      throws IOException
    {
      return AssetManager.this.readAssetChar(this.mAsset);
    }
    
    public final int read(byte[] paramArrayOfByte)
      throws IOException
    {
      return AssetManager.this.readAsset(this.mAsset, paramArrayOfByte, 0, paramArrayOfByte.length);
    }
    
    public final int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      return AssetManager.this.readAsset(this.mAsset, paramArrayOfByte, paramInt1, paramInt2);
    }
    
    public final void reset()
      throws IOException
    {
      AssetManager.this.seekAsset(this.mAsset, this.mMarkPos, -1);
    }
    
    public final long skip(long paramLong)
      throws IOException
    {
      long l = AssetManager.this.seekAsset(this.mAsset, 0L, 0);
      if (l + paramLong > this.mLength) {
        paramLong = this.mLength - l;
      }
      if (paramLong > 0L) {
        AssetManager.this.seekAsset(this.mAsset, paramLong, 0);
      }
      return paramLong;
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\res\AssetManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.content;

import android.util.AndroidRuntimeException;

public class ReceiverCallNotAllowedException
  extends AndroidRuntimeException
{
  public ReceiverCallNotAllowedException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\ReceiverCallNotAllowedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
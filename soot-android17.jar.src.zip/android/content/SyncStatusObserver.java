package android.content;

public abstract interface SyncStatusObserver
{
  public abstract void onStatusChanged(int paramInt);
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\SyncStatusObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
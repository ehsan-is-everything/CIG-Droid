package android.content;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class AbstractThreadedSyncAdapter
{
  @Deprecated
  public static final int LOG_SYNC_DETAILS = 2743;
  private boolean mAllowParallelSyncs;
  private final boolean mAutoInitialize;
  private final Context mContext;
  private final ISyncAdapterImpl mISyncAdapterImpl;
  private final AtomicInteger mNumSyncStarts;
  private final Object mSyncThreadLock = new Object();
  private final HashMap<Account, SyncThread> mSyncThreads = new HashMap();
  
  public AbstractThreadedSyncAdapter(Context paramContext, boolean paramBoolean)
  {
    this(paramContext, paramBoolean, false);
  }
  
  public AbstractThreadedSyncAdapter(Context paramContext, boolean paramBoolean1, boolean paramBoolean2)
  {
    this.mContext = paramContext;
    this.mISyncAdapterImpl = new ISyncAdapterImpl(null);
    this.mNumSyncStarts = new AtomicInteger(0);
    this.mAutoInitialize = paramBoolean1;
    this.mAllowParallelSyncs = paramBoolean2;
  }
  
  private Account toSyncKey(Account paramAccount)
  {
    if (this.mAllowParallelSyncs) {
      return paramAccount;
    }
    return null;
  }
  
  public Context getContext()
  {
    return this.mContext;
  }
  
  public final IBinder getSyncAdapterBinder()
  {
    return this.mISyncAdapterImpl.asBinder();
  }
  
  public abstract void onPerformSync(Account paramAccount, Bundle paramBundle, String paramString, ContentProviderClient paramContentProviderClient, SyncResult paramSyncResult);
  
  public void onSyncCanceled()
  {
    synchronized (this.mSyncThreadLock)
    {
      SyncThread localSyncThread = (SyncThread)this.mSyncThreads.get(null);
      if (localSyncThread != null) {
        localSyncThread.interrupt();
      }
      return;
    }
  }
  
  public void onSyncCanceled(Thread paramThread)
  {
    paramThread.interrupt();
  }
  
  private class ISyncAdapterImpl
    extends ISyncAdapter.Stub
  {
    private ISyncAdapterImpl() {}
    
    public void cancelSync(ISyncContext paramISyncContext)
    {
      synchronized (AbstractThreadedSyncAdapter.this.mSyncThreadLock)
      {
        Iterator localIterator = AbstractThreadedSyncAdapter.this.mSyncThreads.values().iterator();
        AbstractThreadedSyncAdapter.SyncThread localSyncThread;
        do
        {
          boolean bool = localIterator.hasNext();
          localObject3 = null;
          if (!bool) {
            break;
          }
          localSyncThread = (AbstractThreadedSyncAdapter.SyncThread)localIterator.next();
        } while (AbstractThreadedSyncAdapter.SyncThread.access$700(localSyncThread).getSyncContextBinder() != paramISyncContext.asBinder());
        Object localObject3 = localSyncThread;
        if (localObject3 != null)
        {
          if (AbstractThreadedSyncAdapter.this.mAllowParallelSyncs) {
            AbstractThreadedSyncAdapter.this.onSyncCanceled((Thread)localObject3);
          }
        }
        else {
          return;
        }
      }
      AbstractThreadedSyncAdapter.this.onSyncCanceled();
    }
    
    public void initialize(Account paramAccount, String paramString)
      throws RemoteException
    {
      Bundle localBundle = new Bundle();
      localBundle.putBoolean("initialize", true);
      startSync(null, paramString, paramAccount, localBundle);
    }
    
    public void startSync(ISyncContext paramISyncContext, String paramString, Account paramAccount, Bundle paramBundle)
    {
      SyncContext localSyncContext = new SyncContext(paramISyncContext);
      Account localAccount = AbstractThreadedSyncAdapter.this.toSyncKey(paramAccount);
      synchronized (AbstractThreadedSyncAdapter.this.mSyncThreadLock)
      {
        int i;
        if (!AbstractThreadedSyncAdapter.this.mSyncThreads.containsKey(localAccount))
        {
          if ((AbstractThreadedSyncAdapter.this.mAutoInitialize) && (paramBundle != null) && (paramBundle.getBoolean("initialize", false)))
          {
            if (ContentResolver.getIsSyncable(paramAccount, paramString) < 0) {
              ContentResolver.setIsSyncable(paramAccount, paramString, 1);
            }
            localSyncContext.onFinished(new SyncResult());
            return;
          }
          AbstractThreadedSyncAdapter.SyncThread localSyncThread = new AbstractThreadedSyncAdapter.SyncThread(AbstractThreadedSyncAdapter.this, "SyncAdapterThread-" + AbstractThreadedSyncAdapter.this.mNumSyncStarts.incrementAndGet(), localSyncContext, paramString, paramAccount, paramBundle, null);
          AbstractThreadedSyncAdapter.this.mSyncThreads.put(localAccount, localSyncThread);
          localSyncThread.start();
          i = 0;
          if (i != 0) {
            localSyncContext.onFinished(SyncResult.ALREADY_IN_PROGRESS);
          }
        }
        else
        {
          i = 1;
        }
      }
    }
  }
  
  private class SyncThread
    extends Thread
  {
    private final Account mAccount;
    private final String mAuthority;
    private final Bundle mExtras;
    private final SyncContext mSyncContext;
    private final Account mThreadsKey;
    
    private SyncThread(String paramString1, SyncContext paramSyncContext, String paramString2, Account paramAccount, Bundle paramBundle)
    {
      super();
      this.mSyncContext = paramSyncContext;
      this.mAuthority = paramString2;
      this.mAccount = paramAccount;
      this.mExtras = paramBundle;
      this.mThreadsKey = AbstractThreadedSyncAdapter.this.toSyncKey(paramAccount);
    }
    
    private boolean isCanceled()
    {
      return Thread.currentThread().isInterrupted();
    }
    
    /* Error */
    public void run()
    {
      // Byte code:
      //   0: bipush 10
      //   2: invokestatic 60	android/os/Process:setThreadPriority	(I)V
      //   5: ldc2_w 61
      //   8: aload_0
      //   9: getfield 26	android/content/AbstractThreadedSyncAdapter$SyncThread:mAuthority	Ljava/lang/String;
      //   12: invokestatic 68	android/os/Trace:traceBegin	(JLjava/lang/String;)V
      //   15: new 70	android/content/SyncResult
      //   18: dup
      //   19: invokespecial 72	android/content/SyncResult:<init>	()V
      //   22: astore_1
      //   23: aconst_null
      //   24: astore_2
      //   25: aload_0
      //   26: invokespecial 74	android/content/AbstractThreadedSyncAdapter$SyncThread:isCanceled	()Z
      //   29: istore 8
      //   31: iload 8
      //   33: ifeq +61 -> 94
      //   36: ldc2_w 61
      //   39: invokestatic 78	android/os/Trace:traceEnd	(J)V
      //   42: iconst_0
      //   43: ifeq +5 -> 48
      //   46: aconst_null
      //   47: athrow
      //   48: aload_0
      //   49: invokespecial 74	android/content/AbstractThreadedSyncAdapter$SyncThread:isCanceled	()Z
      //   52: ifne +11 -> 63
      //   55: aload_0
      //   56: getfield 24	android/content/AbstractThreadedSyncAdapter$SyncThread:mSyncContext	Landroid/content/SyncContext;
      //   59: aload_1
      //   60: invokevirtual 84	android/content/SyncContext:onFinished	(Landroid/content/SyncResult;)V
      //   63: aload_0
      //   64: getfield 19	android/content/AbstractThreadedSyncAdapter$SyncThread:this$0	Landroid/content/AbstractThreadedSyncAdapter;
      //   67: invokestatic 88	android/content/AbstractThreadedSyncAdapter:access$200	(Landroid/content/AbstractThreadedSyncAdapter;)Ljava/lang/Object;
      //   70: astore 13
      //   72: aload 13
      //   74: monitorenter
      //   75: aload_0
      //   76: getfield 19	android/content/AbstractThreadedSyncAdapter$SyncThread:this$0	Landroid/content/AbstractThreadedSyncAdapter;
      //   79: invokestatic 92	android/content/AbstractThreadedSyncAdapter:access$300	(Landroid/content/AbstractThreadedSyncAdapter;)Ljava/util/HashMap;
      //   82: aload_0
      //   83: getfield 38	android/content/AbstractThreadedSyncAdapter$SyncThread:mThreadsKey	Landroid/accounts/Account;
      //   86: invokevirtual 98	java/util/HashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
      //   89: pop
      //   90: aload 13
      //   92: monitorexit
      //   93: return
      //   94: aload_0
      //   95: getfield 19	android/content/AbstractThreadedSyncAdapter$SyncThread:this$0	Landroid/content/AbstractThreadedSyncAdapter;
      //   98: invokestatic 102	android/content/AbstractThreadedSyncAdapter:access$900	(Landroid/content/AbstractThreadedSyncAdapter;)Landroid/content/Context;
      //   101: invokevirtual 108	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
      //   104: aload_0
      //   105: getfield 26	android/content/AbstractThreadedSyncAdapter$SyncThread:mAuthority	Ljava/lang/String;
      //   108: invokevirtual 114	android/content/ContentResolver:acquireContentProviderClient	(Ljava/lang/String;)Landroid/content/ContentProviderClient;
      //   111: astore_2
      //   112: aload_2
      //   113: ifnull +93 -> 206
      //   116: aload_0
      //   117: getfield 19	android/content/AbstractThreadedSyncAdapter$SyncThread:this$0	Landroid/content/AbstractThreadedSyncAdapter;
      //   120: aload_0
      //   121: getfield 28	android/content/AbstractThreadedSyncAdapter$SyncThread:mAccount	Landroid/accounts/Account;
      //   124: aload_0
      //   125: getfield 30	android/content/AbstractThreadedSyncAdapter$SyncThread:mExtras	Landroid/os/Bundle;
      //   128: aload_0
      //   129: getfield 26	android/content/AbstractThreadedSyncAdapter$SyncThread:mAuthority	Ljava/lang/String;
      //   132: aload_2
      //   133: aload_1
      //   134: invokevirtual 118	android/content/AbstractThreadedSyncAdapter:onPerformSync	(Landroid/accounts/Account;Landroid/os/Bundle;Ljava/lang/String;Landroid/content/ContentProviderClient;Landroid/content/SyncResult;)V
      //   137: ldc2_w 61
      //   140: invokestatic 78	android/os/Trace:traceEnd	(J)V
      //   143: aload_2
      //   144: ifnull +8 -> 152
      //   147: aload_2
      //   148: invokevirtual 123	android/content/ContentProviderClient:release	()Z
      //   151: pop
      //   152: aload_0
      //   153: invokespecial 74	android/content/AbstractThreadedSyncAdapter$SyncThread:isCanceled	()Z
      //   156: ifne +11 -> 167
      //   159: aload_0
      //   160: getfield 24	android/content/AbstractThreadedSyncAdapter$SyncThread:mSyncContext	Landroid/content/SyncContext;
      //   163: aload_1
      //   164: invokevirtual 84	android/content/SyncContext:onFinished	(Landroid/content/SyncResult;)V
      //   167: aload_0
      //   168: getfield 19	android/content/AbstractThreadedSyncAdapter$SyncThread:this$0	Landroid/content/AbstractThreadedSyncAdapter;
      //   171: invokestatic 88	android/content/AbstractThreadedSyncAdapter:access$200	(Landroid/content/AbstractThreadedSyncAdapter;)Ljava/lang/Object;
      //   174: astore 9
      //   176: aload 9
      //   178: monitorenter
      //   179: aload_0
      //   180: getfield 19	android/content/AbstractThreadedSyncAdapter$SyncThread:this$0	Landroid/content/AbstractThreadedSyncAdapter;
      //   183: invokestatic 92	android/content/AbstractThreadedSyncAdapter:access$300	(Landroid/content/AbstractThreadedSyncAdapter;)Ljava/util/HashMap;
      //   186: aload_0
      //   187: getfield 38	android/content/AbstractThreadedSyncAdapter$SyncThread:mThreadsKey	Landroid/accounts/Account;
      //   190: invokevirtual 98	java/util/HashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
      //   193: pop
      //   194: aload 9
      //   196: monitorexit
      //   197: return
      //   198: astore 10
      //   200: aload 9
      //   202: monitorexit
      //   203: aload 10
      //   205: athrow
      //   206: aload_1
      //   207: iconst_1
      //   208: putfield 127	android/content/SyncResult:databaseError	Z
      //   211: goto -74 -> 137
      //   214: astore_3
      //   215: ldc2_w 61
      //   218: invokestatic 78	android/os/Trace:traceEnd	(J)V
      //   221: aload_2
      //   222: ifnull +8 -> 230
      //   225: aload_2
      //   226: invokevirtual 123	android/content/ContentProviderClient:release	()Z
      //   229: pop
      //   230: aload_0
      //   231: invokespecial 74	android/content/AbstractThreadedSyncAdapter$SyncThread:isCanceled	()Z
      //   234: ifne +11 -> 245
      //   237: aload_0
      //   238: getfield 24	android/content/AbstractThreadedSyncAdapter$SyncThread:mSyncContext	Landroid/content/SyncContext;
      //   241: aload_1
      //   242: invokevirtual 84	android/content/SyncContext:onFinished	(Landroid/content/SyncResult;)V
      //   245: aload_0
      //   246: getfield 19	android/content/AbstractThreadedSyncAdapter$SyncThread:this$0	Landroid/content/AbstractThreadedSyncAdapter;
      //   249: invokestatic 88	android/content/AbstractThreadedSyncAdapter:access$200	(Landroid/content/AbstractThreadedSyncAdapter;)Ljava/lang/Object;
      //   252: astore 4
      //   254: aload 4
      //   256: monitorenter
      //   257: aload_0
      //   258: getfield 19	android/content/AbstractThreadedSyncAdapter$SyncThread:this$0	Landroid/content/AbstractThreadedSyncAdapter;
      //   261: invokestatic 92	android/content/AbstractThreadedSyncAdapter:access$300	(Landroid/content/AbstractThreadedSyncAdapter;)Ljava/util/HashMap;
      //   264: aload_0
      //   265: getfield 38	android/content/AbstractThreadedSyncAdapter$SyncThread:mThreadsKey	Landroid/accounts/Account;
      //   268: invokevirtual 98	java/util/HashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
      //   271: pop
      //   272: aload 4
      //   274: monitorexit
      //   275: aload_3
      //   276: athrow
      //   277: astore 5
      //   279: aload 4
      //   281: monitorexit
      //   282: aload 5
      //   284: athrow
      //   285: astore 14
      //   287: aload 13
      //   289: monitorexit
      //   290: aload 14
      //   292: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	293	0	this	SyncThread
      //   22	220	1	localSyncResult	SyncResult
      //   24	202	2	localContentProviderClient	ContentProviderClient
      //   214	62	3	localObject1	Object
      //   277	6	5	localObject3	Object
      //   29	3	8	bool	boolean
      //   198	6	10	localObject5	Object
      //   285	6	14	localObject7	Object
      // Exception table:
      //   from	to	target	type
      //   179	197	198	finally
      //   200	203	198	finally
      //   25	31	214	finally
      //   94	112	214	finally
      //   116	137	214	finally
      //   206	211	214	finally
      //   257	275	277	finally
      //   279	282	277	finally
      //   75	93	285	finally
      //   287	290	285	finally
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\AbstractThreadedSyncAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.content;

import android.content.res.AssetFileDescriptor;
import android.database.BulkCursorDescriptor;
import android.database.Cursor;
import android.database.CursorToBulkCursorAdaptor;
import android.database.DatabaseUtils;
import android.database.IContentObserver;
import android.database.IContentObserver.Stub;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.ICancellationSignal;
import android.os.ICancellationSignal.Stub;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import java.util.ArrayList;

public abstract class ContentProviderNative
  extends Binder
  implements IContentProvider
{
  public ContentProviderNative()
  {
    attachInterface(this, "android.content.IContentProvider");
  }
  
  public static IContentProvider asInterface(IBinder paramIBinder)
  {
    IContentProvider localIContentProvider;
    if (paramIBinder == null) {
      localIContentProvider = null;
    }
    do
    {
      return localIContentProvider;
      localIContentProvider = (IContentProvider)paramIBinder.queryLocalInterface("android.content.IContentProvider");
    } while (localIContentProvider != null);
    return new ContentProviderProxy(paramIBinder);
  }
  
  public IBinder asBinder()
  {
    return this;
  }
  
  public abstract String getProviderName();
  
  public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
    throws RemoteException
  {
    switch (paramInt1)
    {
    case 5: 
    case 6: 
    case 7: 
    case 8: 
    case 9: 
    case 11: 
    case 12: 
    case 16: 
    case 17: 
    case 18: 
    case 19: 
    default: 
      return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
    case 1: 
      try
      {
        paramParcel1.enforceInterface("android.content.IContentProvider");
        Uri localUri2 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
        int i1 = paramParcel1.readInt();
        String[] arrayOfString2 = null;
        if (i1 > 0)
        {
          arrayOfString2 = new String[i1];
          for (int i2 = 0; i2 < i1; i2++) {
            arrayOfString2[i2] = paramParcel1.readString();
          }
        }
        String str2 = paramParcel1.readString();
        int i3 = paramParcel1.readInt();
        String[] arrayOfString3 = null;
        if (i3 > 0)
        {
          arrayOfString3 = new String[i3];
          for (int i4 = 0; i4 < i3; i4++) {
            arrayOfString3[i4] = paramParcel1.readString();
          }
        }
        String str3 = paramParcel1.readString();
        IContentObserver localIContentObserver = IContentObserver.Stub.asInterface(paramParcel1.readStrongBinder());
        Cursor localCursor = query(localUri2, arrayOfString2, str2, arrayOfString3, str3, ICancellationSignal.Stub.asInterface(paramParcel1.readStrongBinder()));
        if (localCursor != null)
        {
          BulkCursorDescriptor localBulkCursorDescriptor = new CursorToBulkCursorAdaptor(localCursor, localIContentObserver, getProviderName()).getBulkCursorDescriptor();
          paramParcel2.writeNoException();
          paramParcel2.writeInt(1);
          localBulkCursorDescriptor.writeToParcel(paramParcel2, 1);
        }
        else
        {
          paramParcel2.writeNoException();
          paramParcel2.writeInt(0);
        }
      }
      catch (Exception localException)
      {
        DatabaseUtils.writeExceptionToParcel(paramParcel2, localException);
        return true;
      }
    case 2: 
      paramParcel1.enforceInterface("android.content.IContentProvider");
      String str1 = getType((Uri)Uri.CREATOR.createFromParcel(paramParcel1));
      paramParcel2.writeNoException();
      paramParcel2.writeString(str1);
      return true;
    case 3: 
      paramParcel1.enforceInterface("android.content.IContentProvider");
      Uri localUri1 = insert((Uri)Uri.CREATOR.createFromParcel(paramParcel1), (ContentValues)ContentValues.CREATOR.createFromParcel(paramParcel1));
      paramParcel2.writeNoException();
      Uri.writeToParcel(paramParcel2, localUri1);
      return true;
    case 13: 
      paramParcel1.enforceInterface("android.content.IContentProvider");
      int n = bulkInsert((Uri)Uri.CREATOR.createFromParcel(paramParcel1), (ContentValues[])paramParcel1.createTypedArray(ContentValues.CREATOR));
      paramParcel2.writeNoException();
      paramParcel2.writeInt(n);
      return true;
    case 20: 
      paramParcel1.enforceInterface("android.content.IContentProvider");
      int k = paramParcel1.readInt();
      ArrayList localArrayList = new ArrayList(k);
      for (int m = 0; m < k; m++)
      {
        Object localObject = ContentProviderOperation.CREATOR.createFromParcel(paramParcel1);
        localArrayList.add(m, localObject);
      }
      ContentProviderResult[] arrayOfContentProviderResult = applyBatch(localArrayList);
      paramParcel2.writeNoException();
      paramParcel2.writeTypedArray(arrayOfContentProviderResult, 0);
      return true;
    case 4: 
      paramParcel1.enforceInterface("android.content.IContentProvider");
      int j = delete((Uri)Uri.CREATOR.createFromParcel(paramParcel1), paramParcel1.readString(), paramParcel1.readStringArray());
      paramParcel2.writeNoException();
      paramParcel2.writeInt(j);
      return true;
    case 10: 
      paramParcel1.enforceInterface("android.content.IContentProvider");
      int i = update((Uri)Uri.CREATOR.createFromParcel(paramParcel1), (ContentValues)ContentValues.CREATOR.createFromParcel(paramParcel1), paramParcel1.readString(), paramParcel1.readStringArray());
      paramParcel2.writeNoException();
      paramParcel2.writeInt(i);
      return true;
    case 14: 
      paramParcel1.enforceInterface("android.content.IContentProvider");
      ParcelFileDescriptor localParcelFileDescriptor = openFile((Uri)Uri.CREATOR.createFromParcel(paramParcel1), paramParcel1.readString());
      paramParcel2.writeNoException();
      if (localParcelFileDescriptor != null)
      {
        paramParcel2.writeInt(1);
        localParcelFileDescriptor.writeToParcel(paramParcel2, 1);
      }
      else
      {
        paramParcel2.writeInt(0);
      }
      break;
    case 15: 
      paramParcel1.enforceInterface("android.content.IContentProvider");
      AssetFileDescriptor localAssetFileDescriptor2 = openAssetFile((Uri)Uri.CREATOR.createFromParcel(paramParcel1), paramParcel1.readString());
      paramParcel2.writeNoException();
      if (localAssetFileDescriptor2 != null)
      {
        paramParcel2.writeInt(1);
        localAssetFileDescriptor2.writeToParcel(paramParcel2, 1);
      }
      else
      {
        paramParcel2.writeInt(0);
      }
      break;
    case 21: 
      paramParcel1.enforceInterface("android.content.IContentProvider");
      Bundle localBundle = call(paramParcel1.readString(), paramParcel1.readString(), paramParcel1.readBundle());
      paramParcel2.writeNoException();
      paramParcel2.writeBundle(localBundle);
      return true;
    case 22: 
      paramParcel1.enforceInterface("android.content.IContentProvider");
      String[] arrayOfString1 = getStreamTypes((Uri)Uri.CREATOR.createFromParcel(paramParcel1), paramParcel1.readString());
      paramParcel2.writeNoException();
      paramParcel2.writeStringArray(arrayOfString1);
      return true;
    case 23: 
      paramParcel1.enforceInterface("android.content.IContentProvider");
      AssetFileDescriptor localAssetFileDescriptor1 = openTypedAssetFile((Uri)Uri.CREATOR.createFromParcel(paramParcel1), paramParcel1.readString(), paramParcel1.readBundle());
      paramParcel2.writeNoException();
      if (localAssetFileDescriptor1 != null)
      {
        paramParcel2.writeInt(1);
        localAssetFileDescriptor1.writeToParcel(paramParcel2, 1);
      }
      else
      {
        paramParcel2.writeInt(0);
      }
      break;
    case 24: 
      paramParcel1.enforceInterface("android.content.IContentProvider");
      ICancellationSignal localICancellationSignal = createCancellationSignal();
      paramParcel2.writeNoException();
      paramParcel2.writeStrongBinder(localICancellationSignal.asBinder());
      return true;
    }
    return true;
    return true;
    return true;
    return true;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\ContentProviderNative.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
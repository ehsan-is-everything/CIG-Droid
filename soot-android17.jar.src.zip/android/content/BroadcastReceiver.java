package android.content;

import android.app.ActivityManagerNative;
import android.app.IActivityManager;
import android.app.QueuedWork;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import java.util.concurrent.ExecutorService;

public abstract class BroadcastReceiver
{
  private boolean mDebugUnregister;
  private PendingResult mPendingResult;
  
  public final void abortBroadcast()
  {
    checkSynchronousHint();
    this.mPendingResult.mAbortBroadcast = true;
  }
  
  void checkSynchronousHint()
  {
    if (this.mPendingResult == null) {
      throw new IllegalStateException("Call while result is not pending");
    }
    if ((this.mPendingResult.mOrderedHint) || (this.mPendingResult.mInitialStickyHint)) {
      return;
    }
    RuntimeException localRuntimeException = new RuntimeException("BroadcastReceiver trying to return result during a non-ordered broadcast");
    localRuntimeException.fillInStackTrace();
    Log.e("BroadcastReceiver", localRuntimeException.getMessage(), localRuntimeException);
  }
  
  public final void clearAbortBroadcast()
  {
    if (this.mPendingResult != null) {
      this.mPendingResult.mAbortBroadcast = false;
    }
  }
  
  public final boolean getAbortBroadcast()
  {
    if (this.mPendingResult != null) {
      return this.mPendingResult.mAbortBroadcast;
    }
    return false;
  }
  
  public final boolean getDebugUnregister()
  {
    return this.mDebugUnregister;
  }
  
  public final PendingResult getPendingResult()
  {
    return this.mPendingResult;
  }
  
  public final int getResultCode()
  {
    if (this.mPendingResult != null) {
      return this.mPendingResult.mResultCode;
    }
    return 0;
  }
  
  public final String getResultData()
  {
    if (this.mPendingResult != null) {
      return this.mPendingResult.mResultData;
    }
    return null;
  }
  
  public final Bundle getResultExtras(boolean paramBoolean)
  {
    Bundle localBundle1;
    if (this.mPendingResult == null) {
      localBundle1 = null;
    }
    do
    {
      return localBundle1;
      localBundle1 = this.mPendingResult.mResultExtras;
    } while ((!paramBoolean) || (localBundle1 != null));
    PendingResult localPendingResult = this.mPendingResult;
    Bundle localBundle2 = new Bundle();
    localPendingResult.mResultExtras = localBundle2;
    return localBundle2;
  }
  
  public int getSendingUserId()
  {
    return this.mPendingResult.mSendingUser;
  }
  
  public final PendingResult goAsync()
  {
    PendingResult localPendingResult = this.mPendingResult;
    this.mPendingResult = null;
    return localPendingResult;
  }
  
  public final boolean isInitialStickyBroadcast()
  {
    if (this.mPendingResult != null) {
      return this.mPendingResult.mInitialStickyHint;
    }
    return false;
  }
  
  public final boolean isOrderedBroadcast()
  {
    if (this.mPendingResult != null) {
      return this.mPendingResult.mOrderedHint;
    }
    return false;
  }
  
  public abstract void onReceive(Context paramContext, Intent paramIntent);
  
  public IBinder peekService(Context paramContext, Intent paramIntent)
  {
    IActivityManager localIActivityManager = ActivityManagerNative.getDefault();
    try
    {
      paramIntent.setAllowFds(false);
      IBinder localIBinder = localIActivityManager.peekService(paramIntent, paramIntent.resolveTypeIfNeeded(paramContext.getContentResolver()));
      return localIBinder;
    }
    catch (RemoteException localRemoteException) {}
    return null;
  }
  
  public final void setDebugUnregister(boolean paramBoolean)
  {
    this.mDebugUnregister = paramBoolean;
  }
  
  public final void setOrderedHint(boolean paramBoolean) {}
  
  public final void setPendingResult(PendingResult paramPendingResult)
  {
    this.mPendingResult = paramPendingResult;
  }
  
  public final void setResult(int paramInt, String paramString, Bundle paramBundle)
  {
    checkSynchronousHint();
    this.mPendingResult.mResultCode = paramInt;
    this.mPendingResult.mResultData = paramString;
    this.mPendingResult.mResultExtras = paramBundle;
  }
  
  public final void setResultCode(int paramInt)
  {
    checkSynchronousHint();
    this.mPendingResult.mResultCode = paramInt;
  }
  
  public final void setResultData(String paramString)
  {
    checkSynchronousHint();
    this.mPendingResult.mResultData = paramString;
  }
  
  public final void setResultExtras(Bundle paramBundle)
  {
    checkSynchronousHint();
    this.mPendingResult.mResultExtras = paramBundle;
  }
  
  public static class PendingResult
  {
    public static final int TYPE_COMPONENT = 0;
    public static final int TYPE_REGISTERED = 1;
    public static final int TYPE_UNREGISTERED = 2;
    boolean mAbortBroadcast;
    boolean mFinished;
    final boolean mInitialStickyHint;
    final boolean mOrderedHint;
    int mResultCode;
    String mResultData;
    Bundle mResultExtras;
    final int mSendingUser;
    final IBinder mToken;
    final int mType;
    
    public PendingResult(int paramInt1, String paramString, Bundle paramBundle, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, IBinder paramIBinder, int paramInt3)
    {
      this.mResultCode = paramInt1;
      this.mResultData = paramString;
      this.mResultExtras = paramBundle;
      this.mType = paramInt2;
      this.mOrderedHint = paramBoolean1;
      this.mInitialStickyHint = paramBoolean2;
      this.mToken = paramIBinder;
      this.mSendingUser = paramInt3;
    }
    
    public final void abortBroadcast()
    {
      checkSynchronousHint();
      this.mAbortBroadcast = true;
    }
    
    void checkSynchronousHint()
    {
      if ((this.mOrderedHint) || (this.mInitialStickyHint)) {
        return;
      }
      RuntimeException localRuntimeException = new RuntimeException("BroadcastReceiver trying to return result during a non-ordered broadcast");
      localRuntimeException.fillInStackTrace();
      Log.e("BroadcastReceiver", localRuntimeException.getMessage(), localRuntimeException);
    }
    
    public final void clearAbortBroadcast()
    {
      this.mAbortBroadcast = false;
    }
    
    public final void finish()
    {
      if (this.mType == 0)
      {
        localIActivityManager = ActivityManagerNative.getDefault();
        if (QueuedWork.hasPendingWork()) {
          QueuedWork.singleThreadExecutor().execute(new Runnable()
          {
            public void run()
            {
              BroadcastReceiver.PendingResult.this.sendFinished(localIActivityManager);
            }
          });
        }
      }
      while ((!this.mOrderedHint) || (this.mType == 2))
      {
        final IActivityManager localIActivityManager;
        return;
        sendFinished(localIActivityManager);
        return;
      }
      sendFinished(ActivityManagerNative.getDefault());
    }
    
    public final boolean getAbortBroadcast()
    {
      return this.mAbortBroadcast;
    }
    
    public final int getResultCode()
    {
      return this.mResultCode;
    }
    
    public final String getResultData()
    {
      return this.mResultData;
    }
    
    public final Bundle getResultExtras(boolean paramBoolean)
    {
      Bundle localBundle = this.mResultExtras;
      if (!paramBoolean) {
        return localBundle;
      }
      if (localBundle == null)
      {
        localBundle = new Bundle();
        this.mResultExtras = localBundle;
      }
      return localBundle;
    }
    
    public int getSendingUserId()
    {
      return this.mSendingUser;
    }
    
    public void sendFinished(IActivityManager paramIActivityManager)
    {
      try
      {
        if (this.mFinished) {
          throw new IllegalStateException("Broadcast already finished");
        }
      }
      finally {}
      this.mFinished = true;
      for (;;)
      {
        try
        {
          if (this.mResultExtras != null) {
            this.mResultExtras.setAllowFds(false);
          }
          if (!this.mOrderedHint) {
            continue;
          }
          paramIActivityManager.finishReceiver(this.mToken, this.mResultCode, this.mResultData, this.mResultExtras, this.mAbortBroadcast);
        }
        catch (RemoteException localRemoteException)
        {
          continue;
        }
        return;
        paramIActivityManager.finishReceiver(this.mToken, 0, null, null, false);
      }
    }
    
    public void setExtrasClassLoader(ClassLoader paramClassLoader)
    {
      if (this.mResultExtras != null) {
        this.mResultExtras.setClassLoader(paramClassLoader);
      }
    }
    
    public final void setResult(int paramInt, String paramString, Bundle paramBundle)
    {
      checkSynchronousHint();
      this.mResultCode = paramInt;
      this.mResultData = paramString;
      this.mResultExtras = paramBundle;
    }
    
    public final void setResultCode(int paramInt)
    {
      checkSynchronousHint();
      this.mResultCode = paramInt;
    }
    
    public final void setResultData(String paramString)
    {
      checkSynchronousHint();
      this.mResultData = paramString;
    }
    
    public final void setResultExtras(Bundle paramBundle)
    {
      checkSynchronousHint();
      this.mResultExtras = paramBundle;
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\BroadcastReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
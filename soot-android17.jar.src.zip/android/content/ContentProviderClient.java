package android.content;

import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.DeadObjectException;
import android.os.ICancellationSignal;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class ContentProviderClient
{
  private final IContentProvider mContentProvider;
  private final ContentResolver mContentResolver;
  private boolean mReleased;
  private final boolean mStable;
  
  ContentProviderClient(ContentResolver paramContentResolver, IContentProvider paramIContentProvider, boolean paramBoolean)
  {
    this.mContentProvider = paramIContentProvider;
    this.mContentResolver = paramContentResolver;
    this.mStable = paramBoolean;
  }
  
  public ContentProviderResult[] applyBatch(ArrayList<ContentProviderOperation> paramArrayList)
    throws RemoteException, OperationApplicationException
  {
    try
    {
      ContentProviderResult[] arrayOfContentProviderResult = this.mContentProvider.applyBatch(paramArrayList);
      return arrayOfContentProviderResult;
    }
    catch (DeadObjectException localDeadObjectException)
    {
      if (!this.mStable) {
        this.mContentResolver.unstableProviderDied(this.mContentProvider);
      }
      throw localDeadObjectException;
    }
  }
  
  public int bulkInsert(Uri paramUri, ContentValues[] paramArrayOfContentValues)
    throws RemoteException
  {
    try
    {
      int i = this.mContentProvider.bulkInsert(paramUri, paramArrayOfContentValues);
      return i;
    }
    catch (DeadObjectException localDeadObjectException)
    {
      if (!this.mStable) {
        this.mContentResolver.unstableProviderDied(this.mContentProvider);
      }
      throw localDeadObjectException;
    }
  }
  
  public Bundle call(String paramString1, String paramString2, Bundle paramBundle)
    throws RemoteException
  {
    try
    {
      Bundle localBundle = this.mContentProvider.call(paramString1, paramString2, paramBundle);
      return localBundle;
    }
    catch (DeadObjectException localDeadObjectException)
    {
      if (!this.mStable) {
        this.mContentResolver.unstableProviderDied(this.mContentProvider);
      }
      throw localDeadObjectException;
    }
  }
  
  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString)
    throws RemoteException
  {
    try
    {
      int i = this.mContentProvider.delete(paramUri, paramString, paramArrayOfString);
      return i;
    }
    catch (DeadObjectException localDeadObjectException)
    {
      if (!this.mStable) {
        this.mContentResolver.unstableProviderDied(this.mContentProvider);
      }
      throw localDeadObjectException;
    }
  }
  
  public ContentProvider getLocalContentProvider()
  {
    return ContentProvider.coerceToLocalContentProvider(this.mContentProvider);
  }
  
  public String[] getStreamTypes(Uri paramUri, String paramString)
    throws RemoteException
  {
    try
    {
      String[] arrayOfString = this.mContentProvider.getStreamTypes(paramUri, paramString);
      return arrayOfString;
    }
    catch (DeadObjectException localDeadObjectException)
    {
      if (!this.mStable) {
        this.mContentResolver.unstableProviderDied(this.mContentProvider);
      }
      throw localDeadObjectException;
    }
  }
  
  public String getType(Uri paramUri)
    throws RemoteException
  {
    try
    {
      String str = this.mContentProvider.getType(paramUri);
      return str;
    }
    catch (DeadObjectException localDeadObjectException)
    {
      if (!this.mStable) {
        this.mContentResolver.unstableProviderDied(this.mContentProvider);
      }
      throw localDeadObjectException;
    }
  }
  
  public Uri insert(Uri paramUri, ContentValues paramContentValues)
    throws RemoteException
  {
    try
    {
      Uri localUri = this.mContentProvider.insert(paramUri, paramContentValues);
      return localUri;
    }
    catch (DeadObjectException localDeadObjectException)
    {
      if (!this.mStable) {
        this.mContentResolver.unstableProviderDied(this.mContentProvider);
      }
      throw localDeadObjectException;
    }
  }
  
  public AssetFileDescriptor openAssetFile(Uri paramUri, String paramString)
    throws RemoteException, FileNotFoundException
  {
    try
    {
      AssetFileDescriptor localAssetFileDescriptor = this.mContentProvider.openAssetFile(paramUri, paramString);
      return localAssetFileDescriptor;
    }
    catch (DeadObjectException localDeadObjectException)
    {
      if (!this.mStable) {
        this.mContentResolver.unstableProviderDied(this.mContentProvider);
      }
      throw localDeadObjectException;
    }
  }
  
  public ParcelFileDescriptor openFile(Uri paramUri, String paramString)
    throws RemoteException, FileNotFoundException
  {
    try
    {
      ParcelFileDescriptor localParcelFileDescriptor = this.mContentProvider.openFile(paramUri, paramString);
      return localParcelFileDescriptor;
    }
    catch (DeadObjectException localDeadObjectException)
    {
      if (!this.mStable) {
        this.mContentResolver.unstableProviderDied(this.mContentProvider);
      }
      throw localDeadObjectException;
    }
  }
  
  public final AssetFileDescriptor openTypedAssetFileDescriptor(Uri paramUri, String paramString, Bundle paramBundle)
    throws RemoteException, FileNotFoundException
  {
    try
    {
      AssetFileDescriptor localAssetFileDescriptor = this.mContentProvider.openTypedAssetFile(paramUri, paramString, paramBundle);
      return localAssetFileDescriptor;
    }
    catch (DeadObjectException localDeadObjectException)
    {
      if (!this.mStable) {
        this.mContentResolver.unstableProviderDied(this.mContentProvider);
      }
      throw localDeadObjectException;
    }
  }
  
  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
    throws RemoteException
  {
    try
    {
      Cursor localCursor = query(paramUri, paramArrayOfString1, paramString1, paramArrayOfString2, paramString2, null);
      return localCursor;
    }
    catch (DeadObjectException localDeadObjectException)
    {
      if (!this.mStable) {
        this.mContentResolver.unstableProviderDied(this.mContentProvider);
      }
      throw localDeadObjectException;
    }
  }
  
  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2, CancellationSignal paramCancellationSignal)
    throws RemoteException
  {
    ICancellationSignal localICancellationSignal = null;
    if (paramCancellationSignal != null)
    {
      localICancellationSignal = this.mContentProvider.createCancellationSignal();
      paramCancellationSignal.setRemote(localICancellationSignal);
    }
    try
    {
      Cursor localCursor = this.mContentProvider.query(paramUri, paramArrayOfString1, paramString1, paramArrayOfString2, paramString2, localICancellationSignal);
      return localCursor;
    }
    catch (DeadObjectException localDeadObjectException)
    {
      if (!this.mStable) {
        this.mContentResolver.unstableProviderDied(this.mContentProvider);
      }
      throw localDeadObjectException;
    }
  }
  
  public boolean release()
  {
    try
    {
      if (this.mReleased) {
        throw new IllegalStateException("Already released");
      }
    }
    finally {}
    this.mReleased = true;
    if (this.mStable)
    {
      boolean bool2 = this.mContentResolver.releaseProvider(this.mContentProvider);
      return bool2;
    }
    boolean bool1 = this.mContentResolver.releaseUnstableProvider(this.mContentProvider);
    return bool1;
  }
  
  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString)
    throws RemoteException
  {
    try
    {
      int i = this.mContentProvider.update(paramUri, paramContentValues, paramString, paramArrayOfString);
      return i;
    }
    catch (DeadObjectException localDeadObjectException)
    {
      if (!this.mStable) {
        this.mContentResolver.unstableProviderDied(this.mContentProvider);
      }
      throw localDeadObjectException;
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\ContentProviderClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
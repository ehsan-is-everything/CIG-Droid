package android.content;

import android.accounts.Account;
import android.accounts.AccountAndUser;
import android.accounts.AccountManagerService;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.RegisteredServicesCache.ServiceInfo;
import android.content.pm.RegisteredServicesCacheListener;
import android.content.pm.ResolveInfo;
import android.content.pm.UserInfo;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.IBinder.DeathRecipient;
import android.os.Looper;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.RemoteException;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.os.UserHandle;
import android.os.UserManager;
import android.os.WorkSource;
import android.provider.Settings.Global;
import android.text.format.DateUtils;
import android.text.format.Time;
import android.util.EventLog;
import android.util.Log;
import android.util.Pair;
import com.android.internal.util.IndentingPrintWriter;
import com.google.android.collect.Lists;
import com.google.android.collect.Maps;
import com.google.android.collect.Sets;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.CountDownLatch;

public class SyncManager
{
  private static final String ACTION_SYNC_ALARM = "android.content.syncmanager.SYNC_ALARM";
  private static final long DEFAULT_MAX_SYNC_RETRY_TIME_IN_SECONDS = 3600L;
  private static final int DELAY_RETRY_SYNC_IN_PROGRESS_IN_SECONDS = 10;
  private static final String HANDLE_SYNC_ALARM_WAKE_LOCK = "SyncManagerHandleSyncAlarm";
  private static final int INITIALIZATION_UNBIND_DELAY_MS = 5000;
  private static final AccountAndUser[] INITIAL_ACCOUNTS_ARRAY;
  private static final long INITIAL_SYNC_RETRY_TIME_IN_MS = 30000L;
  private static final long LOCAL_SYNC_DELAY = 0L;
  private static final int MAX_SIMULTANEOUS_INITIALIZATION_SYNCS = 0;
  private static final int MAX_SIMULTANEOUS_REGULAR_SYNCS = 0;
  private static final long MAX_TIME_PER_SYNC = 0L;
  private static final long SYNC_ALARM_TIMEOUT_MAX = 7200000L;
  private static final long SYNC_ALARM_TIMEOUT_MIN = 30000L;
  private static final String SYNC_LOOP_WAKE_LOCK = "SyncLoopWakeLock";
  private static final long SYNC_NOTIFICATION_DELAY = 0L;
  private static final String SYNC_WAKE_LOCK_PREFIX = "*sync*";
  private static final String TAG = "SyncManager";
  private BroadcastReceiver mAccountsUpdatedReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      SyncManager.this.updateRunningAccounts();
      SyncManager.this.scheduleSync(null, -1, null, null, 0L, false);
    }
  };
  protected final ArrayList<ActiveSyncContext> mActiveSyncContexts = Lists.newArrayList();
  private AlarmManager mAlarmService = null;
  private BroadcastReceiver mBackgroundDataSettingChanged = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      if (SyncManager.this.getConnectivityManager().getBackgroundDataSetting()) {
        SyncManager.this.scheduleSync(null, -1, null, new Bundle(), 0L, false);
      }
    }
  };
  private volatile boolean mBootCompleted = false;
  private BroadcastReceiver mBootCompletedReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      SyncManager.this.mSyncHandler.onBootCompleted();
    }
  };
  private ConnectivityManager mConnManagerDoNotUseDirectly;
  private BroadcastReceiver mConnectivityIntentReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      boolean bool = SyncManager.this.mDataConnectionIsConnected;
      SyncManager.access$402(SyncManager.this, SyncManager.this.readDataConnectionState());
      if (SyncManager.this.mDataConnectionIsConnected)
      {
        if (!bool)
        {
          if (Log.isLoggable("SyncManager", 2)) {
            Log.v("SyncManager", "Reconnection detected: clearing all backoffs");
          }
          SyncManager.this.mSyncStorageEngine.clearAllBackoffs(SyncManager.this.mSyncQueue);
        }
        SyncManager.this.sendCheckAlarmsMessage();
      }
    }
  };
  private Context mContext;
  private volatile boolean mDataConnectionIsConnected = false;
  private volatile PowerManager.WakeLock mHandleAlarmWakeLock;
  private boolean mNeedSyncActiveNotification = false;
  private final NotificationManager mNotificationMgr;
  private final PowerManager mPowerManager;
  private volatile AccountAndUser[] mRunningAccounts = INITIAL_ACCOUNTS_ARRAY;
  private BroadcastReceiver mShutdownIntentReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      Log.w("SyncManager", "Writing sync state before shutdown...");
      SyncManager.this.getSyncStorageEngine().writeAllState();
    }
  };
  private BroadcastReceiver mStorageIntentReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      String str = paramAnonymousIntent.getAction();
      if ("android.intent.action.DEVICE_STORAGE_LOW".equals(str))
      {
        if (Log.isLoggable("SyncManager", 2)) {
          Log.v("SyncManager", "Internal storage is low.");
        }
        SyncManager.access$002(SyncManager.this, true);
        SyncManager.this.cancelActiveSync(null, -1, null);
      }
      while (!"android.intent.action.DEVICE_STORAGE_OK".equals(str)) {
        return;
      }
      if (Log.isLoggable("SyncManager", 2)) {
        Log.v("SyncManager", "Internal storage is ok.");
      }
      SyncManager.access$002(SyncManager.this, false);
      SyncManager.this.sendCheckAlarmsMessage();
    }
  };
  private volatile boolean mStorageIsLow = false;
  protected SyncAdaptersCache mSyncAdapters;
  private final PendingIntent mSyncAlarmIntent;
  private final SyncHandler mSyncHandler;
  private volatile PowerManager.WakeLock mSyncManagerWakeLock;
  private final SyncQueue mSyncQueue;
  private int mSyncRandomOffsetMillis;
  private SyncStorageEngine mSyncStorageEngine;
  private BroadcastReceiver mUserIntentReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      String str = paramAnonymousIntent.getAction();
      int i = paramAnonymousIntent.getIntExtra("android.intent.extra.user_handle", 55536);
      if (i == 55536) {}
      do
      {
        return;
        if ("android.intent.action.USER_REMOVED".equals(str))
        {
          SyncManager.this.onUserRemoved(i);
          return;
        }
        if ("android.intent.action.USER_STARTING".equals(str))
        {
          SyncManager.this.onUserStarting(i);
          return;
        }
      } while (!"android.intent.action.USER_STOPPING".equals(str));
      SyncManager.this.onUserStopping(i);
    }
  };
  private final UserManager mUserManager;
  
  static
  {
    int i = 2;
    boolean bool = ActivityManager.isLargeRAM();
    int j;
    if (bool)
    {
      j = 5;
      if (!bool) {
        break label80;
      }
    }
    for (;;)
    {
      MAX_SIMULTANEOUS_INITIALIZATION_SYNCS = SystemProperties.getInt("sync.max_init_syncs", j);
      MAX_SIMULTANEOUS_REGULAR_SYNCS = SystemProperties.getInt("sync.max_regular_syncs", i);
      LOCAL_SYNC_DELAY = SystemProperties.getLong("sync.local_sync_delay", 30000L);
      MAX_TIME_PER_SYNC = SystemProperties.getLong("sync.max_time_per_sync", 300000L);
      SYNC_NOTIFICATION_DELAY = SystemProperties.getLong("sync.notification_delay", 30000L);
      INITIAL_ACCOUNTS_ARRAY = new AccountAndUser[0];
      return;
      j = i;
      break;
      label80:
      i = 1;
    }
  }
  
  public SyncManager(Context paramContext, boolean paramBoolean)
  {
    this.mContext = paramContext;
    SyncStorageEngine.init(paramContext);
    this.mSyncStorageEngine = SyncStorageEngine.getSingleton();
    this.mSyncStorageEngine.setOnSyncRequestListener(new SyncStorageEngine.OnSyncRequestListener()
    {
      public void onSyncRequest(Account paramAnonymousAccount, int paramAnonymousInt, String paramAnonymousString, Bundle paramAnonymousBundle)
      {
        SyncManager.this.scheduleSync(paramAnonymousAccount, paramAnonymousInt, paramAnonymousString, paramAnonymousBundle, 0L, false);
      }
    });
    this.mSyncAdapters = new SyncAdaptersCache(this.mContext);
    this.mSyncQueue = new SyncQueue(this.mSyncStorageEngine, this.mSyncAdapters);
    HandlerThread localHandlerThread = new HandlerThread("SyncHandlerThread", 10);
    localHandlerThread.start();
    this.mSyncHandler = new SyncHandler(localHandlerThread.getLooper());
    this.mSyncAdapters.setListener(new RegisteredServicesCacheListener()
    {
      public void onServiceChanged(SyncAdapterType paramAnonymousSyncAdapterType, int paramAnonymousInt, boolean paramAnonymousBoolean)
      {
        if (!paramAnonymousBoolean) {
          SyncManager.this.scheduleSync(null, -1, paramAnonymousSyncAdapterType.authority, null, 0L, false);
        }
      }
    }, this.mSyncHandler);
    this.mSyncAlarmIntent = PendingIntent.getBroadcast(this.mContext, 0, new Intent("android.content.syncmanager.SYNC_ALARM"), 0);
    IntentFilter localIntentFilter1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
    paramContext.registerReceiver(this.mConnectivityIntentReceiver, localIntentFilter1);
    if (!paramBoolean)
    {
      IntentFilter localIntentFilter2 = new IntentFilter("android.intent.action.BOOT_COMPLETED");
      paramContext.registerReceiver(this.mBootCompletedReceiver, localIntentFilter2);
    }
    IntentFilter localIntentFilter3 = new IntentFilter("android.net.conn.BACKGROUND_DATA_SETTING_CHANGED");
    paramContext.registerReceiver(this.mBackgroundDataSettingChanged, localIntentFilter3);
    IntentFilter localIntentFilter4 = new IntentFilter("android.intent.action.DEVICE_STORAGE_LOW");
    localIntentFilter4.addAction("android.intent.action.DEVICE_STORAGE_OK");
    paramContext.registerReceiver(this.mStorageIntentReceiver, localIntentFilter4);
    IntentFilter localIntentFilter5 = new IntentFilter("android.intent.action.ACTION_SHUTDOWN");
    localIntentFilter5.setPriority(100);
    paramContext.registerReceiver(this.mShutdownIntentReceiver, localIntentFilter5);
    IntentFilter localIntentFilter6 = new IntentFilter();
    localIntentFilter6.addAction("android.intent.action.USER_REMOVED");
    localIntentFilter6.addAction("android.intent.action.USER_STARTING");
    localIntentFilter6.addAction("android.intent.action.USER_STOPPING");
    this.mContext.registerReceiverAsUser(this.mUserIntentReceiver, UserHandle.ALL, localIntentFilter6, null, null);
    if (!paramBoolean)
    {
      this.mNotificationMgr = ((NotificationManager)paramContext.getSystemService("notification"));
      paramContext.registerReceiver(new SyncAlarmIntentReceiver(), new IntentFilter("android.content.syncmanager.SYNC_ALARM"));
    }
    for (;;)
    {
      this.mPowerManager = ((PowerManager)paramContext.getSystemService("power"));
      this.mUserManager = ((UserManager)this.mContext.getSystemService("user"));
      this.mHandleAlarmWakeLock = this.mPowerManager.newWakeLock(1, "SyncManagerHandleSyncAlarm");
      this.mHandleAlarmWakeLock.setReferenceCounted(false);
      this.mSyncManagerWakeLock = this.mPowerManager.newWakeLock(1, "SyncLoopWakeLock");
      this.mSyncManagerWakeLock.setReferenceCounted(false);
      this.mSyncStorageEngine.addStatusChangeListener(1, new ISyncStatusObserver.Stub()
      {
        public void onStatusChanged(int paramAnonymousInt)
        {
          SyncManager.this.sendCheckAlarmsMessage();
        }
      });
      if (!paramBoolean) {
        this.mContext.registerReceiverAsUser(this.mAccountsUpdatedReceiver, UserHandle.ALL, new IntentFilter("android.accounts.LOGIN_ACCOUNTS_CHANGED"), null, null);
      }
      this.mSyncRandomOffsetMillis = (1000 * this.mSyncStorageEngine.getSyncRandomOffset());
      return;
      this.mNotificationMgr = null;
    }
  }
  
  private void clearBackoffSetting(SyncOperation paramSyncOperation)
  {
    this.mSyncStorageEngine.setBackoff(paramSyncOperation.account, paramSyncOperation.userId, paramSyncOperation.authority, -1L, -1L);
    synchronized (this.mSyncQueue)
    {
      this.mSyncQueue.onBackoffChanged(paramSyncOperation.account, paramSyncOperation.userId, paramSyncOperation.authority, 0L);
      return;
    }
  }
  
  private boolean containsAccountAndUser(AccountAndUser[] paramArrayOfAccountAndUser, Account paramAccount, int paramInt)
  {
    for (int i = 0;; i++)
    {
      int j = paramArrayOfAccountAndUser.length;
      boolean bool = false;
      if (i < j)
      {
        if ((paramArrayOfAccountAndUser[i].userId == paramInt) && (paramArrayOfAccountAndUser[i].account.equals(paramAccount))) {
          bool = true;
        }
      }
      else {
        return bool;
      }
    }
  }
  
  private void doDatabaseCleanup()
  {
    Iterator localIterator = this.mUserManager.getUsers(true).iterator();
    while (localIterator.hasNext())
    {
      UserInfo localUserInfo = (UserInfo)localIterator.next();
      if (!localUserInfo.partial)
      {
        Account[] arrayOfAccount = AccountManagerService.getSingleton().getAccounts(localUserInfo.id);
        this.mSyncStorageEngine.doDatabaseCleanup(arrayOfAccount, localUserInfo.id);
      }
    }
  }
  
  private void dumpDayStatistic(PrintWriter paramPrintWriter, SyncStorageEngine.DayStats paramDayStats)
  {
    paramPrintWriter.print("Success (");
    paramPrintWriter.print(paramDayStats.successCount);
    if (paramDayStats.successCount > 0)
    {
      paramPrintWriter.print(" for ");
      dumpTimeSec(paramPrintWriter, paramDayStats.successTime);
      paramPrintWriter.print(" avg=");
      dumpTimeSec(paramPrintWriter, paramDayStats.successTime / paramDayStats.successCount);
    }
    paramPrintWriter.print(") Failure (");
    paramPrintWriter.print(paramDayStats.failureCount);
    if (paramDayStats.failureCount > 0)
    {
      paramPrintWriter.print(" for ");
      dumpTimeSec(paramPrintWriter, paramDayStats.failureTime);
      paramPrintWriter.print(" avg=");
      dumpTimeSec(paramPrintWriter, paramDayStats.failureTime / paramDayStats.failureCount);
    }
    paramPrintWriter.println(")");
  }
  
  private void dumpDayStatistics(PrintWriter paramPrintWriter)
  {
    SyncStorageEngine.DayStats[] arrayOfDayStats = this.mSyncStorageEngine.getDayStatistics();
    if ((arrayOfDayStats != null) && (arrayOfDayStats[0] != null))
    {
      paramPrintWriter.println();
      paramPrintWriter.println("Sync Statistics");
      paramPrintWriter.print("  Today:  ");
      dumpDayStatistic(paramPrintWriter, arrayOfDayStats[0]);
      int i = arrayOfDayStats[0].day;
      int j = 1;
      SyncStorageEngine.DayStats localDayStats3;
      label79:
      int k;
      label81:
      label82:
      SyncStorageEngine.DayStats localDayStats1;
      if ((j <= 6) && (j < arrayOfDayStats.length))
      {
        localDayStats3 = arrayOfDayStats[j];
        if (localDayStats3 != null) {}
      }
      else
      {
        k = i;
        break label117;
        if (j >= arrayOfDayStats.length) {
          return;
        }
        localDayStats1 = null;
        k -= 7;
      }
      for (;;)
      {
        SyncStorageEngine.DayStats localDayStats2;
        if (j < arrayOfDayStats.length)
        {
          localDayStats2 = arrayOfDayStats[j];
          if (localDayStats2 == null) {
            j = arrayOfDayStats.length;
          }
        }
        else
        {
          label117:
          if (localDayStats1 == null) {
            break label82;
          }
          paramPrintWriter.print("  Week-");
          paramPrintWriter.print((i - k) / 7);
          paramPrintWriter.print(": ");
          dumpDayStatistic(paramPrintWriter, localDayStats1);
          break label82;
          int m = i - localDayStats3.day;
          if (m > 6) {
            break label79;
          }
          paramPrintWriter.print("  Day-");
          paramPrintWriter.print(m);
          paramPrintWriter.print(":  ");
          dumpDayStatistic(paramPrintWriter, localDayStats3);
          j++;
          break;
        }
        if (k - localDayStats2.day > 6) {
          break label81;
        }
        j++;
        if (localDayStats1 == null) {
          localDayStats1 = new SyncStorageEngine.DayStats(k);
        }
        localDayStats1.successCount += localDayStats2.successCount;
        localDayStats1.successTime += localDayStats2.successTime;
        localDayStats1.failureCount += localDayStats2.failureCount;
        localDayStats1.failureTime += localDayStats2.failureTime;
      }
    }
  }
  
  private void dumpRecentHistory(PrintWriter paramPrintWriter)
  {
    ArrayList localArrayList1 = this.mSyncStorageEngine.getSyncHistory();
    if ((localArrayList1 != null) && (localArrayList1.size() > 0))
    {
      HashMap localHashMap1 = Maps.newHashMap();
      long l1 = 0L;
      long l2 = 0L;
      int i = localArrayList1.size();
      int j = 0;
      int k = 0;
      Iterator localIterator1 = localArrayList1.iterator();
      if (localIterator1.hasNext())
      {
        SyncStorageEngine.SyncHistoryItem localSyncHistoryItem2 = (SyncStorageEngine.SyncHistoryItem)localIterator1.next();
        SyncStorageEngine.AuthorityInfo localAuthorityInfo2 = this.mSyncStorageEngine.getAuthority(localSyncHistoryItem2.authorityId);
        String str13;
        if (localAuthorityInfo2 != null) {
          str13 = localAuthorityInfo2.authority;
        }
        for (String str14 = localAuthorityInfo2.account.name + "/" + localAuthorityInfo2.account.type + " u" + localAuthorityInfo2.userId;; str14 = "Unknown")
        {
          int i4 = str13.length();
          if (i4 > j) {
            j = i4;
          }
          int i5 = str14.length();
          if (i5 > k) {
            k = i5;
          }
          long l9 = localSyncHistoryItem2.elapsedTime;
          l1 += l9;
          l2 += 1L;
          AuthoritySyncStats localAuthoritySyncStats2 = (AuthoritySyncStats)localHashMap1.get(str13);
          if (localAuthoritySyncStats2 == null)
          {
            localAuthoritySyncStats2 = new AuthoritySyncStats(str13, null);
            localHashMap1.put(str13, localAuthoritySyncStats2);
          }
          localAuthoritySyncStats2.elapsedTime = (l9 + localAuthoritySyncStats2.elapsedTime);
          localAuthoritySyncStats2.times = (1 + localAuthoritySyncStats2.times);
          Map localMap = localAuthoritySyncStats2.accountMap;
          AccountSyncStats localAccountSyncStats2 = (AccountSyncStats)localMap.get(str14);
          if (localAccountSyncStats2 == null)
          {
            localAccountSyncStats2 = new AccountSyncStats(str14, null);
            localMap.put(str14, localAccountSyncStats2);
          }
          localAccountSyncStats2.elapsedTime = (l9 + localAccountSyncStats2.elapsedTime);
          localAccountSyncStats2.times = (1 + localAccountSyncStats2.times);
          break;
          str13 = "Unknown";
        }
      }
      if (l1 > 0L)
      {
        paramPrintWriter.println();
        Object[] arrayOfObject6 = new Object[2];
        arrayOfObject6[0] = Long.valueOf(l2);
        arrayOfObject6[1] = Long.valueOf(l1 / 1000L);
        paramPrintWriter.printf("Detailed Statistics (Recent history):  %d (# of times) %ds (sync time)\n", arrayOfObject6);
        ArrayList localArrayList2 = new ArrayList(localHashMap1.values());
        Comparator local11 = new Comparator()
        {
          public int compare(SyncManager.AuthoritySyncStats paramAnonymousAuthoritySyncStats1, SyncManager.AuthoritySyncStats paramAnonymousAuthoritySyncStats2)
          {
            int i = Integer.compare(paramAnonymousAuthoritySyncStats2.times, paramAnonymousAuthoritySyncStats1.times);
            if (i == 0) {
              i = Long.compare(paramAnonymousAuthoritySyncStats2.elapsedTime, paramAnonymousAuthoritySyncStats1.elapsedTime);
            }
            return i;
          }
        };
        Collections.sort(localArrayList2, local11);
        int n = k + 3;
        int i1 = Math.max(j, n);
        char[] arrayOfChar = new char[11 + (10 + (2 + (i1 + 4)))];
        Arrays.fill(arrayOfChar, '-');
        String str6 = new String(arrayOfChar);
        Object[] arrayOfObject7 = new Object[1];
        arrayOfObject7[0] = Integer.valueOf(i1 + 2);
        String str7 = String.format("  %%-%ds: %%-9s  %%-11s\n", arrayOfObject7);
        Object[] arrayOfObject8 = new Object[1];
        arrayOfObject8[0] = Integer.valueOf(i1);
        String str8 = String.format("    %%-%ds:   %%-9s  %%-11s\n", arrayOfObject8);
        paramPrintWriter.println(str6);
        Iterator localIterator2 = localArrayList2.iterator();
        while (localIterator2.hasNext())
        {
          AuthoritySyncStats localAuthoritySyncStats1 = (AuthoritySyncStats)localIterator2.next();
          String str9 = localAuthoritySyncStats1.name;
          long l7 = localAuthoritySyncStats1.elapsedTime;
          int i2 = localAuthoritySyncStats1.times;
          Object[] arrayOfObject9 = new Object[2];
          arrayOfObject9[0] = Long.valueOf(l7 / 1000L);
          arrayOfObject9[1] = Long.valueOf(100L * l7 / l1);
          String str10 = String.format("%ds/%d%%", arrayOfObject9);
          Object[] arrayOfObject10 = new Object[2];
          arrayOfObject10[0] = Integer.valueOf(i2);
          arrayOfObject10[1] = Long.valueOf(i2 * 100 / l2);
          paramPrintWriter.printf(str7, new Object[] { str9, String.format("%d/%d%%", arrayOfObject10), str10 });
          ArrayList localArrayList3 = new ArrayList(localAuthoritySyncStats1.accountMap.values());
          Comparator local12 = new Comparator()
          {
            public int compare(SyncManager.AccountSyncStats paramAnonymousAccountSyncStats1, SyncManager.AccountSyncStats paramAnonymousAccountSyncStats2)
            {
              int i = Integer.compare(paramAnonymousAccountSyncStats2.times, paramAnonymousAccountSyncStats1.times);
              if (i == 0) {
                i = Long.compare(paramAnonymousAccountSyncStats2.elapsedTime, paramAnonymousAccountSyncStats1.elapsedTime);
              }
              return i;
            }
          };
          Collections.sort(localArrayList3, local12);
          Iterator localIterator3 = localArrayList3.iterator();
          while (localIterator3.hasNext())
          {
            AccountSyncStats localAccountSyncStats1 = (AccountSyncStats)localIterator3.next();
            long l8 = localAccountSyncStats1.elapsedTime;
            int i3 = localAccountSyncStats1.times;
            Object[] arrayOfObject11 = new Object[2];
            arrayOfObject11[0] = Long.valueOf(l8 / 1000L);
            arrayOfObject11[1] = Long.valueOf(100L * l8 / l1);
            String str11 = String.format("%ds/%d%%", arrayOfObject11);
            Object[] arrayOfObject12 = new Object[2];
            arrayOfObject12[0] = Integer.valueOf(i3);
            arrayOfObject12[1] = Long.valueOf(i3 * 100 / l2);
            String str12 = String.format("%d/%d%%", arrayOfObject12);
            Object[] arrayOfObject13 = new Object[3];
            arrayOfObject13[0] = localAccountSyncStats1.name;
            arrayOfObject13[1] = str12;
            arrayOfObject13[2] = str11;
            paramPrintWriter.printf(str8, arrayOfObject13);
          }
          paramPrintWriter.println(str6);
        }
      }
      paramPrintWriter.println();
      paramPrintWriter.println("Recent Sync History");
      String str1 = "  %-" + k + "s  %s\n";
      HashMap localHashMap2 = Maps.newHashMap();
      int m = 0;
      if (m < i)
      {
        SyncStorageEngine.SyncHistoryItem localSyncHistoryItem1 = (SyncStorageEngine.SyncHistoryItem)localArrayList1.get(m);
        SyncStorageEngine.AuthorityInfo localAuthorityInfo1 = this.mSyncStorageEngine.getAuthority(localSyncHistoryItem1.authorityId);
        String str2;
        String str3;
        label1071:
        long l3;
        long l4;
        String str4;
        Long localLong;
        String str5;
        if (localAuthorityInfo1 != null)
        {
          str2 = localAuthorityInfo1.authority;
          str3 = localAuthorityInfo1.account.name + "/" + localAuthorityInfo1.account.type + " u" + localAuthorityInfo1.userId;
          l3 = localSyncHistoryItem1.elapsedTime;
          Time localTime = new Time();
          l4 = localSyncHistoryItem1.eventTime;
          localTime.set(l4);
          str4 = str2 + "/" + str3;
          localLong = (Long)localHashMap2.get(str4);
          if (localLong != null) {
            break label1405;
          }
          str5 = "";
        }
        for (;;)
        {
          localHashMap2.put(str4, Long.valueOf(l4));
          Object[] arrayOfObject2 = new Object[5];
          arrayOfObject2[0] = Integer.valueOf(m + 1);
          arrayOfObject2[1] = formatTime(l4);
          arrayOfObject2[2] = SyncStorageEngine.SOURCES[localSyncHistoryItem1.source];
          arrayOfObject2[3] = Float.valueOf((float)l3 / 1000.0F);
          arrayOfObject2[4] = str5;
          paramPrintWriter.printf("  #%-3d: %s %8s  %5.1fs  %8s", arrayOfObject2);
          paramPrintWriter.printf(str1, new Object[] { str3, str2 });
          if ((localSyncHistoryItem1.event != 1) || (localSyncHistoryItem1.upstreamActivity != 0L) || (localSyncHistoryItem1.downstreamActivity != 0L))
          {
            Object[] arrayOfObject3 = new Object[3];
            arrayOfObject3[0] = Integer.valueOf(localSyncHistoryItem1.event);
            arrayOfObject3[1] = Long.valueOf(localSyncHistoryItem1.upstreamActivity);
            arrayOfObject3[2] = Long.valueOf(localSyncHistoryItem1.downstreamActivity);
            paramPrintWriter.printf("    event=%d upstreamActivity=%d downstreamActivity=%d\n", arrayOfObject3);
          }
          if ((localSyncHistoryItem1.mesg != null) && (!"success".equals(localSyncHistoryItem1.mesg)))
          {
            Object[] arrayOfObject4 = new Object[1];
            arrayOfObject4[0] = localSyncHistoryItem1.mesg;
            paramPrintWriter.printf("    mesg=%s\n", arrayOfObject4);
          }
          m++;
          break;
          str2 = "Unknown";
          str3 = "Unknown";
          break label1071;
          label1405:
          long l5 = (localLong.longValue() - l4) / 1000L;
          if (l5 < 60L)
          {
            str5 = String.valueOf(l5);
          }
          else if (l5 < 3600L)
          {
            Object[] arrayOfObject5 = new Object[2];
            arrayOfObject5[0] = Long.valueOf(l5 / 60L);
            arrayOfObject5[1] = Long.valueOf(l5 % 60L);
            str5 = String.format("%02d:%02d", arrayOfObject5);
          }
          else
          {
            long l6 = l5 % 3600L;
            Object[] arrayOfObject1 = new Object[3];
            arrayOfObject1[0] = Long.valueOf(l5 / 3600L);
            arrayOfObject1[1] = Long.valueOf(l6 / 60L);
            arrayOfObject1[2] = Long.valueOf(l6 % 60L);
            str5 = String.format("%02d:%02d:%02d", arrayOfObject1);
          }
        }
      }
    }
  }
  
  private void dumpSyncAdapters(IndentingPrintWriter paramIndentingPrintWriter)
  {
    paramIndentingPrintWriter.println();
    List localList = getAllUsers();
    if (localList != null)
    {
      Iterator localIterator1 = localList.iterator();
      while (localIterator1.hasNext())
      {
        UserInfo localUserInfo = (UserInfo)localIterator1.next();
        paramIndentingPrintWriter.println("Sync adapters for " + localUserInfo + ":");
        paramIndentingPrintWriter.increaseIndent();
        Iterator localIterator2 = this.mSyncAdapters.getAllServices(localUserInfo.id).iterator();
        while (localIterator2.hasNext()) {
          paramIndentingPrintWriter.println((RegisteredServicesCache.ServiceInfo)localIterator2.next());
        }
        paramIndentingPrintWriter.decreaseIndent();
        paramIndentingPrintWriter.println();
      }
    }
  }
  
  private void dumpTimeSec(PrintWriter paramPrintWriter, long paramLong)
  {
    paramPrintWriter.print(paramLong / 1000L);
    paramPrintWriter.print('.');
    paramPrintWriter.print(paramLong / 100L % 10L);
    paramPrintWriter.print('s');
  }
  
  private void ensureAlarmService()
  {
    if (this.mAlarmService == null) {
      this.mAlarmService = ((AlarmManager)this.mContext.getSystemService("alarm"));
    }
  }
  
  static String formatTime(long paramLong)
  {
    Time localTime = new Time();
    localTime.set(paramLong);
    return localTime.format("%Y-%m-%d %H:%M:%S");
  }
  
  private List<UserInfo> getAllUsers()
  {
    return this.mUserManager.getUsers();
  }
  
  private ConnectivityManager getConnectivityManager()
  {
    try
    {
      if (this.mConnManagerDoNotUseDirectly == null) {
        this.mConnManagerDoNotUseDirectly = ((ConnectivityManager)this.mContext.getSystemService("connectivity"));
      }
      ConnectivityManager localConnectivityManager = this.mConnManagerDoNotUseDirectly;
      return localConnectivityManager;
    }
    finally {}
  }
  
  private String getLastFailureMessage(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return "unknown";
    case 1: 
      return "sync already in progress";
    case 2: 
      return "authentication error";
    case 3: 
      return "I/O error";
    case 4: 
      return "parse error";
    case 5: 
      return "conflict error";
    case 6: 
      return "too many deletions error";
    case 7: 
      return "too many retries error";
    }
    return "internal error";
  }
  
  private void increaseBackoffSetting(SyncOperation paramSyncOperation)
  {
    long l1 = SystemClock.elapsedRealtime();
    Pair localPair = this.mSyncStorageEngine.getBackoff(paramSyncOperation.account, paramSyncOperation.userId, paramSyncOperation.authority);
    long l2 = -1L;
    if (localPair != null)
    {
      if (l1 < ((Long)localPair.first).longValue())
      {
        if (Log.isLoggable("SyncManager", 2)) {
          Log.v("SyncManager", "Still in backoff, do not increase it. Remaining: " + (((Long)localPair.first).longValue() - l1) / 1000L + " seconds.");
        }
        return;
      }
      l2 = 2L * ((Long)localPair.second).longValue();
    }
    if (l2 <= 0L) {
      l2 = jitterize(30000L, 33000L);
    }
    long l3 = Settings.Global.getLong(this.mContext.getContentResolver(), "sync_max_retry_delay_in_seconds", 3600L);
    if (l2 > 1000L * l3) {
      l2 = l3 * 1000L;
    }
    long l4 = l1 + l2;
    this.mSyncStorageEngine.setBackoff(paramSyncOperation.account, paramSyncOperation.userId, paramSyncOperation.authority, l4, l2);
    paramSyncOperation.backoff = Long.valueOf(l4);
    paramSyncOperation.updateEffectiveRunTime();
    synchronized (this.mSyncQueue)
    {
      this.mSyncQueue.onBackoffChanged(paramSyncOperation.account, paramSyncOperation.userId, paramSyncOperation.authority, l4);
      return;
    }
  }
  
  private boolean isSyncStillActive(ActiveSyncContext paramActiveSyncContext)
  {
    Iterator localIterator = this.mActiveSyncContexts.iterator();
    while (localIterator.hasNext()) {
      if ((ActiveSyncContext)localIterator.next() == paramActiveSyncContext) {
        return true;
      }
    }
    return false;
  }
  
  private long jitterize(long paramLong1, long paramLong2)
  {
    Random localRandom = new Random(SystemClock.elapsedRealtime());
    long l = paramLong2 - paramLong1;
    if (l > 2147483647L) {
      throw new IllegalArgumentException("the difference between the maxValue and the minValue must be less than 2147483647");
    }
    return paramLong1 + localRandom.nextInt((int)l);
  }
  
  private void onUserRemoved(int paramInt)
  {
    updateRunningAccounts();
    this.mSyncStorageEngine.doDatabaseCleanup(new Account[0], paramInt);
    synchronized (this.mSyncQueue)
    {
      this.mSyncQueue.removeUser(paramInt);
      return;
    }
  }
  
  private void onUserStarting(int paramInt)
  {
    AccountManagerService.getSingleton().validateAccounts(paramInt);
    this.mSyncAdapters.invalidateCache(paramInt);
    updateRunningAccounts();
    synchronized (this.mSyncQueue)
    {
      this.mSyncQueue.addPendingOperations(paramInt);
      Account[] arrayOfAccount = AccountManagerService.getSingleton().getAccounts(paramInt);
      int i = arrayOfAccount.length;
      int j = 0;
      if (j < i)
      {
        scheduleSync(arrayOfAccount[j], paramInt, null, null, 0L, true);
        j++;
      }
    }
    sendCheckAlarmsMessage();
  }
  
  private void onUserStopping(int paramInt)
  {
    updateRunningAccounts();
    cancelActiveSync(null, paramInt, null);
  }
  
  private boolean readDataConnectionState()
  {
    NetworkInfo localNetworkInfo = getConnectivityManager().getActiveNetworkInfo();
    return (localNetworkInfo != null) && (localNetworkInfo.isConnected());
  }
  
  private void sendCancelSyncsMessage(Account paramAccount, int paramInt, String paramString)
  {
    if (Log.isLoggable("SyncManager", 2)) {
      Log.v("SyncManager", "sending MESSAGE_CANCEL");
    }
    Message localMessage = this.mSyncHandler.obtainMessage();
    localMessage.what = 6;
    localMessage.obj = Pair.create(paramAccount, paramString);
    localMessage.arg1 = paramInt;
    this.mSyncHandler.sendMessage(localMessage);
  }
  
  private void sendCheckAlarmsMessage()
  {
    if (Log.isLoggable("SyncManager", 2)) {
      Log.v("SyncManager", "sending MESSAGE_CHECK_ALARMS");
    }
    this.mSyncHandler.removeMessages(3);
    this.mSyncHandler.sendEmptyMessage(3);
  }
  
  private void sendSyncAlarmMessage()
  {
    if (Log.isLoggable("SyncManager", 2)) {
      Log.v("SyncManager", "sending MESSAGE_SYNC_ALARM");
    }
    this.mSyncHandler.sendEmptyMessage(2);
  }
  
  private void sendSyncFinishedOrCanceledMessage(ActiveSyncContext paramActiveSyncContext, SyncResult paramSyncResult)
  {
    if (Log.isLoggable("SyncManager", 2)) {
      Log.v("SyncManager", "sending MESSAGE_SYNC_FINISHED");
    }
    Message localMessage = this.mSyncHandler.obtainMessage();
    localMessage.what = 1;
    localMessage.obj = new SyncHandlerMessagePayload(paramActiveSyncContext, paramSyncResult);
    this.mSyncHandler.sendMessage(localMessage);
  }
  
  private void setDelayUntilTime(SyncOperation paramSyncOperation, long paramLong)
  {
    long l1 = paramLong * 1000L;
    long l2 = System.currentTimeMillis();
    if (l1 > l2) {}
    for (long l3 = SystemClock.elapsedRealtime() + (l1 - l2);; l3 = 0L)
    {
      this.mSyncStorageEngine.setDelayUntilTime(paramSyncOperation.account, paramSyncOperation.userId, paramSyncOperation.authority, l3);
      synchronized (this.mSyncQueue)
      {
        this.mSyncQueue.onDelayUntilTimeChanged(paramSyncOperation.account, paramSyncOperation.authority, l3);
        return;
      }
    }
  }
  
  public void cancelActiveSync(Account paramAccount, int paramInt, String paramString)
  {
    sendCancelSyncsMessage(paramAccount, paramInt, paramString);
  }
  
  public void clearScheduledSyncOperations(Account paramAccount, int paramInt, String paramString)
  {
    synchronized (this.mSyncQueue)
    {
      this.mSyncQueue.remove(paramAccount, paramInt, paramString);
      this.mSyncStorageEngine.setBackoff(paramAccount, paramInt, paramString, -1L, -1L);
      return;
    }
  }
  
  protected void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter)
  {
    IndentingPrintWriter localIndentingPrintWriter = new IndentingPrintWriter(paramPrintWriter, "  ");
    dumpSyncState(localIndentingPrintWriter);
    dumpSyncHistory(localIndentingPrintWriter);
    dumpSyncAdapters(localIndentingPrintWriter);
  }
  
  protected void dumpSyncHistory(PrintWriter paramPrintWriter)
  {
    dumpRecentHistory(paramPrintWriter);
    dumpDayStatistics(paramPrintWriter);
  }
  
  protected void dumpSyncState(PrintWriter paramPrintWriter)
  {
    paramPrintWriter.print("data connected: ");
    paramPrintWriter.println(this.mDataConnectionIsConnected);
    paramPrintWriter.print("auto sync: ");
    List localList = getAllUsers();
    if (localList != null)
    {
      Iterator localIterator3 = localList.iterator();
      while (localIterator3.hasNext())
      {
        UserInfo localUserInfo = (UserInfo)localIterator3.next();
        paramPrintWriter.print("u" + localUserInfo.id + "=" + this.mSyncStorageEngine.getMasterSyncAutomatically(localUserInfo.id) + " ");
      }
      paramPrintWriter.println();
    }
    paramPrintWriter.print("memory low: ");
    paramPrintWriter.println(this.mStorageIsLow);
    AccountAndUser[] arrayOfAccountAndUser = AccountManagerService.getSingleton().getAllAccounts();
    paramPrintWriter.print("accounts: ");
    long l1;
    String str1;
    if (arrayOfAccountAndUser != INITIAL_ACCOUNTS_ARRAY)
    {
      paramPrintWriter.println(arrayOfAccountAndUser.length);
      l1 = SystemClock.elapsedRealtime();
      paramPrintWriter.print("now: ");
      paramPrintWriter.print(l1);
      paramPrintWriter.println(" (" + formatTime(System.currentTimeMillis()) + ")");
      paramPrintWriter.print("offset: ");
      paramPrintWriter.print(DateUtils.formatElapsedTime(this.mSyncRandomOffsetMillis / 1000));
      paramPrintWriter.println(" (HH:MM:SS)");
      paramPrintWriter.print("uptime: ");
      paramPrintWriter.print(DateUtils.formatElapsedTime(l1 / 1000L));
      paramPrintWriter.println(" (HH:MM:SS)");
      paramPrintWriter.print("time spent syncing: ");
      paramPrintWriter.print(DateUtils.formatElapsedTime(this.mSyncHandler.mSyncTimeTracker.timeSpentSyncing() / 1000L));
      paramPrintWriter.print(" (HH:MM:SS), sync ");
      if (!this.mSyncHandler.mSyncTimeTracker.mLastWasSyncing) {
        break label576;
      }
      str1 = "";
      label328:
      paramPrintWriter.print(str1);
      paramPrintWriter.println("in progress");
      if (this.mSyncHandler.mAlarmScheduleTime == null) {
        break label584;
      }
      paramPrintWriter.print("next alarm time: ");
      paramPrintWriter.print(this.mSyncHandler.mAlarmScheduleTime);
      paramPrintWriter.print(" (");
      paramPrintWriter.print(DateUtils.formatElapsedTime((this.mSyncHandler.mAlarmScheduleTime.longValue() - l1) / 1000L));
      paramPrintWriter.println(" (HH:MM:SS) from now)");
    }
    StringBuilder localStringBuilder1;
    for (;;)
    {
      paramPrintWriter.print("notification info: ");
      localStringBuilder1 = new StringBuilder();
      this.mSyncHandler.mSyncNotificationInfo.toString(localStringBuilder1);
      paramPrintWriter.println(localStringBuilder1.toString());
      paramPrintWriter.println();
      paramPrintWriter.println("Active Syncs: " + this.mActiveSyncContexts.size());
      Iterator localIterator1 = this.mActiveSyncContexts.iterator();
      while (localIterator1.hasNext())
      {
        ActiveSyncContext localActiveSyncContext = (ActiveSyncContext)localIterator1.next();
        long l3 = (l1 - localActiveSyncContext.mStartTime) / 1000L;
        paramPrintWriter.print("  ");
        paramPrintWriter.print(DateUtils.formatElapsedTime(l3));
        paramPrintWriter.print(" - ");
        paramPrintWriter.print(localActiveSyncContext.mSyncOperation.dump(false));
        paramPrintWriter.println();
      }
      paramPrintWriter.println("not known yet");
      break;
      label576:
      str1 = "not ";
      break label328;
      label584:
      paramPrintWriter.println("no alarm is scheduled (there had better not be any pending syncs)");
    }
    for (;;)
    {
      int j;
      SyncStorageEngine.AuthorityInfo localAuthorityInfo;
      SyncStatusInfo localSyncStatusInfo;
      String str2;
      String str3;
      synchronized (this.mSyncQueue)
      {
        localStringBuilder1.setLength(0);
        this.mSyncQueue.dump(localStringBuilder1);
        paramPrintWriter.println();
        paramPrintWriter.print(localStringBuilder1.toString());
        paramPrintWriter.println();
        paramPrintWriter.println("Sync Status");
        int i = arrayOfAccountAndUser.length;
        j = 0;
        if (j >= i) {
          break;
        }
        AccountAndUser localAccountAndUser = arrayOfAccountAndUser[j];
        paramPrintWriter.print("  Account ");
        paramPrintWriter.print(localAccountAndUser.account.name);
        paramPrintWriter.print(" u");
        paramPrintWriter.print(localAccountAndUser.userId);
        paramPrintWriter.print(" ");
        paramPrintWriter.print(localAccountAndUser.account.type);
        paramPrintWriter.println(":");
        Iterator localIterator2 = this.mSyncAdapters.getAllServices(localAccountAndUser.userId).iterator();
        if (!localIterator2.hasNext()) {
          break label1563;
        }
        RegisteredServicesCache.ServiceInfo localServiceInfo = (RegisteredServicesCache.ServiceInfo)localIterator2.next();
        if (!((SyncAdapterType)localServiceInfo.type).accountType.equals(localAccountAndUser.account.type)) {
          continue;
        }
        localAuthorityInfo = this.mSyncStorageEngine.getOrCreateAuthority(localAccountAndUser.account, localAccountAndUser.userId, ((SyncAdapterType)localServiceInfo.type).authority);
        localSyncStatusInfo = this.mSyncStorageEngine.getOrCreateSyncStatus(localAuthorityInfo);
        paramPrintWriter.print("    ");
        paramPrintWriter.print(localAuthorityInfo.authority);
        paramPrintWriter.println(":");
        paramPrintWriter.print("      settings:");
        StringBuilder localStringBuilder2 = new StringBuilder().append(" ");
        if (localAuthorityInfo.syncable > 0)
        {
          str2 = "syncable";
          paramPrintWriter.print(str2);
          StringBuilder localStringBuilder3 = new StringBuilder().append(", ");
          if (!localAuthorityInfo.enabled) {
            break label1257;
          }
          str3 = "enabled";
          paramPrintWriter.print(str3);
          if (localAuthorityInfo.delayUntil > l1) {
            paramPrintWriter.print(", delay for " + (localAuthorityInfo.delayUntil - l1) / 1000L + " sec");
          }
          if (localAuthorityInfo.backoffTime > l1) {
            paramPrintWriter.print(", backoff for " + (localAuthorityInfo.backoffTime - l1) / 1000L + " sec");
          }
          if (localAuthorityInfo.backoffDelay > 0L) {
            paramPrintWriter.print(", the backoff increment is " + localAuthorityInfo.backoffDelay / 1000L + " sec");
          }
          paramPrintWriter.println();
          int k = 0;
          int m = localAuthorityInfo.periodicSyncs.size();
          if (k >= m) {
            break label1265;
          }
          Pair localPair = (Pair)localAuthorityInfo.periodicSyncs.get(k);
          long l2 = localSyncStatusInfo.getPeriodicSyncTime(k) + 1000L * ((Long)localPair.second).longValue();
          paramPrintWriter.println("      periodic period=" + localPair.second + ", extras=" + localPair.first + ", next=" + formatTime(l2));
          k++;
        }
      }
      if (localAuthorityInfo.syncable == 0)
      {
        str2 = "not syncable";
      }
      else
      {
        str2 = "not initialized";
        continue;
        label1257:
        str3 = "disabled";
        continue;
        label1265:
        paramPrintWriter.print("      count: local=");
        paramPrintWriter.print(localSyncStatusInfo.numSourceLocal);
        paramPrintWriter.print(" poll=");
        paramPrintWriter.print(localSyncStatusInfo.numSourcePoll);
        paramPrintWriter.print(" periodic=");
        paramPrintWriter.print(localSyncStatusInfo.numSourcePeriodic);
        paramPrintWriter.print(" server=");
        paramPrintWriter.print(localSyncStatusInfo.numSourceServer);
        paramPrintWriter.print(" user=");
        paramPrintWriter.print(localSyncStatusInfo.numSourceUser);
        paramPrintWriter.print(" total=");
        paramPrintWriter.print(localSyncStatusInfo.numSyncs);
        paramPrintWriter.println();
        paramPrintWriter.print("      total duration: ");
        paramPrintWriter.println(DateUtils.formatElapsedTime(localSyncStatusInfo.totalElapsedTime / 1000L));
        if (localSyncStatusInfo.lastSuccessTime != 0L)
        {
          paramPrintWriter.print("      SUCCESS: source=");
          paramPrintWriter.print(SyncStorageEngine.SOURCES[localSyncStatusInfo.lastSuccessSource]);
          paramPrintWriter.print(" time=");
          paramPrintWriter.println(formatTime(localSyncStatusInfo.lastSuccessTime));
        }
        if (localSyncStatusInfo.lastFailureTime != 0L)
        {
          paramPrintWriter.print("      FAILURE: source=");
          paramPrintWriter.print(SyncStorageEngine.SOURCES[localSyncStatusInfo.lastFailureSource]);
          paramPrintWriter.print(" initialTime=");
          paramPrintWriter.print(formatTime(localSyncStatusInfo.initialFailureTime));
          paramPrintWriter.print(" lastTime=");
          paramPrintWriter.println(formatTime(localSyncStatusInfo.lastFailureTime));
          int n = localSyncStatusInfo.getLastFailureMesgAsInt(0);
          paramPrintWriter.print("      message: ");
          paramPrintWriter.println(getLastFailureMessage(n) + " (" + n + ")");
          continue;
          label1563:
          j++;
        }
      }
    }
  }
  
  public SyncAdapterType[] getSyncAdapterTypes(int paramInt)
  {
    Collection localCollection = this.mSyncAdapters.getAllServices(paramInt);
    SyncAdapterType[] arrayOfSyncAdapterType = new SyncAdapterType[localCollection.size()];
    int i = 0;
    Iterator localIterator = localCollection.iterator();
    while (localIterator.hasNext())
    {
      arrayOfSyncAdapterType[i] = ((SyncAdapterType)((RegisteredServicesCache.ServiceInfo)localIterator.next()).type);
      i++;
    }
    return arrayOfSyncAdapterType;
  }
  
  public SyncStorageEngine getSyncStorageEngine()
  {
    return this.mSyncStorageEngine;
  }
  
  void maybeRescheduleSync(SyncResult paramSyncResult, SyncOperation paramSyncOperation)
  {
    boolean bool = Log.isLoggable("SyncManager", 3);
    if (bool) {
      Log.d("SyncManager", "encountered error(s) during the sync: " + paramSyncResult + ", " + paramSyncOperation);
    }
    SyncOperation localSyncOperation = new SyncOperation(paramSyncOperation);
    if (localSyncOperation.extras.getBoolean("ignore_backoff", false)) {
      localSyncOperation.extras.remove("ignore_backoff");
    }
    if (localSyncOperation.extras.getBoolean("do_not_retry", false))
    {
      Log.d("SyncManager", "not retrying sync operation because SYNC_EXTRAS_DO_NOT_RETRY was specified " + localSyncOperation);
      return;
    }
    if ((localSyncOperation.extras.getBoolean("upload", false)) && (!paramSyncResult.syncAlreadyInProgress))
    {
      localSyncOperation.extras.remove("upload");
      Log.d("SyncManager", "retrying sync operation as a two-way sync because an upload-only sync encountered an error: " + localSyncOperation);
      scheduleSyncOperation(localSyncOperation);
      return;
    }
    if (paramSyncResult.tooManyRetries)
    {
      Log.d("SyncManager", "not retrying sync operation because it retried too many times: " + localSyncOperation);
      return;
    }
    if (paramSyncResult.madeSomeProgress())
    {
      if (bool) {
        Log.d("SyncManager", "retrying sync operation because even though it had an error it achieved some success");
      }
      scheduleSyncOperation(localSyncOperation);
      return;
    }
    if (paramSyncResult.syncAlreadyInProgress)
    {
      if (bool) {
        Log.d("SyncManager", "retrying sync operation that failed because there was already a sync in progress: " + localSyncOperation);
      }
      scheduleSyncOperation(new SyncOperation(localSyncOperation.account, localSyncOperation.userId, localSyncOperation.syncSource, localSyncOperation.authority, localSyncOperation.extras, 10000L, localSyncOperation.backoff.longValue(), localSyncOperation.delayUntil, localSyncOperation.allowParallelSyncs));
      return;
    }
    if (paramSyncResult.hasSoftError())
    {
      if (bool) {
        Log.d("SyncManager", "retrying sync operation because it encountered a soft error: " + localSyncOperation);
      }
      scheduleSyncOperation(localSyncOperation);
      return;
    }
    Log.d("SyncManager", "not retrying sync operation because the error is a hard error: " + localSyncOperation);
  }
  
  public void scheduleLocalSync(Account paramAccount, int paramInt, String paramString)
  {
    Bundle localBundle = new Bundle();
    localBundle.putBoolean("upload", true);
    scheduleSync(paramAccount, paramInt, paramString, localBundle, LOCAL_SYNC_DELAY, false);
  }
  
  public void scheduleSync(Account paramAccount, int paramInt, String paramString, Bundle paramBundle, long paramLong, boolean paramBoolean)
  {
    boolean bool1 = Log.isLoggable("SyncManager", 2);
    int i;
    AccountAndUser[] arrayOfAccountAndUser1;
    label93:
    boolean bool2;
    boolean bool3;
    boolean bool4;
    int j;
    label157:
    AccountAndUser[] arrayOfAccountAndUser2;
    int k;
    if ((!this.mBootCompleted) || (getConnectivityManager().getBackgroundDataSetting()))
    {
      i = 1;
      if (paramBundle == null) {
        paramBundle = new Bundle();
      }
      if (Boolean.valueOf(paramBundle.getBoolean("expedited", false)).booleanValue()) {
        paramLong = -1L;
      }
      if ((paramAccount == null) || (paramInt == -1)) {
        break label255;
      }
      arrayOfAccountAndUser1 = new AccountAndUser[1];
      arrayOfAccountAndUser1[0] = new AccountAndUser(paramAccount, paramInt);
      bool2 = paramBundle.getBoolean("upload", false);
      bool3 = paramBundle.getBoolean("force", false);
      if (bool3)
      {
        paramBundle.putBoolean("ignore_backoff", true);
        paramBundle.putBoolean("ignore_settings", true);
      }
      bool4 = paramBundle.getBoolean("ignore_settings", false);
      if (!bool2) {
        break label282;
      }
      j = 1;
      arrayOfAccountAndUser2 = arrayOfAccountAndUser1;
      k = arrayOfAccountAndUser2.length;
    }
    for (int m = 0;; m++)
    {
      AccountAndUser localAccountAndUser;
      HashSet localHashSet;
      if (m < k)
      {
        localAccountAndUser = arrayOfAccountAndUser2[m];
        localHashSet = new HashSet();
        Iterator localIterator1 = this.mSyncAdapters.getAllServices(localAccountAndUser.userId).iterator();
        while (localIterator1.hasNext()) {
          localHashSet.add(((SyncAdapterType)((RegisteredServicesCache.ServiceInfo)localIterator1.next()).type).authority);
        }
        i = 0;
        break;
        label255:
        arrayOfAccountAndUser1 = this.mRunningAccounts;
        if (arrayOfAccountAndUser1.length != 0) {
          break label93;
        }
        if (bool1) {
          Log.v("SyncManager", "scheduleSync: no accounts configured, dropping");
        }
      }
      return;
      label282:
      if (bool3)
      {
        j = 3;
        break label157;
      }
      if (paramString == null)
      {
        j = 2;
        break label157;
      }
      j = 0;
      break label157;
      if (paramString != null)
      {
        boolean bool7 = localHashSet.contains(paramString);
        localHashSet.clear();
        if (bool7) {
          localHashSet.add(paramString);
        }
      }
      Iterator localIterator2 = localHashSet.iterator();
      while (localIterator2.hasNext())
      {
        String str = (String)localIterator2.next();
        int n = this.mSyncStorageEngine.getIsSyncable(localAccountAndUser.account, localAccountAndUser.userId, str);
        if (n != 0)
        {
          RegisteredServicesCache.ServiceInfo localServiceInfo = this.mSyncAdapters.getServiceInfo(SyncAdapterType.newKey(str, localAccountAndUser.account.type), localAccountAndUser.userId);
          if (localServiceInfo != null)
          {
            boolean bool5 = ((SyncAdapterType)localServiceInfo.type).allowParallelSyncs();
            boolean bool6 = ((SyncAdapterType)localServiceInfo.type).isAlwaysSyncable();
            if ((n < 0) && (bool6))
            {
              this.mSyncStorageEngine.setIsSyncable(localAccountAndUser.account, localAccountAndUser.userId, str, 1);
              n = 1;
            }
            if (((!paramBoolean) || (n < 0)) && ((((SyncAdapterType)localServiceInfo.type).supportsUploading()) || (!bool2)))
            {
              if ((n < 0) || (bool4) || ((i != 0) && (this.mSyncStorageEngine.getMasterSyncAutomatically(localAccountAndUser.userId)) && (this.mSyncStorageEngine.getSyncAutomatically(localAccountAndUser.account, localAccountAndUser.userId, str)))) {}
              for (int i1 = 1;; i1 = 0)
              {
                if (i1 != 0) {
                  break label631;
                }
                if (!bool1) {
                  break;
                }
                Log.d("SyncManager", "scheduleSync: sync of " + localAccountAndUser + ", " + str + " is not allowed, dropping request");
                break;
              }
              label631:
              Pair localPair = this.mSyncStorageEngine.getBackoff(localAccountAndUser.account, localAccountAndUser.userId, str);
              long l1 = this.mSyncStorageEngine.getDelayUntilTime(localAccountAndUser.account, localAccountAndUser.userId, str);
              if (localPair != null) {}
              for (long l2 = ((Long)localPair.first).longValue();; l2 = 0L)
              {
                if (n < 0)
                {
                  Bundle localBundle = new Bundle();
                  localBundle.putBoolean("initialize", true);
                  if (bool1) {
                    Log.v("SyncManager", "scheduleSync: delay " + paramLong + ", source " + j + ", account " + localAccountAndUser + ", authority " + str + ", extras " + localBundle);
                  }
                  scheduleSyncOperation(new SyncOperation(localAccountAndUser.account, localAccountAndUser.userId, j, str, localBundle, 0L, l2, l1, bool5));
                }
                if (paramBoolean) {
                  break;
                }
                if (bool1) {
                  Log.v("SyncManager", "scheduleSync: delay " + paramLong + ", source " + j + ", account " + localAccountAndUser + ", authority " + str + ", extras " + paramBundle);
                }
                scheduleSyncOperation(new SyncOperation(localAccountAndUser.account, localAccountAndUser.userId, j, str, paramBundle, paramLong, l2, l1, bool5));
                break;
              }
            }
          }
        }
      }
    }
  }
  
  public void scheduleSyncOperation(SyncOperation paramSyncOperation)
  {
    do
    {
      synchronized (this.mSyncQueue)
      {
        boolean bool = this.mSyncQueue.add(paramSyncOperation);
        if (bool)
        {
          if (Log.isLoggable("SyncManager", 2)) {
            Log.v("SyncManager", "scheduleSyncOperation: enqueued " + paramSyncOperation);
          }
          sendCheckAlarmsMessage();
          return;
        }
      }
    } while (!Log.isLoggable("SyncManager", 2));
    Log.v("SyncManager", "scheduleSyncOperation: dropping duplicate sync operation " + paramSyncOperation);
  }
  
  public void updateRunningAccounts()
  {
    this.mRunningAccounts = AccountManagerService.getSingleton().getRunningAccounts();
    if (this.mBootCompleted) {
      doDatabaseCleanup();
    }
    Iterator localIterator = this.mActiveSyncContexts.iterator();
    while (localIterator.hasNext())
    {
      ActiveSyncContext localActiveSyncContext = (ActiveSyncContext)localIterator.next();
      if (!containsAccountAndUser(this.mRunningAccounts, localActiveSyncContext.mSyncOperation.account, localActiveSyncContext.mSyncOperation.userId))
      {
        Log.d("SyncManager", "canceling sync since the account is no longer running");
        sendSyncFinishedOrCanceledMessage(localActiveSyncContext, null);
      }
    }
    sendCheckAlarmsMessage();
  }
  
  private static class AccountSyncStats
  {
    long elapsedTime;
    String name;
    int times;
    
    private AccountSyncStats(String paramString)
    {
      this.name = paramString;
    }
  }
  
  class ActiveSyncContext
    extends ISyncContext.Stub
    implements ServiceConnection, IBinder.DeathRecipient
  {
    boolean mBound;
    final long mHistoryRowId;
    boolean mIsLinkedToDeath = false;
    final long mStartTime;
    ISyncAdapter mSyncAdapter;
    final int mSyncAdapterUid;
    SyncInfo mSyncInfo;
    final SyncOperation mSyncOperation;
    final PowerManager.WakeLock mSyncWakeLock;
    long mTimeoutStartTime;
    
    public ActiveSyncContext(SyncOperation paramSyncOperation, long paramLong, int paramInt)
    {
      this.mSyncAdapterUid = paramInt;
      this.mSyncOperation = paramSyncOperation;
      this.mHistoryRowId = paramLong;
      this.mSyncAdapter = null;
      this.mStartTime = SystemClock.elapsedRealtime();
      this.mTimeoutStartTime = this.mStartTime;
      this.mSyncWakeLock = SyncManager.SyncHandler.access$1300(SyncManager.this.mSyncHandler, this.mSyncOperation.account, this.mSyncOperation.authority);
      this.mSyncWakeLock.setWorkSource(new WorkSource(paramInt));
      this.mSyncWakeLock.acquire();
    }
    
    boolean bindToSyncAdapter(RegisteredServicesCache.ServiceInfo paramServiceInfo, int paramInt)
    {
      if (Log.isLoggable("SyncManager", 2)) {
        Log.d("SyncManager", "bindToSyncAdapter: " + paramServiceInfo.componentName + ", connection " + this);
      }
      Intent localIntent = new Intent();
      localIntent.setAction("android.content.SyncAdapter");
      localIntent.setComponent(paramServiceInfo.componentName);
      localIntent.putExtra("android.intent.extra.client_label", 17040514);
      localIntent.putExtra("android.intent.extra.client_intent", PendingIntent.getActivityAsUser(SyncManager.this.mContext, 0, new Intent("android.settings.SYNC_SETTINGS"), 0, null, new UserHandle(paramInt)));
      this.mBound = true;
      boolean bool = SyncManager.this.mContext.bindService(localIntent, this, 21, this.mSyncOperation.userId);
      if (!bool) {
        this.mBound = false;
      }
      return bool;
    }
    
    public void binderDied()
    {
      SyncManager.this.sendSyncFinishedOrCanceledMessage(this, null);
    }
    
    protected void close()
    {
      if (Log.isLoggable("SyncManager", 2)) {
        Log.d("SyncManager", "unBindFromSyncAdapter: connection " + this);
      }
      if (this.mBound)
      {
        this.mBound = false;
        SyncManager.this.mContext.unbindService(this);
      }
      this.mSyncWakeLock.release();
      this.mSyncWakeLock.setWorkSource(null);
    }
    
    public void onFinished(SyncResult paramSyncResult)
    {
      if (Log.isLoggable("SyncManager", 2)) {
        Log.v("SyncManager", "onFinished: " + this);
      }
      SyncManager.this.sendSyncFinishedOrCanceledMessage(this, paramSyncResult);
    }
    
    public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
    {
      Message localMessage = SyncManager.this.mSyncHandler.obtainMessage();
      localMessage.what = 4;
      localMessage.obj = new SyncManager.ServiceConnectionData(SyncManager.this, this, ISyncAdapter.Stub.asInterface(paramIBinder));
      SyncManager.this.mSyncHandler.sendMessage(localMessage);
    }
    
    public void onServiceDisconnected(ComponentName paramComponentName)
    {
      Message localMessage = SyncManager.this.mSyncHandler.obtainMessage();
      localMessage.what = 5;
      localMessage.obj = new SyncManager.ServiceConnectionData(SyncManager.this, this, null);
      SyncManager.this.mSyncHandler.sendMessage(localMessage);
    }
    
    public void sendHeartbeat() {}
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      toString(localStringBuilder);
      return localStringBuilder.toString();
    }
    
    public void toString(StringBuilder paramStringBuilder)
    {
      paramStringBuilder.append("startTime ").append(this.mStartTime).append(", mTimeoutStartTime ").append(this.mTimeoutStartTime).append(", mHistoryRowId ").append(this.mHistoryRowId).append(", syncOperation ").append(this.mSyncOperation);
    }
  }
  
  private static class AuthoritySyncStats
  {
    Map<String, SyncManager.AccountSyncStats> accountMap = Maps.newHashMap();
    long elapsedTime;
    String name;
    int times;
    
    private AuthoritySyncStats(String paramString)
    {
      this.name = paramString;
    }
  }
  
  class ServiceConnectionData
  {
    public final SyncManager.ActiveSyncContext activeSyncContext;
    public final ISyncAdapter syncAdapter;
    
    ServiceConnectionData(SyncManager.ActiveSyncContext paramActiveSyncContext, ISyncAdapter paramISyncAdapter)
    {
      this.activeSyncContext = paramActiveSyncContext;
      this.syncAdapter = paramISyncAdapter;
    }
  }
  
  class SyncAlarmIntentReceiver
    extends BroadcastReceiver
  {
    SyncAlarmIntentReceiver() {}
    
    public void onReceive(Context paramContext, Intent paramIntent)
    {
      SyncManager.this.mHandleAlarmWakeLock.acquire();
      SyncManager.this.sendSyncAlarmMessage();
    }
  }
  
  class SyncHandler
    extends Handler
  {
    private static final int MESSAGE_CANCEL = 6;
    private static final int MESSAGE_CHECK_ALARMS = 3;
    private static final int MESSAGE_SERVICE_CONNECTED = 4;
    private static final int MESSAGE_SERVICE_DISCONNECTED = 5;
    private static final int MESSAGE_SYNC_ALARM = 2;
    private static final int MESSAGE_SYNC_FINISHED = 1;
    private Long mAlarmScheduleTime = null;
    private volatile CountDownLatch mReadyToRunLatch = new CountDownLatch(1);
    public final SyncNotificationInfo mSyncNotificationInfo = new SyncNotificationInfo();
    public final SyncManager.SyncTimeTracker mSyncTimeTracker = new SyncManager.SyncTimeTracker(SyncManager.this, null);
    private final HashMap<Pair<Account, String>, PowerManager.WakeLock> mWakeLocks = Maps.newHashMap();
    
    public SyncHandler(Looper paramLooper)
    {
      super();
    }
    
    private void cancelActiveSyncLocked(Account paramAccount, int paramInt, String paramString)
    {
      Iterator localIterator = new ArrayList(SyncManager.this.mActiveSyncContexts).iterator();
      while (localIterator.hasNext())
      {
        SyncManager.ActiveSyncContext localActiveSyncContext = (SyncManager.ActiveSyncContext)localIterator.next();
        if ((localActiveSyncContext != null) && ((paramAccount == null) || (paramAccount.equals(localActiveSyncContext.mSyncOperation.account))) && ((paramString == null) || (paramString.equals(localActiveSyncContext.mSyncOperation.authority))) && ((paramInt == -1) || (paramInt == localActiveSyncContext.mSyncOperation.userId))) {
          runSyncFinishedOrCanceledLocked(null, localActiveSyncContext);
        }
      }
    }
    
    private void closeActiveSyncContext(SyncManager.ActiveSyncContext paramActiveSyncContext)
    {
      paramActiveSyncContext.close();
      SyncManager.this.mActiveSyncContexts.remove(paramActiveSyncContext);
      SyncManager.this.mSyncStorageEngine.removeActiveSync(paramActiveSyncContext.mSyncInfo, paramActiveSyncContext.mSyncOperation.userId);
    }
    
    private boolean dispatchSyncOperation(SyncOperation paramSyncOperation)
    {
      if (Log.isLoggable("SyncManager", 2))
      {
        Log.v("SyncManager", "dispatchSyncOperation: we are going to sync " + paramSyncOperation);
        Log.v("SyncManager", "num active syncs: " + SyncManager.this.mActiveSyncContexts.size());
        Iterator localIterator = SyncManager.this.mActiveSyncContexts.iterator();
        while (localIterator.hasNext()) {
          Log.v("SyncManager", ((SyncManager.ActiveSyncContext)localIterator.next()).toString());
        }
      }
      SyncAdapterType localSyncAdapterType = SyncAdapterType.newKey(paramSyncOperation.authority, paramSyncOperation.account.type);
      RegisteredServicesCache.ServiceInfo localServiceInfo = SyncManager.this.mSyncAdapters.getServiceInfo(localSyncAdapterType, paramSyncOperation.userId);
      if (localServiceInfo == null)
      {
        Log.d("SyncManager", "can't find a sync adapter for " + localSyncAdapterType + ", removing settings for it");
        SyncManager.this.mSyncStorageEngine.removeAuthority(paramSyncOperation.account, paramSyncOperation.userId, paramSyncOperation.authority);
        return false;
      }
      SyncManager.ActiveSyncContext localActiveSyncContext = new SyncManager.ActiveSyncContext(SyncManager.this, paramSyncOperation, insertStartSyncEvent(paramSyncOperation), localServiceInfo.uid);
      localActiveSyncContext.mSyncInfo = SyncManager.this.mSyncStorageEngine.addActiveSync(localActiveSyncContext);
      SyncManager.this.mActiveSyncContexts.add(localActiveSyncContext);
      if (Log.isLoggable("SyncManager", 2)) {
        Log.v("SyncManager", "dispatchSyncOperation: starting " + localActiveSyncContext);
      }
      if (!localActiveSyncContext.bindToSyncAdapter(localServiceInfo, paramSyncOperation.userId))
      {
        Log.e("SyncManager", "Bind attempt failed to " + localServiceInfo);
        closeActiveSyncContext(localActiveSyncContext);
        return false;
      }
      return true;
    }
    
    private PowerManager.WakeLock getSyncWakeLock(Account paramAccount, String paramString)
    {
      Pair localPair = Pair.create(paramAccount, paramString);
      PowerManager.WakeLock localWakeLock = (PowerManager.WakeLock)this.mWakeLocks.get(localPair);
      if (localWakeLock == null)
      {
        String str = "*sync*_" + paramString + "_" + paramAccount;
        localWakeLock = SyncManager.this.mPowerManager.newWakeLock(1, str);
        localWakeLock.setReferenceCounted(false);
        this.mWakeLocks.put(localPair, localWakeLock);
      }
      return localWakeLock;
    }
    
    private void installHandleTooManyDeletesNotification(Account paramAccount, String paramString, long paramLong, int paramInt)
    {
      if (SyncManager.this.mNotificationMgr == null) {}
      ProviderInfo localProviderInfo;
      do
      {
        return;
        localProviderInfo = SyncManager.this.mContext.getPackageManager().resolveContentProvider(paramString, 0);
      } while (localProviderInfo == null);
      CharSequence localCharSequence1 = localProviderInfo.loadLabel(SyncManager.this.mContext.getPackageManager());
      Intent localIntent = new Intent(SyncManager.this.mContext, SyncActivityTooManyDeletes.class);
      localIntent.putExtra("account", paramAccount);
      localIntent.putExtra("authority", paramString);
      localIntent.putExtra("provider", localCharSequence1.toString());
      localIntent.putExtra("numDeletes", paramLong);
      if (!isActivityAvailable(localIntent))
      {
        Log.w("SyncManager", "No activity found to handle too many deletes.");
        return;
      }
      PendingIntent localPendingIntent = PendingIntent.getActivityAsUser(SyncManager.this.mContext, 0, localIntent, 268435456, null, new UserHandle(paramInt));
      CharSequence localCharSequence2 = SyncManager.this.mContext.getResources().getText(17039569);
      Notification localNotification = new Notification(17302815, SyncManager.this.mContext.getString(17039567), System.currentTimeMillis());
      localNotification.setLatestEventInfo(SyncManager.this.mContext, SyncManager.this.mContext.getString(17039568), String.format(localCharSequence2.toString(), new Object[] { localCharSequence1 }), localPendingIntent);
      localNotification.flags = (0x2 | localNotification.flags);
      SyncManager.this.mNotificationMgr.notifyAsUser(null, paramAccount.hashCode() ^ paramString.hashCode(), localNotification, new UserHandle(paramInt));
    }
    
    private boolean isActivityAvailable(Intent paramIntent)
    {
      List localList = SyncManager.this.mContext.getPackageManager().queryIntentActivities(paramIntent, 0);
      int i = localList.size();
      for (int j = 0;; j++)
      {
        boolean bool = false;
        if (j < i)
        {
          if ((0x1 & ((ResolveInfo)localList.get(j)).activityInfo.applicationInfo.flags) != 0) {
            bool = true;
          }
        }
        else {
          return bool;
        }
      }
    }
    
    private void manageSyncAlarmLocked(long paramLong1, long paramLong2)
    {
      if (!SyncManager.this.mDataConnectionIsConnected) {}
      int i;
      label428:
      label440:
      label476:
      label663:
      label669:
      label675:
      label685:
      do
      {
        do
        {
          return;
        } while (SyncManager.this.mStorageIsLow);
        if ((!SyncManager.this.mSyncHandler.mSyncNotificationInfo.isActive) && (SyncManager.this.mSyncHandler.mSyncNotificationInfo.startTime != null)) {}
        long l2;
        for (long l1 = SyncManager.this.mSyncHandler.mSyncNotificationInfo.startTime.longValue() + SyncManager.SYNC_NOTIFICATION_DELAY;; l1 = Long.MAX_VALUE)
        {
          l2 = Long.MAX_VALUE;
          Iterator localIterator = SyncManager.this.mActiveSyncContexts.iterator();
          while (localIterator.hasNext())
          {
            long l5 = ((SyncManager.ActiveSyncContext)localIterator.next()).mTimeoutStartTime + SyncManager.MAX_TIME_PER_SYNC;
            if (Log.isLoggable("SyncManager", 2)) {
              Log.v("SyncManager", "manageSyncAlarm: active sync, mTimeoutStartTime + MAX is " + l5);
            }
            if (l2 > l5) {
              l2 = l5;
            }
          }
        }
        if (Log.isLoggable("SyncManager", 2)) {
          Log.v("SyncManager", "manageSyncAlarm: notificationTime is " + l1);
        }
        if (Log.isLoggable("SyncManager", 2)) {
          Log.v("SyncManager", "manageSyncAlarm: earliestTimeoutTime is " + l2);
        }
        if (Log.isLoggable("SyncManager", 2)) {
          Log.v("SyncManager", "manageSyncAlarm: nextPeriodicEventElapsedTime is " + paramLong1);
        }
        if (Log.isLoggable("SyncManager", 2)) {
          Log.v("SyncManager", "manageSyncAlarm: nextPendingEventElapsedTime is " + paramLong2);
        }
        long l3 = Math.min(Math.min(Math.min(l1, l2), paramLong1), paramLong2);
        long l4 = SystemClock.elapsedRealtime();
        int j;
        int k;
        if (l3 < 30000L + l4)
        {
          if (Log.isLoggable("SyncManager", 2)) {
            Log.v("SyncManager", "manageSyncAlarm: the alarmTime is too small, " + l3 + ", setting to " + (30000L + l4));
          }
          l3 = l4 + 30000L;
          i = 0;
          if (this.mAlarmScheduleTime == null) {
            break label663;
          }
          j = 1;
          if (l3 == Long.MAX_VALUE) {
            break label669;
          }
          k = 1;
          if (k == 0) {
            break label675;
          }
          if (j != 0)
          {
            boolean bool = l3 < this.mAlarmScheduleTime.longValue();
            i = 0;
            m = 0;
            if (!bool) {
              break label476;
            }
          }
        }
        for (int m = 1;; m = 0)
        {
          SyncManager.this.ensureAlarmService();
          if (m == 0) {
            break label685;
          }
          if (Log.isLoggable("SyncManager", 2)) {
            Log.v("SyncManager", "requesting that the alarm manager wake us up at elapsed time " + l3 + ", now is " + l4 + ", " + (l3 - l4) / 1000L + " secs from now");
          }
          this.mAlarmScheduleTime = Long.valueOf(l3);
          SyncManager.this.mAlarmService.set(2, l3, SyncManager.this.mSyncAlarmIntent);
          return;
          if (l3 <= 7200000L + l4) {
            break;
          }
          if (Log.isLoggable("SyncManager", 2)) {
            Log.v("SyncManager", "manageSyncAlarm: the alarmTime is too large, " + l3 + ", setting to " + (30000L + l4));
          }
          l3 = l4 + 7200000L;
          break;
          j = 0;
          break label428;
          k = 0;
          break label440;
          i = j;
        }
      } while (i == 0);
      this.mAlarmScheduleTime = null;
      SyncManager.this.mAlarmService.cancel(SyncManager.this.mSyncAlarmIntent);
    }
    
    private void manageSyncNotificationLocked()
    {
      boolean bool1;
      int i;
      if (SyncManager.this.mActiveSyncContexts.isEmpty())
      {
        this.mSyncNotificationInfo.startTime = null;
        bool1 = this.mSyncNotificationInfo.isActive;
        i = 0;
      }
      for (;;)
      {
        if ((bool1) && (i == 0))
        {
          SyncManager.access$3802(SyncManager.this, false);
          sendSyncStateIntent();
          this.mSyncNotificationInfo.isActive = false;
        }
        if (i != 0)
        {
          SyncManager.access$3802(SyncManager.this, true);
          sendSyncStateIntent();
          this.mSyncNotificationInfo.isActive = true;
        }
        return;
        long l = SystemClock.elapsedRealtime();
        if (this.mSyncNotificationInfo.startTime == null) {
          this.mSyncNotificationInfo.startTime = Long.valueOf(l);
        }
        if (this.mSyncNotificationInfo.isActive)
        {
          bool1 = false;
          i = 0;
        }
        else
        {
          if (l > this.mSyncNotificationInfo.startTime.longValue() + SyncManager.SYNC_NOTIFICATION_DELAY) {}
          for (int j = 1;; j = 0)
          {
            if (j == 0) {
              break label173;
            }
            i = 1;
            bool1 = false;
            break;
          }
          label173:
          Iterator localIterator = SyncManager.this.mActiveSyncContexts.iterator();
          do
          {
            boolean bool2 = localIterator.hasNext();
            bool1 = false;
            i = 0;
            if (!bool2) {
              break;
            }
          } while (!((SyncManager.ActiveSyncContext)localIterator.next()).mSyncOperation.extras.getBoolean("force", false));
          i = 1;
          bool1 = false;
        }
      }
    }
    
    private long maybeStartNextSyncLocked()
    {
      boolean bool1 = Log.isLoggable("SyncManager", 2);
      if (bool1) {
        Log.v("SyncManager", "maybeStartNextSync");
      }
      if (!SyncManager.this.mDataConnectionIsConnected)
      {
        if (bool1) {
          Log.v("SyncManager", "maybeStartNextSync: no data connection, skipping");
        }
        l2 = Long.MAX_VALUE;
        return l2;
      }
      if (SyncManager.this.mStorageIsLow)
      {
        if (bool1) {
          Log.v("SyncManager", "maybeStartNextSync: memory low, skipping");
        }
        return Long.MAX_VALUE;
      }
      AccountAndUser[] arrayOfAccountAndUser = SyncManager.this.mRunningAccounts;
      if (arrayOfAccountAndUser == SyncManager.INITIAL_ACCOUNTS_ARRAY)
      {
        if (bool1) {
          Log.v("SyncManager", "maybeStartNextSync: accounts not known, skipping");
        }
        return Long.MAX_VALUE;
      }
      boolean bool2 = SyncManager.this.getConnectivityManager().getBackgroundDataSetting();
      long l1 = SystemClock.elapsedRealtime();
      long l2 = Long.MAX_VALUE;
      ArrayList localArrayList = new ArrayList();
      SyncQueue localSyncQueue1 = SyncManager.this.mSyncQueue;
      if (bool1) {}
      Iterator localIterator1;
      HashSet localHashSet;
      label236:
      SyncOperation localSyncOperation3;
      int i4;
      for (;;)
      {
        ActivityManager localActivityManager;
        try
        {
          Log.v("SyncManager", "build the operation array, syncQueue size is " + SyncManager.this.mSyncQueue.getOperations().size());
          localIterator1 = SyncManager.this.mSyncQueue.getOperations().iterator();
          localActivityManager = (ActivityManager)SyncManager.this.mContext.getSystemService("activity");
          localHashSet = Sets.newHashSet();
          if (!localIterator1.hasNext()) {
            break label636;
          }
          localSyncOperation3 = (SyncOperation)localIterator1.next();
          if (!SyncManager.this.containsAccountAndUser(arrayOfAccountAndUser, localSyncOperation3.account, localSyncOperation3.userId))
          {
            localIterator1.remove();
            SyncManager.this.mSyncStorageEngine.deleteFromPending(localSyncOperation3.pendingOperation);
            continue;
          }
          i4 = SyncManager.this.mSyncStorageEngine.getIsSyncable(localSyncOperation3.account, localSyncOperation3.userId, localSyncOperation3.authority);
        }
        finally {}
        if (i4 == 0)
        {
          localIterator1.remove();
          SyncManager.this.mSyncStorageEngine.deleteFromPending(localSyncOperation3.pendingOperation);
        }
        else if (!localActivityManager.isUserRunning(localSyncOperation3.userId))
        {
          if (SyncManager.this.mUserManager.getUserInfo(localSyncOperation3.userId) == null) {
            localHashSet.add(Integer.valueOf(localSyncOperation3.userId));
          }
        }
        else
        {
          if (localSyncOperation3.effectiveRunTime <= l1) {
            break;
          }
          if (l2 > localSyncOperation3.effectiveRunTime) {
            l2 = localSyncOperation3.effectiveRunTime;
          }
        }
      }
      RegisteredServicesCache.ServiceInfo localServiceInfo = SyncManager.this.mSyncAdapters.getServiceInfo(SyncAdapterType.newKey(localSyncOperation3.authority, localSyncOperation3.account.type), localSyncOperation3.userId);
      int i5;
      if (localServiceInfo != null)
      {
        NetworkInfo localNetworkInfo = SyncManager.this.getConnectivityManager().getActiveNetworkInfoForUid(localServiceInfo.uid);
        if ((localNetworkInfo != null) && (localNetworkInfo.isConnected())) {
          i5 = 1;
        }
      }
      for (;;)
      {
        if ((!localSyncOperation3.extras.getBoolean("ignore_settings", false)) && (i4 > 0) && ((!SyncManager.this.mSyncStorageEngine.getMasterSyncAutomatically(localSyncOperation3.userId)) || (!bool2) || (i5 == 0) || (!SyncManager.this.mSyncStorageEngine.getSyncAutomatically(localSyncOperation3.account, localSyncOperation3.userId, localSyncOperation3.authority))))
        {
          localIterator1.remove();
          SyncManager.this.mSyncStorageEngine.deleteFromPending(localSyncOperation3.pendingOperation);
          break label236;
        }
        localArrayList.add(localSyncOperation3);
        break label236;
        label636:
        Iterator localIterator2 = localHashSet.iterator();
        while (localIterator2.hasNext())
        {
          Integer localInteger = (Integer)localIterator2.next();
          if (SyncManager.this.mUserManager.getUserInfo(localInteger.intValue()) == null) {
            SyncManager.this.onUserRemoved(localInteger.intValue());
          }
        }
        if (bool1) {
          Log.v("SyncManager", "sort the candidate operations, size " + localArrayList.size());
        }
        Collections.sort(localArrayList);
        if (bool1) {
          Log.v("SyncManager", "dispatch all ready sync operations");
        }
        int i = 0;
        int j = localArrayList.size();
        while (i < j)
        {
          SyncOperation localSyncOperation1 = (SyncOperation)localArrayList.get(i);
          boolean bool3 = localSyncOperation1.isInitialization();
          int k = 0;
          int m = 0;
          Object localObject2 = null;
          Object localObject3 = null;
          Object localObject4 = null;
          Iterator localIterator3 = SyncManager.this.mActiveSyncContexts.iterator();
          while (localIterator3.hasNext())
          {
            SyncManager.ActiveSyncContext localActiveSyncContext = (SyncManager.ActiveSyncContext)localIterator3.next();
            SyncOperation localSyncOperation2 = localActiveSyncContext.mSyncOperation;
            if (localSyncOperation2.isInitialization()) {
              k++;
            }
            for (;;)
            {
              if ((!localSyncOperation2.account.type.equals(localSyncOperation1.account.type)) || (!localSyncOperation2.authority.equals(localSyncOperation1.authority)) || (localSyncOperation2.userId != localSyncOperation1.userId) || ((localSyncOperation2.allowParallelSyncs) && (!localSyncOperation2.account.name.equals(localSyncOperation1.account.name)))) {
                break label983;
              }
              localObject2 = localActiveSyncContext;
              break;
              m++;
              if ((!localSyncOperation2.isExpedited()) && ((localObject4 == null) || (((SyncManager.ActiveSyncContext)localObject4).mStartTime > localActiveSyncContext.mStartTime))) {
                localObject4 = localActiveSyncContext;
              }
            }
            label983:
            if ((bool3 == localSyncOperation2.isInitialization()) && (localActiveSyncContext.mStartTime + SyncManager.MAX_TIME_PER_SYNC < l1)) {
              localObject3 = localActiveSyncContext;
            }
          }
          if (bool1)
          {
            Log.v("SyncManager", "candidate " + (i + 1) + " of " + j + ": " + localSyncOperation1);
            Log.v("SyncManager", "  numActiveInit=" + k + ", numActiveRegular=" + m);
            Log.v("SyncManager", "  longRunning: " + localObject3);
            Log.v("SyncManager", "  conflict: " + localObject2);
            Log.v("SyncManager", "  oldestNonExpeditedRegular: " + localObject4);
          }
          int i1;
          label1209:
          Object localObject5;
          if (bool3)
          {
            int i3 = SyncManager.MAX_SIMULTANEOUS_INITIALIZATION_SYNCS;
            if (k < i3)
            {
              i1 = 1;
              if (localObject2 == null) {
                break label1451;
              }
              if ((!bool3) || (((SyncManager.ActiveSyncContext)localObject2).mSyncOperation.isInitialization())) {
                break label1376;
              }
              int i2 = SyncManager.MAX_SIMULTANEOUS_INITIALIZATION_SYNCS;
              if (k >= i2) {
                break label1376;
              }
              localObject5 = localObject2;
              if (Log.isLoggable("SyncManager", 2)) {
                Log.v("SyncManager", "canceling and rescheduling sync since an initialization takes higher priority, " + localObject2);
              }
              label1282:
              if (localObject5 != null)
              {
                runSyncFinishedOrCanceledLocked(null, (SyncManager.ActiveSyncContext)localObject5);
                SyncManager.this.scheduleSyncOperation(((SyncManager.ActiveSyncContext)localObject5).mSyncOperation);
              }
            }
          }
          synchronized (SyncManager.this.mSyncQueue)
          {
            SyncManager.this.mSyncQueue.remove(localSyncOperation1);
            dispatchSyncOperation(localSyncOperation1);
            label1376:
            label1451:
            do
            {
              do
              {
                i++;
                break;
                i1 = 0;
                break label1209;
                int n = SyncManager.MAX_SIMULTANEOUS_REGULAR_SYNCS;
                if (m < n)
                {
                  i1 = 1;
                  break label1209;
                }
                i1 = 0;
                break label1209;
              } while ((!localSyncOperation1.expedited) || (((SyncManager.ActiveSyncContext)localObject2).mSyncOperation.expedited) || (bool3 != ((SyncManager.ActiveSyncContext)localObject2).mSyncOperation.isInitialization()));
              localObject5 = localObject2;
              if (!Log.isLoggable("SyncManager", 2)) {
                break label1282;
              }
              Log.v("SyncManager", "canceling and rescheduling sync since an expedited takes higher priority, " + localObject2);
              break label1282;
              localObject5 = null;
              if (i1 != 0) {
                break label1282;
              }
              if ((localSyncOperation1.isExpedited()) && (localObject4 != null) && (!bool3))
              {
                localObject5 = localObject4;
                if (!Log.isLoggable("SyncManager", 2)) {
                  break label1282;
                }
                Log.v("SyncManager", "canceling and rescheduling sync since an expedited is ready to run, " + localObject4);
                break label1282;
              }
            } while ((localObject3 == null) || (bool3 != ((SyncManager.ActiveSyncContext)localObject3).mSyncOperation.isInitialization()));
            localObject5 = localObject3;
            if (!Log.isLoggable("SyncManager", 2)) {
              break label1282;
            }
            Log.v("SyncManager", "canceling and rescheduling sync since it ran roo long, " + localObject3);
          }
        }
        i5 = 0;
        continue;
        i5 = 0;
      }
    }
    
    private void runBoundToSyncAdapter(SyncManager.ActiveSyncContext paramActiveSyncContext, ISyncAdapter paramISyncAdapter)
    {
      paramActiveSyncContext.mSyncAdapter = paramISyncAdapter;
      SyncOperation localSyncOperation = paramActiveSyncContext.mSyncOperation;
      try
      {
        paramActiveSyncContext.mIsLinkedToDeath = true;
        paramISyncAdapter.asBinder().linkToDeath(paramActiveSyncContext, 0);
        paramISyncAdapter.startSync(paramActiveSyncContext, localSyncOperation.authority, localSyncOperation.account, localSyncOperation.extras);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        Log.d("SyncManager", "maybeStartNextSync: caught a RemoteException, rescheduling", localRemoteException);
        closeActiveSyncContext(paramActiveSyncContext);
        SyncManager.this.increaseBackoffSetting(localSyncOperation);
        SyncManager.this.scheduleSyncOperation(new SyncOperation(localSyncOperation));
        return;
      }
      catch (RuntimeException localRuntimeException)
      {
        closeActiveSyncContext(paramActiveSyncContext);
        Log.e("SyncManager", "Caught RuntimeException while starting the sync " + localSyncOperation, localRuntimeException);
      }
    }
    
    private void runSyncFinishedOrCanceledLocked(SyncResult paramSyncResult, SyncManager.ActiveSyncContext paramActiveSyncContext)
    {
      boolean bool = Log.isLoggable("SyncManager", 2);
      if (paramActiveSyncContext.mIsLinkedToDeath)
      {
        paramActiveSyncContext.mSyncAdapter.asBinder().unlinkToDeath(paramActiveSyncContext, 0);
        paramActiveSyncContext.mIsLinkedToDeath = false;
      }
      closeActiveSyncContext(paramActiveSyncContext);
      SyncOperation localSyncOperation = paramActiveSyncContext.mSyncOperation;
      long l = SystemClock.elapsedRealtime() - paramActiveSyncContext.mStartTime;
      String str;
      if (paramSyncResult != null)
      {
        if (bool) {
          Log.v("SyncManager", "runSyncFinishedOrCanceled [finished]: " + localSyncOperation + ", result " + paramSyncResult);
        }
        if (!paramSyncResult.hasError())
        {
          str = "success";
          SyncManager.this.clearBackoffSetting(localSyncOperation);
          SyncManager.this.setDelayUntilTime(localSyncOperation, paramSyncResult.delayUntil);
        }
      }
      for (;;)
      {
        stopSyncEvent(paramActiveSyncContext.mHistoryRowId, localSyncOperation, str, 0, 0, l);
        if ((paramSyncResult != null) && (paramSyncResult.tooManyDeletions))
        {
          installHandleTooManyDeletesNotification(localSyncOperation.account, localSyncOperation.authority, paramSyncResult.stats.numDeletes, localSyncOperation.userId);
          if ((paramSyncResult != null) && (paramSyncResult.fullSyncRequested)) {
            SyncManager.this.scheduleSyncOperation(new SyncOperation(localSyncOperation.account, localSyncOperation.userId, localSyncOperation.syncSource, localSyncOperation.authority, new Bundle(), 0L, localSyncOperation.backoff.longValue(), localSyncOperation.delayUntil, localSyncOperation.allowParallelSyncs));
          }
          return;
          Log.d("SyncManager", "failed sync operation " + localSyncOperation + ", " + paramSyncResult);
          if (!paramSyncResult.syncAlreadyInProgress) {
            SyncManager.this.increaseBackoffSetting(localSyncOperation);
          }
          SyncManager.this.maybeRescheduleSync(paramSyncResult, localSyncOperation);
          str = Integer.toString(syncResultToErrorNumber(paramSyncResult));
          break;
          if (bool) {
            Log.v("SyncManager", "runSyncFinishedOrCanceled [canceled]: " + localSyncOperation);
          }
          if (paramActiveSyncContext.mSyncAdapter == null) {}
        }
        try
        {
          paramActiveSyncContext.mSyncAdapter.cancelSync(paramActiveSyncContext);
          str = "canceled";
          continue;
          SyncManager.this.mNotificationMgr.cancelAsUser(null, localSyncOperation.account.hashCode() ^ localSyncOperation.authority.hashCode(), new UserHandle(localSyncOperation.userId));
        }
        catch (RemoteException localRemoteException)
        {
          for (;;) {}
        }
      }
    }
    
    private long scheduleReadyPeriodicSyncs()
    {
      boolean bool = SyncManager.this.getConnectivityManager().getBackgroundDataSetting();
      long l1 = Long.MAX_VALUE;
      if (!bool) {
        return l1;
      }
      AccountAndUser[] arrayOfAccountAndUser = SyncManager.this.mRunningAccounts;
      long l2 = System.currentTimeMillis();
      if (0L < l2 - SyncManager.this.mSyncRandomOffsetMillis) {}
      SyncStorageEngine.AuthorityInfo localAuthorityInfo;
      SyncStatusInfo localSyncStatusInfo;
      int i;
      Bundle localBundle;
      long l7;
      Pair localPair;
      RegisteredServicesCache.ServiceInfo localServiceInfo;
      for (long l3 = l2 - SyncManager.this.mSyncRandomOffsetMillis;; l3 = 0L)
      {
        Iterator localIterator = SyncManager.this.mSyncStorageEngine.getAuthorities().iterator();
        for (;;)
        {
          if (!localIterator.hasNext()) {
            break label558;
          }
          localAuthorityInfo = (SyncStorageEngine.AuthorityInfo)localIterator.next();
          if ((SyncManager.this.containsAccountAndUser(arrayOfAccountAndUser, localAuthorityInfo.account, localAuthorityInfo.userId)) && (SyncManager.this.mSyncStorageEngine.getMasterSyncAutomatically(localAuthorityInfo.userId)) && (SyncManager.this.mSyncStorageEngine.getSyncAutomatically(localAuthorityInfo.account, localAuthorityInfo.userId, localAuthorityInfo.authority)) && (SyncManager.this.mSyncStorageEngine.getIsSyncable(localAuthorityInfo.account, localAuthorityInfo.userId, localAuthorityInfo.authority) != 0))
          {
            localSyncStatusInfo = SyncManager.this.mSyncStorageEngine.getOrCreateSyncStatus(localAuthorityInfo);
            i = 0;
            int j = localAuthorityInfo.periodicSyncs.size();
            while (i < j)
            {
              localBundle = (Bundle)((Pair)localAuthorityInfo.periodicSyncs.get(i)).first;
              Long localLong = Long.valueOf(1000L * ((Long)((Pair)localAuthorityInfo.periodicSyncs.get(i)).second).longValue());
              long l6 = localSyncStatusInfo.getPeriodicSyncTime(i);
              l7 = localLong.longValue() - l3 % localLong.longValue();
              if ((l7 != localLong.longValue()) && (l6 <= l2) && (l2 - l6 < localLong.longValue())) {
                break label532;
              }
              localPair = SyncManager.this.mSyncStorageEngine.getBackoff(localAuthorityInfo.account, localAuthorityInfo.userId, localAuthorityInfo.authority);
              localServiceInfo = SyncManager.this.mSyncAdapters.getServiceInfo(SyncAdapterType.newKey(localAuthorityInfo.authority, localAuthorityInfo.account.type), localAuthorityInfo.userId);
              if (localServiceInfo != null) {
                break label418;
              }
              i++;
            }
          }
        }
      }
      label418:
      SyncManager localSyncManager = SyncManager.this;
      Account localAccount = localAuthorityInfo.account;
      int k = localAuthorityInfo.userId;
      String str = localAuthorityInfo.authority;
      if (localPair != null) {}
      for (long l8 = ((Long)localPair.first).longValue();; l8 = 0L)
      {
        localSyncManager.scheduleSyncOperation(new SyncOperation(localAccount, k, 4, str, localBundle, 0L, l8, SyncManager.this.mSyncStorageEngine.getDelayUntilTime(localAuthorityInfo.account, localAuthorityInfo.userId, localAuthorityInfo.authority), ((SyncAdapterType)localServiceInfo.type).allowParallelSyncs()));
        localSyncStatusInfo.setPeriodicSyncTime(i, l2);
        label532:
        long l9 = l2 + l7;
        if (l9 >= l1) {
          break;
        }
        l1 = l9;
        break;
      }
      label558:
      if (l1 == Long.MAX_VALUE) {
        return Long.MAX_VALUE;
      }
      long l4 = SystemClock.elapsedRealtime();
      if (l1 < l2) {}
      for (long l5 = 0L;; l5 = l1 - l2) {
        return l5 + l4;
      }
    }
    
    private void sendSyncStateIntent()
    {
      Intent localIntent = new Intent("android.intent.action.SYNC_STATE_CHANGED");
      localIntent.addFlags(134217728);
      localIntent.putExtra("active", SyncManager.this.mNeedSyncActiveNotification);
      localIntent.putExtra("failing", false);
      SyncManager.this.mContext.sendBroadcastAsUser(localIntent, UserHandle.OWNER);
    }
    
    private int syncResultToErrorNumber(SyncResult paramSyncResult)
    {
      if (paramSyncResult.syncAlreadyInProgress) {
        return 1;
      }
      if (paramSyncResult.stats.numAuthExceptions > 0L) {
        return 2;
      }
      if (paramSyncResult.stats.numIoExceptions > 0L) {
        return 3;
      }
      if (paramSyncResult.stats.numParseExceptions > 0L) {
        return 4;
      }
      if (paramSyncResult.stats.numConflictDetectedExceptions > 0L) {
        return 5;
      }
      if (paramSyncResult.tooManyDeletions) {
        return 6;
      }
      if (paramSyncResult.tooManyRetries) {
        return 7;
      }
      if (paramSyncResult.databaseError) {
        return 8;
      }
      throw new IllegalStateException("we are not in an error state, " + paramSyncResult);
    }
    
    private void waitUntilReadyToRun()
    {
      CountDownLatch localCountDownLatch = this.mReadyToRunLatch;
      if (localCountDownLatch != null) {}
      for (;;)
      {
        try
        {
          localCountDownLatch.await();
          this.mReadyToRunLatch = null;
          return;
        }
        catch (InterruptedException localInterruptedException)
        {
          Thread.currentThread().interrupt();
        }
      }
    }
    
    /* Error */
    public void handleMessage(Message paramMessage)
    {
      // Byte code:
      //   0: ldc2_w 473
      //   3: lstore_2
      //   4: ldc2_w 473
      //   7: lstore 4
      //   9: aload_0
      //   10: invokespecial 1017	android/content/SyncManager$SyncHandler:waitUntilReadyToRun	()V
      //   13: aload_0
      //   14: getfield 34	android/content/SyncManager$SyncHandler:this$0	Landroid/content/SyncManager;
      //   17: aload_0
      //   18: getfield 34	android/content/SyncManager$SyncHandler:this$0	Landroid/content/SyncManager;
      //   21: invokestatic 1020	android/content/SyncManager:access$500	(Landroid/content/SyncManager;)Z
      //   24: invokestatic 1023	android/content/SyncManager:access$402	(Landroid/content/SyncManager;Z)Z
      //   27: pop
      //   28: aload_0
      //   29: getfield 34	android/content/SyncManager$SyncHandler:this$0	Landroid/content/SyncManager;
      //   32: invokestatic 1027	android/content/SyncManager:access$2300	(Landroid/content/SyncManager;)Landroid/os/PowerManager$WakeLock;
      //   35: invokevirtual 1030	android/os/PowerManager$WakeLock:acquire	()V
      //   38: aload_0
      //   39: invokespecial 1032	android/content/SyncManager$SyncHandler:scheduleReadyPeriodicSyncs	()J
      //   42: lstore_2
      //   43: aload_1
      //   44: getfield 1037	android/os/Message:what	I
      //   47: istore 8
      //   49: iload 8
      //   51: tableswitch	default:+37->88, 1:+164->215, 2:+504->555, 3:+565->616, 4:+295->346, 5:+375->426, 6:+66->117
      //   88: aload_0
      //   89: invokespecial 1039	android/content/SyncManager$SyncHandler:manageSyncNotificationLocked	()V
      //   92: aload_0
      //   93: lload_2
      //   94: lload 4
      //   96: invokespecial 1041	android/content/SyncManager$SyncHandler:manageSyncAlarmLocked	(JJ)V
      //   99: aload_0
      //   100: getfield 53	android/content/SyncManager$SyncHandler:mSyncTimeTracker	Landroid/content/SyncManager$SyncTimeTracker;
      //   103: invokevirtual 1044	android/content/SyncManager$SyncTimeTracker:update	()V
      //   106: aload_0
      //   107: getfield 34	android/content/SyncManager$SyncHandler:this$0	Landroid/content/SyncManager;
      //   110: invokestatic 1027	android/content/SyncManager:access$2300	(Landroid/content/SyncManager;)Landroid/os/PowerManager$WakeLock;
      //   113: invokevirtual 1047	android/os/PowerManager$WakeLock:release	()V
      //   116: return
      //   117: aload_1
      //   118: getfield 1050	android/os/Message:obj	Ljava/lang/Object;
      //   121: checkcast 262	android/util/Pair
      //   124: astore 27
      //   126: ldc -94
      //   128: iconst_2
      //   129: invokestatic 168	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
      //   132: ifeq +50 -> 182
      //   135: ldc -94
      //   137: new 170	java/lang/StringBuilder
      //   140: dup
      //   141: invokespecial 172	java/lang/StringBuilder:<init>	()V
      //   144: ldc_w 1052
      //   147: invokevirtual 178	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   150: aload 27
      //   152: getfield 922	android/util/Pair:first	Ljava/lang/Object;
      //   155: invokevirtual 181	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   158: ldc_w 521
      //   161: invokevirtual 178	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   164: aload 27
      //   166: getfield 925	android/util/Pair:second	Ljava/lang/Object;
      //   169: checkcast 127	java/lang/String
      //   172: invokevirtual 178	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   175: invokevirtual 185	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   178: invokestatic 225	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
      //   181: pop
      //   182: aload_0
      //   183: aload 27
      //   185: getfield 922	android/util/Pair:first	Ljava/lang/Object;
      //   188: checkcast 117	android/accounts/Account
      //   191: aload_1
      //   192: getfield 1055	android/os/Message:arg1	I
      //   195: aload 27
      //   197: getfield 925	android/util/Pair:second	Ljava/lang/Object;
      //   200: checkcast 127	java/lang/String
      //   203: invokespecial 1057	android/content/SyncManager$SyncHandler:cancelActiveSyncLocked	(Landroid/accounts/Account;ILjava/lang/String;)V
      //   206: aload_0
      //   207: invokespecial 1059	android/content/SyncManager$SyncHandler:maybeStartNextSyncLocked	()J
      //   210: lstore 4
      //   212: goto -124 -> 88
      //   215: ldc -94
      //   217: iconst_2
      //   218: invokestatic 168	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
      //   221: ifeq +12 -> 233
      //   224: ldc -94
      //   226: ldc_w 1061
      //   229: invokestatic 189	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
      //   232: pop
      //   233: aload_1
      //   234: getfield 1050	android/os/Message:obj	Ljava/lang/Object;
      //   237: checkcast 1063	android/content/SyncManager$SyncHandlerMessagePayload
      //   240: astore 24
      //   242: aload_0
      //   243: getfield 34	android/content/SyncManager$SyncHandler:this$0	Landroid/content/SyncManager;
      //   246: aload 24
      //   248: getfield 1067	android/content/SyncManager$SyncHandlerMessagePayload:activeSyncContext	Landroid/content/SyncManager$ActiveSyncContext;
      //   251: invokestatic 1071	android/content/SyncManager:access$2400	(Landroid/content/SyncManager;Landroid/content/SyncManager$ActiveSyncContext;)Z
      //   254: ifne +69 -> 323
      //   257: ldc -94
      //   259: new 170	java/lang/StringBuilder
      //   262: dup
      //   263: invokespecial 172	java/lang/StringBuilder:<init>	()V
      //   266: ldc_w 1073
      //   269: invokevirtual 178	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   272: aload 24
      //   274: getfield 1067	android/content/SyncManager$SyncHandlerMessagePayload:activeSyncContext	Landroid/content/SyncManager$ActiveSyncContext;
      //   277: invokevirtual 181	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   280: invokevirtual 185	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   283: invokestatic 225	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
      //   286: pop
      //   287: goto -199 -> 88
      //   290: astore 6
      //   292: aload_0
      //   293: invokespecial 1039	android/content/SyncManager$SyncHandler:manageSyncNotificationLocked	()V
      //   296: aload_0
      //   297: lload_2
      //   298: lload 4
      //   300: invokespecial 1041	android/content/SyncManager$SyncHandler:manageSyncAlarmLocked	(JJ)V
      //   303: aload_0
      //   304: getfield 53	android/content/SyncManager$SyncHandler:mSyncTimeTracker	Landroid/content/SyncManager$SyncTimeTracker;
      //   307: invokevirtual 1044	android/content/SyncManager$SyncTimeTracker:update	()V
      //   310: aload_0
      //   311: getfield 34	android/content/SyncManager$SyncHandler:this$0	Landroid/content/SyncManager;
      //   314: invokestatic 1027	android/content/SyncManager:access$2300	(Landroid/content/SyncManager;)Landroid/os/PowerManager$WakeLock;
      //   317: invokevirtual 1047	android/os/PowerManager$WakeLock:release	()V
      //   320: aload 6
      //   322: athrow
      //   323: aload_0
      //   324: aload 24
      //   326: getfield 1077	android/content/SyncManager$SyncHandlerMessagePayload:syncResult	Landroid/content/SyncResult;
      //   329: aload 24
      //   331: getfield 1067	android/content/SyncManager$SyncHandlerMessagePayload:activeSyncContext	Landroid/content/SyncManager$ActiveSyncContext;
      //   334: invokespecial 135	android/content/SyncManager$SyncHandler:runSyncFinishedOrCanceledLocked	(Landroid/content/SyncResult;Landroid/content/SyncManager$ActiveSyncContext;)V
      //   337: aload_0
      //   338: invokespecial 1059	android/content/SyncManager$SyncHandler:maybeStartNextSyncLocked	()J
      //   341: lstore 4
      //   343: goto -255 -> 88
      //   346: aload_1
      //   347: getfield 1050	android/os/Message:obj	Ljava/lang/Object;
      //   350: checkcast 1079	android/content/SyncManager$ServiceConnectionData
      //   353: astore 22
      //   355: ldc -94
      //   357: iconst_2
      //   358: invokestatic 168	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
      //   361: ifeq +33 -> 394
      //   364: ldc -94
      //   366: new 170	java/lang/StringBuilder
      //   369: dup
      //   370: invokespecial 172	java/lang/StringBuilder:<init>	()V
      //   373: ldc_w 1081
      //   376: invokevirtual 178	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   379: aload 22
      //   381: getfield 1082	android/content/SyncManager$ServiceConnectionData:activeSyncContext	Landroid/content/SyncManager$ActiveSyncContext;
      //   384: invokevirtual 181	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   387: invokevirtual 185	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   390: invokestatic 225	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
      //   393: pop
      //   394: aload_0
      //   395: getfield 34	android/content/SyncManager$SyncHandler:this$0	Landroid/content/SyncManager;
      //   398: aload 22
      //   400: getfield 1082	android/content/SyncManager$ServiceConnectionData:activeSyncContext	Landroid/content/SyncManager$ActiveSyncContext;
      //   403: invokestatic 1071	android/content/SyncManager:access$2400	(Landroid/content/SyncManager;Landroid/content/SyncManager$ActiveSyncContext;)Z
      //   406: ifeq -318 -> 88
      //   409: aload_0
      //   410: aload 22
      //   412: getfield 1082	android/content/SyncManager$ServiceConnectionData:activeSyncContext	Landroid/content/SyncManager$ActiveSyncContext;
      //   415: aload 22
      //   417: getfield 1085	android/content/SyncManager$ServiceConnectionData:syncAdapter	Landroid/content/ISyncAdapter;
      //   420: invokespecial 1087	android/content/SyncManager$SyncHandler:runBoundToSyncAdapter	(Landroid/content/SyncManager$ActiveSyncContext;Landroid/content/ISyncAdapter;)V
      //   423: goto -335 -> 88
      //   426: aload_1
      //   427: getfield 1050	android/os/Message:obj	Ljava/lang/Object;
      //   430: checkcast 1079	android/content/SyncManager$ServiceConnectionData
      //   433: getfield 1082	android/content/SyncManager$ServiceConnectionData:activeSyncContext	Landroid/content/SyncManager$ActiveSyncContext;
      //   436: astore 16
      //   438: ldc -94
      //   440: iconst_2
      //   441: invokestatic 168	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
      //   444: ifeq +30 -> 474
      //   447: ldc -94
      //   449: new 170	java/lang/StringBuilder
      //   452: dup
      //   453: invokespecial 172	java/lang/StringBuilder:<init>	()V
      //   456: ldc_w 1089
      //   459: invokevirtual 178	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   462: aload 16
      //   464: invokevirtual 181	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   467: invokevirtual 185	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   470: invokestatic 225	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
      //   473: pop
      //   474: aload_0
      //   475: getfield 34	android/content/SyncManager$SyncHandler:this$0	Landroid/content/SyncManager;
      //   478: aload 16
      //   480: invokestatic 1071	android/content/SyncManager:access$2400	(Landroid/content/SyncManager;Landroid/content/SyncManager$ActiveSyncContext;)Z
      //   483: ifeq -395 -> 88
      //   486: aload 16
      //   488: getfield 777	android/content/SyncManager$ActiveSyncContext:mSyncAdapter	Landroid/content/ISyncAdapter;
      //   491: astore 17
      //   493: aload 17
      //   495: ifnull +15 -> 510
      //   498: aload 16
      //   500: getfield 777	android/content/SyncManager$ActiveSyncContext:mSyncAdapter	Landroid/content/ISyncAdapter;
      //   503: aload 16
      //   505: invokeinterface 891 2 0
      //   510: new 821	android/content/SyncResult
      //   513: dup
      //   514: invokespecial 1090	android/content/SyncResult:<init>	()V
      //   517: astore 18
      //   519: aload 18
      //   521: getfield 850	android/content/SyncResult:stats	Landroid/content/SyncStats;
      //   524: astore 19
      //   526: aload 19
      //   528: lconst_1
      //   529: aload 19
      //   531: getfield 981	android/content/SyncStats:numIoExceptions	J
      //   534: ladd
      //   535: putfield 981	android/content/SyncStats:numIoExceptions	J
      //   538: aload_0
      //   539: aload 18
      //   541: aload 16
      //   543: invokespecial 135	android/content/SyncManager$SyncHandler:runSyncFinishedOrCanceledLocked	(Landroid/content/SyncResult;Landroid/content/SyncManager$ActiveSyncContext;)V
      //   546: aload_0
      //   547: invokespecial 1059	android/content/SyncManager$SyncHandler:maybeStartNextSyncLocked	()J
      //   550: lstore 4
      //   552: goto -464 -> 88
      //   555: ldc -94
      //   557: iconst_2
      //   558: invokestatic 168	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
      //   561: ifeq +12 -> 573
      //   564: ldc -94
      //   566: ldc_w 1092
      //   569: invokestatic 189	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
      //   572: pop
      //   573: aload_0
      //   574: aconst_null
      //   575: putfield 46	android/content/SyncManager$SyncHandler:mAlarmScheduleTime	Ljava/lang/Long;
      //   578: aload_0
      //   579: invokespecial 1059	android/content/SyncManager$SyncHandler:maybeStartNextSyncLocked	()J
      //   582: lstore 13
      //   584: lload 13
      //   586: lstore 4
      //   588: aload_0
      //   589: getfield 34	android/content/SyncManager$SyncHandler:this$0	Landroid/content/SyncManager;
      //   592: invokestatic 1095	android/content/SyncManager:access$1100	(Landroid/content/SyncManager;)Landroid/os/PowerManager$WakeLock;
      //   595: invokevirtual 1047	android/os/PowerManager$WakeLock:release	()V
      //   598: goto -510 -> 88
      //   601: astore 12
      //   603: aload_0
      //   604: getfield 34	android/content/SyncManager$SyncHandler:this$0	Landroid/content/SyncManager;
      //   607: invokestatic 1095	android/content/SyncManager:access$1100	(Landroid/content/SyncManager;)Landroid/os/PowerManager$WakeLock;
      //   610: invokevirtual 1047	android/os/PowerManager$WakeLock:release	()V
      //   613: aload 12
      //   615: athrow
      //   616: ldc -94
      //   618: iconst_2
      //   619: invokestatic 168	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
      //   622: ifeq +12 -> 634
      //   625: ldc -94
      //   627: ldc_w 1097
      //   630: invokestatic 189	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
      //   633: pop
      //   634: aload_0
      //   635: invokespecial 1059	android/content/SyncManager$SyncHandler:maybeStartNextSyncLocked	()J
      //   638: lstore 9
      //   640: lload 9
      //   642: lstore 4
      //   644: goto -556 -> 88
      //   647: astore 20
      //   649: goto -139 -> 510
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	652	0	this	SyncHandler
      //   0	652	1	paramMessage	Message
      //   3	295	2	l1	long
      //   7	636	4	l2	long
      //   290	31	6	localObject1	Object
      //   47	3	8	i	int
      //   638	3	9	l3	long
      //   601	13	12	localObject2	Object
      //   582	3	13	l4	long
      //   436	106	16	localActiveSyncContext	SyncManager.ActiveSyncContext
      //   491	3	17	localISyncAdapter	ISyncAdapter
      //   517	23	18	localSyncResult	SyncResult
      //   524	6	19	localSyncStats	SyncStats
      //   647	1	20	localRemoteException	RemoteException
      //   353	63	22	localServiceConnectionData	SyncManager.ServiceConnectionData
      //   240	90	24	localSyncHandlerMessagePayload	SyncManager.SyncHandlerMessagePayload
      //   124	72	27	localPair	Pair
      // Exception table:
      //   from	to	target	type
      //   9	49	290	finally
      //   117	182	290	finally
      //   182	212	290	finally
      //   215	233	290	finally
      //   233	287	290	finally
      //   323	343	290	finally
      //   346	394	290	finally
      //   394	423	290	finally
      //   426	474	290	finally
      //   474	493	290	finally
      //   498	510	290	finally
      //   510	552	290	finally
      //   555	573	290	finally
      //   573	578	290	finally
      //   588	598	290	finally
      //   603	616	290	finally
      //   616	634	290	finally
      //   634	640	290	finally
      //   578	584	601	finally
      //   498	510	647	android/os/RemoteException
    }
    
    public long insertStartSyncEvent(SyncOperation paramSyncOperation)
    {
      int i = paramSyncOperation.syncSource;
      long l = System.currentTimeMillis();
      Object[] arrayOfObject = new Object[4];
      arrayOfObject[0] = paramSyncOperation.authority;
      arrayOfObject[1] = Integer.valueOf(0);
      arrayOfObject[2] = Integer.valueOf(i);
      arrayOfObject[3] = Integer.valueOf(paramSyncOperation.account.name.hashCode());
      EventLog.writeEvent(2720, arrayOfObject);
      return SyncManager.this.mSyncStorageEngine.insertStartSyncEvent(paramSyncOperation.account, paramSyncOperation.userId, paramSyncOperation.authority, l, i, paramSyncOperation.isInitialization());
    }
    
    public void onBootCompleted()
    {
      SyncManager.access$2002(SyncManager.this, true);
      SyncManager.this.doDatabaseCleanup();
      if (this.mReadyToRunLatch != null) {
        this.mReadyToRunLatch.countDown();
      }
    }
    
    public void stopSyncEvent(long paramLong1, SyncOperation paramSyncOperation, String paramString, int paramInt1, int paramInt2, long paramLong2)
    {
      Object[] arrayOfObject = new Object[4];
      arrayOfObject[0] = paramSyncOperation.authority;
      arrayOfObject[1] = Integer.valueOf(1);
      arrayOfObject[2] = Integer.valueOf(paramSyncOperation.syncSource);
      arrayOfObject[3] = Integer.valueOf(paramSyncOperation.account.name.hashCode());
      EventLog.writeEvent(2720, arrayOfObject);
      SyncManager.this.mSyncStorageEngine.stopSyncEvent(paramLong1, paramLong2, paramString, paramInt2, paramInt1);
    }
    
    class SyncNotificationInfo
    {
      public boolean isActive = false;
      public Long startTime = null;
      
      SyncNotificationInfo() {}
      
      public String toString()
      {
        StringBuilder localStringBuilder = new StringBuilder();
        toString(localStringBuilder);
        return localStringBuilder.toString();
      }
      
      public void toString(StringBuilder paramStringBuilder)
      {
        paramStringBuilder.append("isActive ").append(this.isActive).append(", startTime ").append(this.startTime);
      }
    }
  }
  
  class SyncHandlerMessagePayload
  {
    public final SyncManager.ActiveSyncContext activeSyncContext;
    public final SyncResult syncResult;
    
    SyncHandlerMessagePayload(SyncManager.ActiveSyncContext paramActiveSyncContext, SyncResult paramSyncResult)
    {
      this.activeSyncContext = paramActiveSyncContext;
      this.syncResult = paramSyncResult;
    }
  }
  
  private class SyncTimeTracker
  {
    boolean mLastWasSyncing = false;
    private long mTimeSpentSyncing;
    long mWhenSyncStarted = 0L;
    
    private SyncTimeTracker() {}
    
    /* Error */
    public long timeSpentSyncing()
    {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield 20	android/content/SyncManager$SyncTimeTracker:mLastWasSyncing	Z
      //   6: ifne +14 -> 20
      //   9: aload_0
      //   10: getfield 29	android/content/SyncManager$SyncTimeTracker:mTimeSpentSyncing	J
      //   13: lstore 8
      //   15: aload_0
      //   16: monitorexit
      //   17: lload 8
      //   19: lreturn
      //   20: invokestatic 34	android/os/SystemClock:elapsedRealtime	()J
      //   23: lstore_2
      //   24: aload_0
      //   25: getfield 29	android/content/SyncManager$SyncTimeTracker:mTimeSpentSyncing	J
      //   28: lstore 4
      //   30: aload_0
      //   31: getfield 22	android/content/SyncManager$SyncTimeTracker:mWhenSyncStarted	J
      //   34: lstore 6
      //   36: lload 4
      //   38: lload_2
      //   39: lload 6
      //   41: lsub
      //   42: ladd
      //   43: lstore 8
      //   45: goto -30 -> 15
      //   48: astore_1
      //   49: aload_0
      //   50: monitorexit
      //   51: aload_1
      //   52: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	53	0	this	SyncTimeTracker
      //   48	4	1	localObject	Object
      //   23	16	2	l1	long
      //   28	9	4	l2	long
      //   34	6	6	l3	long
      //   13	31	8	l4	long
      // Exception table:
      //   from	to	target	type
      //   2	15	48	finally
      //   20	36	48	finally
    }
    
    public void update()
    {
      for (;;)
      {
        try
        {
          boolean bool1;
          if (!SyncManager.this.mActiveSyncContexts.isEmpty())
          {
            bool1 = true;
            boolean bool2 = this.mLastWasSyncing;
            if (bool1 != bool2) {}
          }
          else
          {
            bool1 = false;
            continue;
          }
          long l = SystemClock.elapsedRealtime();
          if (bool1)
          {
            this.mWhenSyncStarted = l;
            this.mLastWasSyncing = bool1;
          }
          else
          {
            this.mTimeSpentSyncing += l - this.mWhenSyncStarted;
          }
        }
        finally {}
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\SyncManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.content;

import android.accounts.Account;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface ISyncAdapter
  extends IInterface
{
  public abstract void cancelSync(ISyncContext paramISyncContext)
    throws RemoteException;
  
  public abstract void initialize(Account paramAccount, String paramString)
    throws RemoteException;
  
  public abstract void startSync(ISyncContext paramISyncContext, String paramString, Account paramAccount, Bundle paramBundle)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements ISyncAdapter
  {
    private static final String DESCRIPTOR = "android.content.ISyncAdapter";
    static final int TRANSACTION_cancelSync = 2;
    static final int TRANSACTION_initialize = 3;
    static final int TRANSACTION_startSync = 1;
    
    public Stub()
    {
      attachInterface(this, "android.content.ISyncAdapter");
    }
    
    public static ISyncAdapter asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.content.ISyncAdapter");
      if ((localIInterface != null) && ((localIInterface instanceof ISyncAdapter))) {
        return (ISyncAdapter)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.content.ISyncAdapter");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.content.ISyncAdapter");
        ISyncContext localISyncContext = ISyncContext.Stub.asInterface(paramParcel1.readStrongBinder());
        String str = paramParcel1.readString();
        Account localAccount2;
        if (paramParcel1.readInt() != 0)
        {
          localAccount2 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label145;
          }
        }
        for (Bundle localBundle = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);; localBundle = null)
        {
          startSync(localISyncContext, str, localAccount2, localBundle);
          return true;
          localAccount2 = null;
          break;
        }
      case 2: 
        label145:
        paramParcel1.enforceInterface("android.content.ISyncAdapter");
        cancelSync(ISyncContext.Stub.asInterface(paramParcel1.readStrongBinder()));
        return true;
      }
      paramParcel1.enforceInterface("android.content.ISyncAdapter");
      if (paramParcel1.readInt() != 0) {}
      for (Account localAccount1 = (Account)Account.CREATOR.createFromParcel(paramParcel1);; localAccount1 = null)
      {
        initialize(localAccount1, paramParcel1.readString());
        return true;
      }
    }
    
    private static class Proxy
      implements ISyncAdapter
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public void cancelSync(ISyncContext paramISyncContext)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.content.ISyncAdapter");
          IBinder localIBinder = null;
          if (paramISyncContext != null) {
            localIBinder = paramISyncContext.asBinder();
          }
          localParcel.writeStrongBinder(localIBinder);
          this.mRemote.transact(2, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.content.ISyncAdapter";
      }
      
      /* Error */
      public void initialize(Account paramAccount, String paramString)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: aload_3
        //   5: ldc 29
        //   7: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   10: aload_1
        //   11: ifnull +38 -> 49
        //   14: aload_3
        //   15: iconst_1
        //   16: invokevirtual 57	android/os/Parcel:writeInt	(I)V
        //   19: aload_1
        //   20: aload_3
        //   21: iconst_0
        //   22: invokevirtual 63	android/accounts/Account:writeToParcel	(Landroid/os/Parcel;I)V
        //   25: aload_3
        //   26: aload_2
        //   27: invokevirtual 66	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   30: aload_0
        //   31: getfield 15	android/content/ISyncAdapter$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   34: iconst_3
        //   35: aload_3
        //   36: aconst_null
        //   37: iconst_1
        //   38: invokeinterface 46 5 0
        //   43: pop
        //   44: aload_3
        //   45: invokevirtual 49	android/os/Parcel:recycle	()V
        //   48: return
        //   49: aload_3
        //   50: iconst_0
        //   51: invokevirtual 57	android/os/Parcel:writeInt	(I)V
        //   54: goto -29 -> 25
        //   57: astore 4
        //   59: aload_3
        //   60: invokevirtual 49	android/os/Parcel:recycle	()V
        //   63: aload 4
        //   65: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	66	0	this	Proxy
        //   0	66	1	paramAccount	Account
        //   0	66	2	paramString	String
        //   3	57	3	localParcel	Parcel
        //   57	7	4	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   4	10	57	finally
        //   14	25	57	finally
        //   25	44	57	finally
        //   49	54	57	finally
      }
      
      public void startSync(ISyncContext paramISyncContext, String paramString, Account paramAccount, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel.writeInterfaceToken("android.content.ISyncAdapter");
            IBinder localIBinder = null;
            if (paramISyncContext != null) {
              localIBinder = paramISyncContext.asBinder();
            }
            localParcel.writeStrongBinder(localIBinder);
            localParcel.writeString(paramString);
            if (paramAccount != null)
            {
              localParcel.writeInt(1);
              paramAccount.writeToParcel(localParcel, 0);
              if (paramBundle != null)
              {
                localParcel.writeInt(1);
                paramBundle.writeToParcel(localParcel, 0);
                this.mRemote.transact(1, localParcel, null, 1);
              }
            }
            else
            {
              localParcel.writeInt(0);
              continue;
            }
            localParcel.writeInt(0);
          }
          finally
          {
            localParcel.recycle();
          }
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\ISyncAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
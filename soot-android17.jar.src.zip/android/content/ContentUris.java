package android.content;

import android.net.Uri;
import android.net.Uri.Builder;

public class ContentUris
{
  public static Uri.Builder appendId(Uri.Builder paramBuilder, long paramLong)
  {
    return paramBuilder.appendEncodedPath(String.valueOf(paramLong));
  }
  
  public static long parseId(Uri paramUri)
  {
    String str = paramUri.getLastPathSegment();
    if (str == null) {
      return -1L;
    }
    return Long.parseLong(str);
  }
  
  public static Uri withAppendedId(Uri paramUri, long paramLong)
  {
    return appendId(paramUri.buildUpon(), paramLong).build();
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\content\ContentUris.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
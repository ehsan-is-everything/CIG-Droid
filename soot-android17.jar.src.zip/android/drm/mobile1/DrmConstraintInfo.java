package android.drm.mobile1;

import java.util.Date;

public class DrmConstraintInfo
{
  private int count = -1;
  private long endDate = -1L;
  private long interval = -1L;
  private long startDate = -1L;
  
  public int getCount()
  {
    return this.count;
  }
  
  public Date getEndDate()
  {
    if (this.endDate == -1L) {
      return null;
    }
    return new Date(this.endDate);
  }
  
  public long getInterval()
  {
    return this.interval;
  }
  
  public Date getStartDate()
  {
    if (this.startDate == -1L) {
      return null;
    }
    return new Date(this.startDate);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\drm\mobile1\DrmConstraintInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
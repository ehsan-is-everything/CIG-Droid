package android.drm;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;

public class DrmManagerClient
{
  private static final int ACTION_PROCESS_DRM_INFO = 1002;
  private static final int ACTION_REMOVE_ALL_RIGHTS = 1001;
  public static final int ERROR_NONE = 0;
  public static final int ERROR_UNKNOWN = -2000;
  private static final String TAG = "DrmManagerClient";
  private Context mContext;
  private EventHandler mEventHandler;
  HandlerThread mEventThread;
  private InfoHandler mInfoHandler;
  HandlerThread mInfoThread;
  private int mNativeContext;
  private OnErrorListener mOnErrorListener;
  private OnEventListener mOnEventListener;
  private OnInfoListener mOnInfoListener;
  private boolean mReleased;
  private int mUniqueId;
  
  static
  {
    System.loadLibrary("drmframework_jni");
  }
  
  public DrmManagerClient(Context paramContext)
  {
    this.mContext = paramContext;
    this.mReleased = false;
    createEventThreads();
    this.mUniqueId = _initialize();
  }
  
  private native DrmInfo _acquireDrmInfo(int paramInt, DrmInfoRequest paramDrmInfoRequest);
  
  private native boolean _canHandle(int paramInt, String paramString1, String paramString2);
  
  private native int _checkRightsStatus(int paramInt1, String paramString, int paramInt2);
  
  private native DrmConvertedStatus _closeConvertSession(int paramInt1, int paramInt2);
  
  private native DrmConvertedStatus _convertData(int paramInt1, int paramInt2, byte[] paramArrayOfByte);
  
  private native DrmSupportInfo[] _getAllSupportInfo(int paramInt);
  
  private native ContentValues _getConstraints(int paramInt1, String paramString, int paramInt2);
  
  private native int _getDrmObjectType(int paramInt, String paramString1, String paramString2);
  
  private native ContentValues _getMetadata(int paramInt, String paramString);
  
  private native String _getOriginalMimeType(int paramInt, String paramString, FileDescriptor paramFileDescriptor);
  
  private native int _initialize();
  
  private native void _installDrmEngine(int paramInt, String paramString);
  
  private native int _openConvertSession(int paramInt, String paramString);
  
  private native DrmInfoStatus _processDrmInfo(int paramInt, DrmInfo paramDrmInfo);
  
  private native void _release(int paramInt);
  
  private native int _removeAllRights(int paramInt);
  
  private native int _removeRights(int paramInt, String paramString);
  
  private native int _saveRights(int paramInt, DrmRights paramDrmRights, String paramString1, String paramString2);
  
  private native void _setListeners(int paramInt, Object paramObject);
  
  private String convertUriToPath(Uri paramUri)
  {
    Object localObject1 = null;
    String str1;
    if (paramUri != null)
    {
      str1 = paramUri.getScheme();
      if ((str1 != null) && (!str1.equals("")) && (!str1.equals("file"))) {
        break label40;
      }
      localObject1 = paramUri.getPath();
    }
    label40:
    Cursor localCursor;
    do
    {
      return (String)localObject1;
      if (str1.equals("http")) {
        return paramUri.toString();
      }
      if (!str1.equals("content")) {
        break;
      }
      String[] arrayOfString = { "_data" };
      localCursor = null;
      try
      {
        localCursor = this.mContext.getContentResolver().query(paramUri, arrayOfString, null, null, null);
        if ((localCursor == null) || (localCursor.getCount() == 0) || (!localCursor.moveToFirst())) {
          throw new IllegalArgumentException("Given Uri could not be found in media store");
        }
      }
      catch (SQLiteException localSQLiteException)
      {
        throw new IllegalArgumentException("Given Uri is not formatted in a way so that it can be found in media store.");
      }
      finally
      {
        if (localCursor != null) {
          localCursor.close();
        }
      }
      String str2 = localCursor.getString(localCursor.getColumnIndexOrThrow("_data"));
      localObject1 = str2;
    } while (localCursor == null);
    localCursor.close();
    return (String)localObject1;
    throw new IllegalArgumentException("Given Uri scheme is not supported");
  }
  
  private void createEventThreads()
  {
    if ((this.mEventHandler == null) && (this.mInfoHandler == null))
    {
      this.mInfoThread = new HandlerThread("DrmManagerClient.InfoHandler");
      this.mInfoThread.start();
      this.mInfoHandler = new InfoHandler(this.mInfoThread.getLooper());
      this.mEventThread = new HandlerThread("DrmManagerClient.EventHandler");
      this.mEventThread.start();
      this.mEventHandler = new EventHandler(this.mEventThread.getLooper());
    }
  }
  
  private void createListeners()
  {
    _setListeners(this.mUniqueId, new WeakReference(this));
  }
  
  private int getErrorType(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return -1;
    }
    return 2006;
  }
  
  private int getEventType(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return -1;
    }
    return 1002;
  }
  
  public static void notify(Object paramObject, int paramInt1, int paramInt2, String paramString)
  {
    DrmManagerClient localDrmManagerClient = (DrmManagerClient)((WeakReference)paramObject).get();
    if ((localDrmManagerClient != null) && (localDrmManagerClient.mInfoHandler != null))
    {
      Message localMessage = localDrmManagerClient.mInfoHandler.obtainMessage(1, paramInt1, paramInt2, paramString);
      localDrmManagerClient.mInfoHandler.sendMessage(localMessage);
    }
  }
  
  public DrmInfo acquireDrmInfo(DrmInfoRequest paramDrmInfoRequest)
  {
    if ((paramDrmInfoRequest == null) || (!paramDrmInfoRequest.isValid())) {
      throw new IllegalArgumentException("Given drmInfoRequest is invalid/null");
    }
    return _acquireDrmInfo(this.mUniqueId, paramDrmInfoRequest);
  }
  
  public int acquireRights(DrmInfoRequest paramDrmInfoRequest)
  {
    DrmInfo localDrmInfo = acquireDrmInfo(paramDrmInfoRequest);
    if (localDrmInfo == null) {
      return 63536;
    }
    return processDrmInfo(localDrmInfo);
  }
  
  public boolean canHandle(Uri paramUri, String paramString)
  {
    if (((paramUri == null) || (Uri.EMPTY == paramUri)) && ((paramString == null) || (paramString.equals("")))) {
      throw new IllegalArgumentException("Uri or the mimetype should be non null");
    }
    return canHandle(convertUriToPath(paramUri), paramString);
  }
  
  public boolean canHandle(String paramString1, String paramString2)
  {
    if (((paramString1 == null) || (paramString1.equals(""))) && ((paramString2 == null) || (paramString2.equals("")))) {
      throw new IllegalArgumentException("Path or the mimetype should be non null");
    }
    return _canHandle(this.mUniqueId, paramString1, paramString2);
  }
  
  public int checkRightsStatus(Uri paramUri)
  {
    if ((paramUri == null) || (Uri.EMPTY == paramUri)) {
      throw new IllegalArgumentException("Given uri is not valid");
    }
    return checkRightsStatus(convertUriToPath(paramUri));
  }
  
  public int checkRightsStatus(Uri paramUri, int paramInt)
  {
    if ((paramUri == null) || (Uri.EMPTY == paramUri)) {
      throw new IllegalArgumentException("Given uri is not valid");
    }
    return checkRightsStatus(convertUriToPath(paramUri), paramInt);
  }
  
  public int checkRightsStatus(String paramString)
  {
    return checkRightsStatus(paramString, 0);
  }
  
  public int checkRightsStatus(String paramString, int paramInt)
  {
    if ((paramString == null) || (paramString.equals("")) || (!DrmStore.Action.isValid(paramInt))) {
      throw new IllegalArgumentException("Given path or action is not valid");
    }
    return _checkRightsStatus(this.mUniqueId, paramString, paramInt);
  }
  
  public DrmConvertedStatus closeConvertSession(int paramInt)
  {
    return _closeConvertSession(this.mUniqueId, paramInt);
  }
  
  public DrmConvertedStatus convertData(int paramInt, byte[] paramArrayOfByte)
  {
    if ((paramArrayOfByte == null) || (paramArrayOfByte.length <= 0)) {
      throw new IllegalArgumentException("Given inputData should be non null");
    }
    return _convertData(this.mUniqueId, paramInt, paramArrayOfByte);
  }
  
  protected void finalize()
  {
    if (!this.mReleased)
    {
      Log.w("DrmManagerClient", "You should have called release()");
      release();
    }
  }
  
  public String[] getAvailableDrmEngines()
  {
    DrmSupportInfo[] arrayOfDrmSupportInfo = _getAllSupportInfo(this.mUniqueId);
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < arrayOfDrmSupportInfo.length; i++) {
      localArrayList.add(arrayOfDrmSupportInfo[i].getDescriprition());
    }
    return (String[])localArrayList.toArray(new String[localArrayList.size()]);
  }
  
  public ContentValues getConstraints(Uri paramUri, int paramInt)
  {
    if ((paramUri == null) || (Uri.EMPTY == paramUri)) {
      throw new IllegalArgumentException("Uri should be non null");
    }
    return getConstraints(convertUriToPath(paramUri), paramInt);
  }
  
  public ContentValues getConstraints(String paramString, int paramInt)
  {
    if ((paramString == null) || (paramString.equals("")) || (!DrmStore.Action.isValid(paramInt))) {
      throw new IllegalArgumentException("Given usage or path is invalid/null");
    }
    return _getConstraints(this.mUniqueId, paramString, paramInt);
  }
  
  public int getDrmObjectType(Uri paramUri, String paramString)
  {
    if (((paramUri == null) || (Uri.EMPTY == paramUri)) && ((paramString == null) || (paramString.equals("")))) {
      throw new IllegalArgumentException("Uri or the mimetype should be non null");
    }
    Object localObject = "";
    try
    {
      String str = convertUriToPath(paramUri);
      localObject = str;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        Log.w("DrmManagerClient", "Given Uri could not be found in media store");
      }
    }
    return getDrmObjectType((String)localObject, paramString);
  }
  
  public int getDrmObjectType(String paramString1, String paramString2)
  {
    if (((paramString1 == null) || (paramString1.equals(""))) && ((paramString2 == null) || (paramString2.equals("")))) {
      throw new IllegalArgumentException("Path or the mimetype should be non null");
    }
    return _getDrmObjectType(this.mUniqueId, paramString1, paramString2);
  }
  
  public ContentValues getMetadata(Uri paramUri)
  {
    if ((paramUri == null) || (Uri.EMPTY == paramUri)) {
      throw new IllegalArgumentException("Uri should be non null");
    }
    return getMetadata(convertUriToPath(paramUri));
  }
  
  public ContentValues getMetadata(String paramString)
  {
    if ((paramString == null) || (paramString.equals(""))) {
      throw new IllegalArgumentException("Given path is invalid/null");
    }
    return _getMetadata(this.mUniqueId, paramString);
  }
  
  public String getOriginalMimeType(Uri paramUri)
  {
    if ((paramUri == null) || (Uri.EMPTY == paramUri)) {
      throw new IllegalArgumentException("Given uri is not valid");
    }
    return getOriginalMimeType(convertUriToPath(paramUri));
  }
  
  /* Error */
  public String getOriginalMimeType(String paramString)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnull +12 -> 13
    //   4: aload_1
    //   5: ldc -116
    //   7: invokevirtual 146	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   10: ifeq +14 -> 24
    //   13: new 183	java/lang/IllegalArgumentException
    //   16: dup
    //   17: ldc_w 391
    //   20: invokespecial 187	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   23: athrow
    //   24: aconst_null
    //   25: astore_2
    //   26: new 393	java/io/File
    //   29: dup
    //   30: aload_1
    //   31: invokespecial 394	java/io/File:<init>	(Ljava/lang/String;)V
    //   34: astore_3
    //   35: aload_3
    //   36: invokevirtual 397	java/io/File:exists	()Z
    //   39: istore 9
    //   41: aconst_null
    //   42: astore 10
    //   44: aconst_null
    //   45: astore_2
    //   46: iload 9
    //   48: ifeq +27 -> 75
    //   51: new 399	java/io/FileInputStream
    //   54: dup
    //   55: aload_3
    //   56: invokespecial 402	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   59: astore 11
    //   61: aload 11
    //   63: invokevirtual 406	java/io/FileInputStream:getFD	()Ljava/io/FileDescriptor;
    //   66: astore 13
    //   68: aload 13
    //   70: astore 10
    //   72: aload 11
    //   74: astore_2
    //   75: aload_0
    //   76: aload_0
    //   77: getfield 63	android/drm/DrmManagerClient:mUniqueId	I
    //   80: aload_1
    //   81: aload 10
    //   83: invokespecial 408	android/drm/DrmManagerClient:_getOriginalMimeType	(ILjava/lang/String;Ljava/io/FileDescriptor;)Ljava/lang/String;
    //   86: astore 14
    //   88: aload 14
    //   90: astore 5
    //   92: aload_2
    //   93: ifnull +7 -> 100
    //   96: aload_2
    //   97: invokevirtual 409	java/io/FileInputStream:close	()V
    //   100: aload 5
    //   102: areturn
    //   103: astore 7
    //   105: aload_2
    //   106: ifnull +7 -> 113
    //   109: aload_2
    //   110: invokevirtual 409	java/io/FileInputStream:close	()V
    //   113: aload 7
    //   115: athrow
    //   116: astore 4
    //   118: aconst_null
    //   119: astore 5
    //   121: aload_2
    //   122: ifnull -22 -> 100
    //   125: aload_2
    //   126: invokevirtual 409	java/io/FileInputStream:close	()V
    //   129: aconst_null
    //   130: areturn
    //   131: astore 6
    //   133: aload 5
    //   135: areturn
    //   136: astore 8
    //   138: goto -25 -> 113
    //   141: astore 7
    //   143: aload 11
    //   145: astore_2
    //   146: goto -41 -> 105
    //   149: astore 12
    //   151: aload 11
    //   153: astore_2
    //   154: goto -36 -> 118
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	157	0	this	DrmManagerClient
    //   0	157	1	paramString	String
    //   25	129	2	localObject1	Object
    //   34	22	3	localFile	java.io.File
    //   116	1	4	localIOException1	IOException
    //   90	44	5	str1	String
    //   131	1	6	localIOException2	IOException
    //   103	11	7	localObject2	Object
    //   141	1	7	localObject3	Object
    //   136	1	8	localIOException3	IOException
    //   39	8	9	bool	boolean
    //   42	40	10	localObject4	Object
    //   59	93	11	localFileInputStream	java.io.FileInputStream
    //   149	1	12	localIOException4	IOException
    //   66	3	13	localFileDescriptor	FileDescriptor
    //   86	3	14	str2	String
    // Exception table:
    //   from	to	target	type
    //   26	41	103	finally
    //   51	61	103	finally
    //   75	88	103	finally
    //   26	41	116	java/io/IOException
    //   51	61	116	java/io/IOException
    //   75	88	116	java/io/IOException
    //   96	100	131	java/io/IOException
    //   125	129	131	java/io/IOException
    //   109	113	136	java/io/IOException
    //   61	68	141	finally
    //   61	68	149	java/io/IOException
  }
  
  public void installDrmEngine(String paramString)
  {
    if ((paramString == null) || (paramString.equals(""))) {
      throw new IllegalArgumentException("Given engineFilePath: " + paramString + "is not valid");
    }
    _installDrmEngine(this.mUniqueId, paramString);
  }
  
  public int openConvertSession(String paramString)
  {
    if ((paramString == null) || (paramString.equals(""))) {
      throw new IllegalArgumentException("Path or the mimeType should be non null");
    }
    return _openConvertSession(this.mUniqueId, paramString);
  }
  
  public int processDrmInfo(DrmInfo paramDrmInfo)
  {
    if ((paramDrmInfo == null) || (!paramDrmInfo.isValid())) {
      throw new IllegalArgumentException("Given drmInfo is invalid/null");
    }
    int i = 63536;
    if (this.mEventHandler != null)
    {
      Message localMessage = this.mEventHandler.obtainMessage(1002, paramDrmInfo);
      if (this.mEventHandler.sendMessage(localMessage)) {
        i = 0;
      }
    }
    return i;
  }
  
  public void release()
  {
    if (this.mReleased)
    {
      Log.w("DrmManagerClient", "You have already called release()");
      return;
    }
    this.mReleased = true;
    if (this.mEventHandler != null)
    {
      this.mEventThread.quit();
      this.mEventThread = null;
    }
    if (this.mInfoHandler != null)
    {
      this.mInfoThread.quit();
      this.mInfoThread = null;
    }
    this.mEventHandler = null;
    this.mInfoHandler = null;
    this.mOnEventListener = null;
    this.mOnInfoListener = null;
    this.mOnErrorListener = null;
    _release(this.mUniqueId);
  }
  
  public int removeAllRights()
  {
    int i = 63536;
    if (this.mEventHandler != null)
    {
      Message localMessage = this.mEventHandler.obtainMessage(1001);
      if (this.mEventHandler.sendMessage(localMessage)) {
        i = 0;
      }
    }
    return i;
  }
  
  public int removeRights(Uri paramUri)
  {
    if ((paramUri == null) || (Uri.EMPTY == paramUri)) {
      throw new IllegalArgumentException("Given uri is not valid");
    }
    return removeRights(convertUriToPath(paramUri));
  }
  
  public int removeRights(String paramString)
  {
    if ((paramString == null) || (paramString.equals(""))) {
      throw new IllegalArgumentException("Given path should be non null");
    }
    return _removeRights(this.mUniqueId, paramString);
  }
  
  public int saveRights(DrmRights paramDrmRights, String paramString1, String paramString2)
    throws IOException
  {
    if ((paramDrmRights == null) || (!paramDrmRights.isValid())) {
      throw new IllegalArgumentException("Given drmRights or contentPath is not valid");
    }
    if ((paramString1 != null) && (!paramString1.equals(""))) {
      DrmUtils.writeToFile(paramString1, paramDrmRights.getData());
    }
    return _saveRights(this.mUniqueId, paramDrmRights, paramString1, paramString2);
  }
  
  public void setOnErrorListener(OnErrorListener paramOnErrorListener)
  {
    try
    {
      this.mOnErrorListener = paramOnErrorListener;
      if (paramOnErrorListener != null) {
        createListeners();
      }
      return;
    }
    finally {}
  }
  
  public void setOnEventListener(OnEventListener paramOnEventListener)
  {
    try
    {
      this.mOnEventListener = paramOnEventListener;
      if (paramOnEventListener != null) {
        createListeners();
      }
      return;
    }
    finally {}
  }
  
  public void setOnInfoListener(OnInfoListener paramOnInfoListener)
  {
    try
    {
      this.mOnInfoListener = paramOnInfoListener;
      if (paramOnInfoListener != null) {
        createListeners();
      }
      return;
    }
    finally {}
  }
  
  private class EventHandler
    extends Handler
  {
    public EventHandler(Looper paramLooper)
    {
      super();
    }
    
    public void handleMessage(Message paramMessage)
    {
      DrmErrorEvent localDrmErrorEvent = null;
      HashMap localHashMap = new HashMap();
      DrmInfo localDrmInfo;
      DrmInfoStatus localDrmInfoStatus;
      DrmEvent localDrmEvent;
      switch (paramMessage.what)
      {
      default: 
        Log.e("DrmManagerClient", "Unknown message type " + paramMessage.what);
        return;
      case 1002: 
        localDrmInfo = (DrmInfo)paramMessage.obj;
        localDrmInfoStatus = DrmManagerClient.this._processDrmInfo(DrmManagerClient.this.mUniqueId, localDrmInfo);
        localHashMap.put("drm_info_status_object", localDrmInfoStatus);
        localHashMap.put("drm_info_object", localDrmInfo);
        if ((localDrmInfoStatus != null) && (1 == localDrmInfoStatus.statusCode)) {
          localDrmEvent = new DrmEvent(DrmManagerClient.this.mUniqueId, DrmManagerClient.this.getEventType(localDrmInfoStatus.infoType), null, localHashMap);
        }
        break;
      }
      for (;;)
      {
        if ((DrmManagerClient.this.mOnEventListener != null) && (localDrmEvent != null)) {
          DrmManagerClient.this.mOnEventListener.onEvent(DrmManagerClient.this, localDrmEvent);
        }
        if ((DrmManagerClient.this.mOnErrorListener == null) || (localDrmErrorEvent == null)) {
          break;
        }
        DrmManagerClient.this.mOnErrorListener.onError(DrmManagerClient.this, localDrmErrorEvent);
        return;
        if (localDrmInfoStatus != null) {}
        for (int i = localDrmInfoStatus.infoType;; i = localDrmInfo.getInfoType())
        {
          localDrmErrorEvent = new DrmErrorEvent(DrmManagerClient.this.mUniqueId, DrmManagerClient.this.getErrorType(i), null, localHashMap);
          localDrmEvent = null;
          break;
        }
        if (DrmManagerClient.this._removeAllRights(DrmManagerClient.this.mUniqueId) == 0)
        {
          localDrmEvent = new DrmEvent(DrmManagerClient.this.mUniqueId, 1001, null);
          localDrmErrorEvent = null;
        }
        else
        {
          localDrmErrorEvent = new DrmErrorEvent(DrmManagerClient.this.mUniqueId, 2007, null);
          localDrmEvent = null;
        }
      }
    }
  }
  
  private class InfoHandler
    extends Handler
  {
    public static final int INFO_EVENT_TYPE = 1;
    
    public InfoHandler(Looper paramLooper)
    {
      super();
    }
    
    public void handleMessage(Message paramMessage)
    {
      DrmInfoEvent localDrmInfoEvent = null;
      switch (paramMessage.what)
      {
      default: 
        Log.e("DrmManagerClient", "Unknown message type " + paramMessage.what);
        return;
      }
      int i = paramMessage.arg1;
      int j = paramMessage.arg2;
      String str = paramMessage.obj.toString();
      switch (j)
      {
      }
      for (DrmErrorEvent localDrmErrorEvent = new DrmErrorEvent(i, j, str);; localDrmErrorEvent = null)
      {
        for (;;)
        {
          if ((DrmManagerClient.this.mOnInfoListener != null) && (localDrmInfoEvent != null)) {
            DrmManagerClient.this.mOnInfoListener.onInfo(DrmManagerClient.this, localDrmInfoEvent);
          }
          if ((DrmManagerClient.this.mOnErrorListener == null) || (localDrmErrorEvent == null)) {
            break;
          }
          DrmManagerClient.this.mOnErrorListener.onError(DrmManagerClient.this, localDrmErrorEvent);
          return;
          try
          {
            DrmUtils.removeFile(str);
            localDrmInfoEvent = new DrmInfoEvent(i, j, str);
            localDrmErrorEvent = null;
          }
          catch (IOException localIOException)
          {
            for (;;)
            {
              localIOException.printStackTrace();
            }
          }
        }
        localDrmInfoEvent = new DrmInfoEvent(i, j, str);
      }
    }
  }
  
  public static abstract interface OnErrorListener
  {
    public abstract void onError(DrmManagerClient paramDrmManagerClient, DrmErrorEvent paramDrmErrorEvent);
  }
  
  public static abstract interface OnEventListener
  {
    public abstract void onEvent(DrmManagerClient paramDrmManagerClient, DrmEvent paramDrmEvent);
  }
  
  public static abstract interface OnInfoListener
  {
    public abstract void onInfo(DrmManagerClient paramDrmManagerClient, DrmInfoEvent paramDrmInfoEvent);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\drm\DrmManagerClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
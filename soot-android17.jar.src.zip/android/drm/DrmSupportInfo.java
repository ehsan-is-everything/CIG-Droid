package android.drm;

import java.util.ArrayList;
import java.util.Iterator;

public class DrmSupportInfo
{
  private String mDescription = "";
  private final ArrayList<String> mFileSuffixList = new ArrayList();
  private final ArrayList<String> mMimeTypeList = new ArrayList();
  
  public void addFileSuffix(String paramString)
  {
    if (paramString == "") {
      throw new IllegalArgumentException("fileSuffix is an empty string");
    }
    this.mFileSuffixList.add(paramString);
  }
  
  public void addMimeType(String paramString)
  {
    if (paramString == null) {
      throw new IllegalArgumentException("mimeType is null");
    }
    if (paramString == "") {
      throw new IllegalArgumentException("mimeType is an empty string");
    }
    this.mMimeTypeList.add(paramString);
  }
  
  public boolean equals(Object paramObject)
  {
    boolean bool1 = paramObject instanceof DrmSupportInfo;
    boolean bool2 = false;
    if (bool1)
    {
      DrmSupportInfo localDrmSupportInfo = (DrmSupportInfo)paramObject;
      boolean bool3 = this.mFileSuffixList.equals(localDrmSupportInfo.mFileSuffixList);
      bool2 = false;
      if (bool3)
      {
        boolean bool4 = this.mMimeTypeList.equals(localDrmSupportInfo.mMimeTypeList);
        bool2 = false;
        if (bool4)
        {
          boolean bool5 = this.mDescription.equals(localDrmSupportInfo.mDescription);
          bool2 = false;
          if (bool5) {
            bool2 = true;
          }
        }
      }
    }
    return bool2;
  }
  
  public String getDescriprition()
  {
    return this.mDescription;
  }
  
  public String getDescription()
  {
    return this.mDescription;
  }
  
  public Iterator<String> getFileSuffixIterator()
  {
    return this.mFileSuffixList.iterator();
  }
  
  public Iterator<String> getMimeTypeIterator()
  {
    return this.mMimeTypeList.iterator();
  }
  
  public int hashCode()
  {
    return this.mFileSuffixList.hashCode() + this.mMimeTypeList.hashCode() + this.mDescription.hashCode();
  }
  
  boolean isSupportedFileSuffix(String paramString)
  {
    return this.mFileSuffixList.contains(paramString);
  }
  
  boolean isSupportedMimeType(String paramString)
  {
    if ((paramString != null) && (!paramString.equals(""))) {
      for (int i = 0; i < this.mMimeTypeList.size(); i++) {
        if (((String)this.mMimeTypeList.get(i)).startsWith(paramString)) {
          return true;
        }
      }
    }
    return false;
  }
  
  public void setDescription(String paramString)
  {
    if (paramString == null) {
      throw new IllegalArgumentException("description is null");
    }
    if (paramString == "") {
      throw new IllegalArgumentException("description is an empty string");
    }
    this.mDescription = paramString;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\drm\DrmSupportInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
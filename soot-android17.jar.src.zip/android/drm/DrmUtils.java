package android.drm;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class DrmUtils
{
  public static ExtendedMetadataParser getExtendedMetadataParser(byte[] paramArrayOfByte)
  {
    return new ExtendedMetadataParser(paramArrayOfByte, null);
  }
  
  private static void quietlyDispose(InputStream paramInputStream)
  {
    if (paramInputStream != null) {}
    try
    {
      paramInputStream.close();
      return;
    }
    catch (IOException localIOException) {}
  }
  
  private static void quietlyDispose(OutputStream paramOutputStream)
  {
    if (paramOutputStream != null) {}
    try
    {
      paramOutputStream.close();
      return;
    }
    catch (IOException localIOException) {}
  }
  
  static byte[] readBytes(File paramFile)
    throws IOException
  {
    FileInputStream localFileInputStream = new FileInputStream(paramFile);
    BufferedInputStream localBufferedInputStream = new BufferedInputStream(localFileInputStream);
    try
    {
      int i = localBufferedInputStream.available();
      byte[] arrayOfByte = null;
      if (i > 0)
      {
        arrayOfByte = new byte[i];
        localBufferedInputStream.read(arrayOfByte);
      }
      return arrayOfByte;
    }
    finally
    {
      quietlyDispose(localBufferedInputStream);
      quietlyDispose(localFileInputStream);
    }
  }
  
  static byte[] readBytes(String paramString)
    throws IOException
  {
    return readBytes(new File(paramString));
  }
  
  static void removeFile(String paramString)
    throws IOException
  {
    new File(paramString).delete();
  }
  
  static void writeToFile(String paramString, byte[] paramArrayOfByte)
    throws IOException
  {
    localObject1 = null;
    if ((paramString != null) && (paramArrayOfByte != null)) {}
    try
    {
      localFileOutputStream = new FileOutputStream(paramString);
      quietlyDispose((OutputStream)localObject1);
    }
    finally
    {
      try
      {
        localFileOutputStream.write(paramArrayOfByte);
        quietlyDispose(localFileOutputStream);
        return;
      }
      finally
      {
        FileOutputStream localFileOutputStream;
        localObject1 = localFileOutputStream;
      }
      localObject2 = finally;
    }
    throw ((Throwable)localObject2);
  }
  
  public static class ExtendedMetadataParser
  {
    HashMap<String, String> mMap = new HashMap();
    
    private ExtendedMetadataParser(byte[] paramArrayOfByte)
    {
      int i = 0;
      while (i < paramArrayOfByte.length)
      {
        int j = readByte(paramArrayOfByte, i);
        int k = i + 1;
        int m = readByte(paramArrayOfByte, k);
        int n = k + 1;
        String str1 = readMultipleBytes(paramArrayOfByte, j, n);
        int i1 = n + j;
        String str2 = readMultipleBytes(paramArrayOfByte, m, i1);
        if (str2.equals(" ")) {
          str2 = "";
        }
        i = i1 + m;
        this.mMap.put(str1, str2);
      }
    }
    
    private int readByte(byte[] paramArrayOfByte, int paramInt)
    {
      return paramArrayOfByte[paramInt];
    }
    
    private String readMultipleBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    {
      byte[] arrayOfByte = new byte[paramInt1];
      int i = paramInt2;
      for (int j = 0; i < paramInt2 + paramInt1; j++)
      {
        arrayOfByte[j] = paramArrayOfByte[i];
        i++;
      }
      return new String(arrayOfByte);
    }
    
    public String get(String paramString)
    {
      return (String)this.mMap.get(paramString);
    }
    
    public Iterator<String> iterator()
    {
      return this.mMap.values().iterator();
    }
    
    public Iterator<String> keyIterator()
    {
      return this.mMap.keySet().iterator();
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\drm\DrmUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
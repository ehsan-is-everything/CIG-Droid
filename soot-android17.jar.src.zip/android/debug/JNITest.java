package android.debug;

import java.io.PrintStream;

public class JNITest
{
  private native int part1(int paramInt, double paramDouble, String paramString, int[] paramArrayOfInt);
  
  private int part2(double paramDouble, int paramInt, String paramString)
  {
    System.out.println(paramString + " : " + (float)paramDouble + " : " + paramInt);
    return 6 + part3(paramString);
  }
  
  private static native int part3(String paramString);
  
  public int test(int paramInt, double paramDouble, String paramString)
  {
    return part1(paramInt, paramDouble, paramString, new int[] { 42, 53, 65, 127 });
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\debug\JNITest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.app;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.os.FileUtils;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.android.internal.util.XmlUtils;
import com.google.android.collect.Maps;
import dalvik.system.BlockGuard;
import dalvik.system.BlockGuard.Policy;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import libcore.io.ErrnoException;
import libcore.io.Libcore;
import libcore.io.Os;
import libcore.io.StructStat;
import org.xmlpull.v1.XmlPullParserException;

final class SharedPreferencesImpl
  implements SharedPreferences
{
  private static final boolean DEBUG = false;
  private static final String TAG = "SharedPreferencesImpl";
  private static final Object mContent = new Object();
  private final File mBackupFile;
  private int mDiskWritesInFlight = 0;
  private final File mFile;
  private final WeakHashMap<SharedPreferences.OnSharedPreferenceChangeListener, Object> mListeners = new WeakHashMap();
  private boolean mLoaded = false;
  private Map<String, Object> mMap;
  private final int mMode;
  private long mStatSize;
  private long mStatTimestamp;
  private final Object mWritingToDiskLock = new Object();
  
  SharedPreferencesImpl(File paramFile, int paramInt)
  {
    this.mFile = paramFile;
    this.mBackupFile = makeBackupFile(paramFile);
    this.mMode = paramInt;
    this.mLoaded = false;
    this.mMap = null;
    startLoadFromDisk();
  }
  
  private void awaitLoadedLocked()
  {
    if (!this.mLoaded) {
      BlockGuard.getThreadPolicy().onReadFromDisk();
    }
    while (!this.mLoaded) {
      try
      {
        wait();
      }
      catch (InterruptedException localInterruptedException) {}
    }
  }
  
  private static FileOutputStream createFileOutputStream(File paramFile)
  {
    try
    {
      FileOutputStream localFileOutputStream1 = new FileOutputStream(paramFile);
      localObject = localFileOutputStream1;
    }
    catch (FileNotFoundException localFileNotFoundException1)
    {
      for (;;)
      {
        Object localObject;
        File localFile = paramFile.getParentFile();
        if (!localFile.mkdir())
        {
          Log.e("SharedPreferencesImpl", "Couldn't create directory for SharedPreferences file " + paramFile);
          return null;
        }
        FileUtils.setPermissions(localFile.getPath(), 505, -1, -1);
        try
        {
          FileOutputStream localFileOutputStream2 = new FileOutputStream(paramFile);
          localObject = localFileOutputStream2;
        }
        catch (FileNotFoundException localFileNotFoundException2)
        {
          Log.e("SharedPreferencesImpl", "Couldn't create SharedPreferences file " + paramFile, localFileNotFoundException2);
          localObject = null;
        }
      }
    }
    return (FileOutputStream)localObject;
  }
  
  private void enqueueDiskWrite(final MemoryCommitResult paramMemoryCommitResult, final Runnable paramRunnable)
  {
    Runnable local2 = new Runnable()
    {
      public void run()
      {
        synchronized (SharedPreferencesImpl.this.mWritingToDiskLock)
        {
          SharedPreferencesImpl.this.writeToFile(paramMemoryCommitResult);
        }
        synchronized (SharedPreferencesImpl.this)
        {
          SharedPreferencesImpl.access$310(SharedPreferencesImpl.this);
          if (paramRunnable != null) {
            paramRunnable.run();
          }
          return;
          localObject2 = finally;
          throw ((Throwable)localObject2);
        }
      }
    };
    int i;
    if (paramRunnable == null) {
      i = 1;
    }
    while (i != 0) {
      try
      {
        if (this.mDiskWritesInFlight == 1) {}
        for (int j = 1;; j = 0)
        {
          if (j == 0) {
            break label69;
          }
          local2.run();
          return;
          i = 0;
          break;
        }
        QueuedWork.singleThreadExecutor().execute(local2);
      }
      finally {}
    }
    label69:
  }
  
  /* Error */
  private boolean hasFileChangedUnexpectedly()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 42	android/app/SharedPreferencesImpl:mDiskWritesInFlight	I
    //   6: ifle +7 -> 13
    //   9: aload_0
    //   10: monitorexit
    //   11: iconst_0
    //   12: ireturn
    //   13: aload_0
    //   14: monitorexit
    //   15: invokestatic 104	dalvik/system/BlockGuard:getThreadPolicy	()Ldalvik/system/BlockGuard$Policy;
    //   18: invokeinterface 109 1 0
    //   23: getstatic 197	libcore/io/Libcore:os	Llibcore/io/Os;
    //   26: aload_0
    //   27: getfield 53	android/app/SharedPreferencesImpl:mFile	Ljava/io/File;
    //   30: invokevirtual 156	java/io/File:getPath	()Ljava/lang/String;
    //   33: invokeinterface 203 2 0
    //   38: astore_3
    //   39: aload_0
    //   40: monitorenter
    //   41: aload_0
    //   42: getfield 205	android/app/SharedPreferencesImpl:mStatTimestamp	J
    //   45: aload_3
    //   46: getfield 210	libcore/io/StructStat:st_mtime	J
    //   49: lcmp
    //   50: ifne +45 -> 95
    //   53: aload_0
    //   54: getfield 212	android/app/SharedPreferencesImpl:mStatSize	J
    //   57: aload_3
    //   58: getfield 215	libcore/io/StructStat:st_size	J
    //   61: lcmp
    //   62: istore 6
    //   64: iconst_0
    //   65: istore 5
    //   67: iload 6
    //   69: ifeq +6 -> 75
    //   72: goto +23 -> 95
    //   75: aload_0
    //   76: monitorexit
    //   77: iload 5
    //   79: ireturn
    //   80: astore 4
    //   82: aload_0
    //   83: monitorexit
    //   84: aload 4
    //   86: athrow
    //   87: astore_1
    //   88: aload_0
    //   89: monitorexit
    //   90: aload_1
    //   91: athrow
    //   92: astore_2
    //   93: iconst_1
    //   94: ireturn
    //   95: iconst_1
    //   96: istore 5
    //   98: goto -23 -> 75
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	101	0	this	SharedPreferencesImpl
    //   87	4	1	localObject1	Object
    //   92	1	2	localErrnoException	ErrnoException
    //   38	20	3	localStructStat	StructStat
    //   80	5	4	localObject2	Object
    //   65	32	5	bool1	boolean
    //   62	6	6	bool2	boolean
    // Exception table:
    //   from	to	target	type
    //   41	64	80	finally
    //   75	77	80	finally
    //   82	84	80	finally
    //   2	11	87	finally
    //   13	15	87	finally
    //   88	90	87	finally
    //   15	39	92	libcore/io/ErrnoException
  }
  
  /* Error */
  private void loadFromDiskLocked()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 44	android/app/SharedPreferencesImpl:mLoaded	Z
    //   4: ifeq +4 -> 8
    //   7: return
    //   8: aload_0
    //   9: getfield 59	android/app/SharedPreferencesImpl:mBackupFile	Ljava/io/File;
    //   12: invokevirtual 222	java/io/File:exists	()Z
    //   15: ifeq +23 -> 38
    //   18: aload_0
    //   19: getfield 53	android/app/SharedPreferencesImpl:mFile	Ljava/io/File;
    //   22: invokevirtual 225	java/io/File:delete	()Z
    //   25: pop
    //   26: aload_0
    //   27: getfield 59	android/app/SharedPreferencesImpl:mBackupFile	Ljava/io/File;
    //   30: aload_0
    //   31: getfield 53	android/app/SharedPreferencesImpl:mFile	Ljava/io/File;
    //   34: invokevirtual 229	java/io/File:renameTo	(Ljava/io/File;)Z
    //   37: pop
    //   38: aload_0
    //   39: getfield 53	android/app/SharedPreferencesImpl:mFile	Ljava/io/File;
    //   42: invokevirtual 222	java/io/File:exists	()Z
    //   45: ifeq +46 -> 91
    //   48: aload_0
    //   49: getfield 53	android/app/SharedPreferencesImpl:mFile	Ljava/io/File;
    //   52: invokevirtual 232	java/io/File:canRead	()Z
    //   55: ifne +36 -> 91
    //   58: ldc 13
    //   60: new 133	java/lang/StringBuilder
    //   63: dup
    //   64: invokespecial 134	java/lang/StringBuilder:<init>	()V
    //   67: ldc -22
    //   69: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   72: aload_0
    //   73: getfield 53	android/app/SharedPreferencesImpl:mFile	Ljava/io/File;
    //   76: invokevirtual 143	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   79: ldc -20
    //   81: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   84: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   87: invokestatic 239	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   90: pop
    //   91: aconst_null
    //   92: astore_1
    //   93: aconst_null
    //   94: astore_2
    //   95: getstatic 197	libcore/io/Libcore:os	Llibcore/io/Os;
    //   98: aload_0
    //   99: getfield 53	android/app/SharedPreferencesImpl:mFile	Ljava/io/File;
    //   102: invokevirtual 156	java/io/File:getPath	()Ljava/lang/String;
    //   105: invokeinterface 203 2 0
    //   110: astore_2
    //   111: aload_0
    //   112: getfield 53	android/app/SharedPreferencesImpl:mFile	Ljava/io/File;
    //   115: invokevirtual 232	java/io/File:canRead	()Z
    //   118: istore 4
    //   120: aconst_null
    //   121: astore_1
    //   122: iload 4
    //   124: ifeq +44 -> 168
    //   127: aconst_null
    //   128: astore 5
    //   130: new 241	java/io/BufferedInputStream
    //   133: dup
    //   134: new 243	java/io/FileInputStream
    //   137: dup
    //   138: aload_0
    //   139: getfield 53	android/app/SharedPreferencesImpl:mFile	Ljava/io/File;
    //   142: invokespecial 244	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   145: sipush 16384
    //   148: invokespecial 247	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;I)V
    //   151: astore 6
    //   153: aload 6
    //   155: invokestatic 253	com/android/internal/util/XmlUtils:readMapXml	(Ljava/io/InputStream;)Ljava/util/HashMap;
    //   158: astore 14
    //   160: aload 14
    //   162: astore_1
    //   163: aload 6
    //   165: invokestatic 259	libcore/io/IoUtils:closeQuietly	(Ljava/lang/AutoCloseable;)V
    //   168: aload_0
    //   169: iconst_1
    //   170: putfield 44	android/app/SharedPreferencesImpl:mLoaded	Z
    //   173: aload_1
    //   174: ifnull +110 -> 284
    //   177: aload_0
    //   178: aload_1
    //   179: putfield 63	android/app/SharedPreferencesImpl:mMap	Ljava/util/Map;
    //   182: aload_0
    //   183: aload_2
    //   184: getfield 210	libcore/io/StructStat:st_mtime	J
    //   187: putfield 205	android/app/SharedPreferencesImpl:mStatTimestamp	J
    //   190: aload_0
    //   191: aload_2
    //   192: getfield 215	libcore/io/StructStat:st_size	J
    //   195: putfield 212	android/app/SharedPreferencesImpl:mStatSize	J
    //   198: aload_0
    //   199: invokevirtual 262	java/lang/Object:notifyAll	()V
    //   202: return
    //   203: astore 7
    //   205: ldc 13
    //   207: ldc_w 264
    //   210: aload 7
    //   212: invokestatic 266	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   215: pop
    //   216: aload 5
    //   218: invokestatic 259	libcore/io/IoUtils:closeQuietly	(Ljava/lang/AutoCloseable;)V
    //   221: aconst_null
    //   222: astore_1
    //   223: goto -55 -> 168
    //   226: astore_3
    //   227: goto -59 -> 168
    //   230: astore 10
    //   232: ldc 13
    //   234: ldc_w 264
    //   237: aload 10
    //   239: invokestatic 266	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   242: pop
    //   243: aload 5
    //   245: invokestatic 259	libcore/io/IoUtils:closeQuietly	(Ljava/lang/AutoCloseable;)V
    //   248: aconst_null
    //   249: astore_1
    //   250: goto -82 -> 168
    //   253: astore 12
    //   255: ldc 13
    //   257: ldc_w 264
    //   260: aload 12
    //   262: invokestatic 266	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   265: pop
    //   266: aload 5
    //   268: invokestatic 259	libcore/io/IoUtils:closeQuietly	(Ljava/lang/AutoCloseable;)V
    //   271: aconst_null
    //   272: astore_1
    //   273: goto -105 -> 168
    //   276: aload 5
    //   278: invokestatic 259	libcore/io/IoUtils:closeQuietly	(Ljava/lang/AutoCloseable;)V
    //   281: aload 8
    //   283: athrow
    //   284: aload_0
    //   285: new 268	java/util/HashMap
    //   288: dup
    //   289: invokespecial 269	java/util/HashMap:<init>	()V
    //   292: putfield 63	android/app/SharedPreferencesImpl:mMap	Ljava/util/Map;
    //   295: goto -97 -> 198
    //   298: astore 8
    //   300: aload 6
    //   302: astore 5
    //   304: goto -28 -> 276
    //   307: astore 12
    //   309: aload 6
    //   311: astore 5
    //   313: goto -58 -> 255
    //   316: astore 10
    //   318: aload 6
    //   320: astore 5
    //   322: goto -90 -> 232
    //   325: astore 7
    //   327: aload 6
    //   329: astore 5
    //   331: goto -126 -> 205
    //   334: astore 8
    //   336: goto -60 -> 276
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	339	0	this	SharedPreferencesImpl
    //   92	181	1	localObject1	Object
    //   94	98	2	localStructStat	StructStat
    //   226	1	3	localErrnoException	ErrnoException
    //   118	5	4	bool	boolean
    //   128	202	5	localObject2	Object
    //   151	177	6	localBufferedInputStream	java.io.BufferedInputStream
    //   203	8	7	localXmlPullParserException1	XmlPullParserException
    //   325	1	7	localXmlPullParserException2	XmlPullParserException
    //   281	1	8	localObject3	Object
    //   298	1	8	localObject4	Object
    //   334	1	8	localObject5	Object
    //   230	8	10	localFileNotFoundException1	FileNotFoundException
    //   316	1	10	localFileNotFoundException2	FileNotFoundException
    //   253	8	12	localIOException1	IOException
    //   307	1	12	localIOException2	IOException
    //   158	3	14	localHashMap	HashMap
    // Exception table:
    //   from	to	target	type
    //   130	153	203	org/xmlpull/v1/XmlPullParserException
    //   95	120	226	libcore/io/ErrnoException
    //   163	168	226	libcore/io/ErrnoException
    //   216	221	226	libcore/io/ErrnoException
    //   243	248	226	libcore/io/ErrnoException
    //   266	271	226	libcore/io/ErrnoException
    //   276	284	226	libcore/io/ErrnoException
    //   130	153	230	java/io/FileNotFoundException
    //   130	153	253	java/io/IOException
    //   153	160	298	finally
    //   153	160	307	java/io/IOException
    //   153	160	316	java/io/FileNotFoundException
    //   153	160	325	org/xmlpull/v1/XmlPullParserException
    //   130	153	334	finally
    //   205	216	334	finally
    //   232	243	334	finally
    //   255	266	334	finally
  }
  
  private static File makeBackupFile(File paramFile)
  {
    return new File(paramFile.getPath() + ".bak");
  }
  
  private void startLoadFromDisk()
  {
    try
    {
      this.mLoaded = false;
      new Thread("SharedPreferencesImpl-load")
      {
        public void run()
        {
          synchronized (SharedPreferencesImpl.this)
          {
            SharedPreferencesImpl.this.loadFromDiskLocked();
            return;
          }
        }
      }.start();
      return;
    }
    finally {}
  }
  
  private void writeToFile(MemoryCommitResult paramMemoryCommitResult)
  {
    if (this.mFile.exists())
    {
      if (!paramMemoryCommitResult.changesMade)
      {
        paramMemoryCommitResult.setDiskWriteResult(true);
        return;
      }
      if (!this.mBackupFile.exists())
      {
        if (!this.mFile.renameTo(this.mBackupFile))
        {
          Log.e("SharedPreferencesImpl", "Couldn't rename file " + this.mFile + " to backup file " + this.mBackupFile);
          paramMemoryCommitResult.setDiskWriteResult(false);
        }
      }
      else {
        this.mFile.delete();
      }
    }
    try
    {
      localFileOutputStream = createFileOutputStream(this.mFile);
      if (localFileOutputStream == null)
      {
        paramMemoryCommitResult.setDiskWriteResult(false);
        return;
      }
    }
    catch (XmlPullParserException localXmlPullParserException)
    {
      FileOutputStream localFileOutputStream;
      Log.w("SharedPreferencesImpl", "writeToFile: Got exception:", localXmlPullParserException);
      if ((this.mFile.exists()) && (!this.mFile.delete())) {
        Log.e("SharedPreferencesImpl", "Couldn't clean up partially-written file " + this.mFile);
      }
      paramMemoryCommitResult.setDiskWriteResult(false);
      return;
      XmlUtils.writeMapXml(paramMemoryCommitResult.mapToWriteToDisk, localFileOutputStream);
      FileUtils.sync(localFileOutputStream);
      localFileOutputStream.close();
      ContextImpl.setFilePermissionsFromMode(this.mFile.getPath(), this.mMode, 0);
    }
    catch (IOException localIOException)
    {
      for (;;)
      {
        try
        {
          localStructStat = Libcore.os.stat(this.mFile.getPath());
        }
        catch (ErrnoException localErrnoException)
        {
          StructStat localStructStat;
          continue;
        }
        try
        {
          this.mStatTimestamp = localStructStat.st_mtime;
          this.mStatSize = localStructStat.st_size;
          this.mBackupFile.delete();
          paramMemoryCommitResult.setDiskWriteResult(true);
          return;
        }
        finally {}
        localIOException = localIOException;
        Log.w("SharedPreferencesImpl", "writeToFile: Got exception:", localIOException);
      }
    }
  }
  
  public boolean contains(String paramString)
  {
    try
    {
      awaitLoadedLocked();
      boolean bool = this.mMap.containsKey(paramString);
      return bool;
    }
    finally {}
  }
  
  public SharedPreferences.Editor edit()
  {
    try
    {
      awaitLoadedLocked();
      return new EditorImpl();
    }
    finally {}
  }
  
  public Map<String, ?> getAll()
  {
    try
    {
      awaitLoadedLocked();
      HashMap localHashMap = new HashMap(this.mMap);
      return localHashMap;
    }
    finally {}
  }
  
  public boolean getBoolean(String paramString, boolean paramBoolean)
  {
    try
    {
      awaitLoadedLocked();
      Boolean localBoolean = (Boolean)this.mMap.get(paramString);
      if (localBoolean != null) {
        paramBoolean = localBoolean.booleanValue();
      }
      return paramBoolean;
    }
    finally {}
  }
  
  public float getFloat(String paramString, float paramFloat)
  {
    try
    {
      awaitLoadedLocked();
      Float localFloat = (Float)this.mMap.get(paramString);
      if (localFloat != null) {
        paramFloat = localFloat.floatValue();
      }
      return paramFloat;
    }
    finally {}
  }
  
  public int getInt(String paramString, int paramInt)
  {
    try
    {
      awaitLoadedLocked();
      Integer localInteger = (Integer)this.mMap.get(paramString);
      if (localInteger != null) {
        paramInt = localInteger.intValue();
      }
      return paramInt;
    }
    finally {}
  }
  
  public long getLong(String paramString, long paramLong)
  {
    try
    {
      awaitLoadedLocked();
      Long localLong = (Long)this.mMap.get(paramString);
      if (localLong != null) {
        paramLong = localLong.longValue();
      }
      return paramLong;
    }
    finally {}
  }
  
  public String getString(String paramString1, String paramString2)
  {
    for (;;)
    {
      try
      {
        awaitLoadedLocked();
        str = (String)this.mMap.get(paramString1);
        if (str != null) {
          return str;
        }
      }
      finally {}
      String str = paramString2;
    }
  }
  
  public Set<String> getStringSet(String paramString, Set<String> paramSet)
  {
    for (;;)
    {
      try
      {
        awaitLoadedLocked();
        localObject2 = (Set)this.mMap.get(paramString);
        if (localObject2 != null) {
          return (Set<String>)localObject2;
        }
      }
      finally {}
      Object localObject2 = paramSet;
    }
  }
  
  public void registerOnSharedPreferenceChangeListener(SharedPreferences.OnSharedPreferenceChangeListener paramOnSharedPreferenceChangeListener)
  {
    try
    {
      this.mListeners.put(paramOnSharedPreferenceChangeListener, mContent);
      return;
    }
    finally {}
  }
  
  void startReloadIfChangedUnexpectedly()
  {
    try
    {
      if (!hasFileChangedUnexpectedly()) {
        return;
      }
      startLoadFromDisk();
      return;
    }
    finally {}
  }
  
  public void unregisterOnSharedPreferenceChangeListener(SharedPreferences.OnSharedPreferenceChangeListener paramOnSharedPreferenceChangeListener)
  {
    try
    {
      this.mListeners.remove(paramOnSharedPreferenceChangeListener);
      return;
    }
    finally {}
  }
  
  public final class EditorImpl
    implements SharedPreferences.Editor
  {
    private boolean mClear = false;
    private final Map<String, Object> mModified = Maps.newHashMap();
    
    public EditorImpl() {}
    
    private SharedPreferencesImpl.MemoryCommitResult commitToMemory()
    {
      int i = 1;
      SharedPreferencesImpl.MemoryCommitResult localMemoryCommitResult = new SharedPreferencesImpl.MemoryCommitResult(null);
      for (;;)
      {
        String str;
        Object localObject3;
        synchronized (SharedPreferencesImpl.this)
        {
          if (SharedPreferencesImpl.this.mDiskWritesInFlight > 0) {
            SharedPreferencesImpl.access$402(SharedPreferencesImpl.this, new HashMap(SharedPreferencesImpl.this.mMap));
          }
          localMemoryCommitResult.mapToWriteToDisk = SharedPreferencesImpl.this.mMap;
          SharedPreferencesImpl.access$308(SharedPreferencesImpl.this);
          if (SharedPreferencesImpl.this.mListeners.size() > 0)
          {
            if (i != 0)
            {
              localMemoryCommitResult.keysModified = new ArrayList();
              localMemoryCommitResult.listeners = new HashSet(SharedPreferencesImpl.this.mListeners.keySet());
            }
            try
            {
              if (this.mClear)
              {
                if (!SharedPreferencesImpl.this.mMap.isEmpty())
                {
                  localMemoryCommitResult.changesMade = true;
                  SharedPreferencesImpl.this.mMap.clear();
                }
                this.mClear = false;
              }
              Iterator localIterator = this.mModified.entrySet().iterator();
              if (!localIterator.hasNext()) {
                break;
              }
              Map.Entry localEntry = (Map.Entry)localIterator.next();
              str = (String)localEntry.getKey();
              localObject3 = localEntry.getValue();
              if (localObject3 != this) {
                break label304;
              }
              if (!SharedPreferencesImpl.this.mMap.containsKey(str)) {
                continue;
              }
              SharedPreferencesImpl.this.mMap.remove(str);
              localMemoryCommitResult.changesMade = true;
              if (i == 0) {
                continue;
              }
              localMemoryCommitResult.keysModified.add(str);
              continue;
              localObject1 = finally;
            }
            finally {}
          }
        }
        i = 0;
        continue;
        label304:
        if (SharedPreferencesImpl.this.mMap.containsKey(str))
        {
          Object localObject4 = SharedPreferencesImpl.this.mMap.get(str);
          if ((localObject4 != null) && (localObject4.equals(localObject3))) {}
        }
        else
        {
          SharedPreferencesImpl.this.mMap.put(str, localObject3);
        }
      }
      this.mModified.clear();
      return localMemoryCommitResult;
    }
    
    private void notifyListeners(final SharedPreferencesImpl.MemoryCommitResult paramMemoryCommitResult)
    {
      if ((paramMemoryCommitResult.listeners == null) || (paramMemoryCommitResult.keysModified == null) || (paramMemoryCommitResult.keysModified.size() == 0)) {}
      for (;;)
      {
        return;
        if (Looper.myLooper() != Looper.getMainLooper()) {
          break;
        }
        for (int i = -1 + paramMemoryCommitResult.keysModified.size(); i >= 0; i--)
        {
          String str = (String)paramMemoryCommitResult.keysModified.get(i);
          Iterator localIterator = paramMemoryCommitResult.listeners.iterator();
          while (localIterator.hasNext())
          {
            SharedPreferences.OnSharedPreferenceChangeListener localOnSharedPreferenceChangeListener = (SharedPreferences.OnSharedPreferenceChangeListener)localIterator.next();
            if (localOnSharedPreferenceChangeListener != null) {
              localOnSharedPreferenceChangeListener.onSharedPreferenceChanged(SharedPreferencesImpl.this, str);
            }
          }
        }
      }
      ActivityThread.sMainThreadHandler.post(new Runnable()
      {
        public void run()
        {
          SharedPreferencesImpl.EditorImpl.this.notifyListeners(paramMemoryCommitResult);
        }
      });
    }
    
    public void apply()
    {
      final SharedPreferencesImpl.MemoryCommitResult localMemoryCommitResult = commitToMemory();
      final Runnable local1 = new Runnable()
      {
        public void run()
        {
          try
          {
            localMemoryCommitResult.writtenToDiskLatch.await();
            return;
          }
          catch (InterruptedException localInterruptedException) {}
        }
      };
      QueuedWork.add(local1);
      Runnable local2 = new Runnable()
      {
        public void run()
        {
          local1.run();
          QueuedWork.remove(local1);
        }
      };
      SharedPreferencesImpl.this.enqueueDiskWrite(localMemoryCommitResult, local2);
      notifyListeners(localMemoryCommitResult);
    }
    
    public SharedPreferences.Editor clear()
    {
      try
      {
        this.mClear = true;
        return this;
      }
      finally {}
    }
    
    public boolean commit()
    {
      SharedPreferencesImpl.MemoryCommitResult localMemoryCommitResult = commitToMemory();
      SharedPreferencesImpl.this.enqueueDiskWrite(localMemoryCommitResult, null);
      try
      {
        localMemoryCommitResult.writtenToDiskLatch.await();
        notifyListeners(localMemoryCommitResult);
        return localMemoryCommitResult.writeToDiskResult;
      }
      catch (InterruptedException localInterruptedException) {}
      return false;
    }
    
    public SharedPreferences.Editor putBoolean(String paramString, boolean paramBoolean)
    {
      try
      {
        this.mModified.put(paramString, Boolean.valueOf(paramBoolean));
        return this;
      }
      finally {}
    }
    
    public SharedPreferences.Editor putFloat(String paramString, float paramFloat)
    {
      try
      {
        this.mModified.put(paramString, Float.valueOf(paramFloat));
        return this;
      }
      finally {}
    }
    
    public SharedPreferences.Editor putInt(String paramString, int paramInt)
    {
      try
      {
        this.mModified.put(paramString, Integer.valueOf(paramInt));
        return this;
      }
      finally {}
    }
    
    public SharedPreferences.Editor putLong(String paramString, long paramLong)
    {
      try
      {
        this.mModified.put(paramString, Long.valueOf(paramLong));
        return this;
      }
      finally {}
    }
    
    public SharedPreferences.Editor putString(String paramString1, String paramString2)
    {
      try
      {
        this.mModified.put(paramString1, paramString2);
        return this;
      }
      finally {}
    }
    
    /* Error */
    public SharedPreferences.Editor putStringSet(String paramString, Set<String> paramSet)
    {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield 28	android/app/SharedPreferencesImpl$EditorImpl:mModified	Ljava/util/Map;
      //   6: astore 4
      //   8: aload_2
      //   9: ifnonnull +21 -> 30
      //   12: aconst_null
      //   13: astore 5
      //   15: aload 4
      //   17: aload_1
      //   18: aload 5
      //   20: invokeinterface 161 3 0
      //   25: pop
      //   26: aload_0
      //   27: monitorexit
      //   28: aload_0
      //   29: areturn
      //   30: new 87	java/util/HashSet
      //   33: dup
      //   34: aload_2
      //   35: invokespecial 94	java/util/HashSet:<init>	(Ljava/util/Collection;)V
      //   38: astore 5
      //   40: goto -25 -> 15
      //   43: astore_3
      //   44: aload_0
      //   45: monitorexit
      //   46: aload_3
      //   47: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	48	0	this	EditorImpl
      //   0	48	1	paramString	String
      //   0	48	2	paramSet	Set<String>
      //   43	4	3	localObject1	Object
      //   6	10	4	localMap	Map
      //   13	26	5	localObject2	Object
      // Exception table:
      //   from	to	target	type
      //   2	8	43	finally
      //   15	28	43	finally
      //   30	40	43	finally
      //   44	46	43	finally
    }
    
    public SharedPreferences.Editor remove(String paramString)
    {
      try
      {
        this.mModified.put(paramString, this);
        return this;
      }
      finally {}
    }
  }
  
  private static class MemoryCommitResult
  {
    public boolean changesMade;
    public List<String> keysModified;
    public Set<SharedPreferences.OnSharedPreferenceChangeListener> listeners;
    public Map<?, ?> mapToWriteToDisk;
    public volatile boolean writeToDiskResult = false;
    public final CountDownLatch writtenToDiskLatch = new CountDownLatch(1);
    
    public void setDiskWriteResult(boolean paramBoolean)
    {
      this.writeToDiskResult = paramBoolean;
      this.writtenToDiskLatch.countDown();
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\SharedPreferencesImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
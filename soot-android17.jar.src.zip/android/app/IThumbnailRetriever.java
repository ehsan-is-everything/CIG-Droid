package android.app;

import android.graphics.Bitmap;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface IThumbnailRetriever
  extends IInterface
{
  public abstract Bitmap getThumbnail(int paramInt)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IThumbnailRetriever
  {
    private static final String DESCRIPTOR = "android.app.IThumbnailRetriever";
    static final int TRANSACTION_getThumbnail = 1;
    
    public Stub()
    {
      attachInterface(this, "android.app.IThumbnailRetriever");
    }
    
    public static IThumbnailRetriever asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.app.IThumbnailRetriever");
      if ((localIInterface != null) && ((localIInterface instanceof IThumbnailRetriever))) {
        return (IThumbnailRetriever)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.app.IThumbnailRetriever");
        return true;
      }
      paramParcel1.enforceInterface("android.app.IThumbnailRetriever");
      Bitmap localBitmap = getThumbnail(paramParcel1.readInt());
      paramParcel2.writeNoException();
      if (localBitmap != null)
      {
        paramParcel2.writeInt(1);
        localBitmap.writeToParcel(paramParcel2, 1);
        return true;
      }
      paramParcel2.writeInt(0);
      return true;
    }
    
    private static class Proxy
      implements IThumbnailRetriever
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.app.IThumbnailRetriever";
      }
      
      /* Error */
      public Bitmap getThumbnail(int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 31	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 31	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 21
        //   11: invokevirtual 35	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_2
        //   15: iload_1
        //   16: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   19: aload_0
        //   20: getfield 15	android/app/IThumbnailRetriever$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   23: iconst_1
        //   24: aload_2
        //   25: aload_3
        //   26: iconst_0
        //   27: invokeinterface 45 5 0
        //   32: pop
        //   33: aload_3
        //   34: invokevirtual 48	android/os/Parcel:readException	()V
        //   37: aload_3
        //   38: invokevirtual 52	android/os/Parcel:readInt	()I
        //   41: ifeq +28 -> 69
        //   44: getstatic 58	android/graphics/Bitmap:CREATOR	Landroid/os/Parcelable$Creator;
        //   47: aload_3
        //   48: invokeinterface 64 2 0
        //   53: checkcast 54	android/graphics/Bitmap
        //   56: astore 6
        //   58: aload_3
        //   59: invokevirtual 67	android/os/Parcel:recycle	()V
        //   62: aload_2
        //   63: invokevirtual 67	android/os/Parcel:recycle	()V
        //   66: aload 6
        //   68: areturn
        //   69: aconst_null
        //   70: astore 6
        //   72: goto -14 -> 58
        //   75: astore 4
        //   77: aload_3
        //   78: invokevirtual 67	android/os/Parcel:recycle	()V
        //   81: aload_2
        //   82: invokevirtual 67	android/os/Parcel:recycle	()V
        //   85: aload 4
        //   87: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	88	0	this	Proxy
        //   0	88	1	paramInt	int
        //   3	79	2	localParcel1	Parcel
        //   7	71	3	localParcel2	Parcel
        //   75	11	4	localObject	Object
        //   56	15	6	localBitmap	Bitmap
        // Exception table:
        //   from	to	target	type
        //   8	58	75	finally
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\IThumbnailRetriever.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
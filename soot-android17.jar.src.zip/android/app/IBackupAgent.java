package android.app;

import android.app.backup.IBackupManager;
import android.app.backup.IBackupManager.Stub;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface IBackupAgent
  extends IInterface
{
  public abstract void doBackup(ParcelFileDescriptor paramParcelFileDescriptor1, ParcelFileDescriptor paramParcelFileDescriptor2, ParcelFileDescriptor paramParcelFileDescriptor3, int paramInt, IBackupManager paramIBackupManager)
    throws RemoteException;
  
  public abstract void doFullBackup(ParcelFileDescriptor paramParcelFileDescriptor, int paramInt, IBackupManager paramIBackupManager)
    throws RemoteException;
  
  public abstract void doRestore(ParcelFileDescriptor paramParcelFileDescriptor1, int paramInt1, ParcelFileDescriptor paramParcelFileDescriptor2, int paramInt2, IBackupManager paramIBackupManager)
    throws RemoteException;
  
  public abstract void doRestoreFile(ParcelFileDescriptor paramParcelFileDescriptor, long paramLong1, int paramInt1, String paramString1, String paramString2, long paramLong2, long paramLong3, int paramInt2, IBackupManager paramIBackupManager)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IBackupAgent
  {
    private static final String DESCRIPTOR = "android.app.IBackupAgent";
    static final int TRANSACTION_doBackup = 1;
    static final int TRANSACTION_doFullBackup = 3;
    static final int TRANSACTION_doRestore = 2;
    static final int TRANSACTION_doRestoreFile = 4;
    
    public Stub()
    {
      attachInterface(this, "android.app.IBackupAgent");
    }
    
    public static IBackupAgent asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.app.IBackupAgent");
      if ((localIInterface != null) && ((localIInterface instanceof IBackupAgent))) {
        return (IBackupAgent)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.app.IBackupAgent");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.app.IBackupAgent");
        ParcelFileDescriptor localParcelFileDescriptor5;
        ParcelFileDescriptor localParcelFileDescriptor6;
        if (paramParcel1.readInt() != 0)
        {
          localParcelFileDescriptor5 = (ParcelFileDescriptor)ParcelFileDescriptor.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label168;
          }
          localParcelFileDescriptor6 = (ParcelFileDescriptor)ParcelFileDescriptor.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label174;
          }
        }
        for (ParcelFileDescriptor localParcelFileDescriptor7 = (ParcelFileDescriptor)ParcelFileDescriptor.CREATOR.createFromParcel(paramParcel1);; localParcelFileDescriptor7 = null)
        {
          doBackup(localParcelFileDescriptor5, localParcelFileDescriptor6, localParcelFileDescriptor7, paramParcel1.readInt(), IBackupManager.Stub.asInterface(paramParcel1.readStrongBinder()));
          return true;
          localParcelFileDescriptor5 = null;
          break;
          localParcelFileDescriptor6 = null;
          break label118;
        }
      case 2: 
        paramParcel1.enforceInterface("android.app.IBackupAgent");
        ParcelFileDescriptor localParcelFileDescriptor3;
        int k;
        if (paramParcel1.readInt() != 0)
        {
          localParcelFileDescriptor3 = (ParcelFileDescriptor)ParcelFileDescriptor.CREATOR.createFromParcel(paramParcel1);
          k = paramParcel1.readInt();
          if (paramParcel1.readInt() == 0) {
            break label263;
          }
        }
        for (ParcelFileDescriptor localParcelFileDescriptor4 = (ParcelFileDescriptor)ParcelFileDescriptor.CREATOR.createFromParcel(paramParcel1);; localParcelFileDescriptor4 = null)
        {
          doRestore(localParcelFileDescriptor3, k, localParcelFileDescriptor4, paramParcel1.readInt(), IBackupManager.Stub.asInterface(paramParcel1.readStrongBinder()));
          return true;
          localParcelFileDescriptor3 = null;
          break;
        }
      case 3: 
        label118:
        label168:
        label174:
        label263:
        paramParcel1.enforceInterface("android.app.IBackupAgent");
        if (paramParcel1.readInt() != 0) {}
        for (ParcelFileDescriptor localParcelFileDescriptor2 = (ParcelFileDescriptor)ParcelFileDescriptor.CREATOR.createFromParcel(paramParcel1);; localParcelFileDescriptor2 = null)
        {
          doFullBackup(localParcelFileDescriptor2, paramParcel1.readInt(), IBackupManager.Stub.asInterface(paramParcel1.readStrongBinder()));
          return true;
        }
      }
      paramParcel1.enforceInterface("android.app.IBackupAgent");
      if (paramParcel1.readInt() != 0) {}
      for (ParcelFileDescriptor localParcelFileDescriptor1 = (ParcelFileDescriptor)ParcelFileDescriptor.CREATOR.createFromParcel(paramParcel1);; localParcelFileDescriptor1 = null)
      {
        long l1 = paramParcel1.readLong();
        int i = paramParcel1.readInt();
        String str1 = paramParcel1.readString();
        String str2 = paramParcel1.readString();
        long l2 = paramParcel1.readLong();
        long l3 = paramParcel1.readLong();
        int j = paramParcel1.readInt();
        IBackupManager localIBackupManager = IBackupManager.Stub.asInterface(paramParcel1.readStrongBinder());
        doRestoreFile(localParcelFileDescriptor1, l1, i, str1, str2, l2, l3, j, localIBackupManager);
        return true;
      }
    }
    
    private static class Proxy
      implements IBackupAgent
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public void doBackup(ParcelFileDescriptor paramParcelFileDescriptor1, ParcelFileDescriptor paramParcelFileDescriptor2, ParcelFileDescriptor paramParcelFileDescriptor3, int paramInt, IBackupManager paramIBackupManager)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel.writeInterfaceToken("android.app.IBackupAgent");
            if (paramParcelFileDescriptor1 != null)
            {
              localParcel.writeInt(1);
              paramParcelFileDescriptor1.writeToParcel(localParcel, 0);
              if (paramParcelFileDescriptor2 != null)
              {
                localParcel.writeInt(1);
                paramParcelFileDescriptor2.writeToParcel(localParcel, 0);
                if (paramParcelFileDescriptor3 == null) {
                  break label143;
                }
                localParcel.writeInt(1);
                paramParcelFileDescriptor3.writeToParcel(localParcel, 0);
                localParcel.writeInt(paramInt);
                IBinder localIBinder = null;
                if (paramIBackupManager != null) {
                  localIBinder = paramIBackupManager.asBinder();
                }
                localParcel.writeStrongBinder(localIBinder);
                this.mRemote.transact(1, localParcel, null, 1);
              }
            }
            else
            {
              localParcel.writeInt(0);
              continue;
            }
            localParcel.writeInt(0);
          }
          finally
          {
            localParcel.recycle();
          }
          continue;
          label143:
          localParcel.writeInt(0);
        }
      }
      
      /* Error */
      public void doFullBackup(ParcelFileDescriptor paramParcelFileDescriptor, int paramInt, IBackupManager paramIBackupManager)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: aload 4
        //   7: ldc 29
        //   9: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   12: aload_1
        //   13: ifnull +65 -> 78
        //   16: aload 4
        //   18: iconst_1
        //   19: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   22: aload_1
        //   23: aload 4
        //   25: iconst_0
        //   26: invokevirtual 43	android/os/ParcelFileDescriptor:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload 4
        //   31: iload_2
        //   32: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   35: aconst_null
        //   36: astore 6
        //   38: aload_3
        //   39: ifnull +11 -> 50
        //   42: aload_3
        //   43: invokeinterface 47 1 0
        //   48: astore 6
        //   50: aload 4
        //   52: aload 6
        //   54: invokevirtual 50	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   57: aload_0
        //   58: getfield 15	android/app/IBackupAgent$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   61: iconst_3
        //   62: aload 4
        //   64: aconst_null
        //   65: iconst_1
        //   66: invokeinterface 56 5 0
        //   71: pop
        //   72: aload 4
        //   74: invokevirtual 59	android/os/Parcel:recycle	()V
        //   77: return
        //   78: aload 4
        //   80: iconst_0
        //   81: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   84: goto -55 -> 29
        //   87: astore 5
        //   89: aload 4
        //   91: invokevirtual 59	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramParcelFileDescriptor	ParcelFileDescriptor
        //   0	97	2	paramInt	int
        //   0	97	3	paramIBackupManager	IBackupManager
        //   3	87	4	localParcel	Parcel
        //   87	8	5	localObject	Object
        //   36	17	6	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   5	12	87	finally
        //   16	29	87	finally
        //   29	35	87	finally
        //   42	50	87	finally
        //   50	72	87	finally
        //   78	84	87	finally
      }
      
      public void doRestore(ParcelFileDescriptor paramParcelFileDescriptor1, int paramInt1, ParcelFileDescriptor paramParcelFileDescriptor2, int paramInt2, IBackupManager paramIBackupManager)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel.writeInterfaceToken("android.app.IBackupAgent");
            if (paramParcelFileDescriptor1 != null)
            {
              localParcel.writeInt(1);
              paramParcelFileDescriptor1.writeToParcel(localParcel, 0);
              localParcel.writeInt(paramInt1);
              if (paramParcelFileDescriptor2 != null)
              {
                localParcel.writeInt(1);
                paramParcelFileDescriptor2.writeToParcel(localParcel, 0);
                localParcel.writeInt(paramInt2);
                IBinder localIBinder = null;
                if (paramIBackupManager != null) {
                  localIBinder = paramIBackupManager.asBinder();
                }
                localParcel.writeStrongBinder(localIBinder);
                this.mRemote.transact(2, localParcel, null, 1);
              }
            }
            else
            {
              localParcel.writeInt(0);
              continue;
            }
            localParcel.writeInt(0);
          }
          finally
          {
            localParcel.recycle();
          }
        }
      }
      
      public void doRestoreFile(ParcelFileDescriptor paramParcelFileDescriptor, long paramLong1, int paramInt1, String paramString1, String paramString2, long paramLong2, long paramLong3, int paramInt2, IBackupManager paramIBackupManager)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel.writeInterfaceToken("android.app.IBackupAgent");
            if (paramParcelFileDescriptor != null)
            {
              localParcel.writeInt(1);
              paramParcelFileDescriptor.writeToParcel(localParcel, 0);
              localParcel.writeLong(paramLong1);
              localParcel.writeInt(paramInt1);
              localParcel.writeString(paramString1);
              localParcel.writeString(paramString2);
              localParcel.writeLong(paramLong2);
              localParcel.writeLong(paramLong3);
              localParcel.writeInt(paramInt2);
              if (paramIBackupManager != null)
              {
                localIBinder = paramIBackupManager.asBinder();
                localParcel.writeStrongBinder(localIBinder);
                this.mRemote.transact(4, localParcel, null, 1);
              }
            }
            else
            {
              localParcel.writeInt(0);
              continue;
            }
            IBinder localIBinder = null;
          }
          finally
          {
            localParcel.recycle();
          }
        }
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.app.IBackupAgent";
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\IBackupAgent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
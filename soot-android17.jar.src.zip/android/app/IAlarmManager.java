package android.app;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface IAlarmManager
  extends IInterface
{
  public abstract void remove(PendingIntent paramPendingIntent)
    throws RemoteException;
  
  public abstract void set(int paramInt, long paramLong, PendingIntent paramPendingIntent)
    throws RemoteException;
  
  public abstract void setInexactRepeating(int paramInt, long paramLong1, long paramLong2, PendingIntent paramPendingIntent)
    throws RemoteException;
  
  public abstract void setRepeating(int paramInt, long paramLong1, long paramLong2, PendingIntent paramPendingIntent)
    throws RemoteException;
  
  public abstract void setTime(long paramLong)
    throws RemoteException;
  
  public abstract void setTimeZone(String paramString)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IAlarmManager
  {
    private static final String DESCRIPTOR = "android.app.IAlarmManager";
    static final int TRANSACTION_remove = 6;
    static final int TRANSACTION_set = 1;
    static final int TRANSACTION_setInexactRepeating = 3;
    static final int TRANSACTION_setRepeating = 2;
    static final int TRANSACTION_setTime = 4;
    static final int TRANSACTION_setTimeZone = 5;
    
    public Stub()
    {
      attachInterface(this, "android.app.IAlarmManager");
    }
    
    public static IAlarmManager asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.app.IAlarmManager");
      if ((localIInterface != null) && ((localIInterface instanceof IAlarmManager))) {
        return (IAlarmManager)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.app.IAlarmManager");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.app.IAlarmManager");
        int k = paramParcel1.readInt();
        long l5 = paramParcel1.readLong();
        if (paramParcel1.readInt() != 0) {}
        for (PendingIntent localPendingIntent4 = (PendingIntent)PendingIntent.CREATOR.createFromParcel(paramParcel1);; localPendingIntent4 = null)
        {
          set(k, l5, localPendingIntent4);
          paramParcel2.writeNoException();
          return true;
        }
      case 2: 
        paramParcel1.enforceInterface("android.app.IAlarmManager");
        int j = paramParcel1.readInt();
        long l3 = paramParcel1.readLong();
        long l4 = paramParcel1.readLong();
        if (paramParcel1.readInt() != 0) {}
        for (PendingIntent localPendingIntent3 = (PendingIntent)PendingIntent.CREATOR.createFromParcel(paramParcel1);; localPendingIntent3 = null)
        {
          setRepeating(j, l3, l4, localPendingIntent3);
          paramParcel2.writeNoException();
          return true;
        }
      case 3: 
        paramParcel1.enforceInterface("android.app.IAlarmManager");
        int i = paramParcel1.readInt();
        long l1 = paramParcel1.readLong();
        long l2 = paramParcel1.readLong();
        if (paramParcel1.readInt() != 0) {}
        for (PendingIntent localPendingIntent2 = (PendingIntent)PendingIntent.CREATOR.createFromParcel(paramParcel1);; localPendingIntent2 = null)
        {
          setInexactRepeating(i, l1, l2, localPendingIntent2);
          paramParcel2.writeNoException();
          return true;
        }
      case 4: 
        paramParcel1.enforceInterface("android.app.IAlarmManager");
        setTime(paramParcel1.readLong());
        paramParcel2.writeNoException();
        return true;
      case 5: 
        paramParcel1.enforceInterface("android.app.IAlarmManager");
        setTimeZone(paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      }
      paramParcel1.enforceInterface("android.app.IAlarmManager");
      if (paramParcel1.readInt() != 0) {}
      for (PendingIntent localPendingIntent1 = (PendingIntent)PendingIntent.CREATOR.createFromParcel(paramParcel1);; localPendingIntent1 = null)
      {
        remove(localPendingIntent1);
        paramParcel2.writeNoException();
        return true;
      }
    }
    
    private static class Proxy
      implements IAlarmManager
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.app.IAlarmManager";
      }
      
      /* Error */
      public void remove(PendingIntent paramPendingIntent)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 31	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 31	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 21
        //   11: invokevirtual 35	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +42 -> 57
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 45	android/app/PendingIntent:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/app/IAlarmManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: bipush 6
        //   35: aload_2
        //   36: aload_3
        //   37: iconst_0
        //   38: invokeinterface 51 5 0
        //   43: pop
        //   44: aload_3
        //   45: invokevirtual 54	android/os/Parcel:readException	()V
        //   48: aload_3
        //   49: invokevirtual 57	android/os/Parcel:recycle	()V
        //   52: aload_2
        //   53: invokevirtual 57	android/os/Parcel:recycle	()V
        //   56: return
        //   57: aload_2
        //   58: iconst_0
        //   59: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   62: goto -33 -> 29
        //   65: astore 4
        //   67: aload_3
        //   68: invokevirtual 57	android/os/Parcel:recycle	()V
        //   71: aload_2
        //   72: invokevirtual 57	android/os/Parcel:recycle	()V
        //   75: aload 4
        //   77: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	78	0	this	Proxy
        //   0	78	1	paramPendingIntent	PendingIntent
        //   3	69	2	localParcel1	Parcel
        //   7	61	3	localParcel2	Parcel
        //   65	11	4	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   8	14	65	finally
        //   18	29	65	finally
        //   29	48	65	finally
        //   57	62	65	finally
      }
      
      /* Error */
      public void set(int paramInt, long paramLong, PendingIntent paramPendingIntent)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 31	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 5
        //   5: invokestatic 31	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 6
        //   10: aload 5
        //   12: ldc 21
        //   14: invokevirtual 35	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 5
        //   19: iload_1
        //   20: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   23: aload 5
        //   25: lload_2
        //   26: invokevirtual 63	android/os/Parcel:writeLong	(J)V
        //   29: aload 4
        //   31: ifnull +49 -> 80
        //   34: aload 5
        //   36: iconst_1
        //   37: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   40: aload 4
        //   42: aload 5
        //   44: iconst_0
        //   45: invokevirtual 45	android/app/PendingIntent:writeToParcel	(Landroid/os/Parcel;I)V
        //   48: aload_0
        //   49: getfield 15	android/app/IAlarmManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   52: iconst_1
        //   53: aload 5
        //   55: aload 6
        //   57: iconst_0
        //   58: invokeinterface 51 5 0
        //   63: pop
        //   64: aload 6
        //   66: invokevirtual 54	android/os/Parcel:readException	()V
        //   69: aload 6
        //   71: invokevirtual 57	android/os/Parcel:recycle	()V
        //   74: aload 5
        //   76: invokevirtual 57	android/os/Parcel:recycle	()V
        //   79: return
        //   80: aload 5
        //   82: iconst_0
        //   83: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   86: goto -38 -> 48
        //   89: astore 7
        //   91: aload 6
        //   93: invokevirtual 57	android/os/Parcel:recycle	()V
        //   96: aload 5
        //   98: invokevirtual 57	android/os/Parcel:recycle	()V
        //   101: aload 7
        //   103: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	104	0	this	Proxy
        //   0	104	1	paramInt	int
        //   0	104	2	paramLong	long
        //   0	104	4	paramPendingIntent	PendingIntent
        //   3	94	5	localParcel1	Parcel
        //   8	84	6	localParcel2	Parcel
        //   89	13	7	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	29	89	finally
        //   34	48	89	finally
        //   48	69	89	finally
        //   80	86	89	finally
      }
      
      /* Error */
      public void setInexactRepeating(int paramInt, long paramLong1, long paramLong2, PendingIntent paramPendingIntent)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 31	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 7
        //   5: invokestatic 31	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 8
        //   10: aload 7
        //   12: ldc 21
        //   14: invokevirtual 35	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 7
        //   19: iload_1
        //   20: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   23: aload 7
        //   25: lload_2
        //   26: invokevirtual 63	android/os/Parcel:writeLong	(J)V
        //   29: aload 7
        //   31: lload 4
        //   33: invokevirtual 63	android/os/Parcel:writeLong	(J)V
        //   36: aload 6
        //   38: ifnull +49 -> 87
        //   41: aload 7
        //   43: iconst_1
        //   44: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   47: aload 6
        //   49: aload 7
        //   51: iconst_0
        //   52: invokevirtual 45	android/app/PendingIntent:writeToParcel	(Landroid/os/Parcel;I)V
        //   55: aload_0
        //   56: getfield 15	android/app/IAlarmManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   59: iconst_3
        //   60: aload 7
        //   62: aload 8
        //   64: iconst_0
        //   65: invokeinterface 51 5 0
        //   70: pop
        //   71: aload 8
        //   73: invokevirtual 54	android/os/Parcel:readException	()V
        //   76: aload 8
        //   78: invokevirtual 57	android/os/Parcel:recycle	()V
        //   81: aload 7
        //   83: invokevirtual 57	android/os/Parcel:recycle	()V
        //   86: return
        //   87: aload 7
        //   89: iconst_0
        //   90: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   93: goto -38 -> 55
        //   96: astore 9
        //   98: aload 8
        //   100: invokevirtual 57	android/os/Parcel:recycle	()V
        //   103: aload 7
        //   105: invokevirtual 57	android/os/Parcel:recycle	()V
        //   108: aload 9
        //   110: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	111	0	this	Proxy
        //   0	111	1	paramInt	int
        //   0	111	2	paramLong1	long
        //   0	111	4	paramLong2	long
        //   0	111	6	paramPendingIntent	PendingIntent
        //   3	101	7	localParcel1	Parcel
        //   8	91	8	localParcel2	Parcel
        //   96	13	9	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	36	96	finally
        //   41	55	96	finally
        //   55	76	96	finally
        //   87	93	96	finally
      }
      
      /* Error */
      public void setRepeating(int paramInt, long paramLong1, long paramLong2, PendingIntent paramPendingIntent)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 31	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 7
        //   5: invokestatic 31	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 8
        //   10: aload 7
        //   12: ldc 21
        //   14: invokevirtual 35	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 7
        //   19: iload_1
        //   20: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   23: aload 7
        //   25: lload_2
        //   26: invokevirtual 63	android/os/Parcel:writeLong	(J)V
        //   29: aload 7
        //   31: lload 4
        //   33: invokevirtual 63	android/os/Parcel:writeLong	(J)V
        //   36: aload 6
        //   38: ifnull +49 -> 87
        //   41: aload 7
        //   43: iconst_1
        //   44: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   47: aload 6
        //   49: aload 7
        //   51: iconst_0
        //   52: invokevirtual 45	android/app/PendingIntent:writeToParcel	(Landroid/os/Parcel;I)V
        //   55: aload_0
        //   56: getfield 15	android/app/IAlarmManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   59: iconst_2
        //   60: aload 7
        //   62: aload 8
        //   64: iconst_0
        //   65: invokeinterface 51 5 0
        //   70: pop
        //   71: aload 8
        //   73: invokevirtual 54	android/os/Parcel:readException	()V
        //   76: aload 8
        //   78: invokevirtual 57	android/os/Parcel:recycle	()V
        //   81: aload 7
        //   83: invokevirtual 57	android/os/Parcel:recycle	()V
        //   86: return
        //   87: aload 7
        //   89: iconst_0
        //   90: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   93: goto -38 -> 55
        //   96: astore 9
        //   98: aload 8
        //   100: invokevirtual 57	android/os/Parcel:recycle	()V
        //   103: aload 7
        //   105: invokevirtual 57	android/os/Parcel:recycle	()V
        //   108: aload 9
        //   110: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	111	0	this	Proxy
        //   0	111	1	paramInt	int
        //   0	111	2	paramLong1	long
        //   0	111	4	paramLong2	long
        //   0	111	6	paramPendingIntent	PendingIntent
        //   3	101	7	localParcel1	Parcel
        //   8	91	8	localParcel2	Parcel
        //   96	13	9	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	36	96	finally
        //   41	55	96	finally
        //   55	76	96	finally
        //   87	93	96	finally
      }
      
      public void setTime(long paramLong)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.IAlarmManager");
          localParcel1.writeLong(paramLong);
          this.mRemote.transact(4, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void setTimeZone(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.IAlarmManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\IAlarmManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.app;

import android.content.ComponentName;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface IWallpaperManager
  extends IInterface
{
  public abstract void clearWallpaper()
    throws RemoteException;
  
  public abstract int getHeightHint()
    throws RemoteException;
  
  public abstract ParcelFileDescriptor getWallpaper(IWallpaperManagerCallback paramIWallpaperManagerCallback, Bundle paramBundle)
    throws RemoteException;
  
  public abstract WallpaperInfo getWallpaperInfo()
    throws RemoteException;
  
  public abstract int getWidthHint()
    throws RemoteException;
  
  public abstract boolean hasNamedWallpaper(String paramString)
    throws RemoteException;
  
  public abstract void setDimensionHints(int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract ParcelFileDescriptor setWallpaper(String paramString)
    throws RemoteException;
  
  public abstract void setWallpaperComponent(ComponentName paramComponentName)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IWallpaperManager
  {
    private static final String DESCRIPTOR = "android.app.IWallpaperManager";
    static final int TRANSACTION_clearWallpaper = 5;
    static final int TRANSACTION_getHeightHint = 9;
    static final int TRANSACTION_getWallpaper = 3;
    static final int TRANSACTION_getWallpaperInfo = 4;
    static final int TRANSACTION_getWidthHint = 8;
    static final int TRANSACTION_hasNamedWallpaper = 6;
    static final int TRANSACTION_setDimensionHints = 7;
    static final int TRANSACTION_setWallpaper = 1;
    static final int TRANSACTION_setWallpaperComponent = 2;
    
    public Stub()
    {
      attachInterface(this, "android.app.IWallpaperManager");
    }
    
    public static IWallpaperManager asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.app.IWallpaperManager");
      if ((localIInterface != null) && ((localIInterface instanceof IWallpaperManager))) {
        return (IWallpaperManager)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.app.IWallpaperManager");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.app.IWallpaperManager");
        ParcelFileDescriptor localParcelFileDescriptor2 = setWallpaper(paramParcel1.readString());
        paramParcel2.writeNoException();
        if (localParcelFileDescriptor2 != null)
        {
          paramParcel2.writeInt(1);
          localParcelFileDescriptor2.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 2: 
        paramParcel1.enforceInterface("android.app.IWallpaperManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName = null)
        {
          setWallpaperComponent(localComponentName);
          paramParcel2.writeNoException();
          return true;
        }
      case 3: 
        paramParcel1.enforceInterface("android.app.IWallpaperManager");
        IWallpaperManagerCallback localIWallpaperManagerCallback = IWallpaperManagerCallback.Stub.asInterface(paramParcel1.readStrongBinder());
        Bundle localBundle = new Bundle();
        ParcelFileDescriptor localParcelFileDescriptor1 = getWallpaper(localIWallpaperManagerCallback, localBundle);
        paramParcel2.writeNoException();
        if (localParcelFileDescriptor1 != null)
        {
          paramParcel2.writeInt(1);
          localParcelFileDescriptor1.writeToParcel(paramParcel2, 1);
        }
        while (localBundle != null)
        {
          paramParcel2.writeInt(1);
          localBundle.writeToParcel(paramParcel2, 1);
          return true;
          paramParcel2.writeInt(0);
        }
        paramParcel2.writeInt(0);
        return true;
      case 4: 
        paramParcel1.enforceInterface("android.app.IWallpaperManager");
        WallpaperInfo localWallpaperInfo = getWallpaperInfo();
        paramParcel2.writeNoException();
        if (localWallpaperInfo != null)
        {
          paramParcel2.writeInt(1);
          localWallpaperInfo.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 5: 
        paramParcel1.enforceInterface("android.app.IWallpaperManager");
        clearWallpaper();
        paramParcel2.writeNoException();
        return true;
      case 6: 
        paramParcel1.enforceInterface("android.app.IWallpaperManager");
        boolean bool = hasNamedWallpaper(paramParcel1.readString());
        paramParcel2.writeNoException();
        int k = 0;
        if (bool) {
          k = 1;
        }
        paramParcel2.writeInt(k);
        return true;
      case 7: 
        paramParcel1.enforceInterface("android.app.IWallpaperManager");
        setDimensionHints(paramParcel1.readInt(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 8: 
        paramParcel1.enforceInterface("android.app.IWallpaperManager");
        int j = getWidthHint();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(j);
        return true;
      }
      paramParcel1.enforceInterface("android.app.IWallpaperManager");
      int i = getHeightHint();
      paramParcel2.writeNoException();
      paramParcel2.writeInt(i);
      return true;
    }
    
    private static class Proxy
      implements IWallpaperManager
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public void clearWallpaper()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.IWallpaperManager");
          this.mRemote.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public int getHeightHint()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.IWallpaperManager");
          this.mRemote.transact(9, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.app.IWallpaperManager";
      }
      
      /* Error */
      public ParcelFileDescriptor getWallpaper(IWallpaperManagerCallback paramIWallpaperManagerCallback, Bundle paramBundle)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 26	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 26	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 28
        //   12: invokevirtual 32	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +86 -> 102
        //   19: aload_1
        //   20: invokeinterface 57 1 0
        //   25: astore 6
        //   27: aload_3
        //   28: aload 6
        //   30: invokevirtual 60	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   33: aload_0
        //   34: getfield 15	android/app/IWallpaperManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   37: iconst_3
        //   38: aload_3
        //   39: aload 4
        //   41: iconst_0
        //   42: invokeinterface 38 5 0
        //   47: pop
        //   48: aload 4
        //   50: invokevirtual 41	android/os/Parcel:readException	()V
        //   53: aload 4
        //   55: invokevirtual 49	android/os/Parcel:readInt	()I
        //   58: ifeq +50 -> 108
        //   61: getstatic 66	android/os/ParcelFileDescriptor:CREATOR	Landroid/os/Parcelable$Creator;
        //   64: aload 4
        //   66: invokeinterface 72 2 0
        //   71: checkcast 62	android/os/ParcelFileDescriptor
        //   74: astore 8
        //   76: aload 4
        //   78: invokevirtual 49	android/os/Parcel:readInt	()I
        //   81: ifeq +9 -> 90
        //   84: aload_2
        //   85: aload 4
        //   87: invokevirtual 78	android/os/Bundle:readFromParcel	(Landroid/os/Parcel;)V
        //   90: aload 4
        //   92: invokevirtual 44	android/os/Parcel:recycle	()V
        //   95: aload_3
        //   96: invokevirtual 44	android/os/Parcel:recycle	()V
        //   99: aload 8
        //   101: areturn
        //   102: aconst_null
        //   103: astore 6
        //   105: goto -78 -> 27
        //   108: aconst_null
        //   109: astore 8
        //   111: goto -35 -> 76
        //   114: astore 5
        //   116: aload 4
        //   118: invokevirtual 44	android/os/Parcel:recycle	()V
        //   121: aload_3
        //   122: invokevirtual 44	android/os/Parcel:recycle	()V
        //   125: aload 5
        //   127: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	128	0	this	Proxy
        //   0	128	1	paramIWallpaperManagerCallback	IWallpaperManagerCallback
        //   0	128	2	paramBundle	Bundle
        //   3	119	3	localParcel1	Parcel
        //   7	110	4	localParcel2	Parcel
        //   114	12	5	localObject	Object
        //   25	79	6	localIBinder	IBinder
        //   74	36	8	localParcelFileDescriptor	ParcelFileDescriptor
        // Exception table:
        //   from	to	target	type
        //   9	15	114	finally
        //   19	27	114	finally
        //   27	76	114	finally
        //   76	90	114	finally
      }
      
      /* Error */
      public WallpaperInfo getWallpaperInfo()
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 26	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_1
        //   4: invokestatic 26	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_2
        //   8: aload_1
        //   9: ldc 28
        //   11: invokevirtual 32	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_0
        //   15: getfield 15	android/app/IWallpaperManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   18: iconst_4
        //   19: aload_1
        //   20: aload_2
        //   21: iconst_0
        //   22: invokeinterface 38 5 0
        //   27: pop
        //   28: aload_2
        //   29: invokevirtual 41	android/os/Parcel:readException	()V
        //   32: aload_2
        //   33: invokevirtual 49	android/os/Parcel:readInt	()I
        //   36: ifeq +28 -> 64
        //   39: getstatic 83	android/app/WallpaperInfo:CREATOR	Landroid/os/Parcelable$Creator;
        //   42: aload_2
        //   43: invokeinterface 72 2 0
        //   48: checkcast 82	android/app/WallpaperInfo
        //   51: astore 5
        //   53: aload_2
        //   54: invokevirtual 44	android/os/Parcel:recycle	()V
        //   57: aload_1
        //   58: invokevirtual 44	android/os/Parcel:recycle	()V
        //   61: aload 5
        //   63: areturn
        //   64: aconst_null
        //   65: astore 5
        //   67: goto -14 -> 53
        //   70: astore_3
        //   71: aload_2
        //   72: invokevirtual 44	android/os/Parcel:recycle	()V
        //   75: aload_1
        //   76: invokevirtual 44	android/os/Parcel:recycle	()V
        //   79: aload_3
        //   80: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	81	0	this	Proxy
        //   3	73	1	localParcel1	Parcel
        //   7	65	2	localParcel2	Parcel
        //   70	10	3	localObject	Object
        //   51	15	5	localWallpaperInfo	WallpaperInfo
        // Exception table:
        //   from	to	target	type
        //   8	53	70	finally
      }
      
      public int getWidthHint()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.IWallpaperManager");
          this.mRemote.transact(8, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean hasNamedWallpaper(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.IWallpaperManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(6, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void setDimensionHints(int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.IWallpaperManager");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          this.mRemote.transact(7, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public ParcelFileDescriptor setWallpaper(String paramString)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 26	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 26	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 28
        //   11: invokevirtual 32	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_2
        //   15: aload_1
        //   16: invokevirtual 89	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   19: aload_0
        //   20: getfield 15	android/app/IWallpaperManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   23: iconst_1
        //   24: aload_2
        //   25: aload_3
        //   26: iconst_0
        //   27: invokeinterface 38 5 0
        //   32: pop
        //   33: aload_3
        //   34: invokevirtual 41	android/os/Parcel:readException	()V
        //   37: aload_3
        //   38: invokevirtual 49	android/os/Parcel:readInt	()I
        //   41: ifeq +28 -> 69
        //   44: getstatic 66	android/os/ParcelFileDescriptor:CREATOR	Landroid/os/Parcelable$Creator;
        //   47: aload_3
        //   48: invokeinterface 72 2 0
        //   53: checkcast 62	android/os/ParcelFileDescriptor
        //   56: astore 6
        //   58: aload_3
        //   59: invokevirtual 44	android/os/Parcel:recycle	()V
        //   62: aload_2
        //   63: invokevirtual 44	android/os/Parcel:recycle	()V
        //   66: aload 6
        //   68: areturn
        //   69: aconst_null
        //   70: astore 6
        //   72: goto -14 -> 58
        //   75: astore 4
        //   77: aload_3
        //   78: invokevirtual 44	android/os/Parcel:recycle	()V
        //   81: aload_2
        //   82: invokevirtual 44	android/os/Parcel:recycle	()V
        //   85: aload 4
        //   87: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	88	0	this	Proxy
        //   0	88	1	paramString	String
        //   3	79	2	localParcel1	Parcel
        //   7	71	3	localParcel2	Parcel
        //   75	11	4	localObject	Object
        //   56	15	6	localParcelFileDescriptor	ParcelFileDescriptor
        // Exception table:
        //   from	to	target	type
        //   8	58	75	finally
      }
      
      /* Error */
      public void setWallpaperComponent(ComponentName paramComponentName)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 26	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 26	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 28
        //   11: invokevirtual 32	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +41 -> 56
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 95	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 105	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/app/IWallpaperManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: iconst_2
        //   34: aload_2
        //   35: aload_3
        //   36: iconst_0
        //   37: invokeinterface 38 5 0
        //   42: pop
        //   43: aload_3
        //   44: invokevirtual 41	android/os/Parcel:readException	()V
        //   47: aload_3
        //   48: invokevirtual 44	android/os/Parcel:recycle	()V
        //   51: aload_2
        //   52: invokevirtual 44	android/os/Parcel:recycle	()V
        //   55: return
        //   56: aload_2
        //   57: iconst_0
        //   58: invokevirtual 95	android/os/Parcel:writeInt	(I)V
        //   61: goto -32 -> 29
        //   64: astore 4
        //   66: aload_3
        //   67: invokevirtual 44	android/os/Parcel:recycle	()V
        //   70: aload_2
        //   71: invokevirtual 44	android/os/Parcel:recycle	()V
        //   74: aload 4
        //   76: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	77	0	this	Proxy
        //   0	77	1	paramComponentName	ComponentName
        //   3	68	2	localParcel1	Parcel
        //   7	60	3	localParcel2	Parcel
        //   64	11	4	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   8	14	64	finally
        //   18	29	64	finally
        //   29	47	64	finally
        //   56	61	64	finally
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\IWallpaperManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
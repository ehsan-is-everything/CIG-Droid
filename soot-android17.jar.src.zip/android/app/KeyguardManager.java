package android.app;

import android.os.Binder;
import android.os.IBinder;
import android.os.RemoteException;
import android.view.IOnKeyguardExitResult.Stub;
import android.view.IWindowManager;
import android.view.WindowManagerGlobal;

public class KeyguardManager
{
  private IWindowManager mWM = WindowManagerGlobal.getWindowManagerService();
  
  @Deprecated
  public void exitKeyguardSecurely(final OnKeyguardExitResult paramOnKeyguardExitResult)
  {
    try
    {
      this.mWM.exitKeyguardSecurely(new IOnKeyguardExitResult.Stub()
      {
        public void onKeyguardExitResult(boolean paramAnonymousBoolean)
          throws RemoteException
        {
          paramOnKeyguardExitResult.onKeyguardExitResult(paramAnonymousBoolean);
        }
      });
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public boolean inKeyguardRestrictedInputMode()
  {
    try
    {
      boolean bool = this.mWM.inKeyguardRestrictedInputMode();
      return bool;
    }
    catch (RemoteException localRemoteException) {}
    return false;
  }
  
  public boolean isKeyguardLocked()
  {
    try
    {
      boolean bool = this.mWM.isKeyguardLocked();
      return bool;
    }
    catch (RemoteException localRemoteException) {}
    return false;
  }
  
  public boolean isKeyguardSecure()
  {
    try
    {
      boolean bool = this.mWM.isKeyguardSecure();
      return bool;
    }
    catch (RemoteException localRemoteException) {}
    return false;
  }
  
  @Deprecated
  public KeyguardLock newKeyguardLock(String paramString)
  {
    return new KeyguardLock(paramString);
  }
  
  public class KeyguardLock
  {
    private String mTag;
    private IBinder mToken = new Binder();
    
    KeyguardLock(String paramString)
    {
      this.mTag = paramString;
    }
    
    public void disableKeyguard()
    {
      try
      {
        KeyguardManager.this.mWM.disableKeyguard(this.mToken, this.mTag);
        return;
      }
      catch (RemoteException localRemoteException) {}
    }
    
    public void reenableKeyguard()
    {
      try
      {
        KeyguardManager.this.mWM.reenableKeyguard(this.mToken);
        return;
      }
      catch (RemoteException localRemoteException) {}
    }
  }
  
  public static abstract interface OnKeyguardExitResult
  {
    public abstract void onKeyguardExitResult(boolean paramBoolean);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\KeyguardManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.app;

import android.content.Context;
import android.content.ContextWrapper;
import android.media.MediaRouter;
import android.media.MediaRouter.RouteInfo;
import android.media.MediaRouter.SimpleCallback;
import android.util.Log;
import android.view.ActionProvider;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import com.android.internal.app.MediaRouteChooserDialogFragment;
import java.lang.ref.WeakReference;

public class MediaRouteActionProvider
  extends ActionProvider
{
  private static final String TAG = "MediaRouteActionProvider";
  private RouterCallback mCallback;
  private Context mContext;
  private View.OnClickListener mExtendedSettingsListener;
  private MenuItem mMenuItem;
  private int mRouteTypes;
  private MediaRouter mRouter;
  private MediaRouteButton mView;
  
  public MediaRouteActionProvider(Context paramContext)
  {
    super(paramContext);
    this.mContext = paramContext;
    this.mRouter = ((MediaRouter)paramContext.getSystemService("media_router"));
    this.mCallback = new RouterCallback(this);
    setRouteTypes(1);
  }
  
  private Activity getActivity()
  {
    for (Context localContext = this.mContext; ((localContext instanceof ContextWrapper)) && (!(localContext instanceof Activity)); localContext = ((ContextWrapper)localContext).getBaseContext()) {}
    if (!(localContext instanceof Activity)) {
      throw new IllegalStateException("The MediaRouteActionProvider's Context is not an Activity.");
    }
    return (Activity)localContext;
  }
  
  public boolean isVisible()
  {
    return this.mRouter.getRouteCount() > 1;
  }
  
  public View onCreateActionView()
  {
    throw new UnsupportedOperationException("Use onCreateActionView(MenuItem) instead.");
  }
  
  public View onCreateActionView(MenuItem paramMenuItem)
  {
    if ((this.mMenuItem != null) || (this.mView != null)) {
      Log.e("MediaRouteActionProvider", "onCreateActionView: this ActionProvider is already associated with a menu item. Don't reuse MediaRouteActionProvider instances! Abandoning the old one...");
    }
    this.mMenuItem = paramMenuItem;
    this.mView = new MediaRouteButton(this.mContext);
    this.mView.setCheatSheetEnabled(true);
    this.mView.setRouteTypes(this.mRouteTypes);
    this.mView.setExtendedSettingsClickListener(this.mExtendedSettingsListener);
    this.mView.setLayoutParams(new ViewGroup.LayoutParams(-2, -1));
    return this.mView;
  }
  
  public boolean onPerformDefaultAction()
  {
    FragmentManager localFragmentManager = getActivity().getFragmentManager();
    if ((MediaRouteChooserDialogFragment)localFragmentManager.findFragmentByTag("android:MediaRouteChooserDialogFragment") != null)
    {
      Log.w("MediaRouteActionProvider", "onPerformDefaultAction(): Chooser dialog already showing!");
      return false;
    }
    MediaRouteChooserDialogFragment localMediaRouteChooserDialogFragment = new MediaRouteChooserDialogFragment();
    localMediaRouteChooserDialogFragment.setExtendedSettingsClickListener(this.mExtendedSettingsListener);
    localMediaRouteChooserDialogFragment.setRouteTypes(this.mRouteTypes);
    localMediaRouteChooserDialogFragment.show(localFragmentManager, "android:MediaRouteChooserDialogFragment");
    return true;
  }
  
  public boolean overridesItemVisibility()
  {
    return true;
  }
  
  public void setExtendedSettingsClickListener(View.OnClickListener paramOnClickListener)
  {
    this.mExtendedSettingsListener = paramOnClickListener;
    if (this.mView != null) {
      this.mView.setExtendedSettingsClickListener(paramOnClickListener);
    }
  }
  
  public void setRouteTypes(int paramInt)
  {
    if (this.mRouteTypes == paramInt) {}
    do
    {
      return;
      if (this.mRouteTypes != 0) {
        this.mRouter.removeCallback(this.mCallback);
      }
      this.mRouteTypes = paramInt;
      if (paramInt != 0) {
        this.mRouter.addCallback(paramInt, this.mCallback);
      }
    } while (this.mView == null);
    this.mView.setRouteTypes(this.mRouteTypes);
  }
  
  private static class RouterCallback
    extends MediaRouter.SimpleCallback
  {
    private WeakReference<MediaRouteActionProvider> mAp;
    
    RouterCallback(MediaRouteActionProvider paramMediaRouteActionProvider)
    {
      this.mAp = new WeakReference(paramMediaRouteActionProvider);
    }
    
    public void onRouteAdded(MediaRouter paramMediaRouter, MediaRouter.RouteInfo paramRouteInfo)
    {
      MediaRouteActionProvider localMediaRouteActionProvider = (MediaRouteActionProvider)this.mAp.get();
      if (localMediaRouteActionProvider == null)
      {
        paramMediaRouter.removeCallback(this);
        return;
      }
      localMediaRouteActionProvider.refreshVisibility();
    }
    
    public void onRouteRemoved(MediaRouter paramMediaRouter, MediaRouter.RouteInfo paramRouteInfo)
    {
      MediaRouteActionProvider localMediaRouteActionProvider = (MediaRouteActionProvider)this.mAp.get();
      if (localMediaRouteActionProvider == null)
      {
        paramMediaRouter.removeCallback(this);
        return;
      }
      localMediaRouteActionProvider.refreshVisibility();
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\MediaRouteActionProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
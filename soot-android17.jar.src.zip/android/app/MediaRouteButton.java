package android.app;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.media.MediaRouter;
import android.media.MediaRouter.RouteGroup;
import android.media.MediaRouter.RouteInfo;
import android.media.MediaRouter.SimpleCallback;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.widget.Toast;
import com.android.internal.R.styleable;
import com.android.internal.app.MediaRouteChooserDialogFragment;
import com.android.internal.app.MediaRouteChooserDialogFragment.LauncherListener;

public class MediaRouteButton
  extends View
{
  private static final int[] ACTIVATED_STATE_SET = { 16843518 };
  private static final int[] CHECKED_STATE_SET = { 16842912 };
  private static final String TAG = "MediaRouteButton";
  private boolean mAttachedToWindow;
  private boolean mCheatSheetEnabled;
  private MediaRouteChooserDialogFragment mDialogFragment;
  private View.OnClickListener mExtendedSettingsClickListener;
  private boolean mIsConnecting;
  private int mMinHeight;
  private int mMinWidth;
  private boolean mRemoteActive;
  private Drawable mRemoteIndicator;
  private int mRouteTypes;
  private MediaRouter mRouter;
  private final MediaRouteCallback mRouterCallback = new MediaRouteCallback(null);
  private boolean mToggleMode;
  
  public MediaRouteButton(Context paramContext)
  {
    this(paramContext, null);
  }
  
  public MediaRouteButton(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 16843693);
  }
  
  public MediaRouteButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.mRouter = ((MediaRouter)paramContext.getSystemService("media_router"));
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.MediaRouteButton, paramInt, 0);
    setRemoteIndicatorDrawable(localTypedArray.getDrawable(3));
    this.mMinWidth = localTypedArray.getDimensionPixelSize(0, 0);
    this.mMinHeight = localTypedArray.getDimensionPixelSize(1, 0);
    int i = localTypedArray.getInteger(2, 1);
    localTypedArray.recycle();
    setClickable(true);
    setLongClickable(true);
    setRouteTypes(i);
  }
  
  private Activity getActivity()
  {
    for (Context localContext = getContext(); ((localContext instanceof ContextWrapper)) && (!(localContext instanceof Activity)); localContext = ((ContextWrapper)localContext).getBaseContext()) {}
    if (!(localContext instanceof Activity)) {
      throw new IllegalStateException("The MediaRouteButton's Context is not an Activity.");
    }
    return (Activity)localContext;
  }
  
  private void setRemoteIndicatorDrawable(Drawable paramDrawable)
  {
    if (this.mRemoteIndicator != null)
    {
      this.mRemoteIndicator.setCallback(null);
      unscheduleDrawable(this.mRemoteIndicator);
    }
    this.mRemoteIndicator = paramDrawable;
    if (paramDrawable != null)
    {
      paramDrawable.setCallback(this);
      paramDrawable.setState(getDrawableState());
      if (getVisibility() != 0) {
        break label67;
      }
    }
    label67:
    for (boolean bool = true;; bool = false)
    {
      paramDrawable.setVisible(bool, false);
      refreshDrawableState();
      return;
    }
  }
  
  private void updateRouteInfo()
  {
    updateRemoteIndicator();
    updateRouteCount();
  }
  
  protected void drawableStateChanged()
  {
    super.drawableStateChanged();
    if (this.mRemoteIndicator != null)
    {
      int[] arrayOfInt = getDrawableState();
      this.mRemoteIndicator.setState(arrayOfInt);
      invalidate();
    }
  }
  
  public int getRouteTypes()
  {
    return this.mRouteTypes;
  }
  
  public void jumpDrawablesToCurrentState()
  {
    super.jumpDrawablesToCurrentState();
    if (this.mRemoteIndicator != null) {
      this.mRemoteIndicator.jumpToCurrentState();
    }
  }
  
  public void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    this.mAttachedToWindow = true;
    if (this.mRouteTypes != 0)
    {
      this.mRouter.addCallback(this.mRouteTypes, this.mRouterCallback);
      updateRouteInfo();
    }
  }
  
  protected int[] onCreateDrawableState(int paramInt)
  {
    int[] arrayOfInt = super.onCreateDrawableState(paramInt + 1);
    if (this.mIsConnecting) {
      mergeDrawableStates(arrayOfInt, CHECKED_STATE_SET);
    }
    while (!this.mRemoteActive) {
      return arrayOfInt;
    }
    mergeDrawableStates(arrayOfInt, ACTIVATED_STATE_SET);
    return arrayOfInt;
  }
  
  public void onDetachedFromWindow()
  {
    if (this.mRouteTypes != 0) {
      this.mRouter.removeCallback(this.mRouterCallback);
    }
    this.mAttachedToWindow = false;
    super.onDetachedFromWindow();
  }
  
  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    if (this.mRemoteIndicator == null) {
      return;
    }
    int i = getPaddingLeft();
    int j = getWidth() - getPaddingRight();
    int k = getPaddingTop();
    int m = getHeight() - getPaddingBottom();
    int n = this.mRemoteIndicator.getIntrinsicWidth();
    int i1 = this.mRemoteIndicator.getIntrinsicHeight();
    int i2 = i + (j - i - n) / 2;
    int i3 = k + (m - k - i1) / 2;
    this.mRemoteIndicator.setBounds(i2, i3, i2 + n, i3 + i1);
    this.mRemoteIndicator.draw(paramCanvas);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i = View.MeasureSpec.getSize(paramInt1);
    int j = View.MeasureSpec.getSize(paramInt2);
    int k = View.MeasureSpec.getMode(paramInt1);
    int m = View.MeasureSpec.getMode(paramInt2);
    int n = this.mMinWidth;
    int i1;
    int i2;
    int i5;
    int i6;
    label134:
    int i7;
    if (this.mRemoteIndicator != null)
    {
      i1 = this.mRemoteIndicator.getIntrinsicWidth();
      i2 = Math.max(n, i1);
      int i3 = this.mMinHeight;
      Drawable localDrawable = this.mRemoteIndicator;
      int i4 = 0;
      if (localDrawable != null) {
        i4 = this.mRemoteIndicator.getIntrinsicHeight();
      }
      i5 = Math.max(i3, i4);
      switch (k)
      {
      default: 
        i6 = i2 + getPaddingLeft() + getPaddingRight();
        switch (m)
        {
        default: 
          i7 = i5 + getPaddingTop() + getPaddingBottom();
        }
        break;
      }
    }
    for (;;)
    {
      setMeasuredDimension(i6, i7);
      return;
      i1 = 0;
      break;
      i6 = i;
      break label134;
      i6 = Math.min(i, i2 + getPaddingLeft() + getPaddingRight());
      break label134;
      i7 = j;
      continue;
      i7 = Math.min(j, i5 + getPaddingTop() + getPaddingBottom());
    }
  }
  
  public boolean performClick()
  {
    boolean bool = super.performClick();
    if (!bool) {
      playSoundEffect(0);
    }
    if (this.mToggleMode)
    {
      if (this.mRemoteActive) {
        this.mRouter.selectRouteInt(this.mRouteTypes, this.mRouter.getSystemAudioRoute());
      }
      for (;;)
      {
        return bool;
        int i = this.mRouter.getRouteCount();
        for (int j = 0; j < i; j++)
        {
          MediaRouter.RouteInfo localRouteInfo = this.mRouter.getRouteAt(j);
          if (((localRouteInfo.getSupportedTypes() & this.mRouteTypes) != 0) && (localRouteInfo != this.mRouter.getSystemAudioRoute())) {
            this.mRouter.selectRouteInt(this.mRouteTypes, localRouteInfo);
          }
        }
      }
    }
    showDialog();
    return bool;
  }
  
  public boolean performLongClick()
  {
    if (super.performLongClick()) {
      return true;
    }
    if (!this.mCheatSheetEnabled) {
      return false;
    }
    CharSequence localCharSequence = getContentDescription();
    if (TextUtils.isEmpty(localCharSequence)) {
      return false;
    }
    int[] arrayOfInt = new int[2];
    Rect localRect = new Rect();
    getLocationOnScreen(arrayOfInt);
    getWindowVisibleDisplayFrame(localRect);
    Context localContext = getContext();
    int i = getWidth();
    int j = getHeight();
    int k = arrayOfInt[1] + j / 2;
    int m = localContext.getResources().getDisplayMetrics().widthPixels;
    Toast localToast = Toast.makeText(localContext, localCharSequence, 0);
    if (k < localRect.height()) {
      localToast.setGravity(8388661, m - arrayOfInt[0] - i / 2, j);
    }
    for (;;)
    {
      localToast.show();
      performHapticFeedback(0);
      return true;
      localToast.setGravity(81, 0, j);
    }
  }
  
  void setCheatSheetEnabled(boolean paramBoolean)
  {
    this.mCheatSheetEnabled = paramBoolean;
  }
  
  public void setExtendedSettingsClickListener(View.OnClickListener paramOnClickListener)
  {
    this.mExtendedSettingsClickListener = paramOnClickListener;
    if (this.mDialogFragment != null) {
      this.mDialogFragment.setExtendedSettingsClickListener(paramOnClickListener);
    }
  }
  
  public void setRouteTypes(int paramInt)
  {
    if (paramInt == this.mRouteTypes) {}
    do
    {
      return;
      if ((this.mAttachedToWindow) && (this.mRouteTypes != 0)) {
        this.mRouter.removeCallback(this.mRouterCallback);
      }
      this.mRouteTypes = paramInt;
    } while (!this.mAttachedToWindow);
    updateRouteInfo();
    this.mRouter.addCallback(paramInt, this.mRouterCallback);
  }
  
  public void setVisibility(int paramInt)
  {
    super.setVisibility(paramInt);
    Drawable localDrawable;
    if (this.mRemoteIndicator != null)
    {
      localDrawable = this.mRemoteIndicator;
      if (getVisibility() != 0) {
        break label34;
      }
    }
    label34:
    for (boolean bool = true;; bool = false)
    {
      localDrawable.setVisible(bool, false);
      return;
    }
  }
  
  public void showDialog()
  {
    FragmentManager localFragmentManager = getActivity().getFragmentManager();
    if (this.mDialogFragment == null) {
      this.mDialogFragment = ((MediaRouteChooserDialogFragment)localFragmentManager.findFragmentByTag("android:MediaRouteChooserDialogFragment"));
    }
    if (this.mDialogFragment != null)
    {
      Log.w("MediaRouteButton", "showDialog(): Already showing!");
      return;
    }
    this.mDialogFragment = new MediaRouteChooserDialogFragment();
    this.mDialogFragment.setExtendedSettingsClickListener(this.mExtendedSettingsClickListener);
    this.mDialogFragment.setLauncherListener(new MediaRouteChooserDialogFragment.LauncherListener()
    {
      public void onDetached(MediaRouteChooserDialogFragment paramAnonymousMediaRouteChooserDialogFragment)
      {
        MediaRouteButton.access$102(MediaRouteButton.this, null);
      }
    });
    this.mDialogFragment.setRouteTypes(this.mRouteTypes);
    this.mDialogFragment.show(localFragmentManager, "android:MediaRouteChooserDialogFragment");
  }
  
  void updateRemoteIndicator()
  {
    MediaRouter.RouteInfo localRouteInfo = this.mRouter.getSelectedRoute(this.mRouteTypes);
    boolean bool1;
    if (localRouteInfo != this.mRouter.getSystemAudioRoute())
    {
      bool1 = true;
      if (localRouteInfo.getStatusCode() != 2) {
        break label89;
      }
    }
    label89:
    for (boolean bool2 = true;; bool2 = false)
    {
      boolean bool3 = this.mRemoteActive;
      int i = 0;
      if (bool3 != bool1)
      {
        this.mRemoteActive = bool1;
        i = 1;
      }
      if (this.mIsConnecting != bool2)
      {
        this.mIsConnecting = bool2;
        i = 1;
      }
      if (i != 0) {
        refreshDrawableState();
      }
      return;
      bool1 = false;
      break;
    }
  }
  
  void updateRouteCount()
  {
    boolean bool1 = true;
    int i = this.mRouter.getRouteCount();
    int j = 0;
    int k = 0;
    int m = 0;
    if (m < i)
    {
      MediaRouter.RouteInfo localRouteInfo = this.mRouter.getRouteAt(m);
      int n = localRouteInfo.getSupportedTypes();
      if ((n & this.mRouteTypes) != 0)
      {
        if (!(localRouteInfo instanceof MediaRouter.RouteGroup)) {
          break label87;
        }
        j += ((MediaRouter.RouteGroup)localRouteInfo).getRouteCount();
      }
      for (;;)
      {
        if ((n & 0x2) != 0) {
          k = 1;
        }
        m++;
        break;
        label87:
        j++;
      }
    }
    boolean bool2;
    if (j != 0)
    {
      bool2 = bool1;
      setEnabled(bool2);
      if ((j != 2) || ((0x1 & this.mRouteTypes) == 0) || (k != 0)) {
        break label137;
      }
    }
    for (;;)
    {
      this.mToggleMode = bool1;
      return;
      bool2 = false;
      break;
      label137:
      bool1 = false;
    }
  }
  
  protected boolean verifyDrawable(Drawable paramDrawable)
  {
    return (super.verifyDrawable(paramDrawable)) || (paramDrawable == this.mRemoteIndicator);
  }
  
  private class MediaRouteCallback
    extends MediaRouter.SimpleCallback
  {
    private MediaRouteCallback() {}
    
    public void onRouteAdded(MediaRouter paramMediaRouter, MediaRouter.RouteInfo paramRouteInfo)
    {
      MediaRouteButton.this.updateRouteCount();
    }
    
    public void onRouteChanged(MediaRouter paramMediaRouter, MediaRouter.RouteInfo paramRouteInfo)
    {
      MediaRouteButton.this.updateRemoteIndicator();
    }
    
    public void onRouteGrouped(MediaRouter paramMediaRouter, MediaRouter.RouteInfo paramRouteInfo, MediaRouter.RouteGroup paramRouteGroup, int paramInt)
    {
      MediaRouteButton.this.updateRouteCount();
    }
    
    public void onRouteRemoved(MediaRouter paramMediaRouter, MediaRouter.RouteInfo paramRouteInfo)
    {
      MediaRouteButton.this.updateRouteCount();
    }
    
    public void onRouteSelected(MediaRouter paramMediaRouter, int paramInt, MediaRouter.RouteInfo paramRouteInfo)
    {
      MediaRouteButton.this.updateRemoteIndicator();
    }
    
    public void onRouteUngrouped(MediaRouter paramMediaRouter, MediaRouter.RouteInfo paramRouteInfo, MediaRouter.RouteGroup paramRouteGroup)
    {
      MediaRouteButton.this.updateRouteCount();
    }
    
    public void onRouteUnselected(MediaRouter paramMediaRouter, int paramInt, MediaRouter.RouteInfo paramRouteInfo)
    {
      MediaRouteButton.this.updateRemoteIndicator();
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\MediaRouteButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
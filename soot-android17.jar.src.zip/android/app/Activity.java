package android.app;

import android.content.ComponentCallbacks2;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.IIntentSender;
import android.content.Intent;
import android.content.IntentSender;
import android.content.IntentSender.SendIntentException;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcelable;
import android.os.RemoteException;
import android.os.StrictMode;
import android.os.UserHandle;
import android.text.Selection;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.method.TextKeyListener;
import android.util.AttributeSet;
import android.util.EventLog;
import android.util.Log;
import android.util.SparseArray;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.KeyEvent.Callback;
import android.view.KeyEvent.DispatcherState;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory2;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewManager;
import android.view.Window;
import android.view.Window.Callback;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.view.WindowManagerGlobal;
import android.view.accessibility.AccessibilityEvent;
import com.android.internal.R.styleable;
import com.android.internal.app.ActionBarImpl;
import com.android.internal.policy.PolicyManager;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

public class Activity
  extends ContextThemeWrapper
  implements LayoutInflater.Factory2, Window.Callback, KeyEvent.Callback, View.OnCreateContextMenuListener, ComponentCallbacks2
{
  private static final boolean DEBUG_LIFECYCLE = false;
  public static final int DEFAULT_KEYS_DIALER = 1;
  public static final int DEFAULT_KEYS_DISABLE = 0;
  public static final int DEFAULT_KEYS_SEARCH_GLOBAL = 4;
  public static final int DEFAULT_KEYS_SEARCH_LOCAL = 3;
  public static final int DEFAULT_KEYS_SHORTCUT = 2;
  protected static final int[] FOCUSED_STATE_SET = { 16842908 };
  static final String FRAGMENTS_TAG = "android:fragments";
  public static final int RESULT_CANCELED = 0;
  public static final int RESULT_FIRST_USER = 1;
  public static final int RESULT_OK = -1;
  private static final String SAVED_DIALOGS_TAG = "android:savedDialogs";
  private static final String SAVED_DIALOG_ARGS_KEY_PREFIX = "android:dialog_args_";
  private static final String SAVED_DIALOG_IDS_KEY = "android:savedDialogIds";
  private static final String SAVED_DIALOG_KEY_PREFIX = "android:dialog_";
  private static final String TAG = "Activity";
  private static final String WINDOW_HIERARCHY_TAG = "android:viewHierarchyState";
  ActionBarImpl mActionBar = null;
  ActivityInfo mActivityInfo;
  HashMap<String, LoaderManagerImpl> mAllLoaderManagers;
  private Application mApplication;
  boolean mCalled;
  boolean mChangingConfigurations = false;
  boolean mCheckedForLoaderManager;
  private ComponentName mComponent;
  int mConfigChangeFlags;
  final FragmentContainer mContainer = new FragmentContainer()
  {
    public View findViewById(int paramAnonymousInt)
    {
      return Activity.this.findViewById(paramAnonymousInt);
    }
  };
  Configuration mCurrentConfig;
  View mDecor = null;
  private int mDefaultKeyMode = 0;
  private SpannableStringBuilder mDefaultKeySsb = null;
  private boolean mDestroyed;
  String mEmbeddedID;
  private boolean mEnableDefaultActionBarUp;
  boolean mFinished;
  final FragmentManagerImpl mFragments = new FragmentManagerImpl();
  final Handler mHandler = new Handler();
  private int mIdent;
  private final Object mInstanceTracker = StrictMode.trackActivity(this);
  private Instrumentation mInstrumentation;
  Intent mIntent;
  NonConfigurationInstances mLastNonConfigurationInstances;
  LoaderManagerImpl mLoaderManager;
  boolean mLoadersStarted;
  ActivityThread mMainThread;
  private final ArrayList<ManagedCursor> mManagedCursors = new ArrayList();
  private SparseArray<ManagedDialog> mManagedDialogs;
  private MenuInflater mMenuInflater;
  Activity mParent;
  int mResultCode = 0;
  Intent mResultData = null;
  boolean mResumed;
  private SearchManager mSearchManager;
  boolean mStartedActivity;
  private boolean mStopped;
  boolean mTemporaryPause = false;
  private CharSequence mTitle;
  private int mTitleColor = 0;
  private boolean mTitleReady = false;
  private IBinder mToken;
  private Thread mUiThread;
  boolean mVisibleFromClient = true;
  boolean mVisibleFromServer = false;
  private Window mWindow;
  boolean mWindowAdded = false;
  private WindowManager mWindowManager;
  
  private Dialog createDialog(Integer paramInteger, Bundle paramBundle1, Bundle paramBundle2)
  {
    Dialog localDialog = onCreateDialog(paramInteger.intValue(), paramBundle2);
    if (localDialog == null) {
      return null;
    }
    localDialog.dispatchOnCreate(paramBundle1);
    return localDialog;
  }
  
  private void dumpViewHierarchy(String paramString, PrintWriter paramPrintWriter, View paramView)
  {
    paramPrintWriter.print(paramString);
    if (paramView == null) {
      paramPrintWriter.println("null");
    }
    for (;;)
    {
      return;
      paramPrintWriter.println(paramView.toString());
      if ((paramView instanceof ViewGroup))
      {
        ViewGroup localViewGroup = (ViewGroup)paramView;
        int i = localViewGroup.getChildCount();
        if (i > 0)
        {
          String str = paramString + "  ";
          for (int j = 0; j < i; j++) {
            dumpViewHierarchy(str, paramPrintWriter, localViewGroup.getChildAt(j));
          }
        }
      }
    }
  }
  
  private void ensureSearchManager()
  {
    if (this.mSearchManager != null) {
      return;
    }
    this.mSearchManager = new SearchManager(this, null);
  }
  
  private void initActionBar()
  {
    Window localWindow = getWindow();
    localWindow.getDecorView();
    if ((isChild()) || (!localWindow.hasFeature(8)) || (this.mActionBar != null)) {
      return;
    }
    this.mActionBar = new ActionBarImpl(this);
    this.mActionBar.setDefaultDisplayHomeAsUpEnabled(this.mEnableDefaultActionBarUp);
  }
  
  private IllegalArgumentException missingDialog(int paramInt)
  {
    return new IllegalArgumentException("no dialog with id " + paramInt + " was ever " + "shown via Activity#showDialog");
  }
  
  private void restoreManagedDialogs(Bundle paramBundle)
  {
    Bundle localBundle1 = paramBundle.getBundle("android:savedDialogs");
    if (localBundle1 == null) {}
    for (;;)
    {
      return;
      int[] arrayOfInt = localBundle1.getIntArray("android:savedDialogIds");
      int i = arrayOfInt.length;
      this.mManagedDialogs = new SparseArray(i);
      for (int j = 0; j < i; j++)
      {
        Integer localInteger = Integer.valueOf(arrayOfInt[j]);
        Bundle localBundle2 = localBundle1.getBundle(savedDialogKeyFor(localInteger.intValue()));
        if (localBundle2 != null)
        {
          ManagedDialog localManagedDialog = new ManagedDialog(null);
          localManagedDialog.mArgs = localBundle1.getBundle(savedDialogArgsKeyFor(localInteger.intValue()));
          localManagedDialog.mDialog = createDialog(localInteger, localBundle2, localManagedDialog.mArgs);
          if (localManagedDialog.mDialog != null)
          {
            this.mManagedDialogs.put(localInteger.intValue(), localManagedDialog);
            onPrepareDialog(localInteger.intValue(), localManagedDialog.mDialog, localManagedDialog.mArgs);
            localManagedDialog.mDialog.onRestoreInstanceState(localBundle2);
          }
        }
      }
    }
  }
  
  private void saveManagedDialogs(Bundle paramBundle)
  {
    if (this.mManagedDialogs == null) {}
    int i;
    do
    {
      return;
      i = this.mManagedDialogs.size();
    } while (i == 0);
    Bundle localBundle = new Bundle();
    int[] arrayOfInt = new int[this.mManagedDialogs.size()];
    for (int j = 0; j < i; j++)
    {
      int k = this.mManagedDialogs.keyAt(j);
      arrayOfInt[j] = k;
      ManagedDialog localManagedDialog = (ManagedDialog)this.mManagedDialogs.valueAt(j);
      localBundle.putBundle(savedDialogKeyFor(k), localManagedDialog.mDialog.onSaveInstanceState());
      if (localManagedDialog.mArgs != null) {
        localBundle.putBundle(savedDialogArgsKeyFor(k), localManagedDialog.mArgs);
      }
    }
    localBundle.putIntArray("android:savedDialogIds", arrayOfInt);
    paramBundle.putBundle("android:savedDialogs", localBundle);
  }
  
  private static String savedDialogArgsKeyFor(int paramInt)
  {
    return "android:dialog_args_" + paramInt;
  }
  
  private static String savedDialogKeyFor(int paramInt)
  {
    return "android:dialog_" + paramInt;
  }
  
  private void startIntentSenderForResultInner(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, Activity paramActivity, Bundle paramBundle)
    throws IntentSender.SendIntentException
  {
    String str = null;
    if (paramIntent != null) {}
    int i;
    try
    {
      paramIntent.setAllowFds(false);
      str = paramIntent.resolveTypeIfNeeded(getContentResolver());
      i = ActivityManagerNative.getDefault().startActivityIntentSender(this.mMainThread.getApplicationThread(), paramIntentSender, paramIntent, str, this.mToken, paramActivity.mEmbeddedID, paramInt1, paramInt2, paramInt3, paramBundle);
      if (i == -6) {
        throw new IntentSender.SendIntentException();
      }
    }
    catch (RemoteException localRemoteException) {}
    for (;;)
    {
      if (paramInt1 >= 0) {
        this.mStartedActivity = true;
      }
      return;
      Instrumentation.checkStartActivityResult(i, null);
    }
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    getWindow().addContentView(paramView, paramLayoutParams);
    initActionBar();
  }
  
  final void attach(Context paramContext, ActivityThread paramActivityThread, Instrumentation paramInstrumentation, IBinder paramIBinder, int paramInt, Application paramApplication, Intent paramIntent, ActivityInfo paramActivityInfo, CharSequence paramCharSequence, Activity paramActivity, String paramString, NonConfigurationInstances paramNonConfigurationInstances, Configuration paramConfiguration)
  {
    attachBaseContext(paramContext);
    this.mFragments.attachActivity(this, this.mContainer, null);
    this.mWindow = PolicyManager.makeNewWindow(this);
    this.mWindow.setCallback(this);
    this.mWindow.getLayoutInflater().setPrivateFactory(this);
    if (paramActivityInfo.softInputMode != 0) {
      this.mWindow.setSoftInputMode(paramActivityInfo.softInputMode);
    }
    if (paramActivityInfo.uiOptions != 0) {
      this.mWindow.setUiOptions(paramActivityInfo.uiOptions);
    }
    this.mUiThread = Thread.currentThread();
    this.mMainThread = paramActivityThread;
    this.mInstrumentation = paramInstrumentation;
    this.mToken = paramIBinder;
    this.mIdent = paramInt;
    this.mApplication = paramApplication;
    this.mIntent = paramIntent;
    this.mComponent = paramIntent.getComponent();
    this.mActivityInfo = paramActivityInfo;
    this.mTitle = paramCharSequence;
    this.mParent = paramActivity;
    this.mEmbeddedID = paramString;
    this.mLastNonConfigurationInstances = paramNonConfigurationInstances;
    Window localWindow = this.mWindow;
    WindowManager localWindowManager = (WindowManager)paramContext.getSystemService("window");
    IBinder localIBinder = this.mToken;
    String str = this.mComponent.flattenToString();
    if ((0x200 & paramActivityInfo.flags) != 0) {}
    for (boolean bool = true;; bool = false)
    {
      localWindow.setWindowManager(localWindowManager, localIBinder, str, bool);
      if (this.mParent != null) {
        this.mWindow.setContainer(this.mParent.getWindow());
      }
      this.mWindowManager = this.mWindow.getWindowManager();
      this.mCurrentConfig = paramConfiguration;
      return;
    }
  }
  
  final void attach(Context paramContext, ActivityThread paramActivityThread, Instrumentation paramInstrumentation, IBinder paramIBinder, Application paramApplication, Intent paramIntent, ActivityInfo paramActivityInfo, CharSequence paramCharSequence, Activity paramActivity, String paramString, NonConfigurationInstances paramNonConfigurationInstances, Configuration paramConfiguration)
  {
    attach(paramContext, paramActivityThread, paramInstrumentation, paramIBinder, 0, paramApplication, paramIntent, paramActivityInfo, paramCharSequence, paramActivity, paramString, paramNonConfigurationInstances, paramConfiguration);
  }
  
  public void closeContextMenu()
  {
    this.mWindow.closePanel(6);
  }
  
  public void closeOptionsMenu()
  {
    this.mWindow.closePanel(0);
  }
  
  public PendingIntent createPendingResult(int paramInt1, Intent paramIntent, int paramInt2)
  {
    String str = getPackageName();
    try
    {
      paramIntent.setAllowFds(false);
      IActivityManager localIActivityManager = ActivityManagerNative.getDefault();
      if (this.mParent == null) {}
      for (IBinder localIBinder = this.mToken;; localIBinder = this.mParent.mToken)
      {
        IIntentSender localIIntentSender = localIActivityManager.getIntentSender(3, str, localIBinder, this.mEmbeddedID, paramInt1, new Intent[] { paramIntent }, null, paramInt2, null, UserHandle.myUserId());
        if (localIIntentSender == null) {
          break;
        }
        return new PendingIntent(localIIntentSender);
      }
      return null;
    }
    catch (RemoteException localRemoteException) {}
    return null;
  }
  
  @Deprecated
  public final void dismissDialog(int paramInt)
  {
    if (this.mManagedDialogs == null) {
      throw missingDialog(paramInt);
    }
    ManagedDialog localManagedDialog = (ManagedDialog)this.mManagedDialogs.get(paramInt);
    if (localManagedDialog == null) {
      throw missingDialog(paramInt);
    }
    localManagedDialog.mDialog.dismiss();
  }
  
  void dispatchActivityResult(String paramString, int paramInt1, int paramInt2, Intent paramIntent)
  {
    this.mFragments.noteStateNotSaved();
    if (paramString == null) {
      onActivityResult(paramInt1, paramInt2, paramIntent);
    }
    Fragment localFragment;
    do
    {
      return;
      localFragment = this.mFragments.findFragmentByWho(paramString);
    } while (localFragment == null);
    localFragment.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public boolean dispatchGenericMotionEvent(MotionEvent paramMotionEvent)
  {
    onUserInteraction();
    if (getWindow().superDispatchGenericMotionEvent(paramMotionEvent)) {
      return true;
    }
    return onGenericMotionEvent(paramMotionEvent);
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent)
  {
    onUserInteraction();
    Window localWindow = getWindow();
    if (localWindow.superDispatchKeyEvent(paramKeyEvent)) {
      return true;
    }
    View localView = this.mDecor;
    if (localView == null) {
      localView = localWindow.getDecorView();
    }
    if (localView != null) {}
    for (KeyEvent.DispatcherState localDispatcherState = localView.getKeyDispatcherState();; localDispatcherState = null) {
      return paramKeyEvent.dispatch(this, localDispatcherState, this);
    }
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent)
  {
    onUserInteraction();
    if (getWindow().superDispatchKeyShortcutEvent(paramKeyEvent)) {
      return true;
    }
    return onKeyShortcut(paramKeyEvent.getKeyCode(), paramKeyEvent);
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
  {
    paramAccessibilityEvent.setClassName(getClass().getName());
    paramAccessibilityEvent.setPackageName(getPackageName());
    WindowManager.LayoutParams localLayoutParams = getWindow().getAttributes();
    if ((localLayoutParams.width == -1) && (localLayoutParams.height == -1)) {}
    for (boolean bool = true;; bool = false)
    {
      paramAccessibilityEvent.setFullScreen(bool);
      CharSequence localCharSequence = getTitle();
      if (!TextUtils.isEmpty(localCharSequence)) {
        paramAccessibilityEvent.getText().add(localCharSequence);
      }
      return true;
    }
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent)
  {
    if (paramMotionEvent.getAction() == 0) {
      onUserInteraction();
    }
    if (getWindow().superDispatchTouchEvent(paramMotionEvent)) {
      return true;
    }
    return onTouchEvent(paramMotionEvent);
  }
  
  public boolean dispatchTrackballEvent(MotionEvent paramMotionEvent)
  {
    onUserInteraction();
    if (getWindow().superDispatchTrackballEvent(paramMotionEvent)) {
      return true;
    }
    return onTrackballEvent(paramMotionEvent);
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    dumpInner(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  void dumpInner(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("Local Activity ");
    paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
    paramPrintWriter.println(" State:");
    String str = paramString + "  ";
    paramPrintWriter.print(str);
    paramPrintWriter.print("mResumed=");
    paramPrintWriter.print(this.mResumed);
    paramPrintWriter.print(" mStopped=");
    paramPrintWriter.print(this.mStopped);
    paramPrintWriter.print(" mFinished=");
    paramPrintWriter.println(this.mFinished);
    paramPrintWriter.print(str);
    paramPrintWriter.print("mLoadersStarted=");
    paramPrintWriter.println(this.mLoadersStarted);
    paramPrintWriter.print(str);
    paramPrintWriter.print("mChangingConfigurations=");
    paramPrintWriter.println(this.mChangingConfigurations);
    paramPrintWriter.print(str);
    paramPrintWriter.print("mCurrentConfig=");
    paramPrintWriter.println(this.mCurrentConfig);
    if (this.mLoaderManager != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("Loader Manager ");
      paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this.mLoaderManager)));
      paramPrintWriter.println(":");
      this.mLoaderManager.dump(paramString + "  ", paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    }
    this.mFragments.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.println("View Hierarchy:");
    dumpViewHierarchy(paramString + "  ", paramPrintWriter, getWindow().getDecorView());
  }
  
  public View findViewById(int paramInt)
  {
    return getWindow().findViewById(paramInt);
  }
  
  /* Error */
  public void finish()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 518	android/app/Activity:mParent	Landroid/app/Activity;
    //   4: ifnonnull +54 -> 58
    //   7: aload_0
    //   8: monitorenter
    //   9: aload_0
    //   10: getfield 177	android/app/Activity:mResultCode	I
    //   13: istore_2
    //   14: aload_0
    //   15: getfield 179	android/app/Activity:mResultData	Landroid/content/Intent;
    //   18: astore_3
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_3
    //   22: ifnull +8 -> 30
    //   25: aload_3
    //   26: iconst_0
    //   27: invokevirtual 398	android/content/Intent:setAllowFds	(Z)V
    //   30: invokestatic 412	android/app/ActivityManagerNative:getDefault	()Landroid/app/IActivityManager;
    //   33: aload_0
    //   34: getfield 422	android/app/Activity:mToken	Landroid/os/IBinder;
    //   37: iload_2
    //   38: aload_3
    //   39: invokeinterface 786 4 0
    //   44: ifeq +8 -> 52
    //   47: aload_0
    //   48: iconst_1
    //   49: putfield 752	android/app/Activity:mFinished	Z
    //   52: return
    //   53: astore_1
    //   54: aload_0
    //   55: monitorexit
    //   56: aload_1
    //   57: athrow
    //   58: aload_0
    //   59: getfield 518	android/app/Activity:mParent	Landroid/app/Activity;
    //   62: aload_0
    //   63: invokevirtual 789	android/app/Activity:finishFromChild	(Landroid/app/Activity;)V
    //   66: return
    //   67: astore 4
    //   69: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	70	0	this	Activity
    //   53	4	1	localObject	Object
    //   13	25	2	i	int
    //   18	21	3	localIntent	Intent
    //   67	1	4	localRemoteException	RemoteException
    // Exception table:
    //   from	to	target	type
    //   9	21	53	finally
    //   54	56	53	finally
    //   25	30	67	android/os/RemoteException
    //   30	52	67	android/os/RemoteException
  }
  
  public void finishActivity(int paramInt)
  {
    if (this.mParent == null) {}
    try
    {
      ActivityManagerNative.getDefault().finishSubActivity(this.mToken, this.mEmbeddedID, paramInt);
      return;
    }
    catch (RemoteException localRemoteException) {}
    this.mParent.finishActivityFromChild(this, paramInt);
    return;
  }
  
  public void finishActivityFromChild(Activity paramActivity, int paramInt)
  {
    try
    {
      ActivityManagerNative.getDefault().finishSubActivity(this.mToken, paramActivity.mEmbeddedID, paramInt);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void finishAffinity()
  {
    if (this.mParent != null) {
      throw new IllegalStateException("Can not be called from an embedded activity");
    }
    if ((this.mResultCode != 0) || (this.mResultData != null)) {
      throw new IllegalStateException("Can not be called to deliver a result");
    }
    try
    {
      if (ActivityManagerNative.getDefault().finishActivityAffinity(this.mToken)) {
        this.mFinished = true;
      }
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void finishFromChild(Activity paramActivity)
  {
    finish();
  }
  
  public ActionBar getActionBar()
  {
    initActionBar();
    return this.mActionBar;
  }
  
  public final IBinder getActivityToken()
  {
    if (this.mParent != null) {
      return this.mParent.getActivityToken();
    }
    return this.mToken;
  }
  
  public final Application getApplication()
  {
    return this.mApplication;
  }
  
  public ComponentName getCallingActivity()
  {
    try
    {
      ComponentName localComponentName = ActivityManagerNative.getDefault().getCallingActivity(this.mToken);
      return localComponentName;
    }
    catch (RemoteException localRemoteException) {}
    return null;
  }
  
  public String getCallingPackage()
  {
    try
    {
      String str = ActivityManagerNative.getDefault().getCallingPackage(this.mToken);
      return str;
    }
    catch (RemoteException localRemoteException) {}
    return null;
  }
  
  public int getChangingConfigurations()
  {
    return this.mConfigChangeFlags;
  }
  
  public ComponentName getComponentName()
  {
    return this.mComponent;
  }
  
  public View getCurrentFocus()
  {
    if (this.mWindow != null) {
      return this.mWindow.getCurrentFocus();
    }
    return null;
  }
  
  public FragmentManager getFragmentManager()
  {
    return this.mFragments;
  }
  
  public Intent getIntent()
  {
    return this.mIntent;
  }
  
  HashMap<String, Object> getLastNonConfigurationChildInstances()
  {
    if (this.mLastNonConfigurationInstances != null) {
      return this.mLastNonConfigurationInstances.children;
    }
    return null;
  }
  
  @Deprecated
  public Object getLastNonConfigurationInstance()
  {
    if (this.mLastNonConfigurationInstances != null) {
      return this.mLastNonConfigurationInstances.activity;
    }
    return null;
  }
  
  public LayoutInflater getLayoutInflater()
  {
    return getWindow().getLayoutInflater();
  }
  
  public LoaderManager getLoaderManager()
  {
    if (this.mLoaderManager != null) {
      return this.mLoaderManager;
    }
    this.mCheckedForLoaderManager = true;
    this.mLoaderManager = getLoaderManager(null, this.mLoadersStarted, true);
    return this.mLoaderManager;
  }
  
  LoaderManagerImpl getLoaderManager(String paramString, boolean paramBoolean1, boolean paramBoolean2)
  {
    if (this.mAllLoaderManagers == null) {
      this.mAllLoaderManagers = new HashMap();
    }
    LoaderManagerImpl localLoaderManagerImpl = (LoaderManagerImpl)this.mAllLoaderManagers.get(paramString);
    if (localLoaderManagerImpl == null)
    {
      if (paramBoolean2)
      {
        localLoaderManagerImpl = new LoaderManagerImpl(paramString, this, paramBoolean1);
        this.mAllLoaderManagers.put(paramString, localLoaderManagerImpl);
      }
      return localLoaderManagerImpl;
    }
    localLoaderManagerImpl.updateActivity(this);
    return localLoaderManagerImpl;
  }
  
  public String getLocalClassName()
  {
    String str1 = getPackageName();
    String str2 = this.mComponent.getClassName();
    int i = str1.length();
    if ((!str2.startsWith(str1)) || (str2.length() <= i) || (str2.charAt(i) != '.')) {
      return str2;
    }
    return str2.substring(i + 1);
  }
  
  public MenuInflater getMenuInflater()
  {
    if (this.mMenuInflater == null)
    {
      initActionBar();
      if (this.mActionBar == null) {
        break label42;
      }
    }
    label42:
    for (this.mMenuInflater = new MenuInflater(this.mActionBar.getThemedContext(), this);; this.mMenuInflater = new MenuInflater(this)) {
      return this.mMenuInflater;
    }
  }
  
  public final Activity getParent()
  {
    return this.mParent;
  }
  
  public Intent getParentActivityIntent()
  {
    String str = this.mActivityInfo.parentActivityName;
    if (TextUtils.isEmpty(str)) {
      return null;
    }
    ComponentName localComponentName = new ComponentName(this, str);
    Object localObject;
    try
    {
      if (getPackageManager().getActivityInfo(localComponentName, 0).parentActivityName == null)
      {
        localObject = Intent.makeMainActivity(localComponentName);
      }
      else
      {
        Intent localIntent = new Intent().setComponent(localComponentName);
        localObject = localIntent;
      }
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      Log.e("Activity", "getParentActivityIntent: bad parentActivityName '" + str + "' in manifest");
      return null;
    }
    return (Intent)localObject;
  }
  
  public SharedPreferences getPreferences(int paramInt)
  {
    return getSharedPreferences(getLocalClassName(), paramInt);
  }
  
  public int getRequestedOrientation()
  {
    if (this.mParent == null) {}
    try
    {
      int i = ActivityManagerNative.getDefault().getRequestedOrientation(this.mToken);
      return i;
    }
    catch (RemoteException localRemoteException) {}
    return this.mParent.getRequestedOrientation();
    return -1;
  }
  
  public Object getSystemService(String paramString)
  {
    if (getBaseContext() == null) {
      throw new IllegalStateException("System services not available to Activities before onCreate()");
    }
    if ("window".equals(paramString)) {
      return this.mWindowManager;
    }
    if ("search".equals(paramString))
    {
      ensureSearchManager();
      return this.mSearchManager;
    }
    return super.getSystemService(paramString);
  }
  
  public int getTaskId()
  {
    try
    {
      int i = ActivityManagerNative.getDefault().getTaskForActivity(this.mToken, false);
      return i;
    }
    catch (RemoteException localRemoteException) {}
    return -1;
  }
  
  public final CharSequence getTitle()
  {
    return this.mTitle;
  }
  
  public final int getTitleColor()
  {
    return this.mTitleColor;
  }
  
  public final int getVolumeControlStream()
  {
    return getWindow().getVolumeControlStream();
  }
  
  public Window getWindow()
  {
    return this.mWindow;
  }
  
  public WindowManager getWindowManager()
  {
    return this.mWindowManager;
  }
  
  public boolean hasWindowFocus()
  {
    Window localWindow = getWindow();
    if (localWindow != null)
    {
      View localView = localWindow.getDecorView();
      if (localView != null) {
        return localView.hasWindowFocus();
      }
    }
    return false;
  }
  
  void invalidateFragment(String paramString)
  {
    if (this.mAllLoaderManagers != null)
    {
      LoaderManagerImpl localLoaderManagerImpl = (LoaderManagerImpl)this.mAllLoaderManagers.get(paramString);
      if ((localLoaderManagerImpl != null) && (!localLoaderManagerImpl.mRetaining))
      {
        localLoaderManagerImpl.doDestroy();
        this.mAllLoaderManagers.remove(paramString);
      }
    }
  }
  
  public void invalidateOptionsMenu()
  {
    this.mWindow.invalidatePanelMenu(0);
  }
  
  public boolean isChangingConfigurations()
  {
    return this.mChangingConfigurations;
  }
  
  public final boolean isChild()
  {
    return this.mParent != null;
  }
  
  public boolean isDestroyed()
  {
    return this.mDestroyed;
  }
  
  public boolean isFinishing()
  {
    return this.mFinished;
  }
  
  public boolean isImmersive()
  {
    try
    {
      boolean bool = ActivityManagerNative.getDefault().isImmersive(this.mToken);
      return bool;
    }
    catch (RemoteException localRemoteException) {}
    return false;
  }
  
  public final boolean isResumed()
  {
    return this.mResumed;
  }
  
  public boolean isTaskRoot()
  {
    try
    {
      int i = ActivityManagerNative.getDefault().getTaskForActivity(this.mToken, true);
      return i >= 0;
    }
    catch (RemoteException localRemoteException) {}
    return false;
  }
  
  void makeVisible()
  {
    if (!this.mWindowAdded)
    {
      getWindowManager().addView(this.mDecor, getWindow().getAttributes());
      this.mWindowAdded = true;
    }
    this.mDecor.setVisibility(0);
  }
  
  @Deprecated
  public final Cursor managedQuery(Uri paramUri, String[] paramArrayOfString, String paramString1, String paramString2)
  {
    Cursor localCursor = getContentResolver().query(paramUri, paramArrayOfString, paramString1, null, paramString2);
    if (localCursor != null) {
      startManagingCursor(localCursor);
    }
    return localCursor;
  }
  
  @Deprecated
  public final Cursor managedQuery(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    Cursor localCursor = getContentResolver().query(paramUri, paramArrayOfString1, paramString1, paramArrayOfString2, paramString2);
    if (localCursor != null) {
      startManagingCursor(localCursor);
    }
    return localCursor;
  }
  
  public boolean moveTaskToBack(boolean paramBoolean)
  {
    try
    {
      boolean bool = ActivityManagerNative.getDefault().moveActivityTaskToBack(this.mToken, paramBoolean);
      return bool;
    }
    catch (RemoteException localRemoteException) {}
    return false;
  }
  
  /* Error */
  public boolean navigateUpTo(Intent paramIntent)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 518	android/app/Activity:mParent	Landroid/app/Activity;
    //   4: ifnonnull +104 -> 108
    //   7: aload_1
    //   8: invokevirtual 510	android/content/Intent:getComponent	()Landroid/content/ComponentName;
    //   11: ifnonnull +41 -> 52
    //   14: aload_1
    //   15: aload_0
    //   16: invokevirtual 923	android/app/Activity:getPackageManager	()Landroid/content/pm/PackageManager;
    //   19: invokevirtual 1044	android/content/Intent:resolveActivity	(Landroid/content/pm/PackageManager;)Landroid/content/ComponentName;
    //   22: astore 7
    //   24: aload 7
    //   26: ifnonnull +5 -> 31
    //   29: iconst_0
    //   30: ireturn
    //   31: new 395	android/content/Intent
    //   34: dup
    //   35: aload_1
    //   36: invokespecial 1047	android/content/Intent:<init>	(Landroid/content/Intent;)V
    //   39: astore 8
    //   41: aload 8
    //   43: aload 7
    //   45: invokevirtual 937	android/content/Intent:setComponent	(Landroid/content/ComponentName;)Landroid/content/Intent;
    //   48: pop
    //   49: aload 8
    //   51: astore_1
    //   52: aload_0
    //   53: monitorenter
    //   54: aload_0
    //   55: getfield 177	android/app/Activity:mResultCode	I
    //   58: istore_3
    //   59: aload_0
    //   60: getfield 179	android/app/Activity:mResultData	Landroid/content/Intent;
    //   63: astore 4
    //   65: aload_0
    //   66: monitorexit
    //   67: aload 4
    //   69: ifnull +9 -> 78
    //   72: aload 4
    //   74: iconst_0
    //   75: invokevirtual 398	android/content/Intent:setAllowFds	(Z)V
    //   78: invokestatic 412	android/app/ActivityManagerNative:getDefault	()Landroid/app/IActivityManager;
    //   81: aload_0
    //   82: getfield 422	android/app/Activity:mToken	Landroid/os/IBinder;
    //   85: aload_1
    //   86: iload_3
    //   87: aload 4
    //   89: invokeinterface 1050 5 0
    //   94: istore 6
    //   96: iload 6
    //   98: ireturn
    //   99: astore_2
    //   100: aload_0
    //   101: monitorexit
    //   102: aload_2
    //   103: athrow
    //   104: astore 5
    //   106: iconst_0
    //   107: ireturn
    //   108: aload_0
    //   109: getfield 518	android/app/Activity:mParent	Landroid/app/Activity;
    //   112: aload_0
    //   113: aload_1
    //   114: invokevirtual 1054	android/app/Activity:navigateUpToFromChild	(Landroid/app/Activity;Landroid/content/Intent;)Z
    //   117: ireturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	118	0	this	Activity
    //   0	118	1	paramIntent	Intent
    //   99	4	2	localObject	Object
    //   58	29	3	i	int
    //   63	25	4	localIntent1	Intent
    //   104	1	5	localRemoteException	RemoteException
    //   94	3	6	bool	boolean
    //   22	22	7	localComponentName	ComponentName
    //   39	11	8	localIntent2	Intent
    // Exception table:
    //   from	to	target	type
    //   54	67	99	finally
    //   100	102	99	finally
    //   78	96	104	android/os/RemoteException
  }
  
  public boolean navigateUpToFromChild(Activity paramActivity, Intent paramIntent)
  {
    return navigateUpTo(paramIntent);
  }
  
  public void onActionModeFinished(ActionMode paramActionMode) {}
  
  public void onActionModeStarted(ActionMode paramActionMode) {}
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {}
  
  protected void onApplyThemeResource(Resources.Theme paramTheme, int paramInt, boolean paramBoolean)
  {
    if (this.mParent == null)
    {
      super.onApplyThemeResource(paramTheme, paramInt, paramBoolean);
      return;
    }
    try
    {
      paramTheme.setTo(this.mParent.getTheme());
      paramTheme.applyStyle(paramInt, false);
      return;
    }
    catch (Exception localException)
    {
      for (;;) {}
    }
  }
  
  public void onAttachFragment(Fragment paramFragment) {}
  
  public void onAttachedToWindow() {}
  
  public void onBackPressed()
  {
    if (!this.mFragments.popBackStackImmediate()) {
      finish();
    }
  }
  
  protected void onChildTitleChanged(Activity paramActivity, CharSequence paramCharSequence) {}
  
  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    this.mCalled = true;
    this.mFragments.dispatchConfigurationChanged(paramConfiguration);
    if (this.mWindow != null) {
      this.mWindow.onConfigurationChanged(paramConfiguration);
    }
    if (this.mActionBar != null) {
      this.mActionBar.onConfigurationChanged(paramConfiguration);
    }
  }
  
  public void onContentChanged() {}
  
  public boolean onContextItemSelected(MenuItem paramMenuItem)
  {
    if (this.mParent != null) {
      return this.mParent.onContextItemSelected(paramMenuItem);
    }
    return false;
  }
  
  public void onContextMenuClosed(Menu paramMenu)
  {
    if (this.mParent != null) {
      this.mParent.onContextMenuClosed(paramMenu);
    }
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    if (this.mLastNonConfigurationInstances != null) {
      this.mAllLoaderManagers = this.mLastNonConfigurationInstances.loaders;
    }
    Parcelable localParcelable;
    FragmentManagerImpl localFragmentManagerImpl;
    if (this.mActivityInfo.parentActivityName != null)
    {
      if (this.mActionBar == null) {
        this.mEnableDefaultActionBarUp = true;
      }
    }
    else if (paramBundle != null)
    {
      localParcelable = paramBundle.getParcelable("android:fragments");
      localFragmentManagerImpl = this.mFragments;
      if (this.mLastNonConfigurationInstances == null) {
        break label112;
      }
    }
    label112:
    for (ArrayList localArrayList = this.mLastNonConfigurationInstances.fragments;; localArrayList = null)
    {
      localFragmentManagerImpl.restoreAllState(localParcelable, localArrayList);
      this.mFragments.dispatchCreate();
      getApplication().dispatchActivityCreated(this, paramBundle);
      this.mCalled = true;
      return;
      this.mActionBar.setDefaultDisplayHomeAsUpEnabled(true);
      break;
    }
  }
  
  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo) {}
  
  public CharSequence onCreateDescription()
  {
    return null;
  }
  
  @Deprecated
  protected Dialog onCreateDialog(int paramInt)
  {
    return null;
  }
  
  @Deprecated
  protected Dialog onCreateDialog(int paramInt, Bundle paramBundle)
  {
    return onCreateDialog(paramInt);
  }
  
  public void onCreateNavigateUpTaskStack(TaskStackBuilder paramTaskStackBuilder)
  {
    paramTaskStackBuilder.addParentStack(this);
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    if (this.mParent != null) {
      return this.mParent.onCreateOptionsMenu(paramMenu);
    }
    return true;
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu)
  {
    if (paramInt == 0) {
      return onCreateOptionsMenu(paramMenu) | this.mFragments.dispatchCreateOptionsMenu(paramMenu, getMenuInflater());
    }
    return false;
  }
  
  public View onCreatePanelView(int paramInt)
  {
    return null;
  }
  
  public boolean onCreateThumbnail(Bitmap paramBitmap, Canvas paramCanvas)
  {
    return false;
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet)
  {
    if (!"fragment".equals(paramString)) {
      return onCreateView(paramString, paramContext, paramAttributeSet);
    }
    String str1 = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.Fragment);
    if (str1 == null) {
      str1 = localTypedArray.getString(0);
    }
    int i = localTypedArray.getResourceId(1, -1);
    String str2 = localTypedArray.getString(2);
    localTypedArray.recycle();
    int j = 0;
    if (paramView != null) {
      j = paramView.getId();
    }
    if ((j == -1) && (i == -1) && (str2 == null)) {
      throw new IllegalArgumentException(paramAttributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + str1);
    }
    Fragment localFragment = null;
    if (i != -1) {
      localFragment = this.mFragments.findFragmentById(i);
    }
    if ((localFragment == null) && (str2 != null)) {
      localFragment = this.mFragments.findFragmentByTag(str2);
    }
    if ((localFragment == null) && (j != -1)) {
      localFragment = this.mFragments.findFragmentById(j);
    }
    if (FragmentManagerImpl.DEBUG) {
      Log.v("Activity", "onCreateView: id=0x" + Integer.toHexString(i) + " fname=" + str1 + " existing=" + localFragment);
    }
    int k;
    if (localFragment == null)
    {
      localFragment = Fragment.instantiate(this, str1);
      localFragment.mFromLayout = true;
      if (i != 0)
      {
        k = i;
        localFragment.mFragmentId = k;
        localFragment.mContainerId = j;
        localFragment.mTag = str2;
        localFragment.mInLayout = true;
        localFragment.mFragmentManager = this.mFragments;
        localFragment.onInflate(this, paramAttributeSet, localFragment.mSavedFragmentState);
        this.mFragments.addFragment(localFragment, true);
      }
    }
    for (;;)
    {
      if (localFragment.mView != null) {
        break label530;
      }
      throw new IllegalStateException("Fragment " + str1 + " did not create a view.");
      k = j;
      break;
      if (localFragment.mInLayout) {
        throw new IllegalArgumentException(paramAttributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(i) + ", tag " + str2 + ", or parent id 0x" + Integer.toHexString(j) + " with another fragment for " + str1);
      }
      localFragment.mInLayout = true;
      if (!localFragment.mRetaining) {
        localFragment.onInflate(this, paramAttributeSet, localFragment.mSavedFragmentState);
      }
      this.mFragments.moveToState(localFragment);
    }
    label530:
    if (i != 0) {
      localFragment.mView.setId(i);
    }
    if (localFragment.mView.getTag() == null) {
      localFragment.mView.setTag(str2);
    }
    return localFragment.mView;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet)
  {
    return null;
  }
  
  protected void onDestroy()
  {
    this.mCalled = true;
    if (this.mManagedDialogs != null)
    {
      int k = this.mManagedDialogs.size();
      for (int m = 0; m < k; m++)
      {
        ManagedDialog localManagedDialog = (ManagedDialog)this.mManagedDialogs.valueAt(m);
        if (localManagedDialog.mDialog.isShowing()) {
          localManagedDialog.mDialog.dismiss();
        }
      }
      this.mManagedDialogs = null;
    }
    for (;;)
    {
      int j;
      synchronized (this.mManagedCursors)
      {
        int i = this.mManagedCursors.size();
        j = 0;
        if (j < i)
        {
          ManagedCursor localManagedCursor = (ManagedCursor)this.mManagedCursors.get(j);
          if (localManagedCursor != null) {
            localManagedCursor.mCursor.close();
          }
        }
        else
        {
          this.mManagedCursors.clear();
          if (this.mSearchManager != null) {
            this.mSearchManager.stopSearch();
          }
          getApplication().dispatchActivityDestroyed(this);
          return;
        }
      }
      j++;
    }
  }
  
  public void onDetachedFromWindow() {}
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent)
  {
    return false;
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    boolean bool;
    if (paramInt == 4) {
      if (getApplicationInfo().targetSdkVersion >= 5)
      {
        paramKeyEvent.startTracking();
        bool = true;
      }
    }
    for (;;)
    {
      return bool;
      onBackPressed();
      break;
      if (this.mDefaultKeyMode == 0) {
        return false;
      }
      if (this.mDefaultKeyMode == 2) {
        return getWindow().performPanelShortcut(0, paramInt, paramKeyEvent, 2);
      }
      int i;
      if ((paramKeyEvent.getRepeatCount() != 0) || (paramKeyEvent.isSystem()))
      {
        i = 1;
        bool = false;
      }
      while (i != 0)
      {
        this.mDefaultKeySsb.clear();
        this.mDefaultKeySsb.clearSpans();
        Selection.setSelection(this.mDefaultKeySsb, 0);
        return bool;
        bool = TextKeyListener.getInstance().onKeyDown(null, this.mDefaultKeySsb, paramInt, paramKeyEvent);
        i = 0;
        if (bool)
        {
          int j = this.mDefaultKeySsb.length();
          i = 0;
          if (j > 0)
          {
            String str = this.mDefaultKeySsb.toString();
            i = 1;
            switch (this.mDefaultKeyMode)
            {
            case 2: 
            default: 
              break;
            case 1: 
              Intent localIntent = new Intent("android.intent.action.DIAL", Uri.parse("tel:" + str));
              localIntent.addFlags(268435456);
              startActivity(localIntent);
              break;
            case 3: 
              startSearch(str, false, null, false);
              break;
            case 4: 
              startSearch(str, false, null, true);
            }
          }
        }
      }
    }
  }
  
  public boolean onKeyLongPress(int paramInt, KeyEvent paramKeyEvent)
  {
    return false;
  }
  
  public boolean onKeyMultiple(int paramInt1, int paramInt2, KeyEvent paramKeyEvent)
  {
    return false;
  }
  
  public boolean onKeyShortcut(int paramInt, KeyEvent paramKeyEvent)
  {
    return false;
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((getApplicationInfo().targetSdkVersion >= 5) && (paramInt == 4) && (paramKeyEvent.isTracking()) && (!paramKeyEvent.isCanceled()))
    {
      onBackPressed();
      return true;
    }
    return false;
  }
  
  public void onLowMemory()
  {
    this.mCalled = true;
    this.mFragments.dispatchLowMemory();
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem)
  {
    int i = 1;
    switch (paramInt)
    {
    default: 
      i = 0;
    }
    do
    {
      do
      {
        return i;
        Object[] arrayOfObject2 = new Object[2];
        arrayOfObject2[0] = Integer.valueOf(0);
        arrayOfObject2[i] = paramMenuItem.getTitleCondensed();
        EventLog.writeEvent(50000, arrayOfObject2);
      } while ((onOptionsItemSelected(paramMenuItem)) || (this.mFragments.dispatchOptionsItemSelected(paramMenuItem)));
      if ((paramMenuItem.getItemId() == 16908332) && (this.mActionBar != null) && ((0x4 & this.mActionBar.getDisplayOptions()) != 0))
      {
        if (this.mParent == null) {
          return onNavigateUp();
        }
        return this.mParent.onNavigateUpFromChild(this);
      }
      return false;
      Object[] arrayOfObject1 = new Object[2];
      arrayOfObject1[0] = Integer.valueOf(i);
      arrayOfObject1[i] = paramMenuItem.getTitleCondensed();
      EventLog.writeEvent(50000, arrayOfObject1);
    } while (onContextItemSelected(paramMenuItem));
    return this.mFragments.dispatchContextItemSelected(paramMenuItem);
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu)
  {
    if (paramInt == 8)
    {
      initActionBar();
      if (this.mActionBar != null) {
        this.mActionBar.dispatchMenuVisibilityChanged(true);
      }
    }
    else
    {
      return true;
    }
    Log.e("Activity", "Tried to open action bar menu with no action bar");
    return true;
  }
  
  public boolean onNavigateUp()
  {
    Intent localIntent = getParentActivityIntent();
    if (localIntent != null)
    {
      if (this.mActivityInfo.taskAffinity == null) {
        finish();
      }
      for (;;)
      {
        return true;
        if (shouldUpRecreateTask(localIntent))
        {
          TaskStackBuilder localTaskStackBuilder = TaskStackBuilder.create(this);
          onCreateNavigateUpTaskStack(localTaskStackBuilder);
          onPrepareNavigateUpTaskStack(localTaskStackBuilder);
          localTaskStackBuilder.startActivities();
          if ((this.mResultCode != 0) || (this.mResultData != null))
          {
            Log.i("Activity", "onNavigateUp only finishing topmost activity to return a result");
            finish();
          }
          else
          {
            finishAffinity();
          }
        }
        else
        {
          navigateUpTo(localIntent);
        }
      }
    }
    return false;
  }
  
  public boolean onNavigateUpFromChild(Activity paramActivity)
  {
    return onNavigateUp();
  }
  
  protected void onNewIntent(Intent paramIntent) {}
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    if (this.mParent != null) {
      return this.mParent.onOptionsItemSelected(paramMenuItem);
    }
    return false;
  }
  
  public void onOptionsMenuClosed(Menu paramMenu)
  {
    if (this.mParent != null) {
      this.mParent.onOptionsMenuClosed(paramMenu);
    }
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu)
  {
    switch (paramInt)
    {
    default: 
      return;
    case 0: 
      this.mFragments.dispatchOptionsMenuClosed(paramMenu);
      onOptionsMenuClosed(paramMenu);
      return;
    case 6: 
      onContextMenuClosed(paramMenu);
      return;
    }
    initActionBar();
    this.mActionBar.dispatchMenuVisibilityChanged(false);
  }
  
  protected void onPause()
  {
    getApplication().dispatchActivityPaused(this);
    this.mCalled = true;
  }
  
  protected void onPostCreate(Bundle paramBundle)
  {
    if (!isChild())
    {
      this.mTitleReady = true;
      onTitleChanged(getTitle(), getTitleColor());
    }
    this.mCalled = true;
  }
  
  protected void onPostResume()
  {
    Window localWindow = getWindow();
    if (localWindow != null) {
      localWindow.makeActive();
    }
    if (this.mActionBar != null) {
      this.mActionBar.setShowHideAnimationEnabled(true);
    }
    this.mCalled = true;
  }
  
  @Deprecated
  protected void onPrepareDialog(int paramInt, Dialog paramDialog)
  {
    paramDialog.setOwnerActivity(this);
  }
  
  @Deprecated
  protected void onPrepareDialog(int paramInt, Dialog paramDialog, Bundle paramBundle)
  {
    onPrepareDialog(paramInt, paramDialog);
  }
  
  public void onPrepareNavigateUpTaskStack(TaskStackBuilder paramTaskStackBuilder) {}
  
  public boolean onPrepareOptionsMenu(Menu paramMenu)
  {
    if (this.mParent != null) {
      return this.mParent.onPrepareOptionsMenu(paramMenu);
    }
    return true;
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu)
  {
    if ((paramInt == 0) && (paramMenu != null)) {
      return onPrepareOptionsMenu(paramMenu) | this.mFragments.dispatchPrepareOptionsMenu(paramMenu);
    }
    return true;
  }
  
  protected void onRestart()
  {
    this.mCalled = true;
  }
  
  protected void onRestoreInstanceState(Bundle paramBundle)
  {
    if (this.mWindow != null)
    {
      Bundle localBundle = paramBundle.getBundle("android:viewHierarchyState");
      if (localBundle != null) {
        this.mWindow.restoreHierarchyState(localBundle);
      }
    }
  }
  
  protected void onResume()
  {
    getApplication().dispatchActivityResumed(this);
    this.mCalled = true;
  }
  
  HashMap<String, Object> onRetainNonConfigurationChildInstances()
  {
    return null;
  }
  
  public Object onRetainNonConfigurationInstance()
  {
    return null;
  }
  
  protected void onSaveInstanceState(Bundle paramBundle)
  {
    paramBundle.putBundle("android:viewHierarchyState", this.mWindow.saveHierarchyState());
    Parcelable localParcelable = this.mFragments.saveAllState();
    if (localParcelable != null) {
      paramBundle.putParcelable("android:fragments", localParcelable);
    }
    getApplication().dispatchActivitySaveInstanceState(this, paramBundle);
  }
  
  public boolean onSearchRequested()
  {
    startSearch(null, false, null, false);
    return true;
  }
  
  protected void onStart()
  {
    this.mCalled = true;
    if (!this.mLoadersStarted)
    {
      this.mLoadersStarted = true;
      if (this.mLoaderManager == null) {
        break label45;
      }
      this.mLoaderManager.doStart();
    }
    for (;;)
    {
      this.mCheckedForLoaderManager = true;
      getApplication().dispatchActivityStarted(this);
      return;
      label45:
      if (!this.mCheckedForLoaderManager) {
        this.mLoaderManager = getLoaderManager(null, this.mLoadersStarted, false);
      }
    }
  }
  
  protected void onStop()
  {
    if (this.mActionBar != null) {
      this.mActionBar.setShowHideAnimationEnabled(false);
    }
    getApplication().dispatchActivityStopped(this);
    this.mCalled = true;
  }
  
  protected void onTitleChanged(CharSequence paramCharSequence, int paramInt)
  {
    if (this.mTitleReady)
    {
      Window localWindow = getWindow();
      if (localWindow != null)
      {
        localWindow.setTitle(paramCharSequence);
        if (paramInt != 0) {
          localWindow.setTitleColor(paramInt);
        }
      }
    }
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    if (this.mWindow.shouldCloseOnTouch(this, paramMotionEvent))
    {
      finish();
      return true;
    }
    return false;
  }
  
  public boolean onTrackballEvent(MotionEvent paramMotionEvent)
  {
    return false;
  }
  
  public void onTrimMemory(int paramInt)
  {
    this.mCalled = true;
    this.mFragments.dispatchTrimMemory(paramInt);
  }
  
  public void onUserInteraction() {}
  
  protected void onUserLeaveHint() {}
  
  public void onWindowAttributesChanged(WindowManager.LayoutParams paramLayoutParams)
  {
    if (this.mParent == null)
    {
      View localView = this.mDecor;
      if ((localView != null) && (localView.getParent() != null)) {
        getWindowManager().updateViewLayout(localView, paramLayoutParams);
      }
    }
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {}
  
  public ActionMode onWindowStartingActionMode(ActionMode.Callback paramCallback)
  {
    initActionBar();
    if (this.mActionBar != null) {
      return this.mActionBar.startActionMode(paramCallback);
    }
    return null;
  }
  
  public void openContextMenu(View paramView)
  {
    paramView.showContextMenu();
  }
  
  public void openOptionsMenu()
  {
    this.mWindow.openPanel(0, null);
  }
  
  public void overridePendingTransition(int paramInt1, int paramInt2)
  {
    try
    {
      ActivityManagerNative.getDefault().overridePendingTransition(this.mToken, getPackageName(), paramInt1, paramInt2);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  final void performCreate(Bundle paramBundle)
  {
    onCreate(paramBundle);
    boolean bool1 = this.mWindow.getWindowStyle().getBoolean(10, false);
    boolean bool2 = false;
    if (!bool1) {
      bool2 = true;
    }
    this.mVisibleFromClient = bool2;
    this.mFragments.dispatchActivityCreated();
  }
  
  final void performDestroy()
  {
    this.mDestroyed = true;
    this.mWindow.destroy();
    this.mFragments.dispatchDestroy();
    onDestroy();
    if (this.mLoaderManager != null) {
      this.mLoaderManager.doDestroy();
    }
  }
  
  final void performPause()
  {
    this.mFragments.dispatchPause();
    this.mCalled = false;
    onPause();
    this.mResumed = false;
    if ((!this.mCalled) && (getApplicationInfo().targetSdkVersion >= 9)) {
      throw new SuperNotCalledException("Activity " + this.mComponent.toShortString() + " did not call through to super.onPause()");
    }
    this.mResumed = false;
  }
  
  final void performRestart()
  {
    this.mFragments.noteStateNotSaved();
    if (this.mStopped)
    {
      this.mStopped = false;
      if ((this.mToken != null) && (this.mParent == null)) {
        WindowManagerGlobal.getInstance().setStoppedState(this.mToken, false);
      }
    }
    for (;;)
    {
      int j;
      ManagedCursor localManagedCursor;
      synchronized (this.mManagedCursors)
      {
        int i = this.mManagedCursors.size();
        j = 0;
        if (j >= i) {
          break label177;
        }
        localManagedCursor = (ManagedCursor)this.mManagedCursors.get(j);
        if ((!localManagedCursor.mReleased) && (!localManagedCursor.mUpdated)) {
          break label244;
        }
        if ((!localManagedCursor.mCursor.requery()) && (getApplicationInfo().targetSdkVersion >= 14)) {
          throw new IllegalStateException("trying to requery an already closed cursor  " + localManagedCursor.mCursor);
        }
      }
      ManagedCursor.access$202(localManagedCursor, false);
      ManagedCursor.access$302(localManagedCursor, false);
      break label244;
      label177:
      this.mCalled = false;
      this.mInstrumentation.callActivityOnRestart(this);
      if (!this.mCalled) {
        throw new SuperNotCalledException("Activity " + this.mComponent.toShortString() + " did not call through to super.onRestart()");
      }
      performStart();
      return;
      label244:
      j++;
    }
  }
  
  final void performRestoreInstanceState(Bundle paramBundle)
  {
    onRestoreInstanceState(paramBundle);
    restoreManagedDialogs(paramBundle);
  }
  
  final void performResume()
  {
    performRestart();
    this.mFragments.execPendingActions();
    this.mLastNonConfigurationInstances = null;
    this.mCalled = false;
    this.mInstrumentation.callActivityOnResume(this);
    if (!this.mCalled) {
      throw new SuperNotCalledException("Activity " + this.mComponent.toShortString() + " did not call through to super.onResume()");
    }
    this.mCalled = false;
    this.mFragments.dispatchResume();
    this.mFragments.execPendingActions();
    onPostResume();
    if (!this.mCalled) {
      throw new SuperNotCalledException("Activity " + this.mComponent.toShortString() + " did not call through to super.onPostResume()");
    }
  }
  
  final void performSaveInstanceState(Bundle paramBundle)
  {
    onSaveInstanceState(paramBundle);
    saveManagedDialogs(paramBundle);
  }
  
  final void performStart()
  {
    this.mFragments.noteStateNotSaved();
    this.mCalled = false;
    this.mFragments.execPendingActions();
    this.mInstrumentation.callActivityOnStart(this);
    if (!this.mCalled) {
      throw new SuperNotCalledException("Activity " + this.mComponent.toShortString() + " did not call through to super.onStart()");
    }
    this.mFragments.dispatchStart();
    if (this.mAllLoaderManagers != null)
    {
      LoaderManagerImpl[] arrayOfLoaderManagerImpl = new LoaderManagerImpl[this.mAllLoaderManagers.size()];
      this.mAllLoaderManagers.values().toArray(arrayOfLoaderManagerImpl);
      if (arrayOfLoaderManagerImpl != null) {
        for (int i = 0; i < arrayOfLoaderManagerImpl.length; i++)
        {
          LoaderManagerImpl localLoaderManagerImpl = arrayOfLoaderManagerImpl[i];
          localLoaderManagerImpl.finishRetain();
          localLoaderManagerImpl.doReportStart();
        }
      }
    }
  }
  
  final void performStop()
  {
    if (this.mLoadersStarted)
    {
      this.mLoadersStarted = false;
      if (this.mLoaderManager != null)
      {
        if (this.mChangingConfigurations) {
          break label146;
        }
        this.mLoaderManager.doStop();
      }
    }
    for (;;)
    {
      if (this.mStopped) {
        break label229;
      }
      if (this.mWindow != null) {
        this.mWindow.closeAllPanels();
      }
      if ((this.mToken != null) && (this.mParent == null)) {
        WindowManagerGlobal.getInstance().setStoppedState(this.mToken, true);
      }
      this.mFragments.dispatchStop();
      this.mCalled = false;
      this.mInstrumentation.callActivityOnStop(this);
      if (this.mCalled) {
        break;
      }
      throw new SuperNotCalledException("Activity " + this.mComponent.toShortString() + " did not call through to super.onStop()");
      label146:
      this.mLoaderManager.doRetain();
    }
    for (;;)
    {
      int j;
      synchronized (this.mManagedCursors)
      {
        int i = this.mManagedCursors.size();
        j = 0;
        if (j < i)
        {
          ManagedCursor localManagedCursor = (ManagedCursor)this.mManagedCursors.get(j);
          if (!localManagedCursor.mReleased)
          {
            localManagedCursor.mCursor.deactivate();
            ManagedCursor.access$202(localManagedCursor, true);
          }
        }
        else
        {
          this.mStopped = true;
          label229:
          this.mResumed = false;
          return;
        }
      }
      j++;
    }
  }
  
  final void performUserLeaving()
  {
    onUserInteraction();
    onUserLeaveHint();
  }
  
  public void recreate()
  {
    if (this.mParent != null) {
      throw new IllegalStateException("Can only be called on top-level activity");
    }
    if (Looper.myLooper() != this.mMainThread.getLooper()) {
      throw new IllegalStateException("Must be called from main thread");
    }
    this.mMainThread.requestRelaunchActivity(this.mToken, null, null, 0, false, null, false);
  }
  
  public void registerForContextMenu(View paramView)
  {
    paramView.setOnCreateContextMenuListener(this);
  }
  
  @Deprecated
  public final void removeDialog(int paramInt)
  {
    if (this.mManagedDialogs != null)
    {
      ManagedDialog localManagedDialog = (ManagedDialog)this.mManagedDialogs.get(paramInt);
      if (localManagedDialog != null)
      {
        localManagedDialog.mDialog.dismiss();
        this.mManagedDialogs.remove(paramInt);
      }
    }
  }
  
  public final boolean requestWindowFeature(int paramInt)
  {
    return getWindow().requestFeature(paramInt);
  }
  
  NonConfigurationInstances retainNonConfigurationInstances()
  {
    Object localObject = onRetainNonConfigurationInstance();
    HashMap localHashMap1 = onRetainNonConfigurationChildInstances();
    ArrayList localArrayList = this.mFragments.retainNonConfig();
    HashMap localHashMap2 = this.mAllLoaderManagers;
    int i = 0;
    if (localHashMap2 != null)
    {
      LoaderManagerImpl[] arrayOfLoaderManagerImpl = new LoaderManagerImpl[this.mAllLoaderManagers.size()];
      this.mAllLoaderManagers.values().toArray(arrayOfLoaderManagerImpl);
      i = 0;
      if (arrayOfLoaderManagerImpl != null)
      {
        int j = 0;
        if (j < arrayOfLoaderManagerImpl.length)
        {
          LoaderManagerImpl localLoaderManagerImpl = arrayOfLoaderManagerImpl[j];
          if (localLoaderManagerImpl.mRetaining) {
            i = 1;
          }
          for (;;)
          {
            j++;
            break;
            localLoaderManagerImpl.doDestroy();
            this.mAllLoaderManagers.remove(localLoaderManagerImpl.mWho);
          }
        }
      }
    }
    if ((localObject == null) && (localHashMap1 == null) && (localArrayList == null) && (i == 0)) {
      return null;
    }
    NonConfigurationInstances localNonConfigurationInstances = new NonConfigurationInstances();
    localNonConfigurationInstances.activity = localObject;
    localNonConfigurationInstances.children = localHashMap1;
    localNonConfigurationInstances.fragments = localArrayList;
    localNonConfigurationInstances.loaders = this.mAllLoaderManagers;
    return localNonConfigurationInstances;
  }
  
  public final void runOnUiThread(Runnable paramRunnable)
  {
    if (Thread.currentThread() != this.mUiThread)
    {
      this.mHandler.post(paramRunnable);
      return;
    }
    paramRunnable.run();
  }
  
  public void setContentView(int paramInt)
  {
    getWindow().setContentView(paramInt);
    initActionBar();
  }
  
  public void setContentView(View paramView)
  {
    getWindow().setContentView(paramView);
    initActionBar();
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    getWindow().setContentView(paramView, paramLayoutParams);
    initActionBar();
  }
  
  public final void setDefaultKeyMode(int paramInt)
  {
    this.mDefaultKeyMode = paramInt;
    switch (paramInt)
    {
    default: 
      throw new IllegalArgumentException();
    case 0: 
    case 2: 
      this.mDefaultKeySsb = null;
      return;
    }
    this.mDefaultKeySsb = new SpannableStringBuilder();
    Selection.setSelection(this.mDefaultKeySsb, 0);
  }
  
  public final void setFeatureDrawable(int paramInt, Drawable paramDrawable)
  {
    getWindow().setFeatureDrawable(paramInt, paramDrawable);
  }
  
  public final void setFeatureDrawableAlpha(int paramInt1, int paramInt2)
  {
    getWindow().setFeatureDrawableAlpha(paramInt1, paramInt2);
  }
  
  public final void setFeatureDrawableResource(int paramInt1, int paramInt2)
  {
    getWindow().setFeatureDrawableResource(paramInt1, paramInt2);
  }
  
  public final void setFeatureDrawableUri(int paramInt, Uri paramUri)
  {
    getWindow().setFeatureDrawableUri(paramInt, paramUri);
  }
  
  public void setFinishOnTouchOutside(boolean paramBoolean)
  {
    this.mWindow.setCloseOnTouchOutside(paramBoolean);
  }
  
  public void setImmersive(boolean paramBoolean)
  {
    try
    {
      ActivityManagerNative.getDefault().setImmersive(this.mToken, paramBoolean);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void setIntent(Intent paramIntent)
  {
    this.mIntent = paramIntent;
  }
  
  final void setParent(Activity paramActivity)
  {
    this.mParent = paramActivity;
  }
  
  @Deprecated
  public void setPersistent(boolean paramBoolean) {}
  
  public final void setProgress(int paramInt)
  {
    getWindow().setFeatureInt(2, paramInt + 0);
  }
  
  public final void setProgressBarIndeterminate(boolean paramBoolean)
  {
    Window localWindow = getWindow();
    if (paramBoolean) {}
    for (int i = -3;; i = -4)
    {
      localWindow.setFeatureInt(2, i);
      return;
    }
  }
  
  public final void setProgressBarIndeterminateVisibility(boolean paramBoolean)
  {
    Window localWindow = getWindow();
    if (paramBoolean) {}
    for (int i = -1;; i = -2)
    {
      localWindow.setFeatureInt(5, i);
      return;
    }
  }
  
  public final void setProgressBarVisibility(boolean paramBoolean)
  {
    Window localWindow = getWindow();
    if (paramBoolean) {}
    for (int i = -1;; i = -2)
    {
      localWindow.setFeatureInt(2, i);
      return;
    }
  }
  
  public void setRequestedOrientation(int paramInt)
  {
    if (this.mParent == null) {}
    try
    {
      ActivityManagerNative.getDefault().setRequestedOrientation(this.mToken, paramInt);
      return;
    }
    catch (RemoteException localRemoteException) {}
    this.mParent.setRequestedOrientation(paramInt);
    return;
  }
  
  public final void setResult(int paramInt)
  {
    try
    {
      this.mResultCode = paramInt;
      this.mResultData = null;
      return;
    }
    finally {}
  }
  
  public final void setResult(int paramInt, Intent paramIntent)
  {
    try
    {
      this.mResultCode = paramInt;
      this.mResultData = paramIntent;
      return;
    }
    finally {}
  }
  
  public final void setSecondaryProgress(int paramInt)
  {
    getWindow().setFeatureInt(2, paramInt + 20000);
  }
  
  public void setTitle(int paramInt)
  {
    setTitle(getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence)
  {
    this.mTitle = paramCharSequence;
    onTitleChanged(paramCharSequence, this.mTitleColor);
    if (this.mParent != null) {
      this.mParent.onChildTitleChanged(this, paramCharSequence);
    }
  }
  
  public void setTitleColor(int paramInt)
  {
    this.mTitleColor = paramInt;
    onTitleChanged(this.mTitle, paramInt);
  }
  
  public void setVisible(boolean paramBoolean)
  {
    if (this.mVisibleFromClient != paramBoolean)
    {
      this.mVisibleFromClient = paramBoolean;
      if (this.mVisibleFromServer)
      {
        if (!paramBoolean) {
          break label29;
        }
        makeVisible();
      }
    }
    return;
    label29:
    this.mDecor.setVisibility(4);
  }
  
  public final void setVolumeControlStream(int paramInt)
  {
    getWindow().setVolumeControlStream(paramInt);
  }
  
  public boolean shouldUpRecreateTask(Intent paramIntent)
  {
    try
    {
      PackageManager localPackageManager = getPackageManager();
      ComponentName localComponentName = paramIntent.getComponent();
      if (localComponentName == null) {
        localComponentName = paramIntent.resolveActivity(localPackageManager);
      }
      ActivityInfo localActivityInfo = localPackageManager.getActivityInfo(localComponentName, 0);
      if (localActivityInfo.taskAffinity == null) {
        return false;
      }
      boolean bool = ActivityManagerNative.getDefault().targetTaskAffinityMatchesActivity(this.mToken, localActivityInfo.taskAffinity);
      if (!bool) {
        return true;
      }
    }
    catch (RemoteException localRemoteException)
    {
      return false;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException) {}
    return false;
  }
  
  @Deprecated
  public final void showDialog(int paramInt)
  {
    showDialog(paramInt, null);
  }
  
  @Deprecated
  public final boolean showDialog(int paramInt, Bundle paramBundle)
  {
    if (this.mManagedDialogs == null) {
      this.mManagedDialogs = new SparseArray();
    }
    ManagedDialog localManagedDialog = (ManagedDialog)this.mManagedDialogs.get(paramInt);
    if (localManagedDialog == null)
    {
      localManagedDialog = new ManagedDialog(null);
      localManagedDialog.mDialog = createDialog(Integer.valueOf(paramInt), null, paramBundle);
      if (localManagedDialog.mDialog == null) {
        return false;
      }
      this.mManagedDialogs.put(paramInt, localManagedDialog);
    }
    localManagedDialog.mArgs = paramBundle;
    onPrepareDialog(paramInt, localManagedDialog.mDialog, paramBundle);
    localManagedDialog.mDialog.show();
    return true;
  }
  
  public ActionMode startActionMode(ActionMode.Callback paramCallback)
  {
    return this.mWindow.getDecorView().startActionMode(paramCallback);
  }
  
  public void startActivities(Intent[] paramArrayOfIntent)
  {
    startActivities(paramArrayOfIntent, null);
  }
  
  public void startActivities(Intent[] paramArrayOfIntent, Bundle paramBundle)
  {
    this.mInstrumentation.execStartActivities(this, this.mMainThread.getApplicationThread(), this.mToken, this, paramArrayOfIntent, paramBundle);
  }
  
  public void startActivity(Intent paramIntent)
  {
    startActivity(paramIntent, null);
  }
  
  public void startActivity(Intent paramIntent, Bundle paramBundle)
  {
    if (paramBundle != null)
    {
      startActivityForResult(paramIntent, -1, paramBundle);
      return;
    }
    startActivityForResult(paramIntent, -1);
  }
  
  public void startActivityAsUser(Intent paramIntent, Bundle paramBundle, UserHandle paramUserHandle)
  {
    if (this.mParent != null) {
      throw new RuntimeException("Called be called from a child");
    }
    Instrumentation.ActivityResult localActivityResult = this.mInstrumentation.execStartActivity(this, this.mMainThread.getApplicationThread(), this.mToken, this, paramIntent, -1, paramBundle, paramUserHandle);
    if (localActivityResult != null) {
      this.mMainThread.sendActivityResult(this.mToken, this.mEmbeddedID, -1, localActivityResult.getResultCode(), localActivityResult.getResultData());
    }
  }
  
  public void startActivityAsUser(Intent paramIntent, UserHandle paramUserHandle)
  {
    startActivityAsUser(paramIntent, null, paramUserHandle);
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt)
  {
    startActivityForResult(paramIntent, paramInt, null);
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt, Bundle paramBundle)
  {
    if (this.mParent == null)
    {
      Instrumentation.ActivityResult localActivityResult = this.mInstrumentation.execStartActivity(this, this.mMainThread.getApplicationThread(), this.mToken, this, paramIntent, paramInt, paramBundle);
      if (localActivityResult != null) {
        this.mMainThread.sendActivityResult(this.mToken, this.mEmbeddedID, paramInt, localActivityResult.getResultCode(), localActivityResult.getResultData());
      }
      if (paramInt >= 0) {
        this.mStartedActivity = true;
      }
      return;
    }
    if (paramBundle != null)
    {
      this.mParent.startActivityFromChild(this, paramIntent, paramInt, paramBundle);
      return;
    }
    this.mParent.startActivityFromChild(this, paramIntent, paramInt);
  }
  
  public void startActivityFromChild(Activity paramActivity, Intent paramIntent, int paramInt)
  {
    startActivityFromChild(paramActivity, paramIntent, paramInt, null);
  }
  
  public void startActivityFromChild(Activity paramActivity, Intent paramIntent, int paramInt, Bundle paramBundle)
  {
    Instrumentation.ActivityResult localActivityResult = this.mInstrumentation.execStartActivity(this, this.mMainThread.getApplicationThread(), this.mToken, paramActivity, paramIntent, paramInt, paramBundle);
    if (localActivityResult != null) {
      this.mMainThread.sendActivityResult(this.mToken, paramActivity.mEmbeddedID, paramInt, localActivityResult.getResultCode(), localActivityResult.getResultData());
    }
  }
  
  public void startActivityFromFragment(Fragment paramFragment, Intent paramIntent, int paramInt)
  {
    startActivityFromFragment(paramFragment, paramIntent, paramInt, null);
  }
  
  public void startActivityFromFragment(Fragment paramFragment, Intent paramIntent, int paramInt, Bundle paramBundle)
  {
    Instrumentation.ActivityResult localActivityResult = this.mInstrumentation.execStartActivity(this, this.mMainThread.getApplicationThread(), this.mToken, paramFragment, paramIntent, paramInt, paramBundle);
    if (localActivityResult != null) {
      this.mMainThread.sendActivityResult(this.mToken, paramFragment.mWho, paramInt, localActivityResult.getResultCode(), localActivityResult.getResultData());
    }
  }
  
  public boolean startActivityIfNeeded(Intent paramIntent, int paramInt)
  {
    return startActivityIfNeeded(paramIntent, paramInt, null);
  }
  
  public boolean startActivityIfNeeded(Intent paramIntent, int paramInt, Bundle paramBundle)
  {
    int i;
    if (this.mParent == null) {
      i = 1;
    }
    try
    {
      paramIntent.setAllowFds(false);
      int j = ActivityManagerNative.getDefault().startActivity(this.mMainThread.getApplicationThread(), paramIntent, paramIntent.resolveTypeIfNeeded(getContentResolver()), this.mToken, this.mEmbeddedID, paramInt, 1, null, null, paramBundle);
      i = j;
    }
    catch (RemoteException localRemoteException)
    {
      for (;;) {}
    }
    Instrumentation.checkStartActivityResult(i, paramIntent);
    if (paramInt >= 0) {
      this.mStartedActivity = true;
    }
    return i != 1;
    throw new UnsupportedOperationException("startActivityIfNeeded can only be called from a top-level activity");
  }
  
  public void startIntentSender(IntentSender paramIntentSender, Intent paramIntent, int paramInt1, int paramInt2, int paramInt3)
    throws IntentSender.SendIntentException
  {
    startIntentSender(paramIntentSender, paramIntent, paramInt1, paramInt2, paramInt3, null);
  }
  
  public void startIntentSender(IntentSender paramIntentSender, Intent paramIntent, int paramInt1, int paramInt2, int paramInt3, Bundle paramBundle)
    throws IntentSender.SendIntentException
  {
    if (paramBundle != null)
    {
      startIntentSenderForResult(paramIntentSender, -1, paramIntent, paramInt1, paramInt2, paramInt3, paramBundle);
      return;
    }
    startIntentSenderForResult(paramIntentSender, -1, paramIntent, paramInt1, paramInt2, paramInt3);
  }
  
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4)
    throws IntentSender.SendIntentException
  {
    startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, null);
  }
  
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle)
    throws IntentSender.SendIntentException
  {
    if (this.mParent == null)
    {
      startIntentSenderForResultInner(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, this, paramBundle);
      return;
    }
    if (paramBundle != null)
    {
      this.mParent.startIntentSenderFromChild(this, paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
      return;
    }
    this.mParent.startIntentSenderFromChild(this, paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  public void startIntentSenderFromChild(Activity paramActivity, IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4)
    throws IntentSender.SendIntentException
  {
    startIntentSenderFromChild(paramActivity, paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, null);
  }
  
  public void startIntentSenderFromChild(Activity paramActivity, IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle)
    throws IntentSender.SendIntentException
  {
    startIntentSenderForResultInner(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramActivity, paramBundle);
  }
  
  @Deprecated
  public void startManagingCursor(Cursor paramCursor)
  {
    synchronized (this.mManagedCursors)
    {
      this.mManagedCursors.add(new ManagedCursor(paramCursor));
      return;
    }
  }
  
  public boolean startNextMatchingActivity(Intent paramIntent)
  {
    return startNextMatchingActivity(paramIntent, null);
  }
  
  public boolean startNextMatchingActivity(Intent paramIntent, Bundle paramBundle)
  {
    if (this.mParent == null) {}
    try
    {
      paramIntent.setAllowFds(false);
      boolean bool = ActivityManagerNative.getDefault().startNextMatchingActivity(this.mToken, paramIntent, paramBundle);
      return bool;
    }
    catch (RemoteException localRemoteException) {}
    throw new UnsupportedOperationException("startNextMatchingActivity can only be called from a top-level activity");
    return false;
  }
  
  public void startSearch(String paramString, boolean paramBoolean1, Bundle paramBundle, boolean paramBoolean2)
  {
    ensureSearchManager();
    this.mSearchManager.startSearch(paramString, paramBoolean1, getComponentName(), paramBundle, paramBoolean2);
  }
  
  @Deprecated
  public void stopManagingCursor(Cursor paramCursor)
  {
    for (;;)
    {
      int j;
      synchronized (this.mManagedCursors)
      {
        int i = this.mManagedCursors.size();
        j = 0;
        if (j < i)
        {
          if (((ManagedCursor)this.mManagedCursors.get(j)).mCursor == paramCursor) {
            this.mManagedCursors.remove(j);
          }
        }
        else {
          return;
        }
      }
      j++;
    }
  }
  
  public void takeKeyEvents(boolean paramBoolean)
  {
    getWindow().takeKeyEvents(paramBoolean);
  }
  
  public void triggerSearch(String paramString, Bundle paramBundle)
  {
    ensureSearchManager();
    this.mSearchManager.triggerSearch(paramString, getComponentName(), paramBundle);
  }
  
  public void unregisterForContextMenu(View paramView)
  {
    paramView.setOnCreateContextMenuListener(null);
  }
  
  private static final class ManagedCursor
  {
    private final Cursor mCursor;
    private boolean mReleased;
    private boolean mUpdated;
    
    ManagedCursor(Cursor paramCursor)
    {
      this.mCursor = paramCursor;
      this.mReleased = false;
      this.mUpdated = false;
    }
  }
  
  private static class ManagedDialog
  {
    Bundle mArgs;
    Dialog mDialog;
  }
  
  static final class NonConfigurationInstances
  {
    Object activity;
    HashMap<String, Object> children;
    ArrayList<Fragment> fragments;
    HashMap<String, LoaderManagerImpl> loaders;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\Activity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
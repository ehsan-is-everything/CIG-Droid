package android.app;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.UserHandle;
import android.util.Log;

public class NotificationManager
{
  private static String TAG = "NotificationManager";
  private static boolean localLOGV = false;
  private static INotificationManager sService;
  private Context mContext;
  
  NotificationManager(Context paramContext, Handler paramHandler)
  {
    this.mContext = paramContext;
  }
  
  public static NotificationManager from(Context paramContext)
  {
    return (NotificationManager)paramContext.getSystemService("notification");
  }
  
  public static INotificationManager getService()
  {
    if (sService != null) {
      return sService;
    }
    sService = INotificationManager.Stub.asInterface(ServiceManager.getService("notification"));
    return sService;
  }
  
  public void cancel(int paramInt)
  {
    cancel(null, paramInt);
  }
  
  public void cancel(String paramString, int paramInt)
  {
    INotificationManager localINotificationManager = getService();
    String str = this.mContext.getPackageName();
    if (localLOGV) {
      Log.v(TAG, str + ": cancel(" + paramInt + ")");
    }
    try
    {
      localINotificationManager.cancelNotificationWithTag(str, paramString, paramInt, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void cancelAll()
  {
    INotificationManager localINotificationManager = getService();
    String str = this.mContext.getPackageName();
    if (localLOGV) {
      Log.v(TAG, str + ": cancelAll()");
    }
    try
    {
      localINotificationManager.cancelAllNotifications(str, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void cancelAsUser(String paramString, int paramInt, UserHandle paramUserHandle)
  {
    INotificationManager localINotificationManager = getService();
    String str = this.mContext.getPackageName();
    if (localLOGV) {
      Log.v(TAG, str + ": cancel(" + paramInt + ")");
    }
    try
    {
      localINotificationManager.cancelNotificationWithTag(str, paramString, paramInt, paramUserHandle.getIdentifier());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void notify(int paramInt, Notification paramNotification)
  {
    notify(null, paramInt, paramNotification);
  }
  
  public void notify(String paramString, int paramInt, Notification paramNotification)
  {
    int[] arrayOfInt = new int[1];
    INotificationManager localINotificationManager = getService();
    String str = this.mContext.getPackageName();
    if (paramNotification.sound != null) {
      paramNotification.sound = paramNotification.sound.getCanonicalUri();
    }
    if (localLOGV) {
      Log.v(TAG, str + ": notify(" + paramInt + ", " + paramNotification + ")");
    }
    try
    {
      localINotificationManager.enqueueNotificationWithTag(str, paramString, paramInt, paramNotification, arrayOfInt, UserHandle.myUserId());
      if (paramInt != arrayOfInt[0]) {
        Log.w(TAG, "notify: id corrupted: sent " + paramInt + ", got back " + arrayOfInt[0]);
      }
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void notifyAsUser(String paramString, int paramInt, Notification paramNotification, UserHandle paramUserHandle)
  {
    int[] arrayOfInt = new int[1];
    INotificationManager localINotificationManager = getService();
    String str = this.mContext.getPackageName();
    if (paramNotification.sound != null) {
      paramNotification.sound = paramNotification.sound.getCanonicalUri();
    }
    if (localLOGV) {
      Log.v(TAG, str + ": notify(" + paramInt + ", " + paramNotification + ")");
    }
    try
    {
      localINotificationManager.enqueueNotificationWithTag(str, paramString, paramInt, paramNotification, arrayOfInt, paramUserHandle.getIdentifier());
      if (paramInt != arrayOfInt[0]) {
        Log.w(TAG, "notify: id corrupted: sent " + paramInt + ", got back " + arrayOfInt[0]);
      }
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\NotificationManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
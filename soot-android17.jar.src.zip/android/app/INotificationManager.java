package android.app;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface INotificationManager
  extends IInterface
{
  public abstract boolean areNotificationsEnabledForPackage(String paramString)
    throws RemoteException;
  
  public abstract void cancelAllNotifications(String paramString, int paramInt)
    throws RemoteException;
  
  public abstract void cancelNotificationWithTag(String paramString1, String paramString2, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract void cancelToast(String paramString, ITransientNotification paramITransientNotification)
    throws RemoteException;
  
  public abstract void enqueueNotificationWithTag(String paramString1, String paramString2, int paramInt1, Notification paramNotification, int[] paramArrayOfInt, int paramInt2)
    throws RemoteException;
  
  public abstract void enqueueToast(String paramString, ITransientNotification paramITransientNotification, int paramInt)
    throws RemoteException;
  
  public abstract void setNotificationsEnabledForPackage(String paramString, boolean paramBoolean)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements INotificationManager
  {
    private static final String DESCRIPTOR = "android.app.INotificationManager";
    static final int TRANSACTION_areNotificationsEnabledForPackage = 7;
    static final int TRANSACTION_cancelAllNotifications = 1;
    static final int TRANSACTION_cancelNotificationWithTag = 5;
    static final int TRANSACTION_cancelToast = 3;
    static final int TRANSACTION_enqueueNotificationWithTag = 4;
    static final int TRANSACTION_enqueueToast = 2;
    static final int TRANSACTION_setNotificationsEnabledForPackage = 6;
    
    public Stub()
    {
      attachInterface(this, "android.app.INotificationManager");
    }
    
    public static INotificationManager asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.app.INotificationManager");
      if ((localIInterface != null) && ((localIInterface instanceof INotificationManager))) {
        return (INotificationManager)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.app.INotificationManager");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.app.INotificationManager");
        cancelAllNotifications(paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 2: 
        paramParcel1.enforceInterface("android.app.INotificationManager");
        enqueueToast(paramParcel1.readString(), ITransientNotification.Stub.asInterface(paramParcel1.readStrongBinder()), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 3: 
        paramParcel1.enforceInterface("android.app.INotificationManager");
        cancelToast(paramParcel1.readString(), ITransientNotification.Stub.asInterface(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 4: 
        paramParcel1.enforceInterface("android.app.INotificationManager");
        String str2 = paramParcel1.readString();
        String str3 = paramParcel1.readString();
        int k = paramParcel1.readInt();
        if (paramParcel1.readInt() != 0) {}
        for (Notification localNotification = (Notification)Notification.CREATOR.createFromParcel(paramParcel1);; localNotification = null)
        {
          int[] arrayOfInt = paramParcel1.createIntArray();
          enqueueNotificationWithTag(str2, str3, k, localNotification, arrayOfInt, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeIntArray(arrayOfInt);
          return true;
        }
      case 5: 
        paramParcel1.enforceInterface("android.app.INotificationManager");
        cancelNotificationWithTag(paramParcel1.readString(), paramParcel1.readString(), paramParcel1.readInt(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 6: 
        paramParcel1.enforceInterface("android.app.INotificationManager");
        String str1 = paramParcel1.readString();
        int j = paramParcel1.readInt();
        boolean bool2 = false;
        if (j != 0) {
          bool2 = true;
        }
        setNotificationsEnabledForPackage(str1, bool2);
        paramParcel2.writeNoException();
        return true;
      }
      paramParcel1.enforceInterface("android.app.INotificationManager");
      boolean bool1 = areNotificationsEnabledForPackage(paramParcel1.readString());
      paramParcel2.writeNoException();
      int i = 0;
      if (bool1) {
        i = 1;
      }
      paramParcel2.writeInt(i);
      return true;
    }
    
    private static class Proxy
      implements INotificationManager
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public boolean areNotificationsEnabledForPackage(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.INotificationManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(7, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public void cancelAllNotifications(String paramString, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.INotificationManager");
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(1, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void cancelNotificationWithTag(String paramString1, String paramString2, int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.INotificationManager");
          localParcel1.writeString(paramString1);
          localParcel1.writeString(paramString2);
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          this.mRemote.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public void cancelToast(String paramString, ITransientNotification paramITransientNotification)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_3
        //   16: aload_1
        //   17: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   20: aload_2
        //   21: ifnull +47 -> 68
        //   24: aload_2
        //   25: invokeinterface 66 1 0
        //   30: astore 6
        //   32: aload_3
        //   33: aload 6
        //   35: invokevirtual 69	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   38: aload_0
        //   39: getfield 15	android/app/INotificationManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   42: iconst_3
        //   43: aload_3
        //   44: aload 4
        //   46: iconst_0
        //   47: invokeinterface 40 5 0
        //   52: pop
        //   53: aload 4
        //   55: invokevirtual 43	android/os/Parcel:readException	()V
        //   58: aload 4
        //   60: invokevirtual 50	android/os/Parcel:recycle	()V
        //   63: aload_3
        //   64: invokevirtual 50	android/os/Parcel:recycle	()V
        //   67: return
        //   68: aconst_null
        //   69: astore 6
        //   71: goto -39 -> 32
        //   74: astore 5
        //   76: aload 4
        //   78: invokevirtual 50	android/os/Parcel:recycle	()V
        //   81: aload_3
        //   82: invokevirtual 50	android/os/Parcel:recycle	()V
        //   85: aload 5
        //   87: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	88	0	this	Proxy
        //   0	88	1	paramString	String
        //   0	88	2	paramITransientNotification	ITransientNotification
        //   3	79	3	localParcel1	Parcel
        //   7	70	4	localParcel2	Parcel
        //   74	12	5	localObject	Object
        //   30	40	6	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   9	20	74	finally
        //   24	32	74	finally
        //   32	58	74	finally
      }
      
      /* Error */
      public void enqueueNotificationWithTag(String paramString1, String paramString2, int paramInt1, Notification paramNotification, int[] paramArrayOfInt, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 7
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 8
        //   10: aload 7
        //   12: ldc 27
        //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 7
        //   19: aload_1
        //   20: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   23: aload 7
        //   25: aload_2
        //   26: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   29: aload 7
        //   31: iload_3
        //   32: invokevirtual 58	android/os/Parcel:writeInt	(I)V
        //   35: aload 4
        //   37: ifnull +70 -> 107
        //   40: aload 7
        //   42: iconst_1
        //   43: invokevirtual 58	android/os/Parcel:writeInt	(I)V
        //   46: aload 4
        //   48: aload 7
        //   50: iconst_0
        //   51: invokevirtual 77	android/app/Notification:writeToParcel	(Landroid/os/Parcel;I)V
        //   54: aload 7
        //   56: aload 5
        //   58: invokevirtual 81	android/os/Parcel:writeIntArray	([I)V
        //   61: aload 7
        //   63: iload 6
        //   65: invokevirtual 58	android/os/Parcel:writeInt	(I)V
        //   68: aload_0
        //   69: getfield 15	android/app/INotificationManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   72: iconst_4
        //   73: aload 7
        //   75: aload 8
        //   77: iconst_0
        //   78: invokeinterface 40 5 0
        //   83: pop
        //   84: aload 8
        //   86: invokevirtual 43	android/os/Parcel:readException	()V
        //   89: aload 8
        //   91: aload 5
        //   93: invokevirtual 84	android/os/Parcel:readIntArray	([I)V
        //   96: aload 8
        //   98: invokevirtual 50	android/os/Parcel:recycle	()V
        //   101: aload 7
        //   103: invokevirtual 50	android/os/Parcel:recycle	()V
        //   106: return
        //   107: aload 7
        //   109: iconst_0
        //   110: invokevirtual 58	android/os/Parcel:writeInt	(I)V
        //   113: goto -59 -> 54
        //   116: astore 9
        //   118: aload 8
        //   120: invokevirtual 50	android/os/Parcel:recycle	()V
        //   123: aload 7
        //   125: invokevirtual 50	android/os/Parcel:recycle	()V
        //   128: aload 9
        //   130: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	131	0	this	Proxy
        //   0	131	1	paramString1	String
        //   0	131	2	paramString2	String
        //   0	131	3	paramInt1	int
        //   0	131	4	paramNotification	Notification
        //   0	131	5	paramArrayOfInt	int[]
        //   0	131	6	paramInt2	int
        //   3	121	7	localParcel1	Parcel
        //   8	111	8	localParcel2	Parcel
        //   116	13	9	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	35	116	finally
        //   40	54	116	finally
        //   54	96	116	finally
        //   107	113	116	finally
      }
      
      /* Error */
      public void enqueueToast(String paramString, ITransientNotification paramITransientNotification, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 4
        //   19: aload_1
        //   20: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   23: aload_2
        //   24: ifnull +56 -> 80
        //   27: aload_2
        //   28: invokeinterface 66 1 0
        //   33: astore 7
        //   35: aload 4
        //   37: aload 7
        //   39: invokevirtual 69	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   42: aload 4
        //   44: iload_3
        //   45: invokevirtual 58	android/os/Parcel:writeInt	(I)V
        //   48: aload_0
        //   49: getfield 15	android/app/INotificationManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   52: iconst_2
        //   53: aload 4
        //   55: aload 5
        //   57: iconst_0
        //   58: invokeinterface 40 5 0
        //   63: pop
        //   64: aload 5
        //   66: invokevirtual 43	android/os/Parcel:readException	()V
        //   69: aload 5
        //   71: invokevirtual 50	android/os/Parcel:recycle	()V
        //   74: aload 4
        //   76: invokevirtual 50	android/os/Parcel:recycle	()V
        //   79: return
        //   80: aconst_null
        //   81: astore 7
        //   83: goto -48 -> 35
        //   86: astore 6
        //   88: aload 5
        //   90: invokevirtual 50	android/os/Parcel:recycle	()V
        //   93: aload 4
        //   95: invokevirtual 50	android/os/Parcel:recycle	()V
        //   98: aload 6
        //   100: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	101	0	this	Proxy
        //   0	101	1	paramString	String
        //   0	101	2	paramITransientNotification	ITransientNotification
        //   0	101	3	paramInt	int
        //   3	91	4	localParcel1	Parcel
        //   8	81	5	localParcel2	Parcel
        //   86	13	6	localObject	Object
        //   33	49	7	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   10	23	86	finally
        //   27	35	86	finally
        //   35	69	86	finally
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.app.INotificationManager";
      }
      
      public void setNotificationsEnabledForPackage(String paramString, boolean paramBoolean)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.INotificationManager");
          localParcel1.writeString(paramString);
          int i = 0;
          if (paramBoolean) {
            i = 1;
          }
          localParcel1.writeInt(i);
          this.mRemote.transact(6, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\INotificationManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
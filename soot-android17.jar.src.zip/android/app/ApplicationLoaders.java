package android.app;

import dalvik.system.PathClassLoader;
import java.util.HashMap;
import java.util.Map;

class ApplicationLoaders
{
  private static final ApplicationLoaders gApplicationLoaders = new ApplicationLoaders();
  private final Map<String, ClassLoader> mLoaders = new HashMap();
  
  public static ApplicationLoaders getDefault()
  {
    return gApplicationLoaders;
  }
  
  public ClassLoader getClassLoader(String paramString1, String paramString2, ClassLoader paramClassLoader)
  {
    ClassLoader localClassLoader1 = ClassLoader.getSystemClassLoader().getParent();
    localMap = this.mLoaders;
    if (paramClassLoader == null) {
      paramClassLoader = localClassLoader1;
    }
    if (paramClassLoader == localClassLoader1) {}
    try
    {
      ClassLoader localClassLoader2 = (ClassLoader)this.mLoaders.get(paramString1);
      if (localClassLoader2 != null) {
        return localClassLoader2;
      }
      PathClassLoader localPathClassLoader2 = new PathClassLoader(paramString1, paramString2, paramClassLoader);
      this.mLoaders.put(paramString1, localPathClassLoader2);
      return localPathClassLoader2;
    }
    finally {}
    PathClassLoader localPathClassLoader1 = new PathClassLoader(paramString1, paramClassLoader);
    return localPathClassLoader1;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\ApplicationLoaders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.app;

import android.content.ComponentName;
import android.content.pm.ResolveInfo;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import java.util.ArrayList;
import java.util.List;

public abstract interface ISearchManager
  extends IInterface
{
  public abstract ComponentName getAssistIntent(int paramInt)
    throws RemoteException;
  
  public abstract List<ResolveInfo> getGlobalSearchActivities()
    throws RemoteException;
  
  public abstract ComponentName getGlobalSearchActivity()
    throws RemoteException;
  
  public abstract SearchableInfo getSearchableInfo(ComponentName paramComponentName)
    throws RemoteException;
  
  public abstract List<SearchableInfo> getSearchablesInGlobalSearch()
    throws RemoteException;
  
  public abstract ComponentName getWebSearchActivity()
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements ISearchManager
  {
    private static final String DESCRIPTOR = "android.app.ISearchManager";
    static final int TRANSACTION_getAssistIntent = 6;
    static final int TRANSACTION_getGlobalSearchActivities = 3;
    static final int TRANSACTION_getGlobalSearchActivity = 4;
    static final int TRANSACTION_getSearchableInfo = 1;
    static final int TRANSACTION_getSearchablesInGlobalSearch = 2;
    static final int TRANSACTION_getWebSearchActivity = 5;
    
    public Stub()
    {
      attachInterface(this, "android.app.ISearchManager");
    }
    
    public static ISearchManager asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.app.ISearchManager");
      if ((localIInterface != null) && ((localIInterface instanceof ISearchManager))) {
        return (ISearchManager)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.app.ISearchManager");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.app.ISearchManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName4 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName4 = null)
        {
          SearchableInfo localSearchableInfo = getSearchableInfo(localComponentName4);
          paramParcel2.writeNoException();
          if (localSearchableInfo == null) {
            break;
          }
          paramParcel2.writeInt(1);
          localSearchableInfo.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 2: 
        paramParcel1.enforceInterface("android.app.ISearchManager");
        List localList2 = getSearchablesInGlobalSearch();
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList2);
        return true;
      case 3: 
        paramParcel1.enforceInterface("android.app.ISearchManager");
        List localList1 = getGlobalSearchActivities();
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList1);
        return true;
      case 4: 
        paramParcel1.enforceInterface("android.app.ISearchManager");
        ComponentName localComponentName3 = getGlobalSearchActivity();
        paramParcel2.writeNoException();
        if (localComponentName3 != null)
        {
          paramParcel2.writeInt(1);
          localComponentName3.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 5: 
        paramParcel1.enforceInterface("android.app.ISearchManager");
        ComponentName localComponentName2 = getWebSearchActivity();
        paramParcel2.writeNoException();
        if (localComponentName2 != null)
        {
          paramParcel2.writeInt(1);
          localComponentName2.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      }
      paramParcel1.enforceInterface("android.app.ISearchManager");
      ComponentName localComponentName1 = getAssistIntent(paramParcel1.readInt());
      paramParcel2.writeNoException();
      if (localComponentName1 != null)
      {
        paramParcel2.writeInt(1);
        localComponentName1.writeToParcel(paramParcel2, 1);
        return true;
      }
      paramParcel2.writeInt(0);
      return true;
    }
    
    private static class Proxy
      implements ISearchManager
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      /* Error */
      public ComponentName getAssistIntent(int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_2
        //   15: iload_1
        //   16: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   19: aload_0
        //   20: getfield 15	android/app/ISearchManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   23: bipush 6
        //   25: aload_2
        //   26: aload_3
        //   27: iconst_0
        //   28: invokeinterface 43 5 0
        //   33: pop
        //   34: aload_3
        //   35: invokevirtual 46	android/os/Parcel:readException	()V
        //   38: aload_3
        //   39: invokevirtual 50	android/os/Parcel:readInt	()I
        //   42: ifeq +28 -> 70
        //   45: getstatic 56	android/content/ComponentName:CREATOR	Landroid/os/Parcelable$Creator;
        //   48: aload_3
        //   49: invokeinterface 62 2 0
        //   54: checkcast 52	android/content/ComponentName
        //   57: astore 6
        //   59: aload_3
        //   60: invokevirtual 65	android/os/Parcel:recycle	()V
        //   63: aload_2
        //   64: invokevirtual 65	android/os/Parcel:recycle	()V
        //   67: aload 6
        //   69: areturn
        //   70: aconst_null
        //   71: astore 6
        //   73: goto -14 -> 59
        //   76: astore 4
        //   78: aload_3
        //   79: invokevirtual 65	android/os/Parcel:recycle	()V
        //   82: aload_2
        //   83: invokevirtual 65	android/os/Parcel:recycle	()V
        //   86: aload 4
        //   88: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	89	0	this	Proxy
        //   0	89	1	paramInt	int
        //   3	80	2	localParcel1	Parcel
        //   7	72	3	localParcel2	Parcel
        //   76	11	4	localObject	Object
        //   57	15	6	localComponentName	ComponentName
        // Exception table:
        //   from	to	target	type
        //   8	59	76	finally
      }
      
      public List<ResolveInfo> getGlobalSearchActivities()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.ISearchManager");
          this.mRemote.transact(3, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(ResolveInfo.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public ComponentName getGlobalSearchActivity()
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_1
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_2
        //   8: aload_1
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_0
        //   15: getfield 15	android/app/ISearchManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   18: iconst_4
        //   19: aload_1
        //   20: aload_2
        //   21: iconst_0
        //   22: invokeinterface 43 5 0
        //   27: pop
        //   28: aload_2
        //   29: invokevirtual 46	android/os/Parcel:readException	()V
        //   32: aload_2
        //   33: invokevirtual 50	android/os/Parcel:readInt	()I
        //   36: ifeq +28 -> 64
        //   39: getstatic 56	android/content/ComponentName:CREATOR	Landroid/os/Parcelable$Creator;
        //   42: aload_2
        //   43: invokeinterface 62 2 0
        //   48: checkcast 52	android/content/ComponentName
        //   51: astore 5
        //   53: aload_2
        //   54: invokevirtual 65	android/os/Parcel:recycle	()V
        //   57: aload_1
        //   58: invokevirtual 65	android/os/Parcel:recycle	()V
        //   61: aload 5
        //   63: areturn
        //   64: aconst_null
        //   65: astore 5
        //   67: goto -14 -> 53
        //   70: astore_3
        //   71: aload_2
        //   72: invokevirtual 65	android/os/Parcel:recycle	()V
        //   75: aload_1
        //   76: invokevirtual 65	android/os/Parcel:recycle	()V
        //   79: aload_3
        //   80: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	81	0	this	Proxy
        //   3	73	1	localParcel1	Parcel
        //   7	65	2	localParcel2	Parcel
        //   70	10	3	localObject	Object
        //   51	15	5	localComponentName	ComponentName
        // Exception table:
        //   from	to	target	type
        //   8	53	70	finally
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.app.ISearchManager";
      }
      
      public SearchableInfo getSearchableInfo(ComponentName paramComponentName)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.app.ISearchManager");
            if (paramComponentName != null)
            {
              localParcel1.writeInt(1);
              paramComponentName.writeToParcel(localParcel1, 0);
              this.mRemote.transact(1, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localSearchableInfo = (SearchableInfo)SearchableInfo.CREATOR.createFromParcel(localParcel2);
                return localSearchableInfo;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            SearchableInfo localSearchableInfo = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public List<SearchableInfo> getSearchablesInGlobalSearch()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.ISearchManager");
          this.mRemote.transact(2, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(SearchableInfo.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public ComponentName getWebSearchActivity()
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_1
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_2
        //   8: aload_1
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_0
        //   15: getfield 15	android/app/ISearchManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   18: iconst_5
        //   19: aload_1
        //   20: aload_2
        //   21: iconst_0
        //   22: invokeinterface 43 5 0
        //   27: pop
        //   28: aload_2
        //   29: invokevirtual 46	android/os/Parcel:readException	()V
        //   32: aload_2
        //   33: invokevirtual 50	android/os/Parcel:readInt	()I
        //   36: ifeq +28 -> 64
        //   39: getstatic 56	android/content/ComponentName:CREATOR	Landroid/os/Parcelable$Creator;
        //   42: aload_2
        //   43: invokeinterface 62 2 0
        //   48: checkcast 52	android/content/ComponentName
        //   51: astore 5
        //   53: aload_2
        //   54: invokevirtual 65	android/os/Parcel:recycle	()V
        //   57: aload_1
        //   58: invokevirtual 65	android/os/Parcel:recycle	()V
        //   61: aload 5
        //   63: areturn
        //   64: aconst_null
        //   65: astore 5
        //   67: goto -14 -> 53
        //   70: astore_3
        //   71: aload_2
        //   72: invokevirtual 65	android/os/Parcel:recycle	()V
        //   75: aload_1
        //   76: invokevirtual 65	android/os/Parcel:recycle	()V
        //   79: aload_3
        //   80: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	81	0	this	Proxy
        //   3	73	1	localParcel1	Parcel
        //   7	65	2	localParcel2	Parcel
        //   70	10	3	localObject	Object
        //   51	15	5	localComponentName	ComponentName
        // Exception table:
        //   from	to	target	type
        //   8	53	70	finally
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\ISearchManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
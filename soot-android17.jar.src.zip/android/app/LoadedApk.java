package android.app;

import android.content.BroadcastReceiver;
import android.content.BroadcastReceiver.PendingResult;
import android.content.ComponentName;
import android.content.Context;
import android.content.IIntentReceiver;
import android.content.IIntentReceiver.Stub;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ApplicationInfo;
import android.content.pm.IPackageManager;
import android.content.pm.PackageInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.CompatibilityInfo;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.IBinder.DeathRecipient;
import android.os.Process;
import android.os.RemoteException;
import android.os.StrictMode;
import android.os.StrictMode.ThreadPolicy;
import android.os.Trace;
import android.os.UserHandle;
import android.util.Slog;
import android.view.CompatibilityInfoHolder;
import com.android.internal.util.ArrayUtils;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;

public final class LoadedApk
{
  private static final String TAG = "LoadedApk";
  private final ActivityThread mActivityThread;
  private final String mAppDir;
  private Application mApplication;
  private final ApplicationInfo mApplicationInfo;
  private final ClassLoader mBaseClassLoader;
  private ClassLoader mClassLoader;
  int mClientCount = 0;
  public final CompatibilityInfoHolder mCompatibilityInfo = new CompatibilityInfoHolder();
  private final String mDataDir;
  private final File mDataDirFile;
  private final boolean mIncludeCode;
  private final String mLibDir;
  final String mPackageName;
  private final HashMap<Context, HashMap<BroadcastReceiver, ReceiverDispatcher>> mReceivers = new HashMap();
  private final String mResDir;
  Resources mResources;
  private final boolean mSecurityViolation;
  private final HashMap<Context, HashMap<ServiceConnection, ServiceDispatcher>> mServices = new HashMap();
  private final String[] mSharedLibraries;
  private final HashMap<Context, HashMap<ServiceConnection, ServiceDispatcher>> mUnboundServices = new HashMap();
  private final HashMap<Context, HashMap<BroadcastReceiver, ReceiverDispatcher>> mUnregisteredReceivers = new HashMap();
  
  public LoadedApk(ActivityThread paramActivityThread1, ApplicationInfo paramApplicationInfo, CompatibilityInfo paramCompatibilityInfo, ActivityThread paramActivityThread2, ClassLoader paramClassLoader, boolean paramBoolean1, boolean paramBoolean2)
  {
    this.mActivityThread = paramActivityThread1;
    this.mApplicationInfo = paramApplicationInfo;
    this.mPackageName = paramApplicationInfo.packageName;
    this.mAppDir = paramApplicationInfo.sourceDir;
    int i = Process.myUid();
    String str;
    if (paramApplicationInfo.uid == i)
    {
      str = paramApplicationInfo.sourceDir;
      this.mResDir = str;
      if ((!UserHandle.isSameUser(paramApplicationInfo.uid, i)) && (!Process.isIsolated())) {
        paramApplicationInfo.dataDir = PackageManager.getDataDirForUser(UserHandle.getUserId(i), this.mPackageName);
      }
      this.mSharedLibraries = paramApplicationInfo.sharedLibraryFiles;
      this.mDataDir = paramApplicationInfo.dataDir;
      if (this.mDataDir == null) {
        break label299;
      }
    }
    label299:
    for (File localFile = new File(this.mDataDir);; localFile = null)
    {
      this.mDataDirFile = localFile;
      this.mLibDir = paramApplicationInfo.nativeLibraryDir;
      this.mBaseClassLoader = paramClassLoader;
      this.mSecurityViolation = paramBoolean1;
      this.mIncludeCode = paramBoolean2;
      this.mCompatibilityInfo.set(paramCompatibilityInfo);
      if (this.mAppDir == null)
      {
        if (ActivityThread.mSystemContext == null)
        {
          ActivityThread.mSystemContext = ContextImpl.createSystemContext(paramActivityThread2);
          ActivityThread.mSystemContext.getResources().updateConfiguration(paramActivityThread2.getConfiguration(), paramActivityThread2.getDisplayMetricsLocked(0, paramCompatibilityInfo), paramCompatibilityInfo);
        }
        this.mClassLoader = ActivityThread.mSystemContext.getClassLoader();
        this.mResources = ActivityThread.mSystemContext.getResources();
      }
      return;
      str = paramApplicationInfo.publicSourceDir;
      break;
    }
  }
  
  public LoadedApk(ActivityThread paramActivityThread, String paramString, Context paramContext, ApplicationInfo paramApplicationInfo, CompatibilityInfo paramCompatibilityInfo)
  {
    this.mActivityThread = paramActivityThread;
    if (paramApplicationInfo != null) {}
    for (;;)
    {
      this.mApplicationInfo = paramApplicationInfo;
      this.mApplicationInfo.packageName = paramString;
      this.mPackageName = paramString;
      this.mAppDir = null;
      this.mResDir = null;
      this.mSharedLibraries = null;
      this.mDataDir = null;
      this.mDataDirFile = null;
      this.mLibDir = null;
      this.mBaseClassLoader = null;
      this.mSecurityViolation = false;
      this.mIncludeCode = true;
      this.mClassLoader = paramContext.getClassLoader();
      this.mResources = paramContext.getResources();
      this.mCompatibilityInfo.set(paramCompatibilityInfo);
      return;
      paramApplicationInfo = new ApplicationInfo();
    }
  }
  
  private static String combineLibs(String[] paramArrayOfString1, String[] paramArrayOfString2)
  {
    StringBuilder localStringBuilder = new StringBuilder(300);
    int i = 1;
    if (paramArrayOfString1 != null)
    {
      int n = paramArrayOfString1.length;
      int i1 = 0;
      if (i1 < n)
      {
        String str2 = paramArrayOfString1[i1];
        if (i != 0) {
          i = 0;
        }
        for (;;)
        {
          localStringBuilder.append(str2);
          i1++;
          break;
          localStringBuilder.append(':');
        }
      }
    }
    int j;
    if (i == 0) {
      j = 1;
    }
    while (paramArrayOfString2 != null)
    {
      int k = paramArrayOfString2.length;
      int m = 0;
      for (;;)
      {
        if (m < k)
        {
          String str1 = paramArrayOfString2[m];
          if ((j != 0) && (ArrayUtils.contains(paramArrayOfString1, str1)))
          {
            m++;
            continue;
            j = 0;
            break;
          }
          if (i != 0) {
            i = 0;
          }
          for (;;)
          {
            localStringBuilder.append(str1);
            break;
            localStringBuilder.append(':');
          }
        }
      }
    }
    return localStringBuilder.toString();
  }
  
  private static String[] getLibrariesFor(String paramString)
  {
    ApplicationInfo localApplicationInfo;
    try
    {
      localApplicationInfo = ActivityThread.getPackageManager().getApplicationInfo(paramString, 1024, UserHandle.myUserId());
      if (localApplicationInfo == null) {
        return null;
      }
    }
    catch (RemoteException localRemoteException)
    {
      throw new AssertionError(localRemoteException);
    }
    return localApplicationInfo.sharedLibraryFiles;
  }
  
  private void initializeJavaContextClassLoader()
  {
    IPackageManager localIPackageManager = ActivityThread.getPackageManager();
    for (;;)
    {
      try
      {
        PackageInfo localPackageInfo = localIPackageManager.getPackageInfo(this.mPackageName, 0, UserHandle.myUserId());
        if (localPackageInfo.sharedUserId != null)
        {
          i = 1;
          if ((localPackageInfo.applicationInfo == null) || (this.mPackageName.equals(localPackageInfo.applicationInfo.processName))) {
            break label109;
          }
          j = 1;
          if ((i == 0) && (j == 0)) {
            break label115;
          }
          k = 1;
          if (k == 0) {
            break label121;
          }
          localObject = new WarningContextClassLoader(null);
          Thread.currentThread().setContextClassLoader((ClassLoader)localObject);
          return;
        }
      }
      catch (RemoteException localRemoteException)
      {
        throw new AssertionError(localRemoteException);
      }
      int i = 0;
      continue;
      label109:
      int j = 0;
      continue;
      label115:
      int k = 0;
      continue;
      label121:
      Object localObject = this.mClassLoader;
    }
  }
  
  public IIntentReceiver forgetReceiverDispatcher(Context paramContext, BroadcastReceiver paramBroadcastReceiver)
  {
    synchronized (this.mReceivers)
    {
      HashMap localHashMap2 = (HashMap)this.mReceivers.get(paramContext);
      if (localHashMap2 != null)
      {
        ReceiverDispatcher localReceiverDispatcher1 = (ReceiverDispatcher)localHashMap2.get(paramBroadcastReceiver);
        if (localReceiverDispatcher1 != null)
        {
          localHashMap2.remove(paramBroadcastReceiver);
          if (localHashMap2.size() == 0) {
            this.mReceivers.remove(paramContext);
          }
          if (paramBroadcastReceiver.getDebugUnregister())
          {
            HashMap localHashMap3 = (HashMap)this.mUnregisteredReceivers.get(paramContext);
            if (localHashMap3 == null)
            {
              localHashMap3 = new HashMap();
              this.mUnregisteredReceivers.put(paramContext, localHashMap3);
            }
            IllegalArgumentException localIllegalArgumentException = new IllegalArgumentException("Originally unregistered here:");
            localIllegalArgumentException.fillInStackTrace();
            localReceiverDispatcher1.setUnregisterLocation(localIllegalArgumentException);
            localHashMap3.put(paramBroadcastReceiver, localReceiverDispatcher1);
          }
          localReceiverDispatcher1.mForgotten = true;
          IIntentReceiver localIIntentReceiver = localReceiverDispatcher1.getIIntentReceiver();
          return localIIntentReceiver;
        }
      }
      HashMap localHashMap4 = (HashMap)this.mUnregisteredReceivers.get(paramContext);
      if (localHashMap4 != null)
      {
        ReceiverDispatcher localReceiverDispatcher2 = (ReceiverDispatcher)localHashMap4.get(paramBroadcastReceiver);
        if (localReceiverDispatcher2 != null)
        {
          RuntimeException localRuntimeException = localReceiverDispatcher2.getUnregisterLocation();
          throw new IllegalArgumentException("Unregistering Receiver " + paramBroadcastReceiver + " that was already unregistered", localRuntimeException);
        }
      }
    }
    if (paramContext == null) {
      throw new IllegalStateException("Unbinding Receiver " + paramBroadcastReceiver + " from Context that is no longer in use: " + paramContext);
    }
    throw new IllegalArgumentException("Receiver not registered: " + paramBroadcastReceiver);
  }
  
  public final IServiceConnection forgetServiceDispatcher(Context paramContext, ServiceConnection paramServiceConnection)
  {
    synchronized (this.mServices)
    {
      HashMap localHashMap2 = (HashMap)this.mServices.get(paramContext);
      if (localHashMap2 != null)
      {
        ServiceDispatcher localServiceDispatcher1 = (ServiceDispatcher)localHashMap2.get(paramServiceConnection);
        if (localServiceDispatcher1 != null)
        {
          localHashMap2.remove(paramServiceConnection);
          localServiceDispatcher1.doForget();
          if (localHashMap2.size() == 0) {
            this.mServices.remove(paramContext);
          }
          if ((0x2 & localServiceDispatcher1.getFlags()) != 0)
          {
            HashMap localHashMap3 = (HashMap)this.mUnboundServices.get(paramContext);
            if (localHashMap3 == null)
            {
              localHashMap3 = new HashMap();
              this.mUnboundServices.put(paramContext, localHashMap3);
            }
            IllegalArgumentException localIllegalArgumentException = new IllegalArgumentException("Originally unbound here:");
            localIllegalArgumentException.fillInStackTrace();
            localServiceDispatcher1.setUnbindLocation(localIllegalArgumentException);
            localHashMap3.put(paramServiceConnection, localServiceDispatcher1);
          }
          IServiceConnection localIServiceConnection = localServiceDispatcher1.getIServiceConnection();
          return localIServiceConnection;
        }
      }
      HashMap localHashMap4 = (HashMap)this.mUnboundServices.get(paramContext);
      if (localHashMap4 != null)
      {
        ServiceDispatcher localServiceDispatcher2 = (ServiceDispatcher)localHashMap4.get(paramServiceConnection);
        if (localServiceDispatcher2 != null)
        {
          RuntimeException localRuntimeException = localServiceDispatcher2.getUnbindLocation();
          throw new IllegalArgumentException("Unbinding Service " + paramServiceConnection + " that was already unbound", localRuntimeException);
        }
      }
    }
    if (paramContext == null) {
      throw new IllegalStateException("Unbinding Service " + paramServiceConnection + " from Context that is no longer in use: " + paramContext);
    }
    throw new IllegalArgumentException("Service not registered: " + paramServiceConnection);
  }
  
  public String getAppDir()
  {
    return this.mAppDir;
  }
  
  Application getApplication()
  {
    return this.mApplication;
  }
  
  public ApplicationInfo getApplicationInfo()
  {
    return this.mApplicationInfo;
  }
  
  public AssetManager getAssets(ActivityThread paramActivityThread)
  {
    return getResources(paramActivityThread).getAssets();
  }
  
  public ClassLoader getClassLoader()
  {
    for (;;)
    {
      try
      {
        if (this.mClassLoader != null)
        {
          ClassLoader localClassLoader2 = this.mClassLoader;
          return localClassLoader2;
        }
        if ((this.mIncludeCode) && (!this.mPackageName.equals("android")))
        {
          String str1 = this.mAppDir;
          String str2 = this.mLibDir;
          String str3 = this.mActivityThread.mInstrumentationAppDir;
          String str4 = this.mActivityThread.mInstrumentationAppLibraryDir;
          String str5 = this.mActivityThread.mInstrumentationAppPackage;
          String str6 = this.mActivityThread.mInstrumentedAppDir;
          String str7 = this.mActivityThread.mInstrumentedAppLibraryDir;
          String[] arrayOfString;
          if (!this.mAppDir.equals(str3))
          {
            boolean bool2 = this.mAppDir.equals(str6);
            arrayOfString = null;
            if (!bool2) {}
          }
          else
          {
            str1 = str3 + ":" + str6;
            str2 = str4 + ":" + str7;
            boolean bool1 = str6.equals(str3);
            arrayOfString = null;
            if (!bool1) {
              arrayOfString = getLibrariesFor(str5);
            }
          }
          if ((this.mSharedLibraries != null) || (arrayOfString != null)) {
            str1 = combineLibs(this.mSharedLibraries, arrayOfString) + ':' + str1;
          }
          StrictMode.ThreadPolicy localThreadPolicy = StrictMode.allowThreadDiskReads();
          this.mClassLoader = ApplicationLoaders.getDefault().getClassLoader(str1, str2, this.mBaseClassLoader);
          initializeJavaContextClassLoader();
          StrictMode.setThreadPolicy(localThreadPolicy);
          ClassLoader localClassLoader1 = this.mClassLoader;
          return localClassLoader1;
        }
      }
      finally {}
      if (this.mBaseClassLoader == null) {
        this.mClassLoader = ClassLoader.getSystemClassLoader();
      } else {
        this.mClassLoader = this.mBaseClassLoader;
      }
    }
  }
  
  public String getDataDir()
  {
    return this.mDataDir;
  }
  
  public File getDataDirFile()
  {
    return this.mDataDirFile;
  }
  
  public String getLibDir()
  {
    return this.mLibDir;
  }
  
  public String getPackageName()
  {
    return this.mPackageName;
  }
  
  /* Error */
  public IIntentReceiver getReceiverDispatcher(BroadcastReceiver paramBroadcastReceiver, Context paramContext, Handler paramHandler, Instrumentation paramInstrumentation, boolean paramBoolean)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 57	android/app/LoadedApk:mReceivers	Ljava/util/HashMap;
    //   4: astore 6
    //   6: aload 6
    //   8: monitorenter
    //   9: aconst_null
    //   10: astore 7
    //   12: iload 5
    //   14: ifeq +176 -> 190
    //   17: aload_0
    //   18: getfield 57	android/app/LoadedApk:mReceivers	Ljava/util/HashMap;
    //   21: aload_2
    //   22: invokevirtual 282	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   25: checkcast 54	java/util/HashMap
    //   28: astore 7
    //   30: aload 7
    //   32: ifnull +158 -> 190
    //   35: aload 7
    //   37: aload_1
    //   38: invokevirtual 282	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   41: checkcast 284	android/app/LoadedApk$ReceiverDispatcher
    //   44: astore 21
    //   46: aload 7
    //   48: astore 8
    //   50: aload 21
    //   52: astore 9
    //   54: aload 9
    //   56: ifnonnull +77 -> 133
    //   59: new 284	android/app/LoadedApk$ReceiverDispatcher
    //   62: dup
    //   63: aload_1
    //   64: aload_2
    //   65: aload_3
    //   66: aload 4
    //   68: iload 5
    //   70: invokespecial 446	android/app/LoadedApk$ReceiverDispatcher:<init>	(Landroid/content/BroadcastReceiver;Landroid/content/Context;Landroid/os/Handler;Landroid/app/Instrumentation;Z)V
    //   73: astore 14
    //   75: iload 5
    //   77: ifeq +107 -> 184
    //   80: aload 8
    //   82: ifnonnull +95 -> 177
    //   85: new 54	java/util/HashMap
    //   88: dup
    //   89: invokespecial 55	java/util/HashMap:<init>	()V
    //   92: astore 17
    //   94: aload_0
    //   95: getfield 57	android/app/LoadedApk:mReceivers	Ljava/util/HashMap;
    //   98: aload_2
    //   99: aload 17
    //   101: invokevirtual 299	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   104: pop
    //   105: aload 17
    //   107: aload_1
    //   108: aload 14
    //   110: invokevirtual 299	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   113: pop
    //   114: aload 14
    //   116: iconst_0
    //   117: putfield 317	android/app/LoadedApk$ReceiverDispatcher:mForgotten	Z
    //   120: aload 14
    //   122: invokevirtual 321	android/app/LoadedApk$ReceiverDispatcher:getIIntentReceiver	()Landroid/content/IIntentReceiver;
    //   125: astore 15
    //   127: aload 6
    //   129: monitorexit
    //   130: aload 15
    //   132: areturn
    //   133: aload 9
    //   135: aload_2
    //   136: aload_3
    //   137: invokevirtual 450	android/app/LoadedApk$ReceiverDispatcher:validate	(Landroid/content/Context;Landroid/os/Handler;)V
    //   140: aload 8
    //   142: pop
    //   143: aload 9
    //   145: astore 14
    //   147: goto -33 -> 114
    //   150: astore 10
    //   152: aload 6
    //   154: monitorexit
    //   155: aload 10
    //   157: athrow
    //   158: astore 10
    //   160: aload 8
    //   162: pop
    //   163: aload 9
    //   165: pop
    //   166: goto -14 -> 152
    //   169: astore 10
    //   171: aload 8
    //   173: pop
    //   174: goto -22 -> 152
    //   177: aload 8
    //   179: astore 17
    //   181: goto -76 -> 105
    //   184: aload 8
    //   186: pop
    //   187: goto -73 -> 114
    //   190: aload 7
    //   192: astore 8
    //   194: aconst_null
    //   195: astore 9
    //   197: goto -143 -> 54
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	200	0	this	LoadedApk
    //   0	200	1	paramBroadcastReceiver	BroadcastReceiver
    //   0	200	2	paramContext	Context
    //   0	200	3	paramHandler	Handler
    //   0	200	4	paramInstrumentation	Instrumentation
    //   0	200	5	paramBoolean	boolean
    //   4	149	6	localHashMap1	HashMap
    //   10	181	7	localHashMap2	HashMap
    //   48	145	8	localHashMap3	HashMap
    //   52	144	9	localReceiverDispatcher1	ReceiverDispatcher
    //   150	6	10	localObject1	Object
    //   158	1	10	localObject2	Object
    //   169	1	10	localObject3	Object
    //   73	73	14	localReceiverDispatcher2	ReceiverDispatcher
    //   125	6	15	localIIntentReceiver	IIntentReceiver
    //   92	88	17	localHashMap4	HashMap
    //   44	7	21	localReceiverDispatcher3	ReceiverDispatcher
    // Exception table:
    //   from	to	target	type
    //   17	30	150	finally
    //   35	46	150	finally
    //   94	105	150	finally
    //   105	114	150	finally
    //   114	130	150	finally
    //   152	155	150	finally
    //   59	75	158	finally
    //   133	140	158	finally
    //   85	94	169	finally
  }
  
  public String getResDir()
  {
    return this.mResDir;
  }
  
  public Resources getResources(ActivityThread paramActivityThread)
  {
    if (this.mResources == null) {
      this.mResources = paramActivityThread.getTopLevelResources(this.mResDir, 0, null, this);
    }
    return this.mResources;
  }
  
  public final IServiceConnection getServiceDispatcher(ServiceConnection paramServiceConnection, Context paramContext, Handler paramHandler, int paramInt)
  {
    for (;;)
    {
      HashMap localHashMap2;
      synchronized (this.mServices)
      {
        localHashMap2 = (HashMap)this.mServices.get(paramContext);
        if (localHashMap2 == null) {
          break label138;
        }
        ServiceDispatcher localServiceDispatcher1 = (ServiceDispatcher)localHashMap2.get(paramServiceConnection);
        localServiceDispatcher2 = localServiceDispatcher1;
        if (localServiceDispatcher2 != null) {}
      }
      for (;;)
      {
        try
        {
          localServiceDispatcher3 = new ServiceDispatcher(paramServiceConnection, paramContext, paramHandler, paramInt);
          if (localHashMap2 == null)
          {
            localHashMap2 = new HashMap();
            this.mServices.put(paramContext, localHashMap2);
          }
          localHashMap2.put(paramServiceConnection, localServiceDispatcher3);
          IServiceConnection localIServiceConnection = localServiceDispatcher3.getIServiceConnection();
          return localIServiceConnection;
        }
        finally
        {
          ServiceDispatcher localServiceDispatcher3;
          continue;
        }
        localServiceDispatcher2.validate(paramContext, paramHandler);
        localServiceDispatcher3 = localServiceDispatcher2;
      }
      localObject1 = finally;
      throw ((Throwable)localObject1);
      label138:
      ServiceDispatcher localServiceDispatcher2 = null;
    }
  }
  
  public boolean isSecurityViolation()
  {
    return this.mSecurityViolation;
  }
  
  public Application makeApplication(boolean paramBoolean, Instrumentation paramInstrumentation)
  {
    Application localApplication;
    if (this.mApplication != null) {
      localApplication = this.mApplication;
    }
    for (;;)
    {
      return localApplication;
      localApplication = null;
      String str = this.mApplicationInfo.className;
      if ((paramBoolean) || (str == null)) {
        str = "android.app.Application";
      }
      try
      {
        ClassLoader localClassLoader = getClassLoader();
        ContextImpl localContextImpl = new ContextImpl();
        localContextImpl.init(this, null, this.mActivityThread);
        localApplication = this.mActivityThread.mInstrumentation.newApplication(localClassLoader, str, localContextImpl);
        localContextImpl.setOuterContext(localApplication);
        this.mActivityThread.mAllApplications.add(localApplication);
        this.mApplication = localApplication;
        if (paramInstrumentation == null) {
          continue;
        }
        try
        {
          paramInstrumentation.callApplicationOnCreate(localApplication);
          return localApplication;
        }
        catch (Exception localException2) {}
        if (paramInstrumentation.onException(localApplication, localException2)) {
          continue;
        }
        throw new RuntimeException("Unable to create application " + localApplication.getClass().getName() + ": " + localException2.toString(), localException2);
      }
      catch (Exception localException1)
      {
        while (this.mActivityThread.mInstrumentation.onException(localApplication, localException1)) {}
        throw new RuntimeException("Unable to instantiate application " + str + ": " + localException1.toString(), localException1);
      }
    }
  }
  
  public void removeContextRegistrations(Context paramContext, String paramString1, String paramString2)
  {
    boolean bool = StrictMode.vmRegistrationLeaksEnabled();
    HashMap localHashMap1 = (HashMap)this.mReceivers.remove(paramContext);
    if (localHashMap1 != null)
    {
      Iterator localIterator2 = localHashMap1.values().iterator();
      while (localIterator2.hasNext())
      {
        ReceiverDispatcher localReceiverDispatcher = (ReceiverDispatcher)localIterator2.next();
        IntentReceiverLeaked localIntentReceiverLeaked = new IntentReceiverLeaked(paramString2 + " " + paramString1 + " has leaked IntentReceiver " + localReceiverDispatcher.getIntentReceiver() + " that was " + "originally registered here. Are you missing a " + "call to unregisterReceiver()?");
        localIntentReceiverLeaked.setStackTrace(localReceiverDispatcher.getLocation().getStackTrace());
        Slog.e("ActivityThread", localIntentReceiverLeaked.getMessage(), localIntentReceiverLeaked);
        if (bool) {
          StrictMode.onIntentReceiverLeaked(localIntentReceiverLeaked);
        }
        try
        {
          ActivityManagerNative.getDefault().unregisterReceiver(localReceiverDispatcher.getIIntentReceiver());
        }
        catch (RemoteException localRemoteException2) {}
      }
    }
    this.mUnregisteredReceivers.remove(paramContext);
    HashMap localHashMap2 = (HashMap)this.mServices.remove(paramContext);
    Iterator localIterator1;
    if (localHashMap2 != null) {
      localIterator1 = localHashMap2.values().iterator();
    }
    for (;;)
    {
      ServiceDispatcher localServiceDispatcher;
      if (localIterator1.hasNext())
      {
        localServiceDispatcher = (ServiceDispatcher)localIterator1.next();
        ServiceConnectionLeaked localServiceConnectionLeaked = new ServiceConnectionLeaked(paramString2 + " " + paramString1 + " has leaked ServiceConnection " + localServiceDispatcher.getServiceConnection() + " that was originally bound here");
        localServiceConnectionLeaked.setStackTrace(localServiceDispatcher.getLocation().getStackTrace());
        Slog.e("ActivityThread", localServiceConnectionLeaked.getMessage(), localServiceConnectionLeaked);
        if (bool) {
          StrictMode.onServiceConnectionLeaked(localServiceConnectionLeaked);
        }
      }
      try
      {
        ActivityManagerNative.getDefault().unbindService(localServiceDispatcher.getIServiceConnection());
        localServiceDispatcher.doForget();
        continue;
        this.mUnboundServices.remove(paramContext);
        return;
      }
      catch (RemoteException localRemoteException1)
      {
        for (;;) {}
      }
    }
  }
  
  static final class ReceiverDispatcher
  {
    final Handler mActivityThread;
    final Context mContext;
    boolean mForgotten;
    final IIntentReceiver.Stub mIIntentReceiver;
    final Instrumentation mInstrumentation;
    final IntentReceiverLeaked mLocation;
    final BroadcastReceiver mReceiver;
    final boolean mRegistered;
    RuntimeException mUnregisterLocation;
    
    ReceiverDispatcher(BroadcastReceiver paramBroadcastReceiver, Context paramContext, Handler paramHandler, Instrumentation paramInstrumentation, boolean paramBoolean)
    {
      if (paramHandler == null) {
        throw new NullPointerException("Handler must not be null");
      }
      if (!paramBoolean) {}
      for (boolean bool = true;; bool = false)
      {
        this.mIIntentReceiver = new InnerReceiver(this, bool);
        this.mReceiver = paramBroadcastReceiver;
        this.mContext = paramContext;
        this.mActivityThread = paramHandler;
        this.mInstrumentation = paramInstrumentation;
        this.mRegistered = paramBoolean;
        this.mLocation = new IntentReceiverLeaked(null);
        this.mLocation.fillInStackTrace();
        return;
      }
    }
    
    IIntentReceiver getIIntentReceiver()
    {
      return this.mIIntentReceiver;
    }
    
    BroadcastReceiver getIntentReceiver()
    {
      return this.mReceiver;
    }
    
    IntentReceiverLeaked getLocation()
    {
      return this.mLocation;
    }
    
    RuntimeException getUnregisterLocation()
    {
      return this.mUnregisterLocation;
    }
    
    public void performReceive(Intent paramIntent, int paramInt1, String paramString, Bundle paramBundle, boolean paramBoolean1, boolean paramBoolean2, int paramInt2)
    {
      Args localArgs = new Args(paramIntent, paramInt1, paramString, paramBundle, paramBoolean1, paramBoolean2, paramInt2);
      if ((!this.mActivityThread.post(localArgs)) && (this.mRegistered) && (paramBoolean1)) {
        localArgs.sendFinished(ActivityManagerNative.getDefault());
      }
    }
    
    void setUnregisterLocation(RuntimeException paramRuntimeException)
    {
      this.mUnregisterLocation = paramRuntimeException;
    }
    
    void validate(Context paramContext, Handler paramHandler)
    {
      if (this.mContext != paramContext) {
        throw new IllegalStateException("Receiver " + this.mReceiver + " registered with differing Context (was " + this.mContext + " now " + paramContext + ")");
      }
      if (this.mActivityThread != paramHandler) {
        throw new IllegalStateException("Receiver " + this.mReceiver + " registered with differing handler (was " + this.mActivityThread + " now " + paramHandler + ")");
      }
    }
    
    final class Args
      extends BroadcastReceiver.PendingResult
      implements Runnable
    {
      private Intent mCurIntent;
      private final boolean mOrdered;
      
      public Args(Intent paramIntent, int paramInt1, String paramString, Bundle paramBundle, boolean paramBoolean1, boolean paramBoolean2, int paramInt2) {}
      
      public void run()
      {
        BroadcastReceiver localBroadcastReceiver = LoadedApk.ReceiverDispatcher.this.mReceiver;
        boolean bool = this.mOrdered;
        IActivityManager localIActivityManager = ActivityManagerNative.getDefault();
        Intent localIntent = this.mCurIntent;
        this.mCurIntent = null;
        if ((localBroadcastReceiver == null) || (LoadedApk.ReceiverDispatcher.this.mForgotten))
        {
          if ((LoadedApk.ReceiverDispatcher.this.mRegistered) && (bool)) {
            sendFinished(localIActivityManager);
          }
          return;
        }
        Trace.traceBegin(64L, "broadcastReceiveReg");
        try
        {
          ClassLoader localClassLoader = LoadedApk.ReceiverDispatcher.this.mReceiver.getClass().getClassLoader();
          localIntent.setExtrasClassLoader(localClassLoader);
          setExtrasClassLoader(localClassLoader);
          localBroadcastReceiver.setPendingResult(this);
          localBroadcastReceiver.onReceive(LoadedApk.ReceiverDispatcher.this.mContext, localIntent);
          if (localBroadcastReceiver.getPendingResult() != null) {
            finish();
          }
          Trace.traceEnd(64L);
          return;
        }
        catch (Exception localException)
        {
          do
          {
            if ((LoadedApk.ReceiverDispatcher.this.mRegistered) && (bool)) {
              sendFinished(localIActivityManager);
            }
          } while ((LoadedApk.ReceiverDispatcher.this.mInstrumentation != null) && (LoadedApk.ReceiverDispatcher.this.mInstrumentation.onException(LoadedApk.ReceiverDispatcher.this.mReceiver, localException)));
          Trace.traceEnd(64L);
          throw new RuntimeException("Error receiving broadcast " + localIntent + " in " + LoadedApk.ReceiverDispatcher.this.mReceiver, localException);
        }
      }
    }
    
    static final class InnerReceiver
      extends IIntentReceiver.Stub
    {
      final WeakReference<LoadedApk.ReceiverDispatcher> mDispatcher;
      final LoadedApk.ReceiverDispatcher mStrongRef;
      
      InnerReceiver(LoadedApk.ReceiverDispatcher paramReceiverDispatcher, boolean paramBoolean)
      {
        this.mDispatcher = new WeakReference(paramReceiverDispatcher);
        if (paramBoolean) {}
        for (;;)
        {
          this.mStrongRef = paramReceiverDispatcher;
          return;
          paramReceiverDispatcher = null;
        }
      }
      
      public void performReceive(Intent paramIntent, int paramInt1, String paramString, Bundle paramBundle, boolean paramBoolean1, boolean paramBoolean2, int paramInt2)
      {
        LoadedApk.ReceiverDispatcher localReceiverDispatcher = (LoadedApk.ReceiverDispatcher)this.mDispatcher.get();
        if (localReceiverDispatcher != null)
        {
          localReceiverDispatcher.performReceive(paramIntent, paramInt1, paramString, paramBundle, paramBoolean1, paramBoolean2, paramInt2);
          return;
        }
        IActivityManager localIActivityManager = ActivityManagerNative.getDefault();
        if (paramBundle != null) {}
        try
        {
          paramBundle.setAllowFds(false);
          localIActivityManager.finishReceiver(this, paramInt1, paramString, paramBundle, false);
          return;
        }
        catch (RemoteException localRemoteException)
        {
          Slog.w("ActivityThread", "Couldn't finish broadcast to unregistered receiver");
        }
      }
    }
  }
  
  static final class ServiceDispatcher
  {
    private final HashMap<ComponentName, ConnectionInfo> mActiveConnections = new HashMap();
    private final Handler mActivityThread;
    private final ServiceConnection mConnection;
    private final Context mContext;
    private boolean mDied;
    private final int mFlags;
    private boolean mForgotten;
    private final InnerConnection mIServiceConnection = new InnerConnection(this);
    private final ServiceConnectionLeaked mLocation;
    private RuntimeException mUnbindLocation;
    
    ServiceDispatcher(ServiceConnection paramServiceConnection, Context paramContext, Handler paramHandler, int paramInt)
    {
      this.mConnection = paramServiceConnection;
      this.mContext = paramContext;
      this.mActivityThread = paramHandler;
      this.mLocation = new ServiceConnectionLeaked(null);
      this.mLocation.fillInStackTrace();
      this.mFlags = paramInt;
    }
    
    public void connected(ComponentName paramComponentName, IBinder paramIBinder)
    {
      if (this.mActivityThread != null)
      {
        this.mActivityThread.post(new RunConnection(paramComponentName, paramIBinder, 0));
        return;
      }
      doConnected(paramComponentName, paramIBinder);
    }
    
    public void death(ComponentName paramComponentName, IBinder paramIBinder)
    {
      try
      {
        this.mDied = true;
        ConnectionInfo localConnectionInfo = (ConnectionInfo)this.mActiveConnections.remove(paramComponentName);
        if ((localConnectionInfo == null) || (localConnectionInfo.binder != paramIBinder)) {
          return;
        }
        localConnectionInfo.binder.unlinkToDeath(localConnectionInfo.deathMonitor, 0);
        if (this.mActivityThread != null)
        {
          this.mActivityThread.post(new RunConnection(paramComponentName, paramIBinder, 1));
          return;
        }
      }
      finally {}
      doDeath(paramComponentName, paramIBinder);
    }
    
    public void doConnected(ComponentName paramComponentName, IBinder paramIBinder)
    {
      ConnectionInfo localConnectionInfo1;
      try
      {
        if (this.mForgotten) {
          return;
        }
        localConnectionInfo1 = (ConnectionInfo)this.mActiveConnections.get(paramComponentName);
        if ((localConnectionInfo1 != null) && (localConnectionInfo1.binder == paramIBinder)) {
          return;
        }
      }
      finally {}
      ConnectionInfo localConnectionInfo2;
      if (paramIBinder != null)
      {
        this.mDied = false;
        localConnectionInfo2 = new ConnectionInfo(null);
        localConnectionInfo2.binder = paramIBinder;
        localConnectionInfo2.deathMonitor = new DeathMonitor(paramComponentName, paramIBinder);
      }
      for (;;)
      {
        try
        {
          paramIBinder.linkToDeath(localConnectionInfo2.deathMonitor, 0);
          this.mActiveConnections.put(paramComponentName, localConnectionInfo2);
          if (localConnectionInfo1 != null) {
            localConnectionInfo1.binder.unlinkToDeath(localConnectionInfo1.deathMonitor, 0);
          }
          if (localConnectionInfo1 != null) {
            this.mConnection.onServiceDisconnected(paramComponentName);
          }
          if (paramIBinder == null) {
            break;
          }
          this.mConnection.onServiceConnected(paramComponentName, paramIBinder);
          return;
        }
        catch (RemoteException localRemoteException)
        {
          this.mActiveConnections.remove(paramComponentName);
          return;
        }
        this.mActiveConnections.remove(paramComponentName);
      }
    }
    
    public void doDeath(ComponentName paramComponentName, IBinder paramIBinder)
    {
      this.mConnection.onServiceDisconnected(paramComponentName);
    }
    
    void doForget()
    {
      try
      {
        Iterator localIterator = this.mActiveConnections.values().iterator();
        while (localIterator.hasNext())
        {
          ConnectionInfo localConnectionInfo = (ConnectionInfo)localIterator.next();
          localConnectionInfo.binder.unlinkToDeath(localConnectionInfo.deathMonitor, 0);
        }
        this.mActiveConnections.clear();
      }
      finally {}
      this.mForgotten = true;
    }
    
    int getFlags()
    {
      return this.mFlags;
    }
    
    IServiceConnection getIServiceConnection()
    {
      return this.mIServiceConnection;
    }
    
    ServiceConnectionLeaked getLocation()
    {
      return this.mLocation;
    }
    
    ServiceConnection getServiceConnection()
    {
      return this.mConnection;
    }
    
    RuntimeException getUnbindLocation()
    {
      return this.mUnbindLocation;
    }
    
    void setUnbindLocation(RuntimeException paramRuntimeException)
    {
      this.mUnbindLocation = paramRuntimeException;
    }
    
    void validate(Context paramContext, Handler paramHandler)
    {
      if (this.mContext != paramContext) {
        throw new RuntimeException("ServiceConnection " + this.mConnection + " registered with differing Context (was " + this.mContext + " now " + paramContext + ")");
      }
      if (this.mActivityThread != paramHandler) {
        throw new RuntimeException("ServiceConnection " + this.mConnection + " registered with differing handler (was " + this.mActivityThread + " now " + paramHandler + ")");
      }
    }
    
    private static class ConnectionInfo
    {
      IBinder binder;
      IBinder.DeathRecipient deathMonitor;
    }
    
    private final class DeathMonitor
      implements IBinder.DeathRecipient
    {
      final ComponentName mName;
      final IBinder mService;
      
      DeathMonitor(ComponentName paramComponentName, IBinder paramIBinder)
      {
        this.mName = paramComponentName;
        this.mService = paramIBinder;
      }
      
      public void binderDied()
      {
        LoadedApk.ServiceDispatcher.this.death(this.mName, this.mService);
      }
    }
    
    private static class InnerConnection
      extends IServiceConnection.Stub
    {
      final WeakReference<LoadedApk.ServiceDispatcher> mDispatcher;
      
      InnerConnection(LoadedApk.ServiceDispatcher paramServiceDispatcher)
      {
        this.mDispatcher = new WeakReference(paramServiceDispatcher);
      }
      
      public void connected(ComponentName paramComponentName, IBinder paramIBinder)
        throws RemoteException
      {
        LoadedApk.ServiceDispatcher localServiceDispatcher = (LoadedApk.ServiceDispatcher)this.mDispatcher.get();
        if (localServiceDispatcher != null) {
          localServiceDispatcher.connected(paramComponentName, paramIBinder);
        }
      }
    }
    
    private final class RunConnection
      implements Runnable
    {
      final int mCommand;
      final ComponentName mName;
      final IBinder mService;
      
      RunConnection(ComponentName paramComponentName, IBinder paramIBinder, int paramInt)
      {
        this.mName = paramComponentName;
        this.mService = paramIBinder;
        this.mCommand = paramInt;
      }
      
      public void run()
      {
        if (this.mCommand == 0) {
          LoadedApk.ServiceDispatcher.this.doConnected(this.mName, this.mService);
        }
        while (this.mCommand != 1) {
          return;
        }
        LoadedApk.ServiceDispatcher.this.doDeath(this.mName, this.mService);
      }
    }
  }
  
  private static class WarningContextClassLoader
    extends ClassLoader
  {
    private static boolean warned = false;
    
    private void warn(String paramString)
    {
      if (warned) {
        return;
      }
      warned = true;
      Thread.currentThread().setContextClassLoader(getParent());
      Slog.w("ActivityThread", "ClassLoader." + paramString + ": " + "The class loader returned by " + "Thread.getContextClassLoader() may fail for processes " + "that host multiple applications. You should explicitly " + "specify a context class loader. For example: " + "Thread.setContextClassLoader(getClass().getClassLoader());");
    }
    
    public void clearAssertionStatus()
    {
      warn("clearAssertionStatus");
      getParent().clearAssertionStatus();
    }
    
    public URL getResource(String paramString)
    {
      warn("getResource");
      return getParent().getResource(paramString);
    }
    
    public InputStream getResourceAsStream(String paramString)
    {
      warn("getResourceAsStream");
      return getParent().getResourceAsStream(paramString);
    }
    
    public Enumeration<URL> getResources(String paramString)
      throws IOException
    {
      warn("getResources");
      return getParent().getResources(paramString);
    }
    
    public Class<?> loadClass(String paramString)
      throws ClassNotFoundException
    {
      warn("loadClass");
      return getParent().loadClass(paramString);
    }
    
    public void setClassAssertionStatus(String paramString, boolean paramBoolean)
    {
      warn("setClassAssertionStatus");
      getParent().setClassAssertionStatus(paramString, paramBoolean);
    }
    
    public void setDefaultAssertionStatus(boolean paramBoolean)
    {
      warn("setDefaultAssertionStatus");
      getParent().setDefaultAssertionStatus(paramBoolean);
    }
    
    public void setPackageAssertionStatus(String paramString, boolean paramBoolean)
    {
      warn("setPackageAssertionStatus");
      getParent().setPackageAssertionStatus(paramString, paramBoolean);
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\LoadedApk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
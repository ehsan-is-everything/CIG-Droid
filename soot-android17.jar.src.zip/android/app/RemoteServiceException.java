package android.app;

import android.util.AndroidRuntimeException;

final class RemoteServiceException
  extends AndroidRuntimeException
{
  public RemoteServiceException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\RemoteServiceException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
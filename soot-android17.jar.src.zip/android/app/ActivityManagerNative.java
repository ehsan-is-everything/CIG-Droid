package android.app;

import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.util.Singleton;

public abstract class ActivityManagerNative
  extends Binder
  implements IActivityManager
{
  private static final Singleton<IActivityManager> gDefault = new Singleton()
  {
    protected IActivityManager create()
    {
      return ActivityManagerNative.asInterface(ServiceManager.getService("activity"));
    }
  };
  static boolean sSystemReady = false;
  
  public ActivityManagerNative()
  {
    attachInterface(this, "android.app.IActivityManager");
  }
  
  public static IActivityManager asInterface(IBinder paramIBinder)
  {
    IActivityManager localIActivityManager;
    if (paramIBinder == null) {
      localIActivityManager = null;
    }
    do
    {
      return localIActivityManager;
      localIActivityManager = (IActivityManager)paramIBinder.queryLocalInterface("android.app.IActivityManager");
    } while (localIActivityManager != null);
    return new ActivityManagerProxy(paramIBinder);
  }
  
  public static void broadcastStickyIntent(Intent paramIntent, String paramString, int paramInt)
  {
    try
    {
      getDefault().broadcastIntent(null, paramIntent, null, null, -1, null, null, null, false, true, paramInt);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public static IActivityManager getDefault()
  {
    return (IActivityManager)gDefault.get();
  }
  
  public static boolean isSystemReady()
  {
    if (!sSystemReady) {
      sSystemReady = getDefault().testIsSystemReady();
    }
    return sSystemReady;
  }
  
  public static void noteWakeupAlarm(PendingIntent paramPendingIntent)
  {
    try
    {
      getDefault().noteWakeupAlarm(paramPendingIntent.getTarget());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public IBinder asBinder()
  {
    return this;
  }
  
  /* Error */
  public boolean onTransact(int arg1, android.os.Parcel arg2, android.os.Parcel arg3, int arg4)
    throws RemoteException
  {
    // Byte code:
    //   0: iload_1
    //   1: tableswitch	default:+651->652, 1:+5769->5770, 2:+5801->5802, 3:+661->662, 4:+5371->5372, 5:+5387->5388, 6:+651->652, 7:+651->652, 8:+651->652, 9:+651->652, 10:+651->652, 11:+1776->1777, 12:+2016->2017, 13:+2151->2152, 14:+2185->2186, 15:+2361->2362, 16:+2419->2420, 17:+2490->2491, 18:+2522->2523, 19:+2619->2620, 20:+2639->2640, 21:+2756->2757, 22:+2799->2800, 23:+2827->2828, 24:+3233->3234, 25:+3294->3295, 26:+3378->3379, 27:+3398->3399, 28:+3459->3460, 29:+3528->3529, 30:+3671->3672, 31:+3701->3702, 32:+1888->1889, 33:+3837->3838, 34:+3873->3874, 35:+3924->3925, 36:+4113->4114, 37:+4207->4208, 38:+4252->4253, 39:+2599->2600, 40:+5437->5438, 41:+5453->5454, 42:+5503->5504, 43:+5563->5564, 44:+4378->4379, 45:+4443->4444, 46:+4474->4475, 47:+4499->4500, 48:+3975->3976, 49:+4579->4580, 50:+4607->4608, 51:+4979->4980, 52:+4999->5000, 53:+5073->5074, 54:+5109->5110, 55:+5210->5211, 56:+5253->5254, 57:+5597->5598, 58:+5292->5293, 59:+5947->5948, 60:+2946->2947, 61:+4346->4347, 62:+2736->2737, 63:+4635->4636, 64:+4802->4803, 65:+4825->4826, 66:+5616->5617, 67:+1661->1662, 68:+5632->5633, 69:+3771->3772, 70:+4527->4528, 71:+4551->4552, 72:+4288->4289, 73:+5023->5024, 74:+4025->4026, 75:+3314->3315, 76:+5337->5338, 77:+3161->3162, 78:+5157->5158, 79:+6007->6008, 80:+5655->5656, 81:+3076->3077, 82:+2982->2983, 83:+3185->3186, 84:+6065->6066, 85:+6273->6274, 86:+6090->6091, 87:+6199->6200, 88:+6241->6242, 89:+6257->6258, 90:+6313->6314, 91:+6367->6368, 92:+6391->6392, 93:+4856->4857, 94:+4887->4888, 95:+3029->3030, 96:+6419->6420, 97:+6443->6444, 98:+6463->6464, 99:+6492->6493, 100:+1451->1452, 101:+6516->6517, 102:+5837->5838, 103:+5967->5968, 104:+6548->6549, 105:+1059->1060, 106:+1968->1969, 107:+1261->1262, 108:+3209->3210, 109:+6586->6587, 110:+5903->5904, 111:+6602->6603, 112:+6644->6645, 113:+6687->6688, 114:+6725->6726, 115:+6757->6758, 116:+6797->6798, 117:+6825->6826, 118:+6869->6870, 119:+6915->6916, 120:+6963->6964, 121:+7064->7065, 122:+7374->7375, 123:+2716->2717, 124:+7166->7167, 125:+7190->7191, 126:+7220->7221, 127:+7248->7249, 128:+7592->7593, 129:+7634->7635, 130:+7272->7273, 131:+7462->7463, 132:+7508->7509, 133:+7554->7555, 134:+7573->7574, 135:+7676->7677, 136:+7766->7767, 137:+7794->7795, 138:+7822->7823, 139:+7872->7873, 140:+5991->5992, 141:+3616->3617, 142:+3813->3814, 143:+6031->6032, 144:+5727->5728, 145:+7349->7350, 146:+7888->7889, 147:+7934->7935, 148:+5469->5470, 149:+1916->1917, 150:+8034->8035, 151:+3751->3752, 152:+7721->7722, 153:+858->859, 154:+7314->7315, 155:+8062->8063, 156:+8085->8086, 157:+7438->7439, 158:+8108->8109, 159:+8124->8125
    //   652: aload_0
    //   653: iload_1
    //   654: aload_2
    //   655: aload_3
    //   656: iload 4
    //   658: invokespecial 82	android/os/Binder:onTransact	(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    //   661: ireturn
    //   662: aload_2
    //   663: ldc 25
    //   665: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   668: aload_2
    //   669: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   672: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   675: wide
    //   679: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   682: aload_2
    //   683: invokeinterface 108 2 0
    //   688: checkcast 98	android/content/Intent
    //   691: wide
    //   695: aload_2
    //   696: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   699: wide
    //   703: aload_2
    //   704: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   707: wide
    //   711: aload_2
    //   712: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   715: wide
    //   719: aload_2
    //   720: invokevirtual 116	android/os/Parcel:readInt	()I
    //   723: wide
    //   727: aload_2
    //   728: invokevirtual 116	android/os/Parcel:readInt	()I
    //   731: wide
    //   735: aload_2
    //   736: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   739: wide
    //   743: aload_2
    //   744: invokevirtual 116	android/os/Parcel:readInt	()I
    //   747: ifeq +96 -> 843
    //   750: aload_2
    //   751: invokevirtual 120	android/os/Parcel:readFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   754: wide
    //   758: aload_2
    //   759: invokevirtual 116	android/os/Parcel:readInt	()I
    //   762: ifeq +89 -> 851
    //   765: getstatic 123	android/os/Bundle:CREATOR	Landroid/os/Parcelable$Creator;
    //   768: aload_2
    //   769: invokeinterface 108 2 0
    //   774: checkcast 122	android/os/Bundle
    //   777: wide
    //   781: aload_0
    //   782: wide
    //   786: wide
    //   790: wide
    //   794: wide
    //   798: wide
    //   802: wide
    //   806: wide
    //   810: wide
    //   814: wide
    //   818: wide
    //   822: invokevirtual 127	android/app/ActivityManagerNative:startActivity	(Landroid/app/IApplicationThread;Landroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;Ljava/lang/String;IILjava/lang/String;Landroid/os/ParcelFileDescriptor;Landroid/os/Bundle;)I
    //   825: wide
    //   829: aload_3
    //   830: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   833: aload_3
    //   834: wide
    //   838: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   841: iconst_1
    //   842: ireturn
    //   843: aconst_null
    //   844: wide
    //   848: goto -90 -> 758
    //   851: aconst_null
    //   852: wide
    //   856: goto -75 -> 781
    //   859: aload_2
    //   860: ldc 25
    //   862: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   865: aload_2
    //   866: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   869: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   872: wide
    //   876: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   879: aload_2
    //   880: invokeinterface 108 2 0
    //   885: checkcast 98	android/content/Intent
    //   888: wide
    //   892: aload_2
    //   893: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   896: wide
    //   900: aload_2
    //   901: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   904: wide
    //   908: aload_2
    //   909: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   912: wide
    //   916: aload_2
    //   917: invokevirtual 116	android/os/Parcel:readInt	()I
    //   920: wide
    //   924: aload_2
    //   925: invokevirtual 116	android/os/Parcel:readInt	()I
    //   928: wide
    //   932: aload_2
    //   933: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   936: wide
    //   940: aload_2
    //   941: invokevirtual 116	android/os/Parcel:readInt	()I
    //   944: ifeq +100 -> 1044
    //   947: aload_2
    //   948: invokevirtual 120	android/os/Parcel:readFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   951: wide
    //   955: aload_2
    //   956: invokevirtual 116	android/os/Parcel:readInt	()I
    //   959: ifeq +93 -> 1052
    //   962: getstatic 123	android/os/Bundle:CREATOR	Landroid/os/Parcelable$Creator;
    //   965: aload_2
    //   966: invokeinterface 108 2 0
    //   971: checkcast 122	android/os/Bundle
    //   974: wide
    //   978: aload_0
    //   979: wide
    //   983: wide
    //   987: wide
    //   991: wide
    //   995: wide
    //   999: wide
    //   1003: wide
    //   1007: wide
    //   1011: wide
    //   1015: wide
    //   1019: aload_2
    //   1020: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1023: invokevirtual 138	android/app/ActivityManagerNative:startActivityAsUser	(Landroid/app/IApplicationThread;Landroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;Ljava/lang/String;IILjava/lang/String;Landroid/os/ParcelFileDescriptor;Landroid/os/Bundle;I)I
    //   1026: wide
    //   1030: aload_3
    //   1031: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   1034: aload_3
    //   1035: wide
    //   1039: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   1042: iconst_1
    //   1043: ireturn
    //   1044: aconst_null
    //   1045: wide
    //   1049: goto -94 -> 955
    //   1052: aconst_null
    //   1053: wide
    //   1057: goto -79 -> 978
    //   1060: aload_2
    //   1061: ldc 25
    //   1063: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1066: aload_2
    //   1067: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1070: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   1073: wide
    //   1077: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   1080: aload_2
    //   1081: invokeinterface 108 2 0
    //   1086: checkcast 98	android/content/Intent
    //   1089: wide
    //   1093: aload_2
    //   1094: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   1097: wide
    //   1101: aload_2
    //   1102: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1105: wide
    //   1109: aload_2
    //   1110: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   1113: wide
    //   1117: aload_2
    //   1118: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1121: wide
    //   1125: aload_2
    //   1126: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1129: wide
    //   1133: aload_2
    //   1134: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   1137: wide
    //   1141: aload_2
    //   1142: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1145: ifeq +101 -> 1246
    //   1148: aload_2
    //   1149: invokevirtual 120	android/os/Parcel:readFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   1152: wide
    //   1156: aload_2
    //   1157: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1160: ifeq +94 -> 1254
    //   1163: getstatic 123	android/os/Bundle:CREATOR	Landroid/os/Parcelable$Creator;
    //   1166: aload_2
    //   1167: invokeinterface 108 2 0
    //   1172: checkcast 122	android/os/Bundle
    //   1175: wide
    //   1179: aload_0
    //   1180: wide
    //   1184: wide
    //   1188: wide
    //   1192: wide
    //   1196: wide
    //   1200: wide
    //   1204: wide
    //   1208: wide
    //   1212: wide
    //   1216: wide
    //   1220: aload_2
    //   1221: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1224: invokevirtual 142	android/app/ActivityManagerNative:startActivityAndWait	(Landroid/app/IApplicationThread;Landroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;Ljava/lang/String;IILjava/lang/String;Landroid/os/ParcelFileDescriptor;Landroid/os/Bundle;I)Landroid/app/IActivityManager$WaitResult;
    //   1227: wide
    //   1231: aload_3
    //   1232: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   1235: wide
    //   1239: aload_3
    //   1240: iconst_0
    //   1241: invokevirtual 148	android/app/IActivityManager$WaitResult:writeToParcel	(Landroid/os/Parcel;I)V
    //   1244: iconst_1
    //   1245: ireturn
    //   1246: aconst_null
    //   1247: wide
    //   1251: goto -95 -> 1156
    //   1254: aconst_null
    //   1255: wide
    //   1259: goto -80 -> 1179
    //   1262: aload_2
    //   1263: ldc 25
    //   1265: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1268: aload_2
    //   1269: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1272: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   1275: wide
    //   1279: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   1282: aload_2
    //   1283: invokeinterface 108 2 0
    //   1288: checkcast 98	android/content/Intent
    //   1291: wide
    //   1295: aload_2
    //   1296: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   1299: wide
    //   1303: aload_2
    //   1304: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1307: wide
    //   1311: aload_2
    //   1312: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   1315: wide
    //   1319: aload_2
    //   1320: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1323: wide
    //   1327: aload_2
    //   1328: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1331: wide
    //   1335: getstatic 151	android/content/res/Configuration:CREATOR	Landroid/os/Parcelable$Creator;
    //   1338: aload_2
    //   1339: invokeinterface 108 2 0
    //   1344: checkcast 150	android/content/res/Configuration
    //   1347: wide
    //   1351: aload_2
    //   1352: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1355: ifeq +89 -> 1444
    //   1358: getstatic 123	android/os/Bundle:CREATOR	Landroid/os/Parcelable$Creator;
    //   1361: aload_2
    //   1362: invokeinterface 108 2 0
    //   1367: checkcast 122	android/os/Bundle
    //   1370: wide
    //   1374: aload_2
    //   1375: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1378: wide
    //   1382: aload_0
    //   1383: wide
    //   1387: wide
    //   1391: wide
    //   1395: wide
    //   1399: wide
    //   1403: wide
    //   1407: wide
    //   1411: wide
    //   1415: wide
    //   1419: wide
    //   1423: invokevirtual 155	android/app/ActivityManagerNative:startActivityWithConfig	(Landroid/app/IApplicationThread;Landroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;Ljava/lang/String;IILandroid/content/res/Configuration;Landroid/os/Bundle;I)I
    //   1426: wide
    //   1430: aload_3
    //   1431: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   1434: aload_3
    //   1435: wide
    //   1439: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   1442: iconst_1
    //   1443: ireturn
    //   1444: aconst_null
    //   1445: wide
    //   1449: goto -75 -> 1374
    //   1452: aload_2
    //   1453: ldc 25
    //   1455: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1458: aload_2
    //   1459: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1462: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   1465: wide
    //   1469: getstatic 158	android/content/IntentSender:CREATOR	Landroid/os/Parcelable$Creator;
    //   1472: aload_2
    //   1473: invokeinterface 108 2 0
    //   1478: checkcast 157	android/content/IntentSender
    //   1481: wide
    //   1485: aload_2
    //   1486: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1489: wide
    //   1493: aconst_null
    //   1494: wide
    //   1498: wide
    //   1502: ifeq +19 -> 1521
    //   1505: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   1508: aload_2
    //   1509: invokeinterface 108 2 0
    //   1514: checkcast 98	android/content/Intent
    //   1517: wide
    //   1521: aload_2
    //   1522: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   1525: wide
    //   1529: aload_2
    //   1530: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1533: wide
    //   1537: aload_2
    //   1538: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   1541: wide
    //   1545: aload_2
    //   1546: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1549: wide
    //   1553: aload_2
    //   1554: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1557: wide
    //   1561: aload_2
    //   1562: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1565: wide
    //   1569: aload_2
    //   1570: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1573: ifeq +81 -> 1654
    //   1576: getstatic 123	android/os/Bundle:CREATOR	Landroid/os/Parcelable$Creator;
    //   1579: aload_2
    //   1580: invokeinterface 108 2 0
    //   1585: checkcast 122	android/os/Bundle
    //   1588: wide
    //   1592: aload_0
    //   1593: wide
    //   1597: wide
    //   1601: wide
    //   1605: wide
    //   1609: wide
    //   1613: wide
    //   1617: wide
    //   1621: wide
    //   1625: wide
    //   1629: wide
    //   1633: invokevirtual 162	android/app/ActivityManagerNative:startActivityIntentSender	(Landroid/app/IApplicationThread;Landroid/content/IntentSender;Landroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;Ljava/lang/String;IIILandroid/os/Bundle;)I
    //   1636: wide
    //   1640: aload_3
    //   1641: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   1644: aload_3
    //   1645: wide
    //   1649: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   1652: iconst_1
    //   1653: ireturn
    //   1654: aconst_null
    //   1655: wide
    //   1659: goto -67 -> 1592
    //   1662: aload_2
    //   1663: ldc 25
    //   1665: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1668: aload_2
    //   1669: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1672: wide
    //   1676: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   1679: aload_2
    //   1680: invokeinterface 108 2 0
    //   1685: checkcast 98	android/content/Intent
    //   1688: wide
    //   1692: aload_2
    //   1693: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1696: ifeq +65 -> 1761
    //   1699: getstatic 123	android/os/Bundle:CREATOR	Landroid/os/Parcelable$Creator;
    //   1702: aload_2
    //   1703: invokeinterface 108 2 0
    //   1708: checkcast 122	android/os/Bundle
    //   1711: wide
    //   1715: aload_0
    //   1716: wide
    //   1720: wide
    //   1724: wide
    //   1728: invokevirtual 166	android/app/ActivityManagerNative:startNextMatchingActivity	(Landroid/os/IBinder;Landroid/content/Intent;Landroid/os/Bundle;)Z
    //   1731: wide
    //   1735: aload_3
    //   1736: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   1739: wide
    //   1743: ifeq +26 -> 1769
    //   1746: iconst_1
    //   1747: wide
    //   1751: aload_3
    //   1752: wide
    //   1756: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   1759: iconst_1
    //   1760: ireturn
    //   1761: aconst_null
    //   1762: wide
    //   1766: goto -51 -> 1715
    //   1769: iconst_0
    //   1770: wide
    //   1774: goto -23 -> 1751
    //   1777: aload_2
    //   1778: ldc 25
    //   1780: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1783: aload_2
    //   1784: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1787: wide
    //   1791: aload_2
    //   1792: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1795: wide
    //   1799: aload_2
    //   1800: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1803: wide
    //   1807: aconst_null
    //   1808: wide
    //   1812: wide
    //   1816: ifeq +19 -> 1835
    //   1819: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   1822: aload_2
    //   1823: invokeinterface 108 2 0
    //   1828: checkcast 98	android/content/Intent
    //   1831: wide
    //   1835: aload_0
    //   1836: wide
    //   1840: wide
    //   1844: wide
    //   1848: invokevirtual 170	android/app/ActivityManagerNative:finishActivity	(Landroid/os/IBinder;ILandroid/content/Intent;)Z
    //   1851: wide
    //   1855: aload_3
    //   1856: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   1859: wide
    //   1863: ifeq +18 -> 1881
    //   1866: iconst_1
    //   1867: wide
    //   1871: aload_3
    //   1872: wide
    //   1876: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   1879: iconst_1
    //   1880: ireturn
    //   1881: iconst_0
    //   1882: wide
    //   1886: goto -15 -> 1871
    //   1889: aload_2
    //   1890: ldc 25
    //   1892: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1895: aload_0
    //   1896: aload_2
    //   1897: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1900: aload_2
    //   1901: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   1904: aload_2
    //   1905: invokevirtual 116	android/os/Parcel:readInt	()I
    //   1908: invokevirtual 174	android/app/ActivityManagerNative:finishSubActivity	(Landroid/os/IBinder;Ljava/lang/String;I)V
    //   1911: aload_3
    //   1912: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   1915: iconst_1
    //   1916: ireturn
    //   1917: aload_2
    //   1918: ldc 25
    //   1920: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1923: aload_0
    //   1924: aload_2
    //   1925: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1928: invokevirtual 178	android/app/ActivityManagerNative:finishActivityAffinity	(Landroid/os/IBinder;)Z
    //   1931: wide
    //   1935: aload_3
    //   1936: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   1939: wide
    //   1943: ifeq +18 -> 1961
    //   1946: iconst_1
    //   1947: wide
    //   1951: aload_3
    //   1952: wide
    //   1956: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   1959: iconst_1
    //   1960: ireturn
    //   1961: iconst_0
    //   1962: wide
    //   1966: goto -15 -> 1951
    //   1969: aload_2
    //   1970: ldc 25
    //   1972: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1975: aload_0
    //   1976: aload_2
    //   1977: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1980: invokevirtual 181	android/app/ActivityManagerNative:willActivityBeVisible	(Landroid/os/IBinder;)Z
    //   1983: istore -1
    //   1985: aload_3
    //   1986: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   1989: iload -1
    //   1991: ifeq +18 -> 2009
    //   1994: iconst_1
    //   1995: wide
    //   1999: aload_3
    //   2000: wide
    //   2004: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   2007: iconst_1
    //   2008: ireturn
    //   2009: iconst_0
    //   2010: wide
    //   2014: goto -15 -> 1999
    //   2017: aload_2
    //   2018: ldc 25
    //   2020: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2023: aload_2
    //   2024: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2027: astore -10
    //   2029: aload -10
    //   2031: ifnull +101 -> 2132
    //   2034: aload -10
    //   2036: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   2039: astore -9
    //   2041: aload_2
    //   2042: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   2045: astore -8
    //   2047: aload_2
    //   2048: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2051: astore -7
    //   2053: aload -7
    //   2055: ifnull +83 -> 2138
    //   2058: aload -7
    //   2060: invokestatic 186	android/content/IIntentReceiver$Stub:asInterface	(Landroid/os/IBinder;)Landroid/content/IIntentReceiver;
    //   2063: astore -6
    //   2065: getstatic 189	android/content/IntentFilter:CREATOR	Landroid/os/Parcelable$Creator;
    //   2068: aload_2
    //   2069: invokeinterface 108 2 0
    //   2074: checkcast 188	android/content/IntentFilter
    //   2077: astore -5
    //   2079: aload_2
    //   2080: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   2083: astore -4
    //   2085: aload_2
    //   2086: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2089: istore -3
    //   2091: aload_0
    //   2092: aload -9
    //   2094: aload -8
    //   2096: aload -6
    //   2098: aload -5
    //   2100: aload -4
    //   2102: iload -3
    //   2104: invokevirtual 193	android/app/ActivityManagerNative:registerReceiver	(Landroid/app/IApplicationThread;Ljava/lang/String;Landroid/content/IIntentReceiver;Landroid/content/IntentFilter;Ljava/lang/String;I)Landroid/content/Intent;
    //   2107: astore -2
    //   2109: aload_3
    //   2110: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   2113: aload -2
    //   2115: ifnull +29 -> 2144
    //   2118: aload_3
    //   2119: iconst_1
    //   2120: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   2123: aload -2
    //   2125: aload_3
    //   2126: iconst_0
    //   2127: invokevirtual 194	android/content/Intent:writeToParcel	(Landroid/os/Parcel;I)V
    //   2130: iconst_1
    //   2131: ireturn
    //   2132: aconst_null
    //   2133: astore -9
    //   2135: goto -94 -> 2041
    //   2138: aconst_null
    //   2139: astore -6
    //   2141: goto -76 -> 2065
    //   2144: aload_3
    //   2145: iconst_0
    //   2146: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   2149: goto -19 -> 2130
    //   2152: aload_2
    //   2153: ldc 25
    //   2155: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2158: aload_2
    //   2159: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2162: astore -11
    //   2164: aload -11
    //   2166: ifnonnull +5 -> 2171
    //   2169: iconst_1
    //   2170: ireturn
    //   2171: aload_0
    //   2172: aload -11
    //   2174: invokestatic 186	android/content/IIntentReceiver$Stub:asInterface	(Landroid/os/IBinder;)Landroid/content/IIntentReceiver;
    //   2177: invokevirtual 198	android/app/ActivityManagerNative:unregisterReceiver	(Landroid/content/IIntentReceiver;)V
    //   2180: aload_3
    //   2181: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   2184: iconst_1
    //   2185: ireturn
    //   2186: aload_2
    //   2187: ldc 25
    //   2189: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2192: aload_2
    //   2193: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2196: astore -25
    //   2198: aload -25
    //   2200: ifnull +138 -> 2338
    //   2203: aload -25
    //   2205: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   2208: astore -24
    //   2210: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   2213: aload_2
    //   2214: invokeinterface 108 2 0
    //   2219: checkcast 98	android/content/Intent
    //   2222: astore -23
    //   2224: aload_2
    //   2225: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   2228: astore -22
    //   2230: aload_2
    //   2231: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2234: astore -21
    //   2236: aload -21
    //   2238: ifnull +106 -> 2344
    //   2241: aload -21
    //   2243: invokestatic 186	android/content/IIntentReceiver$Stub:asInterface	(Landroid/os/IBinder;)Landroid/content/IIntentReceiver;
    //   2246: astore -20
    //   2248: aload_2
    //   2249: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2252: istore -19
    //   2254: aload_2
    //   2255: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   2258: astore -18
    //   2260: aload_2
    //   2261: invokevirtual 202	android/os/Parcel:readBundle	()Landroid/os/Bundle;
    //   2264: astore -17
    //   2266: aload_2
    //   2267: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   2270: astore -16
    //   2272: aload_2
    //   2273: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2276: ifeq +74 -> 2350
    //   2279: iconst_1
    //   2280: istore -15
    //   2282: aload_2
    //   2283: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2286: ifeq +70 -> 2356
    //   2289: iconst_1
    //   2290: istore -14
    //   2292: aload_2
    //   2293: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2296: istore -13
    //   2298: aload_0
    //   2299: aload -24
    //   2301: aload -23
    //   2303: aload -22
    //   2305: aload -20
    //   2307: iload -19
    //   2309: aload -18
    //   2311: aload -17
    //   2313: aload -16
    //   2315: iload -15
    //   2317: iload -14
    //   2319: iload -13
    //   2321: invokevirtual 203	android/app/ActivityManagerNative:broadcastIntent	(Landroid/app/IApplicationThread;Landroid/content/Intent;Ljava/lang/String;Landroid/content/IIntentReceiver;ILjava/lang/String;Landroid/os/Bundle;Ljava/lang/String;ZZI)I
    //   2324: istore -12
    //   2326: aload_3
    //   2327: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   2330: aload_3
    //   2331: iload -12
    //   2333: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   2336: iconst_1
    //   2337: ireturn
    //   2338: aconst_null
    //   2339: astore -24
    //   2341: goto -131 -> 2210
    //   2344: aconst_null
    //   2345: astore -20
    //   2347: goto -99 -> 2248
    //   2350: iconst_0
    //   2351: istore -15
    //   2353: goto -71 -> 2282
    //   2356: iconst_0
    //   2357: istore -14
    //   2359: goto -67 -> 2292
    //   2362: aload_2
    //   2363: ldc 25
    //   2365: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2368: aload_2
    //   2369: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2372: astore -27
    //   2374: aload -27
    //   2376: ifnull +38 -> 2414
    //   2379: aload -27
    //   2381: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   2384: astore -26
    //   2386: aload_0
    //   2387: aload -26
    //   2389: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   2392: aload_2
    //   2393: invokeinterface 108 2 0
    //   2398: checkcast 98	android/content/Intent
    //   2401: aload_2
    //   2402: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2405: invokevirtual 207	android/app/ActivityManagerNative:unbroadcastIntent	(Landroid/app/IApplicationThread;Landroid/content/Intent;I)V
    //   2408: aload_3
    //   2409: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   2412: iconst_1
    //   2413: ireturn
    //   2414: aconst_null
    //   2415: astore -26
    //   2417: goto -31 -> 2386
    //   2420: aload_2
    //   2421: ldc 25
    //   2423: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2426: aload_2
    //   2427: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2430: astore -32
    //   2432: aload_2
    //   2433: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2436: istore -31
    //   2438: aload_2
    //   2439: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   2442: astore -30
    //   2444: aload_2
    //   2445: invokevirtual 202	android/os/Parcel:readBundle	()Landroid/os/Bundle;
    //   2448: astore -29
    //   2450: aload_2
    //   2451: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2454: ifeq +31 -> 2485
    //   2457: iconst_1
    //   2458: istore -28
    //   2460: aload -32
    //   2462: ifnull +17 -> 2479
    //   2465: aload_0
    //   2466: aload -32
    //   2468: iload -31
    //   2470: aload -30
    //   2472: aload -29
    //   2474: iload -28
    //   2476: invokevirtual 211	android/app/ActivityManagerNative:finishReceiver	(Landroid/os/IBinder;ILjava/lang/String;Landroid/os/Bundle;Z)V
    //   2479: aload_3
    //   2480: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   2483: iconst_1
    //   2484: ireturn
    //   2485: iconst_0
    //   2486: istore -28
    //   2488: goto -28 -> 2460
    //   2491: aload_2
    //   2492: ldc 25
    //   2494: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2497: aload_2
    //   2498: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2501: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   2504: astore -33
    //   2506: aload -33
    //   2508: ifnull +9 -> 2517
    //   2511: aload_0
    //   2512: aload -33
    //   2514: invokevirtual 215	android/app/ActivityManagerNative:attachApplication	(Landroid/app/IApplicationThread;)V
    //   2517: aload_3
    //   2518: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   2521: iconst_1
    //   2522: ireturn
    //   2523: aload_2
    //   2524: ldc 25
    //   2526: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2529: aload_2
    //   2530: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2533: astore -37
    //   2535: aload_2
    //   2536: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2539: istore -36
    //   2541: aconst_null
    //   2542: astore -35
    //   2544: iload -36
    //   2546: ifeq +17 -> 2563
    //   2549: getstatic 151	android/content/res/Configuration:CREATOR	Landroid/os/Parcelable$Creator;
    //   2552: aload_2
    //   2553: invokeinterface 108 2 0
    //   2558: checkcast 150	android/content/res/Configuration
    //   2561: astore -35
    //   2563: aload_2
    //   2564: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2567: ifeq +27 -> 2594
    //   2570: iconst_1
    //   2571: istore -34
    //   2573: aload -37
    //   2575: ifnull +13 -> 2588
    //   2578: aload_0
    //   2579: aload -37
    //   2581: aload -35
    //   2583: iload -34
    //   2585: invokevirtual 219	android/app/ActivityManagerNative:activityIdle	(Landroid/os/IBinder;Landroid/content/res/Configuration;Z)V
    //   2588: aload_3
    //   2589: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   2592: iconst_1
    //   2593: ireturn
    //   2594: iconst_0
    //   2595: istore -34
    //   2597: goto -24 -> 2573
    //   2600: aload_2
    //   2601: ldc 25
    //   2603: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2606: aload_0
    //   2607: aload_2
    //   2608: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2611: invokevirtual 222	android/app/ActivityManagerNative:activityResumed	(Landroid/os/IBinder;)V
    //   2614: aload_3
    //   2615: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   2618: iconst_1
    //   2619: ireturn
    //   2620: aload_2
    //   2621: ldc 25
    //   2623: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2626: aload_0
    //   2627: aload_2
    //   2628: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2631: invokevirtual 225	android/app/ActivityManagerNative:activityPaused	(Landroid/os/IBinder;)V
    //   2634: aload_3
    //   2635: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   2638: iconst_1
    //   2639: ireturn
    //   2640: aload_2
    //   2641: ldc 25
    //   2643: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2646: aload_2
    //   2647: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2650: astore -41
    //   2652: aload_2
    //   2653: invokevirtual 202	android/os/Parcel:readBundle	()Landroid/os/Bundle;
    //   2656: astore -40
    //   2658: aload_2
    //   2659: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2662: ifeq +49 -> 2711
    //   2665: getstatic 228	android/graphics/Bitmap:CREATOR	Landroid/os/Parcelable$Creator;
    //   2668: aload_2
    //   2669: invokeinterface 108 2 0
    //   2674: checkcast 227	android/graphics/Bitmap
    //   2677: astore -39
    //   2679: getstatic 233	android/text/TextUtils:CHAR_SEQUENCE_CREATOR	Landroid/os/Parcelable$Creator;
    //   2682: aload_2
    //   2683: invokeinterface 108 2 0
    //   2688: checkcast 235	java/lang/CharSequence
    //   2691: astore -38
    //   2693: aload_0
    //   2694: aload -41
    //   2696: aload -40
    //   2698: aload -39
    //   2700: aload -38
    //   2702: invokevirtual 239	android/app/ActivityManagerNative:activityStopped	(Landroid/os/IBinder;Landroid/os/Bundle;Landroid/graphics/Bitmap;Ljava/lang/CharSequence;)V
    //   2705: aload_3
    //   2706: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   2709: iconst_1
    //   2710: ireturn
    //   2711: aconst_null
    //   2712: astore -39
    //   2714: goto -35 -> 2679
    //   2717: aload_2
    //   2718: ldc 25
    //   2720: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2723: aload_0
    //   2724: aload_2
    //   2725: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2728: invokevirtual 242	android/app/ActivityManagerNative:activitySlept	(Landroid/os/IBinder;)V
    //   2731: aload_3
    //   2732: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   2735: iconst_1
    //   2736: ireturn
    //   2737: aload_2
    //   2738: ldc 25
    //   2740: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2743: aload_0
    //   2744: aload_2
    //   2745: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2748: invokevirtual 245	android/app/ActivityManagerNative:activityDestroyed	(Landroid/os/IBinder;)V
    //   2751: aload_3
    //   2752: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   2755: iconst_1
    //   2756: ireturn
    //   2757: aload_2
    //   2758: ldc 25
    //   2760: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2763: aload_2
    //   2764: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2767: astore -43
    //   2769: aload -43
    //   2771: ifnull +23 -> 2794
    //   2774: aload_0
    //   2775: aload -43
    //   2777: invokevirtual 249	android/app/ActivityManagerNative:getCallingPackage	(Landroid/os/IBinder;)Ljava/lang/String;
    //   2780: astore -42
    //   2782: aload_3
    //   2783: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   2786: aload_3
    //   2787: aload -42
    //   2789: invokevirtual 252	android/os/Parcel:writeString	(Ljava/lang/String;)V
    //   2792: iconst_1
    //   2793: ireturn
    //   2794: aconst_null
    //   2795: astore -42
    //   2797: goto -15 -> 2782
    //   2800: aload_2
    //   2801: ldc 25
    //   2803: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2806: aload_0
    //   2807: aload_2
    //   2808: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2811: invokevirtual 256	android/app/ActivityManagerNative:getCallingActivity	(Landroid/os/IBinder;)Landroid/content/ComponentName;
    //   2814: astore -44
    //   2816: aload_3
    //   2817: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   2820: aload -44
    //   2822: aload_3
    //   2823: invokestatic 261	android/content/ComponentName:writeToParcel	(Landroid/content/ComponentName;Landroid/os/Parcel;)V
    //   2826: iconst_1
    //   2827: ireturn
    //   2828: aload_2
    //   2829: ldc 25
    //   2831: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2834: aload_2
    //   2835: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2838: istore -51
    //   2840: aload_2
    //   2841: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2844: istore -50
    //   2846: aload_2
    //   2847: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2850: astore -49
    //   2852: aload -49
    //   2854: ifnull +79 -> 2933
    //   2857: aload -49
    //   2859: invokestatic 266	android/app/IThumbnailReceiver$Stub:asInterface	(Landroid/os/IBinder;)Landroid/app/IThumbnailReceiver;
    //   2862: astore -48
    //   2864: aload_0
    //   2865: iload -51
    //   2867: iload -50
    //   2869: aload -48
    //   2871: invokevirtual 270	android/app/ActivityManagerNative:getTasks	(IILandroid/app/IThumbnailReceiver;)Ljava/util/List;
    //   2874: astore -47
    //   2876: aload_3
    //   2877: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   2880: aload -47
    //   2882: ifnull +57 -> 2939
    //   2885: aload -47
    //   2887: invokeinterface 275 1 0
    //   2892: istore -46
    //   2894: aload_3
    //   2895: iload -46
    //   2897: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   2900: iconst_0
    //   2901: istore -45
    //   2903: iload -45
    //   2905: iload -46
    //   2907: if_icmpge +38 -> 2945
    //   2910: aload -47
    //   2912: iload -45
    //   2914: invokeinterface 278 2 0
    //   2919: checkcast 280	android/app/ActivityManager$RunningTaskInfo
    //   2922: aload_3
    //   2923: iconst_0
    //   2924: invokevirtual 281	android/app/ActivityManager$RunningTaskInfo:writeToParcel	(Landroid/os/Parcel;I)V
    //   2927: iinc -45 1
    //   2930: goto -27 -> 2903
    //   2933: aconst_null
    //   2934: astore -48
    //   2936: goto -72 -> 2864
    //   2939: iconst_m1
    //   2940: istore -46
    //   2942: goto -48 -> 2894
    //   2945: iconst_1
    //   2946: ireturn
    //   2947: aload_2
    //   2948: ldc 25
    //   2950: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2953: aload_0
    //   2954: aload_2
    //   2955: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2958: aload_2
    //   2959: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2962: aload_2
    //   2963: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2966: invokevirtual 285	android/app/ActivityManagerNative:getRecentTasks	(III)Ljava/util/List;
    //   2969: astore -52
    //   2971: aload_3
    //   2972: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   2975: aload_3
    //   2976: aload -52
    //   2978: invokevirtual 289	android/os/Parcel:writeTypedList	(Ljava/util/List;)V
    //   2981: iconst_1
    //   2982: ireturn
    //   2983: aload_2
    //   2984: ldc 25
    //   2986: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2989: aload_0
    //   2990: aload_2
    //   2991: invokevirtual 116	android/os/Parcel:readInt	()I
    //   2994: invokevirtual 293	android/app/ActivityManagerNative:getTaskThumbnails	(I)Landroid/app/ActivityManager$TaskThumbnails;
    //   2997: astore -53
    //   2999: aload_3
    //   3000: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3003: aload -53
    //   3005: ifnull +17 -> 3022
    //   3008: aload_3
    //   3009: iconst_1
    //   3010: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   3013: aload -53
    //   3015: aload_3
    //   3016: iconst_0
    //   3017: invokevirtual 296	android/app/ActivityManager$TaskThumbnails:writeToParcel	(Landroid/os/Parcel;I)V
    //   3020: iconst_1
    //   3021: ireturn
    //   3022: aload_3
    //   3023: iconst_0
    //   3024: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   3027: goto -7 -> 3020
    //   3030: aload_2
    //   3031: ldc 25
    //   3033: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3036: aload_0
    //   3037: aload_2
    //   3038: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3041: invokevirtual 300	android/app/ActivityManagerNative:getTaskTopThumbnail	(I)Landroid/graphics/Bitmap;
    //   3044: astore -54
    //   3046: aload_3
    //   3047: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3050: aload -54
    //   3052: ifnull +17 -> 3069
    //   3055: aload_3
    //   3056: iconst_1
    //   3057: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   3060: aload -54
    //   3062: aload_3
    //   3063: iconst_0
    //   3064: invokevirtual 301	android/graphics/Bitmap:writeToParcel	(Landroid/os/Parcel;I)V
    //   3067: iconst_1
    //   3068: ireturn
    //   3069: aload_3
    //   3070: iconst_0
    //   3071: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   3074: goto -7 -> 3067
    //   3077: aload_2
    //   3078: ldc 25
    //   3080: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3083: aload_0
    //   3084: aload_2
    //   3085: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3088: aload_2
    //   3089: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3092: invokevirtual 305	android/app/ActivityManagerNative:getServices	(II)Ljava/util/List;
    //   3095: astore -57
    //   3097: aload_3
    //   3098: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3101: aload -57
    //   3103: ifnull +51 -> 3154
    //   3106: aload -57
    //   3108: invokeinterface 275 1 0
    //   3113: istore -56
    //   3115: aload_3
    //   3116: iload -56
    //   3118: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   3121: iconst_0
    //   3122: istore -55
    //   3124: iload -55
    //   3126: iload -56
    //   3128: if_icmpge +32 -> 3160
    //   3131: aload -57
    //   3133: iload -55
    //   3135: invokeinterface 278 2 0
    //   3140: checkcast 307	android/app/ActivityManager$RunningServiceInfo
    //   3143: aload_3
    //   3144: iconst_0
    //   3145: invokevirtual 308	android/app/ActivityManager$RunningServiceInfo:writeToParcel	(Landroid/os/Parcel;I)V
    //   3148: iinc -55 1
    //   3151: goto -27 -> 3124
    //   3154: iconst_m1
    //   3155: istore -56
    //   3157: goto -42 -> 3115
    //   3160: iconst_1
    //   3161: ireturn
    //   3162: aload_2
    //   3163: ldc 25
    //   3165: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3168: aload_0
    //   3169: invokevirtual 312	android/app/ActivityManagerNative:getProcessesInErrorState	()Ljava/util/List;
    //   3172: astore -58
    //   3174: aload_3
    //   3175: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3178: aload_3
    //   3179: aload -58
    //   3181: invokevirtual 289	android/os/Parcel:writeTypedList	(Ljava/util/List;)V
    //   3184: iconst_1
    //   3185: ireturn
    //   3186: aload_2
    //   3187: ldc 25
    //   3189: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3192: aload_0
    //   3193: invokevirtual 315	android/app/ActivityManagerNative:getRunningAppProcesses	()Ljava/util/List;
    //   3196: astore -59
    //   3198: aload_3
    //   3199: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3202: aload_3
    //   3203: aload -59
    //   3205: invokevirtual 289	android/os/Parcel:writeTypedList	(Ljava/util/List;)V
    //   3208: iconst_1
    //   3209: ireturn
    //   3210: aload_2
    //   3211: ldc 25
    //   3213: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3216: aload_0
    //   3217: invokevirtual 318	android/app/ActivityManagerNative:getRunningExternalApplications	()Ljava/util/List;
    //   3220: astore -60
    //   3222: aload_3
    //   3223: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3226: aload_3
    //   3227: aload -60
    //   3229: invokevirtual 289	android/os/Parcel:writeTypedList	(Ljava/util/List;)V
    //   3232: iconst_1
    //   3233: ireturn
    //   3234: aload_2
    //   3235: ldc 25
    //   3237: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3240: aload_2
    //   3241: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3244: istore -63
    //   3246: aload_2
    //   3247: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3250: istore -62
    //   3252: aload_2
    //   3253: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3256: ifeq +33 -> 3289
    //   3259: getstatic 123	android/os/Bundle:CREATOR	Landroid/os/Parcelable$Creator;
    //   3262: aload_2
    //   3263: invokeinterface 108 2 0
    //   3268: checkcast 122	android/os/Bundle
    //   3271: astore -61
    //   3273: aload_0
    //   3274: iload -63
    //   3276: iload -62
    //   3278: aload -61
    //   3280: invokevirtual 322	android/app/ActivityManagerNative:moveTaskToFront	(IILandroid/os/Bundle;)V
    //   3283: aload_3
    //   3284: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3287: iconst_1
    //   3288: ireturn
    //   3289: aconst_null
    //   3290: astore -61
    //   3292: goto -19 -> 3273
    //   3295: aload_2
    //   3296: ldc 25
    //   3298: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3301: aload_0
    //   3302: aload_2
    //   3303: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3306: invokevirtual 325	android/app/ActivityManagerNative:moveTaskToBack	(I)V
    //   3309: aload_3
    //   3310: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3313: iconst_1
    //   3314: ireturn
    //   3315: aload_2
    //   3316: ldc 25
    //   3318: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3321: aload_2
    //   3322: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   3325: astore -67
    //   3327: aload_2
    //   3328: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3331: ifeq +36 -> 3367
    //   3334: iconst_1
    //   3335: istore -66
    //   3337: aload_0
    //   3338: aload -67
    //   3340: iload -66
    //   3342: invokevirtual 329	android/app/ActivityManagerNative:moveActivityTaskToBack	(Landroid/os/IBinder;Z)Z
    //   3345: istore -65
    //   3347: aload_3
    //   3348: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3351: iload -65
    //   3353: ifeq +20 -> 3373
    //   3356: iconst_1
    //   3357: istore -64
    //   3359: aload_3
    //   3360: iload -64
    //   3362: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   3365: iconst_1
    //   3366: ireturn
    //   3367: iconst_0
    //   3368: istore -66
    //   3370: goto -33 -> 3337
    //   3373: iconst_0
    //   3374: istore -64
    //   3376: goto -17 -> 3359
    //   3379: aload_2
    //   3380: ldc 25
    //   3382: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3385: aload_0
    //   3386: aload_2
    //   3387: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3390: invokevirtual 332	android/app/ActivityManagerNative:moveTaskBackwards	(I)V
    //   3393: aload_3
    //   3394: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3397: iconst_1
    //   3398: ireturn
    //   3399: aload_2
    //   3400: ldc 25
    //   3402: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3405: aload_2
    //   3406: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   3409: astore -70
    //   3411: aload_2
    //   3412: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3415: ifeq +33 -> 3448
    //   3418: iconst_1
    //   3419: istore -69
    //   3421: aload -70
    //   3423: ifnull +31 -> 3454
    //   3426: aload_0
    //   3427: aload -70
    //   3429: iload -69
    //   3431: invokevirtual 336	android/app/ActivityManagerNative:getTaskForActivity	(Landroid/os/IBinder;Z)I
    //   3434: istore -68
    //   3436: aload_3
    //   3437: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3440: aload_3
    //   3441: iload -68
    //   3443: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   3446: iconst_1
    //   3447: ireturn
    //   3448: iconst_0
    //   3449: istore -69
    //   3451: goto -30 -> 3421
    //   3454: iconst_m1
    //   3455: istore -68
    //   3457: goto -21 -> 3436
    //   3460: aload_2
    //   3461: ldc 25
    //   3463: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3466: aload_2
    //   3467: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   3470: astore -73
    //   3472: aload_2
    //   3473: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3476: ifeq +47 -> 3523
    //   3479: getstatic 228	android/graphics/Bitmap:CREATOR	Landroid/os/Parcelable$Creator;
    //   3482: aload_2
    //   3483: invokeinterface 108 2 0
    //   3488: checkcast 227	android/graphics/Bitmap
    //   3491: astore -72
    //   3493: getstatic 233	android/text/TextUtils:CHAR_SEQUENCE_CREATOR	Landroid/os/Parcelable$Creator;
    //   3496: aload_2
    //   3497: invokeinterface 108 2 0
    //   3502: checkcast 235	java/lang/CharSequence
    //   3505: astore -71
    //   3507: aload_0
    //   3508: aload -73
    //   3510: aload -72
    //   3512: aload -71
    //   3514: invokevirtual 340	android/app/ActivityManagerNative:reportThumbnail	(Landroid/os/IBinder;Landroid/graphics/Bitmap;Ljava/lang/CharSequence;)V
    //   3517: aload_3
    //   3518: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3521: iconst_1
    //   3522: ireturn
    //   3523: aconst_null
    //   3524: astore -72
    //   3526: goto -33 -> 3493
    //   3529: aload_2
    //   3530: ldc 25
    //   3532: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3535: aload_2
    //   3536: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   3539: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   3542: astore -78
    //   3544: aload_2
    //   3545: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   3548: astore -77
    //   3550: aload_2
    //   3551: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3554: istore -76
    //   3556: aload_2
    //   3557: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3560: ifeq +43 -> 3603
    //   3563: iconst_1
    //   3564: istore -75
    //   3566: aload_0
    //   3567: aload -78
    //   3569: aload -77
    //   3571: iload -76
    //   3573: iload -75
    //   3575: invokevirtual 344	android/app/ActivityManagerNative:getContentProvider	(Landroid/app/IApplicationThread;Ljava/lang/String;IZ)Landroid/app/IActivityManager$ContentProviderHolder;
    //   3578: astore -74
    //   3580: aload_3
    //   3581: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3584: aload -74
    //   3586: ifnull +23 -> 3609
    //   3589: aload_3
    //   3590: iconst_1
    //   3591: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   3594: aload -74
    //   3596: aload_3
    //   3597: iconst_0
    //   3598: invokevirtual 347	android/app/IActivityManager$ContentProviderHolder:writeToParcel	(Landroid/os/Parcel;I)V
    //   3601: iconst_1
    //   3602: ireturn
    //   3603: iconst_0
    //   3604: istore -75
    //   3606: goto -40 -> 3566
    //   3609: aload_3
    //   3610: iconst_0
    //   3611: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   3614: goto -13 -> 3601
    //   3617: aload_2
    //   3618: ldc 25
    //   3620: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3623: aload_0
    //   3624: aload_2
    //   3625: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   3628: aload_2
    //   3629: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3632: aload_2
    //   3633: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   3636: invokevirtual 351	android/app/ActivityManagerNative:getContentProviderExternal	(Ljava/lang/String;ILandroid/os/IBinder;)Landroid/app/IActivityManager$ContentProviderHolder;
    //   3639: astore -79
    //   3641: aload_3
    //   3642: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3645: aload -79
    //   3647: ifnull +17 -> 3664
    //   3650: aload_3
    //   3651: iconst_1
    //   3652: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   3655: aload -79
    //   3657: aload_3
    //   3658: iconst_0
    //   3659: invokevirtual 347	android/app/IActivityManager$ContentProviderHolder:writeToParcel	(Landroid/os/Parcel;I)V
    //   3662: iconst_1
    //   3663: ireturn
    //   3664: aload_3
    //   3665: iconst_0
    //   3666: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   3669: goto -7 -> 3662
    //   3672: aload_2
    //   3673: ldc 25
    //   3675: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3678: aload_0
    //   3679: aload_2
    //   3680: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   3683: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   3686: aload_2
    //   3687: getstatic 352	android/app/IActivityManager$ContentProviderHolder:CREATOR	Landroid/os/Parcelable$Creator;
    //   3690: invokevirtual 356	android/os/Parcel:createTypedArrayList	(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;
    //   3693: invokevirtual 360	android/app/ActivityManagerNative:publishContentProviders	(Landroid/app/IApplicationThread;Ljava/util/List;)V
    //   3696: aload_3
    //   3697: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3700: iconst_1
    //   3701: ireturn
    //   3702: aload_2
    //   3703: ldc 25
    //   3705: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3708: aload_0
    //   3709: aload_2
    //   3710: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   3713: aload_2
    //   3714: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3717: aload_2
    //   3718: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3721: invokevirtual 364	android/app/ActivityManagerNative:refContentProvider	(Landroid/os/IBinder;II)Z
    //   3724: istore -81
    //   3726: aload_3
    //   3727: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3730: iload -81
    //   3732: ifeq +14 -> 3746
    //   3735: iconst_1
    //   3736: istore -80
    //   3738: aload_3
    //   3739: iload -80
    //   3741: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   3744: iconst_1
    //   3745: ireturn
    //   3746: iconst_0
    //   3747: istore -80
    //   3749: goto -11 -> 3738
    //   3752: aload_2
    //   3753: ldc 25
    //   3755: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3758: aload_0
    //   3759: aload_2
    //   3760: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   3763: invokevirtual 367	android/app/ActivityManagerNative:unstableProviderDied	(Landroid/os/IBinder;)V
    //   3766: aload_3
    //   3767: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3770: iconst_1
    //   3771: ireturn
    //   3772: aload_2
    //   3773: ldc 25
    //   3775: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3778: aload_2
    //   3779: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   3782: astore -83
    //   3784: aload_2
    //   3785: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3788: ifeq +20 -> 3808
    //   3791: iconst_1
    //   3792: istore -82
    //   3794: aload_0
    //   3795: aload -83
    //   3797: iload -82
    //   3799: invokevirtual 371	android/app/ActivityManagerNative:removeContentProvider	(Landroid/os/IBinder;Z)V
    //   3802: aload_3
    //   3803: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3806: iconst_1
    //   3807: ireturn
    //   3808: iconst_0
    //   3809: istore -82
    //   3811: goto -17 -> 3794
    //   3814: aload_2
    //   3815: ldc 25
    //   3817: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3820: aload_0
    //   3821: aload_2
    //   3822: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   3825: aload_2
    //   3826: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   3829: invokevirtual 375	android/app/ActivityManagerNative:removeContentProviderExternal	(Ljava/lang/String;Landroid/os/IBinder;)V
    //   3832: aload_3
    //   3833: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3836: iconst_1
    //   3837: ireturn
    //   3838: aload_2
    //   3839: ldc 25
    //   3841: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3844: aload_0
    //   3845: getstatic 376	android/content/ComponentName:CREATOR	Landroid/os/Parcelable$Creator;
    //   3848: aload_2
    //   3849: invokeinterface 108 2 0
    //   3854: checkcast 258	android/content/ComponentName
    //   3857: invokevirtual 380	android/app/ActivityManagerNative:getRunningServiceControlPanel	(Landroid/content/ComponentName;)Landroid/app/PendingIntent;
    //   3860: astore -84
    //   3862: aload_3
    //   3863: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3866: aload -84
    //   3868: aload_3
    //   3869: invokestatic 384	android/app/PendingIntent:writePendingIntentOrNullToParcel	(Landroid/app/PendingIntent;Landroid/os/Parcel;)V
    //   3872: iconst_1
    //   3873: ireturn
    //   3874: aload_2
    //   3875: ldc 25
    //   3877: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3880: aload_0
    //   3881: aload_2
    //   3882: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   3885: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   3888: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   3891: aload_2
    //   3892: invokeinterface 108 2 0
    //   3897: checkcast 98	android/content/Intent
    //   3900: aload_2
    //   3901: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   3904: aload_2
    //   3905: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3908: invokevirtual 388	android/app/ActivityManagerNative:startService	(Landroid/app/IApplicationThread;Landroid/content/Intent;Ljava/lang/String;I)Landroid/content/ComponentName;
    //   3911: astore -85
    //   3913: aload_3
    //   3914: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3917: aload -85
    //   3919: aload_3
    //   3920: invokestatic 261	android/content/ComponentName:writeToParcel	(Landroid/content/ComponentName;Landroid/os/Parcel;)V
    //   3923: iconst_1
    //   3924: ireturn
    //   3925: aload_2
    //   3926: ldc 25
    //   3928: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3931: aload_0
    //   3932: aload_2
    //   3933: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   3936: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   3939: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   3942: aload_2
    //   3943: invokeinterface 108 2 0
    //   3948: checkcast 98	android/content/Intent
    //   3951: aload_2
    //   3952: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   3955: aload_2
    //   3956: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3959: invokevirtual 392	android/app/ActivityManagerNative:stopService	(Landroid/app/IApplicationThread;Landroid/content/Intent;Ljava/lang/String;I)I
    //   3962: istore -86
    //   3964: aload_3
    //   3965: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   3968: aload_3
    //   3969: iload -86
    //   3971: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   3974: iconst_1
    //   3975: ireturn
    //   3976: aload_2
    //   3977: ldc 25
    //   3979: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   3982: aload_0
    //   3983: aload_2
    //   3984: invokestatic 396	android/content/ComponentName:readFromParcel	(Landroid/os/Parcel;)Landroid/content/ComponentName;
    //   3987: aload_2
    //   3988: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   3991: aload_2
    //   3992: invokevirtual 116	android/os/Parcel:readInt	()I
    //   3995: invokevirtual 400	android/app/ActivityManagerNative:stopServiceToken	(Landroid/content/ComponentName;Landroid/os/IBinder;I)Z
    //   3998: istore -88
    //   4000: aload_3
    //   4001: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4004: iload -88
    //   4006: ifeq +14 -> 4020
    //   4009: iconst_1
    //   4010: istore -87
    //   4012: aload_3
    //   4013: iload -87
    //   4015: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   4018: iconst_1
    //   4019: ireturn
    //   4020: iconst_0
    //   4021: istore -87
    //   4023: goto -11 -> 4012
    //   4026: aload_2
    //   4027: ldc 25
    //   4029: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4032: aload_2
    //   4033: invokestatic 396	android/content/ComponentName:readFromParcel	(Landroid/os/Parcel;)Landroid/content/ComponentName;
    //   4036: astore -94
    //   4038: aload_2
    //   4039: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4042: astore -93
    //   4044: aload_2
    //   4045: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4048: istore -92
    //   4050: aload_2
    //   4051: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4054: istore -91
    //   4056: aconst_null
    //   4057: astore -90
    //   4059: iload -91
    //   4061: ifeq +17 -> 4078
    //   4064: getstatic 403	android/app/Notification:CREATOR	Landroid/os/Parcelable$Creator;
    //   4067: aload_2
    //   4068: invokeinterface 108 2 0
    //   4073: checkcast 402	android/app/Notification
    //   4076: astore -90
    //   4078: aload_2
    //   4079: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4082: ifeq +26 -> 4108
    //   4085: iconst_1
    //   4086: istore -89
    //   4088: aload_0
    //   4089: aload -94
    //   4091: aload -93
    //   4093: iload -92
    //   4095: aload -90
    //   4097: iload -89
    //   4099: invokevirtual 407	android/app/ActivityManagerNative:setServiceForeground	(Landroid/content/ComponentName;Landroid/os/IBinder;ILandroid/app/Notification;Z)V
    //   4102: aload_3
    //   4103: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4106: iconst_1
    //   4107: ireturn
    //   4108: iconst_0
    //   4109: istore -89
    //   4111: goto -23 -> 4088
    //   4114: aload_2
    //   4115: ldc 25
    //   4117: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4120: aload_2
    //   4121: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4124: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   4127: astore -102
    //   4129: aload_2
    //   4130: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4133: astore -101
    //   4135: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   4138: aload_2
    //   4139: invokeinterface 108 2 0
    //   4144: checkcast 98	android/content/Intent
    //   4147: astore -100
    //   4149: aload_2
    //   4150: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   4153: astore -99
    //   4155: aload_2
    //   4156: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4159: astore -98
    //   4161: aload_2
    //   4162: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4165: istore -97
    //   4167: aload_2
    //   4168: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4171: istore -96
    //   4173: aload_0
    //   4174: aload -102
    //   4176: aload -101
    //   4178: aload -100
    //   4180: aload -99
    //   4182: aload -98
    //   4184: invokestatic 412	android/app/IServiceConnection$Stub:asInterface	(Landroid/os/IBinder;)Landroid/app/IServiceConnection;
    //   4187: iload -97
    //   4189: iload -96
    //   4191: invokevirtual 416	android/app/ActivityManagerNative:bindService	(Landroid/app/IApplicationThread;Landroid/os/IBinder;Landroid/content/Intent;Ljava/lang/String;Landroid/app/IServiceConnection;II)I
    //   4194: istore -95
    //   4196: aload_3
    //   4197: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4200: aload_3
    //   4201: iload -95
    //   4203: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   4206: iconst_1
    //   4207: ireturn
    //   4208: aload_2
    //   4209: ldc 25
    //   4211: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4214: aload_0
    //   4215: aload_2
    //   4216: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4219: invokestatic 412	android/app/IServiceConnection$Stub:asInterface	(Landroid/os/IBinder;)Landroid/app/IServiceConnection;
    //   4222: invokevirtual 420	android/app/ActivityManagerNative:unbindService	(Landroid/app/IServiceConnection;)Z
    //   4225: istore -104
    //   4227: aload_3
    //   4228: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4231: iload -104
    //   4233: ifeq +14 -> 4247
    //   4236: iconst_1
    //   4237: istore -103
    //   4239: aload_3
    //   4240: iload -103
    //   4242: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   4245: iconst_1
    //   4246: ireturn
    //   4247: iconst_0
    //   4248: istore -103
    //   4250: goto -11 -> 4239
    //   4253: aload_2
    //   4254: ldc 25
    //   4256: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4259: aload_0
    //   4260: aload_2
    //   4261: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4264: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   4267: aload_2
    //   4268: invokeinterface 108 2 0
    //   4273: checkcast 98	android/content/Intent
    //   4276: aload_2
    //   4277: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4280: invokevirtual 424	android/app/ActivityManagerNative:publishService	(Landroid/os/IBinder;Landroid/content/Intent;Landroid/os/IBinder;)V
    //   4283: aload_3
    //   4284: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4287: iconst_1
    //   4288: ireturn
    //   4289: aload_2
    //   4290: ldc 25
    //   4292: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4295: aload_2
    //   4296: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4299: astore -107
    //   4301: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   4304: aload_2
    //   4305: invokeinterface 108 2 0
    //   4310: checkcast 98	android/content/Intent
    //   4313: astore -106
    //   4315: aload_2
    //   4316: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4319: ifeq +22 -> 4341
    //   4322: iconst_1
    //   4323: istore -105
    //   4325: aload_0
    //   4326: aload -107
    //   4328: aload -106
    //   4330: iload -105
    //   4332: invokevirtual 428	android/app/ActivityManagerNative:unbindFinished	(Landroid/os/IBinder;Landroid/content/Intent;Z)V
    //   4335: aload_3
    //   4336: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4339: iconst_1
    //   4340: ireturn
    //   4341: iconst_0
    //   4342: istore -105
    //   4344: goto -19 -> 4325
    //   4347: aload_2
    //   4348: ldc 25
    //   4350: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4353: aload_0
    //   4354: aload_2
    //   4355: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4358: aload_2
    //   4359: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4362: aload_2
    //   4363: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4366: aload_2
    //   4367: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4370: invokevirtual 432	android/app/ActivityManagerNative:serviceDoneExecuting	(Landroid/os/IBinder;III)V
    //   4373: aload_3
    //   4374: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4377: iconst_1
    //   4378: ireturn
    //   4379: aload_2
    //   4380: ldc 25
    //   4382: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4385: aload_0
    //   4386: aload_2
    //   4387: invokestatic 396	android/content/ComponentName:readFromParcel	(Landroid/os/Parcel;)Landroid/content/ComponentName;
    //   4390: aload_2
    //   4391: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   4394: aload_2
    //   4395: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4398: aload_2
    //   4399: invokevirtual 202	android/os/Parcel:readBundle	()Landroid/os/Bundle;
    //   4402: aload_2
    //   4403: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4406: invokestatic 437	android/app/IInstrumentationWatcher$Stub:asInterface	(Landroid/os/IBinder;)Landroid/app/IInstrumentationWatcher;
    //   4409: aload_2
    //   4410: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4413: invokevirtual 441	android/app/ActivityManagerNative:startInstrumentation	(Landroid/content/ComponentName;Ljava/lang/String;ILandroid/os/Bundle;Landroid/app/IInstrumentationWatcher;I)Z
    //   4416: istore -109
    //   4418: aload_3
    //   4419: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4422: iload -109
    //   4424: ifeq +14 -> 4438
    //   4427: iconst_1
    //   4428: istore -108
    //   4430: aload_3
    //   4431: iload -108
    //   4433: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   4436: iconst_1
    //   4437: ireturn
    //   4438: iconst_0
    //   4439: istore -108
    //   4441: goto -11 -> 4430
    //   4444: aload_2
    //   4445: ldc 25
    //   4447: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4450: aload_0
    //   4451: aload_2
    //   4452: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4455: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   4458: aload_2
    //   4459: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4462: aload_2
    //   4463: invokevirtual 202	android/os/Parcel:readBundle	()Landroid/os/Bundle;
    //   4466: invokevirtual 445	android/app/ActivityManagerNative:finishInstrumentation	(Landroid/app/IApplicationThread;ILandroid/os/Bundle;)V
    //   4469: aload_3
    //   4470: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4473: iconst_1
    //   4474: ireturn
    //   4475: aload_2
    //   4476: ldc 25
    //   4478: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4481: aload_0
    //   4482: invokevirtual 449	android/app/ActivityManagerNative:getConfiguration	()Landroid/content/res/Configuration;
    //   4485: astore -110
    //   4487: aload_3
    //   4488: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4491: aload -110
    //   4493: aload_3
    //   4494: iconst_0
    //   4495: invokevirtual 450	android/content/res/Configuration:writeToParcel	(Landroid/os/Parcel;I)V
    //   4498: iconst_1
    //   4499: ireturn
    //   4500: aload_2
    //   4501: ldc 25
    //   4503: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4506: aload_0
    //   4507: getstatic 151	android/content/res/Configuration:CREATOR	Landroid/os/Parcelable$Creator;
    //   4510: aload_2
    //   4511: invokeinterface 108 2 0
    //   4516: checkcast 150	android/content/res/Configuration
    //   4519: invokevirtual 454	android/app/ActivityManagerNative:updateConfiguration	(Landroid/content/res/Configuration;)V
    //   4522: aload_3
    //   4523: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4526: iconst_1
    //   4527: ireturn
    //   4528: aload_2
    //   4529: ldc 25
    //   4531: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4534: aload_0
    //   4535: aload_2
    //   4536: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4539: aload_2
    //   4540: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4543: invokevirtual 458	android/app/ActivityManagerNative:setRequestedOrientation	(Landroid/os/IBinder;I)V
    //   4546: aload_3
    //   4547: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4550: iconst_1
    //   4551: ireturn
    //   4552: aload_2
    //   4553: ldc 25
    //   4555: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4558: aload_0
    //   4559: aload_2
    //   4560: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4563: invokevirtual 462	android/app/ActivityManagerNative:getRequestedOrientation	(Landroid/os/IBinder;)I
    //   4566: istore -111
    //   4568: aload_3
    //   4569: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4572: aload_3
    //   4573: iload -111
    //   4575: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   4578: iconst_1
    //   4579: ireturn
    //   4580: aload_2
    //   4581: ldc 25
    //   4583: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4586: aload_0
    //   4587: aload_2
    //   4588: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4591: invokevirtual 465	android/app/ActivityManagerNative:getActivityClassForToken	(Landroid/os/IBinder;)Landroid/content/ComponentName;
    //   4594: astore -112
    //   4596: aload_3
    //   4597: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4600: aload -112
    //   4602: aload_3
    //   4603: invokestatic 261	android/content/ComponentName:writeToParcel	(Landroid/content/ComponentName;Landroid/os/Parcel;)V
    //   4606: iconst_1
    //   4607: ireturn
    //   4608: aload_2
    //   4609: ldc 25
    //   4611: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4614: aload_2
    //   4615: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4618: astore -113
    //   4620: aload_3
    //   4621: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4624: aload_3
    //   4625: aload_0
    //   4626: aload -113
    //   4628: invokevirtual 468	android/app/ActivityManagerNative:getPackageForToken	(Landroid/os/IBinder;)Ljava/lang/String;
    //   4631: invokevirtual 252	android/os/Parcel:writeString	(Ljava/lang/String;)V
    //   4634: iconst_1
    //   4635: ireturn
    //   4636: aload_2
    //   4637: ldc 25
    //   4639: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4642: aload_2
    //   4643: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4646: istore -125
    //   4648: aload_2
    //   4649: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   4652: astore -124
    //   4654: aload_2
    //   4655: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4658: astore -123
    //   4660: aload_2
    //   4661: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   4664: astore -122
    //   4666: aload_2
    //   4667: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4670: istore -121
    //   4672: aload_2
    //   4673: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4676: ifeq +106 -> 4782
    //   4679: aload_2
    //   4680: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   4683: invokevirtual 472	android/os/Parcel:createTypedArray	(Landroid/os/Parcelable$Creator;)[Ljava/lang/Object;
    //   4686: checkcast 474	[Landroid/content/Intent;
    //   4689: astore -120
    //   4691: aload_2
    //   4692: invokevirtual 478	android/os/Parcel:createStringArray	()[Ljava/lang/String;
    //   4695: astore -119
    //   4697: aload_2
    //   4698: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4701: istore -118
    //   4703: aload_2
    //   4704: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4707: ifeq +84 -> 4791
    //   4710: getstatic 123	android/os/Bundle:CREATOR	Landroid/os/Parcelable$Creator;
    //   4713: aload_2
    //   4714: invokeinterface 108 2 0
    //   4719: checkcast 122	android/os/Bundle
    //   4722: astore -117
    //   4724: aload_2
    //   4725: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4728: istore -116
    //   4730: aload_0
    //   4731: iload -125
    //   4733: aload -124
    //   4735: aload -123
    //   4737: aload -122
    //   4739: iload -121
    //   4741: aload -120
    //   4743: aload -119
    //   4745: iload -118
    //   4747: aload -117
    //   4749: iload -116
    //   4751: invokevirtual 482	android/app/ActivityManagerNative:getIntentSender	(ILjava/lang/String;Landroid/os/IBinder;Ljava/lang/String;I[Landroid/content/Intent;[Ljava/lang/String;ILandroid/os/Bundle;I)Landroid/content/IIntentSender;
    //   4754: astore -115
    //   4756: aload_3
    //   4757: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4760: aload -115
    //   4762: ifnull +35 -> 4797
    //   4765: aload -115
    //   4767: invokeinterface 486 1 0
    //   4772: astore -114
    //   4774: aload_3
    //   4775: aload -114
    //   4777: invokevirtual 489	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
    //   4780: iconst_1
    //   4781: ireturn
    //   4782: aconst_null
    //   4783: astore -120
    //   4785: aconst_null
    //   4786: astore -119
    //   4788: goto -91 -> 4697
    //   4791: aconst_null
    //   4792: astore -117
    //   4794: goto -70 -> 4724
    //   4797: aconst_null
    //   4798: astore -114
    //   4800: goto -26 -> 4774
    //   4803: aload_2
    //   4804: ldc 25
    //   4806: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4809: aload_0
    //   4810: aload_2
    //   4811: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4814: invokestatic 494	android/content/IIntentSender$Stub:asInterface	(Landroid/os/IBinder;)Landroid/content/IIntentSender;
    //   4817: invokevirtual 497	android/app/ActivityManagerNative:cancelIntentSender	(Landroid/content/IIntentSender;)V
    //   4820: aload_3
    //   4821: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4824: iconst_1
    //   4825: ireturn
    //   4826: aload_2
    //   4827: ldc 25
    //   4829: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4832: aload_0
    //   4833: aload_2
    //   4834: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4837: invokestatic 494	android/content/IIntentSender$Stub:asInterface	(Landroid/os/IBinder;)Landroid/content/IIntentSender;
    //   4840: invokevirtual 501	android/app/ActivityManagerNative:getPackageForIntentSender	(Landroid/content/IIntentSender;)Ljava/lang/String;
    //   4843: astore -126
    //   4845: aload_3
    //   4846: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4849: aload_3
    //   4850: aload -126
    //   4852: invokevirtual 252	android/os/Parcel:writeString	(Ljava/lang/String;)V
    //   4855: iconst_1
    //   4856: ireturn
    //   4857: aload_2
    //   4858: ldc 25
    //   4860: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4863: aload_0
    //   4864: aload_2
    //   4865: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   4868: invokestatic 494	android/content/IIntentSender$Stub:asInterface	(Landroid/os/IBinder;)Landroid/content/IIntentSender;
    //   4871: invokevirtual 505	android/app/ActivityManagerNative:getUidForIntentSender	(Landroid/content/IIntentSender;)I
    //   4874: istore -127
    //   4876: aload_3
    //   4877: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4880: aload_3
    //   4881: iload -127
    //   4883: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   4886: iconst_1
    //   4887: ireturn
    //   4888: aload_2
    //   4889: ldc 25
    //   4891: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4894: aload_2
    //   4895: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4898: istore 123
    //   4900: aload_2
    //   4901: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4904: istore 124
    //   4906: aload_2
    //   4907: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4910: istore 125
    //   4912: aload_2
    //   4913: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4916: ifeq +52 -> 4968
    //   4919: iconst_1
    //   4920: istore 126
    //   4922: aload_2
    //   4923: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4926: ifeq +48 -> 4974
    //   4929: iconst_1
    //   4930: istore 127
    //   4932: aload_0
    //   4933: iload 123
    //   4935: iload 124
    //   4937: iload 125
    //   4939: iload 126
    //   4941: iload 127
    //   4943: aload_2
    //   4944: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   4947: aload_2
    //   4948: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   4951: invokevirtual 509	android/app/ActivityManagerNative:handleIncomingUser	(IIIZZLjava/lang/String;Ljava/lang/String;)I
    //   4954: istore -128
    //   4956: aload_3
    //   4957: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4960: aload_3
    //   4961: iload -128
    //   4963: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   4966: iconst_1
    //   4967: ireturn
    //   4968: iconst_0
    //   4969: istore 126
    //   4971: goto -49 -> 4922
    //   4974: iconst_0
    //   4975: istore 127
    //   4977: goto -45 -> 4932
    //   4980: aload_2
    //   4981: ldc 25
    //   4983: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   4986: aload_0
    //   4987: aload_2
    //   4988: invokevirtual 116	android/os/Parcel:readInt	()I
    //   4991: invokevirtual 512	android/app/ActivityManagerNative:setProcessLimit	(I)V
    //   4994: aload_3
    //   4995: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   4998: iconst_1
    //   4999: ireturn
    //   5000: aload_2
    //   5001: ldc 25
    //   5003: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5006: aload_0
    //   5007: invokevirtual 515	android/app/ActivityManagerNative:getProcessLimit	()I
    //   5010: istore 122
    //   5012: aload_3
    //   5013: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5016: aload_3
    //   5017: iload 122
    //   5019: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   5022: iconst_1
    //   5023: ireturn
    //   5024: aload_2
    //   5025: ldc 25
    //   5027: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5030: aload_2
    //   5031: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   5034: astore 119
    //   5036: aload_2
    //   5037: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5040: istore 120
    //   5042: aload_2
    //   5043: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5046: ifeq +22 -> 5068
    //   5049: iconst_1
    //   5050: istore 121
    //   5052: aload_0
    //   5053: aload 119
    //   5055: iload 120
    //   5057: iload 121
    //   5059: invokevirtual 519	android/app/ActivityManagerNative:setProcessForeground	(Landroid/os/IBinder;IZ)V
    //   5062: aload_3
    //   5063: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5066: iconst_1
    //   5067: ireturn
    //   5068: iconst_0
    //   5069: istore 121
    //   5071: goto -19 -> 5052
    //   5074: aload_2
    //   5075: ldc 25
    //   5077: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5080: aload_0
    //   5081: aload_2
    //   5082: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   5085: aload_2
    //   5086: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5089: aload_2
    //   5090: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5093: invokevirtual 523	android/app/ActivityManagerNative:checkPermission	(Ljava/lang/String;II)I
    //   5096: istore 118
    //   5098: aload_3
    //   5099: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5102: aload_3
    //   5103: iload 118
    //   5105: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   5108: iconst_1
    //   5109: ireturn
    //   5110: aload_2
    //   5111: ldc 25
    //   5113: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5116: aload_0
    //   5117: getstatic 526	android/net/Uri:CREATOR	Landroid/os/Parcelable$Creator;
    //   5120: aload_2
    //   5121: invokeinterface 108 2 0
    //   5126: checkcast 525	android/net/Uri
    //   5129: aload_2
    //   5130: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5133: aload_2
    //   5134: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5137: aload_2
    //   5138: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5141: invokevirtual 530	android/app/ActivityManagerNative:checkUriPermission	(Landroid/net/Uri;III)I
    //   5144: istore 117
    //   5146: aload_3
    //   5147: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5150: aload_3
    //   5151: iload 117
    //   5153: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   5156: iconst_1
    //   5157: ireturn
    //   5158: aload_2
    //   5159: ldc 25
    //   5161: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5164: aload_0
    //   5165: aload_2
    //   5166: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   5169: aload_2
    //   5170: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   5173: invokestatic 535	android/content/pm/IPackageDataObserver$Stub:asInterface	(Landroid/os/IBinder;)Landroid/content/pm/IPackageDataObserver;
    //   5176: aload_2
    //   5177: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5180: invokevirtual 539	android/app/ActivityManagerNative:clearApplicationUserData	(Ljava/lang/String;Landroid/content/pm/IPackageDataObserver;I)Z
    //   5183: istore 115
    //   5185: aload_3
    //   5186: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5189: iload 115
    //   5191: ifeq +14 -> 5205
    //   5194: iconst_1
    //   5195: istore 116
    //   5197: aload_3
    //   5198: iload 116
    //   5200: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   5203: iconst_1
    //   5204: ireturn
    //   5205: iconst_0
    //   5206: istore 116
    //   5208: goto -11 -> 5197
    //   5211: aload_2
    //   5212: ldc 25
    //   5214: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5217: aload_0
    //   5218: aload_2
    //   5219: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   5222: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   5225: aload_2
    //   5226: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   5229: getstatic 526	android/net/Uri:CREATOR	Landroid/os/Parcelable$Creator;
    //   5232: aload_2
    //   5233: invokeinterface 108 2 0
    //   5238: checkcast 525	android/net/Uri
    //   5241: aload_2
    //   5242: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5245: invokevirtual 543	android/app/ActivityManagerNative:grantUriPermission	(Landroid/app/IApplicationThread;Ljava/lang/String;Landroid/net/Uri;I)V
    //   5248: aload_3
    //   5249: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5252: iconst_1
    //   5253: ireturn
    //   5254: aload_2
    //   5255: ldc 25
    //   5257: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5260: aload_0
    //   5261: aload_2
    //   5262: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   5265: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   5268: getstatic 526	android/net/Uri:CREATOR	Landroid/os/Parcelable$Creator;
    //   5271: aload_2
    //   5272: invokeinterface 108 2 0
    //   5277: checkcast 525	android/net/Uri
    //   5280: aload_2
    //   5281: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5284: invokevirtual 547	android/app/ActivityManagerNative:revokeUriPermission	(Landroid/app/IApplicationThread;Landroid/net/Uri;I)V
    //   5287: aload_3
    //   5288: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5291: iconst_1
    //   5292: ireturn
    //   5293: aload_2
    //   5294: ldc 25
    //   5296: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5299: aload_2
    //   5300: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   5303: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   5306: astore 113
    //   5308: aload_2
    //   5309: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5312: ifeq +20 -> 5332
    //   5315: iconst_1
    //   5316: istore 114
    //   5318: aload_0
    //   5319: aload 113
    //   5321: iload 114
    //   5323: invokevirtual 551	android/app/ActivityManagerNative:showWaitingForDebugger	(Landroid/app/IApplicationThread;Z)V
    //   5326: aload_3
    //   5327: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5330: iconst_1
    //   5331: ireturn
    //   5332: iconst_0
    //   5333: istore 114
    //   5335: goto -17 -> 5318
    //   5338: aload_2
    //   5339: ldc 25
    //   5341: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5344: new 553	android/app/ActivityManager$MemoryInfo
    //   5347: dup
    //   5348: invokespecial 554	android/app/ActivityManager$MemoryInfo:<init>	()V
    //   5351: astore 112
    //   5353: aload_0
    //   5354: aload 112
    //   5356: invokevirtual 558	android/app/ActivityManagerNative:getMemoryInfo	(Landroid/app/ActivityManager$MemoryInfo;)V
    //   5359: aload_3
    //   5360: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5363: aload 112
    //   5365: aload_3
    //   5366: iconst_0
    //   5367: invokevirtual 559	android/app/ActivityManager$MemoryInfo:writeToParcel	(Landroid/os/Parcel;I)V
    //   5370: iconst_1
    //   5371: ireturn
    //   5372: aload_2
    //   5373: ldc 25
    //   5375: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5378: aload_0
    //   5379: invokevirtual 562	android/app/ActivityManagerNative:unhandledBack	()V
    //   5382: aload_3
    //   5383: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5386: iconst_1
    //   5387: ireturn
    //   5388: aload_2
    //   5389: ldc 25
    //   5391: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5394: aload_0
    //   5395: aload_2
    //   5396: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   5399: invokestatic 566	android/net/Uri:parse	(Ljava/lang/String;)Landroid/net/Uri;
    //   5402: invokevirtual 570	android/app/ActivityManagerNative:openContentUri	(Landroid/net/Uri;)Landroid/os/ParcelFileDescriptor;
    //   5405: astore 111
    //   5407: aload_3
    //   5408: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5411: aload 111
    //   5413: ifnull +17 -> 5430
    //   5416: aload_3
    //   5417: iconst_1
    //   5418: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   5421: aload 111
    //   5423: aload_3
    //   5424: iconst_1
    //   5425: invokevirtual 573	android/os/ParcelFileDescriptor:writeToParcel	(Landroid/os/Parcel;I)V
    //   5428: iconst_1
    //   5429: ireturn
    //   5430: aload_3
    //   5431: iconst_0
    //   5432: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   5435: goto -7 -> 5428
    //   5438: aload_2
    //   5439: ldc 25
    //   5441: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5444: aload_0
    //   5445: invokevirtual 576	android/app/ActivityManagerNative:goingToSleep	()V
    //   5448: aload_3
    //   5449: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5452: iconst_1
    //   5453: ireturn
    //   5454: aload_2
    //   5455: ldc 25
    //   5457: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5460: aload_0
    //   5461: invokevirtual 579	android/app/ActivityManagerNative:wakingUp	()V
    //   5464: aload_3
    //   5465: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5468: iconst_1
    //   5469: ireturn
    //   5470: aload_2
    //   5471: ldc 25
    //   5473: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5476: aload_2
    //   5477: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5480: ifeq +18 -> 5498
    //   5483: iconst_1
    //   5484: istore 110
    //   5486: aload_0
    //   5487: iload 110
    //   5489: invokevirtual 583	android/app/ActivityManagerNative:setLockScreenShown	(Z)V
    //   5492: aload_3
    //   5493: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5496: iconst_1
    //   5497: ireturn
    //   5498: iconst_0
    //   5499: istore 110
    //   5501: goto -15 -> 5486
    //   5504: aload_2
    //   5505: ldc 25
    //   5507: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5510: aload_2
    //   5511: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   5514: astore 107
    //   5516: aload_2
    //   5517: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5520: ifeq +32 -> 5552
    //   5523: iconst_1
    //   5524: istore 108
    //   5526: aload_2
    //   5527: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5530: ifeq +28 -> 5558
    //   5533: iconst_1
    //   5534: istore 109
    //   5536: aload_0
    //   5537: aload 107
    //   5539: iload 108
    //   5541: iload 109
    //   5543: invokevirtual 587	android/app/ActivityManagerNative:setDebugApp	(Ljava/lang/String;ZZ)V
    //   5546: aload_3
    //   5547: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5550: iconst_1
    //   5551: ireturn
    //   5552: iconst_0
    //   5553: istore 108
    //   5555: goto -29 -> 5526
    //   5558: iconst_0
    //   5559: istore 109
    //   5561: goto -25 -> 5536
    //   5564: aload_2
    //   5565: ldc 25
    //   5567: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5570: aload_2
    //   5571: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5574: ifeq +18 -> 5592
    //   5577: iconst_1
    //   5578: istore 106
    //   5580: aload_0
    //   5581: iload 106
    //   5583: invokevirtual 590	android/app/ActivityManagerNative:setAlwaysFinish	(Z)V
    //   5586: aload_3
    //   5587: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5590: iconst_1
    //   5591: ireturn
    //   5592: iconst_0
    //   5593: istore 106
    //   5595: goto -15 -> 5580
    //   5598: aload_2
    //   5599: ldc 25
    //   5601: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5604: aload_0
    //   5605: aload_2
    //   5606: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   5609: invokestatic 595	android/app/IActivityController$Stub:asInterface	(Landroid/os/IBinder;)Landroid/app/IActivityController;
    //   5612: invokevirtual 599	android/app/ActivityManagerNative:setActivityController	(Landroid/app/IActivityController;)V
    //   5615: iconst_1
    //   5616: ireturn
    //   5617: aload_2
    //   5618: ldc 25
    //   5620: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5623: aload_0
    //   5624: invokevirtual 602	android/app/ActivityManagerNative:enterSafeMode	()V
    //   5627: aload_3
    //   5628: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5631: iconst_1
    //   5632: ireturn
    //   5633: aload_2
    //   5634: ldc 25
    //   5636: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5639: aload_0
    //   5640: aload_2
    //   5641: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   5644: invokestatic 494	android/content/IIntentSender$Stub:asInterface	(Landroid/os/IBinder;)Landroid/content/IIntentSender;
    //   5647: invokevirtual 603	android/app/ActivityManagerNative:noteWakeupAlarm	(Landroid/content/IIntentSender;)V
    //   5650: aload_3
    //   5651: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5654: iconst_1
    //   5655: ireturn
    //   5656: aload_2
    //   5657: ldc 25
    //   5659: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5662: aload_2
    //   5663: invokevirtual 607	android/os/Parcel:createIntArray	()[I
    //   5666: astore 101
    //   5668: aload_2
    //   5669: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   5672: astore 102
    //   5674: aload_2
    //   5675: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5678: ifeq +38 -> 5716
    //   5681: iconst_1
    //   5682: istore 103
    //   5684: aload_0
    //   5685: aload 101
    //   5687: aload 102
    //   5689: iload 103
    //   5691: invokevirtual 611	android/app/ActivityManagerNative:killPids	([ILjava/lang/String;Z)Z
    //   5694: istore 104
    //   5696: aload_3
    //   5697: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5700: iload 104
    //   5702: ifeq +20 -> 5722
    //   5705: iconst_1
    //   5706: istore 105
    //   5708: aload_3
    //   5709: iload 105
    //   5711: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   5714: iconst_1
    //   5715: ireturn
    //   5716: iconst_0
    //   5717: istore 103
    //   5719: goto -35 -> 5684
    //   5722: iconst_0
    //   5723: istore 105
    //   5725: goto -17 -> 5708
    //   5728: aload_2
    //   5729: ldc 25
    //   5731: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5734: aload_0
    //   5735: aload_2
    //   5736: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   5739: invokevirtual 615	android/app/ActivityManagerNative:killProcessesBelowForeground	(Ljava/lang/String;)Z
    //   5742: istore 99
    //   5744: aload_3
    //   5745: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5748: iload 99
    //   5750: ifeq +14 -> 5764
    //   5753: iconst_1
    //   5754: istore 100
    //   5756: aload_3
    //   5757: iload 100
    //   5759: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   5762: iconst_1
    //   5763: ireturn
    //   5764: iconst_0
    //   5765: istore 100
    //   5767: goto -11 -> 5756
    //   5770: aload_2
    //   5771: ldc 25
    //   5773: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5776: aload_0
    //   5777: aload_2
    //   5778: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   5781: aload_2
    //   5782: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   5785: aload_2
    //   5786: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   5789: aload_2
    //   5790: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   5793: invokevirtual 619	android/app/ActivityManagerNative:startRunning	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   5796: aload_3
    //   5797: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5800: iconst_1
    //   5801: ireturn
    //   5802: aload_2
    //   5803: ldc 25
    //   5805: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5808: aload_2
    //   5809: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   5812: astore 97
    //   5814: new 621	android/app/ApplicationErrorReport$CrashInfo
    //   5817: dup
    //   5818: aload_2
    //   5819: invokespecial 624	android/app/ApplicationErrorReport$CrashInfo:<init>	(Landroid/os/Parcel;)V
    //   5822: astore 98
    //   5824: aload_0
    //   5825: aload 97
    //   5827: aload 98
    //   5829: invokevirtual 628	android/app/ActivityManagerNative:handleApplicationCrash	(Landroid/os/IBinder;Landroid/app/ApplicationErrorReport$CrashInfo;)V
    //   5832: aload_3
    //   5833: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5836: iconst_1
    //   5837: ireturn
    //   5838: aload_2
    //   5839: ldc 25
    //   5841: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5844: aload_2
    //   5845: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   5848: astore 92
    //   5850: aload_2
    //   5851: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   5854: astore 93
    //   5856: new 621	android/app/ApplicationErrorReport$CrashInfo
    //   5859: dup
    //   5860: aload_2
    //   5861: invokespecial 624	android/app/ApplicationErrorReport$CrashInfo:<init>	(Landroid/os/Parcel;)V
    //   5864: astore 94
    //   5866: aload_0
    //   5867: aload 92
    //   5869: aload 93
    //   5871: aload 94
    //   5873: invokevirtual 632	android/app/ActivityManagerNative:handleApplicationWtf	(Landroid/os/IBinder;Ljava/lang/String;Landroid/app/ApplicationErrorReport$CrashInfo;)Z
    //   5876: istore 95
    //   5878: aload_3
    //   5879: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5882: iload 95
    //   5884: ifeq +14 -> 5898
    //   5887: iconst_1
    //   5888: istore 96
    //   5890: aload_3
    //   5891: iload 96
    //   5893: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   5896: iconst_1
    //   5897: ireturn
    //   5898: iconst_0
    //   5899: istore 96
    //   5901: goto -11 -> 5890
    //   5904: aload_2
    //   5905: ldc 25
    //   5907: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5910: aload_2
    //   5911: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   5914: astore 89
    //   5916: aload_2
    //   5917: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5920: istore 90
    //   5922: new 634	android/os/StrictMode$ViolationInfo
    //   5925: dup
    //   5926: aload_2
    //   5927: invokespecial 635	android/os/StrictMode$ViolationInfo:<init>	(Landroid/os/Parcel;)V
    //   5930: astore 91
    //   5932: aload_0
    //   5933: aload 89
    //   5935: iload 90
    //   5937: aload 91
    //   5939: invokevirtual 639	android/app/ActivityManagerNative:handleApplicationStrictModeViolation	(Landroid/os/IBinder;ILandroid/os/StrictMode$ViolationInfo;)V
    //   5942: aload_3
    //   5943: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5946: iconst_1
    //   5947: ireturn
    //   5948: aload_2
    //   5949: ldc 25
    //   5951: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5954: aload_0
    //   5955: aload_2
    //   5956: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5959: invokevirtual 642	android/app/ActivityManagerNative:signalPersistentProcesses	(I)V
    //   5962: aload_3
    //   5963: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5966: iconst_1
    //   5967: ireturn
    //   5968: aload_2
    //   5969: ldc 25
    //   5971: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5974: aload_0
    //   5975: aload_2
    //   5976: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   5979: aload_2
    //   5980: invokevirtual 116	android/os/Parcel:readInt	()I
    //   5983: invokevirtual 646	android/app/ActivityManagerNative:killBackgroundProcesses	(Ljava/lang/String;I)V
    //   5986: aload_3
    //   5987: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   5990: iconst_1
    //   5991: ireturn
    //   5992: aload_2
    //   5993: ldc 25
    //   5995: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   5998: aload_0
    //   5999: invokevirtual 649	android/app/ActivityManagerNative:killAllBackgroundProcesses	()V
    //   6002: aload_3
    //   6003: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6006: iconst_1
    //   6007: ireturn
    //   6008: aload_2
    //   6009: ldc 25
    //   6011: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6014: aload_0
    //   6015: aload_2
    //   6016: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   6019: aload_2
    //   6020: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6023: invokevirtual 652	android/app/ActivityManagerNative:forceStopPackage	(Ljava/lang/String;I)V
    //   6026: aload_3
    //   6027: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6030: iconst_1
    //   6031: ireturn
    //   6032: aload_2
    //   6033: ldc 25
    //   6035: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6038: new 654	android/app/ActivityManager$RunningAppProcessInfo
    //   6041: dup
    //   6042: invokespecial 655	android/app/ActivityManager$RunningAppProcessInfo:<init>	()V
    //   6045: astore 88
    //   6047: aload_0
    //   6048: aload 88
    //   6050: invokevirtual 659	android/app/ActivityManagerNative:getMyMemoryState	(Landroid/app/ActivityManager$RunningAppProcessInfo;)V
    //   6053: aload_3
    //   6054: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6057: aload 88
    //   6059: aload_3
    //   6060: iconst_0
    //   6061: invokevirtual 660	android/app/ActivityManager$RunningAppProcessInfo:writeToParcel	(Landroid/os/Parcel;I)V
    //   6064: iconst_1
    //   6065: ireturn
    //   6066: aload_2
    //   6067: ldc 25
    //   6069: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6072: aload_0
    //   6073: invokevirtual 664	android/app/ActivityManagerNative:getDeviceConfigurationInfo	()Landroid/content/pm/ConfigurationInfo;
    //   6076: astore 87
    //   6078: aload_3
    //   6079: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6082: aload 87
    //   6084: aload_3
    //   6085: iconst_0
    //   6086: invokevirtual 667	android/content/pm/ConfigurationInfo:writeToParcel	(Landroid/os/Parcel;I)V
    //   6089: iconst_1
    //   6090: ireturn
    //   6091: aload_2
    //   6092: ldc 25
    //   6094: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6097: aload_2
    //   6098: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   6101: astore 79
    //   6103: aload_2
    //   6104: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6107: istore 80
    //   6109: aload_2
    //   6110: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6113: ifeq +69 -> 6182
    //   6116: iconst_1
    //   6117: istore 81
    //   6119: aload_2
    //   6120: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6123: istore 82
    //   6125: aload_2
    //   6126: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   6129: astore 83
    //   6131: aload_2
    //   6132: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6135: ifeq +53 -> 6188
    //   6138: aload_2
    //   6139: invokevirtual 120	android/os/Parcel:readFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   6142: astore 84
    //   6144: aload_0
    //   6145: aload 79
    //   6147: iload 80
    //   6149: iload 81
    //   6151: aload 83
    //   6153: aload 84
    //   6155: iload 82
    //   6157: invokevirtual 671	android/app/ActivityManagerNative:profileControl	(Ljava/lang/String;IZLjava/lang/String;Landroid/os/ParcelFileDescriptor;I)Z
    //   6160: istore 85
    //   6162: aload_3
    //   6163: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6166: iload 85
    //   6168: ifeq +26 -> 6194
    //   6171: iconst_1
    //   6172: istore 86
    //   6174: aload_3
    //   6175: iload 86
    //   6177: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   6180: iconst_1
    //   6181: ireturn
    //   6182: iconst_0
    //   6183: istore 81
    //   6185: goto -66 -> 6119
    //   6188: aconst_null
    //   6189: astore 84
    //   6191: goto -47 -> 6144
    //   6194: iconst_0
    //   6195: istore 86
    //   6197: goto -23 -> 6174
    //   6200: aload_2
    //   6201: ldc 25
    //   6203: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6206: aload_0
    //   6207: aload_2
    //   6208: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6211: invokevirtual 675	android/app/ActivityManagerNative:shutdown	(I)Z
    //   6214: istore 77
    //   6216: aload_3
    //   6217: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6220: iload 77
    //   6222: ifeq +14 -> 6236
    //   6225: iconst_1
    //   6226: istore 78
    //   6228: aload_3
    //   6229: iload 78
    //   6231: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   6234: iconst_1
    //   6235: ireturn
    //   6236: iconst_0
    //   6237: istore 78
    //   6239: goto -11 -> 6228
    //   6242: aload_2
    //   6243: ldc 25
    //   6245: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6248: aload_0
    //   6249: invokevirtual 678	android/app/ActivityManagerNative:stopAppSwitches	()V
    //   6252: aload_3
    //   6253: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6256: iconst_1
    //   6257: ireturn
    //   6258: aload_2
    //   6259: ldc 25
    //   6261: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6264: aload_0
    //   6265: invokevirtual 681	android/app/ActivityManagerNative:resumeAppSwitches	()V
    //   6268: aload_3
    //   6269: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6272: iconst_1
    //   6273: ireturn
    //   6274: aload_2
    //   6275: ldc 25
    //   6277: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6280: aload_0
    //   6281: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   6284: aload_2
    //   6285: invokeinterface 108 2 0
    //   6290: checkcast 98	android/content/Intent
    //   6293: aload_2
    //   6294: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   6297: invokevirtual 685	android/app/ActivityManagerNative:peekService	(Landroid/content/Intent;Ljava/lang/String;)Landroid/os/IBinder;
    //   6300: astore 76
    //   6302: aload_3
    //   6303: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6306: aload_3
    //   6307: aload 76
    //   6309: invokevirtual 489	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
    //   6312: iconst_1
    //   6313: ireturn
    //   6314: aload_2
    //   6315: ldc 25
    //   6317: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6320: aload_0
    //   6321: getstatic 688	android/content/pm/ApplicationInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   6324: aload_2
    //   6325: invokeinterface 108 2 0
    //   6330: checkcast 687	android/content/pm/ApplicationInfo
    //   6333: aload_2
    //   6334: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6337: invokevirtual 692	android/app/ActivityManagerNative:bindBackupAgent	(Landroid/content/pm/ApplicationInfo;I)Z
    //   6340: istore 74
    //   6342: aload_3
    //   6343: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6346: iload 74
    //   6348: ifeq +14 -> 6362
    //   6351: iconst_1
    //   6352: istore 75
    //   6354: aload_3
    //   6355: iload 75
    //   6357: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   6360: iconst_1
    //   6361: ireturn
    //   6362: iconst_0
    //   6363: istore 75
    //   6365: goto -11 -> 6354
    //   6368: aload_2
    //   6369: ldc 25
    //   6371: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6374: aload_0
    //   6375: aload_2
    //   6376: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   6379: aload_2
    //   6380: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   6383: invokevirtual 695	android/app/ActivityManagerNative:backupAgentCreated	(Ljava/lang/String;Landroid/os/IBinder;)V
    //   6386: aload_3
    //   6387: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6390: iconst_1
    //   6391: ireturn
    //   6392: aload_2
    //   6393: ldc 25
    //   6395: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6398: aload_0
    //   6399: getstatic 688	android/content/pm/ApplicationInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   6402: aload_2
    //   6403: invokeinterface 108 2 0
    //   6408: checkcast 687	android/content/pm/ApplicationInfo
    //   6411: invokevirtual 699	android/app/ActivityManagerNative:unbindBackupAgent	(Landroid/content/pm/ApplicationInfo;)V
    //   6414: aload_3
    //   6415: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6418: iconst_1
    //   6419: ireturn
    //   6420: aload_2
    //   6421: ldc 25
    //   6423: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6426: aload_0
    //   6427: aload_2
    //   6428: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   6431: aload_2
    //   6432: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6435: invokevirtual 702	android/app/ActivityManagerNative:killApplicationWithAppId	(Ljava/lang/String;I)V
    //   6438: aload_3
    //   6439: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6442: iconst_1
    //   6443: ireturn
    //   6444: aload_2
    //   6445: ldc 25
    //   6447: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6450: aload_0
    //   6451: aload_2
    //   6452: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   6455: invokevirtual 705	android/app/ActivityManagerNative:closeSystemDialogs	(Ljava/lang/String;)V
    //   6458: aload_3
    //   6459: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6462: iconst_1
    //   6463: ireturn
    //   6464: aload_2
    //   6465: ldc 25
    //   6467: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6470: aload_0
    //   6471: aload_2
    //   6472: invokevirtual 607	android/os/Parcel:createIntArray	()[I
    //   6475: invokevirtual 709	android/app/ActivityManagerNative:getProcessMemoryInfo	([I)[Landroid/os/Debug$MemoryInfo;
    //   6478: astore 73
    //   6480: aload_3
    //   6481: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6484: aload_3
    //   6485: aload 73
    //   6487: iconst_1
    //   6488: invokevirtual 713	android/os/Parcel:writeTypedArray	([Landroid/os/Parcelable;I)V
    //   6491: iconst_1
    //   6492: ireturn
    //   6493: aload_2
    //   6494: ldc 25
    //   6496: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6499: aload_0
    //   6500: aload_2
    //   6501: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   6504: aload_2
    //   6505: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6508: invokevirtual 716	android/app/ActivityManagerNative:killApplicationProcess	(Ljava/lang/String;I)V
    //   6511: aload_3
    //   6512: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6515: iconst_1
    //   6516: ireturn
    //   6517: aload_2
    //   6518: ldc 25
    //   6520: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6523: aload_0
    //   6524: aload_2
    //   6525: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   6528: aload_2
    //   6529: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   6532: aload_2
    //   6533: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6536: aload_2
    //   6537: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6540: invokevirtual 720	android/app/ActivityManagerNative:overridePendingTransition	(Landroid/os/IBinder;Ljava/lang/String;II)V
    //   6543: aload_3
    //   6544: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6547: iconst_1
    //   6548: ireturn
    //   6549: aload_2
    //   6550: ldc 25
    //   6552: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6555: aload_0
    //   6556: invokevirtual 723	android/app/ActivityManagerNative:isUserAMonkey	()Z
    //   6559: istore 71
    //   6561: aload_3
    //   6562: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6565: iload 71
    //   6567: ifeq +14 -> 6581
    //   6570: iconst_1
    //   6571: istore 72
    //   6573: aload_3
    //   6574: iload 72
    //   6576: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   6579: iconst_1
    //   6580: ireturn
    //   6581: iconst_0
    //   6582: istore 72
    //   6584: goto -11 -> 6573
    //   6587: aload_2
    //   6588: ldc 25
    //   6590: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6593: aload_0
    //   6594: invokevirtual 726	android/app/ActivityManagerNative:finishHeavyWeightApp	()V
    //   6597: aload_3
    //   6598: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6601: iconst_1
    //   6602: ireturn
    //   6603: aload_2
    //   6604: ldc 25
    //   6606: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6609: aload_0
    //   6610: aload_2
    //   6611: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   6614: invokevirtual 729	android/app/ActivityManagerNative:isImmersive	(Landroid/os/IBinder;)Z
    //   6617: istore 69
    //   6619: aload_3
    //   6620: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6623: iload 69
    //   6625: ifeq +14 -> 6639
    //   6628: iconst_1
    //   6629: istore 70
    //   6631: aload_3
    //   6632: iload 70
    //   6634: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   6637: iconst_1
    //   6638: ireturn
    //   6639: iconst_0
    //   6640: istore 70
    //   6642: goto -11 -> 6631
    //   6645: aload_2
    //   6646: ldc 25
    //   6648: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6651: aload_2
    //   6652: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   6655: astore 67
    //   6657: aload_2
    //   6658: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6661: iconst_1
    //   6662: if_icmpne +20 -> 6682
    //   6665: iconst_1
    //   6666: istore 68
    //   6668: aload_0
    //   6669: aload 67
    //   6671: iload 68
    //   6673: invokevirtual 732	android/app/ActivityManagerNative:setImmersive	(Landroid/os/IBinder;Z)V
    //   6676: aload_3
    //   6677: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6680: iconst_1
    //   6681: ireturn
    //   6682: iconst_0
    //   6683: istore 68
    //   6685: goto -17 -> 6668
    //   6688: aload_2
    //   6689: ldc 25
    //   6691: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6694: aload_0
    //   6695: invokevirtual 735	android/app/ActivityManagerNative:isTopActivityImmersive	()Z
    //   6698: istore 65
    //   6700: aload_3
    //   6701: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6704: iload 65
    //   6706: ifeq +14 -> 6720
    //   6709: iconst_1
    //   6710: istore 66
    //   6712: aload_3
    //   6713: iload 66
    //   6715: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   6718: iconst_1
    //   6719: ireturn
    //   6720: iconst_0
    //   6721: istore 66
    //   6723: goto -11 -> 6712
    //   6726: aload_2
    //   6727: ldc 25
    //   6729: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6732: aload_0
    //   6733: aload_2
    //   6734: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6737: aload_2
    //   6738: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6741: aload_2
    //   6742: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   6745: aload_2
    //   6746: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   6749: invokevirtual 739	android/app/ActivityManagerNative:crashApplication	(IILjava/lang/String;Ljava/lang/String;)V
    //   6752: aload_3
    //   6753: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6756: iconst_1
    //   6757: ireturn
    //   6758: aload_2
    //   6759: ldc 25
    //   6761: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6764: aload_0
    //   6765: getstatic 526	android/net/Uri:CREATOR	Landroid/os/Parcelable$Creator;
    //   6768: aload_2
    //   6769: invokeinterface 108 2 0
    //   6774: checkcast 525	android/net/Uri
    //   6777: aload_2
    //   6778: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6781: invokevirtual 743	android/app/ActivityManagerNative:getProviderMimeType	(Landroid/net/Uri;I)Ljava/lang/String;
    //   6784: astore 64
    //   6786: aload_3
    //   6787: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6790: aload_3
    //   6791: aload 64
    //   6793: invokevirtual 252	android/os/Parcel:writeString	(Ljava/lang/String;)V
    //   6796: iconst_1
    //   6797: ireturn
    //   6798: aload_2
    //   6799: ldc 25
    //   6801: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6804: aload_0
    //   6805: aload_2
    //   6806: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   6809: invokevirtual 747	android/app/ActivityManagerNative:newUriPermissionOwner	(Ljava/lang/String;)Landroid/os/IBinder;
    //   6812: astore 63
    //   6814: aload_3
    //   6815: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6818: aload_3
    //   6819: aload 63
    //   6821: invokevirtual 489	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
    //   6824: iconst_1
    //   6825: ireturn
    //   6826: aload_2
    //   6827: ldc 25
    //   6829: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6832: aload_0
    //   6833: aload_2
    //   6834: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   6837: aload_2
    //   6838: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6841: aload_2
    //   6842: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   6845: getstatic 526	android/net/Uri:CREATOR	Landroid/os/Parcelable$Creator;
    //   6848: aload_2
    //   6849: invokeinterface 108 2 0
    //   6854: checkcast 525	android/net/Uri
    //   6857: aload_2
    //   6858: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6861: invokevirtual 751	android/app/ActivityManagerNative:grantUriPermissionFromOwner	(Landroid/os/IBinder;ILjava/lang/String;Landroid/net/Uri;I)V
    //   6864: aload_3
    //   6865: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6868: iconst_1
    //   6869: ireturn
    //   6870: aload_2
    //   6871: ldc 25
    //   6873: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6876: aload_2
    //   6877: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   6880: astore 61
    //   6882: aload_2
    //   6883: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6886: ifeq +13 -> 6899
    //   6889: getstatic 526	android/net/Uri:CREATOR	Landroid/os/Parcelable$Creator;
    //   6892: aload_2
    //   6893: invokeinterface 108 2 0
    //   6898: pop
    //   6899: aload_0
    //   6900: aload 61
    //   6902: aconst_null
    //   6903: aload_2
    //   6904: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6907: invokevirtual 755	android/app/ActivityManagerNative:revokeUriPermissionFromOwner	(Landroid/os/IBinder;Landroid/net/Uri;I)V
    //   6910: aload_3
    //   6911: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6914: iconst_1
    //   6915: ireturn
    //   6916: aload_2
    //   6917: ldc 25
    //   6919: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6922: aload_0
    //   6923: aload_2
    //   6924: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6927: aload_2
    //   6928: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   6931: getstatic 526	android/net/Uri:CREATOR	Landroid/os/Parcelable$Creator;
    //   6934: aload_2
    //   6935: invokeinterface 108 2 0
    //   6940: checkcast 525	android/net/Uri
    //   6943: aload_2
    //   6944: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6947: invokevirtual 759	android/app/ActivityManagerNative:checkGrantUriPermission	(ILjava/lang/String;Landroid/net/Uri;I)I
    //   6950: istore 60
    //   6952: aload_3
    //   6953: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   6956: aload_3
    //   6957: iload 60
    //   6959: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   6962: iconst_1
    //   6963: ireturn
    //   6964: aload_2
    //   6965: ldc 25
    //   6967: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   6970: aload_2
    //   6971: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   6974: astore 53
    //   6976: aload_2
    //   6977: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6980: istore 54
    //   6982: aload_2
    //   6983: invokevirtual 116	android/os/Parcel:readInt	()I
    //   6986: ifeq +61 -> 7047
    //   6989: iconst_1
    //   6990: istore 55
    //   6992: aload_2
    //   6993: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   6996: astore 56
    //   6998: aload_2
    //   6999: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7002: ifeq +51 -> 7053
    //   7005: aload_2
    //   7006: invokevirtual 120	android/os/Parcel:readFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   7009: astore 57
    //   7011: aload_0
    //   7012: aload 53
    //   7014: iload 54
    //   7016: iload 55
    //   7018: aload 56
    //   7020: aload 57
    //   7022: invokevirtual 763	android/app/ActivityManagerNative:dumpHeap	(Ljava/lang/String;IZLjava/lang/String;Landroid/os/ParcelFileDescriptor;)Z
    //   7025: istore 58
    //   7027: aload_3
    //   7028: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7031: iload 58
    //   7033: ifeq +26 -> 7059
    //   7036: iconst_1
    //   7037: istore 59
    //   7039: aload_3
    //   7040: iload 59
    //   7042: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   7045: iconst_1
    //   7046: ireturn
    //   7047: iconst_0
    //   7048: istore 55
    //   7050: goto -58 -> 6992
    //   7053: aconst_null
    //   7054: astore 57
    //   7056: goto -45 -> 7011
    //   7059: iconst_0
    //   7060: istore 59
    //   7062: goto -23 -> 7039
    //   7065: aload_2
    //   7066: ldc 25
    //   7068: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7071: aload_2
    //   7072: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   7075: invokestatic 96	android/app/ApplicationThreadNative:asInterface	(Landroid/os/IBinder;)Landroid/app/IApplicationThread;
    //   7078: astore 46
    //   7080: aload_2
    //   7081: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   7084: invokevirtual 472	android/os/Parcel:createTypedArray	(Landroid/os/Parcelable$Creator;)[Ljava/lang/Object;
    //   7087: checkcast 474	[Landroid/content/Intent;
    //   7090: astore 47
    //   7092: aload_2
    //   7093: invokevirtual 478	android/os/Parcel:createStringArray	()[Ljava/lang/String;
    //   7096: astore 48
    //   7098: aload_2
    //   7099: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   7102: astore 49
    //   7104: aload_2
    //   7105: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7108: ifeq +53 -> 7161
    //   7111: getstatic 123	android/os/Bundle:CREATOR	Landroid/os/Parcelable$Creator;
    //   7114: aload_2
    //   7115: invokeinterface 108 2 0
    //   7120: checkcast 122	android/os/Bundle
    //   7123: astore 50
    //   7125: aload_2
    //   7126: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7129: istore 51
    //   7131: aload_0
    //   7132: aload 46
    //   7134: aload 47
    //   7136: aload 48
    //   7138: aload 49
    //   7140: aload 50
    //   7142: iload 51
    //   7144: invokevirtual 767	android/app/ActivityManagerNative:startActivities	(Landroid/app/IApplicationThread;[Landroid/content/Intent;[Ljava/lang/String;Landroid/os/IBinder;Landroid/os/Bundle;I)I
    //   7147: istore 52
    //   7149: aload_3
    //   7150: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7153: aload_3
    //   7154: iload 52
    //   7156: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   7159: iconst_1
    //   7160: ireturn
    //   7161: aconst_null
    //   7162: astore 50
    //   7164: goto -39 -> 7125
    //   7167: aload_2
    //   7168: ldc 25
    //   7170: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7173: aload_0
    //   7174: invokevirtual 770	android/app/ActivityManagerNative:getFrontActivityScreenCompatMode	()I
    //   7177: istore 45
    //   7179: aload_3
    //   7180: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7183: aload_3
    //   7184: iload 45
    //   7186: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   7189: iconst_1
    //   7190: ireturn
    //   7191: aload_2
    //   7192: ldc 25
    //   7194: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7197: aload_2
    //   7198: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7201: istore 44
    //   7203: aload_0
    //   7204: iload 44
    //   7206: invokevirtual 773	android/app/ActivityManagerNative:setFrontActivityScreenCompatMode	(I)V
    //   7209: aload_3
    //   7210: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7213: aload_3
    //   7214: iload 44
    //   7216: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   7219: iconst_1
    //   7220: ireturn
    //   7221: aload_2
    //   7222: ldc 25
    //   7224: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7227: aload_0
    //   7228: aload_2
    //   7229: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   7232: invokevirtual 777	android/app/ActivityManagerNative:getPackageScreenCompatMode	(Ljava/lang/String;)I
    //   7235: istore 43
    //   7237: aload_3
    //   7238: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7241: aload_3
    //   7242: iload 43
    //   7244: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   7247: iconst_1
    //   7248: ireturn
    //   7249: aload_2
    //   7250: ldc 25
    //   7252: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7255: aload_0
    //   7256: aload_2
    //   7257: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   7260: aload_2
    //   7261: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7264: invokevirtual 780	android/app/ActivityManagerNative:setPackageScreenCompatMode	(Ljava/lang/String;I)V
    //   7267: aload_3
    //   7268: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7271: iconst_1
    //   7272: ireturn
    //   7273: aload_2
    //   7274: ldc 25
    //   7276: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7279: aload_0
    //   7280: aload_2
    //   7281: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7284: invokevirtual 783	android/app/ActivityManagerNative:switchUser	(I)Z
    //   7287: istore 41
    //   7289: aload_3
    //   7290: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7293: iload 41
    //   7295: ifeq +14 -> 7309
    //   7298: iconst_1
    //   7299: istore 42
    //   7301: aload_3
    //   7302: iload 42
    //   7304: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   7307: iconst_1
    //   7308: ireturn
    //   7309: iconst_0
    //   7310: istore 42
    //   7312: goto -11 -> 7301
    //   7315: aload_2
    //   7316: ldc 25
    //   7318: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7321: aload_0
    //   7322: aload_2
    //   7323: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7326: aload_2
    //   7327: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   7330: invokestatic 788	android/app/IStopUserCallback$Stub:asInterface	(Landroid/os/IBinder;)Landroid/app/IStopUserCallback;
    //   7333: invokevirtual 792	android/app/ActivityManagerNative:stopUser	(ILandroid/app/IStopUserCallback;)I
    //   7336: istore 40
    //   7338: aload_3
    //   7339: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7342: aload_3
    //   7343: iload 40
    //   7345: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   7348: iconst_1
    //   7349: ireturn
    //   7350: aload_2
    //   7351: ldc 25
    //   7353: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7356: aload_0
    //   7357: invokevirtual 796	android/app/ActivityManagerNative:getCurrentUser	()Landroid/content/pm/UserInfo;
    //   7360: astore 39
    //   7362: aload_3
    //   7363: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7366: aload 39
    //   7368: aload_3
    //   7369: iconst_0
    //   7370: invokevirtual 799	android/content/pm/UserInfo:writeToParcel	(Landroid/os/Parcel;I)V
    //   7373: iconst_1
    //   7374: ireturn
    //   7375: aload_2
    //   7376: ldc 25
    //   7378: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7381: aload_2
    //   7382: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7385: istore 35
    //   7387: aload_2
    //   7388: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7391: ifeq +36 -> 7427
    //   7394: iconst_1
    //   7395: istore 36
    //   7397: aload_0
    //   7398: iload 35
    //   7400: iload 36
    //   7402: invokevirtual 803	android/app/ActivityManagerNative:isUserRunning	(IZ)Z
    //   7405: istore 37
    //   7407: aload_3
    //   7408: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7411: iload 37
    //   7413: ifeq +20 -> 7433
    //   7416: iconst_1
    //   7417: istore 38
    //   7419: aload_3
    //   7420: iload 38
    //   7422: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   7425: iconst_1
    //   7426: ireturn
    //   7427: iconst_0
    //   7428: istore 36
    //   7430: goto -33 -> 7397
    //   7433: iconst_0
    //   7434: istore 38
    //   7436: goto -17 -> 7419
    //   7439: aload_2
    //   7440: ldc 25
    //   7442: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7445: aload_0
    //   7446: invokevirtual 806	android/app/ActivityManagerNative:getRunningUserIds	()[I
    //   7449: astore 34
    //   7451: aload_3
    //   7452: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7455: aload_3
    //   7456: aload 34
    //   7458: invokevirtual 810	android/os/Parcel:writeIntArray	([I)V
    //   7461: iconst_1
    //   7462: ireturn
    //   7463: aload_2
    //   7464: ldc 25
    //   7466: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7469: aload_0
    //   7470: aload_2
    //   7471: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7474: aload_2
    //   7475: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7478: invokevirtual 814	android/app/ActivityManagerNative:removeSubTask	(II)Z
    //   7481: istore 32
    //   7483: aload_3
    //   7484: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7487: iload 32
    //   7489: ifeq +14 -> 7503
    //   7492: iconst_1
    //   7493: istore 33
    //   7495: aload_3
    //   7496: iload 33
    //   7498: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   7501: iconst_1
    //   7502: ireturn
    //   7503: iconst_0
    //   7504: istore 33
    //   7506: goto -11 -> 7495
    //   7509: aload_2
    //   7510: ldc 25
    //   7512: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7515: aload_0
    //   7516: aload_2
    //   7517: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7520: aload_2
    //   7521: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7524: invokevirtual 817	android/app/ActivityManagerNative:removeTask	(II)Z
    //   7527: istore 30
    //   7529: aload_3
    //   7530: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7533: iload 30
    //   7535: ifeq +14 -> 7549
    //   7538: iconst_1
    //   7539: istore 31
    //   7541: aload_3
    //   7542: iload 31
    //   7544: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   7547: iconst_1
    //   7548: ireturn
    //   7549: iconst_0
    //   7550: istore 31
    //   7552: goto -11 -> 7541
    //   7555: aload_2
    //   7556: ldc 25
    //   7558: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7561: aload_0
    //   7562: aload_2
    //   7563: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   7566: invokestatic 822	android/app/IProcessObserver$Stub:asInterface	(Landroid/os/IBinder;)Landroid/app/IProcessObserver;
    //   7569: invokevirtual 826	android/app/ActivityManagerNative:registerProcessObserver	(Landroid/app/IProcessObserver;)V
    //   7572: iconst_1
    //   7573: ireturn
    //   7574: aload_2
    //   7575: ldc 25
    //   7577: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7580: aload_0
    //   7581: aload_2
    //   7582: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   7585: invokestatic 822	android/app/IProcessObserver$Stub:asInterface	(Landroid/os/IBinder;)Landroid/app/IProcessObserver;
    //   7588: invokevirtual 829	android/app/ActivityManagerNative:unregisterProcessObserver	(Landroid/app/IProcessObserver;)V
    //   7591: iconst_1
    //   7592: ireturn
    //   7593: aload_2
    //   7594: ldc 25
    //   7596: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7599: aload_0
    //   7600: aload_2
    //   7601: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   7604: invokevirtual 832	android/app/ActivityManagerNative:getPackageAskScreenCompat	(Ljava/lang/String;)Z
    //   7607: istore 28
    //   7609: aload_3
    //   7610: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7613: iload 28
    //   7615: ifeq +14 -> 7629
    //   7618: iconst_1
    //   7619: istore 29
    //   7621: aload_3
    //   7622: iload 29
    //   7624: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   7627: iconst_1
    //   7628: ireturn
    //   7629: iconst_0
    //   7630: istore 29
    //   7632: goto -11 -> 7621
    //   7635: aload_2
    //   7636: ldc 25
    //   7638: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7641: aload_2
    //   7642: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   7645: astore 26
    //   7647: aload_2
    //   7648: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7651: ifeq +20 -> 7671
    //   7654: iconst_1
    //   7655: istore 27
    //   7657: aload_0
    //   7658: aload 26
    //   7660: iload 27
    //   7662: invokevirtual 836	android/app/ActivityManagerNative:setPackageAskScreenCompat	(Ljava/lang/String;Z)V
    //   7665: aload_3
    //   7666: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7669: iconst_1
    //   7670: ireturn
    //   7671: iconst_0
    //   7672: istore 27
    //   7674: goto -17 -> 7657
    //   7677: aload_2
    //   7678: ldc 25
    //   7680: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7683: aload_0
    //   7684: aload_2
    //   7685: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   7688: invokestatic 494	android/content/IIntentSender$Stub:asInterface	(Landroid/os/IBinder;)Landroid/content/IIntentSender;
    //   7691: invokevirtual 840	android/app/ActivityManagerNative:isIntentSenderTargetedToPackage	(Landroid/content/IIntentSender;)Z
    //   7694: istore 24
    //   7696: aload_3
    //   7697: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7700: iload 24
    //   7702: ifeq +14 -> 7716
    //   7705: iconst_1
    //   7706: istore 25
    //   7708: aload_3
    //   7709: iload 25
    //   7711: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   7714: iconst_1
    //   7715: ireturn
    //   7716: iconst_0
    //   7717: istore 25
    //   7719: goto -11 -> 7708
    //   7722: aload_2
    //   7723: ldc 25
    //   7725: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7728: aload_0
    //   7729: aload_2
    //   7730: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   7733: invokestatic 494	android/content/IIntentSender$Stub:asInterface	(Landroid/os/IBinder;)Landroid/content/IIntentSender;
    //   7736: invokevirtual 843	android/app/ActivityManagerNative:isIntentSenderAnActivity	(Landroid/content/IIntentSender;)Z
    //   7739: istore 22
    //   7741: aload_3
    //   7742: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7745: iload 22
    //   7747: ifeq +14 -> 7761
    //   7750: iconst_1
    //   7751: istore 23
    //   7753: aload_3
    //   7754: iload 23
    //   7756: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   7759: iconst_1
    //   7760: ireturn
    //   7761: iconst_0
    //   7762: istore 23
    //   7764: goto -11 -> 7753
    //   7767: aload_2
    //   7768: ldc 25
    //   7770: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7773: aload_0
    //   7774: getstatic 151	android/content/res/Configuration:CREATOR	Landroid/os/Parcelable$Creator;
    //   7777: aload_2
    //   7778: invokeinterface 108 2 0
    //   7783: checkcast 150	android/content/res/Configuration
    //   7786: invokevirtual 846	android/app/ActivityManagerNative:updatePersistentConfiguration	(Landroid/content/res/Configuration;)V
    //   7789: aload_3
    //   7790: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7793: iconst_1
    //   7794: ireturn
    //   7795: aload_2
    //   7796: ldc 25
    //   7798: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7801: aload_0
    //   7802: aload_2
    //   7803: invokevirtual 607	android/os/Parcel:createIntArray	()[I
    //   7806: invokevirtual 850	android/app/ActivityManagerNative:getProcessPss	([I)[J
    //   7809: astore 21
    //   7811: aload_3
    //   7812: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7815: aload_3
    //   7816: aload 21
    //   7818: invokevirtual 854	android/os/Parcel:writeLongArray	([J)V
    //   7821: iconst_1
    //   7822: ireturn
    //   7823: aload_2
    //   7824: ldc 25
    //   7826: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7829: getstatic 233	android/text/TextUtils:CHAR_SEQUENCE_CREATOR	Landroid/os/Parcelable$Creator;
    //   7832: aload_2
    //   7833: invokeinterface 108 2 0
    //   7838: checkcast 235	java/lang/CharSequence
    //   7841: astore 19
    //   7843: aload_2
    //   7844: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7847: ifeq +20 -> 7867
    //   7850: iconst_1
    //   7851: istore 20
    //   7853: aload_0
    //   7854: aload 19
    //   7856: iload 20
    //   7858: invokevirtual 858	android/app/ActivityManagerNative:showBootMessage	(Ljava/lang/CharSequence;Z)V
    //   7861: aload_3
    //   7862: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7865: iconst_1
    //   7866: ireturn
    //   7867: iconst_0
    //   7868: istore 20
    //   7870: goto -17 -> 7853
    //   7873: aload_2
    //   7874: ldc 25
    //   7876: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7879: aload_0
    //   7880: invokevirtual 861	android/app/ActivityManagerNative:dismissKeyguardOnNextActivity	()V
    //   7883: aload_3
    //   7884: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7887: iconst_1
    //   7888: ireturn
    //   7889: aload_2
    //   7890: ldc 25
    //   7892: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7895: aload_0
    //   7896: aload_2
    //   7897: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   7900: aload_2
    //   7901: invokevirtual 112	android/os/Parcel:readString	()Ljava/lang/String;
    //   7904: invokevirtual 865	android/app/ActivityManagerNative:targetTaskAffinityMatchesActivity	(Landroid/os/IBinder;Ljava/lang/String;)Z
    //   7907: istore 17
    //   7909: aload_3
    //   7910: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   7913: iload 17
    //   7915: ifeq +14 -> 7929
    //   7918: iconst_1
    //   7919: istore 18
    //   7921: aload_3
    //   7922: iload 18
    //   7924: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   7927: iconst_1
    //   7928: ireturn
    //   7929: iconst_0
    //   7930: istore 18
    //   7932: goto -11 -> 7921
    //   7935: aload_2
    //   7936: ldc 25
    //   7938: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   7941: aload_2
    //   7942: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   7945: astore 10
    //   7947: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   7950: aload_2
    //   7951: invokeinterface 108 2 0
    //   7956: checkcast 98	android/content/Intent
    //   7959: astore 11
    //   7961: aload_2
    //   7962: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7965: istore 12
    //   7967: aload_2
    //   7968: invokevirtual 116	android/os/Parcel:readInt	()I
    //   7971: istore 13
    //   7973: aconst_null
    //   7974: astore 14
    //   7976: iload 13
    //   7978: ifeq +17 -> 7995
    //   7981: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   7984: aload_2
    //   7985: invokeinterface 108 2 0
    //   7990: checkcast 98	android/content/Intent
    //   7993: astore 14
    //   7995: aload_0
    //   7996: aload 10
    //   7998: aload 11
    //   8000: iload 12
    //   8002: aload 14
    //   8004: invokevirtual 869	android/app/ActivityManagerNative:navigateUpTo	(Landroid/os/IBinder;Landroid/content/Intent;ILandroid/content/Intent;)Z
    //   8007: istore 15
    //   8009: aload_3
    //   8010: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   8013: iload 15
    //   8015: ifeq +14 -> 8029
    //   8018: iconst_1
    //   8019: istore 16
    //   8021: aload_3
    //   8022: iload 16
    //   8024: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   8027: iconst_1
    //   8028: ireturn
    //   8029: iconst_0
    //   8030: istore 16
    //   8032: goto -11 -> 8021
    //   8035: aload_2
    //   8036: ldc 25
    //   8038: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   8041: aload_0
    //   8042: aload_2
    //   8043: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   8046: invokevirtual 872	android/app/ActivityManagerNative:getLaunchedFromUid	(Landroid/os/IBinder;)I
    //   8049: istore 9
    //   8051: aload_3
    //   8052: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   8055: aload_3
    //   8056: iload 9
    //   8058: invokevirtual 134	android/os/Parcel:writeInt	(I)V
    //   8061: iconst_1
    //   8062: ireturn
    //   8063: aload_2
    //   8064: ldc 25
    //   8066: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   8069: aload_0
    //   8070: aload_2
    //   8071: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   8074: invokestatic 877	android/app/IUserSwitchObserver$Stub:asInterface	(Landroid/os/IBinder;)Landroid/app/IUserSwitchObserver;
    //   8077: invokevirtual 881	android/app/ActivityManagerNative:registerUserSwitchObserver	(Landroid/app/IUserSwitchObserver;)V
    //   8080: aload_3
    //   8081: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   8084: iconst_1
    //   8085: ireturn
    //   8086: aload_2
    //   8087: ldc 25
    //   8089: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   8092: aload_0
    //   8093: aload_2
    //   8094: invokevirtual 91	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   8097: invokestatic 877	android/app/IUserSwitchObserver$Stub:asInterface	(Landroid/os/IBinder;)Landroid/app/IUserSwitchObserver;
    //   8100: invokevirtual 884	android/app/ActivityManagerNative:unregisterUserSwitchObserver	(Landroid/app/IUserSwitchObserver;)V
    //   8103: aload_3
    //   8104: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   8107: iconst_1
    //   8108: ireturn
    //   8109: aload_2
    //   8110: ldc 25
    //   8112: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   8115: aload_0
    //   8116: invokevirtual 887	android/app/ActivityManagerNative:requestBugReport	()V
    //   8119: aload_3
    //   8120: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   8123: iconst_1
    //   8124: ireturn
    //   8125: aload_2
    //   8126: ldc 25
    //   8128: invokevirtual 88	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   8131: aload_2
    //   8132: invokevirtual 116	android/os/Parcel:readInt	()I
    //   8135: istore 5
    //   8137: aload_2
    //   8138: invokevirtual 116	android/os/Parcel:readInt	()I
    //   8141: ifeq +28 -> 8169
    //   8144: iconst_1
    //   8145: istore 6
    //   8147: aload_0
    //   8148: iload 5
    //   8150: iload 6
    //   8152: invokevirtual 891	android/app/ActivityManagerNative:inputDispatchingTimedOut	(IZ)J
    //   8155: lstore 7
    //   8157: aload_3
    //   8158: invokevirtual 130	android/os/Parcel:writeNoException	()V
    //   8161: aload_3
    //   8162: lload 7
    //   8164: invokevirtual 895	android/os/Parcel:writeLong	(J)V
    //   8167: iconst_1
    //   8168: ireturn
    //   8169: iconst_0
    //   8170: istore 6
    //   8172: goto -25 -> 8147
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\ActivityManagerNative.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.app;

public abstract interface OnActivityPausedListener
{
  public abstract void onPaused(Activity paramActivity);
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\OnActivityPausedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
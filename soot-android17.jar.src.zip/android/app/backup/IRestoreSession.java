package android.app.backup;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface IRestoreSession
  extends IInterface
{
  public abstract void endRestoreSession()
    throws RemoteException;
  
  public abstract int getAvailableRestoreSets(IRestoreObserver paramIRestoreObserver)
    throws RemoteException;
  
  public abstract int restoreAll(long paramLong, IRestoreObserver paramIRestoreObserver)
    throws RemoteException;
  
  public abstract int restorePackage(String paramString, IRestoreObserver paramIRestoreObserver)
    throws RemoteException;
  
  public abstract int restoreSome(long paramLong, IRestoreObserver paramIRestoreObserver, String[] paramArrayOfString)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IRestoreSession
  {
    private static final String DESCRIPTOR = "android.app.backup.IRestoreSession";
    static final int TRANSACTION_endRestoreSession = 5;
    static final int TRANSACTION_getAvailableRestoreSets = 1;
    static final int TRANSACTION_restoreAll = 2;
    static final int TRANSACTION_restorePackage = 4;
    static final int TRANSACTION_restoreSome = 3;
    
    public Stub()
    {
      attachInterface(this, "android.app.backup.IRestoreSession");
    }
    
    public static IRestoreSession asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.app.backup.IRestoreSession");
      if ((localIInterface != null) && ((localIInterface instanceof IRestoreSession))) {
        return (IRestoreSession)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.app.backup.IRestoreSession");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.app.backup.IRestoreSession");
        int m = getAvailableRestoreSets(IRestoreObserver.Stub.asInterface(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        paramParcel2.writeInt(m);
        return true;
      case 2: 
        paramParcel1.enforceInterface("android.app.backup.IRestoreSession");
        int k = restoreAll(paramParcel1.readLong(), IRestoreObserver.Stub.asInterface(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        paramParcel2.writeInt(k);
        return true;
      case 3: 
        paramParcel1.enforceInterface("android.app.backup.IRestoreSession");
        int j = restoreSome(paramParcel1.readLong(), IRestoreObserver.Stub.asInterface(paramParcel1.readStrongBinder()), paramParcel1.createStringArray());
        paramParcel2.writeNoException();
        paramParcel2.writeInt(j);
        return true;
      case 4: 
        paramParcel1.enforceInterface("android.app.backup.IRestoreSession");
        int i = restorePackage(paramParcel1.readString(), IRestoreObserver.Stub.asInterface(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i);
        return true;
      }
      paramParcel1.enforceInterface("android.app.backup.IRestoreSession");
      endRestoreSession();
      paramParcel2.writeNoException();
      return true;
    }
    
    private static class Proxy
      implements IRestoreSession
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public void endRestoreSession()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IRestoreSession");
          this.mRemote.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public int getAvailableRestoreSets(IRestoreObserver paramIRestoreObserver)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 26	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 26	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 28
        //   11: invokevirtual 32	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +52 -> 67
        //   18: aload_1
        //   19: invokeinterface 50 1 0
        //   24: astore 5
        //   26: aload_2
        //   27: aload 5
        //   29: invokevirtual 53	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   32: aload_0
        //   33: getfield 15	android/app/backup/IRestoreSession$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   36: iconst_1
        //   37: aload_2
        //   38: aload_3
        //   39: iconst_0
        //   40: invokeinterface 38 5 0
        //   45: pop
        //   46: aload_3
        //   47: invokevirtual 41	android/os/Parcel:readException	()V
        //   50: aload_3
        //   51: invokevirtual 57	android/os/Parcel:readInt	()I
        //   54: istore 7
        //   56: aload_3
        //   57: invokevirtual 44	android/os/Parcel:recycle	()V
        //   60: aload_2
        //   61: invokevirtual 44	android/os/Parcel:recycle	()V
        //   64: iload 7
        //   66: ireturn
        //   67: aconst_null
        //   68: astore 5
        //   70: goto -44 -> 26
        //   73: astore 4
        //   75: aload_3
        //   76: invokevirtual 44	android/os/Parcel:recycle	()V
        //   79: aload_2
        //   80: invokevirtual 44	android/os/Parcel:recycle	()V
        //   83: aload 4
        //   85: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	86	0	this	Proxy
        //   0	86	1	paramIRestoreObserver	IRestoreObserver
        //   3	77	2	localParcel1	Parcel
        //   7	69	3	localParcel2	Parcel
        //   73	11	4	localObject	Object
        //   24	45	5	localIBinder	IBinder
        //   54	11	7	i	int
        // Exception table:
        //   from	to	target	type
        //   8	14	73	finally
        //   18	26	73	finally
        //   26	56	73	finally
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.app.backup.IRestoreSession";
      }
      
      /* Error */
      public int restoreAll(long paramLong, IRestoreObserver paramIRestoreObserver)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 26	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 26	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 28
        //   14: invokevirtual 32	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 4
        //   19: lload_1
        //   20: invokevirtual 65	android/os/Parcel:writeLong	(J)V
        //   23: aload_3
        //   24: ifnull +59 -> 83
        //   27: aload_3
        //   28: invokeinterface 50 1 0
        //   33: astore 7
        //   35: aload 4
        //   37: aload 7
        //   39: invokevirtual 53	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   42: aload_0
        //   43: getfield 15	android/app/backup/IRestoreSession$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   46: iconst_2
        //   47: aload 4
        //   49: aload 5
        //   51: iconst_0
        //   52: invokeinterface 38 5 0
        //   57: pop
        //   58: aload 5
        //   60: invokevirtual 41	android/os/Parcel:readException	()V
        //   63: aload 5
        //   65: invokevirtual 57	android/os/Parcel:readInt	()I
        //   68: istore 9
        //   70: aload 5
        //   72: invokevirtual 44	android/os/Parcel:recycle	()V
        //   75: aload 4
        //   77: invokevirtual 44	android/os/Parcel:recycle	()V
        //   80: iload 9
        //   82: ireturn
        //   83: aconst_null
        //   84: astore 7
        //   86: goto -51 -> 35
        //   89: astore 6
        //   91: aload 5
        //   93: invokevirtual 44	android/os/Parcel:recycle	()V
        //   96: aload 4
        //   98: invokevirtual 44	android/os/Parcel:recycle	()V
        //   101: aload 6
        //   103: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	104	0	this	Proxy
        //   0	104	1	paramLong	long
        //   0	104	3	paramIRestoreObserver	IRestoreObserver
        //   3	94	4	localParcel1	Parcel
        //   8	84	5	localParcel2	Parcel
        //   89	13	6	localObject	Object
        //   33	52	7	localIBinder	IBinder
        //   68	13	9	i	int
        // Exception table:
        //   from	to	target	type
        //   10	23	89	finally
        //   27	35	89	finally
        //   35	70	89	finally
      }
      
      /* Error */
      public int restorePackage(String paramString, IRestoreObserver paramIRestoreObserver)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 26	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 26	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 28
        //   12: invokevirtual 32	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_3
        //   16: aload_1
        //   17: invokevirtual 70	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   20: aload_2
        //   21: ifnull +56 -> 77
        //   24: aload_2
        //   25: invokeinterface 50 1 0
        //   30: astore 6
        //   32: aload_3
        //   33: aload 6
        //   35: invokevirtual 53	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   38: aload_0
        //   39: getfield 15	android/app/backup/IRestoreSession$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   42: iconst_4
        //   43: aload_3
        //   44: aload 4
        //   46: iconst_0
        //   47: invokeinterface 38 5 0
        //   52: pop
        //   53: aload 4
        //   55: invokevirtual 41	android/os/Parcel:readException	()V
        //   58: aload 4
        //   60: invokevirtual 57	android/os/Parcel:readInt	()I
        //   63: istore 8
        //   65: aload 4
        //   67: invokevirtual 44	android/os/Parcel:recycle	()V
        //   70: aload_3
        //   71: invokevirtual 44	android/os/Parcel:recycle	()V
        //   74: iload 8
        //   76: ireturn
        //   77: aconst_null
        //   78: astore 6
        //   80: goto -48 -> 32
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 44	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 44	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramString	String
        //   0	97	2	paramIRestoreObserver	IRestoreObserver
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   30	49	6	localIBinder	IBinder
        //   63	12	8	i	int
        // Exception table:
        //   from	to	target	type
        //   9	20	83	finally
        //   24	32	83	finally
        //   32	65	83	finally
      }
      
      /* Error */
      public int restoreSome(long paramLong, IRestoreObserver paramIRestoreObserver, String[] paramArrayOfString)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 26	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 5
        //   5: invokestatic 26	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 6
        //   10: aload 5
        //   12: ldc 28
        //   14: invokevirtual 32	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 5
        //   19: lload_1
        //   20: invokevirtual 65	android/os/Parcel:writeLong	(J)V
        //   23: aload_3
        //   24: ifnull +66 -> 90
        //   27: aload_3
        //   28: invokeinterface 50 1 0
        //   33: astore 8
        //   35: aload 5
        //   37: aload 8
        //   39: invokevirtual 53	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   42: aload 5
        //   44: aload 4
        //   46: invokevirtual 76	android/os/Parcel:writeStringArray	([Ljava/lang/String;)V
        //   49: aload_0
        //   50: getfield 15	android/app/backup/IRestoreSession$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   53: iconst_3
        //   54: aload 5
        //   56: aload 6
        //   58: iconst_0
        //   59: invokeinterface 38 5 0
        //   64: pop
        //   65: aload 6
        //   67: invokevirtual 41	android/os/Parcel:readException	()V
        //   70: aload 6
        //   72: invokevirtual 57	android/os/Parcel:readInt	()I
        //   75: istore 10
        //   77: aload 6
        //   79: invokevirtual 44	android/os/Parcel:recycle	()V
        //   82: aload 5
        //   84: invokevirtual 44	android/os/Parcel:recycle	()V
        //   87: iload 10
        //   89: ireturn
        //   90: aconst_null
        //   91: astore 8
        //   93: goto -58 -> 35
        //   96: astore 7
        //   98: aload 6
        //   100: invokevirtual 44	android/os/Parcel:recycle	()V
        //   103: aload 5
        //   105: invokevirtual 44	android/os/Parcel:recycle	()V
        //   108: aload 7
        //   110: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	111	0	this	Proxy
        //   0	111	1	paramLong	long
        //   0	111	3	paramIRestoreObserver	IRestoreObserver
        //   0	111	4	paramArrayOfString	String[]
        //   3	101	5	localParcel1	Parcel
        //   8	91	6	localParcel2	Parcel
        //   96	13	7	localObject	Object
        //   33	59	8	localIBinder	IBinder
        //   75	13	10	i	int
        // Exception table:
        //   from	to	target	type
        //   10	23	96	finally
        //   27	35	96	finally
        //   35	77	96	finally
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\backup\IRestoreSession.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
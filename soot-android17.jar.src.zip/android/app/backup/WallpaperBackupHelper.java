package android.app.backup;

import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Point;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.view.Display;
import android.view.WindowManager;
import java.io.File;

public class WallpaperBackupHelper
  extends FileBackupHelperBase
  implements BackupHelper
{
  private static final boolean DEBUG = false;
  private static final String STAGE_FILE = new File(Environment.getUserSystemDirectory(0), "wallpaper-tmp").getAbsolutePath();
  private static final String TAG = "WallpaperBackupHelper";
  public static final String WALLPAPER_IMAGE = new File(Environment.getUserSystemDirectory(0), "wallpaper").getAbsolutePath();
  public static final String WALLPAPER_IMAGE_KEY = "/data/data/com.android.settings/files/wallpaper";
  public static final String WALLPAPER_INFO = new File(Environment.getUserSystemDirectory(0), "wallpaper_info.xml").getAbsolutePath();
  public static final String WALLPAPER_INFO_KEY = "/data/system/wallpaper_info.xml";
  Context mContext;
  double mDesiredMinHeight;
  double mDesiredMinWidth;
  String[] mFiles;
  String[] mKeys;
  
  public WallpaperBackupHelper(Context paramContext, String[] paramArrayOfString1, String[] paramArrayOfString2)
  {
    super(paramContext);
    this.mContext = paramContext;
    this.mFiles = paramArrayOfString1;
    this.mKeys = paramArrayOfString2;
    WallpaperManager localWallpaperManager = (WallpaperManager)paramContext.getSystemService("wallpaper");
    this.mDesiredMinWidth = localWallpaperManager.getDesiredMinimumWidth();
    this.mDesiredMinHeight = localWallpaperManager.getDesiredMinimumHeight();
    if ((this.mDesiredMinWidth <= 0.0D) || (this.mDesiredMinHeight <= 0.0D))
    {
      Display localDisplay = ((WindowManager)paramContext.getSystemService("window")).getDefaultDisplay();
      Point localPoint = new Point();
      localDisplay.getSize(localPoint);
      this.mDesiredMinWidth = localPoint.x;
      this.mDesiredMinHeight = localPoint.y;
    }
  }
  
  public void performBackup(ParcelFileDescriptor paramParcelFileDescriptor1, BackupDataOutput paramBackupDataOutput, ParcelFileDescriptor paramParcelFileDescriptor2)
  {
    performBackup_checked(paramParcelFileDescriptor1, paramBackupDataOutput, paramParcelFileDescriptor2, this.mFiles, this.mKeys);
  }
  
  public void restoreEntity(BackupDataInputStream paramBackupDataInputStream)
  {
    String str = paramBackupDataInputStream.getKey();
    if (isKeyInList(str, this.mKeys))
    {
      if (!str.equals("/data/data/com.android.settings/files/wallpaper")) {
        break label150;
      }
      localFile = new File(STAGE_FILE);
      if (writeFile(localFile, paramBackupDataInputStream))
      {
        localOptions = new BitmapFactory.Options();
        localOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(STAGE_FILE, localOptions);
        d1 = this.mDesiredMinWidth / localOptions.outWidth;
        d2 = this.mDesiredMinHeight / localOptions.outHeight;
        if ((d1 <= 0.0D) || (d1 >= 1.33D) || (d2 <= 0.0D) || (d2 >= 1.33D)) {
          break label144;
        }
        localFile.renameTo(new File(WALLPAPER_IMAGE));
      }
    }
    label144:
    label150:
    while (!str.equals("/data/system/wallpaper_info.xml"))
    {
      File localFile;
      BitmapFactory.Options localOptions;
      double d1;
      double d2;
      return;
      localFile.delete();
      return;
    }
    writeFile(new File(WALLPAPER_INFO), paramBackupDataInputStream);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\backup\WallpaperBackupHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
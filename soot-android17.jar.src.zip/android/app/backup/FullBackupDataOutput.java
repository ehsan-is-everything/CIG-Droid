package android.app.backup;

import android.os.ParcelFileDescriptor;

public class FullBackupDataOutput
{
  private BackupDataOutput mData;
  
  public FullBackupDataOutput(ParcelFileDescriptor paramParcelFileDescriptor)
  {
    this.mData = new BackupDataOutput(paramParcelFileDescriptor.getFileDescriptor());
  }
  
  public BackupDataOutput getData()
  {
    return this.mData;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\backup\FullBackupDataOutput.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
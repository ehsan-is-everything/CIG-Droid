package android.app.backup;

import android.content.Context;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.util.Log;

public class BackupManager
{
  private static final String TAG = "BackupManager";
  private static IBackupManager sService;
  private Context mContext;
  
  public BackupManager(Context paramContext)
  {
    this.mContext = paramContext;
  }
  
  private static void checkServiceBinder()
  {
    if (sService == null) {
      sService = IBackupManager.Stub.asInterface(ServiceManager.getService("backup"));
    }
  }
  
  public static void dataChanged(String paramString)
  {
    
    if (sService != null) {}
    try
    {
      sService.dataChanged(paramString);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.d("BackupManager", "dataChanged(pkg) couldn't connect");
    }
  }
  
  public RestoreSession beginRestoreSession()
  {
    checkServiceBinder();
    IBackupManager localIBackupManager = sService;
    Object localObject = null;
    if (localIBackupManager != null) {}
    try
    {
      IRestoreSession localIRestoreSession = sService.beginRestoreSession(null, null);
      localObject = null;
      if (localIRestoreSession != null)
      {
        RestoreSession localRestoreSession = new RestoreSession(this.mContext, localIRestoreSession);
        localObject = localRestoreSession;
      }
      return (RestoreSession)localObject;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w("BackupManager", "beginRestoreSession() couldn't connect");
    }
    return null;
  }
  
  public void dataChanged()
  {
    
    if (sService != null) {}
    try
    {
      sService.dataChanged(this.mContext.getPackageName());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.d("BackupManager", "dataChanged() couldn't connect");
    }
  }
  
  /* Error */
  public int requestRestore(RestoreObserver paramRestoreObserver)
  {
    // Byte code:
    //   0: iconst_m1
    //   1: istore_2
    //   2: invokestatic 42	android/app/backup/BackupManager:checkServiceBinder	()V
    //   5: getstatic 22	android/app/backup/BackupManager:sService	Landroid/app/backup/IBackupManager;
    //   8: ifnull +74 -> 82
    //   11: aconst_null
    //   12: astore_3
    //   13: getstatic 22	android/app/backup/BackupManager:sService	Landroid/app/backup/IBackupManager;
    //   16: aload_0
    //   17: getfield 19	android/app/backup/BackupManager:mContext	Landroid/content/Context;
    //   20: invokevirtual 75	android/content/Context:getPackageName	()Ljava/lang/String;
    //   23: aconst_null
    //   24: invokeinterface 59 3 0
    //   29: astore 7
    //   31: aconst_null
    //   32: astore_3
    //   33: aload 7
    //   35: ifnull +39 -> 74
    //   38: new 61	android/app/backup/RestoreSession
    //   41: dup
    //   42: aload_0
    //   43: getfield 19	android/app/backup/BackupManager:mContext	Landroid/content/Context;
    //   46: aload 7
    //   48: invokespecial 64	android/app/backup/RestoreSession:<init>	(Landroid/content/Context;Landroid/app/backup/IRestoreSession;)V
    //   51: astore 8
    //   53: aload 8
    //   55: aload_0
    //   56: getfield 19	android/app/backup/BackupManager:mContext	Landroid/content/Context;
    //   59: invokevirtual 75	android/content/Context:getPackageName	()Ljava/lang/String;
    //   62: aload_1
    //   63: invokevirtual 83	android/app/backup/RestoreSession:restorePackage	(Ljava/lang/String;Landroid/app/backup/RestoreObserver;)I
    //   66: istore 10
    //   68: iload 10
    //   70: istore_2
    //   71: aload 8
    //   73: astore_3
    //   74: aload_3
    //   75: ifnull +7 -> 82
    //   78: aload_3
    //   79: invokevirtual 86	android/app/backup/RestoreSession:endRestoreSession	()V
    //   82: iload_2
    //   83: ireturn
    //   84: astore 5
    //   86: ldc 8
    //   88: ldc 88
    //   90: invokestatic 69	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   93: pop
    //   94: aload_3
    //   95: ifnull -13 -> 82
    //   98: aload_3
    //   99: invokevirtual 86	android/app/backup/RestoreSession:endRestoreSession	()V
    //   102: iload_2
    //   103: ireturn
    //   104: astore 4
    //   106: aload_3
    //   107: ifnull +7 -> 114
    //   110: aload_3
    //   111: invokevirtual 86	android/app/backup/RestoreSession:endRestoreSession	()V
    //   114: aload 4
    //   116: athrow
    //   117: astore 4
    //   119: aload 8
    //   121: astore_3
    //   122: goto -16 -> 106
    //   125: astore 9
    //   127: aload 8
    //   129: astore_3
    //   130: goto -44 -> 86
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	133	0	this	BackupManager
    //   0	133	1	paramRestoreObserver	RestoreObserver
    //   1	102	2	i	int
    //   12	118	3	localObject1	Object
    //   104	11	4	localObject2	Object
    //   117	1	4	localObject3	Object
    //   84	1	5	localRemoteException1	RemoteException
    //   29	18	7	localIRestoreSession	IRestoreSession
    //   51	77	8	localRestoreSession	RestoreSession
    //   125	1	9	localRemoteException2	RemoteException
    //   66	3	10	j	int
    // Exception table:
    //   from	to	target	type
    //   13	31	84	android/os/RemoteException
    //   38	53	84	android/os/RemoteException
    //   13	31	104	finally
    //   38	53	104	finally
    //   86	94	104	finally
    //   53	68	117	finally
    //   53	68	125	android/os/RemoteException
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\backup\BackupManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
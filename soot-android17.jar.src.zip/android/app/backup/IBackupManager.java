package android.app.backup;

import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface IBackupManager
  extends IInterface
{
  public abstract void acknowledgeFullBackupOrRestore(int paramInt, boolean paramBoolean, String paramString1, String paramString2, IFullBackupRestoreObserver paramIFullBackupRestoreObserver)
    throws RemoteException;
  
  public abstract void agentConnected(String paramString, IBinder paramIBinder)
    throws RemoteException;
  
  public abstract void agentDisconnected(String paramString)
    throws RemoteException;
  
  public abstract void backupNow()
    throws RemoteException;
  
  public abstract IRestoreSession beginRestoreSession(String paramString1, String paramString2)
    throws RemoteException;
  
  public abstract void clearBackupData(String paramString)
    throws RemoteException;
  
  public abstract void dataChanged(String paramString)
    throws RemoteException;
  
  public abstract void fullBackup(ParcelFileDescriptor paramParcelFileDescriptor, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, String[] paramArrayOfString)
    throws RemoteException;
  
  public abstract void fullRestore(ParcelFileDescriptor paramParcelFileDescriptor)
    throws RemoteException;
  
  public abstract Intent getConfigurationIntent(String paramString)
    throws RemoteException;
  
  public abstract String getCurrentTransport()
    throws RemoteException;
  
  public abstract String getDestinationString(String paramString)
    throws RemoteException;
  
  public abstract boolean hasBackupPassword()
    throws RemoteException;
  
  public abstract boolean isBackupEnabled()
    throws RemoteException;
  
  public abstract String[] listAllTransports()
    throws RemoteException;
  
  public abstract void opComplete(int paramInt)
    throws RemoteException;
  
  public abstract void restoreAtInstall(String paramString, int paramInt)
    throws RemoteException;
  
  public abstract String selectBackupTransport(String paramString)
    throws RemoteException;
  
  public abstract void setAutoRestore(boolean paramBoolean)
    throws RemoteException;
  
  public abstract void setBackupEnabled(boolean paramBoolean)
    throws RemoteException;
  
  public abstract boolean setBackupPassword(String paramString1, String paramString2)
    throws RemoteException;
  
  public abstract void setBackupProvisioned(boolean paramBoolean)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IBackupManager
  {
    private static final String DESCRIPTOR = "android.app.backup.IBackupManager";
    static final int TRANSACTION_acknowledgeFullBackupOrRestore = 15;
    static final int TRANSACTION_agentConnected = 3;
    static final int TRANSACTION_agentDisconnected = 4;
    static final int TRANSACTION_backupNow = 12;
    static final int TRANSACTION_beginRestoreSession = 21;
    static final int TRANSACTION_clearBackupData = 2;
    static final int TRANSACTION_dataChanged = 1;
    static final int TRANSACTION_fullBackup = 13;
    static final int TRANSACTION_fullRestore = 14;
    static final int TRANSACTION_getConfigurationIntent = 19;
    static final int TRANSACTION_getCurrentTransport = 16;
    static final int TRANSACTION_getDestinationString = 20;
    static final int TRANSACTION_hasBackupPassword = 11;
    static final int TRANSACTION_isBackupEnabled = 9;
    static final int TRANSACTION_listAllTransports = 17;
    static final int TRANSACTION_opComplete = 22;
    static final int TRANSACTION_restoreAtInstall = 5;
    static final int TRANSACTION_selectBackupTransport = 18;
    static final int TRANSACTION_setAutoRestore = 7;
    static final int TRANSACTION_setBackupEnabled = 6;
    static final int TRANSACTION_setBackupPassword = 10;
    static final int TRANSACTION_setBackupProvisioned = 8;
    
    public Stub()
    {
      attachInterface(this, "android.app.backup.IBackupManager");
    }
    
    public static IBackupManager asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.app.backup.IBackupManager");
      if ((localIInterface != null) && ((localIInterface instanceof IBackupManager))) {
        return (IBackupManager)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.app.backup.IBackupManager");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        dataChanged(paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 2: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        clearBackupData(paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 3: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        agentConnected(paramParcel1.readString(), paramParcel1.readStrongBinder());
        paramParcel2.writeNoException();
        return true;
      case 4: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        agentDisconnected(paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 5: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        restoreAtInstall(paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 6: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        if (paramParcel1.readInt() != 0) {}
        for (boolean bool11 = true;; bool11 = false)
        {
          setBackupEnabled(bool11);
          paramParcel2.writeNoException();
          return true;
        }
      case 7: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        if (paramParcel1.readInt() != 0) {}
        for (boolean bool10 = true;; bool10 = false)
        {
          setAutoRestore(bool10);
          paramParcel2.writeNoException();
          return true;
        }
      case 8: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        if (paramParcel1.readInt() != 0) {}
        for (boolean bool9 = true;; bool9 = false)
        {
          setBackupProvisioned(bool9);
          paramParcel2.writeNoException();
          return true;
        }
      case 9: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        boolean bool8 = isBackupEnabled();
        paramParcel2.writeNoException();
        int m = 0;
        if (bool8) {
          m = 1;
        }
        paramParcel2.writeInt(m);
        return true;
      case 10: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        boolean bool7 = setBackupPassword(paramParcel1.readString(), paramParcel1.readString());
        paramParcel2.writeNoException();
        int k = 0;
        if (bool7) {
          k = 1;
        }
        paramParcel2.writeInt(k);
        return true;
      case 11: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        boolean bool6 = hasBackupPassword();
        paramParcel2.writeNoException();
        int j = 0;
        if (bool6) {
          j = 1;
        }
        paramParcel2.writeInt(j);
        return true;
      case 12: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        backupNow();
        paramParcel2.writeNoException();
        return true;
      case 13: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        ParcelFileDescriptor localParcelFileDescriptor2;
        boolean bool2;
        boolean bool3;
        boolean bool4;
        if (paramParcel1.readInt() != 0)
        {
          localParcelFileDescriptor2 = (ParcelFileDescriptor)ParcelFileDescriptor.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label650;
          }
          bool2 = true;
          if (paramParcel1.readInt() == 0) {
            break label656;
          }
          bool3 = true;
          if (paramParcel1.readInt() == 0) {
            break label662;
          }
          bool4 = true;
          if (paramParcel1.readInt() == 0) {
            break label668;
          }
        }
        for (boolean bool5 = true;; bool5 = false)
        {
          fullBackup(localParcelFileDescriptor2, bool2, bool3, bool4, bool5, paramParcel1.createStringArray());
          paramParcel2.writeNoException();
          return true;
          localParcelFileDescriptor2 = null;
          break;
          bool2 = false;
          break label590;
          bool3 = false;
          break label600;
          bool4 = false;
          break label610;
        }
      case 14: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        if (paramParcel1.readInt() != 0) {}
        for (ParcelFileDescriptor localParcelFileDescriptor1 = (ParcelFileDescriptor)ParcelFileDescriptor.CREATOR.createFromParcel(paramParcel1);; localParcelFileDescriptor1 = null)
        {
          fullRestore(localParcelFileDescriptor1);
          paramParcel2.writeNoException();
          return true;
        }
      case 15: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        int i = paramParcel1.readInt();
        if (paramParcel1.readInt() != 0) {}
        for (boolean bool1 = true;; bool1 = false)
        {
          acknowledgeFullBackupOrRestore(i, bool1, paramParcel1.readString(), paramParcel1.readString(), IFullBackupRestoreObserver.Stub.asInterface(paramParcel1.readStrongBinder()));
          paramParcel2.writeNoException();
          return true;
        }
      case 16: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        String str3 = getCurrentTransport();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str3);
        return true;
      case 17: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        String[] arrayOfString = listAllTransports();
        paramParcel2.writeNoException();
        paramParcel2.writeStringArray(arrayOfString);
        return true;
      case 18: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        String str2 = selectBackupTransport(paramParcel1.readString());
        paramParcel2.writeNoException();
        paramParcel2.writeString(str2);
        return true;
      case 19: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        Intent localIntent = getConfigurationIntent(paramParcel1.readString());
        paramParcel2.writeNoException();
        if (localIntent != null)
        {
          paramParcel2.writeInt(1);
          localIntent.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 20: 
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        String str1 = getDestinationString(paramParcel1.readString());
        paramParcel2.writeNoException();
        paramParcel2.writeString(str1);
        return true;
      case 21: 
        label590:
        label600:
        label610:
        label650:
        label656:
        label662:
        label668:
        paramParcel1.enforceInterface("android.app.backup.IBackupManager");
        IRestoreSession localIRestoreSession = beginRestoreSession(paramParcel1.readString(), paramParcel1.readString());
        paramParcel2.writeNoException();
        if (localIRestoreSession != null) {}
        for (IBinder localIBinder = localIRestoreSession.asBinder();; localIBinder = null)
        {
          paramParcel2.writeStrongBinder(localIBinder);
          return true;
        }
      }
      paramParcel1.enforceInterface("android.app.backup.IBackupManager");
      opComplete(paramParcel1.readInt());
      paramParcel2.writeNoException();
      return true;
    }
    
    private static class Proxy
      implements IBackupManager
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      /* Error */
      public void acknowledgeFullBackupOrRestore(int paramInt, boolean paramBoolean, String paramString1, String paramString2, IFullBackupRestoreObserver paramIFullBackupRestoreObserver)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 6
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 7
        //   10: aload 6
        //   12: ldc 27
        //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload 6
        //   19: iload_1
        //   20: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   23: iconst_0
        //   24: istore 9
        //   26: iload_2
        //   27: ifeq +6 -> 33
        //   30: iconst_1
        //   31: istore 9
        //   33: aload 6
        //   35: iload 9
        //   37: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   40: aload 6
        //   42: aload_3
        //   43: invokevirtual 38	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   46: aload 6
        //   48: aload 4
        //   50: invokevirtual 38	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   53: aload 5
        //   55: ifnull +52 -> 107
        //   58: aload 5
        //   60: invokeinterface 44 1 0
        //   65: astore 10
        //   67: aload 6
        //   69: aload 10
        //   71: invokevirtual 47	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   74: aload_0
        //   75: getfield 15	android/app/backup/IBackupManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   78: bipush 15
        //   80: aload 6
        //   82: aload 7
        //   84: iconst_0
        //   85: invokeinterface 53 5 0
        //   90: pop
        //   91: aload 7
        //   93: invokevirtual 56	android/os/Parcel:readException	()V
        //   96: aload 7
        //   98: invokevirtual 59	android/os/Parcel:recycle	()V
        //   101: aload 6
        //   103: invokevirtual 59	android/os/Parcel:recycle	()V
        //   106: return
        //   107: aconst_null
        //   108: astore 10
        //   110: goto -43 -> 67
        //   113: astore 8
        //   115: aload 7
        //   117: invokevirtual 59	android/os/Parcel:recycle	()V
        //   120: aload 6
        //   122: invokevirtual 59	android/os/Parcel:recycle	()V
        //   125: aload 8
        //   127: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	128	0	this	Proxy
        //   0	128	1	paramInt	int
        //   0	128	2	paramBoolean	boolean
        //   0	128	3	paramString1	String
        //   0	128	4	paramString2	String
        //   0	128	5	paramIFullBackupRestoreObserver	IFullBackupRestoreObserver
        //   3	118	6	localParcel1	Parcel
        //   8	108	7	localParcel2	Parcel
        //   113	13	8	localObject	Object
        //   24	12	9	i	int
        //   65	44	10	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   10	23	113	finally
        //   33	53	113	finally
        //   58	67	113	finally
        //   67	96	113	finally
      }
      
      public void agentConnected(String paramString, IBinder paramIBinder)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          localParcel1.writeString(paramString);
          localParcel1.writeStrongBinder(paramIBinder);
          this.mRemote.transact(3, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void agentDisconnected(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(4, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public void backupNow()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          this.mRemote.transact(12, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public IRestoreSession beginRestoreSession(String paramString1, String paramString2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          localParcel1.writeString(paramString1);
          localParcel1.writeString(paramString2);
          this.mRemote.transact(21, localParcel1, localParcel2, 0);
          localParcel2.readException();
          IRestoreSession localIRestoreSession = IRestoreSession.Stub.asInterface(localParcel2.readStrongBinder());
          return localIRestoreSession;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void clearBackupData(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(2, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void dataChanged(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(1, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void fullBackup(ParcelFileDescriptor paramParcelFileDescriptor, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, String[] paramArrayOfString)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          int k;
          label55:
          int m;
          try
          {
            localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
            if (paramParcelFileDescriptor != null)
            {
              localParcel1.writeInt(1);
              paramParcelFileDescriptor.writeToParcel(localParcel1, 0);
              break label178;
              localParcel1.writeInt(j);
              if (paramBoolean2)
              {
                k = i;
                localParcel1.writeInt(k);
                if (!paramBoolean3) {
                  break label166;
                }
                m = i;
                label71:
                localParcel1.writeInt(m);
                if (!paramBoolean4) {
                  break label172;
                }
                label83:
                localParcel1.writeInt(i);
                localParcel1.writeStringArray(paramArrayOfString);
                this.mRemote.transact(13, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localParcel1.writeInt(0);
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          label166:
          label172:
          label178:
          do
          {
            j = 0;
            break;
            k = 0;
            break label55;
            m = 0;
            break label71;
            i = 0;
            break label83;
          } while (!paramBoolean1);
          int j = i;
        }
      }
      
      /* Error */
      public void fullRestore(ParcelFileDescriptor paramParcelFileDescriptor)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +42 -> 57
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 84	android/os/ParcelFileDescriptor:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/app/backup/IBackupManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: bipush 14
        //   35: aload_2
        //   36: aload_3
        //   37: iconst_0
        //   38: invokeinterface 53 5 0
        //   43: pop
        //   44: aload_3
        //   45: invokevirtual 56	android/os/Parcel:readException	()V
        //   48: aload_3
        //   49: invokevirtual 59	android/os/Parcel:recycle	()V
        //   52: aload_2
        //   53: invokevirtual 59	android/os/Parcel:recycle	()V
        //   56: return
        //   57: aload_2
        //   58: iconst_0
        //   59: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   62: goto -33 -> 29
        //   65: astore 4
        //   67: aload_3
        //   68: invokevirtual 59	android/os/Parcel:recycle	()V
        //   71: aload_2
        //   72: invokevirtual 59	android/os/Parcel:recycle	()V
        //   75: aload 4
        //   77: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	78	0	this	Proxy
        //   0	78	1	paramParcelFileDescriptor	ParcelFileDescriptor
        //   3	69	2	localParcel1	Parcel
        //   7	61	3	localParcel2	Parcel
        //   65	11	4	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   8	14	65	finally
        //   18	29	65	finally
        //   29	48	65	finally
        //   57	62	65	finally
      }
      
      /* Error */
      public Intent getConfigurationIntent(String paramString)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_2
        //   15: aload_1
        //   16: invokevirtual 38	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   19: aload_0
        //   20: getfield 15	android/app/backup/IBackupManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   23: bipush 19
        //   25: aload_2
        //   26: aload_3
        //   27: iconst_0
        //   28: invokeinterface 53 5 0
        //   33: pop
        //   34: aload_3
        //   35: invokevirtual 56	android/os/Parcel:readException	()V
        //   38: aload_3
        //   39: invokevirtual 96	android/os/Parcel:readInt	()I
        //   42: ifeq +28 -> 70
        //   45: getstatic 102	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
        //   48: aload_3
        //   49: invokeinterface 108 2 0
        //   54: checkcast 98	android/content/Intent
        //   57: astore 6
        //   59: aload_3
        //   60: invokevirtual 59	android/os/Parcel:recycle	()V
        //   63: aload_2
        //   64: invokevirtual 59	android/os/Parcel:recycle	()V
        //   67: aload 6
        //   69: areturn
        //   70: aconst_null
        //   71: astore 6
        //   73: goto -14 -> 59
        //   76: astore 4
        //   78: aload_3
        //   79: invokevirtual 59	android/os/Parcel:recycle	()V
        //   82: aload_2
        //   83: invokevirtual 59	android/os/Parcel:recycle	()V
        //   86: aload 4
        //   88: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	89	0	this	Proxy
        //   0	89	1	paramString	String
        //   3	80	2	localParcel1	Parcel
        //   7	72	3	localParcel2	Parcel
        //   76	11	4	localObject	Object
        //   57	15	6	localIntent	Intent
        // Exception table:
        //   from	to	target	type
        //   8	59	76	finally
      }
      
      public String getCurrentTransport()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          this.mRemote.transact(16, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str = localParcel2.readString();
          return str;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String getDestinationString(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(20, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str = localParcel2.readString();
          return str;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.app.backup.IBackupManager";
      }
      
      public boolean hasBackupPassword()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          this.mRemote.transact(11, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean isBackupEnabled()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          this.mRemote.transact(9, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String[] listAllTransports()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          this.mRemote.transact(17, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String[] arrayOfString = localParcel2.createStringArray();
          return arrayOfString;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void opComplete(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(22, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void restoreAtInstall(String paramString, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String selectBackupTransport(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(18, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str = localParcel2.readString();
          return str;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void setAutoRestore(boolean paramBoolean)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          int i = 0;
          if (paramBoolean) {
            i = 1;
          }
          localParcel1.writeInt(i);
          this.mRemote.transact(7, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void setBackupEnabled(boolean paramBoolean)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          int i = 0;
          if (paramBoolean) {
            i = 1;
          }
          localParcel1.writeInt(i);
          this.mRemote.transact(6, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean setBackupPassword(String paramString1, String paramString2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          localParcel1.writeString(paramString1);
          localParcel1.writeString(paramString2);
          this.mRemote.transact(10, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void setBackupProvisioned(boolean paramBoolean)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.backup.IBackupManager");
          int i = 0;
          if (paramBoolean) {
            i = 1;
          }
          localParcel1.writeInt(i);
          this.mRemote.transact(8, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\backup\IBackupManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
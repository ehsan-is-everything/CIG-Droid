package android.app;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.internal.R.styleable;

public class FragmentBreadCrumbs
  extends ViewGroup
  implements FragmentManager.OnBackStackChangedListener
{
  private static final int DEFAULT_GRAVITY = 8388627;
  Activity mActivity;
  LinearLayout mContainer;
  private int mGravity;
  LayoutInflater mInflater;
  int mMaxVisible = -1;
  private OnBreadCrumbClickListener mOnBreadCrumbClickListener;
  private View.OnClickListener mOnClickListener = new View.OnClickListener()
  {
    public void onClick(View paramAnonymousView)
    {
      FragmentManager.BackStackEntry localBackStackEntry1;
      if ((paramAnonymousView.getTag() instanceof FragmentManager.BackStackEntry))
      {
        localBackStackEntry1 = (FragmentManager.BackStackEntry)paramAnonymousView.getTag();
        if (localBackStackEntry1 != FragmentBreadCrumbs.this.mParentEntry) {
          break label53;
        }
        if (FragmentBreadCrumbs.this.mParentClickListener != null) {
          FragmentBreadCrumbs.this.mParentClickListener.onClick(paramAnonymousView);
        }
      }
      for (;;)
      {
        return;
        label53:
        FragmentBreadCrumbs.OnBreadCrumbClickListener localOnBreadCrumbClickListener;
        if (FragmentBreadCrumbs.this.mOnBreadCrumbClickListener != null)
        {
          localOnBreadCrumbClickListener = FragmentBreadCrumbs.this.mOnBreadCrumbClickListener;
          if (localBackStackEntry1 != FragmentBreadCrumbs.this.mTopEntry) {
            break label122;
          }
        }
        label122:
        for (FragmentManager.BackStackEntry localBackStackEntry2 = null; !localOnBreadCrumbClickListener.onBreadCrumbClick(localBackStackEntry2, 0); localBackStackEntry2 = localBackStackEntry1)
        {
          if (localBackStackEntry1 != FragmentBreadCrumbs.this.mTopEntry) {
            break label128;
          }
          FragmentBreadCrumbs.this.mActivity.getFragmentManager().popBackStack();
          return;
        }
      }
      label128:
      FragmentBreadCrumbs.this.mActivity.getFragmentManager().popBackStack(localBackStackEntry1.getId(), 0);
    }
  };
  private View.OnClickListener mParentClickListener;
  BackStackRecord mParentEntry;
  BackStackRecord mTopEntry;
  
  public FragmentBreadCrumbs(Context paramContext)
  {
    this(paramContext, null);
  }
  
  public FragmentBreadCrumbs(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 16973961);
  }
  
  public FragmentBreadCrumbs(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.FragmentBreadCrumbs, paramInt, 0);
    this.mGravity = localTypedArray.getInt(0, 8388627);
    localTypedArray.recycle();
  }
  
  private BackStackRecord createBackStackEntry(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    if (paramCharSequence1 == null) {
      return null;
    }
    BackStackRecord localBackStackRecord = new BackStackRecord((FragmentManagerImpl)this.mActivity.getFragmentManager());
    localBackStackRecord.setBreadCrumbTitle(paramCharSequence1);
    localBackStackRecord.setBreadCrumbShortTitle(paramCharSequence2);
    return localBackStackRecord;
  }
  
  private FragmentManager.BackStackEntry getPreEntry(int paramInt)
  {
    if (this.mParentEntry != null)
    {
      if (paramInt == 0) {
        return this.mParentEntry;
      }
      return this.mTopEntry;
    }
    return this.mTopEntry;
  }
  
  private int getPreEntryCount()
  {
    int i = 1;
    int j;
    if (this.mTopEntry != null)
    {
      j = i;
      if (this.mParentEntry == null) {
        break label27;
      }
    }
    for (;;)
    {
      return j + i;
      j = 0;
      break;
      label27:
      i = 0;
    }
  }
  
  public void onBackStackChanged()
  {
    updateCrumbs();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (getChildCount() == 0) {
      return;
    }
    View localView = getChildAt(0);
    int i = this.mPaddingTop;
    int j = this.mPaddingTop + localView.getMeasuredHeight() - this.mPaddingBottom;
    int k = getLayoutDirection();
    int m;
    int n;
    switch (Gravity.getAbsoluteGravity(0x800007 & this.mGravity, k))
    {
    default: 
      m = this.mPaddingLeft;
      n = m + localView.getMeasuredWidth();
    }
    for (;;)
    {
      if (m < this.mPaddingLeft) {
        m = this.mPaddingLeft;
      }
      if (n > this.mRight - this.mLeft - this.mPaddingRight) {
        n = this.mRight - this.mLeft - this.mPaddingRight;
      }
      localView.layout(m, i, n, j);
      return;
      n = this.mRight - this.mLeft - this.mPaddingRight;
      m = n - localView.getMeasuredWidth();
      continue;
      m = this.mPaddingLeft + (this.mRight - this.mLeft - localView.getMeasuredWidth()) / 2;
      n = m + localView.getMeasuredWidth();
    }
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i = getChildCount();
    int j = 0;
    int k = 0;
    int m = 0;
    for (int n = 0; n < i; n++)
    {
      View localView = getChildAt(n);
      if (localView.getVisibility() != 8)
      {
        measureChild(localView, paramInt1, paramInt2);
        k = Math.max(k, localView.getMeasuredWidth());
        j = Math.max(j, localView.getMeasuredHeight());
        m = combineMeasuredStates(m, localView.getMeasuredState());
      }
    }
    int i1 = k + (this.mPaddingLeft + this.mPaddingRight);
    int i2 = Math.max(j + (this.mPaddingTop + this.mPaddingBottom), getSuggestedMinimumHeight());
    setMeasuredDimension(resolveSizeAndState(Math.max(i1, getSuggestedMinimumWidth()), paramInt1, m), resolveSizeAndState(i2, paramInt2, m << 16));
  }
  
  public void setActivity(Activity paramActivity)
  {
    this.mActivity = paramActivity;
    this.mInflater = ((LayoutInflater)paramActivity.getSystemService("layout_inflater"));
    this.mContainer = ((LinearLayout)this.mInflater.inflate(17367106, this, false));
    addView(this.mContainer);
    paramActivity.getFragmentManager().addOnBackStackChangedListener(this);
    updateCrumbs();
    setLayoutTransition(new LayoutTransition());
  }
  
  public void setMaxVisible(int paramInt)
  {
    if (paramInt < 1) {
      throw new IllegalArgumentException("visibleCrumbs must be greater than zero");
    }
    this.mMaxVisible = paramInt;
  }
  
  public void setOnBreadCrumbClickListener(OnBreadCrumbClickListener paramOnBreadCrumbClickListener)
  {
    this.mOnBreadCrumbClickListener = paramOnBreadCrumbClickListener;
  }
  
  public void setParentTitle(CharSequence paramCharSequence1, CharSequence paramCharSequence2, View.OnClickListener paramOnClickListener)
  {
    this.mParentEntry = createBackStackEntry(paramCharSequence1, paramCharSequence2);
    this.mParentClickListener = paramOnClickListener;
    updateCrumbs();
  }
  
  public void setTitle(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    this.mTopEntry = createBackStackEntry(paramCharSequence1, paramCharSequence2);
    updateCrumbs();
  }
  
  void updateCrumbs()
  {
    FragmentManager localFragmentManager = this.mActivity.getFragmentManager();
    int i = localFragmentManager.getBackStackEntryCount();
    int j = getPreEntryCount();
    int k = this.mContainer.getChildCount();
    for (int m = 0; m < i + j; m++)
    {
      FragmentManager.BackStackEntry localBackStackEntry;
      if (m < j) {
        localBackStackEntry = getPreEntry(m);
      }
      while ((m < k) && (this.mContainer.getChildAt(m).getTag() != localBackStackEntry))
      {
        int i5 = m;
        for (;;)
        {
          if (i5 < k)
          {
            this.mContainer.removeViewAt(m);
            i5++;
            continue;
            localBackStackEntry = localFragmentManager.getBackStackEntryAt(m - j);
            break;
          }
        }
        k = m;
      }
      if (m >= k)
      {
        View localView4 = this.mInflater.inflate(17367105, this, false);
        TextView localTextView = (TextView)localView4.findViewById(16908310);
        localTextView.setText(localBackStackEntry.getBreadCrumbTitle());
        localTextView.setTag(localBackStackEntry);
        if (m == 0) {
          localView4.findViewById(16908861).setVisibility(8);
        }
        this.mContainer.addView(localView4);
        localTextView.setOnClickListener(this.mOnClickListener);
      }
    }
    int n = i + j;
    for (int i1 = this.mContainer.getChildCount(); i1 > n; i1--) {
      this.mContainer.removeViewAt(i1 - 1);
    }
    int i2 = 0;
    if (i2 < i1)
    {
      View localView1 = this.mContainer.getChildAt(i2);
      View localView2 = localView1.findViewById(16908310);
      boolean bool;
      label295:
      int i3;
      label325:
      View localView3;
      if (i2 < i1 - 1)
      {
        bool = true;
        localView2.setEnabled(bool);
        if (this.mMaxVisible > 0)
        {
          if (i2 >= i1 - this.mMaxVisible) {
            break label381;
          }
          i3 = 8;
          localView1.setVisibility(i3);
          localView3 = localView1.findViewById(16908861);
          if ((i2 <= i1 - this.mMaxVisible) || (i2 == 0)) {
            break label387;
          }
        }
      }
      label381:
      label387:
      for (int i4 = 0;; i4 = 8)
      {
        localView3.setVisibility(i4);
        i2++;
        break;
        bool = false;
        break label295;
        i3 = 0;
        break label325;
      }
    }
  }
  
  public static abstract interface OnBreadCrumbClickListener
  {
    public abstract boolean onBreadCrumbClick(FragmentManager.BackStackEntry paramBackStackEntry, int paramInt);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\FragmentBreadCrumbs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
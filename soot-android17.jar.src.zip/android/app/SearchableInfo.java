package android.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ProviderInfo;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.UserHandle;
import android.util.AttributeSet;
import android.util.Log;
import com.android.internal.R.styleable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

public final class SearchableInfo
  implements Parcelable
{
  public static final Parcelable.Creator<SearchableInfo> CREATOR = new Parcelable.Creator()
  {
    public SearchableInfo createFromParcel(Parcel paramAnonymousParcel)
    {
      return new SearchableInfo(paramAnonymousParcel);
    }
    
    public SearchableInfo[] newArray(int paramAnonymousInt)
    {
      return new SearchableInfo[paramAnonymousInt];
    }
  };
  private static final boolean DBG = false;
  private static final String LOG_TAG = "SearchableInfo";
  private static final String MD_LABEL_SEARCHABLE = "android.app.searchable";
  private static final String MD_XML_ELEMENT_SEARCHABLE = "searchable";
  private static final String MD_XML_ELEMENT_SEARCHABLE_ACTION_KEY = "actionkey";
  private static final int SEARCH_MODE_BADGE_ICON = 8;
  private static final int SEARCH_MODE_BADGE_LABEL = 4;
  private static final int SEARCH_MODE_QUERY_REWRITE_FROM_DATA = 16;
  private static final int SEARCH_MODE_QUERY_REWRITE_FROM_TEXT = 32;
  private static final int VOICE_SEARCH_LAUNCH_RECOGNIZER = 4;
  private static final int VOICE_SEARCH_LAUNCH_WEB_SEARCH = 2;
  private static final int VOICE_SEARCH_SHOW_BUTTON = 1;
  private HashMap<Integer, ActionKeyInfo> mActionKeys = null;
  private final boolean mAutoUrlDetect;
  private final int mHintId;
  private final int mIconId;
  private final boolean mIncludeInGlobalSearch;
  private final int mLabelId;
  private final boolean mQueryAfterZeroResults;
  private final ComponentName mSearchActivity;
  private final int mSearchButtonText;
  private final int mSearchImeOptions;
  private final int mSearchInputType;
  private final int mSearchMode;
  private final int mSettingsDescriptionId;
  private final String mSuggestAuthority;
  private final String mSuggestIntentAction;
  private final String mSuggestIntentData;
  private final String mSuggestPath;
  private final String mSuggestProviderPackage;
  private final String mSuggestSelection;
  private final int mSuggestThreshold;
  private final int mVoiceLanguageId;
  private final int mVoiceLanguageModeId;
  private final int mVoiceMaxResults;
  private final int mVoicePromptTextId;
  private final int mVoiceSearchMode;
  
  private SearchableInfo(Context paramContext, AttributeSet paramAttributeSet, ComponentName paramComponentName)
  {
    this.mSearchActivity = paramComponentName;
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.Searchable);
    this.mSearchMode = localTypedArray.getInt(3, 0);
    this.mLabelId = localTypedArray.getResourceId(0, 0);
    this.mHintId = localTypedArray.getResourceId(2, 0);
    this.mIconId = localTypedArray.getResourceId(1, 0);
    this.mSearchButtonText = localTypedArray.getResourceId(9, 0);
    this.mSearchInputType = localTypedArray.getInt(10, 1);
    this.mSearchImeOptions = localTypedArray.getInt(16, 2);
    this.mIncludeInGlobalSearch = localTypedArray.getBoolean(18, false);
    this.mQueryAfterZeroResults = localTypedArray.getBoolean(19, false);
    this.mAutoUrlDetect = localTypedArray.getBoolean(21, false);
    this.mSettingsDescriptionId = localTypedArray.getResourceId(20, 0);
    this.mSuggestAuthority = localTypedArray.getString(4);
    this.mSuggestPath = localTypedArray.getString(5);
    this.mSuggestSelection = localTypedArray.getString(6);
    this.mSuggestIntentAction = localTypedArray.getString(7);
    this.mSuggestIntentData = localTypedArray.getString(8);
    this.mSuggestThreshold = localTypedArray.getInt(17, 0);
    this.mVoiceSearchMode = localTypedArray.getInt(11, 0);
    this.mVoiceLanguageModeId = localTypedArray.getResourceId(12, 0);
    this.mVoicePromptTextId = localTypedArray.getResourceId(13, 0);
    this.mVoiceLanguageId = localTypedArray.getResourceId(14, 0);
    this.mVoiceMaxResults = localTypedArray.getInt(15, 0);
    localTypedArray.recycle();
    String str1 = this.mSuggestAuthority;
    String str2 = null;
    if (str1 != null)
    {
      ProviderInfo localProviderInfo = paramContext.getPackageManager().resolveContentProvider(this.mSuggestAuthority, 0);
      str2 = null;
      if (localProviderInfo != null) {
        str2 = localProviderInfo.packageName;
      }
    }
    this.mSuggestProviderPackage = str2;
    if (this.mLabelId == 0) {
      throw new IllegalArgumentException("Search label must be a resource reference.");
    }
  }
  
  SearchableInfo(Parcel paramParcel)
  {
    this.mLabelId = paramParcel.readInt();
    this.mSearchActivity = ComponentName.readFromParcel(paramParcel);
    this.mHintId = paramParcel.readInt();
    this.mSearchMode = paramParcel.readInt();
    this.mIconId = paramParcel.readInt();
    this.mSearchButtonText = paramParcel.readInt();
    this.mSearchInputType = paramParcel.readInt();
    this.mSearchImeOptions = paramParcel.readInt();
    boolean bool2;
    boolean bool3;
    if (paramParcel.readInt() != 0)
    {
      bool2 = bool1;
      this.mIncludeInGlobalSearch = bool2;
      if (paramParcel.readInt() == 0) {
        break label208;
      }
      bool3 = bool1;
      label99:
      this.mQueryAfterZeroResults = bool3;
      if (paramParcel.readInt() == 0) {
        break label214;
      }
    }
    for (;;)
    {
      this.mAutoUrlDetect = bool1;
      this.mSettingsDescriptionId = paramParcel.readInt();
      this.mSuggestAuthority = paramParcel.readString();
      this.mSuggestPath = paramParcel.readString();
      this.mSuggestSelection = paramParcel.readString();
      this.mSuggestIntentAction = paramParcel.readString();
      this.mSuggestIntentData = paramParcel.readString();
      this.mSuggestThreshold = paramParcel.readInt();
      for (int i = paramParcel.readInt(); i > 0; i--) {
        addActionKey(new ActionKeyInfo(paramParcel, null));
      }
      bool2 = false;
      break;
      label208:
      bool3 = false;
      break label99;
      label214:
      bool1 = false;
    }
    this.mSuggestProviderPackage = paramParcel.readString();
    this.mVoiceSearchMode = paramParcel.readInt();
    this.mVoiceLanguageModeId = paramParcel.readInt();
    this.mVoicePromptTextId = paramParcel.readInt();
    this.mVoiceLanguageId = paramParcel.readInt();
    this.mVoiceMaxResults = paramParcel.readInt();
  }
  
  private void addActionKey(ActionKeyInfo paramActionKeyInfo)
  {
    if (this.mActionKeys == null) {
      this.mActionKeys = new HashMap();
    }
    this.mActionKeys.put(Integer.valueOf(paramActionKeyInfo.getKeyCode()), paramActionKeyInfo);
  }
  
  private static Context createActivityContext(Context paramContext, ComponentName paramComponentName)
  {
    try
    {
      Context localContext = paramContext.createPackageContext(paramComponentName.getPackageName(), 0);
      return localContext;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      Log.e("SearchableInfo", "Package not found " + paramComponentName.getPackageName());
      return null;
    }
    catch (SecurityException localSecurityException)
    {
      Log.e("SearchableInfo", "Can't make context for " + paramComponentName.getPackageName(), localSecurityException);
    }
    return null;
  }
  
  public static SearchableInfo getActivityMetaData(Context paramContext, ActivityInfo paramActivityInfo, int paramInt)
  {
    Context localContext;
    XmlResourceParser localXmlResourceParser;
    try
    {
      localContext = paramContext.createPackageContextAsUser("system", 0, new UserHandle(paramInt));
      localXmlResourceParser = paramActivityInfo.loadXmlMetaData(localContext.getPackageManager(), "android.app.searchable");
      if (localXmlResourceParser == null) {
        return null;
      }
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      Log.e("SearchableInfo", "Couldn't create package context for user " + paramInt);
      return null;
    }
    SearchableInfo localSearchableInfo = getActivityMetaData(localContext, localXmlResourceParser, new ComponentName(paramActivityInfo.packageName, paramActivityInfo.name));
    localXmlResourceParser.close();
    return localSearchableInfo;
  }
  
  /* Error */
  private static SearchableInfo getActivityMetaData(Context paramContext, org.xmlpull.v1.XmlPullParser paramXmlPullParser, ComponentName paramComponentName)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_2
    //   2: invokestatic 304	android/app/SearchableInfo:createActivityContext	(Landroid/content/Context;Landroid/content/ComponentName;)Landroid/content/Context;
    //   5: astore_3
    //   6: aload_3
    //   7: ifnonnull +5 -> 12
    //   10: aconst_null
    //   11: areturn
    //   12: aload_1
    //   13: invokeinterface 309 1 0
    //   18: istore 8
    //   20: iload 8
    //   22: istore 9
    //   24: aconst_null
    //   25: astore 10
    //   27: iload 9
    //   29: iconst_1
    //   30: if_icmpeq +293 -> 323
    //   33: iload 9
    //   35: iconst_2
    //   36: if_icmpne +309 -> 345
    //   39: aload_1
    //   40: invokeinterface 312 1 0
    //   45: ldc 22
    //   47: invokevirtual 318	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   50: ifeq +96 -> 146
    //   53: aload_1
    //   54: invokestatic 324	android/util/Xml:asAttributeSet	(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;
    //   57: astore 21
    //   59: aload 21
    //   61: ifnull +284 -> 345
    //   64: new 2	android/app/SearchableInfo
    //   67: dup
    //   68: aload_3
    //   69: aload 21
    //   71: aload_2
    //   72: invokespecial 326	android/app/SearchableInfo:<init>	(Landroid/content/Context;Landroid/util/AttributeSet;Landroid/content/ComponentName;)V
    //   75: astore 12
    //   77: aload_1
    //   78: invokeinterface 309 1 0
    //   83: istore 13
    //   85: iload 13
    //   87: istore 9
    //   89: aload 12
    //   91: astore 10
    //   93: goto -66 -> 27
    //   96: astore 22
    //   98: ldc 16
    //   100: new 239	java/lang/StringBuilder
    //   103: dup
    //   104: invokespecial 240	java/lang/StringBuilder:<init>	()V
    //   107: ldc_w 328
    //   110: invokevirtual 246	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   113: aload_2
    //   114: invokevirtual 331	android/content/ComponentName:flattenToShortString	()Ljava/lang/String;
    //   117: invokevirtual 246	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   120: ldc_w 333
    //   123: invokevirtual 246	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   126: aload 22
    //   128: invokevirtual 336	java/lang/IllegalArgumentException:getMessage	()Ljava/lang/String;
    //   131: invokevirtual 246	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   134: invokevirtual 249	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   137: invokestatic 339	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   140: pop
    //   141: aload 10
    //   143: pop
    //   144: aconst_null
    //   145: areturn
    //   146: aload_1
    //   147: invokeinterface 312 1 0
    //   152: ldc 25
    //   154: invokevirtual 318	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   157: ifeq +188 -> 345
    //   160: aload 10
    //   162: ifnonnull +8 -> 170
    //   165: aload 10
    //   167: pop
    //   168: aconst_null
    //   169: areturn
    //   170: aload_1
    //   171: invokestatic 324	android/util/Xml:asAttributeSet	(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;
    //   174: astore 16
    //   176: aload 16
    //   178: ifnull +167 -> 345
    //   181: aload 10
    //   183: new 201	android/app/SearchableInfo$ActionKeyInfo
    //   186: dup
    //   187: aload_3
    //   188: aload 16
    //   190: invokespecial 342	android/app/SearchableInfo$ActionKeyInfo:<init>	(Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   193: invokespecial 208	android/app/SearchableInfo:addActionKey	(Landroid/app/SearchableInfo$ActionKeyInfo;)V
    //   196: aload 10
    //   198: astore 12
    //   200: goto -123 -> 77
    //   203: astore 17
    //   205: ldc 16
    //   207: new 239	java/lang/StringBuilder
    //   210: dup
    //   211: invokespecial 240	java/lang/StringBuilder:<init>	()V
    //   214: ldc_w 344
    //   217: invokevirtual 246	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   220: aload_2
    //   221: invokevirtual 331	android/content/ComponentName:flattenToShortString	()Ljava/lang/String;
    //   224: invokevirtual 246	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   227: ldc_w 333
    //   230: invokevirtual 246	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   233: aload 17
    //   235: invokevirtual 336	java/lang/IllegalArgumentException:getMessage	()Ljava/lang/String;
    //   238: invokevirtual 246	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   241: invokevirtual 249	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   244: invokestatic 339	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   247: pop
    //   248: aload 10
    //   250: pop
    //   251: aconst_null
    //   252: areturn
    //   253: astore 6
    //   255: ldc 16
    //   257: new 239	java/lang/StringBuilder
    //   260: dup
    //   261: invokespecial 240	java/lang/StringBuilder:<init>	()V
    //   264: ldc_w 346
    //   267: invokevirtual 246	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   270: aload_2
    //   271: invokevirtual 331	android/content/ComponentName:flattenToShortString	()Ljava/lang/String;
    //   274: invokevirtual 246	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   277: invokevirtual 249	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   280: aload 6
    //   282: invokestatic 348	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   285: pop
    //   286: aconst_null
    //   287: areturn
    //   288: astore 4
    //   290: ldc 16
    //   292: new 239	java/lang/StringBuilder
    //   295: dup
    //   296: invokespecial 240	java/lang/StringBuilder:<init>	()V
    //   299: ldc_w 346
    //   302: invokevirtual 246	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   305: aload_2
    //   306: invokevirtual 331	android/content/ComponentName:flattenToShortString	()Ljava/lang/String;
    //   309: invokevirtual 246	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   312: invokevirtual 249	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   315: aload 4
    //   317: invokestatic 348	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   320: pop
    //   321: aconst_null
    //   322: areturn
    //   323: aload 10
    //   325: pop
    //   326: aload 10
    //   328: areturn
    //   329: astore 4
    //   331: aload 10
    //   333: pop
    //   334: goto -44 -> 290
    //   337: astore 6
    //   339: aload 10
    //   341: pop
    //   342: goto -87 -> 255
    //   345: aload 10
    //   347: astore 12
    //   349: goto -272 -> 77
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	352	0	paramContext	Context
    //   0	352	1	paramXmlPullParser	org.xmlpull.v1.XmlPullParser
    //   0	352	2	paramComponentName	ComponentName
    //   5	183	3	localContext	Context
    //   288	28	4	localIOException1	java.io.IOException
    //   329	1	4	localIOException2	java.io.IOException
    //   253	28	6	localXmlPullParserException1	org.xmlpull.v1.XmlPullParserException
    //   337	1	6	localXmlPullParserException2	org.xmlpull.v1.XmlPullParserException
    //   18	3	8	i	int
    //   22	66	9	j	int
    //   25	321	10	localObject1	Object
    //   75	273	12	localObject2	Object
    //   83	3	13	k	int
    //   174	15	16	localAttributeSet1	AttributeSet
    //   203	31	17	localIllegalArgumentException1	IllegalArgumentException
    //   57	13	21	localAttributeSet2	AttributeSet
    //   96	31	22	localIllegalArgumentException2	IllegalArgumentException
    // Exception table:
    //   from	to	target	type
    //   64	77	96	java/lang/IllegalArgumentException
    //   181	196	203	java/lang/IllegalArgumentException
    //   12	20	253	org/xmlpull/v1/XmlPullParserException
    //   77	85	253	org/xmlpull/v1/XmlPullParserException
    //   12	20	288	java/io/IOException
    //   77	85	288	java/io/IOException
    //   39	59	329	java/io/IOException
    //   64	77	329	java/io/IOException
    //   98	141	329	java/io/IOException
    //   146	160	329	java/io/IOException
    //   170	176	329	java/io/IOException
    //   181	196	329	java/io/IOException
    //   205	248	329	java/io/IOException
    //   39	59	337	org/xmlpull/v1/XmlPullParserException
    //   64	77	337	org/xmlpull/v1/XmlPullParserException
    //   98	141	337	org/xmlpull/v1/XmlPullParserException
    //   146	160	337	org/xmlpull/v1/XmlPullParserException
    //   170	176	337	org/xmlpull/v1/XmlPullParserException
    //   181	196	337	org/xmlpull/v1/XmlPullParserException
    //   205	248	337	org/xmlpull/v1/XmlPullParserException
  }
  
  public boolean autoUrlDetect()
  {
    return this.mAutoUrlDetect;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public ActionKeyInfo findActionKey(int paramInt)
  {
    if (this.mActionKeys == null) {
      return null;
    }
    return (ActionKeyInfo)this.mActionKeys.get(Integer.valueOf(paramInt));
  }
  
  public Context getActivityContext(Context paramContext)
  {
    return createActivityContext(paramContext, this.mSearchActivity);
  }
  
  public int getHintId()
  {
    return this.mHintId;
  }
  
  public int getIconId()
  {
    return this.mIconId;
  }
  
  public int getImeOptions()
  {
    return this.mSearchImeOptions;
  }
  
  public int getInputType()
  {
    return this.mSearchInputType;
  }
  
  public int getLabelId()
  {
    return this.mLabelId;
  }
  
  public Context getProviderContext(Context paramContext1, Context paramContext2)
  {
    if (this.mSearchActivity.getPackageName().equals(this.mSuggestProviderPackage)) {
      return paramContext2;
    }
    String str = this.mSuggestProviderPackage;
    localObject = null;
    if (str != null) {}
    try
    {
      Context localContext = paramContext1.createPackageContext(this.mSuggestProviderPackage, 0);
      localObject = localContext;
    }
    catch (SecurityException localSecurityException)
    {
      for (;;)
      {
        localObject = null;
      }
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      for (;;)
      {
        localObject = null;
      }
    }
    return (Context)localObject;
  }
  
  public ComponentName getSearchActivity()
  {
    return this.mSearchActivity;
  }
  
  public int getSearchButtonText()
  {
    return this.mSearchButtonText;
  }
  
  public int getSettingsDescriptionId()
  {
    return this.mSettingsDescriptionId;
  }
  
  public String getSuggestAuthority()
  {
    return this.mSuggestAuthority;
  }
  
  public String getSuggestIntentAction()
  {
    return this.mSuggestIntentAction;
  }
  
  public String getSuggestIntentData()
  {
    return this.mSuggestIntentData;
  }
  
  public String getSuggestPackage()
  {
    return this.mSuggestProviderPackage;
  }
  
  public String getSuggestPath()
  {
    return this.mSuggestPath;
  }
  
  public String getSuggestSelection()
  {
    return this.mSuggestSelection;
  }
  
  public int getSuggestThreshold()
  {
    return this.mSuggestThreshold;
  }
  
  public int getVoiceLanguageId()
  {
    return this.mVoiceLanguageId;
  }
  
  public int getVoiceLanguageModeId()
  {
    return this.mVoiceLanguageModeId;
  }
  
  public int getVoiceMaxResults()
  {
    return this.mVoiceMaxResults;
  }
  
  public int getVoicePromptTextId()
  {
    return this.mVoicePromptTextId;
  }
  
  public boolean getVoiceSearchEnabled()
  {
    return (0x1 & this.mVoiceSearchMode) != 0;
  }
  
  public boolean getVoiceSearchLaunchRecognizer()
  {
    return (0x4 & this.mVoiceSearchMode) != 0;
  }
  
  public boolean getVoiceSearchLaunchWebSearch()
  {
    return (0x2 & this.mVoiceSearchMode) != 0;
  }
  
  public boolean queryAfterZeroResults()
  {
    return this.mQueryAfterZeroResults;
  }
  
  public boolean shouldIncludeInGlobalSearch()
  {
    return this.mIncludeInGlobalSearch;
  }
  
  public boolean shouldRewriteQueryFromData()
  {
    return (0x10 & this.mSearchMode) != 0;
  }
  
  public boolean shouldRewriteQueryFromText()
  {
    return (0x20 & this.mSearchMode) != 0;
  }
  
  public boolean useBadgeIcon()
  {
    return ((0x8 & this.mSearchMode) != 0) && (this.mIconId != 0);
  }
  
  public boolean useBadgeLabel()
  {
    return (0x4 & this.mSearchMode) != 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    int i = 1;
    paramParcel.writeInt(this.mLabelId);
    this.mSearchActivity.writeToParcel(paramParcel, paramInt);
    paramParcel.writeInt(this.mHintId);
    paramParcel.writeInt(this.mSearchMode);
    paramParcel.writeInt(this.mIconId);
    paramParcel.writeInt(this.mSearchButtonText);
    paramParcel.writeInt(this.mSearchInputType);
    paramParcel.writeInt(this.mSearchImeOptions);
    int j;
    int k;
    if (this.mIncludeInGlobalSearch)
    {
      j = i;
      paramParcel.writeInt(j);
      if (!this.mQueryAfterZeroResults) {
        break label234;
      }
      k = i;
      label93:
      paramParcel.writeInt(k);
      if (!this.mAutoUrlDetect) {
        break label240;
      }
      label106:
      paramParcel.writeInt(i);
      paramParcel.writeInt(this.mSettingsDescriptionId);
      paramParcel.writeString(this.mSuggestAuthority);
      paramParcel.writeString(this.mSuggestPath);
      paramParcel.writeString(this.mSuggestSelection);
      paramParcel.writeString(this.mSuggestIntentAction);
      paramParcel.writeString(this.mSuggestIntentData);
      paramParcel.writeInt(this.mSuggestThreshold);
      if (this.mActionKeys != null) {
        break label245;
      }
      paramParcel.writeInt(0);
    }
    for (;;)
    {
      paramParcel.writeString(this.mSuggestProviderPackage);
      paramParcel.writeInt(this.mVoiceSearchMode);
      paramParcel.writeInt(this.mVoiceLanguageModeId);
      paramParcel.writeInt(this.mVoicePromptTextId);
      paramParcel.writeInt(this.mVoiceLanguageId);
      paramParcel.writeInt(this.mVoiceMaxResults);
      return;
      j = 0;
      break;
      label234:
      k = 0;
      break label93;
      label240:
      i = 0;
      break label106;
      label245:
      paramParcel.writeInt(this.mActionKeys.size());
      Iterator localIterator = this.mActionKeys.values().iterator();
      while (localIterator.hasNext()) {
        ((ActionKeyInfo)localIterator.next()).writeToParcel(paramParcel, paramInt);
      }
    }
  }
  
  public static class ActionKeyInfo
    implements Parcelable
  {
    private final int mKeyCode;
    private final String mQueryActionMsg;
    private final String mSuggestActionMsg;
    private final String mSuggestActionMsgColumn;
    
    ActionKeyInfo(Context paramContext, AttributeSet paramAttributeSet)
    {
      TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.SearchableActionKey);
      this.mKeyCode = localTypedArray.getInt(0, 0);
      this.mQueryActionMsg = localTypedArray.getString(1);
      this.mSuggestActionMsg = localTypedArray.getString(2);
      this.mSuggestActionMsgColumn = localTypedArray.getString(3);
      localTypedArray.recycle();
      if (this.mKeyCode == 0) {
        throw new IllegalArgumentException("No keycode.");
      }
      if ((this.mQueryActionMsg == null) && (this.mSuggestActionMsg == null) && (this.mSuggestActionMsgColumn == null)) {
        throw new IllegalArgumentException("No message information.");
      }
    }
    
    private ActionKeyInfo(Parcel paramParcel)
    {
      this.mKeyCode = paramParcel.readInt();
      this.mQueryActionMsg = paramParcel.readString();
      this.mSuggestActionMsg = paramParcel.readString();
      this.mSuggestActionMsgColumn = paramParcel.readString();
    }
    
    public int describeContents()
    {
      return 0;
    }
    
    public int getKeyCode()
    {
      return this.mKeyCode;
    }
    
    public String getQueryActionMsg()
    {
      return this.mQueryActionMsg;
    }
    
    public String getSuggestActionMsg()
    {
      return this.mSuggestActionMsg;
    }
    
    public String getSuggestActionMsgColumn()
    {
      return this.mSuggestActionMsgColumn;
    }
    
    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      paramParcel.writeInt(this.mKeyCode);
      paramParcel.writeString(this.mQueryActionMsg);
      paramParcel.writeString(this.mSuggestActionMsg);
      paramParcel.writeString(this.mSuggestActionMsgColumn);
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\SearchableInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
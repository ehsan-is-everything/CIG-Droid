package android.app;

import android.graphics.Bitmap;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import android.text.TextUtils;

public abstract interface IThumbnailReceiver
  extends IInterface
{
  public abstract void finished()
    throws RemoteException;
  
  public abstract void newThumbnail(int paramInt, Bitmap paramBitmap, CharSequence paramCharSequence)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IThumbnailReceiver
  {
    private static final String DESCRIPTOR = "android.app.IThumbnailReceiver";
    static final int TRANSACTION_finished = 2;
    static final int TRANSACTION_newThumbnail = 1;
    
    public Stub()
    {
      attachInterface(this, "android.app.IThumbnailReceiver");
    }
    
    public static IThumbnailReceiver asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.app.IThumbnailReceiver");
      if ((localIInterface != null) && ((localIInterface instanceof IThumbnailReceiver))) {
        return (IThumbnailReceiver)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.app.IThumbnailReceiver");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.app.IThumbnailReceiver");
        int i = paramParcel1.readInt();
        Bitmap localBitmap;
        if (paramParcel1.readInt() != 0)
        {
          localBitmap = (Bitmap)Bitmap.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label126;
          }
        }
        label126:
        for (CharSequence localCharSequence = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel1);; localCharSequence = null)
        {
          newThumbnail(i, localBitmap, localCharSequence);
          return true;
          localBitmap = null;
          break;
        }
      }
      paramParcel1.enforceInterface("android.app.IThumbnailReceiver");
      finished();
      return true;
    }
    
    private static class Proxy
      implements IThumbnailReceiver
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public void finished()
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.app.IThumbnailReceiver");
          this.mRemote.transact(2, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.app.IThumbnailReceiver";
      }
      
      public void newThumbnail(int paramInt, Bitmap paramBitmap, CharSequence paramCharSequence)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel.writeInterfaceToken("android.app.IThumbnailReceiver");
            localParcel.writeInt(paramInt);
            if (paramBitmap != null)
            {
              localParcel.writeInt(1);
              paramBitmap.writeToParcel(localParcel, 0);
              if (paramCharSequence != null)
              {
                localParcel.writeInt(1);
                TextUtils.writeToParcel(paramCharSequence, localParcel, 0);
                this.mRemote.transact(1, localParcel, null, 1);
              }
            }
            else
            {
              localParcel.writeInt(0);
              continue;
            }
            localParcel.writeInt(0);
          }
          finally
          {
            localParcel.recycle();
          }
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\IThumbnailReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
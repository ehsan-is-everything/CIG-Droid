package android.app.admin;

import android.content.ComponentName;
import android.content.Context;
import android.os.Handler;
import android.os.RemoteCallback;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.UserHandle;
import android.util.Log;
import java.net.InetSocketAddress;
import java.net.Proxy.Type;
import java.util.Iterator;
import java.util.List;

public class DevicePolicyManager
{
  public static final String ACTION_ADD_DEVICE_ADMIN = "android.app.action.ADD_DEVICE_ADMIN";
  public static final String ACTION_DEVICE_POLICY_MANAGER_STATE_CHANGED = "android.app.action.DEVICE_POLICY_MANAGER_STATE_CHANGED";
  public static final String ACTION_SET_NEW_PASSWORD = "android.app.action.SET_NEW_PASSWORD";
  public static final String ACTION_START_ENCRYPTION = "android.app.action.START_ENCRYPTION";
  public static final int ENCRYPTION_STATUS_ACTIVATING = 2;
  public static final int ENCRYPTION_STATUS_ACTIVE = 3;
  public static final int ENCRYPTION_STATUS_INACTIVE = 1;
  public static final int ENCRYPTION_STATUS_UNSUPPORTED = 0;
  public static final String EXTRA_ADD_EXPLANATION = "android.app.extra.ADD_EXPLANATION";
  public static final String EXTRA_DEVICE_ADMIN = "android.app.extra.DEVICE_ADMIN";
  public static final int KEYGUARD_DISABLE_FEATURES_ALL = Integer.MAX_VALUE;
  public static final int KEYGUARD_DISABLE_FEATURES_NONE = 0;
  public static final int KEYGUARD_DISABLE_SECURE_CAMERA = 2;
  public static final int KEYGUARD_DISABLE_WIDGETS_ALL = 1;
  public static final int PASSWORD_QUALITY_ALPHABETIC = 262144;
  public static final int PASSWORD_QUALITY_ALPHANUMERIC = 327680;
  public static final int PASSWORD_QUALITY_BIOMETRIC_WEAK = 32768;
  public static final int PASSWORD_QUALITY_COMPLEX = 393216;
  public static final int PASSWORD_QUALITY_NUMERIC = 131072;
  public static final int PASSWORD_QUALITY_SOMETHING = 65536;
  public static final int PASSWORD_QUALITY_UNSPECIFIED = 0;
  public static final int RESET_PASSWORD_REQUIRE_ENTRY = 1;
  private static String TAG = "DevicePolicyManager";
  public static final int WIPE_EXTERNAL_STORAGE = 1;
  private final Context mContext;
  private final IDevicePolicyManager mService;
  
  private DevicePolicyManager(Context paramContext, Handler paramHandler)
  {
    this.mContext = paramContext;
    this.mService = IDevicePolicyManager.Stub.asInterface(ServiceManager.getService("device_policy"));
  }
  
  public static DevicePolicyManager create(Context paramContext, Handler paramHandler)
  {
    DevicePolicyManager localDevicePolicyManager = new DevicePolicyManager(paramContext, paramHandler);
    if (localDevicePolicyManager.mService != null) {
      return localDevicePolicyManager;
    }
    return null;
  }
  
  public List<ComponentName> getActiveAdmins()
  {
    if (this.mService != null) {
      try
      {
        List localList = this.mService.getActiveAdmins(UserHandle.myUserId());
        return localList;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return null;
  }
  
  /* Error */
  public DeviceAdminInfo getAdminInfo(ComponentName paramComponentName)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 69	android/app/admin/DevicePolicyManager:mContext	Landroid/content/Context;
    //   4: invokevirtual 126	android/content/Context:getPackageManager	()Landroid/content/pm/PackageManager;
    //   7: aload_1
    //   8: sipush 128
    //   11: invokevirtual 132	android/content/pm/PackageManager:getReceiverInfo	(Landroid/content/ComponentName;I)Landroid/content/pm/ActivityInfo;
    //   14: astore 4
    //   16: new 134	android/content/pm/ResolveInfo
    //   19: dup
    //   20: invokespecial 135	android/content/pm/ResolveInfo:<init>	()V
    //   23: astore 5
    //   25: aload 5
    //   27: aload 4
    //   29: putfield 139	android/content/pm/ResolveInfo:activityInfo	Landroid/content/pm/ActivityInfo;
    //   32: new 141	android/app/admin/DeviceAdminInfo
    //   35: dup
    //   36: aload_0
    //   37: getfield 69	android/app/admin/DevicePolicyManager:mContext	Landroid/content/Context;
    //   40: aload 5
    //   42: invokespecial 144	android/app/admin/DeviceAdminInfo:<init>	(Landroid/content/Context;Landroid/content/pm/ResolveInfo;)V
    //   45: astore 6
    //   47: aload 6
    //   49: areturn
    //   50: astore_2
    //   51: getstatic 63	android/app/admin/DevicePolicyManager:TAG	Ljava/lang/String;
    //   54: new 146	java/lang/StringBuilder
    //   57: dup
    //   58: invokespecial 147	java/lang/StringBuilder:<init>	()V
    //   61: ldc -107
    //   63: invokevirtual 153	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: aload_1
    //   67: invokevirtual 156	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   70: invokevirtual 160	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   73: aload_2
    //   74: invokestatic 112	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   77: pop
    //   78: aconst_null
    //   79: areturn
    //   80: astore 9
    //   82: getstatic 63	android/app/admin/DevicePolicyManager:TAG	Ljava/lang/String;
    //   85: new 146	java/lang/StringBuilder
    //   88: dup
    //   89: invokespecial 147	java/lang/StringBuilder:<init>	()V
    //   92: ldc -94
    //   94: invokevirtual 153	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   97: aload_1
    //   98: invokevirtual 156	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   101: invokevirtual 160	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   104: aload 9
    //   106: invokestatic 112	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   109: pop
    //   110: aconst_null
    //   111: areturn
    //   112: astore 7
    //   114: getstatic 63	android/app/admin/DevicePolicyManager:TAG	Ljava/lang/String;
    //   117: new 146	java/lang/StringBuilder
    //   120: dup
    //   121: invokespecial 147	java/lang/StringBuilder:<init>	()V
    //   124: ldc -94
    //   126: invokevirtual 153	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   129: aload_1
    //   130: invokevirtual 156	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   133: invokevirtual 160	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   136: aload 7
    //   138: invokestatic 112	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   141: pop
    //   142: aconst_null
    //   143: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	144	0	this	DevicePolicyManager
    //   0	144	1	paramComponentName	ComponentName
    //   50	24	2	localNameNotFoundException	android.content.pm.PackageManager.NameNotFoundException
    //   14	14	4	localActivityInfo	android.content.pm.ActivityInfo
    //   23	18	5	localResolveInfo	android.content.pm.ResolveInfo
    //   45	3	6	localDeviceAdminInfo	DeviceAdminInfo
    //   112	25	7	localIOException	java.io.IOException
    //   80	25	9	localXmlPullParserException	org.xmlpull.v1.XmlPullParserException
    // Exception table:
    //   from	to	target	type
    //   0	16	50	android/content/pm/PackageManager$NameNotFoundException
    //   32	47	80	org/xmlpull/v1/XmlPullParserException
    //   32	47	112	java/io/IOException
  }
  
  public boolean getCameraDisabled(ComponentName paramComponentName)
  {
    return getCameraDisabled(paramComponentName, UserHandle.myUserId());
  }
  
  public boolean getCameraDisabled(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {
      try
      {
        boolean bool = this.mService.getCameraDisabled(paramComponentName, paramInt);
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return false;
  }
  
  public int getCurrentFailedPasswordAttempts()
  {
    if (this.mService != null) {
      try
      {
        int i = this.mService.getCurrentFailedPasswordAttempts(UserHandle.myUserId());
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return -1;
  }
  
  public ComponentName getGlobalProxyAdmin()
  {
    if (this.mService != null) {
      try
      {
        ComponentName localComponentName = this.mService.getGlobalProxyAdmin(UserHandle.myUserId());
        return localComponentName;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return null;
  }
  
  public int getKeyguardDisabledFeatures(ComponentName paramComponentName)
  {
    return getKeyguardDisabledFeatures(paramComponentName, UserHandle.myUserId());
  }
  
  public int getKeyguardDisabledFeatures(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {
      try
      {
        int i = this.mService.getKeyguardDisabledFeatures(paramComponentName, paramInt);
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return 0;
  }
  
  public int getMaximumFailedPasswordsForWipe(ComponentName paramComponentName)
  {
    return getMaximumFailedPasswordsForWipe(paramComponentName, UserHandle.myUserId());
  }
  
  public int getMaximumFailedPasswordsForWipe(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {
      try
      {
        int i = this.mService.getMaximumFailedPasswordsForWipe(paramComponentName, paramInt);
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return 0;
  }
  
  public long getMaximumTimeToLock(ComponentName paramComponentName)
  {
    return getMaximumTimeToLock(paramComponentName, UserHandle.myUserId());
  }
  
  public long getMaximumTimeToLock(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {
      try
      {
        long l = this.mService.getMaximumTimeToLock(paramComponentName, paramInt);
        return l;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return 0L;
  }
  
  public long getPasswordExpiration(ComponentName paramComponentName)
  {
    if (this.mService != null) {
      try
      {
        long l = this.mService.getPasswordExpiration(paramComponentName, UserHandle.myUserId());
        return l;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return 0L;
  }
  
  public long getPasswordExpirationTimeout(ComponentName paramComponentName)
  {
    if (this.mService != null) {
      try
      {
        long l = this.mService.getPasswordExpirationTimeout(paramComponentName, UserHandle.myUserId());
        return l;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return 0L;
  }
  
  public int getPasswordHistoryLength(ComponentName paramComponentName)
  {
    return getPasswordHistoryLength(paramComponentName, UserHandle.myUserId());
  }
  
  public int getPasswordHistoryLength(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {
      try
      {
        int i = this.mService.getPasswordHistoryLength(paramComponentName, paramInt);
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return 0;
  }
  
  public int getPasswordMaximumLength(int paramInt)
  {
    return 16;
  }
  
  public int getPasswordMinimumLength(ComponentName paramComponentName)
  {
    return getPasswordMinimumLength(paramComponentName, UserHandle.myUserId());
  }
  
  public int getPasswordMinimumLength(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {
      try
      {
        int i = this.mService.getPasswordMinimumLength(paramComponentName, paramInt);
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return 0;
  }
  
  public int getPasswordMinimumLetters(ComponentName paramComponentName)
  {
    return getPasswordMinimumLetters(paramComponentName, UserHandle.myUserId());
  }
  
  public int getPasswordMinimumLetters(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {
      try
      {
        int i = this.mService.getPasswordMinimumLetters(paramComponentName, paramInt);
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return 0;
  }
  
  public int getPasswordMinimumLowerCase(ComponentName paramComponentName)
  {
    return getPasswordMinimumLowerCase(paramComponentName, UserHandle.myUserId());
  }
  
  public int getPasswordMinimumLowerCase(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {
      try
      {
        int i = this.mService.getPasswordMinimumLowerCase(paramComponentName, paramInt);
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return 0;
  }
  
  public int getPasswordMinimumNonLetter(ComponentName paramComponentName)
  {
    return getPasswordMinimumNonLetter(paramComponentName, UserHandle.myUserId());
  }
  
  public int getPasswordMinimumNonLetter(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {
      try
      {
        int i = this.mService.getPasswordMinimumNonLetter(paramComponentName, paramInt);
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return 0;
  }
  
  public int getPasswordMinimumNumeric(ComponentName paramComponentName)
  {
    return getPasswordMinimumNumeric(paramComponentName, UserHandle.myUserId());
  }
  
  public int getPasswordMinimumNumeric(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {
      try
      {
        int i = this.mService.getPasswordMinimumNumeric(paramComponentName, paramInt);
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return 0;
  }
  
  public int getPasswordMinimumSymbols(ComponentName paramComponentName)
  {
    return getPasswordMinimumSymbols(paramComponentName, UserHandle.myUserId());
  }
  
  public int getPasswordMinimumSymbols(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {
      try
      {
        int i = this.mService.getPasswordMinimumSymbols(paramComponentName, paramInt);
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return 0;
  }
  
  public int getPasswordMinimumUpperCase(ComponentName paramComponentName)
  {
    return getPasswordMinimumUpperCase(paramComponentName, UserHandle.myUserId());
  }
  
  public int getPasswordMinimumUpperCase(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {
      try
      {
        int i = this.mService.getPasswordMinimumUpperCase(paramComponentName, paramInt);
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return 0;
  }
  
  public int getPasswordQuality(ComponentName paramComponentName)
  {
    return getPasswordQuality(paramComponentName, UserHandle.myUserId());
  }
  
  public int getPasswordQuality(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {
      try
      {
        int i = this.mService.getPasswordQuality(paramComponentName, paramInt);
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return 0;
  }
  
  public void getRemoveWarning(ComponentName paramComponentName, RemoteCallback paramRemoteCallback)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.getRemoveWarning(paramComponentName, paramRemoteCallback, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public boolean getStorageEncryption(ComponentName paramComponentName)
  {
    if (this.mService != null) {
      try
      {
        boolean bool = this.mService.getStorageEncryption(paramComponentName, UserHandle.myUserId());
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return false;
  }
  
  public int getStorageEncryptionStatus()
  {
    return getStorageEncryptionStatus(UserHandle.myUserId());
  }
  
  public int getStorageEncryptionStatus(int paramInt)
  {
    if (this.mService != null) {
      try
      {
        int i = this.mService.getStorageEncryptionStatus(paramInt);
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return 0;
  }
  
  public boolean hasGrantedPolicy(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {
      try
      {
        boolean bool = this.mService.hasGrantedPolicy(paramComponentName, paramInt, UserHandle.myUserId());
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return false;
  }
  
  public boolean isActivePasswordSufficient()
  {
    if (this.mService != null) {
      try
      {
        boolean bool = this.mService.isActivePasswordSufficient(UserHandle.myUserId());
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return false;
  }
  
  public boolean isAdminActive(ComponentName paramComponentName)
  {
    if (this.mService != null) {
      try
      {
        boolean bool = this.mService.isAdminActive(paramComponentName, UserHandle.myUserId());
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return false;
  }
  
  public void lockNow()
  {
    if (this.mService != null) {}
    try
    {
      this.mService.lockNow();
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public boolean packageHasActiveAdmins(String paramString)
  {
    if (this.mService != null) {
      try
      {
        boolean bool = this.mService.packageHasActiveAdmins(paramString, UserHandle.myUserId());
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return false;
  }
  
  public void removeActiveAdmin(ComponentName paramComponentName)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.removeActiveAdmin(paramComponentName, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public void reportFailedPasswordAttempt(int paramInt)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.reportFailedPasswordAttempt(paramInt);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public void reportSuccessfulPasswordAttempt(int paramInt)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.reportSuccessfulPasswordAttempt(paramInt);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public boolean resetPassword(String paramString, int paramInt)
  {
    if (this.mService != null) {
      try
      {
        boolean bool = this.mService.resetPassword(paramString, paramInt, UserHandle.myUserId());
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return false;
  }
  
  public void setActiveAdmin(ComponentName paramComponentName, boolean paramBoolean)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.setActiveAdmin(paramComponentName, paramBoolean, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public void setActivePasswordState(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.setActivePasswordState(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public void setCameraDisabled(ComponentName paramComponentName, boolean paramBoolean)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.setCameraDisabled(paramComponentName, paramBoolean, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public ComponentName setGlobalProxy(ComponentName paramComponentName, java.net.Proxy paramProxy, List<String> paramList)
  {
    if (paramProxy == null) {
      throw new NullPointerException();
    }
    if (this.mService != null) {}
    Object localObject;
    for (;;)
    {
      try
      {
        if (paramProxy.equals(java.net.Proxy.NO_PROXY))
        {
          str1 = null;
          localObject = null;
          return this.mService.setGlobalProxy(paramComponentName, str1, (String)localObject, UserHandle.myUserId());
        }
        if (paramProxy.type().equals(Proxy.Type.HTTP)) {
          break label89;
        }
        throw new IllegalArgumentException();
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
      return null;
      label89:
      InetSocketAddress localInetSocketAddress = (InetSocketAddress)paramProxy.address();
      String str2 = localInetSocketAddress.getHostName();
      int i = localInetSocketAddress.getPort();
      String str1 = str2 + ":" + Integer.toString(i);
      if (paramList != null) {
        break;
      }
      localObject = "";
      android.net.Proxy.validate(str2, Integer.toString(i), (String)localObject);
    }
    StringBuilder localStringBuilder = new StringBuilder();
    int j = 1;
    Iterator localIterator = paramList.iterator();
    label187:
    String str4;
    if (localIterator.hasNext())
    {
      str4 = (String)localIterator.next();
      if (j != 0) {
        break label253;
      }
      localStringBuilder = localStringBuilder.append(",");
    }
    for (;;)
    {
      localStringBuilder = localStringBuilder.append(str4.trim());
      break label187;
      String str3 = localStringBuilder.toString();
      localObject = str3;
      break;
      label253:
      j = 0;
    }
  }
  
  public void setKeyguardDisabledFeatures(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.setKeyguardDisabledFeatures(paramComponentName, paramInt, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public void setMaximumFailedPasswordsForWipe(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.setMaximumFailedPasswordsForWipe(paramComponentName, paramInt, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public void setMaximumTimeToLock(ComponentName paramComponentName, long paramLong)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.setMaximumTimeToLock(paramComponentName, paramLong, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public void setPasswordExpirationTimeout(ComponentName paramComponentName, long paramLong)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.setPasswordExpirationTimeout(paramComponentName, paramLong, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public void setPasswordHistoryLength(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.setPasswordHistoryLength(paramComponentName, paramInt, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public void setPasswordMinimumLength(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.setPasswordMinimumLength(paramComponentName, paramInt, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public void setPasswordMinimumLetters(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.setPasswordMinimumLetters(paramComponentName, paramInt, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public void setPasswordMinimumLowerCase(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.setPasswordMinimumLowerCase(paramComponentName, paramInt, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public void setPasswordMinimumNonLetter(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.setPasswordMinimumNonLetter(paramComponentName, paramInt, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public void setPasswordMinimumNumeric(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.setPasswordMinimumNumeric(paramComponentName, paramInt, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public void setPasswordMinimumSymbols(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.setPasswordMinimumSymbols(paramComponentName, paramInt, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public void setPasswordMinimumUpperCase(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.setPasswordMinimumUpperCase(paramComponentName, paramInt, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public void setPasswordQuality(ComponentName paramComponentName, int paramInt)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.setPasswordQuality(paramComponentName, paramInt, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
  
  public int setStorageEncryption(ComponentName paramComponentName, boolean paramBoolean)
  {
    if (this.mService != null) {
      try
      {
        int i = this.mService.setStorageEncryption(paramComponentName, paramBoolean, UserHandle.myUserId());
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.w(TAG, "Failed talking with device policy service", localRemoteException);
      }
    }
    return 0;
  }
  
  public void wipeData(int paramInt)
  {
    if (this.mService != null) {}
    try
    {
      this.mService.wipeData(paramInt, UserHandle.myUserId());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w(TAG, "Failed talking with device policy service", localRemoteException);
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\admin\DevicePolicyManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
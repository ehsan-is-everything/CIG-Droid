package android.app.admin;

import android.content.ComponentName;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteCallback;
import android.os.RemoteException;
import java.util.ArrayList;
import java.util.List;

public abstract interface IDevicePolicyManager
  extends IInterface
{
  public abstract List<ComponentName> getActiveAdmins(int paramInt)
    throws RemoteException;
  
  public abstract boolean getCameraDisabled(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract int getCurrentFailedPasswordAttempts(int paramInt)
    throws RemoteException;
  
  public abstract ComponentName getGlobalProxyAdmin(int paramInt)
    throws RemoteException;
  
  public abstract int getKeyguardDisabledFeatures(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract int getMaximumFailedPasswordsForWipe(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract long getMaximumTimeToLock(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract long getPasswordExpiration(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract long getPasswordExpirationTimeout(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract int getPasswordHistoryLength(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract int getPasswordMinimumLength(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract int getPasswordMinimumLetters(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract int getPasswordMinimumLowerCase(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract int getPasswordMinimumNonLetter(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract int getPasswordMinimumNumeric(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract int getPasswordMinimumSymbols(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract int getPasswordMinimumUpperCase(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract int getPasswordQuality(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract void getRemoveWarning(ComponentName paramComponentName, RemoteCallback paramRemoteCallback, int paramInt)
    throws RemoteException;
  
  public abstract boolean getStorageEncryption(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract int getStorageEncryptionStatus(int paramInt)
    throws RemoteException;
  
  public abstract boolean hasGrantedPolicy(ComponentName paramComponentName, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract boolean isActivePasswordSufficient(int paramInt)
    throws RemoteException;
  
  public abstract boolean isAdminActive(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract void lockNow()
    throws RemoteException;
  
  public abstract boolean packageHasActiveAdmins(String paramString, int paramInt)
    throws RemoteException;
  
  public abstract void removeActiveAdmin(ComponentName paramComponentName, int paramInt)
    throws RemoteException;
  
  public abstract void reportFailedPasswordAttempt(int paramInt)
    throws RemoteException;
  
  public abstract void reportSuccessfulPasswordAttempt(int paramInt)
    throws RemoteException;
  
  public abstract boolean resetPassword(String paramString, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract void setActiveAdmin(ComponentName paramComponentName, boolean paramBoolean, int paramInt)
    throws RemoteException;
  
  public abstract void setActivePasswordState(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
    throws RemoteException;
  
  public abstract void setCameraDisabled(ComponentName paramComponentName, boolean paramBoolean, int paramInt)
    throws RemoteException;
  
  public abstract ComponentName setGlobalProxy(ComponentName paramComponentName, String paramString1, String paramString2, int paramInt)
    throws RemoteException;
  
  public abstract void setKeyguardDisabledFeatures(ComponentName paramComponentName, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract void setMaximumFailedPasswordsForWipe(ComponentName paramComponentName, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract void setMaximumTimeToLock(ComponentName paramComponentName, long paramLong, int paramInt)
    throws RemoteException;
  
  public abstract void setPasswordExpirationTimeout(ComponentName paramComponentName, long paramLong, int paramInt)
    throws RemoteException;
  
  public abstract void setPasswordHistoryLength(ComponentName paramComponentName, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract void setPasswordMinimumLength(ComponentName paramComponentName, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract void setPasswordMinimumLetters(ComponentName paramComponentName, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract void setPasswordMinimumLowerCase(ComponentName paramComponentName, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract void setPasswordMinimumNonLetter(ComponentName paramComponentName, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract void setPasswordMinimumNumeric(ComponentName paramComponentName, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract void setPasswordMinimumSymbols(ComponentName paramComponentName, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract void setPasswordMinimumUpperCase(ComponentName paramComponentName, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract void setPasswordQuality(ComponentName paramComponentName, int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract int setStorageEncryption(ComponentName paramComponentName, boolean paramBoolean, int paramInt)
    throws RemoteException;
  
  public abstract void wipeData(int paramInt1, int paramInt2)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IDevicePolicyManager
  {
    private static final String DESCRIPTOR = "android.app.admin.IDevicePolicyManager";
    static final int TRANSACTION_getActiveAdmins = 42;
    static final int TRANSACTION_getCameraDisabled = 37;
    static final int TRANSACTION_getCurrentFailedPasswordAttempts = 23;
    static final int TRANSACTION_getGlobalProxyAdmin = 32;
    static final int TRANSACTION_getKeyguardDisabledFeatures = 39;
    static final int TRANSACTION_getMaximumFailedPasswordsForWipe = 25;
    static final int TRANSACTION_getMaximumTimeToLock = 28;
    static final int TRANSACTION_getPasswordExpiration = 21;
    static final int TRANSACTION_getPasswordExpirationTimeout = 20;
    static final int TRANSACTION_getPasswordHistoryLength = 18;
    static final int TRANSACTION_getPasswordMinimumLength = 4;
    static final int TRANSACTION_getPasswordMinimumLetters = 10;
    static final int TRANSACTION_getPasswordMinimumLowerCase = 8;
    static final int TRANSACTION_getPasswordMinimumNonLetter = 16;
    static final int TRANSACTION_getPasswordMinimumNumeric = 12;
    static final int TRANSACTION_getPasswordMinimumSymbols = 14;
    static final int TRANSACTION_getPasswordMinimumUpperCase = 6;
    static final int TRANSACTION_getPasswordQuality = 2;
    static final int TRANSACTION_getRemoveWarning = 44;
    static final int TRANSACTION_getStorageEncryption = 34;
    static final int TRANSACTION_getStorageEncryptionStatus = 35;
    static final int TRANSACTION_hasGrantedPolicy = 46;
    static final int TRANSACTION_isActivePasswordSufficient = 22;
    static final int TRANSACTION_isAdminActive = 41;
    static final int TRANSACTION_lockNow = 29;
    static final int TRANSACTION_packageHasActiveAdmins = 43;
    static final int TRANSACTION_removeActiveAdmin = 45;
    static final int TRANSACTION_reportFailedPasswordAttempt = 48;
    static final int TRANSACTION_reportSuccessfulPasswordAttempt = 49;
    static final int TRANSACTION_resetPassword = 26;
    static final int TRANSACTION_setActiveAdmin = 40;
    static final int TRANSACTION_setActivePasswordState = 47;
    static final int TRANSACTION_setCameraDisabled = 36;
    static final int TRANSACTION_setGlobalProxy = 31;
    static final int TRANSACTION_setKeyguardDisabledFeatures = 38;
    static final int TRANSACTION_setMaximumFailedPasswordsForWipe = 24;
    static final int TRANSACTION_setMaximumTimeToLock = 27;
    static final int TRANSACTION_setPasswordExpirationTimeout = 19;
    static final int TRANSACTION_setPasswordHistoryLength = 17;
    static final int TRANSACTION_setPasswordMinimumLength = 3;
    static final int TRANSACTION_setPasswordMinimumLetters = 9;
    static final int TRANSACTION_setPasswordMinimumLowerCase = 7;
    static final int TRANSACTION_setPasswordMinimumNonLetter = 15;
    static final int TRANSACTION_setPasswordMinimumNumeric = 11;
    static final int TRANSACTION_setPasswordMinimumSymbols = 13;
    static final int TRANSACTION_setPasswordMinimumUpperCase = 5;
    static final int TRANSACTION_setPasswordQuality = 1;
    static final int TRANSACTION_setStorageEncryption = 33;
    static final int TRANSACTION_wipeData = 30;
    
    public Stub()
    {
      attachInterface(this, "android.app.admin.IDevicePolicyManager");
    }
    
    public static IDevicePolicyManager asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.app.admin.IDevicePolicyManager");
      if ((localIInterface != null) && ((localIInterface instanceof IDevicePolicyManager))) {
        return (IDevicePolicyManager)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.app.admin.IDevicePolicyManager");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName39 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName39 = null)
        {
          setPasswordQuality(localComponentName39, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 2: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName38 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName38 = null)
        {
          int i16 = getPasswordQuality(localComponentName38, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i16);
          return true;
        }
      case 3: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName37 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName37 = null)
        {
          setPasswordMinimumLength(localComponentName37, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 4: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName36 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName36 = null)
        {
          int i15 = getPasswordMinimumLength(localComponentName36, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i15);
          return true;
        }
      case 5: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName35 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName35 = null)
        {
          setPasswordMinimumUpperCase(localComponentName35, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 6: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName34 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName34 = null)
        {
          int i14 = getPasswordMinimumUpperCase(localComponentName34, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i14);
          return true;
        }
      case 7: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName33 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName33 = null)
        {
          setPasswordMinimumLowerCase(localComponentName33, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 8: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName32 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName32 = null)
        {
          int i13 = getPasswordMinimumLowerCase(localComponentName32, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i13);
          return true;
        }
      case 9: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName31 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName31 = null)
        {
          setPasswordMinimumLetters(localComponentName31, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 10: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName30 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName30 = null)
        {
          int i12 = getPasswordMinimumLetters(localComponentName30, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i12);
          return true;
        }
      case 11: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName29 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName29 = null)
        {
          setPasswordMinimumNumeric(localComponentName29, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 12: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName28 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName28 = null)
        {
          int i11 = getPasswordMinimumNumeric(localComponentName28, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i11);
          return true;
        }
      case 13: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName27 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName27 = null)
        {
          setPasswordMinimumSymbols(localComponentName27, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 14: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName26 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName26 = null)
        {
          int i10 = getPasswordMinimumSymbols(localComponentName26, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i10);
          return true;
        }
      case 15: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName25 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName25 = null)
        {
          setPasswordMinimumNonLetter(localComponentName25, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 16: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName24 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName24 = null)
        {
          int i9 = getPasswordMinimumNonLetter(localComponentName24, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i9);
          return true;
        }
      case 17: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName23 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName23 = null)
        {
          setPasswordHistoryLength(localComponentName23, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 18: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName22 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName22 = null)
        {
          int i8 = getPasswordHistoryLength(localComponentName22, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i8);
          return true;
        }
      case 19: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName21 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName21 = null)
        {
          setPasswordExpirationTimeout(localComponentName21, paramParcel1.readLong(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 20: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName20 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName20 = null)
        {
          long l3 = getPasswordExpirationTimeout(localComponentName20, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeLong(l3);
          return true;
        }
      case 21: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName19 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName19 = null)
        {
          long l2 = getPasswordExpiration(localComponentName19, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeLong(l2);
          return true;
        }
      case 22: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        boolean bool10 = isActivePasswordSufficient(paramParcel1.readInt());
        paramParcel2.writeNoException();
        if (bool10) {}
        for (int i7 = 1;; i7 = 0)
        {
          paramParcel2.writeInt(i7);
          return true;
        }
      case 23: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        int i6 = getCurrentFailedPasswordAttempts(paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i6);
        return true;
      case 24: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName18 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName18 = null)
        {
          setMaximumFailedPasswordsForWipe(localComponentName18, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 25: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName17 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName17 = null)
        {
          int i5 = getMaximumFailedPasswordsForWipe(localComponentName17, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i5);
          return true;
        }
      case 26: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        boolean bool9 = resetPassword(paramParcel1.readString(), paramParcel1.readInt(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        if (bool9) {}
        for (int i4 = 1;; i4 = 0)
        {
          paramParcel2.writeInt(i4);
          return true;
        }
      case 27: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName16 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName16 = null)
        {
          setMaximumTimeToLock(localComponentName16, paramParcel1.readLong(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 28: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName15 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName15 = null)
        {
          long l1 = getMaximumTimeToLock(localComponentName15, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeLong(l1);
          return true;
        }
      case 29: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        lockNow();
        paramParcel2.writeNoException();
        return true;
      case 30: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        wipeData(paramParcel1.readInt(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 31: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        ComponentName localComponentName13;
        if (paramParcel1.readInt() != 0)
        {
          localComponentName13 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);
          ComponentName localComponentName14 = setGlobalProxy(localComponentName13, paramParcel1.readString(), paramParcel1.readString(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          if (localComponentName14 == null) {
            break label2043;
          }
          paramParcel2.writeInt(1);
          localComponentName14.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          localComponentName13 = null;
          break;
          paramParcel2.writeInt(0);
        }
      case 32: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        ComponentName localComponentName12 = getGlobalProxyAdmin(paramParcel1.readInt());
        paramParcel2.writeNoException();
        if (localComponentName12 != null)
        {
          paramParcel2.writeInt(1);
          localComponentName12.writeToParcel(paramParcel2, 1);
        }
        for (;;)
        {
          return true;
          paramParcel2.writeInt(0);
        }
      case 33: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        ComponentName localComponentName11;
        if (paramParcel1.readInt() != 0)
        {
          localComponentName11 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label2167;
          }
        }
        for (boolean bool8 = true;; bool8 = false)
        {
          int i3 = setStorageEncryption(localComponentName11, bool8, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i3);
          return true;
          localComponentName11 = null;
          break;
        }
      case 34: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        ComponentName localComponentName10;
        if (paramParcel1.readInt() != 0)
        {
          localComponentName10 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);
          boolean bool7 = getStorageEncryption(localComponentName10, paramParcel1.readInt());
          paramParcel2.writeNoException();
          if (!bool7) {
            break label2238;
          }
        }
        for (int i2 = 1;; i2 = 0)
        {
          paramParcel2.writeInt(i2);
          return true;
          localComponentName10 = null;
          break;
        }
      case 35: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        int i1 = getStorageEncryptionStatus(paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i1);
        return true;
      case 36: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        ComponentName localComponentName9;
        if (paramParcel1.readInt() != 0)
        {
          localComponentName9 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label2333;
          }
        }
        for (boolean bool6 = true;; bool6 = false)
        {
          setCameraDisabled(localComponentName9, bool6, paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
          localComponentName9 = null;
          break;
        }
      case 37: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        ComponentName localComponentName8;
        if (paramParcel1.readInt() != 0)
        {
          localComponentName8 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);
          boolean bool5 = getCameraDisabled(localComponentName8, paramParcel1.readInt());
          paramParcel2.writeNoException();
          if (!bool5) {
            break label2404;
          }
        }
        for (int n = 1;; n = 0)
        {
          paramParcel2.writeInt(n);
          return true;
          localComponentName8 = null;
          break;
        }
      case 38: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName7 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName7 = null)
        {
          setKeyguardDisabledFeatures(localComponentName7, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 39: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName6 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName6 = null)
        {
          int m = getKeyguardDisabledFeatures(localComponentName6, paramParcel1.readInt());
          paramParcel2.writeNoException();
          paramParcel2.writeInt(m);
          return true;
        }
      case 40: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        ComponentName localComponentName5;
        if (paramParcel1.readInt() != 0)
        {
          localComponentName5 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label2581;
          }
        }
        for (boolean bool4 = true;; bool4 = false)
        {
          setActiveAdmin(localComponentName5, bool4, paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
          localComponentName5 = null;
          break;
        }
      case 41: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        ComponentName localComponentName4;
        if (paramParcel1.readInt() != 0)
        {
          localComponentName4 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);
          boolean bool3 = isAdminActive(localComponentName4, paramParcel1.readInt());
          paramParcel2.writeNoException();
          if (!bool3) {
            break label2652;
          }
        }
        for (int k = 1;; k = 0)
        {
          paramParcel2.writeInt(k);
          return true;
          localComponentName4 = null;
          break;
        }
      case 42: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        List localList = getActiveAdmins(paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList);
        return true;
      case 43: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        boolean bool2 = packageHasActiveAdmins(paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        if (bool2) {}
        for (int j = 1;; j = 0)
        {
          paramParcel2.writeInt(j);
          return true;
        }
      case 44: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        ComponentName localComponentName3;
        if (paramParcel1.readInt() != 0)
        {
          localComponentName3 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label2804;
          }
        }
        for (RemoteCallback localRemoteCallback = (RemoteCallback)RemoteCallback.CREATOR.createFromParcel(paramParcel1);; localRemoteCallback = null)
        {
          getRemoveWarning(localComponentName3, localRemoteCallback, paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
          localComponentName3 = null;
          break;
        }
      case 45: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        if (paramParcel1.readInt() != 0) {}
        for (ComponentName localComponentName2 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);; localComponentName2 = null)
        {
          removeActiveAdmin(localComponentName2, paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 46: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        ComponentName localComponentName1;
        if (paramParcel1.readInt() != 0)
        {
          localComponentName1 = (ComponentName)ComponentName.CREATOR.createFromParcel(paramParcel1);
          boolean bool1 = hasGrantedPolicy(localComponentName1, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          if (!bool1) {
            break label2928;
          }
        }
        for (int i = 1;; i = 0)
        {
          paramParcel2.writeInt(i);
          return true;
          localComponentName1 = null;
          break;
        }
      case 47: 
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        setActivePasswordState(paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 48: 
        label2043:
        label2167:
        label2238:
        label2333:
        label2404:
        label2581:
        label2652:
        label2804:
        label2928:
        paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
        reportFailedPasswordAttempt(paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      }
      paramParcel1.enforceInterface("android.app.admin.IDevicePolicyManager");
      reportSuccessfulPasswordAttempt(paramParcel1.readInt());
      paramParcel2.writeNoException();
      return true;
    }
    
    private static class Proxy
      implements IDevicePolicyManager
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public List<ComponentName> getActiveAdmins(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(42, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(ComponentName.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean getCameraDisabled(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
            if (paramComponentName != null)
            {
              localParcel1.writeInt(1);
              paramComponentName.writeToParcel(localParcel1, 0);
              localParcel1.writeInt(paramInt);
              this.mRemote.transact(37, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public int getCurrentFailedPasswordAttempts(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(23, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public ComponentName getGlobalProxyAdmin(int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_2
        //   15: iload_1
        //   16: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   19: aload_0
        //   20: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   23: bipush 32
        //   25: aload_2
        //   26: aload_3
        //   27: iconst_0
        //   28: invokeinterface 43 5 0
        //   33: pop
        //   34: aload_3
        //   35: invokevirtual 46	android/os/Parcel:readException	()V
        //   38: aload_3
        //   39: invokevirtual 69	android/os/Parcel:readInt	()I
        //   42: ifeq +28 -> 70
        //   45: getstatic 52	android/content/ComponentName:CREATOR	Landroid/os/Parcelable$Creator;
        //   48: aload_3
        //   49: invokeinterface 79 2 0
        //   54: checkcast 48	android/content/ComponentName
        //   57: astore 6
        //   59: aload_3
        //   60: invokevirtual 59	android/os/Parcel:recycle	()V
        //   63: aload_2
        //   64: invokevirtual 59	android/os/Parcel:recycle	()V
        //   67: aload 6
        //   69: areturn
        //   70: aconst_null
        //   71: astore 6
        //   73: goto -14 -> 59
        //   76: astore 4
        //   78: aload_3
        //   79: invokevirtual 59	android/os/Parcel:recycle	()V
        //   82: aload_2
        //   83: invokevirtual 59	android/os/Parcel:recycle	()V
        //   86: aload 4
        //   88: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	89	0	this	Proxy
        //   0	89	1	paramInt	int
        //   3	80	2	localParcel1	Parcel
        //   7	72	3	localParcel2	Parcel
        //   76	11	4	localObject	Object
        //   57	15	6	localComponentName	ComponentName
        // Exception table:
        //   from	to	target	type
        //   8	59	76	finally
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.app.admin.IDevicePolicyManager";
      }
      
      /* Error */
      public int getKeyguardDisabledFeatures(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 29
        //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +59 -> 75
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 39
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 43 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 46	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 69	android/os/Parcel:readInt	()I
        //   61: istore 7
        //   63: aload 4
        //   65: invokevirtual 59	android/os/Parcel:recycle	()V
        //   68: aload_3
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: iload 7
        //   74: ireturn
        //   75: aload_3
        //   76: iconst_0
        //   77: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   80: goto -50 -> 30
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 59	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 59	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramComponentName	ComponentName
        //   0	97	2	paramInt	int
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   61	12	7	i	int
        // Exception table:
        //   from	to	target	type
        //   9	15	83	finally
        //   19	30	83	finally
        //   30	63	83	finally
        //   75	80	83	finally
      }
      
      /* Error */
      public int getMaximumFailedPasswordsForWipe(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 29
        //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +59 -> 75
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 25
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 43 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 46	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 69	android/os/Parcel:readInt	()I
        //   61: istore 7
        //   63: aload 4
        //   65: invokevirtual 59	android/os/Parcel:recycle	()V
        //   68: aload_3
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: iload 7
        //   74: ireturn
        //   75: aload_3
        //   76: iconst_0
        //   77: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   80: goto -50 -> 30
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 59	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 59	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramComponentName	ComponentName
        //   0	97	2	paramInt	int
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   61	12	7	i	int
        // Exception table:
        //   from	to	target	type
        //   9	15	83	finally
        //   19	30	83	finally
        //   30	63	83	finally
        //   75	80	83	finally
      }
      
      /* Error */
      public long getMaximumTimeToLock(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 29
        //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +59 -> 75
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 28
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 43 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 46	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 90	android/os/Parcel:readLong	()J
        //   61: lstore 7
        //   63: aload 4
        //   65: invokevirtual 59	android/os/Parcel:recycle	()V
        //   68: aload_3
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: lload 7
        //   74: lreturn
        //   75: aload_3
        //   76: iconst_0
        //   77: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   80: goto -50 -> 30
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 59	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 59	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramComponentName	ComponentName
        //   0	97	2	paramInt	int
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   61	12	7	l	long
        // Exception table:
        //   from	to	target	type
        //   9	15	83	finally
        //   19	30	83	finally
        //   30	63	83	finally
        //   75	80	83	finally
      }
      
      /* Error */
      public long getPasswordExpiration(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 29
        //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +59 -> 75
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 21
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 43 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 46	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 90	android/os/Parcel:readLong	()J
        //   61: lstore 7
        //   63: aload 4
        //   65: invokevirtual 59	android/os/Parcel:recycle	()V
        //   68: aload_3
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: lload 7
        //   74: lreturn
        //   75: aload_3
        //   76: iconst_0
        //   77: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   80: goto -50 -> 30
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 59	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 59	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramComponentName	ComponentName
        //   0	97	2	paramInt	int
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   61	12	7	l	long
        // Exception table:
        //   from	to	target	type
        //   9	15	83	finally
        //   19	30	83	finally
        //   30	63	83	finally
        //   75	80	83	finally
      }
      
      /* Error */
      public long getPasswordExpirationTimeout(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 29
        //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +59 -> 75
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 20
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 43 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 46	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 90	android/os/Parcel:readLong	()J
        //   61: lstore 7
        //   63: aload 4
        //   65: invokevirtual 59	android/os/Parcel:recycle	()V
        //   68: aload_3
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: lload 7
        //   74: lreturn
        //   75: aload_3
        //   76: iconst_0
        //   77: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   80: goto -50 -> 30
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 59	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 59	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramComponentName	ComponentName
        //   0	97	2	paramInt	int
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   61	12	7	l	long
        // Exception table:
        //   from	to	target	type
        //   9	15	83	finally
        //   19	30	83	finally
        //   30	63	83	finally
        //   75	80	83	finally
      }
      
      /* Error */
      public int getPasswordHistoryLength(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 29
        //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +59 -> 75
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 18
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 43 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 46	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 69	android/os/Parcel:readInt	()I
        //   61: istore 7
        //   63: aload 4
        //   65: invokevirtual 59	android/os/Parcel:recycle	()V
        //   68: aload_3
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: iload 7
        //   74: ireturn
        //   75: aload_3
        //   76: iconst_0
        //   77: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   80: goto -50 -> 30
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 59	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 59	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramComponentName	ComponentName
        //   0	97	2	paramInt	int
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   61	12	7	i	int
        // Exception table:
        //   from	to	target	type
        //   9	15	83	finally
        //   19	30	83	finally
        //   30	63	83	finally
        //   75	80	83	finally
      }
      
      /* Error */
      public int getPasswordMinimumLength(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 29
        //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +58 -> 74
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: iconst_4
        //   40: aload_3
        //   41: aload 4
        //   43: iconst_0
        //   44: invokeinterface 43 5 0
        //   49: pop
        //   50: aload 4
        //   52: invokevirtual 46	android/os/Parcel:readException	()V
        //   55: aload 4
        //   57: invokevirtual 69	android/os/Parcel:readInt	()I
        //   60: istore 7
        //   62: aload 4
        //   64: invokevirtual 59	android/os/Parcel:recycle	()V
        //   67: aload_3
        //   68: invokevirtual 59	android/os/Parcel:recycle	()V
        //   71: iload 7
        //   73: ireturn
        //   74: aload_3
        //   75: iconst_0
        //   76: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   79: goto -49 -> 30
        //   82: astore 5
        //   84: aload 4
        //   86: invokevirtual 59	android/os/Parcel:recycle	()V
        //   89: aload_3
        //   90: invokevirtual 59	android/os/Parcel:recycle	()V
        //   93: aload 5
        //   95: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	96	0	this	Proxy
        //   0	96	1	paramComponentName	ComponentName
        //   0	96	2	paramInt	int
        //   3	87	3	localParcel1	Parcel
        //   7	78	4	localParcel2	Parcel
        //   82	12	5	localObject	Object
        //   60	12	7	i	int
        // Exception table:
        //   from	to	target	type
        //   9	15	82	finally
        //   19	30	82	finally
        //   30	62	82	finally
        //   74	79	82	finally
      }
      
      /* Error */
      public int getPasswordMinimumLetters(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 29
        //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +59 -> 75
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 10
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 43 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 46	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 69	android/os/Parcel:readInt	()I
        //   61: istore 7
        //   63: aload 4
        //   65: invokevirtual 59	android/os/Parcel:recycle	()V
        //   68: aload_3
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: iload 7
        //   74: ireturn
        //   75: aload_3
        //   76: iconst_0
        //   77: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   80: goto -50 -> 30
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 59	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 59	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramComponentName	ComponentName
        //   0	97	2	paramInt	int
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   61	12	7	i	int
        // Exception table:
        //   from	to	target	type
        //   9	15	83	finally
        //   19	30	83	finally
        //   30	63	83	finally
        //   75	80	83	finally
      }
      
      /* Error */
      public int getPasswordMinimumLowerCase(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 29
        //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +59 -> 75
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 8
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 43 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 46	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 69	android/os/Parcel:readInt	()I
        //   61: istore 7
        //   63: aload 4
        //   65: invokevirtual 59	android/os/Parcel:recycle	()V
        //   68: aload_3
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: iload 7
        //   74: ireturn
        //   75: aload_3
        //   76: iconst_0
        //   77: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   80: goto -50 -> 30
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 59	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 59	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramComponentName	ComponentName
        //   0	97	2	paramInt	int
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   61	12	7	i	int
        // Exception table:
        //   from	to	target	type
        //   9	15	83	finally
        //   19	30	83	finally
        //   30	63	83	finally
        //   75	80	83	finally
      }
      
      /* Error */
      public int getPasswordMinimumNonLetter(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 29
        //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +59 -> 75
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 16
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 43 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 46	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 69	android/os/Parcel:readInt	()I
        //   61: istore 7
        //   63: aload 4
        //   65: invokevirtual 59	android/os/Parcel:recycle	()V
        //   68: aload_3
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: iload 7
        //   74: ireturn
        //   75: aload_3
        //   76: iconst_0
        //   77: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   80: goto -50 -> 30
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 59	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 59	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramComponentName	ComponentName
        //   0	97	2	paramInt	int
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   61	12	7	i	int
        // Exception table:
        //   from	to	target	type
        //   9	15	83	finally
        //   19	30	83	finally
        //   30	63	83	finally
        //   75	80	83	finally
      }
      
      /* Error */
      public int getPasswordMinimumNumeric(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 29
        //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +59 -> 75
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 12
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 43 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 46	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 69	android/os/Parcel:readInt	()I
        //   61: istore 7
        //   63: aload 4
        //   65: invokevirtual 59	android/os/Parcel:recycle	()V
        //   68: aload_3
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: iload 7
        //   74: ireturn
        //   75: aload_3
        //   76: iconst_0
        //   77: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   80: goto -50 -> 30
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 59	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 59	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramComponentName	ComponentName
        //   0	97	2	paramInt	int
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   61	12	7	i	int
        // Exception table:
        //   from	to	target	type
        //   9	15	83	finally
        //   19	30	83	finally
        //   30	63	83	finally
        //   75	80	83	finally
      }
      
      /* Error */
      public int getPasswordMinimumSymbols(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 29
        //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +59 -> 75
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 14
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 43 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 46	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 69	android/os/Parcel:readInt	()I
        //   61: istore 7
        //   63: aload 4
        //   65: invokevirtual 59	android/os/Parcel:recycle	()V
        //   68: aload_3
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: iload 7
        //   74: ireturn
        //   75: aload_3
        //   76: iconst_0
        //   77: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   80: goto -50 -> 30
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 59	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 59	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramComponentName	ComponentName
        //   0	97	2	paramInt	int
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   61	12	7	i	int
        // Exception table:
        //   from	to	target	type
        //   9	15	83	finally
        //   19	30	83	finally
        //   30	63	83	finally
        //   75	80	83	finally
      }
      
      /* Error */
      public int getPasswordMinimumUpperCase(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 29
        //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +59 -> 75
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 6
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 43 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 46	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 69	android/os/Parcel:readInt	()I
        //   61: istore 7
        //   63: aload 4
        //   65: invokevirtual 59	android/os/Parcel:recycle	()V
        //   68: aload_3
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: iload 7
        //   74: ireturn
        //   75: aload_3
        //   76: iconst_0
        //   77: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   80: goto -50 -> 30
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 59	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 59	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramComponentName	ComponentName
        //   0	97	2	paramInt	int
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   61	12	7	i	int
        // Exception table:
        //   from	to	target	type
        //   9	15	83	finally
        //   19	30	83	finally
        //   30	63	83	finally
        //   75	80	83	finally
      }
      
      /* Error */
      public int getPasswordQuality(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 29
        //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +58 -> 74
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: iconst_2
        //   40: aload_3
        //   41: aload 4
        //   43: iconst_0
        //   44: invokeinterface 43 5 0
        //   49: pop
        //   50: aload 4
        //   52: invokevirtual 46	android/os/Parcel:readException	()V
        //   55: aload 4
        //   57: invokevirtual 69	android/os/Parcel:readInt	()I
        //   60: istore 7
        //   62: aload 4
        //   64: invokevirtual 59	android/os/Parcel:recycle	()V
        //   67: aload_3
        //   68: invokevirtual 59	android/os/Parcel:recycle	()V
        //   71: iload 7
        //   73: ireturn
        //   74: aload_3
        //   75: iconst_0
        //   76: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   79: goto -49 -> 30
        //   82: astore 5
        //   84: aload 4
        //   86: invokevirtual 59	android/os/Parcel:recycle	()V
        //   89: aload_3
        //   90: invokevirtual 59	android/os/Parcel:recycle	()V
        //   93: aload 5
        //   95: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	96	0	this	Proxy
        //   0	96	1	paramComponentName	ComponentName
        //   0	96	2	paramInt	int
        //   3	87	3	localParcel1	Parcel
        //   7	78	4	localParcel2	Parcel
        //   82	12	5	localObject	Object
        //   60	12	7	i	int
        // Exception table:
        //   from	to	target	type
        //   9	15	82	finally
        //   19	30	82	finally
        //   30	62	82	finally
        //   74	79	82	finally
      }
      
      public void getRemoveWarning(ComponentName paramComponentName, RemoteCallback paramRemoteCallback, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
            if (paramComponentName != null)
            {
              localParcel1.writeInt(1);
              paramComponentName.writeToParcel(localParcel1, 0);
              if (paramRemoteCallback != null)
              {
                localParcel1.writeInt(1);
                paramRemoteCallback.writeToParcel(localParcel1, 0);
                localParcel1.writeInt(paramInt);
                this.mRemote.transact(44, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            localParcel1.writeInt(0);
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean getStorageEncryption(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
            if (paramComponentName != null)
            {
              localParcel1.writeInt(1);
              paramComponentName.writeToParcel(localParcel1, 0);
              localParcel1.writeInt(paramInt);
              this.mRemote.transact(34, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public int getStorageEncryptionStatus(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(35, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean hasGrantedPolicy(ComponentName paramComponentName, int paramInt1, int paramInt2)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
            if (paramComponentName != null)
            {
              localParcel1.writeInt(1);
              paramComponentName.writeToParcel(localParcel1, 0);
              localParcel1.writeInt(paramInt1);
              localParcel1.writeInt(paramInt2);
              this.mRemote.transact(46, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean isActivePasswordSufficient(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(22, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean isAdminActive(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
            if (paramComponentName != null)
            {
              localParcel1.writeInt(1);
              paramComponentName.writeToParcel(localParcel1, 0);
              localParcel1.writeInt(paramInt);
              this.mRemote.transact(41, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public void lockNow()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
          this.mRemote.transact(29, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean packageHasActiveAdmins(String paramString, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(43, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public void removeActiveAdmin(ComponentName paramComponentName, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 29
        //   12: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +50 -> 66
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 45
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 43 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 46	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 59	android/os/Parcel:recycle	()V
        //   61: aload_3
        //   62: invokevirtual 59	android/os/Parcel:recycle	()V
        //   65: return
        //   66: aload_3
        //   67: iconst_0
        //   68: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   71: goto -41 -> 30
        //   74: astore 5
        //   76: aload 4
        //   78: invokevirtual 59	android/os/Parcel:recycle	()V
        //   81: aload_3
        //   82: invokevirtual 59	android/os/Parcel:recycle	()V
        //   85: aload 5
        //   87: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	88	0	this	Proxy
        //   0	88	1	paramComponentName	ComponentName
        //   0	88	2	paramInt	int
        //   3	79	3	localParcel1	Parcel
        //   7	70	4	localParcel2	Parcel
        //   74	12	5	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   9	15	74	finally
        //   19	30	74	finally
        //   30	56	74	finally
        //   66	71	74	finally
      }
      
      public void reportFailedPasswordAttempt(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(48, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void reportSuccessfulPasswordAttempt(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(49, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean resetPassword(String paramString, int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          this.mRemote.transact(26, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void setActiveAdmin(ComponentName paramComponentName, boolean paramBoolean, int paramInt)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
            if (paramComponentName != null)
            {
              localParcel1.writeInt(1);
              paramComponentName.writeToParcel(localParcel1, 0);
              break label116;
              localParcel1.writeInt(i);
              localParcel1.writeInt(paramInt);
              this.mRemote.transact(40, localParcel1, localParcel2, 0);
              localParcel2.readException();
            }
            else
            {
              localParcel1.writeInt(0);
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          label116:
          do
          {
            i = 0;
            break;
          } while (!paramBoolean);
        }
      }
      
      public void setActivePasswordState(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          localParcel1.writeInt(paramInt3);
          localParcel1.writeInt(paramInt4);
          localParcel1.writeInt(paramInt5);
          localParcel1.writeInt(paramInt6);
          localParcel1.writeInt(paramInt7);
          localParcel1.writeInt(paramInt8);
          localParcel1.writeInt(paramInt9);
          this.mRemote.transact(47, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void setCameraDisabled(ComponentName paramComponentName, boolean paramBoolean, int paramInt)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
            if (paramComponentName != null)
            {
              localParcel1.writeInt(1);
              paramComponentName.writeToParcel(localParcel1, 0);
              break label116;
              localParcel1.writeInt(i);
              localParcel1.writeInt(paramInt);
              this.mRemote.transact(36, localParcel1, localParcel2, 0);
              localParcel2.readException();
            }
            else
            {
              localParcel1.writeInt(0);
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          label116:
          do
          {
            i = 0;
            break;
          } while (!paramBoolean);
        }
      }
      
      public ComponentName setGlobalProxy(ComponentName paramComponentName, String paramString1, String paramString2, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
            if (paramComponentName != null)
            {
              localParcel1.writeInt(1);
              paramComponentName.writeToParcel(localParcel1, 0);
              localParcel1.writeString(paramString1);
              localParcel1.writeString(paramString2);
              localParcel1.writeInt(paramInt);
              this.mRemote.transact(31, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localComponentName = (ComponentName)ComponentName.CREATOR.createFromParcel(localParcel2);
                return localComponentName;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            ComponentName localComponentName = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      /* Error */
      public void setKeyguardDisabledFeatures(ComponentName paramComponentName, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +61 -> 79
        //   21: aload 4
        //   23: iconst_1
        //   24: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 4
        //   30: iconst_0
        //   31: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 4
        //   36: iload_2
        //   37: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   40: aload 4
        //   42: iload_3
        //   43: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   46: aload_0
        //   47: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   50: bipush 38
        //   52: aload 4
        //   54: aload 5
        //   56: iconst_0
        //   57: invokeinterface 43 5 0
        //   62: pop
        //   63: aload 5
        //   65: invokevirtual 46	android/os/Parcel:readException	()V
        //   68: aload 5
        //   70: invokevirtual 59	android/os/Parcel:recycle	()V
        //   73: aload 4
        //   75: invokevirtual 59	android/os/Parcel:recycle	()V
        //   78: return
        //   79: aload 4
        //   81: iconst_0
        //   82: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   85: goto -51 -> 34
        //   88: astore 6
        //   90: aload 5
        //   92: invokevirtual 59	android/os/Parcel:recycle	()V
        //   95: aload 4
        //   97: invokevirtual 59	android/os/Parcel:recycle	()V
        //   100: aload 6
        //   102: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	103	0	this	Proxy
        //   0	103	1	paramComponentName	ComponentName
        //   0	103	2	paramInt1	int
        //   0	103	3	paramInt2	int
        //   3	93	4	localParcel1	Parcel
        //   8	83	5	localParcel2	Parcel
        //   88	13	6	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	88	finally
        //   21	34	88	finally
        //   34	68	88	finally
        //   79	85	88	finally
      }
      
      /* Error */
      public void setMaximumFailedPasswordsForWipe(ComponentName paramComponentName, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +61 -> 79
        //   21: aload 4
        //   23: iconst_1
        //   24: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 4
        //   30: iconst_0
        //   31: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 4
        //   36: iload_2
        //   37: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   40: aload 4
        //   42: iload_3
        //   43: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   46: aload_0
        //   47: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   50: bipush 24
        //   52: aload 4
        //   54: aload 5
        //   56: iconst_0
        //   57: invokeinterface 43 5 0
        //   62: pop
        //   63: aload 5
        //   65: invokevirtual 46	android/os/Parcel:readException	()V
        //   68: aload 5
        //   70: invokevirtual 59	android/os/Parcel:recycle	()V
        //   73: aload 4
        //   75: invokevirtual 59	android/os/Parcel:recycle	()V
        //   78: return
        //   79: aload 4
        //   81: iconst_0
        //   82: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   85: goto -51 -> 34
        //   88: astore 6
        //   90: aload 5
        //   92: invokevirtual 59	android/os/Parcel:recycle	()V
        //   95: aload 4
        //   97: invokevirtual 59	android/os/Parcel:recycle	()V
        //   100: aload 6
        //   102: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	103	0	this	Proxy
        //   0	103	1	paramComponentName	ComponentName
        //   0	103	2	paramInt1	int
        //   0	103	3	paramInt2	int
        //   3	93	4	localParcel1	Parcel
        //   8	83	5	localParcel2	Parcel
        //   88	13	6	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	88	finally
        //   21	34	88	finally
        //   34	68	88	finally
        //   79	85	88	finally
      }
      
      /* Error */
      public void setMaximumTimeToLock(ComponentName paramComponentName, long paramLong, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 5
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 6
        //   10: aload 5
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +62 -> 80
        //   21: aload 5
        //   23: iconst_1
        //   24: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 5
        //   30: iconst_0
        //   31: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 5
        //   36: lload_2
        //   37: invokevirtual 141	android/os/Parcel:writeLong	(J)V
        //   40: aload 5
        //   42: iload 4
        //   44: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   47: aload_0
        //   48: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   51: bipush 27
        //   53: aload 5
        //   55: aload 6
        //   57: iconst_0
        //   58: invokeinterface 43 5 0
        //   63: pop
        //   64: aload 6
        //   66: invokevirtual 46	android/os/Parcel:readException	()V
        //   69: aload 6
        //   71: invokevirtual 59	android/os/Parcel:recycle	()V
        //   74: aload 5
        //   76: invokevirtual 59	android/os/Parcel:recycle	()V
        //   79: return
        //   80: aload 5
        //   82: iconst_0
        //   83: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   86: goto -52 -> 34
        //   89: astore 7
        //   91: aload 6
        //   93: invokevirtual 59	android/os/Parcel:recycle	()V
        //   96: aload 5
        //   98: invokevirtual 59	android/os/Parcel:recycle	()V
        //   101: aload 7
        //   103: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	104	0	this	Proxy
        //   0	104	1	paramComponentName	ComponentName
        //   0	104	2	paramLong	long
        //   0	104	4	paramInt	int
        //   3	94	5	localParcel1	Parcel
        //   8	84	6	localParcel2	Parcel
        //   89	13	7	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	89	finally
        //   21	34	89	finally
        //   34	69	89	finally
        //   80	86	89	finally
      }
      
      /* Error */
      public void setPasswordExpirationTimeout(ComponentName paramComponentName, long paramLong, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 5
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 6
        //   10: aload 5
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +62 -> 80
        //   21: aload 5
        //   23: iconst_1
        //   24: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 5
        //   30: iconst_0
        //   31: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 5
        //   36: lload_2
        //   37: invokevirtual 141	android/os/Parcel:writeLong	(J)V
        //   40: aload 5
        //   42: iload 4
        //   44: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   47: aload_0
        //   48: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   51: bipush 19
        //   53: aload 5
        //   55: aload 6
        //   57: iconst_0
        //   58: invokeinterface 43 5 0
        //   63: pop
        //   64: aload 6
        //   66: invokevirtual 46	android/os/Parcel:readException	()V
        //   69: aload 6
        //   71: invokevirtual 59	android/os/Parcel:recycle	()V
        //   74: aload 5
        //   76: invokevirtual 59	android/os/Parcel:recycle	()V
        //   79: return
        //   80: aload 5
        //   82: iconst_0
        //   83: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   86: goto -52 -> 34
        //   89: astore 7
        //   91: aload 6
        //   93: invokevirtual 59	android/os/Parcel:recycle	()V
        //   96: aload 5
        //   98: invokevirtual 59	android/os/Parcel:recycle	()V
        //   101: aload 7
        //   103: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	104	0	this	Proxy
        //   0	104	1	paramComponentName	ComponentName
        //   0	104	2	paramLong	long
        //   0	104	4	paramInt	int
        //   3	94	5	localParcel1	Parcel
        //   8	84	6	localParcel2	Parcel
        //   89	13	7	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	89	finally
        //   21	34	89	finally
        //   34	69	89	finally
        //   80	86	89	finally
      }
      
      /* Error */
      public void setPasswordHistoryLength(ComponentName paramComponentName, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +61 -> 79
        //   21: aload 4
        //   23: iconst_1
        //   24: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 4
        //   30: iconst_0
        //   31: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 4
        //   36: iload_2
        //   37: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   40: aload 4
        //   42: iload_3
        //   43: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   46: aload_0
        //   47: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   50: bipush 17
        //   52: aload 4
        //   54: aload 5
        //   56: iconst_0
        //   57: invokeinterface 43 5 0
        //   62: pop
        //   63: aload 5
        //   65: invokevirtual 46	android/os/Parcel:readException	()V
        //   68: aload 5
        //   70: invokevirtual 59	android/os/Parcel:recycle	()V
        //   73: aload 4
        //   75: invokevirtual 59	android/os/Parcel:recycle	()V
        //   78: return
        //   79: aload 4
        //   81: iconst_0
        //   82: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   85: goto -51 -> 34
        //   88: astore 6
        //   90: aload 5
        //   92: invokevirtual 59	android/os/Parcel:recycle	()V
        //   95: aload 4
        //   97: invokevirtual 59	android/os/Parcel:recycle	()V
        //   100: aload 6
        //   102: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	103	0	this	Proxy
        //   0	103	1	paramComponentName	ComponentName
        //   0	103	2	paramInt1	int
        //   0	103	3	paramInt2	int
        //   3	93	4	localParcel1	Parcel
        //   8	83	5	localParcel2	Parcel
        //   88	13	6	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	88	finally
        //   21	34	88	finally
        //   34	68	88	finally
        //   79	85	88	finally
      }
      
      /* Error */
      public void setPasswordMinimumLength(ComponentName paramComponentName, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +60 -> 78
        //   21: aload 4
        //   23: iconst_1
        //   24: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 4
        //   30: iconst_0
        //   31: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 4
        //   36: iload_2
        //   37: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   40: aload 4
        //   42: iload_3
        //   43: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   46: aload_0
        //   47: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   50: iconst_3
        //   51: aload 4
        //   53: aload 5
        //   55: iconst_0
        //   56: invokeinterface 43 5 0
        //   61: pop
        //   62: aload 5
        //   64: invokevirtual 46	android/os/Parcel:readException	()V
        //   67: aload 5
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: aload 4
        //   74: invokevirtual 59	android/os/Parcel:recycle	()V
        //   77: return
        //   78: aload 4
        //   80: iconst_0
        //   81: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   84: goto -50 -> 34
        //   87: astore 6
        //   89: aload 5
        //   91: invokevirtual 59	android/os/Parcel:recycle	()V
        //   94: aload 4
        //   96: invokevirtual 59	android/os/Parcel:recycle	()V
        //   99: aload 6
        //   101: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	102	0	this	Proxy
        //   0	102	1	paramComponentName	ComponentName
        //   0	102	2	paramInt1	int
        //   0	102	3	paramInt2	int
        //   3	92	4	localParcel1	Parcel
        //   8	82	5	localParcel2	Parcel
        //   87	13	6	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	87	finally
        //   21	34	87	finally
        //   34	67	87	finally
        //   78	84	87	finally
      }
      
      /* Error */
      public void setPasswordMinimumLetters(ComponentName paramComponentName, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +61 -> 79
        //   21: aload 4
        //   23: iconst_1
        //   24: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 4
        //   30: iconst_0
        //   31: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 4
        //   36: iload_2
        //   37: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   40: aload 4
        //   42: iload_3
        //   43: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   46: aload_0
        //   47: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   50: bipush 9
        //   52: aload 4
        //   54: aload 5
        //   56: iconst_0
        //   57: invokeinterface 43 5 0
        //   62: pop
        //   63: aload 5
        //   65: invokevirtual 46	android/os/Parcel:readException	()V
        //   68: aload 5
        //   70: invokevirtual 59	android/os/Parcel:recycle	()V
        //   73: aload 4
        //   75: invokevirtual 59	android/os/Parcel:recycle	()V
        //   78: return
        //   79: aload 4
        //   81: iconst_0
        //   82: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   85: goto -51 -> 34
        //   88: astore 6
        //   90: aload 5
        //   92: invokevirtual 59	android/os/Parcel:recycle	()V
        //   95: aload 4
        //   97: invokevirtual 59	android/os/Parcel:recycle	()V
        //   100: aload 6
        //   102: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	103	0	this	Proxy
        //   0	103	1	paramComponentName	ComponentName
        //   0	103	2	paramInt1	int
        //   0	103	3	paramInt2	int
        //   3	93	4	localParcel1	Parcel
        //   8	83	5	localParcel2	Parcel
        //   88	13	6	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	88	finally
        //   21	34	88	finally
        //   34	68	88	finally
        //   79	85	88	finally
      }
      
      /* Error */
      public void setPasswordMinimumLowerCase(ComponentName paramComponentName, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +61 -> 79
        //   21: aload 4
        //   23: iconst_1
        //   24: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 4
        //   30: iconst_0
        //   31: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 4
        //   36: iload_2
        //   37: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   40: aload 4
        //   42: iload_3
        //   43: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   46: aload_0
        //   47: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   50: bipush 7
        //   52: aload 4
        //   54: aload 5
        //   56: iconst_0
        //   57: invokeinterface 43 5 0
        //   62: pop
        //   63: aload 5
        //   65: invokevirtual 46	android/os/Parcel:readException	()V
        //   68: aload 5
        //   70: invokevirtual 59	android/os/Parcel:recycle	()V
        //   73: aload 4
        //   75: invokevirtual 59	android/os/Parcel:recycle	()V
        //   78: return
        //   79: aload 4
        //   81: iconst_0
        //   82: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   85: goto -51 -> 34
        //   88: astore 6
        //   90: aload 5
        //   92: invokevirtual 59	android/os/Parcel:recycle	()V
        //   95: aload 4
        //   97: invokevirtual 59	android/os/Parcel:recycle	()V
        //   100: aload 6
        //   102: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	103	0	this	Proxy
        //   0	103	1	paramComponentName	ComponentName
        //   0	103	2	paramInt1	int
        //   0	103	3	paramInt2	int
        //   3	93	4	localParcel1	Parcel
        //   8	83	5	localParcel2	Parcel
        //   88	13	6	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	88	finally
        //   21	34	88	finally
        //   34	68	88	finally
        //   79	85	88	finally
      }
      
      /* Error */
      public void setPasswordMinimumNonLetter(ComponentName paramComponentName, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +61 -> 79
        //   21: aload 4
        //   23: iconst_1
        //   24: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 4
        //   30: iconst_0
        //   31: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 4
        //   36: iload_2
        //   37: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   40: aload 4
        //   42: iload_3
        //   43: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   46: aload_0
        //   47: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   50: bipush 15
        //   52: aload 4
        //   54: aload 5
        //   56: iconst_0
        //   57: invokeinterface 43 5 0
        //   62: pop
        //   63: aload 5
        //   65: invokevirtual 46	android/os/Parcel:readException	()V
        //   68: aload 5
        //   70: invokevirtual 59	android/os/Parcel:recycle	()V
        //   73: aload 4
        //   75: invokevirtual 59	android/os/Parcel:recycle	()V
        //   78: return
        //   79: aload 4
        //   81: iconst_0
        //   82: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   85: goto -51 -> 34
        //   88: astore 6
        //   90: aload 5
        //   92: invokevirtual 59	android/os/Parcel:recycle	()V
        //   95: aload 4
        //   97: invokevirtual 59	android/os/Parcel:recycle	()V
        //   100: aload 6
        //   102: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	103	0	this	Proxy
        //   0	103	1	paramComponentName	ComponentName
        //   0	103	2	paramInt1	int
        //   0	103	3	paramInt2	int
        //   3	93	4	localParcel1	Parcel
        //   8	83	5	localParcel2	Parcel
        //   88	13	6	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	88	finally
        //   21	34	88	finally
        //   34	68	88	finally
        //   79	85	88	finally
      }
      
      /* Error */
      public void setPasswordMinimumNumeric(ComponentName paramComponentName, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +61 -> 79
        //   21: aload 4
        //   23: iconst_1
        //   24: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 4
        //   30: iconst_0
        //   31: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 4
        //   36: iload_2
        //   37: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   40: aload 4
        //   42: iload_3
        //   43: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   46: aload_0
        //   47: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   50: bipush 11
        //   52: aload 4
        //   54: aload 5
        //   56: iconst_0
        //   57: invokeinterface 43 5 0
        //   62: pop
        //   63: aload 5
        //   65: invokevirtual 46	android/os/Parcel:readException	()V
        //   68: aload 5
        //   70: invokevirtual 59	android/os/Parcel:recycle	()V
        //   73: aload 4
        //   75: invokevirtual 59	android/os/Parcel:recycle	()V
        //   78: return
        //   79: aload 4
        //   81: iconst_0
        //   82: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   85: goto -51 -> 34
        //   88: astore 6
        //   90: aload 5
        //   92: invokevirtual 59	android/os/Parcel:recycle	()V
        //   95: aload 4
        //   97: invokevirtual 59	android/os/Parcel:recycle	()V
        //   100: aload 6
        //   102: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	103	0	this	Proxy
        //   0	103	1	paramComponentName	ComponentName
        //   0	103	2	paramInt1	int
        //   0	103	3	paramInt2	int
        //   3	93	4	localParcel1	Parcel
        //   8	83	5	localParcel2	Parcel
        //   88	13	6	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	88	finally
        //   21	34	88	finally
        //   34	68	88	finally
        //   79	85	88	finally
      }
      
      /* Error */
      public void setPasswordMinimumSymbols(ComponentName paramComponentName, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +61 -> 79
        //   21: aload 4
        //   23: iconst_1
        //   24: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 4
        //   30: iconst_0
        //   31: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 4
        //   36: iload_2
        //   37: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   40: aload 4
        //   42: iload_3
        //   43: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   46: aload_0
        //   47: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   50: bipush 13
        //   52: aload 4
        //   54: aload 5
        //   56: iconst_0
        //   57: invokeinterface 43 5 0
        //   62: pop
        //   63: aload 5
        //   65: invokevirtual 46	android/os/Parcel:readException	()V
        //   68: aload 5
        //   70: invokevirtual 59	android/os/Parcel:recycle	()V
        //   73: aload 4
        //   75: invokevirtual 59	android/os/Parcel:recycle	()V
        //   78: return
        //   79: aload 4
        //   81: iconst_0
        //   82: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   85: goto -51 -> 34
        //   88: astore 6
        //   90: aload 5
        //   92: invokevirtual 59	android/os/Parcel:recycle	()V
        //   95: aload 4
        //   97: invokevirtual 59	android/os/Parcel:recycle	()V
        //   100: aload 6
        //   102: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	103	0	this	Proxy
        //   0	103	1	paramComponentName	ComponentName
        //   0	103	2	paramInt1	int
        //   0	103	3	paramInt2	int
        //   3	93	4	localParcel1	Parcel
        //   8	83	5	localParcel2	Parcel
        //   88	13	6	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	88	finally
        //   21	34	88	finally
        //   34	68	88	finally
        //   79	85	88	finally
      }
      
      /* Error */
      public void setPasswordMinimumUpperCase(ComponentName paramComponentName, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +60 -> 78
        //   21: aload 4
        //   23: iconst_1
        //   24: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 4
        //   30: iconst_0
        //   31: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 4
        //   36: iload_2
        //   37: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   40: aload 4
        //   42: iload_3
        //   43: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   46: aload_0
        //   47: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   50: iconst_5
        //   51: aload 4
        //   53: aload 5
        //   55: iconst_0
        //   56: invokeinterface 43 5 0
        //   61: pop
        //   62: aload 5
        //   64: invokevirtual 46	android/os/Parcel:readException	()V
        //   67: aload 5
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: aload 4
        //   74: invokevirtual 59	android/os/Parcel:recycle	()V
        //   77: return
        //   78: aload 4
        //   80: iconst_0
        //   81: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   84: goto -50 -> 34
        //   87: astore 6
        //   89: aload 5
        //   91: invokevirtual 59	android/os/Parcel:recycle	()V
        //   94: aload 4
        //   96: invokevirtual 59	android/os/Parcel:recycle	()V
        //   99: aload 6
        //   101: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	102	0	this	Proxy
        //   0	102	1	paramComponentName	ComponentName
        //   0	102	2	paramInt1	int
        //   0	102	3	paramInt2	int
        //   3	92	4	localParcel1	Parcel
        //   8	82	5	localParcel2	Parcel
        //   87	13	6	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	87	finally
        //   21	34	87	finally
        //   34	67	87	finally
        //   78	84	87	finally
      }
      
      /* Error */
      public void setPasswordQuality(ComponentName paramComponentName, int paramInt1, int paramInt2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +60 -> 78
        //   21: aload 4
        //   23: iconst_1
        //   24: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 4
        //   30: iconst_0
        //   31: invokevirtual 65	android/content/ComponentName:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 4
        //   36: iload_2
        //   37: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   40: aload 4
        //   42: iload_3
        //   43: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   46: aload_0
        //   47: getfield 15	android/app/admin/IDevicePolicyManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   50: iconst_1
        //   51: aload 4
        //   53: aload 5
        //   55: iconst_0
        //   56: invokeinterface 43 5 0
        //   61: pop
        //   62: aload 5
        //   64: invokevirtual 46	android/os/Parcel:readException	()V
        //   67: aload 5
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: aload 4
        //   74: invokevirtual 59	android/os/Parcel:recycle	()V
        //   77: return
        //   78: aload 4
        //   80: iconst_0
        //   81: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   84: goto -50 -> 34
        //   87: astore 6
        //   89: aload 5
        //   91: invokevirtual 59	android/os/Parcel:recycle	()V
        //   94: aload 4
        //   96: invokevirtual 59	android/os/Parcel:recycle	()V
        //   99: aload 6
        //   101: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	102	0	this	Proxy
        //   0	102	1	paramComponentName	ComponentName
        //   0	102	2	paramInt1	int
        //   0	102	3	paramInt2	int
        //   3	92	4	localParcel1	Parcel
        //   8	82	5	localParcel2	Parcel
        //   87	13	6	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	87	finally
        //   21	34	87	finally
        //   34	67	87	finally
        //   78	84	87	finally
      }
      
      public int setStorageEncryption(ComponentName paramComponentName, boolean paramBoolean, int paramInt)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
            if (paramComponentName != null)
            {
              localParcel1.writeInt(1);
              paramComponentName.writeToParcel(localParcel1, 0);
              break label125;
              localParcel1.writeInt(i);
              localParcel1.writeInt(paramInt);
              this.mRemote.transact(33, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int j = localParcel2.readInt();
              return j;
            }
            else
            {
              localParcel1.writeInt(0);
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          label125:
          do
          {
            i = 0;
            break;
          } while (!paramBoolean);
        }
      }
      
      public void wipeData(int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.app.admin.IDevicePolicyManager");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          this.mRemote.transact(30, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\admin\IDevicePolicyManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.app;

import android.os.Binder;
import android.os.IBinder;

public abstract class ApplicationThreadNative
  extends Binder
  implements IApplicationThread
{
  public ApplicationThreadNative()
  {
    attachInterface(this, "android.app.IApplicationThread");
  }
  
  public static IApplicationThread asInterface(IBinder paramIBinder)
  {
    IApplicationThread localIApplicationThread;
    if (paramIBinder == null) {
      localIApplicationThread = null;
    }
    do
    {
      return localIApplicationThread;
      localIApplicationThread = (IApplicationThread)paramIBinder.queryLocalInterface("android.app.IApplicationThread");
    } while (localIApplicationThread != null);
    return new ApplicationThreadProxy(paramIBinder);
  }
  
  public IBinder asBinder()
  {
    return this;
  }
  
  /* Error */
  public boolean onTransact(int paramInt1, android.os.Parcel paramParcel1, android.os.Parcel paramParcel2, int paramInt2)
    throws android.os.RemoteException
  {
    // Byte code:
    //   0: iload_1
    //   1: tableswitch	default:+203->204, 1:+213->214, 2:+203->204, 3:+277->278, 4:+323->324, 5:+399->400, 6:+437->438, 7:+460->461, 8:+763->764, 9:+786->787, 10:+832->833, 11:+938->939, 12:+1143->1144, 13:+1159->1160, 14:+1408->1409, 15:+1432->1433, 16:+1448->1449, 17:+1060->1061, 18:+1472->1473, 19:+1520->1521, 20:+978->979, 21:+1032->1033, 22:+1532->1533, 23:+1630->1631, 24:+1733->1734, 25:+1745->1746, 26:+665->666, 27:+361->362, 28:+1761->1762, 29:+1828->1829, 30:+1844->1845, 31:+1884->1885, 32:+1920->1921, 33:+1420->1421, 34:+1954->1955, 35:+1974->1975, 36:+1990->1991, 37:+2049->2050, 38:+1484->1485, 39:+1496->1497, 40:+2106->2107, 41:+2122->2123, 42:+2150->2151, 43:+2166->2167, 44:+2273->2274, 45:+1581->1582, 46:+2328->2329, 47:+2383->2384
    //   204: aload_0
    //   205: iload_1
    //   206: aload_2
    //   207: aload_3
    //   208: iload 4
    //   210: invokespecial 39	android/os/Binder:onTransact	(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    //   213: ireturn
    //   214: aload_2
    //   215: ldc 12
    //   217: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   220: aload_2
    //   221: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   224: astore 117
    //   226: aload_2
    //   227: invokevirtual 52	android/os/Parcel:readInt	()I
    //   230: ifeq +36 -> 266
    //   233: iconst_1
    //   234: istore 118
    //   236: aload_2
    //   237: invokevirtual 52	android/os/Parcel:readInt	()I
    //   240: ifeq +32 -> 272
    //   243: iconst_1
    //   244: istore 119
    //   246: aload_2
    //   247: invokevirtual 52	android/os/Parcel:readInt	()I
    //   250: istore 120
    //   252: aload_0
    //   253: aload 117
    //   255: iload 118
    //   257: iload 119
    //   259: iload 120
    //   261: invokevirtual 56	android/app/ApplicationThreadNative:schedulePauseActivity	(Landroid/os/IBinder;ZZI)V
    //   264: iconst_1
    //   265: ireturn
    //   266: iconst_0
    //   267: istore 118
    //   269: goto -33 -> 236
    //   272: iconst_0
    //   273: istore 119
    //   275: goto -29 -> 246
    //   278: aload_2
    //   279: ldc 12
    //   281: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   284: aload_2
    //   285: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   288: astore 114
    //   290: aload_2
    //   291: invokevirtual 52	android/os/Parcel:readInt	()I
    //   294: ifeq +24 -> 318
    //   297: iconst_1
    //   298: istore 115
    //   300: aload_2
    //   301: invokevirtual 52	android/os/Parcel:readInt	()I
    //   304: istore 116
    //   306: aload_0
    //   307: aload 114
    //   309: iload 115
    //   311: iload 116
    //   313: invokevirtual 60	android/app/ApplicationThreadNative:scheduleStopActivity	(Landroid/os/IBinder;ZI)V
    //   316: iconst_1
    //   317: ireturn
    //   318: iconst_0
    //   319: istore 115
    //   321: goto -21 -> 300
    //   324: aload_2
    //   325: ldc 12
    //   327: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   330: aload_2
    //   331: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   334: astore 112
    //   336: aload_2
    //   337: invokevirtual 52	android/os/Parcel:readInt	()I
    //   340: ifeq +16 -> 356
    //   343: iconst_1
    //   344: istore 113
    //   346: aload_0
    //   347: aload 112
    //   349: iload 113
    //   351: invokevirtual 64	android/app/ApplicationThreadNative:scheduleWindowVisibility	(Landroid/os/IBinder;Z)V
    //   354: iconst_1
    //   355: ireturn
    //   356: iconst_0
    //   357: istore 113
    //   359: goto -13 -> 346
    //   362: aload_2
    //   363: ldc 12
    //   365: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   368: aload_2
    //   369: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   372: astore 110
    //   374: aload_2
    //   375: invokevirtual 52	android/os/Parcel:readInt	()I
    //   378: ifeq +16 -> 394
    //   381: iconst_1
    //   382: istore 111
    //   384: aload_0
    //   385: aload 110
    //   387: iload 111
    //   389: invokevirtual 67	android/app/ApplicationThreadNative:scheduleSleeping	(Landroid/os/IBinder;Z)V
    //   392: iconst_1
    //   393: ireturn
    //   394: iconst_0
    //   395: istore 111
    //   397: goto -13 -> 384
    //   400: aload_2
    //   401: ldc 12
    //   403: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   406: aload_2
    //   407: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   410: astore 108
    //   412: aload_2
    //   413: invokevirtual 52	android/os/Parcel:readInt	()I
    //   416: ifeq +16 -> 432
    //   419: iconst_1
    //   420: istore 109
    //   422: aload_0
    //   423: aload 108
    //   425: iload 109
    //   427: invokevirtual 70	android/app/ApplicationThreadNative:scheduleResumeActivity	(Landroid/os/IBinder;Z)V
    //   430: iconst_1
    //   431: ireturn
    //   432: iconst_0
    //   433: istore 109
    //   435: goto -13 -> 422
    //   438: aload_2
    //   439: ldc 12
    //   441: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   444: aload_0
    //   445: aload_2
    //   446: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   449: aload_2
    //   450: getstatic 76	android/app/ResultInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   453: invokevirtual 80	android/os/Parcel:createTypedArrayList	(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;
    //   456: invokevirtual 84	android/app/ApplicationThreadNative:scheduleSendResult	(Landroid/os/IBinder;Ljava/util/List;)V
    //   459: iconst_1
    //   460: ireturn
    //   461: aload_2
    //   462: ldc 12
    //   464: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   467: getstatic 87	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   470: aload_2
    //   471: invokeinterface 93 2 0
    //   476: checkcast 86	android/content/Intent
    //   479: astore 94
    //   481: aload_2
    //   482: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   485: astore 95
    //   487: aload_2
    //   488: invokevirtual 52	android/os/Parcel:readInt	()I
    //   491: istore 96
    //   493: getstatic 96	android/content/pm/ActivityInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   496: aload_2
    //   497: invokeinterface 93 2 0
    //   502: checkcast 95	android/content/pm/ActivityInfo
    //   505: astore 97
    //   507: getstatic 99	android/content/res/Configuration:CREATOR	Landroid/os/Parcelable$Creator;
    //   510: aload_2
    //   511: invokeinterface 93 2 0
    //   516: checkcast 98	android/content/res/Configuration
    //   519: astore 98
    //   521: getstatic 102	android/content/res/CompatibilityInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   524: aload_2
    //   525: invokeinterface 93 2 0
    //   530: checkcast 101	android/content/res/CompatibilityInfo
    //   533: astore 99
    //   535: aload_2
    //   536: invokevirtual 106	android/os/Parcel:readBundle	()Landroid/os/Bundle;
    //   539: astore 100
    //   541: aload_2
    //   542: getstatic 76	android/app/ResultInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   545: invokevirtual 80	android/os/Parcel:createTypedArrayList	(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;
    //   548: astore 101
    //   550: aload_2
    //   551: getstatic 87	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   554: invokevirtual 80	android/os/Parcel:createTypedArrayList	(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;
    //   557: astore 102
    //   559: aload_2
    //   560: invokevirtual 52	android/os/Parcel:readInt	()I
    //   563: ifeq +79 -> 642
    //   566: iconst_1
    //   567: istore 103
    //   569: aload_2
    //   570: invokevirtual 52	android/os/Parcel:readInt	()I
    //   573: ifeq +75 -> 648
    //   576: iconst_1
    //   577: istore 104
    //   579: aload_2
    //   580: invokevirtual 110	android/os/Parcel:readString	()Ljava/lang/String;
    //   583: astore 105
    //   585: aload_2
    //   586: invokevirtual 52	android/os/Parcel:readInt	()I
    //   589: ifeq +65 -> 654
    //   592: aload_2
    //   593: invokevirtual 114	android/os/Parcel:readFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   596: astore 106
    //   598: aload_2
    //   599: invokevirtual 52	android/os/Parcel:readInt	()I
    //   602: ifeq +58 -> 660
    //   605: iconst_1
    //   606: istore 107
    //   608: aload_0
    //   609: aload 94
    //   611: aload 95
    //   613: iload 96
    //   615: aload 97
    //   617: aload 98
    //   619: aload 99
    //   621: aload 100
    //   623: aload 101
    //   625: aload 102
    //   627: iload 103
    //   629: iload 104
    //   631: aload 105
    //   633: aload 106
    //   635: iload 107
    //   637: invokevirtual 118	android/app/ApplicationThreadNative:scheduleLaunchActivity	(Landroid/content/Intent;Landroid/os/IBinder;ILandroid/content/pm/ActivityInfo;Landroid/content/res/Configuration;Landroid/content/res/CompatibilityInfo;Landroid/os/Bundle;Ljava/util/List;Ljava/util/List;ZZLjava/lang/String;Landroid/os/ParcelFileDescriptor;Z)V
    //   640: iconst_1
    //   641: ireturn
    //   642: iconst_0
    //   643: istore 103
    //   645: goto -76 -> 569
    //   648: iconst_0
    //   649: istore 104
    //   651: goto -72 -> 579
    //   654: aconst_null
    //   655: astore 106
    //   657: goto -59 -> 598
    //   660: iconst_0
    //   661: istore 107
    //   663: goto -55 -> 608
    //   666: aload_2
    //   667: ldc 12
    //   669: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   672: aload_2
    //   673: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   676: astore 87
    //   678: aload_2
    //   679: getstatic 76	android/app/ResultInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   682: invokevirtual 80	android/os/Parcel:createTypedArrayList	(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;
    //   685: astore 88
    //   687: aload_2
    //   688: getstatic 87	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   691: invokevirtual 80	android/os/Parcel:createTypedArrayList	(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;
    //   694: astore 89
    //   696: aload_2
    //   697: invokevirtual 52	android/os/Parcel:readInt	()I
    //   700: istore 90
    //   702: aload_2
    //   703: invokevirtual 52	android/os/Parcel:readInt	()I
    //   706: ifeq +52 -> 758
    //   709: iconst_1
    //   710: istore 91
    //   712: aload_2
    //   713: invokevirtual 52	android/os/Parcel:readInt	()I
    //   716: istore 92
    //   718: aconst_null
    //   719: astore 93
    //   721: iload 92
    //   723: ifeq +17 -> 740
    //   726: getstatic 99	android/content/res/Configuration:CREATOR	Landroid/os/Parcelable$Creator;
    //   729: aload_2
    //   730: invokeinterface 93 2 0
    //   735: checkcast 98	android/content/res/Configuration
    //   738: astore 93
    //   740: aload_0
    //   741: aload 87
    //   743: aload 88
    //   745: aload 89
    //   747: iload 90
    //   749: iload 91
    //   751: aload 93
    //   753: invokevirtual 122	android/app/ApplicationThreadNative:scheduleRelaunchActivity	(Landroid/os/IBinder;Ljava/util/List;Ljava/util/List;IZLandroid/content/res/Configuration;)V
    //   756: iconst_1
    //   757: ireturn
    //   758: iconst_0
    //   759: istore 91
    //   761: goto -49 -> 712
    //   764: aload_2
    //   765: ldc 12
    //   767: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   770: aload_0
    //   771: aload_2
    //   772: getstatic 87	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   775: invokevirtual 80	android/os/Parcel:createTypedArrayList	(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;
    //   778: aload_2
    //   779: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   782: invokevirtual 126	android/app/ApplicationThreadNative:scheduleNewIntent	(Ljava/util/List;Landroid/os/IBinder;)V
    //   785: iconst_1
    //   786: ireturn
    //   787: aload_2
    //   788: ldc 12
    //   790: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   793: aload_2
    //   794: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   797: astore 84
    //   799: aload_2
    //   800: invokevirtual 52	android/os/Parcel:readInt	()I
    //   803: ifeq +24 -> 827
    //   806: iconst_1
    //   807: istore 85
    //   809: aload_2
    //   810: invokevirtual 52	android/os/Parcel:readInt	()I
    //   813: istore 86
    //   815: aload_0
    //   816: aload 84
    //   818: iload 85
    //   820: iload 86
    //   822: invokevirtual 129	android/app/ApplicationThreadNative:scheduleDestroyActivity	(Landroid/os/IBinder;ZI)V
    //   825: iconst_1
    //   826: ireturn
    //   827: iconst_0
    //   828: istore 85
    //   830: goto -21 -> 809
    //   833: aload_2
    //   834: ldc 12
    //   836: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   839: getstatic 87	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   842: aload_2
    //   843: invokeinterface 93 2 0
    //   848: checkcast 86	android/content/Intent
    //   851: astore 77
    //   853: getstatic 96	android/content/pm/ActivityInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   856: aload_2
    //   857: invokeinterface 93 2 0
    //   862: checkcast 95	android/content/pm/ActivityInfo
    //   865: astore 78
    //   867: getstatic 102	android/content/res/CompatibilityInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   870: aload_2
    //   871: invokeinterface 93 2 0
    //   876: checkcast 101	android/content/res/CompatibilityInfo
    //   879: astore 79
    //   881: aload_2
    //   882: invokevirtual 52	android/os/Parcel:readInt	()I
    //   885: istore 80
    //   887: aload_2
    //   888: invokevirtual 110	android/os/Parcel:readString	()Ljava/lang/String;
    //   891: astore 81
    //   893: aload_2
    //   894: invokevirtual 106	android/os/Parcel:readBundle	()Landroid/os/Bundle;
    //   897: astore 82
    //   899: aload_2
    //   900: invokevirtual 52	android/os/Parcel:readInt	()I
    //   903: ifeq +30 -> 933
    //   906: iconst_1
    //   907: istore 83
    //   909: aload_0
    //   910: aload 77
    //   912: aload 78
    //   914: aload 79
    //   916: iload 80
    //   918: aload 81
    //   920: aload 82
    //   922: iload 83
    //   924: aload_2
    //   925: invokevirtual 52	android/os/Parcel:readInt	()I
    //   928: invokevirtual 133	android/app/ApplicationThreadNative:scheduleReceiver	(Landroid/content/Intent;Landroid/content/pm/ActivityInfo;Landroid/content/res/CompatibilityInfo;ILjava/lang/String;Landroid/os/Bundle;ZI)V
    //   931: iconst_1
    //   932: ireturn
    //   933: iconst_0
    //   934: istore 83
    //   936: goto -27 -> 909
    //   939: aload_2
    //   940: ldc 12
    //   942: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   945: aload_0
    //   946: aload_2
    //   947: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   950: getstatic 136	android/content/pm/ServiceInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   953: aload_2
    //   954: invokeinterface 93 2 0
    //   959: checkcast 135	android/content/pm/ServiceInfo
    //   962: getstatic 102	android/content/res/CompatibilityInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   965: aload_2
    //   966: invokeinterface 93 2 0
    //   971: checkcast 101	android/content/res/CompatibilityInfo
    //   974: invokevirtual 140	android/app/ApplicationThreadNative:scheduleCreateService	(Landroid/os/IBinder;Landroid/content/pm/ServiceInfo;Landroid/content/res/CompatibilityInfo;)V
    //   977: iconst_1
    //   978: ireturn
    //   979: aload_2
    //   980: ldc 12
    //   982: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   985: aload_2
    //   986: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   989: astore 74
    //   991: getstatic 87	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   994: aload_2
    //   995: invokeinterface 93 2 0
    //   1000: checkcast 86	android/content/Intent
    //   1003: astore 75
    //   1005: aload_2
    //   1006: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1009: ifeq +18 -> 1027
    //   1012: iconst_1
    //   1013: istore 76
    //   1015: aload_0
    //   1016: aload 74
    //   1018: aload 75
    //   1020: iload 76
    //   1022: invokevirtual 144	android/app/ApplicationThreadNative:scheduleBindService	(Landroid/os/IBinder;Landroid/content/Intent;Z)V
    //   1025: iconst_1
    //   1026: ireturn
    //   1027: iconst_0
    //   1028: istore 76
    //   1030: goto -15 -> 1015
    //   1033: aload_2
    //   1034: ldc 12
    //   1036: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1039: aload_0
    //   1040: aload_2
    //   1041: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1044: getstatic 87	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   1047: aload_2
    //   1048: invokeinterface 93 2 0
    //   1053: checkcast 86	android/content/Intent
    //   1056: invokevirtual 148	android/app/ApplicationThreadNative:scheduleUnbindService	(Landroid/os/IBinder;Landroid/content/Intent;)V
    //   1059: iconst_1
    //   1060: ireturn
    //   1061: aload_2
    //   1062: ldc 12
    //   1064: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1067: aload_2
    //   1068: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1071: astore 69
    //   1073: aload_2
    //   1074: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1077: ifeq +55 -> 1132
    //   1080: iconst_1
    //   1081: istore 70
    //   1083: aload_2
    //   1084: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1087: istore 71
    //   1089: aload_2
    //   1090: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1093: istore 72
    //   1095: aload_2
    //   1096: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1099: ifeq +39 -> 1138
    //   1102: getstatic 87	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   1105: aload_2
    //   1106: invokeinterface 93 2 0
    //   1111: checkcast 86	android/content/Intent
    //   1114: astore 73
    //   1116: aload_0
    //   1117: aload 69
    //   1119: iload 70
    //   1121: iload 71
    //   1123: iload 72
    //   1125: aload 73
    //   1127: invokevirtual 152	android/app/ApplicationThreadNative:scheduleServiceArgs	(Landroid/os/IBinder;ZIILandroid/content/Intent;)V
    //   1130: iconst_1
    //   1131: ireturn
    //   1132: iconst_0
    //   1133: istore 70
    //   1135: goto -52 -> 1083
    //   1138: aconst_null
    //   1139: astore 73
    //   1141: goto -25 -> 1116
    //   1144: aload_2
    //   1145: ldc 12
    //   1147: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1150: aload_0
    //   1151: aload_2
    //   1152: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1155: invokevirtual 155	android/app/ApplicationThreadNative:scheduleStopService	(Landroid/os/IBinder;)V
    //   1158: iconst_1
    //   1159: ireturn
    //   1160: aload_2
    //   1161: ldc 12
    //   1163: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1166: aload_2
    //   1167: invokevirtual 110	android/os/Parcel:readString	()Ljava/lang/String;
    //   1170: astore 52
    //   1172: getstatic 158	android/content/pm/ApplicationInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   1175: aload_2
    //   1176: invokeinterface 93 2 0
    //   1181: checkcast 157	android/content/pm/ApplicationInfo
    //   1184: astore 53
    //   1186: aload_2
    //   1187: getstatic 161	android/content/pm/ProviderInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   1190: invokevirtual 80	android/os/Parcel:createTypedArrayList	(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;
    //   1193: astore 54
    //   1195: aload_2
    //   1196: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1199: ifeq +174 -> 1373
    //   1202: new 163	android/content/ComponentName
    //   1205: dup
    //   1206: aload_2
    //   1207: invokespecial 166	android/content/ComponentName:<init>	(Landroid/os/Parcel;)V
    //   1210: astore 55
    //   1212: aload_2
    //   1213: invokevirtual 110	android/os/Parcel:readString	()Ljava/lang/String;
    //   1216: astore 56
    //   1218: aload_2
    //   1219: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1222: ifeq +157 -> 1379
    //   1225: aload_2
    //   1226: invokevirtual 114	android/os/Parcel:readFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   1229: astore 57
    //   1231: aload_2
    //   1232: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1235: ifeq +150 -> 1385
    //   1238: iconst_1
    //   1239: istore 58
    //   1241: aload_2
    //   1242: invokevirtual 106	android/os/Parcel:readBundle	()Landroid/os/Bundle;
    //   1245: astore 59
    //   1247: aload_2
    //   1248: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1251: invokestatic 171	android/app/IInstrumentationWatcher$Stub:asInterface	(Landroid/os/IBinder;)Landroid/app/IInstrumentationWatcher;
    //   1254: astore 60
    //   1256: aload_2
    //   1257: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1260: istore 61
    //   1262: aload_2
    //   1263: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1266: ifeq +125 -> 1391
    //   1269: iconst_1
    //   1270: istore 62
    //   1272: aload_2
    //   1273: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1276: ifeq +121 -> 1397
    //   1279: iconst_1
    //   1280: istore 63
    //   1282: aload_2
    //   1283: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1286: ifeq +117 -> 1403
    //   1289: iconst_1
    //   1290: istore 64
    //   1292: getstatic 99	android/content/res/Configuration:CREATOR	Landroid/os/Parcelable$Creator;
    //   1295: aload_2
    //   1296: invokeinterface 93 2 0
    //   1301: checkcast 98	android/content/res/Configuration
    //   1304: astore 65
    //   1306: getstatic 102	android/content/res/CompatibilityInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   1309: aload_2
    //   1310: invokeinterface 93 2 0
    //   1315: checkcast 101	android/content/res/CompatibilityInfo
    //   1318: astore 66
    //   1320: aload_2
    //   1321: aconst_null
    //   1322: invokevirtual 175	android/os/Parcel:readHashMap	(Ljava/lang/ClassLoader;)Ljava/util/HashMap;
    //   1325: astore 67
    //   1327: aload_2
    //   1328: invokevirtual 106	android/os/Parcel:readBundle	()Landroid/os/Bundle;
    //   1331: astore 68
    //   1333: aload_0
    //   1334: aload 52
    //   1336: aload 53
    //   1338: aload 54
    //   1340: aload 55
    //   1342: aload 56
    //   1344: aload 57
    //   1346: iload 58
    //   1348: aload 59
    //   1350: aload 60
    //   1352: iload 61
    //   1354: iload 62
    //   1356: iload 63
    //   1358: iload 64
    //   1360: aload 65
    //   1362: aload 66
    //   1364: aload 67
    //   1366: aload 68
    //   1368: invokevirtual 179	android/app/ApplicationThreadNative:bindApplication	(Ljava/lang/String;Landroid/content/pm/ApplicationInfo;Ljava/util/List;Landroid/content/ComponentName;Ljava/lang/String;Landroid/os/ParcelFileDescriptor;ZLandroid/os/Bundle;Landroid/app/IInstrumentationWatcher;IZZZLandroid/content/res/Configuration;Landroid/content/res/CompatibilityInfo;Ljava/util/Map;Landroid/os/Bundle;)V
    //   1371: iconst_1
    //   1372: ireturn
    //   1373: aconst_null
    //   1374: astore 55
    //   1376: goto -164 -> 1212
    //   1379: aconst_null
    //   1380: astore 57
    //   1382: goto -151 -> 1231
    //   1385: iconst_0
    //   1386: istore 58
    //   1388: goto -147 -> 1241
    //   1391: iconst_0
    //   1392: istore 62
    //   1394: goto -122 -> 1272
    //   1397: iconst_0
    //   1398: istore 63
    //   1400: goto -118 -> 1282
    //   1403: iconst_0
    //   1404: istore 64
    //   1406: goto -114 -> 1292
    //   1409: aload_2
    //   1410: ldc 12
    //   1412: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1415: aload_0
    //   1416: invokevirtual 182	android/app/ApplicationThreadNative:scheduleExit	()V
    //   1419: iconst_1
    //   1420: ireturn
    //   1421: aload_2
    //   1422: ldc 12
    //   1424: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1427: aload_0
    //   1428: invokevirtual 185	android/app/ApplicationThreadNative:scheduleSuicide	()V
    //   1431: iconst_1
    //   1432: ireturn
    //   1433: aload_2
    //   1434: ldc 12
    //   1436: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1439: aload_0
    //   1440: aload_2
    //   1441: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1444: invokevirtual 188	android/app/ApplicationThreadNative:requestThumbnail	(Landroid/os/IBinder;)V
    //   1447: iconst_1
    //   1448: ireturn
    //   1449: aload_2
    //   1450: ldc 12
    //   1452: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1455: aload_0
    //   1456: getstatic 99	android/content/res/Configuration:CREATOR	Landroid/os/Parcelable$Creator;
    //   1459: aload_2
    //   1460: invokeinterface 93 2 0
    //   1465: checkcast 98	android/content/res/Configuration
    //   1468: invokevirtual 192	android/app/ApplicationThreadNative:scheduleConfigurationChanged	(Landroid/content/res/Configuration;)V
    //   1471: iconst_1
    //   1472: ireturn
    //   1473: aload_2
    //   1474: ldc 12
    //   1476: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1479: aload_0
    //   1480: invokevirtual 195	android/app/ApplicationThreadNative:updateTimeZone	()V
    //   1483: iconst_1
    //   1484: ireturn
    //   1485: aload_2
    //   1486: ldc 12
    //   1488: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1491: aload_0
    //   1492: invokevirtual 198	android/app/ApplicationThreadNative:clearDnsCache	()V
    //   1495: iconst_1
    //   1496: ireturn
    //   1497: aload_2
    //   1498: ldc 12
    //   1500: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1503: aload_0
    //   1504: aload_2
    //   1505: invokevirtual 110	android/os/Parcel:readString	()Ljava/lang/String;
    //   1508: aload_2
    //   1509: invokevirtual 110	android/os/Parcel:readString	()Ljava/lang/String;
    //   1512: aload_2
    //   1513: invokevirtual 110	android/os/Parcel:readString	()Ljava/lang/String;
    //   1516: invokevirtual 202	android/app/ApplicationThreadNative:setHttpProxy	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   1519: iconst_1
    //   1520: ireturn
    //   1521: aload_2
    //   1522: ldc 12
    //   1524: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1527: aload_0
    //   1528: invokevirtual 205	android/app/ApplicationThreadNative:processInBackground	()V
    //   1531: iconst_1
    //   1532: ireturn
    //   1533: aload_2
    //   1534: ldc 12
    //   1536: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1539: aload_2
    //   1540: invokevirtual 114	android/os/Parcel:readFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   1543: astore 48
    //   1545: aload_2
    //   1546: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1549: astore 49
    //   1551: aload_2
    //   1552: invokevirtual 209	android/os/Parcel:readStringArray	()[Ljava/lang/String;
    //   1555: astore 50
    //   1557: aload 48
    //   1559: ifnull +21 -> 1580
    //   1562: aload_0
    //   1563: aload 48
    //   1565: invokevirtual 215	android/os/ParcelFileDescriptor:getFileDescriptor	()Ljava/io/FileDescriptor;
    //   1568: aload 49
    //   1570: aload 50
    //   1572: invokevirtual 219	android/app/ApplicationThreadNative:dumpService	(Ljava/io/FileDescriptor;Landroid/os/IBinder;[Ljava/lang/String;)V
    //   1575: aload 48
    //   1577: invokevirtual 222	android/os/ParcelFileDescriptor:close	()V
    //   1580: iconst_1
    //   1581: ireturn
    //   1582: aload_2
    //   1583: ldc 12
    //   1585: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1588: aload_2
    //   1589: invokevirtual 114	android/os/Parcel:readFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   1592: astore 44
    //   1594: aload_2
    //   1595: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1598: astore 45
    //   1600: aload_2
    //   1601: invokevirtual 209	android/os/Parcel:readStringArray	()[Ljava/lang/String;
    //   1604: astore 46
    //   1606: aload 44
    //   1608: ifnull +21 -> 1629
    //   1611: aload_0
    //   1612: aload 44
    //   1614: invokevirtual 215	android/os/ParcelFileDescriptor:getFileDescriptor	()Ljava/io/FileDescriptor;
    //   1617: aload 45
    //   1619: aload 46
    //   1621: invokevirtual 225	android/app/ApplicationThreadNative:dumpProvider	(Ljava/io/FileDescriptor;Landroid/os/IBinder;[Ljava/lang/String;)V
    //   1624: aload 44
    //   1626: invokevirtual 222	android/os/ParcelFileDescriptor:close	()V
    //   1629: iconst_1
    //   1630: ireturn
    //   1631: aload_2
    //   1632: ldc 12
    //   1634: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1637: aload_2
    //   1638: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1641: invokestatic 230	android/content/IIntentReceiver$Stub:asInterface	(Landroid/os/IBinder;)Landroid/content/IIntentReceiver;
    //   1644: astore 37
    //   1646: getstatic 87	android/content/Intent:CREATOR	Landroid/os/Parcelable$Creator;
    //   1649: aload_2
    //   1650: invokeinterface 93 2 0
    //   1655: checkcast 86	android/content/Intent
    //   1658: astore 38
    //   1660: aload_2
    //   1661: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1664: istore 39
    //   1666: aload_2
    //   1667: invokevirtual 110	android/os/Parcel:readString	()Ljava/lang/String;
    //   1670: astore 40
    //   1672: aload_2
    //   1673: invokevirtual 106	android/os/Parcel:readBundle	()Landroid/os/Bundle;
    //   1676: astore 41
    //   1678: aload_2
    //   1679: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1682: ifeq +40 -> 1722
    //   1685: iconst_1
    //   1686: istore 42
    //   1688: aload_2
    //   1689: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1692: ifeq +36 -> 1728
    //   1695: iconst_1
    //   1696: istore 43
    //   1698: aload_0
    //   1699: aload 37
    //   1701: aload 38
    //   1703: iload 39
    //   1705: aload 40
    //   1707: aload 41
    //   1709: iload 42
    //   1711: iload 43
    //   1713: aload_2
    //   1714: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1717: invokevirtual 234	android/app/ApplicationThreadNative:scheduleRegisteredReceiver	(Landroid/content/IIntentReceiver;Landroid/content/Intent;ILjava/lang/String;Landroid/os/Bundle;ZZI)V
    //   1720: iconst_1
    //   1721: ireturn
    //   1722: iconst_0
    //   1723: istore 42
    //   1725: goto -37 -> 1688
    //   1728: iconst_0
    //   1729: istore 43
    //   1731: goto -33 -> 1698
    //   1734: aload_2
    //   1735: ldc 12
    //   1737: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1740: aload_0
    //   1741: invokevirtual 237	android/app/ApplicationThreadNative:scheduleLowMemory	()V
    //   1744: iconst_1
    //   1745: ireturn
    //   1746: aload_2
    //   1747: ldc 12
    //   1749: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1752: aload_0
    //   1753: aload_2
    //   1754: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   1757: invokevirtual 240	android/app/ApplicationThreadNative:scheduleActivityConfigurationChanged	(Landroid/os/IBinder;)V
    //   1760: iconst_1
    //   1761: ireturn
    //   1762: aload_2
    //   1763: ldc 12
    //   1765: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1768: aload_2
    //   1769: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1772: ifeq +45 -> 1817
    //   1775: iconst_1
    //   1776: istore 33
    //   1778: aload_2
    //   1779: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1782: istore 34
    //   1784: aload_2
    //   1785: invokevirtual 110	android/os/Parcel:readString	()Ljava/lang/String;
    //   1788: astore 35
    //   1790: aload_2
    //   1791: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1794: ifeq +29 -> 1823
    //   1797: aload_2
    //   1798: invokevirtual 114	android/os/Parcel:readFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   1801: astore 36
    //   1803: aload_0
    //   1804: iload 33
    //   1806: aload 35
    //   1808: aload 36
    //   1810: iload 34
    //   1812: invokevirtual 244	android/app/ApplicationThreadNative:profilerControl	(ZLjava/lang/String;Landroid/os/ParcelFileDescriptor;I)V
    //   1815: iconst_1
    //   1816: ireturn
    //   1817: iconst_0
    //   1818: istore 33
    //   1820: goto -42 -> 1778
    //   1823: aconst_null
    //   1824: astore 36
    //   1826: goto -23 -> 1803
    //   1829: aload_2
    //   1830: ldc 12
    //   1832: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1835: aload_0
    //   1836: aload_2
    //   1837: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1840: invokevirtual 248	android/app/ApplicationThreadNative:setSchedulingGroup	(I)V
    //   1843: iconst_1
    //   1844: ireturn
    //   1845: aload_2
    //   1846: ldc 12
    //   1848: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1851: aload_0
    //   1852: getstatic 158	android/content/pm/ApplicationInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   1855: aload_2
    //   1856: invokeinterface 93 2 0
    //   1861: checkcast 157	android/content/pm/ApplicationInfo
    //   1864: getstatic 102	android/content/res/CompatibilityInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   1867: aload_2
    //   1868: invokeinterface 93 2 0
    //   1873: checkcast 101	android/content/res/CompatibilityInfo
    //   1876: aload_2
    //   1877: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1880: invokevirtual 252	android/app/ApplicationThreadNative:scheduleCreateBackupAgent	(Landroid/content/pm/ApplicationInfo;Landroid/content/res/CompatibilityInfo;I)V
    //   1883: iconst_1
    //   1884: ireturn
    //   1885: aload_2
    //   1886: ldc 12
    //   1888: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1891: aload_0
    //   1892: getstatic 158	android/content/pm/ApplicationInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   1895: aload_2
    //   1896: invokeinterface 93 2 0
    //   1901: checkcast 157	android/content/pm/ApplicationInfo
    //   1904: getstatic 102	android/content/res/CompatibilityInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   1907: aload_2
    //   1908: invokeinterface 93 2 0
    //   1913: checkcast 101	android/content/res/CompatibilityInfo
    //   1916: invokevirtual 256	android/app/ApplicationThreadNative:scheduleDestroyBackupAgent	(Landroid/content/pm/ApplicationInfo;Landroid/content/res/CompatibilityInfo;)V
    //   1919: iconst_1
    //   1920: ireturn
    //   1921: aload_2
    //   1922: ldc 12
    //   1924: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1927: new 258	android/os/Debug$MemoryInfo
    //   1930: dup
    //   1931: invokespecial 259	android/os/Debug$MemoryInfo:<init>	()V
    //   1934: astore 32
    //   1936: aload_0
    //   1937: aload 32
    //   1939: invokevirtual 263	android/app/ApplicationThreadNative:getMemoryInfo	(Landroid/os/Debug$MemoryInfo;)V
    //   1942: aload_3
    //   1943: invokevirtual 266	android/os/Parcel:writeNoException	()V
    //   1946: aload 32
    //   1948: aload_3
    //   1949: iconst_0
    //   1950: invokevirtual 270	android/os/Debug$MemoryInfo:writeToParcel	(Landroid/os/Parcel;I)V
    //   1953: iconst_1
    //   1954: ireturn
    //   1955: aload_2
    //   1956: ldc 12
    //   1958: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1961: aload_0
    //   1962: aload_2
    //   1963: invokevirtual 52	android/os/Parcel:readInt	()I
    //   1966: aload_2
    //   1967: invokevirtual 209	android/os/Parcel:readStringArray	()[Ljava/lang/String;
    //   1970: invokevirtual 274	android/app/ApplicationThreadNative:dispatchPackageBroadcast	(I[Ljava/lang/String;)V
    //   1973: iconst_1
    //   1974: ireturn
    //   1975: aload_2
    //   1976: ldc 12
    //   1978: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1981: aload_0
    //   1982: aload_2
    //   1983: invokevirtual 110	android/os/Parcel:readString	()Ljava/lang/String;
    //   1986: invokevirtual 277	android/app/ApplicationThreadNative:scheduleCrash	(Ljava/lang/String;)V
    //   1989: iconst_1
    //   1990: ireturn
    //   1991: aload_2
    //   1992: ldc 12
    //   1994: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   1997: aload_2
    //   1998: invokevirtual 52	android/os/Parcel:readInt	()I
    //   2001: ifeq +37 -> 2038
    //   2004: iconst_1
    //   2005: istore 29
    //   2007: aload_2
    //   2008: invokevirtual 110	android/os/Parcel:readString	()Ljava/lang/String;
    //   2011: astore 30
    //   2013: aload_2
    //   2014: invokevirtual 52	android/os/Parcel:readInt	()I
    //   2017: ifeq +27 -> 2044
    //   2020: aload_2
    //   2021: invokevirtual 114	android/os/Parcel:readFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   2024: astore 31
    //   2026: aload_0
    //   2027: iload 29
    //   2029: aload 30
    //   2031: aload 31
    //   2033: invokevirtual 281	android/app/ApplicationThreadNative:dumpHeap	(ZLjava/lang/String;Landroid/os/ParcelFileDescriptor;)V
    //   2036: iconst_1
    //   2037: ireturn
    //   2038: iconst_0
    //   2039: istore 29
    //   2041: goto -34 -> 2007
    //   2044: aconst_null
    //   2045: astore 31
    //   2047: goto -21 -> 2026
    //   2050: aload_2
    //   2051: ldc 12
    //   2053: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2056: aload_2
    //   2057: invokevirtual 114	android/os/Parcel:readFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   2060: astore 24
    //   2062: aload_2
    //   2063: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2066: astore 25
    //   2068: aload_2
    //   2069: invokevirtual 110	android/os/Parcel:readString	()Ljava/lang/String;
    //   2072: astore 26
    //   2074: aload_2
    //   2075: invokevirtual 209	android/os/Parcel:readStringArray	()[Ljava/lang/String;
    //   2078: astore 27
    //   2080: aload 24
    //   2082: ifnull +23 -> 2105
    //   2085: aload_0
    //   2086: aload 24
    //   2088: invokevirtual 215	android/os/ParcelFileDescriptor:getFileDescriptor	()Ljava/io/FileDescriptor;
    //   2091: aload 25
    //   2093: aload 26
    //   2095: aload 27
    //   2097: invokevirtual 285	android/app/ApplicationThreadNative:dumpActivity	(Ljava/io/FileDescriptor;Landroid/os/IBinder;Ljava/lang/String;[Ljava/lang/String;)V
    //   2100: aload 24
    //   2102: invokevirtual 222	android/os/ParcelFileDescriptor:close	()V
    //   2105: iconst_1
    //   2106: ireturn
    //   2107: aload_2
    //   2108: ldc 12
    //   2110: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2113: aload_0
    //   2114: aload_2
    //   2115: invokevirtual 106	android/os/Parcel:readBundle	()Landroid/os/Bundle;
    //   2118: invokevirtual 289	android/app/ApplicationThreadNative:setCoreSettings	(Landroid/os/Bundle;)V
    //   2121: iconst_1
    //   2122: ireturn
    //   2123: aload_2
    //   2124: ldc 12
    //   2126: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2129: aload_0
    //   2130: aload_2
    //   2131: invokevirtual 110	android/os/Parcel:readString	()Ljava/lang/String;
    //   2134: getstatic 102	android/content/res/CompatibilityInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   2137: aload_2
    //   2138: invokeinterface 93 2 0
    //   2143: checkcast 101	android/content/res/CompatibilityInfo
    //   2146: invokevirtual 293	android/app/ApplicationThreadNative:updatePackageCompatibilityInfo	(Ljava/lang/String;Landroid/content/res/CompatibilityInfo;)V
    //   2149: iconst_1
    //   2150: ireturn
    //   2151: aload_2
    //   2152: ldc 12
    //   2154: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2157: aload_0
    //   2158: aload_2
    //   2159: invokevirtual 52	android/os/Parcel:readInt	()I
    //   2162: invokevirtual 296	android/app/ApplicationThreadNative:scheduleTrimMemory	(I)V
    //   2165: iconst_1
    //   2166: ireturn
    //   2167: aload_2
    //   2168: ldc 12
    //   2170: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2173: aload_2
    //   2174: invokevirtual 114	android/os/Parcel:readFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   2177: astore 15
    //   2179: aload_2
    //   2180: invokevirtual 52	android/os/Parcel:readInt	()I
    //   2183: ifeq +69 -> 2252
    //   2186: iconst_1
    //   2187: istore 16
    //   2189: aload_2
    //   2190: invokevirtual 52	android/os/Parcel:readInt	()I
    //   2193: ifeq +65 -> 2258
    //   2196: iconst_1
    //   2197: istore 17
    //   2199: aload_2
    //   2200: invokevirtual 209	android/os/Parcel:readStringArray	()[Ljava/lang/String;
    //   2203: astore 18
    //   2205: aconst_null
    //   2206: astore 19
    //   2208: aload 15
    //   2210: ifnull +29 -> 2239
    //   2213: aload_0
    //   2214: aload 15
    //   2216: invokevirtual 215	android/os/ParcelFileDescriptor:getFileDescriptor	()Ljava/io/FileDescriptor;
    //   2219: iload 16
    //   2221: iload 17
    //   2223: aload 18
    //   2225: invokevirtual 300	android/app/ApplicationThreadNative:dumpMemInfo	(Ljava/io/FileDescriptor;ZZ[Ljava/lang/String;)Landroid/os/Debug$MemoryInfo;
    //   2228: astore 22
    //   2230: aload 22
    //   2232: astore 19
    //   2234: aload 15
    //   2236: invokevirtual 222	android/os/ParcelFileDescriptor:close	()V
    //   2239: aload_3
    //   2240: invokevirtual 266	android/os/Parcel:writeNoException	()V
    //   2243: aload 19
    //   2245: aload_3
    //   2246: iconst_0
    //   2247: invokevirtual 270	android/os/Debug$MemoryInfo:writeToParcel	(Landroid/os/Parcel;I)V
    //   2250: iconst_1
    //   2251: ireturn
    //   2252: iconst_0
    //   2253: istore 16
    //   2255: goto -66 -> 2189
    //   2258: iconst_0
    //   2259: istore 17
    //   2261: goto -62 -> 2199
    //   2264: astore 20
    //   2266: aload 15
    //   2268: invokevirtual 222	android/os/ParcelFileDescriptor:close	()V
    //   2271: aload 20
    //   2273: athrow
    //   2274: aload_2
    //   2275: ldc 12
    //   2277: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2280: aload_2
    //   2281: invokevirtual 114	android/os/Parcel:readFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   2284: astore 10
    //   2286: aload_2
    //   2287: invokevirtual 209	android/os/Parcel:readStringArray	()[Ljava/lang/String;
    //   2290: astore 11
    //   2292: aload 10
    //   2294: ifnull +19 -> 2313
    //   2297: aload_0
    //   2298: aload 10
    //   2300: invokevirtual 215	android/os/ParcelFileDescriptor:getFileDescriptor	()Ljava/io/FileDescriptor;
    //   2303: aload 11
    //   2305: invokevirtual 304	android/app/ApplicationThreadNative:dumpGfxInfo	(Ljava/io/FileDescriptor;[Ljava/lang/String;)V
    //   2308: aload 10
    //   2310: invokevirtual 222	android/os/ParcelFileDescriptor:close	()V
    //   2313: aload_3
    //   2314: invokevirtual 266	android/os/Parcel:writeNoException	()V
    //   2317: iconst_1
    //   2318: ireturn
    //   2319: astore 12
    //   2321: aload 10
    //   2323: invokevirtual 222	android/os/ParcelFileDescriptor:close	()V
    //   2326: aload 12
    //   2328: athrow
    //   2329: aload_2
    //   2330: ldc 12
    //   2332: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2335: aload_2
    //   2336: invokevirtual 114	android/os/Parcel:readFileDescriptor	()Landroid/os/ParcelFileDescriptor;
    //   2339: astore 5
    //   2341: aload_2
    //   2342: invokevirtual 209	android/os/Parcel:readStringArray	()[Ljava/lang/String;
    //   2345: astore 6
    //   2347: aload 5
    //   2349: ifnull +19 -> 2368
    //   2352: aload_0
    //   2353: aload 5
    //   2355: invokevirtual 215	android/os/ParcelFileDescriptor:getFileDescriptor	()Ljava/io/FileDescriptor;
    //   2358: aload 6
    //   2360: invokevirtual 307	android/app/ApplicationThreadNative:dumpDbInfo	(Ljava/io/FileDescriptor;[Ljava/lang/String;)V
    //   2363: aload 5
    //   2365: invokevirtual 222	android/os/ParcelFileDescriptor:close	()V
    //   2368: aload_3
    //   2369: invokevirtual 266	android/os/Parcel:writeNoException	()V
    //   2372: iconst_1
    //   2373: ireturn
    //   2374: astore 7
    //   2376: aload 5
    //   2378: invokevirtual 222	android/os/ParcelFileDescriptor:close	()V
    //   2381: aload 7
    //   2383: athrow
    //   2384: aload_2
    //   2385: ldc 12
    //   2387: invokevirtual 45	android/os/Parcel:enforceInterface	(Ljava/lang/String;)V
    //   2390: aload_0
    //   2391: aload_2
    //   2392: invokevirtual 48	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
    //   2395: invokevirtual 310	android/app/ApplicationThreadNative:unstableProviderDied	(Landroid/os/IBinder;)V
    //   2398: aload_3
    //   2399: invokevirtual 266	android/os/Parcel:writeNoException	()V
    //   2402: iconst_1
    //   2403: ireturn
    //   2404: astore 51
    //   2406: goto -826 -> 1580
    //   2409: astore 47
    //   2411: goto -782 -> 1629
    //   2414: astore 28
    //   2416: goto -311 -> 2105
    //   2419: astore 23
    //   2421: goto -182 -> 2239
    //   2424: astore 21
    //   2426: goto -155 -> 2271
    //   2429: astore 14
    //   2431: goto -118 -> 2313
    //   2434: astore 13
    //   2436: goto -110 -> 2326
    //   2439: astore 9
    //   2441: goto -73 -> 2368
    //   2444: astore 8
    //   2446: goto -65 -> 2381
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	2449	0	this	ApplicationThreadNative
    //   0	2449	1	paramInt1	int
    //   0	2449	2	paramParcel1	android.os.Parcel
    //   0	2449	3	paramParcel2	android.os.Parcel
    //   0	2449	4	paramInt2	int
    //   2339	38	5	localParcelFileDescriptor1	android.os.ParcelFileDescriptor
    //   2345	14	6	arrayOfString1	String[]
    //   2374	8	7	localObject1	Object
    //   2444	1	8	localIOException1	java.io.IOException
    //   2439	1	9	localIOException2	java.io.IOException
    //   2284	38	10	localParcelFileDescriptor2	android.os.ParcelFileDescriptor
    //   2290	14	11	arrayOfString2	String[]
    //   2319	8	12	localObject2	Object
    //   2434	1	13	localIOException3	java.io.IOException
    //   2429	1	14	localIOException4	java.io.IOException
    //   2177	90	15	localParcelFileDescriptor3	android.os.ParcelFileDescriptor
    //   2187	67	16	bool1	boolean
    //   2197	63	17	bool2	boolean
    //   2203	21	18	arrayOfString3	String[]
    //   2206	38	19	localObject3	Object
    //   2264	8	20	localObject4	Object
    //   2424	1	21	localIOException5	java.io.IOException
    //   2228	3	22	localMemoryInfo1	android.os.Debug.MemoryInfo
    //   2419	1	23	localIOException6	java.io.IOException
    //   2060	41	24	localParcelFileDescriptor4	android.os.ParcelFileDescriptor
    //   2066	26	25	localIBinder1	IBinder
    //   2072	22	26	str1	String
    //   2078	18	27	arrayOfString4	String[]
    //   2414	1	28	localIOException7	java.io.IOException
    //   2005	35	29	bool3	boolean
    //   2011	19	30	str2	String
    //   2024	22	31	localParcelFileDescriptor5	android.os.ParcelFileDescriptor
    //   1934	13	32	localMemoryInfo2	android.os.Debug.MemoryInfo
    //   1776	43	33	bool4	boolean
    //   1782	29	34	i	int
    //   1788	19	35	str3	String
    //   1801	24	36	localParcelFileDescriptor6	android.os.ParcelFileDescriptor
    //   1644	56	37	localIIntentReceiver	android.content.IIntentReceiver
    //   1658	44	38	localIntent1	android.content.Intent
    //   1664	40	39	j	int
    //   1670	36	40	str4	String
    //   1676	32	41	localBundle1	android.os.Bundle
    //   1686	38	42	bool5	boolean
    //   1696	34	43	bool6	boolean
    //   1592	33	44	localParcelFileDescriptor7	android.os.ParcelFileDescriptor
    //   1598	20	45	localIBinder2	IBinder
    //   1604	16	46	arrayOfString5	String[]
    //   2409	1	47	localIOException8	java.io.IOException
    //   1543	33	48	localParcelFileDescriptor8	android.os.ParcelFileDescriptor
    //   1549	20	49	localIBinder3	IBinder
    //   1555	16	50	arrayOfString6	String[]
    //   2404	1	51	localIOException9	java.io.IOException
    //   1170	165	52	str5	String
    //   1184	153	53	localApplicationInfo	android.content.pm.ApplicationInfo
    //   1193	146	54	localArrayList1	java.util.ArrayList
    //   1210	165	55	localComponentName	android.content.ComponentName
    //   1216	127	56	str6	String
    //   1229	152	57	localParcelFileDescriptor9	android.os.ParcelFileDescriptor
    //   1239	148	58	bool7	boolean
    //   1245	104	59	localBundle2	android.os.Bundle
    //   1254	97	60	localIInstrumentationWatcher	IInstrumentationWatcher
    //   1260	93	61	k	int
    //   1270	123	62	bool8	boolean
    //   1280	119	63	bool9	boolean
    //   1290	115	64	bool10	boolean
    //   1304	57	65	localConfiguration1	android.content.res.Configuration
    //   1318	45	66	localCompatibilityInfo1	android.content.res.CompatibilityInfo
    //   1325	40	67	localHashMap	java.util.HashMap
    //   1331	36	68	localBundle3	android.os.Bundle
    //   1071	47	69	localIBinder4	IBinder
    //   1081	53	70	bool11	boolean
    //   1087	35	71	m	int
    //   1093	31	72	n	int
    //   1114	26	73	localIntent2	android.content.Intent
    //   989	28	74	localIBinder5	IBinder
    //   1003	16	75	localIntent3	android.content.Intent
    //   1013	16	76	bool12	boolean
    //   851	60	77	localIntent4	android.content.Intent
    //   865	48	78	localActivityInfo1	android.content.pm.ActivityInfo
    //   879	36	79	localCompatibilityInfo2	android.content.res.CompatibilityInfo
    //   885	32	80	i1	int
    //   891	28	81	str7	String
    //   897	24	82	localBundle4	android.os.Bundle
    //   907	28	83	bool13	boolean
    //   797	20	84	localIBinder6	IBinder
    //   807	22	85	bool14	boolean
    //   813	8	86	i2	int
    //   676	66	87	localIBinder7	IBinder
    //   685	59	88	localArrayList2	java.util.ArrayList
    //   694	52	89	localArrayList3	java.util.ArrayList
    //   700	48	90	i3	int
    //   710	50	91	bool15	boolean
    //   716	6	92	i4	int
    //   719	33	93	localConfiguration2	android.content.res.Configuration
    //   479	131	94	localIntent5	android.content.Intent
    //   485	127	95	localIBinder8	IBinder
    //   491	123	96	i5	int
    //   505	111	97	localActivityInfo2	android.content.pm.ActivityInfo
    //   519	99	98	localConfiguration3	android.content.res.Configuration
    //   533	87	99	localCompatibilityInfo3	android.content.res.CompatibilityInfo
    //   539	83	100	localBundle5	android.os.Bundle
    //   548	76	101	localArrayList4	java.util.ArrayList
    //   557	69	102	localArrayList5	java.util.ArrayList
    //   567	77	103	bool16	boolean
    //   577	73	104	bool17	boolean
    //   583	49	105	str8	String
    //   596	60	106	localParcelFileDescriptor10	android.os.ParcelFileDescriptor
    //   606	56	107	bool18	boolean
    //   410	14	108	localIBinder9	IBinder
    //   420	14	109	bool19	boolean
    //   372	14	110	localIBinder10	IBinder
    //   382	14	111	bool20	boolean
    //   334	14	112	localIBinder11	IBinder
    //   344	14	113	bool21	boolean
    //   288	20	114	localIBinder12	IBinder
    //   298	22	115	bool22	boolean
    //   304	8	116	i6	int
    //   224	30	117	localIBinder13	IBinder
    //   234	34	118	bool23	boolean
    //   244	30	119	bool24	boolean
    //   250	10	120	i7	int
    // Exception table:
    //   from	to	target	type
    //   2213	2230	2264	finally
    //   2297	2308	2319	finally
    //   2352	2363	2374	finally
    //   1575	1580	2404	java/io/IOException
    //   1624	1629	2409	java/io/IOException
    //   2100	2105	2414	java/io/IOException
    //   2234	2239	2419	java/io/IOException
    //   2266	2271	2424	java/io/IOException
    //   2308	2313	2429	java/io/IOException
    //   2321	2326	2434	java/io/IOException
    //   2363	2368	2439	java/io/IOException
    //   2376	2381	2444	java/io/IOException
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\ApplicationThreadNative.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
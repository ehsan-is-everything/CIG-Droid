package android.app;

import android.app.backup.BackupAgent;
import android.content.BroadcastReceiver;
import android.content.BroadcastReceiver.PendingResult;
import android.content.ComponentCallbacks2;
import android.content.ComponentName;
import android.content.ContentProvider;
import android.content.Context;
import android.content.IContentProvider;
import android.content.IIntentReceiver;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.IPackageManager;
import android.content.pm.IPackageManager.Stub;
import android.content.pm.PackageInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;
import android.content.res.AssetManager;
import android.content.res.CompatibilityInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDebug;
import android.database.sqlite.SQLiteDebug.DbStats;
import android.database.sqlite.SQLiteDebug.PagerStats;
import android.ddm.DdmHandleAppName;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.hardware.display.DisplayManagerGlobal;
import android.net.Proxy;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Debug;
import android.os.Debug.MemoryInfo;
import android.os.DropBoxManager;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.MessageQueue;
import android.os.MessageQueue.IdleHandler;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.StrictMode;
import android.os.StrictMode.ThreadPolicy;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.os.Trace;
import android.os.UserHandle;
import android.renderscript.RenderScript;
import android.util.DisplayMetrics;
import android.util.EventLog;
import android.util.Log;
import android.util.PrintWriterPrinter;
import android.util.Slog;
import android.view.CompatibilityInfoHolder;
import android.view.Display;
import android.view.HardwareRenderer;
import android.view.View;
import android.view.ViewDebug;
import android.view.ViewManager;
import android.view.ViewRootImpl;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.view.WindowManagerGlobal;
import com.android.internal.os.BinderInternal;
import com.android.internal.os.RuntimeInit;
import com.android.internal.os.SamplingProfilerIntegration;
import com.android.internal.util.Objects;
import dalvik.system.CloseGuard;
import dalvik.system.VMRuntime;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TimeZone;
import java.util.regex.Pattern;
import libcore.io.DropBox;
import libcore.io.DropBox.Reporter;
import libcore.io.EventLogger;
import libcore.io.EventLogger.Reporter;
import libcore.io.IoUtils;
import org.apache.harmony.xnet.provider.jsse.OpenSSLSocketImpl;

public final class ActivityThread
{
  private static final boolean DEBUG_BACKUP = false;
  public static final boolean DEBUG_BROADCAST = false;
  private static final boolean DEBUG_CONFIGURATION = false;
  private static final boolean DEBUG_MEMORY_TRIM = false;
  static final boolean DEBUG_MESSAGES = false;
  private static final boolean DEBUG_PROVIDER = false;
  private static final boolean DEBUG_RESULTS = false;
  private static final boolean DEBUG_SERVICE = false;
  private static final int LOG_ON_PAUSE_CALLED = 30021;
  private static final int LOG_ON_RESUME_CALLED = 30022;
  private static final long MIN_TIME_BETWEEN_GCS = 5000L;
  private static final Pattern PATTERN_SEMICOLON;
  private static final int SQLITE_MEM_RELEASED_EVENT_LOG_TAG = 75003;
  public static final String TAG = "ActivityThread";
  private static final Bitmap.Config THUMBNAIL_FORMAT = Bitmap.Config.RGB_565;
  static final boolean localLOGV;
  static ContextImpl mSystemContext;
  private static final ThreadLocal<Intent> sCurrentBroadcastIntent = new ThreadLocal();
  static Handler sMainThreadHandler;
  static IPackageManager sPackageManager;
  static final ThreadLocal<ActivityThread> sThreadLocal;
  final HashMap<ResourcesKey, WeakReference<Resources>> mActiveResources = new HashMap();
  final HashMap<IBinder, ActivityClientRecord> mActivities = new HashMap();
  final ArrayList<Application> mAllApplications = new ArrayList();
  final ApplicationThread mAppThread = new ApplicationThread(null);
  private Bitmap mAvailThumbnailBitmap = null;
  final HashMap<String, BackupAgent> mBackupAgents = new HashMap();
  AppBindData mBoundApplication;
  Configuration mCompatConfiguration;
  Configuration mConfiguration;
  Bundle mCoreSettings = null;
  int mCurDefaultDisplayDpi;
  final HashMap<CompatibilityInfo, DisplayMetrics> mDefaultDisplayMetrics = new HashMap();
  boolean mDensityCompatMode;
  final GcIdler mGcIdler = new GcIdler();
  boolean mGcIdlerScheduled = false;
  final H mH = new H(null);
  Application mInitialApplication;
  Instrumentation mInstrumentation;
  String mInstrumentationAppDir = null;
  String mInstrumentationAppLibraryDir = null;
  String mInstrumentationAppPackage = null;
  String mInstrumentedAppDir = null;
  String mInstrumentedAppLibraryDir = null;
  boolean mJitEnabled = false;
  final HashMap<IBinder, ProviderClientRecord> mLocalProviders = new HashMap();
  final HashMap<ComponentName, ProviderClientRecord> mLocalProvidersByName = new HashMap();
  final Looper mLooper = Looper.myLooper();
  private Configuration mMainThreadConfig = new Configuration();
  ActivityClientRecord mNewActivities = null;
  int mNumVisibleActivities = 0;
  final HashMap<Activity, ArrayList<OnActivityPausedListener>> mOnPauseListeners = new HashMap();
  final HashMap<String, WeakReference<LoadedApk>> mPackages = new HashMap();
  Configuration mPendingConfiguration = null;
  Profiler mProfiler;
  final HashMap<ProviderKey, ProviderClientRecord> mProviderMap = new HashMap();
  final HashMap<IBinder, ProviderRefCount> mProviderRefCountMap = new HashMap();
  final ArrayList<ActivityClientRecord> mRelaunchingActivities = new ArrayList();
  CompatibilityInfo mResCompatibilityInfo;
  Configuration mResConfiguration;
  final HashMap<String, WeakReference<LoadedApk>> mResourcePackages = new HashMap();
  final HashMap<IBinder, Service> mServices = new HashMap();
  boolean mSystemThread = false;
  private Canvas mThumbnailCanvas = null;
  private int mThumbnailHeight = -1;
  private int mThumbnailWidth = -1;
  
  static
  {
    PATTERN_SEMICOLON = Pattern.compile(";");
    mSystemContext = null;
    sThreadLocal = new ThreadLocal();
  }
  
  private void attach(boolean paramBoolean)
  {
    sThreadLocal.set(this);
    this.mSystemThread = paramBoolean;
    IActivityManager localIActivityManager;
    if (!paramBoolean)
    {
      ViewRootImpl.addFirstDrawHandler(new Runnable()
      {
        public void run()
        {
          ActivityThread.this.ensureJitEnabled();
        }
      });
      DdmHandleAppName.setAppName("<pre-initialized>", UserHandle.myUserId());
      RuntimeInit.setApplicationObject(this.mAppThread.asBinder());
      localIActivityManager = ActivityManagerNative.getDefault();
    }
    try
    {
      localIActivityManager.attachApplication(this.mAppThread);
      for (;;)
      {
        DropBox.setReporter(new DropBoxReporter());
        ViewRootImpl.addConfigCallback(new ComponentCallbacks2()
        {
          public void onConfigurationChanged(Configuration paramAnonymousConfiguration)
          {
            synchronized (ActivityThread.this.mPackages)
            {
              if ((ActivityThread.this.applyConfigurationToResourcesLocked(paramAnonymousConfiguration, null)) && ((ActivityThread.this.mPendingConfiguration == null) || (ActivityThread.this.mPendingConfiguration.isOtherSeqNewer(paramAnonymousConfiguration))))
              {
                ActivityThread.this.mPendingConfiguration = paramAnonymousConfiguration;
                ActivityThread.this.queueOrSendMessage(118, paramAnonymousConfiguration);
              }
              return;
            }
          }
          
          public void onLowMemory() {}
          
          public void onTrimMemory(int paramAnonymousInt) {}
        });
        return;
        DdmHandleAppName.setAppName("system_process", UserHandle.myUserId());
        try
        {
          this.mInstrumentation = new Instrumentation();
          ContextImpl localContextImpl = new ContextImpl();
          localContextImpl.init(getSystemContext().mPackageInfo, null, this);
          Application localApplication = Instrumentation.newApplication(Application.class, localContextImpl);
          this.mAllApplications.add(localApplication);
          this.mInitialApplication = localApplication;
          localApplication.onCreate();
        }
        catch (Exception localException)
        {
          throw new RuntimeException("Unable to instantiate Application():" + localException.toString(), localException);
        }
      }
    }
    catch (RemoteException localRemoteException)
    {
      for (;;) {}
    }
  }
  
  static final void cleanUpPendingRemoveWindows(ActivityClientRecord paramActivityClientRecord)
  {
    if (paramActivityClientRecord.mPendingRemoveWindow != null)
    {
      paramActivityClientRecord.mPendingRemoveWindowManager.removeViewImmediate(paramActivityClientRecord.mPendingRemoveWindow);
      IBinder localIBinder = paramActivityClientRecord.mPendingRemoveWindow.getWindowToken();
      if (localIBinder != null) {
        WindowManagerGlobal.getInstance().closeAll(localIBinder, paramActivityClientRecord.activity.getClass().getName(), "Activity");
      }
    }
    paramActivityClientRecord.mPendingRemoveWindow = null;
    paramActivityClientRecord.mPendingRemoveWindowManager = null;
  }
  
  private Context createBaseContextForActivity(ActivityClientRecord paramActivityClientRecord, Activity paramActivity)
  {
    ContextImpl localContextImpl = new ContextImpl();
    localContextImpl.init(paramActivityClientRecord.packageInfo, paramActivityClientRecord.token, this);
    localContextImpl.setOuterContext(paramActivity);
    Object localObject = localContextImpl;
    String str = SystemProperties.get("debug.second-display.pkg");
    DisplayManagerGlobal localDisplayManagerGlobal;
    int[] arrayOfInt;
    int i;
    if ((str != null) && (!str.isEmpty()) && (paramActivityClientRecord.packageInfo.mPackageName.contains(str)))
    {
      localDisplayManagerGlobal = DisplayManagerGlobal.getInstance();
      arrayOfInt = localDisplayManagerGlobal.getDisplayIds();
      i = arrayOfInt.length;
    }
    for (int j = 0;; j++) {
      if (j < i)
      {
        int k = arrayOfInt[j];
        if (k != 0) {
          localObject = localContextImpl.createDisplayContext(localDisplayManagerGlobal.getRealDisplay(k));
        }
      }
      else
      {
        return (Context)localObject;
      }
    }
  }
  
  private Bitmap createThumbnailBitmap(ActivityClientRecord paramActivityClientRecord)
  {
    localBitmap = this.mAvailThumbnailBitmap;
    if (localBitmap == null) {}
    try
    {
      int i = this.mThumbnailWidth;
      int j;
      if (i < 0)
      {
        Resources localResources = paramActivityClientRecord.activity.getResources();
        j = localResources.getDimensionPixelSize(17104897);
        this.mThumbnailHeight = j;
        i = localResources.getDimensionPixelSize(17104898);
        this.mThumbnailWidth = i;
      }
      for (;;)
      {
        if ((i > 0) && (j > 0))
        {
          localBitmap = Bitmap.createBitmap(paramActivityClientRecord.activity.getResources().getDisplayMetrics(), i, j, THUMBNAIL_FORMAT);
          localBitmap.eraseColor(0);
        }
        if (localBitmap == null) {
          break;
        }
        Canvas localCanvas = this.mThumbnailCanvas;
        if (localCanvas == null)
        {
          localCanvas = new Canvas();
          this.mThumbnailCanvas = localCanvas;
        }
        localCanvas.setBitmap(localBitmap);
        if (!paramActivityClientRecord.activity.onCreateThumbnail(localBitmap, localCanvas))
        {
          this.mAvailThumbnailBitmap = localBitmap;
          localBitmap = null;
        }
        localCanvas.setBitmap(null);
        return localBitmap;
        j = this.mThumbnailHeight;
      }
      return localBitmap;
    }
    catch (Exception localException)
    {
      if (!this.mInstrumentation.onException(paramActivityClientRecord.activity, localException)) {
        throw new RuntimeException("Unable to create thumbnail of " + paramActivityClientRecord.intent.getComponent().toShortString() + ": " + localException.toString(), localException);
      }
      localBitmap = null;
    }
  }
  
  public static ActivityThread currentActivityThread()
  {
    return (ActivityThread)sThreadLocal.get();
  }
  
  public static Application currentApplication()
  {
    ActivityThread localActivityThread = currentActivityThread();
    if (localActivityThread != null) {
      return localActivityThread.mInitialApplication;
    }
    return null;
  }
  
  public static String currentPackageName()
  {
    ActivityThread localActivityThread = currentActivityThread();
    if ((localActivityThread != null) && (localActivityThread.mBoundApplication != null)) {
      return localActivityThread.mBoundApplication.processName;
    }
    return null;
  }
  
  private void deliverNewIntents(ActivityClientRecord paramActivityClientRecord, List<Intent> paramList)
  {
    int i = paramList.size();
    for (int j = 0; j < i; j++)
    {
      Intent localIntent = (Intent)paramList.get(j);
      localIntent.setExtrasClassLoader(paramActivityClientRecord.activity.getClassLoader());
      paramActivityClientRecord.activity.mFragments.noteStateNotSaved();
      this.mInstrumentation.callActivityOnNewIntent(paramActivityClientRecord.activity, localIntent);
    }
  }
  
  private void deliverResults(ActivityClientRecord paramActivityClientRecord, List<ResultInfo> paramList)
  {
    int i = paramList.size();
    int j = 0;
    while (j < i)
    {
      ResultInfo localResultInfo = (ResultInfo)paramList.get(j);
      try
      {
        if (localResultInfo.mData != null) {
          localResultInfo.mData.setExtrasClassLoader(paramActivityClientRecord.activity.getClassLoader());
        }
        paramActivityClientRecord.activity.dispatchActivityResult(localResultInfo.mResultWho, localResultInfo.mRequestCode, localResultInfo.mResultCode, localResultInfo.mData);
        j++;
      }
      catch (Exception localException)
      {
        while (this.mInstrumentation.onException(paramActivityClientRecord.activity, localException)) {}
        throw new RuntimeException("Failure delivering result " + localResultInfo + " to activity " + paramActivityClientRecord.intent.getComponent().toShortString() + ": " + localException.toString(), localException);
      }
    }
  }
  
  private native void dumpGraphicsInfo(FileDescriptor paramFileDescriptor);
  
  private void flushDisplayMetricsLocked()
  {
    this.mDefaultDisplayMetrics.clear();
  }
  
  public static Intent getIntentBeingBroadcast()
  {
    return (Intent)sCurrentBroadcastIntent.get();
  }
  
  private LoadedApk getPackageInfo(ApplicationInfo paramApplicationInfo, CompatibilityInfo paramCompatibilityInfo, ClassLoader paramClassLoader, boolean paramBoolean1, boolean paramBoolean2)
  {
    HashMap localHashMap = this.mPackages;
    if (paramBoolean2) {}
    for (;;)
    {
      try
      {
        WeakReference localWeakReference = (WeakReference)this.mPackages.get(paramApplicationInfo.packageName);
        if (localWeakReference != null)
        {
          localLoadedApk = (LoadedApk)localWeakReference.get();
          if ((localLoadedApk == null) || ((localLoadedApk.mResources != null) && (!localLoadedApk.mResources.getAssets().isUpToDate())))
          {
            if ((!paramBoolean2) || ((0x4 & paramApplicationInfo.flags) == 0)) {
              break label196;
            }
            bool = true;
            localLoadedApk = new LoadedApk(this, paramApplicationInfo, paramCompatibilityInfo, this, paramClassLoader, paramBoolean1, bool);
            if (paramBoolean2) {
              this.mPackages.put(paramApplicationInfo.packageName, new WeakReference(localLoadedApk));
            }
          }
          else
          {
            return localLoadedApk;
            localWeakReference = (WeakReference)this.mResourcePackages.get(paramApplicationInfo.packageName);
            continue;
          }
          this.mResourcePackages.put(paramApplicationInfo.packageName, new WeakReference(localLoadedApk));
          continue;
        }
        LoadedApk localLoadedApk = null;
      }
      finally {}
      continue;
      label196:
      boolean bool = false;
    }
  }
  
  public static IPackageManager getPackageManager()
  {
    if (sPackageManager != null) {
      return sPackageManager;
    }
    sPackageManager = IPackageManager.Stub.asInterface(ServiceManager.getService("package"));
    return sPackageManager;
  }
  
  /* Error */
  private void handleBindApplication(AppBindData paramAppBindData)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: putfield 704	android/app/ActivityThread:mBoundApplication	Landroid/app/ActivityThread$AppBindData;
    //   5: aload_0
    //   6: new 237	android/content/res/Configuration
    //   9: dup
    //   10: aload_1
    //   11: getfield 835	android/app/ActivityThread$AppBindData:config	Landroid/content/res/Configuration;
    //   14: invokespecial 838	android/content/res/Configuration:<init>	(Landroid/content/res/Configuration;)V
    //   17: putfield 840	android/app/ActivityThread:mConfiguration	Landroid/content/res/Configuration;
    //   20: aload_0
    //   21: new 237	android/content/res/Configuration
    //   24: dup
    //   25: aload_1
    //   26: getfield 835	android/app/ActivityThread$AppBindData:config	Landroid/content/res/Configuration;
    //   29: invokespecial 838	android/content/res/Configuration:<init>	(Landroid/content/res/Configuration;)V
    //   32: putfield 842	android/app/ActivityThread:mCompatConfiguration	Landroid/content/res/Configuration;
    //   35: aload_0
    //   36: new 844	android/app/ActivityThread$Profiler
    //   39: dup
    //   40: invokespecial 845	android/app/ActivityThread$Profiler:<init>	()V
    //   43: putfield 847	android/app/ActivityThread:mProfiler	Landroid/app/ActivityThread$Profiler;
    //   46: aload_0
    //   47: getfield 847	android/app/ActivityThread:mProfiler	Landroid/app/ActivityThread$Profiler;
    //   50: aload_1
    //   51: getfield 850	android/app/ActivityThread$AppBindData:initProfileFile	Ljava/lang/String;
    //   54: putfield 853	android/app/ActivityThread$Profiler:profileFile	Ljava/lang/String;
    //   57: aload_0
    //   58: getfield 847	android/app/ActivityThread:mProfiler	Landroid/app/ActivityThread$Profiler;
    //   61: aload_1
    //   62: getfield 857	android/app/ActivityThread$AppBindData:initProfileFd	Landroid/os/ParcelFileDescriptor;
    //   65: putfield 860	android/app/ActivityThread$Profiler:profileFd	Landroid/os/ParcelFileDescriptor;
    //   68: aload_0
    //   69: getfield 847	android/app/ActivityThread:mProfiler	Landroid/app/ActivityThread$Profiler;
    //   72: aload_1
    //   73: getfield 863	android/app/ActivityThread$AppBindData:initAutoStopProfiler	Z
    //   76: putfield 866	android/app/ActivityThread$Profiler:autoStopProfiler	Z
    //   79: aload_1
    //   80: getfield 709	android/app/ActivityThread$AppBindData:processName	Ljava/lang/String;
    //   83: invokestatic 872	android/os/Process:setArgV0	(Ljava/lang/String;)V
    //   86: aload_1
    //   87: getfield 709	android/app/ActivityThread$AppBindData:processName	Ljava/lang/String;
    //   90: invokestatic 429	android/os/UserHandle:myUserId	()I
    //   93: invokestatic 435	android/ddm/DdmHandleAppName:setAppName	(Ljava/lang/String;I)V
    //   96: aload_1
    //   97: getfield 875	android/app/ActivityThread$AppBindData:persistent	Z
    //   100: ifeq +13 -> 113
    //   103: invokestatic 880	android/app/ActivityManager:isHighEndGfx	()Z
    //   106: ifne +7 -> 113
    //   109: iconst_0
    //   110: invokestatic 885	android/view/HardwareRenderer:disable	(Z)V
    //   113: aload_0
    //   114: getfield 847	android/app/ActivityThread:mProfiler	Landroid/app/ActivityThread$Profiler;
    //   117: getfield 860	android/app/ActivityThread$Profiler:profileFd	Landroid/os/ParcelFileDescriptor;
    //   120: ifnull +10 -> 130
    //   123: aload_0
    //   124: getfield 847	android/app/ActivityThread:mProfiler	Landroid/app/ActivityThread$Profiler;
    //   127: invokevirtual 888	android/app/ActivityThread$Profiler:startProfiling	()V
    //   130: aload_1
    //   131: getfield 892	android/app/ActivityThread$AppBindData:appInfo	Landroid/content/pm/ApplicationInfo;
    //   134: getfield 895	android/content/pm/ApplicationInfo:targetSdkVersion	I
    //   137: bipush 12
    //   139: if_icmpgt +9 -> 148
    //   142: getstatic 901	android/os/AsyncTask:THREAD_POOL_EXECUTOR	Ljava/util/concurrent/Executor;
    //   145: invokestatic 905	android/os/AsyncTask:setDefaultExecutor	(Ljava/util/concurrent/Executor;)V
    //   148: aconst_null
    //   149: invokestatic 911	java/util/TimeZone:setDefault	(Ljava/util/TimeZone;)V
    //   152: aload_1
    //   153: getfield 835	android/app/ActivityThread$AppBindData:config	Landroid/content/res/Configuration;
    //   156: getfield 915	android/content/res/Configuration:locale	Ljava/util/Locale;
    //   159: invokestatic 920	java/util/Locale:setDefault	(Ljava/util/Locale;)V
    //   162: aload_0
    //   163: aload_1
    //   164: getfield 835	android/app/ActivityThread$AppBindData:config	Landroid/content/res/Configuration;
    //   167: aload_1
    //   168: getfield 923	android/app/ActivityThread$AppBindData:compatInfo	Landroid/content/res/CompatibilityInfo;
    //   171: invokevirtual 927	android/app/ActivityThread:applyConfigurationToResourcesLocked	(Landroid/content/res/Configuration;Landroid/content/res/CompatibilityInfo;)Z
    //   174: pop
    //   175: aload_0
    //   176: aload_1
    //   177: getfield 835	android/app/ActivityThread$AppBindData:config	Landroid/content/res/Configuration;
    //   180: getfield 930	android/content/res/Configuration:densityDpi	I
    //   183: putfield 932	android/app/ActivityThread:mCurDefaultDisplayDpi	I
    //   186: aload_0
    //   187: aload_0
    //   188: getfield 932	android/app/ActivityThread:mCurDefaultDisplayDpi	I
    //   191: invokevirtual 936	android/app/ActivityThread:applyCompatConfiguration	(I)Landroid/content/res/Configuration;
    //   194: pop
    //   195: aload_1
    //   196: aload_0
    //   197: aload_1
    //   198: getfield 892	android/app/ActivityThread$AppBindData:appInfo	Landroid/content/pm/ApplicationInfo;
    //   201: aload_1
    //   202: getfield 923	android/app/ActivityThread$AppBindData:compatInfo	Landroid/content/res/CompatibilityInfo;
    //   205: invokevirtual 940	android/app/ActivityThread:getPackageInfoNoCheck	(Landroid/content/pm/ApplicationInfo;Landroid/content/res/CompatibilityInfo;)Landroid/app/LoadedApk;
    //   208: putfield 943	android/app/ActivityThread$AppBindData:info	Landroid/app/LoadedApk;
    //   211: sipush 8192
    //   214: aload_1
    //   215: getfield 892	android/app/ActivityThread$AppBindData:appInfo	Landroid/content/pm/ApplicationInfo;
    //   218: getfield 803	android/content/pm/ApplicationInfo:flags	I
    //   221: iand
    //   222: ifne +14 -> 236
    //   225: aload_0
    //   226: iconst_1
    //   227: putfield 945	android/app/ActivityThread:mDensityCompatMode	Z
    //   230: sipush 160
    //   233: invokestatic 948	android/graphics/Bitmap:setDefaultDensity	(I)V
    //   236: aload_0
    //   237: invokespecial 951	android/app/ActivityThread:updateDefaultDensity	()V
    //   240: new 481	android/app/ContextImpl
    //   243: dup
    //   244: invokespecial 482	android/app/ContextImpl:<init>	()V
    //   247: astore 4
    //   249: aload 4
    //   251: aload_1
    //   252: getfield 943	android/app/ActivityThread$AppBindData:info	Landroid/app/LoadedApk;
    //   255: aconst_null
    //   256: aload_0
    //   257: invokevirtual 494	android/app/ContextImpl:init	(Landroid/app/LoadedApk;Landroid/os/IBinder;Landroid/app/ActivityThread;)V
    //   260: invokestatic 954	android/os/Process:isIsolated	()Z
    //   263: ifne +37 -> 300
    //   266: aload 4
    //   268: invokevirtual 958	android/app/ContextImpl:getCacheDir	()Ljava/io/File;
    //   271: astore 30
    //   273: aload 30
    //   275: ifnull +251 -> 526
    //   278: ldc_w 960
    //   281: aload 30
    //   283: invokevirtual 965	java/io/File:getAbsolutePath	()Ljava/lang/String;
    //   286: invokestatic 971	java/lang/System:setProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   289: pop
    //   290: aload_0
    //   291: aload_1
    //   292: getfield 943	android/app/ActivityThread$AppBindData:info	Landroid/app/LoadedApk;
    //   295: aload 30
    //   297: invokespecial 975	android/app/ActivityThread:setupGraphicsSupport	(Landroid/app/LoadedApk;Ljava/io/File;)V
    //   300: sipush 129
    //   303: aload_1
    //   304: getfield 892	android/app/ActivityThread$AppBindData:appInfo	Landroid/content/pm/ApplicationInfo;
    //   307: getfield 803	android/content/pm/ApplicationInfo:flags	I
    //   310: iand
    //   311: ifeq +7 -> 318
    //   314: invokestatic 980	android/os/StrictMode:conditionallyEnableDebugLogging	()Z
    //   317: pop
    //   318: aload_1
    //   319: getfield 892	android/app/ActivityThread$AppBindData:appInfo	Landroid/content/pm/ApplicationInfo;
    //   322: getfield 895	android/content/pm/ApplicationInfo:targetSdkVersion	I
    //   325: bipush 9
    //   327: if_icmple +6 -> 333
    //   330: invokestatic 983	android/os/StrictMode:enableDeathOnNetwork	()V
    //   333: aload_1
    //   334: getfield 986	android/app/ActivityThread$AppBindData:debugMode	I
    //   337: ifeq +87 -> 424
    //   340: sipush 8100
    //   343: invokestatic 991	android/os/Debug:changeDebugPort	(I)V
    //   346: aload_1
    //   347: getfield 986	android/app/ActivityThread$AppBindData:debugMode	I
    //   350: iconst_2
    //   351: if_icmpne +187 -> 538
    //   354: ldc 31
    //   356: new 513	java/lang/StringBuilder
    //   359: dup
    //   360: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   363: ldc_w 993
    //   366: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   369: aload_1
    //   370: getfield 943	android/app/ActivityThread$AppBindData:info	Landroid/app/LoadedApk;
    //   373: invokevirtual 996	android/app/LoadedApk:getPackageName	()Ljava/lang/String;
    //   376: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   379: ldc_w 998
    //   382: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   385: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   388: invokestatic 1004	android/util/Slog:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   391: pop
    //   392: invokestatic 450	android/app/ActivityManagerNative:getDefault	()Landroid/app/IActivityManager;
    //   395: astore 26
    //   397: aload 26
    //   399: aload_0
    //   400: getfield 157	android/app/ActivityThread:mAppThread	Landroid/app/ActivityThread$ApplicationThread;
    //   403: iconst_1
    //   404: invokeinterface 1008 3 0
    //   409: invokestatic 1011	android/os/Debug:waitForDebugger	()V
    //   412: aload 26
    //   414: aload_0
    //   415: getfield 157	android/app/ActivityThread:mAppThread	Landroid/app/ActivityThread$ApplicationThread;
    //   418: iconst_0
    //   419: invokeinterface 1008 3 0
    //   424: aload_1
    //   425: getfield 1014	android/app/ActivityThread$AppBindData:enableOpenGlTrace	Z
    //   428: ifeq +6 -> 434
    //   431: invokestatic 1019	android/opengl/GLUtils:enableTracing	()V
    //   434: ldc_w 1021
    //   437: invokestatic 824	android/os/ServiceManager:getService	(Ljava/lang/String;)Landroid/os/IBinder;
    //   440: astore 5
    //   442: aload 5
    //   444: ifnull +20 -> 464
    //   447: aload 5
    //   449: invokestatic 1026	android/net/IConnectivityManager$Stub:asInterface	(Landroid/os/IBinder;)Landroid/net/IConnectivityManager;
    //   452: astore 22
    //   454: aload 22
    //   456: invokeinterface 1032 1 0
    //   461: invokestatic 1038	android/net/Proxy:setHttpProxySystemProperty	(Landroid/net/ProxyProperties;)V
    //   464: aload_1
    //   465: getfield 1042	android/app/ActivityThread$AppBindData:instrumentationName	Landroid/content/ComponentName;
    //   468: ifnull +546 -> 1014
    //   471: aload 4
    //   473: invokevirtual 1045	android/app/ContextImpl:getPackageManager	()Landroid/content/pm/PackageManager;
    //   476: aload_1
    //   477: getfield 1042	android/app/ActivityThread$AppBindData:instrumentationName	Landroid/content/ComponentName;
    //   480: iconst_0
    //   481: invokevirtual 1051	android/content/pm/PackageManager:getInstrumentationInfo	(Landroid/content/ComponentName;I)Landroid/content/pm/InstrumentationInfo;
    //   484: astore 21
    //   486: aload 21
    //   488: astore 14
    //   490: aload 14
    //   492: ifnonnull +87 -> 579
    //   495: new 511	java/lang/RuntimeException
    //   498: dup
    //   499: new 513	java/lang/StringBuilder
    //   502: dup
    //   503: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   506: ldc_w 1053
    //   509: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   512: aload_1
    //   513: getfield 1042	android/app/ActivityThread$AppBindData:instrumentationName	Landroid/content/ComponentName;
    //   516: invokevirtual 764	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   519: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   522: invokespecial 1055	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   525: athrow
    //   526: ldc 31
    //   528: ldc_w 1057
    //   531: invokestatic 1062	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   534: pop
    //   535: goto -235 -> 300
    //   538: ldc 31
    //   540: new 513	java/lang/StringBuilder
    //   543: dup
    //   544: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   547: ldc_w 993
    //   550: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   553: aload_1
    //   554: getfield 943	android/app/ActivityThread$AppBindData:info	Landroid/app/LoadedApk;
    //   557: invokevirtual 996	android/app/LoadedApk:getPackageName	()Ljava/lang/String;
    //   560: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   563: ldc_w 1064
    //   566: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   569: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   572: invokestatic 1004	android/util/Slog:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   575: pop
    //   576: goto -152 -> 424
    //   579: aload_0
    //   580: aload 14
    //   582: getfield 1069	android/content/pm/InstrumentationInfo:sourceDir	Ljava/lang/String;
    //   585: putfield 190	android/app/ActivityThread:mInstrumentationAppDir	Ljava/lang/String;
    //   588: aload_0
    //   589: aload 14
    //   591: getfield 1072	android/content/pm/InstrumentationInfo:nativeLibraryDir	Ljava/lang/String;
    //   594: putfield 192	android/app/ActivityThread:mInstrumentationAppLibraryDir	Ljava/lang/String;
    //   597: aload_0
    //   598: aload 14
    //   600: getfield 779	android/content/pm/PackageItemInfo:packageName	Ljava/lang/String;
    //   603: putfield 194	android/app/ActivityThread:mInstrumentationAppPackage	Ljava/lang/String;
    //   606: aload_0
    //   607: aload_1
    //   608: getfield 943	android/app/ActivityThread$AppBindData:info	Landroid/app/LoadedApk;
    //   611: invokevirtual 1075	android/app/LoadedApk:getAppDir	()Ljava/lang/String;
    //   614: putfield 196	android/app/ActivityThread:mInstrumentedAppDir	Ljava/lang/String;
    //   617: aload_0
    //   618: aload_1
    //   619: getfield 943	android/app/ActivityThread$AppBindData:info	Landroid/app/LoadedApk;
    //   622: invokevirtual 1078	android/app/LoadedApk:getLibDir	()Ljava/lang/String;
    //   625: putfield 198	android/app/ActivityThread:mInstrumentedAppLibraryDir	Ljava/lang/String;
    //   628: new 800	android/content/pm/ApplicationInfo
    //   631: dup
    //   632: invokespecial 1079	android/content/pm/ApplicationInfo:<init>	()V
    //   635: astore 15
    //   637: aload 15
    //   639: aload 14
    //   641: getfield 779	android/content/pm/PackageItemInfo:packageName	Ljava/lang/String;
    //   644: putfield 779	android/content/pm/PackageItemInfo:packageName	Ljava/lang/String;
    //   647: aload 15
    //   649: aload 14
    //   651: getfield 1069	android/content/pm/InstrumentationInfo:sourceDir	Ljava/lang/String;
    //   654: putfield 1080	android/content/pm/ApplicationInfo:sourceDir	Ljava/lang/String;
    //   657: aload 15
    //   659: aload 14
    //   661: getfield 1083	android/content/pm/InstrumentationInfo:publicSourceDir	Ljava/lang/String;
    //   664: putfield 1084	android/content/pm/ApplicationInfo:publicSourceDir	Ljava/lang/String;
    //   667: aload 15
    //   669: aload 14
    //   671: getfield 1087	android/content/pm/InstrumentationInfo:dataDir	Ljava/lang/String;
    //   674: putfield 1088	android/content/pm/ApplicationInfo:dataDir	Ljava/lang/String;
    //   677: aload 15
    //   679: aload 14
    //   681: getfield 1072	android/content/pm/InstrumentationInfo:nativeLibraryDir	Ljava/lang/String;
    //   684: putfield 1089	android/content/pm/ApplicationInfo:nativeLibraryDir	Ljava/lang/String;
    //   687: aload_0
    //   688: aload 15
    //   690: aload_1
    //   691: getfield 923	android/app/ActivityThread$AppBindData:compatInfo	Landroid/content/res/CompatibilityInfo;
    //   694: aload 4
    //   696: invokevirtual 1090	android/app/ContextImpl:getClassLoader	()Ljava/lang/ClassLoader;
    //   699: iconst_0
    //   700: iconst_1
    //   701: invokespecial 1092	android/app/ActivityThread:getPackageInfo	(Landroid/content/pm/ApplicationInfo;Landroid/content/res/CompatibilityInfo;Ljava/lang/ClassLoader;ZZ)Landroid/app/LoadedApk;
    //   704: astore 16
    //   706: new 481	android/app/ContextImpl
    //   709: dup
    //   710: invokespecial 482	android/app/ContextImpl:<init>	()V
    //   713: astore 17
    //   715: aload 17
    //   717: aload 16
    //   719: aconst_null
    //   720: aload_0
    //   721: invokevirtual 494	android/app/ContextImpl:init	(Landroid/app/LoadedApk;Landroid/os/IBinder;Landroid/app/ActivityThread;)V
    //   724: aload_0
    //   725: aload 17
    //   727: invokevirtual 1090	android/app/ContextImpl:getClassLoader	()Ljava/lang/ClassLoader;
    //   730: aload_1
    //   731: getfield 1042	android/app/ActivityThread$AppBindData:instrumentationName	Landroid/content/ComponentName;
    //   734: invokevirtual 1095	android/content/ComponentName:getClassName	()Ljava/lang/String;
    //   737: invokevirtual 1101	java/lang/ClassLoader:loadClass	(Ljava/lang/String;)Ljava/lang/Class;
    //   740: invokevirtual 1104	java/lang/Class:newInstance	()Ljava/lang/Object;
    //   743: checkcast 476	android/app/Instrumentation
    //   746: putfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   749: aload_0
    //   750: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   753: aload_0
    //   754: aload 17
    //   756: aload 4
    //   758: new 687	android/content/ComponentName
    //   761: dup
    //   762: aload 14
    //   764: getfield 779	android/content/pm/PackageItemInfo:packageName	Ljava/lang/String;
    //   767: aload 14
    //   769: getfield 1107	android/content/pm/PackageItemInfo:name	Ljava/lang/String;
    //   772: invokespecial 1110	android/content/ComponentName:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   775: aload_1
    //   776: getfield 1114	android/app/ActivityThread$AppBindData:instrumentationWatcher	Landroid/app/IInstrumentationWatcher;
    //   779: invokevirtual 1117	android/app/Instrumentation:init	(Landroid/app/ActivityThread;Landroid/content/Context;Landroid/content/Context;Landroid/content/ComponentName;Landroid/app/IInstrumentationWatcher;)V
    //   782: aload_0
    //   783: getfield 847	android/app/ActivityThread:mProfiler	Landroid/app/ActivityThread$Profiler;
    //   786: getfield 853	android/app/ActivityThread$Profiler:profileFile	Ljava/lang/String;
    //   789: ifnull +65 -> 854
    //   792: aload 14
    //   794: getfield 1120	android/content/pm/InstrumentationInfo:handleProfiling	Z
    //   797: ifne +57 -> 854
    //   800: aload_0
    //   801: getfield 847	android/app/ActivityThread:mProfiler	Landroid/app/ActivityThread$Profiler;
    //   804: getfield 860	android/app/ActivityThread$Profiler:profileFd	Landroid/os/ParcelFileDescriptor;
    //   807: ifnonnull +47 -> 854
    //   810: aload_0
    //   811: getfield 847	android/app/ActivityThread:mProfiler	Landroid/app/ActivityThread$Profiler;
    //   814: iconst_1
    //   815: putfield 1123	android/app/ActivityThread$Profiler:handlingProfiling	Z
    //   818: new 962	java/io/File
    //   821: dup
    //   822: aload_0
    //   823: getfield 847	android/app/ActivityThread:mProfiler	Landroid/app/ActivityThread$Profiler;
    //   826: getfield 853	android/app/ActivityThread$Profiler:profileFile	Ljava/lang/String;
    //   829: invokespecial 1124	java/io/File:<init>	(Ljava/lang/String;)V
    //   832: astore 19
    //   834: aload 19
    //   836: invokevirtual 1127	java/io/File:getParentFile	()Ljava/io/File;
    //   839: invokevirtual 1130	java/io/File:mkdirs	()Z
    //   842: pop
    //   843: aload 19
    //   845: invokevirtual 1131	java/io/File:toString	()Ljava/lang/String;
    //   848: ldc_w 1132
    //   851: invokestatic 1135	android/os/Debug:startMethodTracing	(Ljava/lang/String;I)V
    //   854: ldc_w 1136
    //   857: aload_1
    //   858: getfield 892	android/app/ActivityThread$AppBindData:appInfo	Landroid/content/pm/ApplicationInfo;
    //   861: getfield 803	android/content/pm/ApplicationInfo:flags	I
    //   864: iand
    //   865: ifeq +9 -> 874
    //   868: invokestatic 1142	dalvik/system/VMRuntime:getRuntime	()Ldalvik/system/VMRuntime;
    //   871: invokevirtual 1145	dalvik/system/VMRuntime:clearGrowthLimit	()V
    //   874: invokestatic 1149	android/os/StrictMode:allowThreadDiskWrites	()Landroid/os/StrictMode$ThreadPolicy;
    //   877: astore 6
    //   879: aload_1
    //   880: getfield 943	android/app/ActivityThread$AppBindData:info	Landroid/app/LoadedApk;
    //   883: aload_1
    //   884: getfield 1152	android/app/ActivityThread$AppBindData:restrictedBackupMode	Z
    //   887: aconst_null
    //   888: invokevirtual 1156	android/app/LoadedApk:makeApplication	(ZLandroid/app/Instrumentation;)Landroid/app/Application;
    //   891: astore 8
    //   893: aload_0
    //   894: aload 8
    //   896: putfield 506	android/app/ActivityThread:mInitialApplication	Landroid/app/Application;
    //   899: aload_1
    //   900: getfield 1152	android/app/ActivityThread$AppBindData:restrictedBackupMode	Z
    //   903: ifne +36 -> 939
    //   906: aload_1
    //   907: getfield 1160	android/app/ActivityThread$AppBindData:providers	Ljava/util/List;
    //   910: astore 11
    //   912: aload 11
    //   914: ifnull +25 -> 939
    //   917: aload_0
    //   918: aload 8
    //   920: aload 11
    //   922: invokespecial 1164	android/app/ActivityThread:installContentProviders	(Landroid/content/Context;Ljava/util/List;)V
    //   925: aload_0
    //   926: getfield 170	android/app/ActivityThread:mH	Landroid/app/ActivityThread$H;
    //   929: sipush 132
    //   932: ldc2_w 1165
    //   935: invokevirtual 1170	android/app/ActivityThread$H:sendEmptyMessageDelayed	(IJ)Z
    //   938: pop
    //   939: aload_0
    //   940: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   943: aload_1
    //   944: getfield 1173	android/app/ActivityThread$AppBindData:instrumentationArgs	Landroid/os/Bundle;
    //   947: invokevirtual 1175	android/app/Instrumentation:onCreate	(Landroid/os/Bundle;)V
    //   950: aload_0
    //   951: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   954: aload 8
    //   956: invokevirtual 1179	android/app/Instrumentation:callApplicationOnCreate	(Landroid/app/Application;)V
    //   959: aload 6
    //   961: invokestatic 1183	android/os/StrictMode:setThreadPolicy	(Landroid/os/StrictMode$ThreadPolicy;)V
    //   964: return
    //   965: astore 18
    //   967: new 511	java/lang/RuntimeException
    //   970: dup
    //   971: new 513	java/lang/StringBuilder
    //   974: dup
    //   975: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   978: ldc_w 1185
    //   981: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   984: aload_1
    //   985: getfield 1042	android/app/ActivityThread$AppBindData:instrumentationName	Landroid/content/ComponentName;
    //   988: invokevirtual 764	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   991: ldc_w 692
    //   994: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   997: aload 18
    //   999: invokevirtual 524	java/lang/Exception:toString	()Ljava/lang/String;
    //   1002: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1005: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1008: aload 18
    //   1010: invokespecial 528	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   1013: athrow
    //   1014: aload_0
    //   1015: new 476	android/app/Instrumentation
    //   1018: dup
    //   1019: invokespecial 477	android/app/Instrumentation:<init>	()V
    //   1022: putfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   1025: goto -171 -> 854
    //   1028: astore 9
    //   1030: new 511	java/lang/RuntimeException
    //   1033: dup
    //   1034: new 513	java/lang/StringBuilder
    //   1037: dup
    //   1038: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   1041: ldc_w 1187
    //   1044: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1047: aload_1
    //   1048: getfield 1042	android/app/ActivityThread$AppBindData:instrumentationName	Landroid/content/ComponentName;
    //   1051: invokevirtual 764	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1054: ldc_w 692
    //   1057: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1060: aload 9
    //   1062: invokevirtual 524	java/lang/Exception:toString	()Ljava/lang/String;
    //   1065: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1068: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1071: aload 9
    //   1073: invokespecial 528	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   1076: athrow
    //   1077: astore 7
    //   1079: aload 6
    //   1081: invokestatic 1183	android/os/StrictMode:setThreadPolicy	(Landroid/os/StrictMode$ThreadPolicy;)V
    //   1084: aload 7
    //   1086: athrow
    //   1087: astore 10
    //   1089: aload_0
    //   1090: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   1093: aload 8
    //   1095: aload 10
    //   1097: invokevirtual 673	android/app/Instrumentation:onException	(Ljava/lang/Object;Ljava/lang/Throwable;)Z
    //   1100: ifne -141 -> 959
    //   1103: new 511	java/lang/RuntimeException
    //   1106: dup
    //   1107: new 513	java/lang/StringBuilder
    //   1110: dup
    //   1111: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   1114: ldc_w 1189
    //   1117: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1120: aload 8
    //   1122: invokevirtual 564	java/lang/Object:getClass	()Ljava/lang/Class;
    //   1125: invokevirtual 569	java/lang/Class:getName	()Ljava/lang/String;
    //   1128: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1131: ldc_w 692
    //   1134: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1137: aload 10
    //   1139: invokevirtual 524	java/lang/Exception:toString	()Ljava/lang/String;
    //   1142: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1145: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1148: aload 10
    //   1150: invokespecial 528	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   1153: athrow
    //   1154: astore 13
    //   1156: aconst_null
    //   1157: astore 14
    //   1159: goto -669 -> 490
    //   1162: astore 23
    //   1164: goto -700 -> 464
    //   1167: astore 28
    //   1169: goto -745 -> 424
    //   1172: astore 27
    //   1174: goto -765 -> 409
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	1177	0	this	ActivityThread
    //   0	1177	1	paramAppBindData	AppBindData
    //   247	510	4	localContextImpl1	ContextImpl
    //   440	8	5	localIBinder	IBinder
    //   877	203	6	localThreadPolicy	StrictMode.ThreadPolicy
    //   1077	8	7	localObject	Object
    //   891	230	8	localApplication	Application
    //   1028	44	9	localException1	Exception
    //   1087	62	10	localException2	Exception
    //   910	11	11	localList	List
    //   1154	1	13	localNameNotFoundException	PackageManager.NameNotFoundException
    //   488	670	14	localInstrumentationInfo1	android.content.pm.InstrumentationInfo
    //   635	54	15	localApplicationInfo	ApplicationInfo
    //   704	14	16	localLoadedApk	LoadedApk
    //   713	42	17	localContextImpl2	ContextImpl
    //   965	44	18	localException3	Exception
    //   832	12	19	localFile1	File
    //   484	3	21	localInstrumentationInfo2	android.content.pm.InstrumentationInfo
    //   452	3	22	localIConnectivityManager	android.net.IConnectivityManager
    //   1162	1	23	localRemoteException1	RemoteException
    //   395	18	26	localIActivityManager	IActivityManager
    //   1172	1	27	localRemoteException2	RemoteException
    //   1167	1	28	localRemoteException3	RemoteException
    //   271	25	30	localFile2	File
    // Exception table:
    //   from	to	target	type
    //   724	749	965	java/lang/Exception
    //   939	950	1028	java/lang/Exception
    //   879	912	1077	finally
    //   917	939	1077	finally
    //   939	950	1077	finally
    //   950	959	1077	finally
    //   1030	1077	1077	finally
    //   1089	1154	1077	finally
    //   950	959	1087	java/lang/Exception
    //   471	486	1154	android/content/pm/PackageManager$NameNotFoundException
    //   454	464	1162	android/os/RemoteException
    //   412	424	1167	android/os/RemoteException
    //   397	409	1172	android/os/RemoteException
  }
  
  /* Error */
  private void handleBindService(BindServiceData paramBindServiceData)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 181	android/app/ActivityThread:mServices	Ljava/util/HashMap;
    //   4: aload_1
    //   5: getfield 1192	android/app/ActivityThread$BindServiceData:token	Landroid/os/IBinder;
    //   8: invokevirtual 782	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   11: checkcast 1194	android/app/Service
    //   14: astore_2
    //   15: aload_2
    //   16: ifnull +151 -> 167
    //   19: aload_1
    //   20: getfield 1195	android/app/ActivityThread$BindServiceData:intent	Landroid/content/Intent;
    //   23: aload_2
    //   24: invokevirtual 1196	android/app/Service:getClassLoader	()Ljava/lang/ClassLoader;
    //   27: invokevirtual 727	android/content/Intent:setExtrasClassLoader	(Ljava/lang/ClassLoader;)V
    //   30: aload_1
    //   31: getfield 1199	android/app/ActivityThread$BindServiceData:rebind	Z
    //   34: ifne +36 -> 70
    //   37: aload_2
    //   38: aload_1
    //   39: getfield 1195	android/app/ActivityThread$BindServiceData:intent	Landroid/content/Intent;
    //   42: invokevirtual 1203	android/app/Service:onBind	(Landroid/content/Intent;)Landroid/os/IBinder;
    //   45: astore 5
    //   47: invokestatic 450	android/app/ActivityManagerNative:getDefault	()Landroid/app/IActivityManager;
    //   50: aload_1
    //   51: getfield 1192	android/app/ActivityThread$BindServiceData:token	Landroid/os/IBinder;
    //   54: aload_1
    //   55: getfield 1195	android/app/ActivityThread$BindServiceData:intent	Landroid/content/Intent;
    //   58: aload 5
    //   60: invokeinterface 1207 4 0
    //   65: aload_0
    //   66: invokevirtual 1210	android/app/ActivityThread:ensureJitEnabled	()V
    //   69: return
    //   70: aload_2
    //   71: aload_1
    //   72: getfield 1195	android/app/ActivityThread$BindServiceData:intent	Landroid/content/Intent;
    //   75: invokevirtual 1214	android/app/Service:onRebind	(Landroid/content/Intent;)V
    //   78: invokestatic 450	android/app/ActivityManagerNative:getDefault	()Landroid/app/IActivityManager;
    //   81: aload_1
    //   82: getfield 1192	android/app/ActivityThread$BindServiceData:token	Landroid/os/IBinder;
    //   85: iconst_0
    //   86: iconst_0
    //   87: iconst_0
    //   88: invokeinterface 1218 5 0
    //   93: goto -28 -> 65
    //   96: astore 4
    //   98: return
    //   99: astore_3
    //   100: aload_0
    //   101: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   104: aload_2
    //   105: aload_3
    //   106: invokevirtual 673	android/app/Instrumentation:onException	(Ljava/lang/Object;Ljava/lang/Throwable;)Z
    //   109: ifne +58 -> 167
    //   112: new 511	java/lang/RuntimeException
    //   115: dup
    //   116: new 513	java/lang/StringBuilder
    //   119: dup
    //   120: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   123: ldc_w 1220
    //   126: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   129: aload_2
    //   130: invokevirtual 764	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   133: ldc_w 1222
    //   136: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   139: aload_1
    //   140: getfield 1195	android/app/ActivityThread$BindServiceData:intent	Landroid/content/Intent;
    //   143: invokevirtual 764	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   146: ldc_w 692
    //   149: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   152: aload_3
    //   153: invokevirtual 524	java/lang/Exception:toString	()Ljava/lang/String;
    //   156: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   159: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   162: aload_3
    //   163: invokespecial 528	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   166: athrow
    //   167: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	168	0	this	ActivityThread
    //   0	168	1	paramBindServiceData	BindServiceData
    //   14	116	2	localService	Service
    //   99	64	3	localException	Exception
    //   96	1	4	localRemoteException	RemoteException
    //   45	14	5	localIBinder	IBinder
    // Exception table:
    //   from	to	target	type
    //   30	65	96	android/os/RemoteException
    //   65	69	96	android/os/RemoteException
    //   70	93	96	android/os/RemoteException
    //   19	30	99	java/lang/Exception
    //   30	65	99	java/lang/Exception
    //   65	69	99	java/lang/Exception
    //   70	93	99	java/lang/Exception
  }
  
  /* Error */
  private void handleCreateBackupAgent(CreateBackupAgentData paramCreateBackupAgentData)
  {
    // Byte code:
    //   0: invokestatic 1224	android/app/ActivityThread:getPackageManager	()Landroid/content/pm/IPackageManager;
    //   3: aload_1
    //   4: getfield 1227	android/app/ActivityThread$CreateBackupAgentData:appInfo	Landroid/content/pm/ApplicationInfo;
    //   7: getfield 779	android/content/pm/PackageItemInfo:packageName	Ljava/lang/String;
    //   10: iconst_0
    //   11: invokestatic 429	android/os/UserHandle:myUserId	()I
    //   14: invokeinterface 1232 4 0
    //   19: getfield 1237	android/content/pm/PackageInfo:applicationInfo	Landroid/content/pm/ApplicationInfo;
    //   22: getfield 1240	android/content/pm/ApplicationInfo:uid	I
    //   25: invokestatic 1243	android/os/Process:myUid	()I
    //   28: if_icmpeq +48 -> 76
    //   31: ldc 31
    //   33: new 513	java/lang/StringBuilder
    //   36: dup
    //   37: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   40: ldc_w 1245
    //   43: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   46: aload_1
    //   47: getfield 1227	android/app/ActivityThread$CreateBackupAgentData:appInfo	Landroid/content/pm/ApplicationInfo;
    //   50: getfield 779	android/content/pm/PackageItemInfo:packageName	Ljava/lang/String;
    //   53: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   56: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   59: invokestatic 1004	android/util/Slog:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   62: pop
    //   63: return
    //   64: astore_2
    //   65: ldc 31
    //   67: ldc_w 1247
    //   70: aload_2
    //   71: invokestatic 1250	android/util/Slog:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   74: pop
    //   75: return
    //   76: aload_0
    //   77: invokevirtual 1253	android/app/ActivityThread:unscheduleGcIdler	()V
    //   80: aload_0
    //   81: aload_1
    //   82: getfield 1227	android/app/ActivityThread$CreateBackupAgentData:appInfo	Landroid/content/pm/ApplicationInfo;
    //   85: aload_1
    //   86: getfield 1254	android/app/ActivityThread$CreateBackupAgentData:compatInfo	Landroid/content/res/CompatibilityInfo;
    //   89: invokevirtual 940	android/app/ActivityThread:getPackageInfoNoCheck	(Landroid/content/pm/ApplicationInfo;Landroid/content/res/CompatibilityInfo;)Landroid/app/LoadedApk;
    //   92: astore 4
    //   94: aload 4
    //   96: getfield 607	android/app/LoadedApk:mPackageName	Ljava/lang/String;
    //   99: astore 5
    //   101: aload 5
    //   103: ifnonnull +13 -> 116
    //   106: ldc 31
    //   108: ldc_w 1256
    //   111: invokestatic 1259	android/util/Slog:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   114: pop
    //   115: return
    //   116: aload_0
    //   117: getfield 188	android/app/ActivityThread:mBackupAgents	Ljava/util/HashMap;
    //   120: aload 5
    //   122: invokevirtual 782	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   125: ifnull +37 -> 162
    //   128: ldc 31
    //   130: new 513	java/lang/StringBuilder
    //   133: dup
    //   134: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   137: ldc_w 1261
    //   140: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   143: aload 5
    //   145: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: ldc_w 1263
    //   151: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   154: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   157: invokestatic 1259	android/util/Slog:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   160: pop
    //   161: return
    //   162: aload_1
    //   163: getfield 1227	android/app/ActivityThread$CreateBackupAgentData:appInfo	Landroid/content/pm/ApplicationInfo;
    //   166: getfield 1266	android/content/pm/ApplicationInfo:backupAgentName	Ljava/lang/String;
    //   169: astore 6
    //   171: aload 6
    //   173: ifnonnull +24 -> 197
    //   176: aload_1
    //   177: getfield 1269	android/app/ActivityThread$CreateBackupAgentData:backupMode	I
    //   180: iconst_1
    //   181: if_icmpeq +11 -> 192
    //   184: aload_1
    //   185: getfield 1269	android/app/ActivityThread$CreateBackupAgentData:backupMode	I
    //   188: iconst_3
    //   189: if_icmpne +8 -> 197
    //   192: ldc_w 1271
    //   195: astore 6
    //   197: aconst_null
    //   198: astore 7
    //   200: aload 4
    //   202: invokevirtual 1272	android/app/LoadedApk:getClassLoader	()Ljava/lang/ClassLoader;
    //   205: aload 6
    //   207: invokevirtual 1101	java/lang/ClassLoader:loadClass	(Ljava/lang/String;)Ljava/lang/Class;
    //   210: invokevirtual 1104	java/lang/Class:newInstance	()Ljava/lang/Object;
    //   213: checkcast 1274	android/app/backup/BackupAgent
    //   216: astore 12
    //   218: new 481	android/app/ContextImpl
    //   221: dup
    //   222: invokespecial 482	android/app/ContextImpl:<init>	()V
    //   225: astore 13
    //   227: aload 13
    //   229: aload 4
    //   231: aconst_null
    //   232: aload_0
    //   233: invokevirtual 494	android/app/ContextImpl:init	(Landroid/app/LoadedApk;Landroid/os/IBinder;Landroid/app/ActivityThread;)V
    //   236: aload 13
    //   238: aload 12
    //   240: invokevirtual 588	android/app/ContextImpl:setOuterContext	(Landroid/content/Context;)V
    //   243: aload 12
    //   245: aload 13
    //   247: invokevirtual 1276	android/app/backup/BackupAgent:attach	(Landroid/content/Context;)V
    //   250: aload 12
    //   252: invokevirtual 1277	android/app/backup/BackupAgent:onCreate	()V
    //   255: aload 12
    //   257: invokevirtual 1279	android/app/backup/BackupAgent:onBind	()Landroid/os/IBinder;
    //   260: astore 7
    //   262: aload_0
    //   263: getfield 188	android/app/ActivityThread:mBackupAgents	Ljava/util/HashMap;
    //   266: aload 5
    //   268: aload 12
    //   270: invokevirtual 812	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   273: pop
    //   274: invokestatic 450	android/app/ActivityManagerNative:getDefault	()Landroid/app/IActivityManager;
    //   277: aload 5
    //   279: aload 7
    //   281: invokeinterface 1283 3 0
    //   286: return
    //   287: astore 11
    //   289: return
    //   290: astore 8
    //   292: ldc 31
    //   294: new 513	java/lang/StringBuilder
    //   297: dup
    //   298: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   301: ldc_w 1285
    //   304: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   307: aload 8
    //   309: invokevirtual 764	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   312: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   315: invokestatic 1286	android/util/Slog:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   318: pop
    //   319: aload_1
    //   320: getfield 1269	android/app/ActivityThread$CreateBackupAgentData:backupMode	I
    //   323: iconst_2
    //   324: if_icmpeq -50 -> 274
    //   327: aload_1
    //   328: getfield 1269	android/app/ActivityThread$CreateBackupAgentData:backupMode	I
    //   331: iconst_3
    //   332: if_icmpeq -58 -> 274
    //   335: aload 8
    //   337: athrow
    //   338: astore 9
    //   340: new 511	java/lang/RuntimeException
    //   343: dup
    //   344: new 513	java/lang/StringBuilder
    //   347: dup
    //   348: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   351: ldc_w 1288
    //   354: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   357: aload 6
    //   359: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   362: ldc_w 692
    //   365: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   368: aload 9
    //   370: invokevirtual 524	java/lang/Exception:toString	()Ljava/lang/String;
    //   373: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   376: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   379: aload 9
    //   381: invokespecial 528	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   384: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	385	0	this	ActivityThread
    //   0	385	1	paramCreateBackupAgentData	CreateBackupAgentData
    //   64	7	2	localRemoteException1	RemoteException
    //   92	138	4	localLoadedApk	LoadedApk
    //   99	179	5	str1	String
    //   169	189	6	str2	String
    //   198	82	7	localIBinder	IBinder
    //   290	46	8	localException1	Exception
    //   338	42	9	localException2	Exception
    //   287	1	11	localRemoteException2	RemoteException
    //   216	53	12	localBackupAgent	BackupAgent
    //   225	21	13	localContextImpl	ContextImpl
    // Exception table:
    //   from	to	target	type
    //   0	63	64	android/os/RemoteException
    //   274	286	287	android/os/RemoteException
    //   200	274	290	java/lang/Exception
    //   274	286	338	java/lang/Exception
    //   292	338	338	java/lang/Exception
  }
  
  private void handleCreateService(CreateServiceData paramCreateServiceData)
  {
    unscheduleGcIdler();
    LoadedApk localLoadedApk = getPackageInfoNoCheck(paramCreateServiceData.info.applicationInfo, paramCreateServiceData.compatInfo);
    try
    {
      localService = (Service)localLoadedApk.getClassLoader().loadClass(paramCreateServiceData.info.name).newInstance();
    }
    catch (Exception localException1)
    {
      for (;;)
      {
        try
        {
          ContextImpl localContextImpl = new ContextImpl();
          localContextImpl.init(localLoadedApk, null, this);
          Application localApplication = localLoadedApk.makeApplication(false, this.mInstrumentation);
          localContextImpl.setOuterContext(localService);
          localService.attach(localContextImpl, this, paramCreateServiceData.info.name, paramCreateServiceData.token, localApplication, ActivityManagerNative.getDefault());
          localService.onCreate();
          this.mServices.put(paramCreateServiceData.token, localService);
        }
        catch (Exception localException2)
        {
          Service localService;
          boolean bool;
          if (!this.mInstrumentation.onException(localService, localException2)) {
            throw new RuntimeException("Unable to create service " + paramCreateServiceData.info.name + ": " + localException2.toString(), localException2);
          }
        }
        try
        {
          ActivityManagerNative.getDefault().serviceDoneExecuting(paramCreateServiceData.token, 0, 0, 0);
          return;
        }
        catch (RemoteException localRemoteException) {}
        localException1 = localException1;
        bool = this.mInstrumentation.onException(null, localException1);
        localService = null;
        if (!bool) {
          throw new RuntimeException("Unable to instantiate service " + paramCreateServiceData.info.name + ": " + localException1.toString(), localException1);
        }
      }
    }
  }
  
  private void handleDestroyActivity(IBinder paramIBinder, boolean paramBoolean1, int paramInt, boolean paramBoolean2)
  {
    ActivityClientRecord localActivityClientRecord = performDestroyActivity(paramIBinder, paramBoolean1, paramInt, paramBoolean2);
    WindowManager localWindowManager;
    View localView;
    IBinder localIBinder;
    if (localActivityClientRecord != null)
    {
      cleanUpPendingRemoveWindows(localActivityClientRecord);
      localWindowManager = localActivityClientRecord.activity.getWindowManager();
      localView = localActivityClientRecord.activity.mDecor;
      if (localView != null)
      {
        if (localActivityClientRecord.activity.mVisibleFromServer) {
          this.mNumVisibleActivities = (-1 + this.mNumVisibleActivities);
        }
        localIBinder = localView.getWindowToken();
        if (localActivityClientRecord.activity.mWindowAdded)
        {
          if (!localActivityClientRecord.onlyLocalRequest) {
            break label234;
          }
          localActivityClientRecord.mPendingRemoveWindow = localView;
          localActivityClientRecord.mPendingRemoveWindowManager = localWindowManager;
        }
      }
    }
    for (;;)
    {
      if ((localIBinder != null) && (localActivityClientRecord.mPendingRemoveWindow == null)) {
        WindowManagerGlobal.getInstance().closeAll(localIBinder, localActivityClientRecord.activity.getClass().getName(), "Activity");
      }
      localActivityClientRecord.activity.mDecor = null;
      if (localActivityClientRecord.mPendingRemoveWindow == null) {
        WindowManagerGlobal.getInstance().closeAll(paramIBinder, localActivityClientRecord.activity.getClass().getName(), "Activity");
      }
      Context localContext = localActivityClientRecord.activity.getBaseContext();
      if ((localContext instanceof ContextImpl)) {
        ((ContextImpl)localContext).scheduleFinalCleanup(localActivityClientRecord.activity.getClass().getName(), "Activity");
      }
      if (paramBoolean1) {}
      label234:
      try
      {
        ActivityManagerNative.getDefault().activityDestroyed(paramIBinder);
        return;
      }
      catch (RemoteException localRemoteException) {}
      localWindowManager.removeViewImmediate(localView);
    }
  }
  
  private void handleDestroyBackupAgent(CreateBackupAgentData paramCreateBackupAgentData)
  {
    String str = getPackageInfoNoCheck(paramCreateBackupAgentData.appInfo, paramCreateBackupAgentData.compatInfo).mPackageName;
    BackupAgent localBackupAgent = (BackupAgent)this.mBackupAgents.get(str);
    if (localBackupAgent != null) {
      try
      {
        localBackupAgent.onDestroy();
        this.mBackupAgents.remove(str);
        return;
      }
      catch (Exception localException)
      {
        for (;;)
        {
          Slog.w("ActivityThread", "Exception thrown in onDestroy by backup agent of " + paramCreateBackupAgentData.appInfo);
          localException.printStackTrace();
        }
      }
    }
    Slog.w("ActivityThread", "Attempt to destroy unknown backup agent " + paramCreateBackupAgentData);
  }
  
  private void handleDumpActivity(DumpComponentInfo paramDumpComponentInfo)
  {
    StrictMode.ThreadPolicy localThreadPolicy = StrictMode.allowThreadDiskWrites();
    try
    {
      ActivityClientRecord localActivityClientRecord = (ActivityClientRecord)this.mActivities.get(paramDumpComponentInfo.token);
      if ((localActivityClientRecord != null) && (localActivityClientRecord.activity != null))
      {
        PrintWriter localPrintWriter = new PrintWriter(new FileOutputStream(paramDumpComponentInfo.fd.getFileDescriptor()));
        localActivityClientRecord.activity.dump(paramDumpComponentInfo.prefix, paramDumpComponentInfo.fd.getFileDescriptor(), localPrintWriter, paramDumpComponentInfo.args);
        localPrintWriter.flush();
      }
      return;
    }
    finally
    {
      IoUtils.closeQuietly(paramDumpComponentInfo.fd);
      StrictMode.setThreadPolicy(localThreadPolicy);
    }
  }
  
  static final void handleDumpHeap(boolean paramBoolean, DumpHeapData paramDumpHeapData)
  {
    if (paramBoolean) {
      try
      {
        Debug.dumpHprofData(paramDumpHeapData.path, paramDumpHeapData.fd.getFileDescriptor());
        try
        {
          paramDumpHeapData.fd.close();
          throw ((Throwable)localObject);
          Debug.dumpNativeHeap(paramDumpHeapData.fd.getFileDescriptor());
          return;
        }
        catch (IOException localIOException1)
        {
          for (;;)
          {
            Slog.w("ActivityThread", "Failure closing profile fd", localIOException1);
          }
        }
      }
      catch (IOException localIOException2)
      {
        try
        {
          paramDumpHeapData.fd.close();
          return;
        }
        catch (IOException localIOException4)
        {
          for (;;)
          {
            String str1 = "ActivityThread";
            String str2 = "Failure closing profile fd";
          }
        }
        localIOException2 = localIOException2;
        Slog.w("ActivityThread", "Managed heap dump failed on path " + paramDumpHeapData.path + " -- can the process access this path?");
        try
        {
          paramDumpHeapData.fd.close();
          return;
        }
        catch (IOException localIOException3)
        {
          str1 = "ActivityThread";
          str2 = "Failure closing profile fd";
        }
        Slog.w(str1, str2, localIOException3);
        return;
      }
      finally {}
    }
  }
  
  private void handleDumpProvider(DumpComponentInfo paramDumpComponentInfo)
  {
    StrictMode.ThreadPolicy localThreadPolicy = StrictMode.allowThreadDiskWrites();
    try
    {
      ProviderClientRecord localProviderClientRecord = (ProviderClientRecord)this.mLocalProviders.get(paramDumpComponentInfo.token);
      if ((localProviderClientRecord != null) && (localProviderClientRecord.mLocalProvider != null))
      {
        PrintWriter localPrintWriter = new PrintWriter(new FileOutputStream(paramDumpComponentInfo.fd.getFileDescriptor()));
        localProviderClientRecord.mLocalProvider.dump(paramDumpComponentInfo.fd.getFileDescriptor(), localPrintWriter, paramDumpComponentInfo.args);
        localPrintWriter.flush();
      }
      return;
    }
    finally
    {
      IoUtils.closeQuietly(paramDumpComponentInfo.fd);
      StrictMode.setThreadPolicy(localThreadPolicy);
    }
  }
  
  private void handleDumpService(DumpComponentInfo paramDumpComponentInfo)
  {
    StrictMode.ThreadPolicy localThreadPolicy = StrictMode.allowThreadDiskWrites();
    try
    {
      Service localService = (Service)this.mServices.get(paramDumpComponentInfo.token);
      if (localService != null)
      {
        PrintWriter localPrintWriter = new PrintWriter(new FileOutputStream(paramDumpComponentInfo.fd.getFileDescriptor()));
        localService.dump(paramDumpComponentInfo.fd.getFileDescriptor(), localPrintWriter, paramDumpComponentInfo.args);
        localPrintWriter.flush();
      }
      return;
    }
    finally
    {
      IoUtils.closeQuietly(paramDumpComponentInfo.fd);
      StrictMode.setThreadPolicy(localThreadPolicy);
    }
  }
  
  private void handleLaunchActivity(ActivityClientRecord paramActivityClientRecord, Intent paramIntent)
  {
    unscheduleGcIdler();
    if (paramActivityClientRecord.profileFd != null)
    {
      this.mProfiler.setProfiler(paramActivityClientRecord.profileFile, paramActivityClientRecord.profileFd);
      this.mProfiler.startProfiling();
      this.mProfiler.autoStopProfiler = paramActivityClientRecord.autoStopProfiler;
    }
    handleConfigurationChanged(null, null);
    if (performLaunchActivity(paramActivityClientRecord, paramIntent) != null)
    {
      paramActivityClientRecord.createdConfig = new Configuration(this.mConfiguration);
      Bundle localBundle = paramActivityClientRecord.state;
      IBinder localIBinder = paramActivityClientRecord.token;
      boolean bool1 = paramActivityClientRecord.isForward;
      boolean bool2;
      if ((!paramActivityClientRecord.activity.mFinished) && (!paramActivityClientRecord.startsNotResumed)) {
        bool2 = true;
      }
      for (;;)
      {
        handleResumeActivity(localIBinder, false, bool1, bool2);
        if ((!paramActivityClientRecord.activity.mFinished) && (paramActivityClientRecord.startsNotResumed)) {
          try
          {
            paramActivityClientRecord.activity.mCalled = false;
            this.mInstrumentation.callActivityOnPause(paramActivityClientRecord.activity);
            if (paramActivityClientRecord.isPreHoneycomb()) {
              paramActivityClientRecord.state = localBundle;
            }
            if (!paramActivityClientRecord.activity.mCalled) {
              throw new SuperNotCalledException("Activity " + paramActivityClientRecord.intent.getComponent().toShortString() + " did not call through to super.onPause()");
            }
          }
          catch (SuperNotCalledException localSuperNotCalledException)
          {
            throw localSuperNotCalledException;
            bool2 = false;
          }
          catch (Exception localException)
          {
            if (!this.mInstrumentation.onException(paramActivityClientRecord.activity, localException)) {
              throw new RuntimeException("Unable to pause activity " + paramActivityClientRecord.intent.getComponent().toShortString() + ": " + localException.toString(), localException);
            }
            paramActivityClientRecord.paused = true;
          }
        }
      }
      return;
    }
    try
    {
      ActivityManagerNative.getDefault().finishActivity(paramActivityClientRecord.token, 0, null);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  private void handleNewIntent(NewIntentData paramNewIntentData)
  {
    performNewIntents(paramNewIntentData.token, paramNewIntentData.intents);
  }
  
  private void handlePauseActivity(IBinder paramIBinder, boolean paramBoolean1, boolean paramBoolean2, int paramInt)
  {
    ActivityClientRecord localActivityClientRecord = (ActivityClientRecord)this.mActivities.get(paramIBinder);
    if (localActivityClientRecord != null)
    {
      if (paramBoolean2) {
        performUserLeavingActivity(localActivityClientRecord);
      }
      Activity localActivity = localActivityClientRecord.activity;
      localActivity.mConfigChangeFlags = (paramInt | localActivity.mConfigChangeFlags);
      performPauseActivity(paramIBinder, paramBoolean1, localActivityClientRecord.isPreHoneycomb());
      if (localActivityClientRecord.isPreHoneycomb()) {
        QueuedWork.waitToFinish();
      }
    }
    try
    {
      ActivityManagerNative.getDefault().activityPaused(paramIBinder);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  private void handleReceiver(ReceiverData paramReceiverData)
  {
    unscheduleGcIdler();
    String str = paramReceiverData.intent.getComponent().getClassName();
    LoadedApk localLoadedApk = getPackageInfoNoCheck(paramReceiverData.info.applicationInfo, paramReceiverData.compatInfo);
    IActivityManager localIActivityManager = ActivityManagerNative.getDefault();
    label272:
    for (;;)
    {
      try
      {
        ClassLoader localClassLoader = localLoadedApk.getClassLoader();
        paramReceiverData.intent.setExtrasClassLoader(localClassLoader);
        paramReceiverData.setExtrasClassLoader(localClassLoader);
        BroadcastReceiver localBroadcastReceiver = (BroadcastReceiver)localClassLoader.loadClass(str).newInstance();
        ContextImpl localContextImpl;
        ThreadLocal localThreadLocal = sCurrentBroadcastIntent;
      }
      catch (Exception localException1)
      {
        try
        {
          localContextImpl = (ContextImpl)localLoadedApk.makeApplication(false, this.mInstrumentation).getBaseContext();
          sCurrentBroadcastIntent.set(paramReceiverData.intent);
          localBroadcastReceiver.setPendingResult(paramReceiverData);
          localBroadcastReceiver.onReceive(localContextImpl.getReceiverRestrictedContext(), paramReceiverData.intent);
          localThreadLocal = sCurrentBroadcastIntent;
          localThreadLocal.set(null);
          if (localBroadcastReceiver.getPendingResult() != null) {
            paramReceiverData.finish();
          }
          return;
        }
        catch (Exception localException2)
        {
          paramReceiverData.sendFinished(localIActivityManager);
          if (this.mInstrumentation.onException(localBroadcastReceiver, localException2)) {
            break label272;
          }
          throw new RuntimeException("Unable to start receiver " + str + ": " + localException2.toString(), localException2);
        }
        finally
        {
          sCurrentBroadcastIntent.set(null);
        }
        localException1 = localException1;
        paramReceiverData.sendFinished(localIActivityManager);
        throw new RuntimeException("Unable to instantiate receiver " + str + ": " + localException1.toString(), localException1);
      }
    }
  }
  
  private void handleRelaunchActivity(ActivityClientRecord paramActivityClientRecord)
  {
    unscheduleGcIdler();
    int i = 0;
    for (;;)
    {
      Object localObject2;
      int k;
      ActivityClientRecord localActivityClientRecord2;
      synchronized (this.mPackages)
      {
        int j = this.mRelaunchingActivities.size();
        IBinder localIBinder = paramActivityClientRecord.token;
        localObject2 = null;
        k = 0;
        if (k < j)
        {
          ActivityClientRecord localActivityClientRecord1 = (ActivityClientRecord)this.mRelaunchingActivities.get(k);
          if (localActivityClientRecord1.token != localIBinder) {
            break label535;
          }
          localObject2 = localActivityClientRecord1;
          i |= ((ActivityClientRecord)localObject2).pendingConfigChanges;
          this.mRelaunchingActivities.remove(k);
          k--;
          j--;
          break label535;
        }
        if (localObject2 == null) {
          return;
        }
        Configuration localConfiguration1 = this.mPendingConfiguration;
        Configuration localConfiguration2 = null;
        if (localConfiguration1 != null)
        {
          localConfiguration2 = this.mPendingConfiguration;
          this.mPendingConfiguration = null;
        }
        if ((((ActivityClientRecord)localObject2).createdConfig != null) && ((this.mConfiguration == null) || ((((ActivityClientRecord)localObject2).createdConfig.isOtherSeqNewer(this.mConfiguration)) && (this.mConfiguration.diff(((ActivityClientRecord)localObject2).createdConfig) != 0))) && ((localConfiguration2 == null) || (((ActivityClientRecord)localObject2).createdConfig.isOtherSeqNewer(localConfiguration2)))) {
          localConfiguration2 = ((ActivityClientRecord)localObject2).createdConfig;
        }
        if (localConfiguration2 != null)
        {
          this.mCurDefaultDisplayDpi = localConfiguration2.densityDpi;
          updateDefaultDensity();
          handleConfigurationChanged(localConfiguration2, null);
        }
        localActivityClientRecord2 = (ActivityClientRecord)this.mActivities.get(((ActivityClientRecord)localObject2).token);
        if (localActivityClientRecord2 == null) {
          break;
        }
        Activity localActivity = localActivityClientRecord2.activity;
        localActivity.mConfigChangeFlags = (i | localActivity.mConfigChangeFlags);
        localActivityClientRecord2.onlyLocalRequest = ((ActivityClientRecord)localObject2).onlyLocalRequest;
        Intent localIntent = localActivityClientRecord2.activity.mIntent;
        localActivityClientRecord2.activity.mChangingConfigurations = true;
        if (!localActivityClientRecord2.paused) {
          performPauseActivity(localActivityClientRecord2.token, false, localActivityClientRecord2.isPreHoneycomb());
        }
        if ((localActivityClientRecord2.state == null) && (!localActivityClientRecord2.stopped) && (!localActivityClientRecord2.isPreHoneycomb()))
        {
          localActivityClientRecord2.state = new Bundle();
          localActivityClientRecord2.state.setAllowFds(false);
          this.mInstrumentation.callActivityOnSaveInstanceState(localActivityClientRecord2.activity, localActivityClientRecord2.state);
        }
        handleDestroyActivity(localActivityClientRecord2.token, false, i, true);
        localActivityClientRecord2.activity = null;
        localActivityClientRecord2.window = null;
        localActivityClientRecord2.hideForNow = false;
        localActivityClientRecord2.nextIdle = null;
        if (((ActivityClientRecord)localObject2).pendingResults != null)
        {
          if (localActivityClientRecord2.pendingResults == null) {
            localActivityClientRecord2.pendingResults = ((ActivityClientRecord)localObject2).pendingResults;
          }
        }
        else
        {
          if (((ActivityClientRecord)localObject2).pendingIntents != null)
          {
            if (localActivityClientRecord2.pendingIntents != null) {
              break label516;
            }
            localActivityClientRecord2.pendingIntents = ((ActivityClientRecord)localObject2).pendingIntents;
          }
          localActivityClientRecord2.startsNotResumed = ((ActivityClientRecord)localObject2).startsNotResumed;
          handleLaunchActivity(localActivityClientRecord2, localIntent);
          return;
        }
      }
      localActivityClientRecord2.pendingResults.addAll(((ActivityClientRecord)localObject2).pendingResults);
      continue;
      label516:
      localActivityClientRecord2.pendingIntents.addAll(((ActivityClientRecord)localObject2).pendingIntents);
      continue;
      label535:
      k++;
    }
  }
  
  private void handleRequestThumbnail(IBinder paramIBinder)
  {
    ActivityClientRecord localActivityClientRecord = (ActivityClientRecord)this.mActivities.get(paramIBinder);
    Bitmap localBitmap = createThumbnailBitmap(localActivityClientRecord);
    try
    {
      CharSequence localCharSequence2 = localActivityClientRecord.activity.onCreateDescription();
      CharSequence localCharSequence1 = localCharSequence2;
      boolean bool;
      return;
    }
    catch (Exception localException)
    {
      do
      {
        try
        {
          ActivityManagerNative.getDefault().reportThumbnail(paramIBinder, localBitmap, localCharSequence1);
          return;
        }
        catch (RemoteException localRemoteException) {}
        localException = localException;
        bool = this.mInstrumentation.onException(localActivityClientRecord.activity, localException);
        localCharSequence1 = null;
      } while (bool);
      throw new RuntimeException("Unable to create description of activity " + localActivityClientRecord.intent.getComponent().toShortString() + ": " + localException.toString(), localException);
    }
  }
  
  private void handleSendResult(ResultData paramResultData)
  {
    ActivityClientRecord localActivityClientRecord = (ActivityClientRecord)this.mActivities.get(paramResultData.token);
    if (localActivityClientRecord != null)
    {
      int i;
      if (!localActivityClientRecord.paused) {
        i = 1;
      }
      for (;;)
      {
        if ((!localActivityClientRecord.activity.mFinished) && (localActivityClientRecord.activity.mDecor != null) && (localActivityClientRecord.hideForNow) && (i != 0)) {
          updateVisibility(localActivityClientRecord, true);
        }
        if (i != 0) {
          try
          {
            localActivityClientRecord.activity.mCalled = false;
            localActivityClientRecord.activity.mTemporaryPause = true;
            this.mInstrumentation.callActivityOnPause(localActivityClientRecord.activity);
            if (!localActivityClientRecord.activity.mCalled) {
              throw new SuperNotCalledException("Activity " + localActivityClientRecord.intent.getComponent().toShortString() + " did not call through to super.onPause()");
            }
          }
          catch (SuperNotCalledException localSuperNotCalledException)
          {
            throw localSuperNotCalledException;
            i = 0;
          }
          catch (Exception localException)
          {
            if (!this.mInstrumentation.onException(localActivityClientRecord.activity, localException)) {
              throw new RuntimeException("Unable to pause activity " + localActivityClientRecord.intent.getComponent().toShortString() + ": " + localException.toString(), localException);
            }
          }
        }
      }
      deliverResults(localActivityClientRecord, paramResultData.results);
      if (i != 0)
      {
        localActivityClientRecord.activity.performResume();
        localActivityClientRecord.activity.mTemporaryPause = false;
      }
    }
  }
  
  private void handleServiceArgs(ServiceArgsData paramServiceArgsData)
  {
    Service localService = (Service)this.mServices.get(paramServiceArgsData.token);
    if (localService != null) {
      try
      {
        if (paramServiceArgsData.args != null) {
          paramServiceArgsData.args.setExtrasClassLoader(localService.getClassLoader());
        }
        int i;
        if (!paramServiceArgsData.taskRemoved)
        {
          i = localService.onStartCommand(paramServiceArgsData.args, paramServiceArgsData.flags, paramServiceArgsData.startId);
          QueuedWork.waitToFinish();
        }
        return;
      }
      catch (Exception localException)
      {
        try
        {
          for (;;)
          {
            ActivityManagerNative.getDefault().serviceDoneExecuting(paramServiceArgsData.token, 1, paramServiceArgsData.startId, i);
            ensureJitEnabled();
            return;
            localService.onTaskRemoved(paramServiceArgsData.args);
            i = 1000;
          }
          localException = localException;
          if (!this.mInstrumentation.onException(localService, localException)) {
            throw new RuntimeException("Unable to start service " + localService + " with " + paramServiceArgsData.args + ": " + localException.toString(), localException);
          }
        }
        catch (RemoteException localRemoteException)
        {
          for (;;) {}
        }
      }
    }
  }
  
  private void handleSetCoreSettings(Bundle paramBundle)
  {
    synchronized (this.mPackages)
    {
      this.mCoreSettings = paramBundle;
      return;
    }
  }
  
  private void handleSleeping(IBinder paramIBinder, boolean paramBoolean)
  {
    ActivityClientRecord localActivityClientRecord = (ActivityClientRecord)this.mActivities.get(paramIBinder);
    if (localActivityClientRecord == null) {
      Log.w("ActivityThread", "handleSleeping: no activity for token " + paramIBinder);
    }
    do
    {
      return;
      if (paramBoolean)
      {
        if ((!localActivityClientRecord.stopped) && (!localActivityClientRecord.isPreHoneycomb())) {}
        try
        {
          localActivityClientRecord.activity.performStop();
          localActivityClientRecord.stopped = true;
          if (!localActivityClientRecord.isPreHoneycomb()) {
            QueuedWork.waitToFinish();
          }
          try
          {
            ActivityManagerNative.getDefault().activitySlept(localActivityClientRecord.token);
            return;
          }
          catch (RemoteException localRemoteException)
          {
            return;
          }
        }
        catch (Exception localException)
        {
          while (this.mInstrumentation.onException(localActivityClientRecord.activity, localException)) {}
          throw new RuntimeException("Unable to stop activity " + localActivityClientRecord.intent.getComponent().toShortString() + ": " + localException.toString(), localException);
        }
      }
    } while ((!localActivityClientRecord.stopped) || (!localActivityClientRecord.activity.mVisibleFromServer));
    localActivityClientRecord.activity.performRestart();
    localActivityClientRecord.stopped = false;
  }
  
  private void handleStopActivity(IBinder paramIBinder, boolean paramBoolean, int paramInt)
  {
    ActivityClientRecord localActivityClientRecord = (ActivityClientRecord)this.mActivities.get(paramIBinder);
    Activity localActivity = localActivityClientRecord.activity;
    localActivity.mConfigChangeFlags = (paramInt | localActivity.mConfigChangeFlags);
    StopInfo localStopInfo = new StopInfo(null);
    performStopActivityInner(localActivityClientRecord, localStopInfo, paramBoolean, true);
    updateVisibility(localActivityClientRecord, paramBoolean);
    if (!localActivityClientRecord.isPreHoneycomb()) {
      QueuedWork.waitToFinish();
    }
    localStopInfo.activity = localActivityClientRecord;
    localStopInfo.state = localActivityClientRecord.state;
    this.mH.post(localStopInfo);
  }
  
  private void handleStopService(IBinder paramIBinder)
  {
    Service localService = (Service)this.mServices.remove(paramIBinder);
    if (localService != null) {}
    try
    {
      localService.onDestroy();
      Context localContext = localService.getBaseContext();
      if ((localContext instanceof ContextImpl))
      {
        String str = localService.getClassName();
        ((ContextImpl)localContext).scheduleFinalCleanup(str, "Service");
      }
      QueuedWork.waitToFinish();
      return;
    }
    catch (Exception localException)
    {
      do
      {
        try
        {
          ActivityManagerNative.getDefault().serviceDoneExecuting(paramIBinder, 0, 0, 0);
          return;
        }
        catch (RemoteException localRemoteException) {}
        localException = localException;
      } while (this.mInstrumentation.onException(localService, localException));
      throw new RuntimeException("Unable to stop service " + localService + ": " + localException.toString(), localException);
    }
  }
  
  private void handleUnbindService(BindServiceData paramBindServiceData)
  {
    Service localService = (Service)this.mServices.get(paramBindServiceData.token);
    if (localService != null) {
      try
      {
        paramBindServiceData.intent.setExtrasClassLoader(localService.getClassLoader());
        boolean bool = localService.onUnbind(paramBindServiceData.intent);
        if (bool) {}
        try
        {
          ActivityManagerNative.getDefault().unbindFinished(paramBindServiceData.token, paramBindServiceData.intent, bool);
          return;
        }
        catch (RemoteException localRemoteException)
        {
          return;
        }
        ActivityManagerNative.getDefault().serviceDoneExecuting(paramBindServiceData.token, 0, 0, 0);
        return;
      }
      catch (Exception localException)
      {
        if (!this.mInstrumentation.onException(localService, localException)) {
          throw new RuntimeException("Unable to unbind to service " + localService + " with " + paramBindServiceData.intent + ": " + localException.toString(), localException);
        }
      }
    }
  }
  
  private void handleUpdatePackageCompatibilityInfo(UpdateCompatibilityData paramUpdateCompatibilityData)
  {
    LoadedApk localLoadedApk1 = peekPackageInfo(paramUpdateCompatibilityData.pkg, false);
    if (localLoadedApk1 != null) {
      localLoadedApk1.mCompatibilityInfo.set(paramUpdateCompatibilityData.info);
    }
    LoadedApk localLoadedApk2 = peekPackageInfo(paramUpdateCompatibilityData.pkg, true);
    if (localLoadedApk2 != null) {
      localLoadedApk2.mCompatibilityInfo.set(paramUpdateCompatibilityData.info);
    }
    handleConfigurationChanged(this.mConfiguration, paramUpdateCompatibilityData.info);
    WindowManagerGlobal.getInstance().reportNewConfiguration(this.mConfiguration);
  }
  
  private void handleWindowVisibility(IBinder paramIBinder, boolean paramBoolean)
  {
    ActivityClientRecord localActivityClientRecord = (ActivityClientRecord)this.mActivities.get(paramIBinder);
    if (localActivityClientRecord == null) {
      Log.w("ActivityThread", "handleWindowVisibility: no activity for token " + paramIBinder);
    }
    for (;;)
    {
      return;
      if ((!paramBoolean) && (!localActivityClientRecord.stopped)) {
        performStopActivityInner(localActivityClientRecord, null, paramBoolean, false);
      }
      while (localActivityClientRecord.activity.mDecor != null)
      {
        updateVisibility(localActivityClientRecord, paramBoolean);
        return;
        if ((paramBoolean) && (localActivityClientRecord.stopped))
        {
          unscheduleGcIdler();
          localActivityClientRecord.activity.performRestart();
          localActivityClientRecord.stopped = false;
        }
      }
    }
  }
  
  private final void incProviderRefLocked(ProviderRefCount paramProviderRefCount, boolean paramBoolean)
  {
    int i;
    if (paramBoolean)
    {
      paramProviderRefCount.stableCount = (1 + paramProviderRefCount.stableCount);
      if (paramProviderRefCount.stableCount == 1)
      {
        if (!paramProviderRefCount.removePending) {
          break label68;
        }
        i = -1;
        paramProviderRefCount.removePending = false;
        this.mH.removeMessages(131, paramProviderRefCount);
      }
    }
    for (;;)
    {
      label68:
      try
      {
        ActivityManagerNative.getDefault().refContentProvider(paramProviderRefCount.holder.connection, 1, i);
        return;
      }
      catch (RemoteException localRemoteException2) {}
      i = 0;
      continue;
      paramProviderRefCount.unstableCount = (1 + paramProviderRefCount.unstableCount);
      if (paramProviderRefCount.unstableCount == 1)
      {
        if (paramProviderRefCount.removePending)
        {
          paramProviderRefCount.removePending = false;
          this.mH.removeMessages(131, paramProviderRefCount);
          return;
        }
        try
        {
          ActivityManagerNative.getDefault().refContentProvider(paramProviderRefCount.holder.connection, 0, 1);
          return;
        }
        catch (RemoteException localRemoteException1)
        {
          return;
        }
      }
    }
  }
  
  private void installContentProviders(Context paramContext, List<ProviderInfo> paramList)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      ProviderInfo localProviderInfo = (ProviderInfo)localIterator.next();
      StringBuilder localStringBuilder = new StringBuilder(128);
      localStringBuilder.append("Pub ");
      localStringBuilder.append(localProviderInfo.authority);
      localStringBuilder.append(": ");
      localStringBuilder.append(localProviderInfo.name);
      Log.i("ActivityThread", localStringBuilder.toString());
      IActivityManager.ContentProviderHolder localContentProviderHolder = installProvider(paramContext, null, localProviderInfo, false, true, true);
      if (localContentProviderHolder != null)
      {
        localContentProviderHolder.noReleaseNeeded = true;
        localArrayList.add(localContentProviderHolder);
      }
    }
    try
    {
      ActivityManagerNative.getDefault().publishContentProviders(getApplicationThread(), localArrayList);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  /* Error */
  private IActivityManager.ContentProviderHolder installProvider(Context paramContext, IActivityManager.ContentProviderHolder paramContentProviderHolder, ProviderInfo paramProviderInfo, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    // Byte code:
    //   0: aload_2
    //   1: ifnull +10 -> 11
    //   4: aload_2
    //   5: getfield 1807	android/app/IActivityManager$ContentProviderHolder:provider	Landroid/content/IContentProvider;
    //   8: ifnonnull +412 -> 420
    //   11: iload 4
    //   13: ifeq +45 -> 58
    //   16: ldc 31
    //   18: new 513	java/lang/StringBuilder
    //   21: dup
    //   22: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   25: ldc_w 1809
    //   28: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   31: aload_3
    //   32: getfield 1785	android/content/pm/ProviderInfo:authority	Ljava/lang/String;
    //   35: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   38: ldc_w 692
    //   41: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   44: aload_3
    //   45: getfield 1107	android/content/pm/PackageItemInfo:name	Ljava/lang/String;
    //   48: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   54: invokestatic 1259	android/util/Slog:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   57: pop
    //   58: aload_3
    //   59: getfield 1296	android/content/pm/ComponentInfo:applicationInfo	Landroid/content/pm/ApplicationInfo;
    //   62: astore 7
    //   64: aload_1
    //   65: invokevirtual 1812	android/content/Context:getPackageName	()Ljava/lang/String;
    //   68: aload 7
    //   70: getfield 779	android/content/pm/PackageItemInfo:packageName	Ljava/lang/String;
    //   73: invokevirtual 1815	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   76: ifeq +56 -> 132
    //   79: aload_1
    //   80: astore 9
    //   82: aload 9
    //   84: ifnonnull +101 -> 185
    //   87: ldc 31
    //   89: new 513	java/lang/StringBuilder
    //   92: dup
    //   93: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   96: ldc_w 1817
    //   99: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   102: aload 7
    //   104: getfield 779	android/content/pm/PackageItemInfo:packageName	Ljava/lang/String;
    //   107: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   110: ldc_w 1819
    //   113: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   116: aload_3
    //   117: getfield 1107	android/content/pm/PackageItemInfo:name	Ljava/lang/String;
    //   120: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   123: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   126: invokestatic 1004	android/util/Slog:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   129: pop
    //   130: aconst_null
    //   131: areturn
    //   132: aload_0
    //   133: getfield 506	android/app/ActivityThread:mInitialApplication	Landroid/app/Application;
    //   136: ifnull +30 -> 166
    //   139: aload_0
    //   140: getfield 506	android/app/ActivityThread:mInitialApplication	Landroid/app/Application;
    //   143: invokevirtual 1820	android/app/Application:getPackageName	()Ljava/lang/String;
    //   146: aload 7
    //   148: getfield 779	android/content/pm/PackageItemInfo:packageName	Ljava/lang/String;
    //   151: invokevirtual 1815	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   154: ifeq +12 -> 166
    //   157: aload_0
    //   158: getfield 506	android/app/ActivityThread:mInitialApplication	Landroid/app/Application;
    //   161: astore 9
    //   163: goto -81 -> 82
    //   166: aload_1
    //   167: aload 7
    //   169: getfield 779	android/content/pm/PackageItemInfo:packageName	Ljava/lang/String;
    //   172: iconst_1
    //   173: invokevirtual 1824	android/content/Context:createPackageContext	(Ljava/lang/String;I)Landroid/content/Context;
    //   176: astore 29
    //   178: aload 29
    //   180: astore 9
    //   182: goto -100 -> 82
    //   185: aload 9
    //   187: invokevirtual 1825	android/content/Context:getClassLoader	()Ljava/lang/ClassLoader;
    //   190: aload_3
    //   191: getfield 1107	android/content/pm/PackageItemInfo:name	Ljava/lang/String;
    //   194: invokevirtual 1101	java/lang/ClassLoader:loadClass	(Ljava/lang/String;)Ljava/lang/Class;
    //   197: invokevirtual 1104	java/lang/Class:newInstance	()Ljava/lang/Object;
    //   200: checkcast 1428	android/content/ContentProvider
    //   203: astore 11
    //   205: aload 11
    //   207: invokevirtual 1829	android/content/ContentProvider:getIContentProvider	()Landroid/content/IContentProvider;
    //   210: astore 12
    //   212: aload 12
    //   214: ifnonnull +50 -> 264
    //   217: ldc 31
    //   219: new 513	java/lang/StringBuilder
    //   222: dup
    //   223: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   226: ldc_w 1831
    //   229: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   232: aload_3
    //   233: getfield 1107	android/content/pm/PackageItemInfo:name	Ljava/lang/String;
    //   236: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   239: ldc_w 1833
    //   242: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   245: aload_3
    //   246: getfield 1296	android/content/pm/ComponentInfo:applicationInfo	Landroid/content/pm/ApplicationInfo;
    //   249: getfield 1080	android/content/pm/ApplicationInfo:sourceDir	Ljava/lang/String;
    //   252: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   255: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   258: invokestatic 1286	android/util/Slog:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   261: pop
    //   262: aconst_null
    //   263: areturn
    //   264: aload 11
    //   266: aload 9
    //   268: aload_3
    //   269: invokevirtual 1837	android/content/ContentProvider:attachInfo	(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V
    //   272: aload_0
    //   273: getfield 216	android/app/ActivityThread:mProviderMap	Ljava/util/HashMap;
    //   276: astore 14
    //   278: aload 14
    //   280: monitorenter
    //   281: aload 12
    //   283: invokeinterface 1840 1 0
    //   288: astore 16
    //   290: aload 11
    //   292: ifnull +202 -> 494
    //   295: new 687	android/content/ComponentName
    //   298: dup
    //   299: aload_3
    //   300: getfield 779	android/content/pm/PackageItemInfo:packageName	Ljava/lang/String;
    //   303: aload_3
    //   304: getfield 1107	android/content/pm/PackageItemInfo:name	Ljava/lang/String;
    //   307: invokespecial 1110	android/content/ComponentName:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   310: astore 17
    //   312: aload_0
    //   313: getfield 222	android/app/ActivityThread:mLocalProvidersByName	Ljava/util/HashMap;
    //   316: aload 17
    //   318: invokevirtual 782	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   321: checkcast 1422	android/app/ActivityThread$ProviderClientRecord
    //   324: astore 18
    //   326: aload 18
    //   328: ifnull +104 -> 432
    //   331: aload 18
    //   333: getfield 1843	android/app/ActivityThread$ProviderClientRecord:mProvider	Landroid/content/IContentProvider;
    //   336: pop
    //   337: aload 18
    //   339: getfield 1846	android/app/ActivityThread$ProviderClientRecord:mHolder	Landroid/app/IActivityManager$ContentProviderHolder;
    //   342: astore 20
    //   344: aload 14
    //   346: monitorexit
    //   347: aload 20
    //   349: areturn
    //   350: aload 14
    //   352: monitorexit
    //   353: aload 15
    //   355: athrow
    //   356: astore 10
    //   358: aload_0
    //   359: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   362: aconst_null
    //   363: aload 10
    //   365: invokevirtual 673	android/app/Instrumentation:onException	(Ljava/lang/Object;Ljava/lang/Throwable;)Z
    //   368: ifne +50 -> 418
    //   371: new 511	java/lang/RuntimeException
    //   374: dup
    //   375: new 513	java/lang/StringBuilder
    //   378: dup
    //   379: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   382: ldc_w 1848
    //   385: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   388: aload_3
    //   389: getfield 1107	android/content/pm/PackageItemInfo:name	Ljava/lang/String;
    //   392: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   395: ldc_w 692
    //   398: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   401: aload 10
    //   403: invokevirtual 524	java/lang/Exception:toString	()Ljava/lang/String;
    //   406: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   409: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   412: aload 10
    //   414: invokespecial 528	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   417: athrow
    //   418: aconst_null
    //   419: areturn
    //   420: aload_2
    //   421: getfield 1807	android/app/IActivityManager$ContentProviderHolder:provider	Landroid/content/IContentProvider;
    //   424: astore 12
    //   426: aconst_null
    //   427: astore 11
    //   429: goto -157 -> 272
    //   432: new 1754	android/app/IActivityManager$ContentProviderHolder
    //   435: dup
    //   436: aload_3
    //   437: invokespecial 1851	android/app/IActivityManager$ContentProviderHolder:<init>	(Landroid/content/pm/ProviderInfo;)V
    //   440: astore 21
    //   442: aload 21
    //   444: aload 12
    //   446: putfield 1807	android/app/IActivityManager$ContentProviderHolder:provider	Landroid/content/IContentProvider;
    //   449: aload 21
    //   451: iconst_1
    //   452: putfield 1795	android/app/IActivityManager$ContentProviderHolder:noReleaseNeeded	Z
    //   455: aload_0
    //   456: aload 12
    //   458: aload 11
    //   460: aload 21
    //   462: invokespecial 1855	android/app/ActivityThread:installProviderAuthoritiesLocked	(Landroid/content/IContentProvider;Landroid/content/ContentProvider;Landroid/app/IActivityManager$ContentProviderHolder;)Landroid/app/ActivityThread$ProviderClientRecord;
    //   465: astore 18
    //   467: aload_0
    //   468: getfield 220	android/app/ActivityThread:mLocalProviders	Ljava/util/HashMap;
    //   471: aload 16
    //   473: aload 18
    //   475: invokevirtual 812	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   478: pop
    //   479: aload_0
    //   480: getfield 222	android/app/ActivityThread:mLocalProvidersByName	Ljava/util/HashMap;
    //   483: aload 17
    //   485: aload 18
    //   487: invokevirtual 812	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   490: pop
    //   491: goto -154 -> 337
    //   494: aload_0
    //   495: getfield 218	android/app/ActivityThread:mProviderRefCountMap	Ljava/util/HashMap;
    //   498: aload 16
    //   500: invokevirtual 782	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   503: checkcast 1739	android/app/ActivityThread$ProviderRefCount
    //   506: astore 24
    //   508: aload 24
    //   510: ifnull +40 -> 550
    //   513: iload 5
    //   515: ifne +25 -> 540
    //   518: aload_0
    //   519: aload 24
    //   521: iload 6
    //   523: invokespecial 1857	android/app/ActivityThread:incProviderRefLocked	(Landroid/app/ActivityThread$ProviderRefCount;Z)V
    //   526: invokestatic 450	android/app/ActivityManagerNative:getDefault	()Landroid/app/IActivityManager;
    //   529: aload_2
    //   530: getfield 1757	android/app/IActivityManager$ContentProviderHolder:connection	Landroid/os/IBinder;
    //   533: iload 6
    //   535: invokeinterface 1860 3 0
    //   540: aload 24
    //   542: getfield 1752	android/app/ActivityThread$ProviderRefCount:holder	Landroid/app/IActivityManager$ContentProviderHolder;
    //   545: astore 20
    //   547: goto -203 -> 344
    //   550: aload_0
    //   551: aload 12
    //   553: aload 11
    //   555: aload_2
    //   556: invokespecial 1855	android/app/ActivityThread:installProviderAuthoritiesLocked	(Landroid/content/IContentProvider;Landroid/content/ContentProvider;Landroid/app/IActivityManager$ContentProviderHolder;)Landroid/app/ActivityThread$ProviderClientRecord;
    //   559: astore 25
    //   561: iload 5
    //   563: ifeq +36 -> 599
    //   566: new 1739	android/app/ActivityThread$ProviderRefCount
    //   569: dup
    //   570: aload_2
    //   571: aload 25
    //   573: sipush 1000
    //   576: sipush 1000
    //   579: invokespecial 1863	android/app/ActivityThread$ProviderRefCount:<init>	(Landroid/app/IActivityManager$ContentProviderHolder;Landroid/app/ActivityThread$ProviderClientRecord;II)V
    //   582: astore 24
    //   584: aload_0
    //   585: getfield 218	android/app/ActivityThread:mProviderRefCountMap	Ljava/util/HashMap;
    //   588: aload 16
    //   590: aload 24
    //   592: invokevirtual 812	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   595: pop
    //   596: goto -56 -> 540
    //   599: iload 6
    //   601: ifeq +20 -> 621
    //   604: new 1739	android/app/ActivityThread$ProviderRefCount
    //   607: dup
    //   608: aload_2
    //   609: aload 25
    //   611: iconst_1
    //   612: iconst_0
    //   613: invokespecial 1863	android/app/ActivityThread$ProviderRefCount:<init>	(Landroid/app/IActivityManager$ContentProviderHolder;Landroid/app/ActivityThread$ProviderClientRecord;II)V
    //   616: astore 24
    //   618: goto +43 -> 661
    //   621: new 1739	android/app/ActivityThread$ProviderRefCount
    //   624: dup
    //   625: aload_2
    //   626: aload 25
    //   628: iconst_0
    //   629: iconst_1
    //   630: invokespecial 1863	android/app/ActivityThread$ProviderRefCount:<init>	(Landroid/app/IActivityManager$ContentProviderHolder;Landroid/app/ActivityThread$ProviderClientRecord;II)V
    //   633: astore 24
    //   635: goto +26 -> 661
    //   638: astore 15
    //   640: goto -290 -> 350
    //   643: astore 27
    //   645: goto -105 -> 540
    //   648: astore 8
    //   650: aconst_null
    //   651: astore 9
    //   653: goto -571 -> 82
    //   656: astore 15
    //   658: goto -308 -> 350
    //   661: goto -77 -> 584
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	664	0	this	ActivityThread
    //   0	664	1	paramContext	Context
    //   0	664	2	paramContentProviderHolder	IActivityManager.ContentProviderHolder
    //   0	664	3	paramProviderInfo	ProviderInfo
    //   0	664	4	paramBoolean1	boolean
    //   0	664	5	paramBoolean2	boolean
    //   0	664	6	paramBoolean3	boolean
    //   62	106	7	localApplicationInfo	ApplicationInfo
    //   648	1	8	localNameNotFoundException	PackageManager.NameNotFoundException
    //   80	572	9	localObject1	Object
    //   356	57	10	localException	Exception
    //   203	351	11	localContentProvider	ContentProvider
    //   210	342	12	localIContentProvider	IContentProvider
    //   353	1	15	localObject2	Object
    //   638	1	15	localObject3	Object
    //   656	1	15	localObject4	Object
    //   288	301	16	localIBinder	IBinder
    //   310	174	17	localComponentName	ComponentName
    //   324	162	18	localProviderClientRecord1	ProviderClientRecord
    //   342	204	20	localContentProviderHolder1	IActivityManager.ContentProviderHolder
    //   440	21	21	localContentProviderHolder2	IActivityManager.ContentProviderHolder
    //   506	128	24	localProviderRefCount	ProviderRefCount
    //   559	68	25	localProviderClientRecord2	ProviderClientRecord
    //   643	1	27	localRemoteException	RemoteException
    //   176	3	29	localContext	Context
    // Exception table:
    //   from	to	target	type
    //   185	212	356	java/lang/Exception
    //   217	262	356	java/lang/Exception
    //   264	272	356	java/lang/Exception
    //   442	491	638	finally
    //   526	540	643	android/os/RemoteException
    //   166	178	648	android/content/pm/PackageManager$NameNotFoundException
    //   281	290	656	finally
    //   295	326	656	finally
    //   331	337	656	finally
    //   337	344	656	finally
    //   344	347	656	finally
    //   350	353	656	finally
    //   432	442	656	finally
    //   494	508	656	finally
    //   518	526	656	finally
    //   526	540	656	finally
    //   540	547	656	finally
    //   550	561	656	finally
    //   566	584	656	finally
    //   584	596	656	finally
    //   604	618	656	finally
    //   621	635	656	finally
  }
  
  private ProviderClientRecord installProviderAuthoritiesLocked(IContentProvider paramIContentProvider, ContentProvider paramContentProvider, IActivityManager.ContentProviderHolder paramContentProviderHolder)
  {
    String[] arrayOfString = PATTERN_SEMICOLON.split(paramContentProviderHolder.info.authority);
    int i = UserHandle.getUserId(paramContentProviderHolder.info.applicationInfo.uid);
    ProviderClientRecord localProviderClientRecord = new ProviderClientRecord(arrayOfString, paramIContentProvider, paramContentProvider, paramContentProviderHolder);
    int j = arrayOfString.length;
    int k = 0;
    if (k < j)
    {
      String str = arrayOfString[k];
      ProviderKey localProviderKey = new ProviderKey(str, i);
      if ((ProviderClientRecord)this.mProviderMap.get(localProviderKey) != null) {
        Slog.w("ActivityThread", "Content provider " + localProviderClientRecord.mHolder.info.name + " already published as " + str);
      }
      for (;;)
      {
        k++;
        break;
        this.mProviderMap.put(localProviderKey, localProviderClientRecord);
      }
    }
    return localProviderClientRecord;
  }
  
  public static void main(String[] paramArrayOfString)
  {
    SamplingProfilerIntegration.start();
    CloseGuard.setEnabled(false);
    Environment.initForCurrentUser();
    EventLogger.setReporter(new EventLoggingReporter(null));
    Process.setArgV0("<pre-initialized>");
    Looper.prepareMainLooper();
    ActivityThread localActivityThread = new ActivityThread();
    localActivityThread.attach(false);
    if (sMainThreadHandler == null) {
      sMainThreadHandler = localActivityThread.getHandler();
    }
    AsyncTask.init();
    Looper.loop();
    throw new RuntimeException("Main thread loop unexpectedly exited");
  }
  
  private static void performConfigurationChanged(ComponentCallbacks2 paramComponentCallbacks2, Configuration paramConfiguration)
  {
    Activity localActivity;
    int i;
    if ((paramComponentCallbacks2 instanceof Activity))
    {
      localActivity = (Activity)paramComponentCallbacks2;
      if (localActivity != null) {
        localActivity.mCalled = false;
      }
      if ((localActivity != null) && (localActivity.mCurrentConfig != null)) {
        break label98;
      }
      i = 1;
    }
    for (;;)
    {
      if (i != 0)
      {
        paramComponentCallbacks2.onConfigurationChanged(paramConfiguration);
        if (localActivity != null)
        {
          if (!localActivity.mCalled)
          {
            throw new SuperNotCalledException("Activity " + localActivity.getLocalClassName() + " did not call through to super.onConfigurationChanged()");
            localActivity = null;
            break;
            label98:
            int j = localActivity.mCurrentConfig.diff(paramConfiguration);
            i = 0;
            if (j == 0) {
              continue;
            }
            int k = j & (0xFFFFFFFF ^ localActivity.mActivityInfo.getRealConfigChanged());
            i = 0;
            if (k != 0) {
              continue;
            }
            i = 1;
            continue;
          }
          localActivity.mConfigChangeFlags = 0;
          localActivity.mCurrentConfig = new Configuration(paramConfiguration);
        }
      }
    }
  }
  
  /* Error */
  private ActivityClientRecord performDestroyActivity(IBinder paramIBinder, boolean paramBoolean1, int paramInt, boolean paramBoolean2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 175	android/app/ActivityThread:mActivities	Ljava/util/HashMap;
    //   4: aload_1
    //   5: invokevirtual 782	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   8: checkcast 531	android/app/ActivityThread$ActivityClientRecord
    //   11: astore 5
    //   13: aconst_null
    //   14: astore 6
    //   16: aload 5
    //   18: ifnull +529 -> 547
    //   21: aload 5
    //   23: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   26: invokevirtual 564	java/lang/Object:getClass	()Ljava/lang/Class;
    //   29: astore 6
    //   31: aload 5
    //   33: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   36: astore 8
    //   38: aload 8
    //   40: iload_3
    //   41: aload 8
    //   43: getfield 1508	android/app/Activity:mConfigChangeFlags	I
    //   46: ior
    //   47: putfield 1508	android/app/Activity:mConfigChangeFlags	I
    //   50: iload_2
    //   51: ifeq +12 -> 63
    //   54: aload 5
    //   56: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   59: iconst_1
    //   60: putfield 1461	android/app/Activity:mFinished	Z
    //   63: aload 5
    //   65: getfield 1488	android/app/ActivityThread$ActivityClientRecord:paused	Z
    //   68: ifne +197 -> 265
    //   71: aload 5
    //   73: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   76: iconst_0
    //   77: putfield 1471	android/app/Activity:mCalled	Z
    //   80: aload_0
    //   81: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   84: aload 5
    //   86: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   89: invokevirtual 1475	android/app/Instrumentation:callActivityOnPause	(Landroid/app/Activity;)V
    //   92: iconst_2
    //   93: anewarray 4	java/lang/Object
    //   96: astore 16
    //   98: aload 16
    //   100: iconst_0
    //   101: invokestatic 429	android/os/UserHandle:myUserId	()I
    //   104: invokestatic 1957	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   107: aastore
    //   108: aload 16
    //   110: iconst_1
    //   111: aload 5
    //   113: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   116: invokevirtual 1960	android/app/Activity:getComponentName	()Landroid/content/ComponentName;
    //   119: invokevirtual 1095	android/content/ComponentName:getClassName	()Ljava/lang/String;
    //   122: aastore
    //   123: sipush 30021
    //   126: aload 16
    //   128: invokestatic 1966	android/util/EventLog:writeEvent	(I[Ljava/lang/Object;)I
    //   131: pop
    //   132: aload 5
    //   134: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   137: getfield 1471	android/app/Activity:mCalled	Z
    //   140: ifne +119 -> 259
    //   143: new 1434	android/app/SuperNotCalledException
    //   146: dup
    //   147: new 513	java/lang/StringBuilder
    //   150: dup
    //   151: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   154: ldc_w 1480
    //   157: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: aload 5
    //   162: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   165: invokestatic 1970	android/app/ActivityThread:safeToComponentShortString	(Landroid/content/Intent;)Ljava/lang/String;
    //   168: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   171: ldc_w 1482
    //   174: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   177: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   180: invokespecial 1483	android/app/SuperNotCalledException:<init>	(Ljava/lang/String;)V
    //   183: athrow
    //   184: astore 15
    //   186: aload 15
    //   188: athrow
    //   189: astore 14
    //   191: aload_0
    //   192: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   195: aload 5
    //   197: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   200: aload 14
    //   202: invokevirtual 673	android/app/Instrumentation:onException	(Ljava/lang/Object;Ljava/lang/Throwable;)Z
    //   205: ifne +54 -> 259
    //   208: new 511	java/lang/RuntimeException
    //   211: dup
    //   212: new 513	java/lang/StringBuilder
    //   215: dup
    //   216: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   219: ldc_w 1485
    //   222: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   225: aload 5
    //   227: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   230: invokestatic 1970	android/app/ActivityThread:safeToComponentShortString	(Landroid/content/Intent;)Ljava/lang/String;
    //   233: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   236: ldc_w 692
    //   239: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   242: aload 14
    //   244: invokevirtual 524	java/lang/Exception:toString	()Ljava/lang/String;
    //   247: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   250: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   253: aload 14
    //   255: invokespecial 528	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   258: athrow
    //   259: aload 5
    //   261: iconst_1
    //   262: putfield 1488	android/app/ActivityThread$ActivityClientRecord:paused	Z
    //   265: aload 5
    //   267: getfield 1581	android/app/ActivityThread$ActivityClientRecord:stopped	Z
    //   270: ifne +17 -> 287
    //   273: aload 5
    //   275: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   278: invokevirtual 1669	android/app/Activity:performStop	()V
    //   281: aload 5
    //   283: iconst_1
    //   284: putfield 1581	android/app/ActivityThread$ActivityClientRecord:stopped	Z
    //   287: iload 4
    //   289: ifeq +16 -> 305
    //   292: aload 5
    //   294: aload 5
    //   296: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   299: invokevirtual 1974	android/app/Activity:retainNonConfigurationInstances	()Landroid/app/Activity$NonConfigurationInstances;
    //   302: putfield 1978	android/app/ActivityThread$ActivityClientRecord:lastNonConfigurationInstances	Landroid/app/Activity$NonConfigurationInstances;
    //   305: aload 5
    //   307: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   310: iconst_0
    //   311: putfield 1471	android/app/Activity:mCalled	Z
    //   314: aload_0
    //   315: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   318: aload 5
    //   320: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   323: invokevirtual 1981	android/app/Instrumentation:callActivityOnDestroy	(Landroid/app/Activity;)V
    //   326: aload 5
    //   328: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   331: getfield 1471	android/app/Activity:mCalled	Z
    //   334: ifne +197 -> 531
    //   337: new 1434	android/app/SuperNotCalledException
    //   340: dup
    //   341: new 513	java/lang/StringBuilder
    //   344: dup
    //   345: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   348: ldc_w 1480
    //   351: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   354: aload 5
    //   356: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   359: invokestatic 1970	android/app/ActivityThread:safeToComponentShortString	(Landroid/content/Intent;)Ljava/lang/String;
    //   362: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   365: ldc_w 1983
    //   368: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   371: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   374: invokespecial 1483	android/app/SuperNotCalledException:<init>	(Ljava/lang/String;)V
    //   377: athrow
    //   378: astore 10
    //   380: aload 10
    //   382: athrow
    //   383: astore 13
    //   385: aload 13
    //   387: athrow
    //   388: astore 12
    //   390: aload_0
    //   391: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   394: aload 5
    //   396: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   399: aload 12
    //   401: invokevirtual 673	android/app/Instrumentation:onException	(Ljava/lang/Object;Ljava/lang/Throwable;)Z
    //   404: ifne -123 -> 281
    //   407: new 511	java/lang/RuntimeException
    //   410: dup
    //   411: new 513	java/lang/StringBuilder
    //   414: dup
    //   415: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   418: ldc_w 1674
    //   421: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   424: aload 5
    //   426: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   429: invokestatic 1970	android/app/ActivityThread:safeToComponentShortString	(Landroid/content/Intent;)Ljava/lang/String;
    //   432: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   435: ldc_w 692
    //   438: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   441: aload 12
    //   443: invokevirtual 524	java/lang/Exception:toString	()Ljava/lang/String;
    //   446: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   449: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   452: aload 12
    //   454: invokespecial 528	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   457: athrow
    //   458: astore 11
    //   460: aload_0
    //   461: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   464: aload 5
    //   466: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   469: aload 11
    //   471: invokevirtual 673	android/app/Instrumentation:onException	(Ljava/lang/Object;Ljava/lang/Throwable;)Z
    //   474: ifne -169 -> 305
    //   477: new 511	java/lang/RuntimeException
    //   480: dup
    //   481: new 513	java/lang/StringBuilder
    //   484: dup
    //   485: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   488: ldc_w 1985
    //   491: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   494: aload 5
    //   496: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   499: invokevirtual 685	android/content/Intent:getComponent	()Landroid/content/ComponentName;
    //   502: invokevirtual 690	android/content/ComponentName:toShortString	()Ljava/lang/String;
    //   505: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   508: ldc_w 692
    //   511: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   514: aload 11
    //   516: invokevirtual 524	java/lang/Exception:toString	()Ljava/lang/String;
    //   519: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   522: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   525: aload 11
    //   527: invokespecial 528	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   530: athrow
    //   531: aload 5
    //   533: getfield 1596	android/app/ActivityThread$ActivityClientRecord:window	Landroid/view/Window;
    //   536: ifnull +11 -> 547
    //   539: aload 5
    //   541: getfield 1596	android/app/ActivityThread$ActivityClientRecord:window	Landroid/view/Window;
    //   544: invokevirtual 1990	android/view/Window:closeAllPanels	()V
    //   547: aload_0
    //   548: getfield 175	android/app/ActivityThread:mActivities	Ljava/util/HashMap;
    //   551: aload_1
    //   552: invokevirtual 1344	java/util/HashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
    //   555: pop
    //   556: aload 6
    //   558: invokestatic 1994	android/os/StrictMode:decrementExpectedActivityCount	(Ljava/lang/Class;)V
    //   561: aload 5
    //   563: areturn
    //   564: astore 9
    //   566: aload_0
    //   567: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   570: aload 5
    //   572: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   575: aload 9
    //   577: invokevirtual 673	android/app/Instrumentation:onException	(Ljava/lang/Object;Ljava/lang/Throwable;)Z
    //   580: ifne -33 -> 547
    //   583: new 511	java/lang/RuntimeException
    //   586: dup
    //   587: new 513	java/lang/StringBuilder
    //   590: dup
    //   591: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   594: ldc_w 1996
    //   597: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   600: aload 5
    //   602: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   605: invokestatic 1970	android/app/ActivityThread:safeToComponentShortString	(Landroid/content/Intent;)Ljava/lang/String;
    //   608: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   611: ldc_w 692
    //   614: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   617: aload 9
    //   619: invokevirtual 524	java/lang/Exception:toString	()Ljava/lang/String;
    //   622: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   625: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   628: aload 9
    //   630: invokespecial 528	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   633: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	634	0	this	ActivityThread
    //   0	634	1	paramIBinder	IBinder
    //   0	634	2	paramBoolean1	boolean
    //   0	634	3	paramInt	int
    //   0	634	4	paramBoolean2	boolean
    //   11	590	5	localActivityClientRecord	ActivityClientRecord
    //   14	543	6	localClass	Class
    //   36	6	8	localActivity	Activity
    //   564	65	9	localException1	Exception
    //   378	3	10	localSuperNotCalledException1	SuperNotCalledException
    //   458	68	11	localException2	Exception
    //   388	65	12	localException3	Exception
    //   383	3	13	localSuperNotCalledException2	SuperNotCalledException
    //   189	65	14	localException4	Exception
    //   184	3	15	localSuperNotCalledException3	SuperNotCalledException
    //   96	31	16	arrayOfObject	Object[]
    // Exception table:
    //   from	to	target	type
    //   71	184	184	android/app/SuperNotCalledException
    //   71	184	189	java/lang/Exception
    //   305	378	378	android/app/SuperNotCalledException
    //   531	547	378	android/app/SuperNotCalledException
    //   273	281	383	android/app/SuperNotCalledException
    //   273	281	388	java/lang/Exception
    //   292	305	458	java/lang/Exception
    //   305	378	564	java/lang/Exception
    //   531	547	564	java/lang/Exception
  }
  
  /* Error */
  private Activity performLaunchActivity(ActivityClientRecord paramActivityClientRecord, Intent paramIntent)
  {
    // Byte code:
    //   0: aload_1
    //   1: getfield 1999	android/app/ActivityThread$ActivityClientRecord:activityInfo	Landroid/content/pm/ActivityInfo;
    //   4: astore_3
    //   5: aload_1
    //   6: getfield 580	android/app/ActivityThread$ActivityClientRecord:packageInfo	Landroid/app/LoadedApk;
    //   9: ifnonnull +20 -> 29
    //   12: aload_1
    //   13: aload_0
    //   14: aload_3
    //   15: getfield 1296	android/content/pm/ComponentInfo:applicationInfo	Landroid/content/pm/ApplicationInfo;
    //   18: aload_1
    //   19: getfield 2000	android/app/ActivityThread$ActivityClientRecord:compatInfo	Landroid/content/res/CompatibilityInfo;
    //   22: iconst_1
    //   23: invokevirtual 2003	android/app/ActivityThread:getPackageInfo	(Landroid/content/pm/ApplicationInfo;Landroid/content/res/CompatibilityInfo;I)Landroid/app/LoadedApk;
    //   26: putfield 580	android/app/ActivityThread$ActivityClientRecord:packageInfo	Landroid/app/LoadedApk;
    //   29: aload_1
    //   30: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   33: invokevirtual 685	android/content/Intent:getComponent	()Landroid/content/ComponentName;
    //   36: astore 4
    //   38: aload 4
    //   40: ifnonnull +29 -> 69
    //   43: aload_1
    //   44: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   47: aload_0
    //   48: getfield 506	android/app/ActivityThread:mInitialApplication	Landroid/app/Application;
    //   51: invokevirtual 2004	android/app/Application:getPackageManager	()Landroid/content/pm/PackageManager;
    //   54: invokevirtual 2008	android/content/Intent:resolveActivity	(Landroid/content/pm/PackageManager;)Landroid/content/ComponentName;
    //   57: astore 4
    //   59: aload_1
    //   60: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   63: aload 4
    //   65: invokevirtual 2012	android/content/Intent:setComponent	(Landroid/content/ComponentName;)Landroid/content/Intent;
    //   68: pop
    //   69: aload_1
    //   70: getfield 1999	android/app/ActivityThread$ActivityClientRecord:activityInfo	Landroid/content/pm/ActivityInfo;
    //   73: getfield 2015	android/content/pm/ActivityInfo:targetActivity	Ljava/lang/String;
    //   76: ifnull +34 -> 110
    //   79: aload_1
    //   80: getfield 1999	android/app/ActivityThread$ActivityClientRecord:activityInfo	Landroid/content/pm/ActivityInfo;
    //   83: getfield 779	android/content/pm/PackageItemInfo:packageName	Ljava/lang/String;
    //   86: astore 16
    //   88: aload_1
    //   89: getfield 1999	android/app/ActivityThread$ActivityClientRecord:activityInfo	Landroid/content/pm/ActivityInfo;
    //   92: getfield 2015	android/content/pm/ActivityInfo:targetActivity	Ljava/lang/String;
    //   95: astore 17
    //   97: new 687	android/content/ComponentName
    //   100: dup
    //   101: aload 16
    //   103: aload 17
    //   105: invokespecial 1110	android/content/ComponentName:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   108: astore 4
    //   110: aconst_null
    //   111: astore 5
    //   113: aload_1
    //   114: getfield 580	android/app/ActivityThread$ActivityClientRecord:packageInfo	Landroid/app/LoadedApk;
    //   117: invokevirtual 1272	android/app/LoadedApk:getClassLoader	()Ljava/lang/ClassLoader;
    //   120: astore 15
    //   122: aload_0
    //   123: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   126: aload 15
    //   128: aload 4
    //   130: invokevirtual 1095	android/content/ComponentName:getClassName	()Ljava/lang/String;
    //   133: aload_1
    //   134: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   137: invokevirtual 2019	android/app/Instrumentation:newActivity	(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/app/Activity;
    //   140: astore 5
    //   142: aload 5
    //   144: invokevirtual 564	java/lang/Object:getClass	()Ljava/lang/Class;
    //   147: invokestatic 2022	android/os/StrictMode:incrementExpectedActivityCount	(Ljava/lang/Class;)V
    //   150: aload_1
    //   151: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   154: aload 15
    //   156: invokevirtual 727	android/content/Intent:setExtrasClassLoader	(Ljava/lang/ClassLoader;)V
    //   159: aload_1
    //   160: getfield 1455	android/app/ActivityThread$ActivityClientRecord:state	Landroid/os/Bundle;
    //   163: ifnull +12 -> 175
    //   166: aload_1
    //   167: getfield 1455	android/app/ActivityThread$ActivityClientRecord:state	Landroid/os/Bundle;
    //   170: aload 15
    //   172: invokevirtual 2025	android/os/Bundle:setClassLoader	(Ljava/lang/ClassLoader;)V
    //   175: aload_1
    //   176: getfield 580	android/app/ActivityThread$ActivityClientRecord:packageInfo	Landroid/app/LoadedApk;
    //   179: iconst_0
    //   180: aload_0
    //   181: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   184: invokevirtual 1156	android/app/LoadedApk:makeApplication	(ZLandroid/app/Instrumentation;)Landroid/app/Application;
    //   187: astore 9
    //   189: aload 5
    //   191: ifnull +465 -> 656
    //   194: aload_0
    //   195: aload_1
    //   196: aload 5
    //   198: invokespecial 2027	android/app/ActivityThread:createBaseContextForActivity	(Landroid/app/ActivityThread$ActivityClientRecord;Landroid/app/Activity;)Landroid/content/Context;
    //   201: astore 10
    //   203: aload_1
    //   204: getfield 1999	android/app/ActivityThread$ActivityClientRecord:activityInfo	Landroid/content/pm/ActivityInfo;
    //   207: aload 10
    //   209: invokevirtual 2028	android/content/Context:getPackageManager	()Landroid/content/pm/PackageManager;
    //   212: invokevirtual 2032	android/content/pm/ActivityInfo:loadLabel	(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;
    //   215: astore 11
    //   217: new 237	android/content/res/Configuration
    //   220: dup
    //   221: aload_0
    //   222: getfield 842	android/app/ActivityThread:mCompatConfiguration	Landroid/content/res/Configuration;
    //   225: invokespecial 838	android/content/res/Configuration:<init>	(Landroid/content/res/Configuration;)V
    //   228: astore 12
    //   230: aload 5
    //   232: aload 10
    //   234: aload_0
    //   235: aload_0
    //   236: invokevirtual 2036	android/app/ActivityThread:getInstrumentation	()Landroid/app/Instrumentation;
    //   239: aload_1
    //   240: getfield 584	android/app/ActivityThread$ActivityClientRecord:token	Landroid/os/IBinder;
    //   243: aload_1
    //   244: getfield 2039	android/app/ActivityThread$ActivityClientRecord:ident	I
    //   247: aload 9
    //   249: aload_1
    //   250: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   253: aload_1
    //   254: getfield 1999	android/app/ActivityThread$ActivityClientRecord:activityInfo	Landroid/content/pm/ActivityInfo;
    //   257: aload 11
    //   259: aload_1
    //   260: getfield 2042	android/app/ActivityThread$ActivityClientRecord:parent	Landroid/app/Activity;
    //   263: aload_1
    //   264: getfield 2045	android/app/ActivityThread$ActivityClientRecord:embeddedID	Ljava/lang/String;
    //   267: aload_1
    //   268: getfield 1978	android/app/ActivityThread$ActivityClientRecord:lastNonConfigurationInstances	Landroid/app/Activity$NonConfigurationInstances;
    //   271: aload 12
    //   273: invokevirtual 2048	android/app/Activity:attach	(Landroid/content/Context;Landroid/app/ActivityThread;Landroid/app/Instrumentation;Landroid/os/IBinder;ILandroid/app/Application;Landroid/content/Intent;Landroid/content/pm/ActivityInfo;Ljava/lang/CharSequence;Landroid/app/Activity;Ljava/lang/String;Landroid/app/Activity$NonConfigurationInstances;Landroid/content/res/Configuration;)V
    //   276: aload_2
    //   277: ifnull +9 -> 286
    //   280: aload 5
    //   282: aload_2
    //   283: putfield 1575	android/app/Activity:mIntent	Landroid/content/Intent;
    //   286: aload_1
    //   287: aconst_null
    //   288: putfield 1978	android/app/ActivityThread$ActivityClientRecord:lastNonConfigurationInstances	Landroid/app/Activity$NonConfigurationInstances;
    //   291: aload 5
    //   293: iconst_0
    //   294: putfield 2051	android/app/Activity:mStartedActivity	Z
    //   297: aload_1
    //   298: getfield 1999	android/app/ActivityThread$ActivityClientRecord:activityInfo	Landroid/content/pm/ActivityInfo;
    //   301: invokevirtual 2054	android/content/pm/ActivityInfo:getThemeResource	()I
    //   304: istore 13
    //   306: iload 13
    //   308: ifeq +10 -> 318
    //   311: aload 5
    //   313: iload 13
    //   315: invokevirtual 2057	android/app/Activity:setTheme	(I)V
    //   318: aload 5
    //   320: iconst_0
    //   321: putfield 1471	android/app/Activity:mCalled	Z
    //   324: aload_0
    //   325: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   328: aload 5
    //   330: aload_1
    //   331: getfield 1455	android/app/ActivityThread$ActivityClientRecord:state	Landroid/os/Bundle;
    //   334: invokevirtual 2060	android/app/Instrumentation:callActivityOnCreate	(Landroid/app/Activity;Landroid/os/Bundle;)V
    //   337: aload 5
    //   339: getfield 1471	android/app/Activity:mCalled	Z
    //   342: ifne +112 -> 454
    //   345: new 1434	android/app/SuperNotCalledException
    //   348: dup
    //   349: new 513	java/lang/StringBuilder
    //   352: dup
    //   353: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   356: ldc_w 1480
    //   359: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   362: aload_1
    //   363: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   366: invokevirtual 685	android/content/Intent:getComponent	()Landroid/content/ComponentName;
    //   369: invokevirtual 690	android/content/ComponentName:toShortString	()Ljava/lang/String;
    //   372: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   375: ldc_w 2062
    //   378: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   381: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   384: invokespecial 1483	android/app/SuperNotCalledException:<init>	(Ljava/lang/String;)V
    //   387: athrow
    //   388: astore 8
    //   390: aload 8
    //   392: athrow
    //   393: astore 6
    //   395: aload_0
    //   396: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   399: aload 5
    //   401: aload 6
    //   403: invokevirtual 673	android/app/Instrumentation:onException	(Ljava/lang/Object;Ljava/lang/Throwable;)Z
    //   406: ifne -231 -> 175
    //   409: new 511	java/lang/RuntimeException
    //   412: dup
    //   413: new 513	java/lang/StringBuilder
    //   416: dup
    //   417: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   420: ldc_w 2064
    //   423: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   426: aload 4
    //   428: invokevirtual 764	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   431: ldc_w 692
    //   434: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   437: aload 6
    //   439: invokevirtual 524	java/lang/Exception:toString	()Ljava/lang/String;
    //   442: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   445: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   448: aload 6
    //   450: invokespecial 528	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   453: athrow
    //   454: aload_1
    //   455: aload 5
    //   457: putfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   460: aload_1
    //   461: iconst_1
    //   462: putfield 1581	android/app/ActivityThread$ActivityClientRecord:stopped	Z
    //   465: aload_1
    //   466: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   469: getfield 1461	android/app/Activity:mFinished	Z
    //   472: ifne +13 -> 485
    //   475: aload 5
    //   477: invokevirtual 2067	android/app/Activity:performStart	()V
    //   480: aload_1
    //   481: iconst_0
    //   482: putfield 1581	android/app/ActivityThread$ActivityClientRecord:stopped	Z
    //   485: aload_1
    //   486: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   489: getfield 1461	android/app/Activity:mFinished	Z
    //   492: ifne +23 -> 515
    //   495: aload_1
    //   496: getfield 1455	android/app/ActivityThread$ActivityClientRecord:state	Landroid/os/Bundle;
    //   499: ifnull +16 -> 515
    //   502: aload_0
    //   503: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   506: aload 5
    //   508: aload_1
    //   509: getfield 1455	android/app/ActivityThread$ActivityClientRecord:state	Landroid/os/Bundle;
    //   512: invokevirtual 2070	android/app/Instrumentation:callActivityOnRestoreInstanceState	(Landroid/app/Activity;Landroid/os/Bundle;)V
    //   515: aload_1
    //   516: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   519: getfield 1461	android/app/Activity:mFinished	Z
    //   522: ifne +134 -> 656
    //   525: aload 5
    //   527: iconst_0
    //   528: putfield 1471	android/app/Activity:mCalled	Z
    //   531: aload_0
    //   532: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   535: aload 5
    //   537: aload_1
    //   538: getfield 1455	android/app/ActivityThread$ActivityClientRecord:state	Landroid/os/Bundle;
    //   541: invokevirtual 2073	android/app/Instrumentation:callActivityOnPostCreate	(Landroid/app/Activity;Landroid/os/Bundle;)V
    //   544: aload 5
    //   546: getfield 1471	android/app/Activity:mCalled	Z
    //   549: ifne +107 -> 656
    //   552: new 1434	android/app/SuperNotCalledException
    //   555: dup
    //   556: new 513	java/lang/StringBuilder
    //   559: dup
    //   560: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   563: ldc_w 1480
    //   566: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   569: aload_1
    //   570: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   573: invokevirtual 685	android/content/Intent:getComponent	()Landroid/content/ComponentName;
    //   576: invokevirtual 690	android/content/ComponentName:toShortString	()Ljava/lang/String;
    //   579: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   582: ldc_w 2075
    //   585: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   588: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   591: invokespecial 1483	android/app/SuperNotCalledException:<init>	(Ljava/lang/String;)V
    //   594: athrow
    //   595: astore 7
    //   597: aload_0
    //   598: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   601: aload 5
    //   603: aload 7
    //   605: invokevirtual 673	android/app/Instrumentation:onException	(Ljava/lang/Object;Ljava/lang/Throwable;)Z
    //   608: ifne +66 -> 674
    //   611: new 511	java/lang/RuntimeException
    //   614: dup
    //   615: new 513	java/lang/StringBuilder
    //   618: dup
    //   619: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   622: ldc_w 2077
    //   625: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   628: aload 4
    //   630: invokevirtual 764	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   633: ldc_w 692
    //   636: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   639: aload 7
    //   641: invokevirtual 524	java/lang/Exception:toString	()Ljava/lang/String;
    //   644: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   647: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   650: aload 7
    //   652: invokespecial 528	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   655: athrow
    //   656: aload_1
    //   657: iconst_1
    //   658: putfield 1488	android/app/ActivityThread$ActivityClientRecord:paused	Z
    //   661: aload_0
    //   662: getfield 175	android/app/ActivityThread:mActivities	Ljava/util/HashMap;
    //   665: aload_1
    //   666: getfield 584	android/app/ActivityThread$ActivityClientRecord:token	Landroid/os/IBinder;
    //   669: aload_1
    //   670: invokevirtual 812	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   673: pop
    //   674: aload 5
    //   676: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	677	0	this	ActivityThread
    //   0	677	1	paramActivityClientRecord	ActivityClientRecord
    //   0	677	2	paramIntent	Intent
    //   4	11	3	localActivityInfo	ActivityInfo
    //   36	593	4	localComponentName	ComponentName
    //   111	564	5	localActivity	Activity
    //   393	56	6	localException1	Exception
    //   595	56	7	localException2	Exception
    //   388	3	8	localSuperNotCalledException	SuperNotCalledException
    //   187	61	9	localApplication	Application
    //   201	32	10	localContext	Context
    //   215	43	11	localCharSequence	CharSequence
    //   228	44	12	localConfiguration	Configuration
    //   304	10	13	i	int
    //   120	51	15	localClassLoader	ClassLoader
    //   86	16	16	str1	String
    //   95	9	17	str2	String
    // Exception table:
    //   from	to	target	type
    //   175	189	388	android/app/SuperNotCalledException
    //   194	276	388	android/app/SuperNotCalledException
    //   280	286	388	android/app/SuperNotCalledException
    //   286	306	388	android/app/SuperNotCalledException
    //   311	318	388	android/app/SuperNotCalledException
    //   318	388	388	android/app/SuperNotCalledException
    //   454	485	388	android/app/SuperNotCalledException
    //   485	515	388	android/app/SuperNotCalledException
    //   515	595	388	android/app/SuperNotCalledException
    //   656	674	388	android/app/SuperNotCalledException
    //   113	175	393	java/lang/Exception
    //   175	189	595	java/lang/Exception
    //   194	276	595	java/lang/Exception
    //   280	286	595	java/lang/Exception
    //   286	306	595	java/lang/Exception
    //   311	318	595	java/lang/Exception
    //   318	388	595	java/lang/Exception
    //   454	485	595	java/lang/Exception
    //   485	515	595	java/lang/Exception
    //   515	595	595	java/lang/Exception
    //   656	674	595	java/lang/Exception
  }
  
  /* Error */
  private void performStopActivityInner(ActivityClientRecord paramActivityClientRecord, StopInfo paramStopInfo, boolean paramBoolean1, boolean paramBoolean2)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnull +24 -> 25
    //   4: iload_3
    //   5: ifne +72 -> 77
    //   8: aload_1
    //   9: getfield 1581	android/app/ActivityThread$ActivityClientRecord:stopped	Z
    //   12: ifeq +65 -> 77
    //   15: aload_1
    //   16: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   19: getfield 1461	android/app/Activity:mFinished	Z
    //   22: ifeq +4 -> 26
    //   25: return
    //   26: new 511	java/lang/RuntimeException
    //   29: dup
    //   30: new 513	java/lang/StringBuilder
    //   33: dup
    //   34: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   37: ldc_w 2079
    //   40: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   43: aload_1
    //   44: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   47: invokevirtual 685	android/content/Intent:getComponent	()Landroid/content/ComponentName;
    //   50: invokevirtual 690	android/content/ComponentName:toShortString	()Ljava/lang/String;
    //   53: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   56: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   59: invokespecial 1055	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   62: astore 10
    //   64: ldc 31
    //   66: aload 10
    //   68: invokevirtual 2082	java/lang/RuntimeException:getMessage	()Ljava/lang/String;
    //   71: aload 10
    //   73: invokestatic 1250	android/util/Slog:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   76: pop
    //   77: aload_2
    //   78: ifnull +19 -> 97
    //   81: aload_2
    //   82: aconst_null
    //   83: putfield 2085	android/app/ActivityThread$StopInfo:thumbnail	Landroid/graphics/Bitmap;
    //   86: aload_2
    //   87: aload_1
    //   88: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   91: invokevirtual 1618	android/app/Activity:onCreateDescription	()Ljava/lang/CharSequence;
    //   94: putfield 2089	android/app/ActivityThread$StopInfo:description	Ljava/lang/CharSequence;
    //   97: aload_1
    //   98: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   101: getfield 1461	android/app/Activity:mFinished	Z
    //   104: ifne +50 -> 154
    //   107: iload 4
    //   109: ifeq +45 -> 154
    //   112: aload_1
    //   113: getfield 1455	android/app/ActivityThread$ActivityClientRecord:state	Landroid/os/Bundle;
    //   116: ifnonnull +131 -> 247
    //   119: new 1583	android/os/Bundle
    //   122: dup
    //   123: invokespecial 1584	android/os/Bundle:<init>	()V
    //   126: astore 6
    //   128: aload 6
    //   130: iconst_0
    //   131: invokevirtual 1588	android/os/Bundle:setAllowFds	(Z)Z
    //   134: pop
    //   135: aload_0
    //   136: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   139: aload_1
    //   140: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   143: aload 6
    //   145: invokevirtual 1592	android/app/Instrumentation:callActivityOnSaveInstanceState	(Landroid/app/Activity;Landroid/os/Bundle;)V
    //   148: aload_1
    //   149: aload 6
    //   151: putfield 1455	android/app/ActivityThread$ActivityClientRecord:state	Landroid/os/Bundle;
    //   154: iload_3
    //   155: ifne +15 -> 170
    //   158: aload_1
    //   159: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   162: invokevirtual 1669	android/app/Activity:performStop	()V
    //   165: aload_1
    //   166: iconst_1
    //   167: putfield 1581	android/app/ActivityThread$ActivityClientRecord:stopped	Z
    //   170: aload_1
    //   171: iconst_1
    //   172: putfield 1488	android/app/ActivityThread$ActivityClientRecord:paused	Z
    //   175: return
    //   176: astore 9
    //   178: aload_0
    //   179: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   182: aload_1
    //   183: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   186: aload 9
    //   188: invokevirtual 673	android/app/Instrumentation:onException	(Ljava/lang/Object;Ljava/lang/Throwable;)Z
    //   191: ifne -94 -> 97
    //   194: new 511	java/lang/RuntimeException
    //   197: dup
    //   198: new 513	java/lang/StringBuilder
    //   201: dup
    //   202: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   205: ldc_w 2091
    //   208: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   211: aload_1
    //   212: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   215: invokevirtual 685	android/content/Intent:getComponent	()Landroid/content/ComponentName;
    //   218: invokevirtual 690	android/content/ComponentName:toShortString	()Ljava/lang/String;
    //   221: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   224: ldc_w 692
    //   227: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   230: aload 9
    //   232: invokevirtual 524	java/lang/Exception:toString	()Ljava/lang/String;
    //   235: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   238: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   241: aload 9
    //   243: invokespecial 528	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   246: athrow
    //   247: aload_1
    //   248: getfield 1455	android/app/ActivityThread$ActivityClientRecord:state	Landroid/os/Bundle;
    //   251: pop
    //   252: goto -98 -> 154
    //   255: astore 5
    //   257: aload_0
    //   258: getfield 479	android/app/ActivityThread:mInstrumentation	Landroid/app/Instrumentation;
    //   261: aload_1
    //   262: getfield 560	android/app/ActivityThread$ActivityClientRecord:activity	Landroid/app/Activity;
    //   265: aload 5
    //   267: invokevirtual 673	android/app/Instrumentation:onException	(Ljava/lang/Object;Ljava/lang/Throwable;)Z
    //   270: ifne -105 -> 165
    //   273: new 511	java/lang/RuntimeException
    //   276: dup
    //   277: new 513	java/lang/StringBuilder
    //   280: dup
    //   281: invokespecial 514	java/lang/StringBuilder:<init>	()V
    //   284: ldc_w 1674
    //   287: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   290: aload_1
    //   291: getfield 679	android/app/ActivityThread$ActivityClientRecord:intent	Landroid/content/Intent;
    //   294: invokevirtual 685	android/content/Intent:getComponent	()Landroid/content/ComponentName;
    //   297: invokevirtual 690	android/content/ComponentName:toShortString	()Ljava/lang/String;
    //   300: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   303: ldc_w 692
    //   306: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   309: aload 5
    //   311: invokevirtual 524	java/lang/Exception:toString	()Ljava/lang/String;
    //   314: invokevirtual 520	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   317: invokevirtual 525	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   320: aload 5
    //   322: invokespecial 528	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   325: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	326	0	this	ActivityThread
    //   0	326	1	paramActivityClientRecord	ActivityClientRecord
    //   0	326	2	paramStopInfo	StopInfo
    //   0	326	3	paramBoolean1	boolean
    //   0	326	4	paramBoolean2	boolean
    //   255	66	5	localException1	Exception
    //   126	24	6	localBundle	Bundle
    //   176	66	9	localException2	Exception
    //   62	10	10	localRuntimeException	RuntimeException
    // Exception table:
    //   from	to	target	type
    //   81	97	176	java/lang/Exception
    //   158	165	255	java/lang/Exception
  }
  
  private void queueOrSendMessage(int paramInt, Object paramObject)
  {
    queueOrSendMessage(paramInt, paramObject, 0, 0);
  }
  
  private void queueOrSendMessage(int paramInt1, Object paramObject, int paramInt2)
  {
    queueOrSendMessage(paramInt1, paramObject, paramInt2, 0);
  }
  
  private void queueOrSendMessage(int paramInt1, Object paramObject, int paramInt2, int paramInt3)
  {
    try
    {
      Message localMessage = Message.obtain();
      localMessage.what = paramInt1;
      localMessage.obj = paramObject;
      localMessage.arg1 = paramInt2;
      localMessage.arg2 = paramInt3;
      this.mH.sendMessage(localMessage);
      return;
    }
    finally {}
  }
  
  private static String safeToComponentShortString(Intent paramIntent)
  {
    ComponentName localComponentName = paramIntent.getComponent();
    if (localComponentName == null) {
      return "[Unknown]";
    }
    return localComponentName.toShortString();
  }
  
  private void setupGraphicsSupport(LoadedApk paramLoadedApk, File paramFile)
  {
    if (Process.isIsolated()) {}
    for (;;)
    {
      return;
      try
      {
        int i = Process.myUid();
        String[] arrayOfString = getPackageManager().getPackagesForUid(i);
        if ((arrayOfString != null) && (arrayOfString.length == 1))
        {
          HardwareRenderer.setupDiskCache(paramFile);
          RenderScript.setupDiskCache(paramFile);
          return;
        }
      }
      catch (RemoteException localRemoteException) {}
    }
  }
  
  public static ActivityThread systemMain()
  {
    HardwareRenderer.disable(true);
    ActivityThread localActivityThread = new ActivityThread();
    localActivityThread.attach(true);
    return localActivityThread;
  }
  
  private void updateDefaultDensity()
  {
    if ((this.mCurDefaultDisplayDpi != 0) && (this.mCurDefaultDisplayDpi != DisplayMetrics.DENSITY_DEVICE) && (!this.mDensityCompatMode))
    {
      Slog.i("ActivityThread", "Switching default density from " + DisplayMetrics.DENSITY_DEVICE + " to " + this.mCurDefaultDisplayDpi);
      DisplayMetrics.DENSITY_DEVICE = this.mCurDefaultDisplayDpi;
      Bitmap.setDefaultDensity(160);
    }
  }
  
  private void updateVisibility(ActivityClientRecord paramActivityClientRecord, boolean paramBoolean)
  {
    View localView = paramActivityClientRecord.activity.mDecor;
    if (localView != null)
    {
      if (!paramBoolean) {
        break label103;
      }
      if (!paramActivityClientRecord.activity.mVisibleFromServer)
      {
        paramActivityClientRecord.activity.mVisibleFromServer = true;
        this.mNumVisibleActivities = (1 + this.mNumVisibleActivities);
        if (paramActivityClientRecord.activity.mVisibleFromClient) {
          paramActivityClientRecord.activity.makeVisible();
        }
      }
      if (paramActivityClientRecord.newConfig != null)
      {
        performConfigurationChanged(paramActivityClientRecord.activity, paramActivityClientRecord.newConfig);
        freeTextLayoutCachesIfNeeded(paramActivityClientRecord.activity.mCurrentConfig.diff(paramActivityClientRecord.newConfig));
        paramActivityClientRecord.newConfig = null;
      }
    }
    label103:
    while (!paramActivityClientRecord.activity.mVisibleFromServer) {
      return;
    }
    paramActivityClientRecord.activity.mVisibleFromServer = false;
    this.mNumVisibleActivities = (-1 + this.mNumVisibleActivities);
    localView.setVisibility(4);
  }
  
  public final IContentProvider acquireExistingProvider(Context paramContext, String paramString, int paramInt, boolean paramBoolean)
  {
    synchronized (this.mProviderMap)
    {
      ProviderKey localProviderKey = new ProviderKey(paramString, paramInt);
      ProviderClientRecord localProviderClientRecord = (ProviderClientRecord)this.mProviderMap.get(localProviderKey);
      if (localProviderClientRecord == null) {
        return null;
      }
      IContentProvider localIContentProvider = localProviderClientRecord.mProvider;
      IBinder localIBinder = localIContentProvider.asBinder();
      if (!localIBinder.isBinderAlive())
      {
        Log.i("ActivityThread", "Acquiring provider " + paramString + " for user " + paramInt + ": existing object's process dead");
        handleUnstableProviderDiedLocked(localIBinder, true);
        return null;
      }
      ProviderRefCount localProviderRefCount = (ProviderRefCount)this.mProviderRefCountMap.get(localIBinder);
      if (localProviderRefCount != null) {
        incProviderRefLocked(localProviderRefCount, paramBoolean);
      }
      return localIContentProvider;
    }
  }
  
  public final IContentProvider acquireProvider(Context paramContext, String paramString, int paramInt, boolean paramBoolean)
  {
    IContentProvider localIContentProvider = acquireExistingProvider(paramContext, paramString, paramInt, paramBoolean);
    if (localIContentProvider != null) {
      return localIContentProvider;
    }
    try
    {
      IActivityManager.ContentProviderHolder localContentProviderHolder2 = ActivityManagerNative.getDefault().getContentProvider(getApplicationThread(), paramString, paramInt, paramBoolean);
      localContentProviderHolder1 = localContentProviderHolder2;
    }
    catch (RemoteException localRemoteException)
    {
      for (;;)
      {
        IActivityManager.ContentProviderHolder localContentProviderHolder1 = null;
      }
    }
    if (localContentProviderHolder1 == null)
    {
      Slog.e("ActivityThread", "Failed to find provider info for " + paramString);
      return null;
    }
    return installProvider(paramContext, localContentProviderHolder1, localContentProviderHolder1.info, true, localContentProviderHolder1.noReleaseNeeded, paramBoolean).provider;
  }
  
  final Configuration applyCompatConfiguration(int paramInt)
  {
    Configuration localConfiguration = this.mConfiguration;
    if (this.mCompatConfiguration == null) {
      this.mCompatConfiguration = new Configuration();
    }
    this.mCompatConfiguration.setTo(this.mConfiguration);
    if ((this.mResCompatibilityInfo != null) && (!this.mResCompatibilityInfo.supportsScreen()))
    {
      this.mResCompatibilityInfo.applyToConfiguration(paramInt, this.mCompatConfiguration);
      localConfiguration = this.mCompatConfiguration;
    }
    return localConfiguration;
  }
  
  Configuration applyConfigCompatMainThread(int paramInt, Configuration paramConfiguration, CompatibilityInfo paramCompatibilityInfo)
  {
    if (paramConfiguration == null) {
      return null;
    }
    if ((paramCompatibilityInfo != null) && (!paramCompatibilityInfo.supportsScreen()))
    {
      this.mMainThreadConfig.setTo(paramConfiguration);
      paramConfiguration = this.mMainThreadConfig;
      paramCompatibilityInfo.applyToConfiguration(paramInt, paramConfiguration);
    }
    return paramConfiguration;
  }
  
  public final void applyConfigurationToResources(Configuration paramConfiguration)
  {
    synchronized (this.mPackages)
    {
      applyConfigurationToResourcesLocked(paramConfiguration, null);
      return;
    }
  }
  
  final boolean applyConfigurationToResourcesLocked(Configuration paramConfiguration, CompatibilityInfo paramCompatibilityInfo)
  {
    if (this.mResConfiguration == null) {
      this.mResConfiguration = new Configuration();
    }
    if ((!this.mResConfiguration.isOtherSeqNewer(paramConfiguration)) && (paramCompatibilityInfo == null)) {
      return false;
    }
    int i = this.mResConfiguration.updateFrom(paramConfiguration);
    flushDisplayMetricsLocked();
    DisplayMetrics localDisplayMetrics1 = getDisplayMetricsLocked(0, null);
    if ((paramCompatibilityInfo != null) && ((this.mResCompatibilityInfo == null) || (!this.mResCompatibilityInfo.equals(paramCompatibilityInfo))))
    {
      this.mResCompatibilityInfo = paramCompatibilityInfo;
      i |= 0xD00;
    }
    if (paramConfiguration.locale != null) {
      Locale.setDefault(paramConfiguration.locale);
    }
    Resources.updateSystemConfiguration(paramConfiguration, localDisplayMetrics1, paramCompatibilityInfo);
    ApplicationPackageManager.configurationChanged();
    Configuration localConfiguration1 = null;
    Iterator localIterator = this.mActiveResources.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      Resources localResources = (Resources)((WeakReference)localEntry.getValue()).get();
      if (localResources != null)
      {
        int j = ((ResourcesKey)localEntry.getKey()).mDisplayId;
        if (j == 0) {}
        DisplayMetrics localDisplayMetrics2;
        for (int k = 1;; k = 0)
        {
          localDisplayMetrics2 = localDisplayMetrics1;
          Configuration localConfiguration2 = ((ResourcesKey)localEntry.getKey()).mOverrideConfiguration;
          if ((k != 0) && (localConfiguration2 == null)) {
            break label301;
          }
          if (localConfiguration1 == null) {
            localConfiguration1 = new Configuration();
          }
          localConfiguration1.setTo(paramConfiguration);
          if (k == 0)
          {
            localDisplayMetrics2 = getDisplayMetricsLocked(j, null);
            applyNonDefaultDisplayMetricsToConfigurationLocked(localDisplayMetrics2, localConfiguration1);
          }
          if (localConfiguration2 != null) {
            localConfiguration1.updateFrom(localConfiguration2);
          }
          localResources.updateConfiguration(localConfiguration1, localDisplayMetrics2, paramCompatibilityInfo);
          break;
        }
        label301:
        localResources.updateConfiguration(paramConfiguration, localDisplayMetrics2, paramCompatibilityInfo);
      }
      else
      {
        localIterator.remove();
      }
    }
    return i != 0;
  }
  
  final void applyNonDefaultDisplayMetricsToConfigurationLocked(DisplayMetrics paramDisplayMetrics, Configuration paramConfiguration)
  {
    paramConfiguration.touchscreen = 1;
    paramConfiguration.densityDpi = paramDisplayMetrics.densityDpi;
    paramConfiguration.screenWidthDp = ((int)(paramDisplayMetrics.widthPixels / paramDisplayMetrics.density));
    paramConfiguration.screenHeightDp = ((int)(paramDisplayMetrics.heightPixels / paramDisplayMetrics.density));
    int i = Configuration.resetScreenLayout(paramConfiguration.screenLayout);
    if (paramDisplayMetrics.widthPixels > paramDisplayMetrics.heightPixels) {
      paramConfiguration.orientation = 2;
    }
    for (paramConfiguration.screenLayout = Configuration.reduceScreenLayout(i, paramConfiguration.screenWidthDp, paramConfiguration.screenHeightDp);; paramConfiguration.screenLayout = Configuration.reduceScreenLayout(i, paramConfiguration.screenHeightDp, paramConfiguration.screenWidthDp))
    {
      paramConfiguration.smallestScreenWidthDp = paramConfiguration.screenWidthDp;
      paramConfiguration.compatScreenWidthDp = paramConfiguration.screenWidthDp;
      paramConfiguration.compatScreenHeightDp = paramConfiguration.screenHeightDp;
      paramConfiguration.compatSmallestScreenWidthDp = paramConfiguration.smallestScreenWidthDp;
      return;
      paramConfiguration.orientation = 1;
    }
  }
  
  ArrayList<ComponentCallbacks2> collectComponentCallbacks(boolean paramBoolean, Configuration paramConfiguration)
  {
    ArrayList localArrayList = new ArrayList();
    for (;;)
    {
      ActivityClientRecord localActivityClientRecord;
      Configuration localConfiguration;
      synchronized (this.mPackages)
      {
        int i = this.mAllApplications.size();
        int j = 0;
        if (j < i)
        {
          localArrayList.add(this.mAllApplications.get(j));
          j++;
          continue;
        }
        if (this.mActivities.size() <= 0) {
          break;
        }
        Iterator localIterator3 = this.mActivities.values().iterator();
        if (!localIterator3.hasNext()) {
          break;
        }
        localActivityClientRecord = (ActivityClientRecord)localIterator3.next();
        Activity localActivity = localActivityClientRecord.activity;
        if (localActivity == null) {
          continue;
        }
        localConfiguration = applyConfigCompatMainThread(this.mCurDefaultDisplayDpi, paramConfiguration, localActivityClientRecord.packageInfo.mCompatibilityInfo.getIfNeeded());
        if ((!localActivityClientRecord.activity.mFinished) && ((paramBoolean) || (!localActivityClientRecord.paused))) {
          localArrayList.add(localActivity);
        }
      }
      if (localConfiguration != null) {
        localActivityClientRecord.newConfig = localConfiguration;
      }
    }
    if (this.mServices.size() > 0)
    {
      Iterator localIterator2 = this.mServices.values().iterator();
      while (localIterator2.hasNext()) {
        localArrayList.add((Service)localIterator2.next());
      }
    }
    synchronized (this.mProviderMap)
    {
      if (this.mLocalProviders.size() > 0)
      {
        Iterator localIterator1 = this.mLocalProviders.values().iterator();
        if (localIterator1.hasNext()) {
          localArrayList.add(((ProviderClientRecord)localIterator1.next()).mLocalProvider);
        }
      }
    }
    return localArrayList;
  }
  
  final void completeRemoveProvider(ProviderRefCount paramProviderRefCount)
  {
    synchronized (this.mProviderMap)
    {
      if (!paramProviderRefCount.removePending) {
        return;
      }
      IBinder localIBinder = paramProviderRefCount.holder.provider.asBinder();
      if ((ProviderRefCount)this.mProviderRefCountMap.get(localIBinder) == paramProviderRefCount) {
        this.mProviderRefCountMap.remove(localIBinder);
      }
      Iterator localIterator = this.mProviderMap.values().iterator();
      while (localIterator.hasNext()) {
        if (((ProviderClientRecord)localIterator.next()).mProvider.asBinder() == localIBinder) {
          localIterator.remove();
        }
      }
    }
    try
    {
      ActivityManagerNative.getDefault().removeContentProvider(paramProviderRefCount.holder.connection, false);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  void doGcIfNeeded()
  {
    this.mGcIdlerScheduled = false;
    long l = SystemClock.uptimeMillis();
    if (5000L + BinderInternal.getLastGcTime() < l) {
      BinderInternal.forceGc("bg");
    }
  }
  
  void ensureJitEnabled()
  {
    if (!this.mJitEnabled)
    {
      this.mJitEnabled = true;
      VMRuntime.getRuntime().startJitCompilation();
    }
  }
  
  final void finishInstrumentation(int paramInt, Bundle paramBundle)
  {
    IActivityManager localIActivityManager = ActivityManagerNative.getDefault();
    if ((this.mProfiler.profileFile != null) && (this.mProfiler.handlingProfiling) && (this.mProfiler.profileFd == null)) {
      Debug.stopMethodTracing();
    }
    try
    {
      localIActivityManager.finishInstrumentation(this.mAppThread, paramInt, paramBundle);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  final void freeTextLayoutCachesIfNeeded(int paramInt)
  {
    if (paramInt != 0) {
      if ((paramInt & 0x4) == 0) {
        break label20;
      }
    }
    label20:
    for (int i = 1;; i = 0)
    {
      if (i != 0) {
        Canvas.freeTextLayoutCaches();
      }
      return;
    }
  }
  
  public final Activity getActivity(IBinder paramIBinder)
  {
    return ((ActivityClientRecord)this.mActivities.get(paramIBinder)).activity;
  }
  
  public Application getApplication()
  {
    return this.mInitialApplication;
  }
  
  public ApplicationThread getApplicationThread()
  {
    return this.mAppThread;
  }
  
  public Configuration getConfiguration()
  {
    return this.mResConfiguration;
  }
  
  DisplayMetrics getDisplayMetricsLocked(int paramInt, CompatibilityInfo paramCompatibilityInfo)
  {
    int i;
    if (paramInt == 0)
    {
      i = 1;
      if (i == 0) {
        break label36;
      }
    }
    label36:
    for (DisplayMetrics localDisplayMetrics1 = (DisplayMetrics)this.mDefaultDisplayMetrics.get(paramCompatibilityInfo);; localDisplayMetrics1 = null)
    {
      if (localDisplayMetrics1 == null) {
        break label42;
      }
      return localDisplayMetrics1;
      i = 0;
      break;
    }
    label42:
    DisplayMetrics localDisplayMetrics2 = new DisplayMetrics();
    DisplayManagerGlobal localDisplayManagerGlobal = DisplayManagerGlobal.getInstance();
    if (localDisplayManagerGlobal == null)
    {
      localDisplayMetrics2.setToDefaults();
      return localDisplayMetrics2;
    }
    if (i != 0) {
      this.mDefaultDisplayMetrics.put(paramCompatibilityInfo, localDisplayMetrics2);
    }
    CompatibilityInfoHolder localCompatibilityInfoHolder = new CompatibilityInfoHolder();
    localCompatibilityInfoHolder.set(paramCompatibilityInfo);
    Display localDisplay = localDisplayManagerGlobal.getCompatibleDisplay(paramInt, localCompatibilityInfoHolder);
    if (localDisplay != null) {
      localDisplay.getMetrics(localDisplayMetrics2);
    }
    for (;;)
    {
      return localDisplayMetrics2;
      localDisplayMetrics2.setToDefaults();
    }
  }
  
  final Handler getHandler()
  {
    return this.mH;
  }
  
  public Instrumentation getInstrumentation()
  {
    return this.mInstrumentation;
  }
  
  public int getIntCoreSetting(String paramString, int paramInt)
  {
    synchronized (this.mPackages)
    {
      if (this.mCoreSettings != null)
      {
        int i = this.mCoreSettings.getInt(paramString, paramInt);
        return i;
      }
      return paramInt;
    }
  }
  
  public Looper getLooper()
  {
    return this.mLooper;
  }
  
  public final LoadedApk getPackageInfo(ApplicationInfo paramApplicationInfo, CompatibilityInfo paramCompatibilityInfo, int paramInt)
  {
    if ((paramInt & 0x1) != 0) {}
    boolean bool2;
    for (boolean bool1 = true;; bool1 = false)
    {
      bool2 = false;
      if (bool1)
      {
        int i = paramApplicationInfo.uid;
        bool2 = false;
        if (i != 0)
        {
          int j = paramApplicationInfo.uid;
          bool2 = false;
          if (j != 1000) {
            if (this.mBoundApplication != null)
            {
              boolean bool3 = UserHandle.isSameApp(paramApplicationInfo.uid, this.mBoundApplication.appInfo.uid);
              bool2 = false;
              if (bool3) {}
            }
            else
            {
              bool2 = true;
            }
          }
        }
      }
      if (((paramInt & 0x3) != 1) || (!bool2)) {
        break;
      }
      String str = "Requesting code from " + paramApplicationInfo.packageName + " (with uid " + paramApplicationInfo.uid + ")";
      if (this.mBoundApplication != null) {
        str = str + " to be run in process " + this.mBoundApplication.processName + " (with uid " + this.mBoundApplication.appInfo.uid + ")";
      }
      throw new SecurityException(str);
    }
    return getPackageInfo(paramApplicationInfo, paramCompatibilityInfo, null, bool2, bool1);
  }
  
  public final LoadedApk getPackageInfo(String paramString, CompatibilityInfo paramCompatibilityInfo, int paramInt)
  {
    return getPackageInfo(paramString, paramCompatibilityInfo, paramInt, UserHandle.myUserId());
  }
  
  public final LoadedApk getPackageInfo(String paramString, CompatibilityInfo paramCompatibilityInfo, int paramInt1, int paramInt2)
  {
    HashMap localHashMap = this.mPackages;
    if ((paramInt1 & 0x1) != 0) {}
    for (;;)
    {
      try
      {
        localWeakReference = (WeakReference)this.mPackages.get(paramString);
        if (localWeakReference == null) {
          break label224;
        }
        localLoadedApk = (LoadedApk)localWeakReference.get();
        if ((localLoadedApk == null) || ((localLoadedApk.mResources != null) && (!localLoadedApk.mResources.getAssets().isUpToDate()))) {
          break label177;
        }
        if ((!localLoadedApk.isSecurityViolation()) || ((paramInt1 & 0x2) != 0)) {
          break label171;
        }
        throw new SecurityException("Requesting code from " + paramString + " to be run in process " + this.mBoundApplication.processName + "/" + this.mBoundApplication.appInfo.uid);
      }
      finally {}
      WeakReference localWeakReference = (WeakReference)this.mResourcePackages.get(paramString);
      continue;
      label171:
      return localLoadedApk;
      try
      {
        label177:
        ApplicationInfo localApplicationInfo2 = getPackageManager().getApplicationInfo(paramString, 1024, paramInt2);
        localApplicationInfo1 = localApplicationInfo2;
      }
      catch (RemoteException localRemoteException)
      {
        for (;;)
        {
          ApplicationInfo localApplicationInfo1 = null;
        }
      }
      if (localApplicationInfo1 != null) {
        return getPackageInfo(localApplicationInfo1, paramCompatibilityInfo, paramInt1);
      }
      return null;
      label224:
      LoadedApk localLoadedApk = null;
    }
  }
  
  public final LoadedApk getPackageInfoNoCheck(ApplicationInfo paramApplicationInfo, CompatibilityInfo paramCompatibilityInfo)
  {
    return getPackageInfo(paramApplicationInfo, paramCompatibilityInfo, null, false, true);
  }
  
  public String getProcessName()
  {
    return this.mBoundApplication.processName;
  }
  
  public String getProfileFilePath()
  {
    return this.mProfiler.profileFile;
  }
  
  public ContextImpl getSystemContext()
  {
    try
    {
      if (mSystemContext == null)
      {
        ContextImpl localContextImpl = ContextImpl.createSystemContext(this);
        localContextImpl.init(new LoadedApk(this, "android", localContextImpl, null, CompatibilityInfo.DEFAULT_COMPATIBILITY_INFO), null, this);
        localContextImpl.getResources().updateConfiguration(getConfiguration(), getDisplayMetricsLocked(0, CompatibilityInfo.DEFAULT_COMPATIBILITY_INFO));
        mSystemContext = localContextImpl;
      }
      return mSystemContext;
    }
    finally {}
  }
  
  Resources getTopLevelResources(String paramString, int paramInt, Configuration paramConfiguration, LoadedApk paramLoadedApk)
  {
    return getTopLevelResources(paramString, paramInt, paramConfiguration, paramLoadedApk.mCompatibilityInfo.get());
  }
  
  Resources getTopLevelResources(String paramString, int paramInt, Configuration paramConfiguration, CompatibilityInfo paramCompatibilityInfo)
  {
    ResourcesKey localResourcesKey = new ResourcesKey(paramString, paramInt, paramConfiguration, paramCompatibilityInfo.applicationScale);
    for (;;)
    {
      Resources localResources2;
      synchronized (this.mPackages)
      {
        WeakReference localWeakReference1 = (WeakReference)this.mActiveResources.get(localResourcesKey);
        if (localWeakReference1 == null) {
          break label326;
        }
        localResources1 = (Resources)localWeakReference1.get();
        if ((localResources1 != null) && (localResources1.getAssets().isUpToDate())) {
          return localResources1;
        }
        AssetManager localAssetManager = new AssetManager();
        int i = localAssetManager.addAssetPath(paramString);
        localObject2 = null;
        if (i == 0) {
          break label323;
        }
        DisplayMetrics localDisplayMetrics = getDisplayMetricsLocked(paramInt, null);
        if (paramInt == 0)
        {
          j = 1;
          if ((j != 0) && (localResourcesKey.mOverrideConfiguration == null)) {
            break label288;
          }
          localConfiguration = new Configuration(getConfiguration());
          if (j == 0) {
            applyNonDefaultDisplayMetricsToConfigurationLocked(localDisplayMetrics, localConfiguration);
          }
          if (localResourcesKey.mOverrideConfiguration != null) {
            localConfiguration.updateFrom(localResourcesKey.mOverrideConfiguration);
          }
          localResources2 = new Resources(localAssetManager, localDisplayMetrics, localConfiguration, paramCompatibilityInfo);
          synchronized (this.mPackages)
          {
            WeakReference localWeakReference2 = (WeakReference)this.mActiveResources.get(localResourcesKey);
            Resources localResources3 = null;
            if (localWeakReference2 != null) {
              localResources3 = (Resources)localWeakReference2.get();
            }
            if ((localResources3 == null) || (!localResources3.getAssets().isUpToDate())) {
              break label297;
            }
            localResources2.getAssets().close();
            return localResources3;
          }
        }
      }
      int j = 0;
      continue;
      label288:
      Configuration localConfiguration = getConfiguration();
      continue;
      label297:
      this.mActiveResources.put(localResourcesKey, new WeakReference(localResources2));
      Object localObject2 = localResources2;
      label323:
      return (Resources)localObject2;
      label326:
      Resources localResources1 = null;
    }
  }
  
  final void handleActivityConfigurationChanged(IBinder paramIBinder)
  {
    ActivityClientRecord localActivityClientRecord = (ActivityClientRecord)this.mActivities.get(paramIBinder);
    if ((localActivityClientRecord == null) || (localActivityClientRecord.activity == null)) {
      return;
    }
    performConfigurationChanged(localActivityClientRecord.activity, this.mCompatConfiguration);
    freeTextLayoutCachesIfNeeded(localActivityClientRecord.activity.mCurrentConfig.diff(this.mCompatConfiguration));
  }
  
  final void handleConfigurationChanged(Configuration paramConfiguration, CompatibilityInfo paramCompatibilityInfo)
  {
    synchronized (this.mPackages)
    {
      if (this.mPendingConfiguration != null)
      {
        if (!this.mPendingConfiguration.isOtherSeqNewer(paramConfiguration))
        {
          paramConfiguration = this.mPendingConfiguration;
          this.mCurDefaultDisplayDpi = paramConfiguration.densityDpi;
          updateDefaultDensity();
        }
        this.mPendingConfiguration = null;
      }
      if (paramConfiguration == null) {
        return;
      }
      applyConfigurationToResourcesLocked(paramConfiguration, paramCompatibilityInfo);
      if (this.mConfiguration == null) {
        this.mConfiguration = new Configuration();
      }
      if ((!this.mConfiguration.isOtherSeqNewer(paramConfiguration)) && (paramCompatibilityInfo == null)) {
        return;
      }
    }
    int i = this.mConfiguration.diff(paramConfiguration);
    this.mConfiguration.updateFrom(paramConfiguration);
    Configuration localConfiguration = applyCompatConfiguration(this.mCurDefaultDisplayDpi);
    ArrayList localArrayList = collectComponentCallbacks(false, localConfiguration);
    WindowManagerGlobal.getInstance().trimLocalMemory();
    freeTextLayoutCachesIfNeeded(i);
    if (localArrayList != null)
    {
      int j = localArrayList.size();
      for (int k = 0; k < j; k++) {
        performConfigurationChanged((ComponentCallbacks2)localArrayList.get(k), localConfiguration);
      }
    }
  }
  
  final void handleDispatchPackageBroadcast(int paramInt, String[] paramArrayOfString)
  {
    boolean bool = false;
    if (paramArrayOfString != null)
    {
      int i = -1 + paramArrayOfString.length;
      if (i >= 0)
      {
        if (!bool)
        {
          WeakReference localWeakReference1 = (WeakReference)this.mPackages.get(paramArrayOfString[i]);
          if ((localWeakReference1 == null) || (localWeakReference1.get() == null)) {
            break label82;
          }
        }
        for (bool = true;; bool = true)
        {
          label82:
          WeakReference localWeakReference2;
          do
          {
            this.mPackages.remove(paramArrayOfString[i]);
            this.mResourcePackages.remove(paramArrayOfString[i]);
            i--;
            break;
            localWeakReference2 = (WeakReference)this.mResourcePackages.get(paramArrayOfString[i]);
          } while ((localWeakReference2 == null) || (localWeakReference2.get() == null));
        }
      }
    }
    ApplicationPackageManager.handlePackageBroadcast(paramInt, paramArrayOfString, bool);
  }
  
  final void handleLowMemory()
  {
    ArrayList localArrayList = collectComponentCallbacks(true, null);
    int i = localArrayList.size();
    for (int j = 0; j < i; j++) {
      ((ComponentCallbacks2)localArrayList.get(j)).onLowMemory();
    }
    if (Process.myUid() != 1000) {
      EventLog.writeEvent(75003, SQLiteDatabase.releaseMemory());
    }
    Canvas.freeCaches();
    Canvas.freeTextLayoutCaches();
    BinderInternal.forceGc("mem");
  }
  
  final void handleProfilerControl(boolean paramBoolean, ProfilerControlData paramProfilerControlData, int paramInt)
  {
    if (paramBoolean) {
      try
      {
        this.mProfiler.setProfiler(paramProfilerControlData.path, paramProfilerControlData.fd);
        this.mProfiler.autoStopProfiler = false;
        this.mProfiler.startProfiling();
        try
        {
          paramProfilerControlData.fd.close();
          throw ((Throwable)localObject);
          this.mProfiler.stopProfiling();
          return;
        }
        catch (IOException localIOException1)
        {
          for (;;)
          {
            Slog.w("ActivityThread", "Failure closing profile fd", localIOException1);
          }
        }
      }
      catch (RuntimeException localRuntimeException)
      {
        try
        {
          paramProfilerControlData.fd.close();
          return;
        }
        catch (IOException localIOException3)
        {
          for (;;)
          {
            String str1 = "ActivityThread";
            String str2 = "Failure closing profile fd";
          }
        }
        localRuntimeException = localRuntimeException;
        Slog.w("ActivityThread", "Profiling failed on path " + paramProfilerControlData.path + " -- can the process access this path?");
        try
        {
          paramProfilerControlData.fd.close();
          return;
        }
        catch (IOException localIOException2)
        {
          str1 = "ActivityThread";
          str2 = "Failure closing profile fd";
        }
        Slog.w(str1, str2, localIOException2);
        return;
      }
      finally {}
    }
  }
  
  final void handleResumeActivity(IBinder paramIBinder, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    unscheduleGcIdler();
    ActivityClientRecord localActivityClientRecord = performResumeActivity(paramIBinder, paramBoolean1);
    Activity localActivity;
    int i;
    int j;
    if (localActivityClientRecord != null)
    {
      localActivity = localActivityClientRecord.activity;
      if (paramBoolean2)
      {
        i = 256;
        if (localActivity.mStartedActivity) {
          break label448;
        }
        j = 1;
        label44:
        if (j != 0) {}
      }
    }
    try
    {
      boolean bool = ActivityManagerNative.getDefault().willActivityBeVisible(localActivity.getActivityToken());
      j = bool;
    }
    catch (RemoteException localRemoteException3)
    {
      View localView;
      WindowManager localWindowManager;
      WindowManager.LayoutParams localLayoutParams2;
      for (;;) {}
    }
    if ((localActivityClientRecord.window == null) && (!localActivity.mFinished) && (j != 0))
    {
      localActivityClientRecord.window = localActivityClientRecord.activity.getWindow();
      localView = localActivityClientRecord.window.getDecorView();
      localView.setVisibility(4);
      localWindowManager = localActivity.getWindowManager();
      localLayoutParams2 = localActivityClientRecord.window.getAttributes();
      localActivity.mDecor = localView;
      localLayoutParams2.type = 1;
      localLayoutParams2.softInputMode = (i | localLayoutParams2.softInputMode);
      if (localActivity.mVisibleFromClient)
      {
        localActivity.mWindowAdded = true;
        localWindowManager.addView(localView, localLayoutParams2);
      }
    }
    for (;;)
    {
      cleanUpPendingRemoveWindows(localActivityClientRecord);
      if ((!localActivityClientRecord.activity.mFinished) && (j != 0) && (localActivityClientRecord.activity.mDecor != null) && (!localActivityClientRecord.hideForNow))
      {
        if (localActivityClientRecord.newConfig != null)
        {
          performConfigurationChanged(localActivityClientRecord.activity, localActivityClientRecord.newConfig);
          freeTextLayoutCachesIfNeeded(localActivityClientRecord.activity.mCurrentConfig.diff(localActivityClientRecord.newConfig));
          localActivityClientRecord.newConfig = null;
        }
        WindowManager.LayoutParams localLayoutParams1 = localActivityClientRecord.window.getAttributes();
        if ((0x100 & localLayoutParams1.softInputMode) != i)
        {
          localLayoutParams1.softInputMode = (i | 0xFEFF & localLayoutParams1.softInputMode);
          if (localActivityClientRecord.activity.mVisibleFromClient) {
            localActivity.getWindowManager().updateViewLayout(localActivityClientRecord.window.getDecorView(), localLayoutParams1);
          }
        }
        localActivityClientRecord.activity.mVisibleFromServer = true;
        this.mNumVisibleActivities = (1 + this.mNumVisibleActivities);
        if (localActivityClientRecord.activity.mVisibleFromClient) {
          localActivityClientRecord.activity.makeVisible();
        }
      }
      if (!localActivityClientRecord.onlyLocalRequest)
      {
        localActivityClientRecord.nextIdle = this.mNewActivities;
        this.mNewActivities = localActivityClientRecord;
        Looper.myQueue().addIdleHandler(new Idler(null));
      }
      localActivityClientRecord.onlyLocalRequest = false;
      if (paramBoolean3) {}
      try
      {
        ActivityManagerNative.getDefault().activityResumed(paramIBinder);
        return;
      }
      catch (RemoteException localRemoteException2)
      {
        label448:
        return;
      }
      i = 0;
      break;
      j = 0;
      break label44;
      if (j == 0) {
        localActivityClientRecord.hideForNow = true;
      }
    }
    try
    {
      ActivityManagerNative.getDefault().finishActivity(paramIBinder, 0, null);
      return;
    }
    catch (RemoteException localRemoteException1) {}
  }
  
  final void handleTrimMemory(int paramInt)
  {
    WindowManagerGlobal localWindowManagerGlobal = WindowManagerGlobal.getInstance();
    localWindowManagerGlobal.startTrimMemory(paramInt);
    ArrayList localArrayList = collectComponentCallbacks(true, null);
    int i = localArrayList.size();
    for (int j = 0; j < i; j++) {
      ((ComponentCallbacks2)localArrayList.get(j)).onTrimMemory(paramInt);
    }
    localWindowManagerGlobal.endTrimMemory();
  }
  
  final void handleUnstableProviderDied(IBinder paramIBinder, boolean paramBoolean)
  {
    synchronized (this.mProviderMap)
    {
      handleUnstableProviderDiedLocked(paramIBinder, paramBoolean);
      return;
    }
  }
  
  final void handleUnstableProviderDiedLocked(IBinder paramIBinder, boolean paramBoolean)
  {
    ProviderRefCount localProviderRefCount = (ProviderRefCount)this.mProviderRefCountMap.get(paramIBinder);
    if (localProviderRefCount != null)
    {
      this.mProviderRefCountMap.remove(paramIBinder);
      if ((localProviderRefCount.client != null) && (localProviderRefCount.client.mNames != null)) {
        for (String str : localProviderRefCount.client.mNames)
        {
          ProviderClientRecord localProviderClientRecord = (ProviderClientRecord)this.mProviderMap.get(str);
          if ((localProviderClientRecord != null) && (localProviderClientRecord.mProvider.asBinder() == paramIBinder))
          {
            Slog.i("ActivityThread", "Removing dead content provider: " + str);
            this.mProviderMap.remove(str);
          }
        }
      }
      if (!paramBoolean) {}
    }
    try
    {
      ActivityManagerNative.getDefault().unstableProviderDied(localProviderRefCount.holder.connection);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void installSystemApplicationInfo(ApplicationInfo paramApplicationInfo)
  {
    try
    {
      ContextImpl localContextImpl = getSystemContext();
      localContextImpl.init(new LoadedApk(this, "android", localContextImpl, paramApplicationInfo, CompatibilityInfo.DEFAULT_COMPATIBILITY_INFO), null, this);
      this.mProfiler = new Profiler();
      return;
    }
    finally {}
  }
  
  public final void installSystemProviders(List<ProviderInfo> paramList)
  {
    if (paramList != null) {
      installContentProviders(this.mInitialApplication, paramList);
    }
  }
  
  public boolean isProfiling()
  {
    return (this.mProfiler != null) && (this.mProfiler.profileFile != null) && (this.mProfiler.profileFd == null);
  }
  
  public final LoadedApk peekPackageInfo(String paramString, boolean paramBoolean)
  {
    HashMap localHashMap = this.mPackages;
    if (paramBoolean) {}
    for (;;)
    {
      try
      {
        localWeakReference = (WeakReference)this.mPackages.get(paramString);
        if (localWeakReference == null) {
          break label67;
        }
        localLoadedApk = (LoadedApk)localWeakReference.get();
        return localLoadedApk;
      }
      finally {}
      WeakReference localWeakReference = (WeakReference)this.mResourcePackages.get(paramString);
      continue;
      label67:
      LoadedApk localLoadedApk = null;
    }
  }
  
  public final ActivityClientRecord performDestroyActivity(IBinder paramIBinder, boolean paramBoolean)
  {
    return performDestroyActivity(paramIBinder, paramBoolean, 0, false);
  }
  
  public final void performNewIntents(IBinder paramIBinder, List<Intent> paramList)
  {
    ActivityClientRecord localActivityClientRecord = (ActivityClientRecord)this.mActivities.get(paramIBinder);
    if (localActivityClientRecord != null) {
      if (localActivityClientRecord.paused) {
        break label77;
      }
    }
    label77:
    for (int i = 1;; i = 0)
    {
      if (i != 0)
      {
        localActivityClientRecord.activity.mTemporaryPause = true;
        this.mInstrumentation.callActivityOnPause(localActivityClientRecord.activity);
      }
      deliverNewIntents(localActivityClientRecord, paramList);
      if (i != 0)
      {
        localActivityClientRecord.activity.performResume();
        localActivityClientRecord.activity.mTemporaryPause = false;
      }
      return;
    }
  }
  
  final Bundle performPauseActivity(ActivityClientRecord paramActivityClientRecord, boolean paramBoolean1, boolean paramBoolean2)
  {
    if (paramActivityClientRecord.paused) {
      if (paramActivityClientRecord.activity.mFinished) {
        localObject1 = null;
      }
    }
    for (;;)
    {
      return (Bundle)localObject1;
      RuntimeException localRuntimeException = new RuntimeException("Performing pause of activity that is not resumed: " + paramActivityClientRecord.intent.getComponent().toShortString());
      Slog.e("ActivityThread", localRuntimeException.getMessage(), localRuntimeException);
      localObject1 = null;
      if (paramBoolean1) {
        paramActivityClientRecord.activity.mFinished = true;
      }
      try
      {
        boolean bool = paramActivityClientRecord.activity.mFinished;
        localObject1 = null;
        if (!bool)
        {
          localObject1 = null;
          if (paramBoolean2) {
            localBundle = new Bundle();
          }
        }
      }
      catch (SuperNotCalledException localSuperNotCalledException1)
      {
        try
        {
          localBundle.setAllowFds(false);
          this.mInstrumentation.callActivityOnSaveInstanceState(paramActivityClientRecord.activity, localBundle);
          paramActivityClientRecord.state = localBundle;
          localObject1 = localBundle;
          paramActivityClientRecord.activity.mCalled = false;
          this.mInstrumentation.callActivityOnPause(paramActivityClientRecord.activity);
          Object[] arrayOfObject = new Object[2];
          arrayOfObject[0] = Integer.valueOf(UserHandle.myUserId());
          arrayOfObject[1] = paramActivityClientRecord.activity.getComponentName().getClassName();
          EventLog.writeEvent(30021, arrayOfObject);
          if (paramActivityClientRecord.activity.mCalled) {
            break label339;
          }
          throw new SuperNotCalledException("Activity " + paramActivityClientRecord.intent.getComponent().toShortString() + " did not call through to super.onPause()");
        }
        catch (Exception localException2)
        {
          for (;;)
          {
            Bundle localBundle;
            ArrayList localArrayList;
            int i;
            int j;
            localObject1 = localBundle;
          }
        }
        catch (SuperNotCalledException localSuperNotCalledException2)
        {
          for (;;) {}
        }
        localSuperNotCalledException1 = localSuperNotCalledException1;
        throw localSuperNotCalledException1;
      }
      catch (Exception localException1)
      {
        if (!this.mInstrumentation.onException(paramActivityClientRecord.activity, localException1)) {
          throw new RuntimeException("Unable to pause activity " + paramActivityClientRecord.intent.getComponent().toShortString() + ": " + localException1.toString(), localException1);
        }
        label339:
        paramActivityClientRecord.paused = true;
        synchronized (this.mOnPauseListeners)
        {
          localArrayList = (ArrayList)this.mOnPauseListeners.remove(paramActivityClientRecord.activity);
          i = 0;
          if (localArrayList != null) {
            i = localArrayList.size();
          }
          j = 0;
          if (j >= i) {
            continue;
          }
          ((OnActivityPausedListener)localArrayList.get(j)).onPaused(paramActivityClientRecord.activity);
          j++;
        }
      }
    }
  }
  
  final Bundle performPauseActivity(IBinder paramIBinder, boolean paramBoolean1, boolean paramBoolean2)
  {
    ActivityClientRecord localActivityClientRecord = (ActivityClientRecord)this.mActivities.get(paramIBinder);
    if (localActivityClientRecord != null) {
      return performPauseActivity(localActivityClientRecord, paramBoolean1, paramBoolean2);
    }
    return null;
  }
  
  final void performRestartActivity(IBinder paramIBinder)
  {
    ActivityClientRecord localActivityClientRecord = (ActivityClientRecord)this.mActivities.get(paramIBinder);
    if (localActivityClientRecord.stopped)
    {
      localActivityClientRecord.activity.performRestart();
      localActivityClientRecord.stopped = false;
    }
  }
  
  public final ActivityClientRecord performResumeActivity(IBinder paramIBinder, boolean paramBoolean)
  {
    localActivityClientRecord = (ActivityClientRecord)this.mActivities.get(paramIBinder);
    if ((localActivityClientRecord != null) && (!localActivityClientRecord.activity.mFinished)) {
      if (paramBoolean)
      {
        localActivityClientRecord.hideForNow = false;
        localActivityClientRecord.activity.mStartedActivity = false;
      }
    }
    try
    {
      localActivityClientRecord.activity.mFragments.noteStateNotSaved();
      if (localActivityClientRecord.pendingIntents != null)
      {
        deliverNewIntents(localActivityClientRecord, localActivityClientRecord.pendingIntents);
        localActivityClientRecord.pendingIntents = null;
      }
      if (localActivityClientRecord.pendingResults != null)
      {
        deliverResults(localActivityClientRecord, localActivityClientRecord.pendingResults);
        localActivityClientRecord.pendingResults = null;
      }
      localActivityClientRecord.activity.performResume();
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Integer.valueOf(UserHandle.myUserId());
      arrayOfObject[1] = localActivityClientRecord.activity.getComponentName().getClassName();
      EventLog.writeEvent(30022, arrayOfObject);
      localActivityClientRecord.paused = false;
      localActivityClientRecord.stopped = false;
      localActivityClientRecord.state = null;
    }
    catch (Exception localException)
    {
      while (this.mInstrumentation.onException(localActivityClientRecord.activity, localException)) {}
      throw new RuntimeException("Unable to resume activity " + localActivityClientRecord.intent.getComponent().toShortString() + ": " + localException.toString(), localException);
    }
    return localActivityClientRecord;
  }
  
  final void performStopActivity(IBinder paramIBinder, boolean paramBoolean)
  {
    performStopActivityInner((ActivityClientRecord)this.mActivities.get(paramIBinder), null, false, paramBoolean);
  }
  
  final void performUserLeavingActivity(ActivityClientRecord paramActivityClientRecord)
  {
    this.mInstrumentation.callActivityOnUserLeaving(paramActivityClientRecord.activity);
  }
  
  public void registerOnActivityPausedListener(Activity paramActivity, OnActivityPausedListener paramOnActivityPausedListener)
  {
    synchronized (this.mOnPauseListeners)
    {
      ArrayList localArrayList = (ArrayList)this.mOnPauseListeners.get(paramActivity);
      if (localArrayList == null)
      {
        localArrayList = new ArrayList();
        this.mOnPauseListeners.put(paramActivity, localArrayList);
      }
      localArrayList.add(paramOnActivityPausedListener);
      return;
    }
  }
  
  public final boolean releaseProvider(IContentProvider paramIContentProvider, boolean paramBoolean)
  {
    if (paramIContentProvider == null) {
      return false;
    }
    IBinder localIBinder1 = paramIContentProvider.asBinder();
    ProviderRefCount localProviderRefCount;
    synchronized (this.mProviderMap)
    {
      localProviderRefCount = (ProviderRefCount)this.mProviderRefCountMap.get(localIBinder1);
      if (localProviderRefCount == null) {
        return false;
      }
    }
    if (paramBoolean)
    {
      if (localProviderRefCount.stableCount == 0) {
        return false;
      }
      localProviderRefCount.stableCount = (-1 + localProviderRefCount.stableCount);
      int m = localProviderRefCount.stableCount;
      j = 0;
      if (m == 0)
      {
        int n = localProviderRefCount.unstableCount;
        if (n != 0) {
          break label336;
        }
      }
    }
    label290:
    label292:
    label336:
    for (int j = 1;; j = 0)
    {
      try
      {
        IActivityManager localIActivityManager = ActivityManagerNative.getDefault();
        IBinder localIBinder2 = localProviderRefCount.holder.connection;
        int i1 = 0;
        if (j != 0) {
          i1 = 1;
        }
        localIActivityManager.refContentProvider(localIBinder2, -1, i1);
      }
      catch (RemoteException localRemoteException2)
      {
        Message localMessage;
        for (;;) {}
      }
      if (j != 0)
      {
        if (localProviderRefCount.removePending) {
          break label292;
        }
        localProviderRefCount.removePending = true;
        localMessage = this.mH.obtainMessage(131, localProviderRefCount);
        this.mH.sendMessage(localMessage);
      }
      for (;;)
      {
        return true;
        if (localProviderRefCount.unstableCount == 0) {
          return false;
        }
        localProviderRefCount.unstableCount = (-1 + localProviderRefCount.unstableCount);
        int i = localProviderRefCount.unstableCount;
        j = 0;
        if (i != 0) {
          break;
        }
        int k = localProviderRefCount.stableCount;
        if (k == 0) {}
        for (j = 1;; j = 0)
        {
          if (j != 0) {
            break label290;
          }
          try
          {
            ActivityManagerNative.getDefault().refContentProvider(localProviderRefCount.holder.connection, 0, -1);
          }
          catch (RemoteException localRemoteException1) {}
          break;
        }
        break;
        Slog.w("ActivityThread", "Duplicate remove pending of provider " + localProviderRefCount.holder.info.name);
      }
    }
  }
  
  /* Error */
  public final void requestRelaunchActivity(IBinder paramIBinder, List<ResultInfo> paramList, List<Intent> paramList1, int paramInt, boolean paramBoolean1, Configuration paramConfiguration, boolean paramBoolean2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 204	android/app/ActivityThread:mPackages	Ljava/util/HashMap;
    //   4: astore 8
    //   6: aload 8
    //   8: monitorenter
    //   9: iconst_0
    //   10: istore 9
    //   12: aload_0
    //   13: getfield 212	android/app/ActivityThread:mRelaunchingActivities	Ljava/util/ArrayList;
    //   16: invokevirtual 1558	java/util/ArrayList:size	()I
    //   19: istore 11
    //   21: aconst_null
    //   22: astore 12
    //   24: iload 9
    //   26: iload 11
    //   28: if_icmpge +267 -> 295
    //   31: aload_0
    //   32: getfield 212	android/app/ActivityThread:mRelaunchingActivities	Ljava/util/ArrayList;
    //   35: iload 9
    //   37: invokevirtual 1559	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   40: checkcast 531	android/app/ActivityThread$ActivityClientRecord
    //   43: astore 13
    //   45: aload 13
    //   47: getfield 584	android/app/ActivityThread$ActivityClientRecord:token	Landroid/os/IBinder;
    //   50: aload_1
    //   51: if_acmpne +223 -> 274
    //   54: aload 13
    //   56: astore 12
    //   58: aload_2
    //   59: ifnull +23 -> 82
    //   62: aload 13
    //   64: getfield 1605	android/app/ActivityThread$ActivityClientRecord:pendingResults	Ljava/util/List;
    //   67: ifnull +179 -> 246
    //   70: aload 13
    //   72: getfield 1605	android/app/ActivityThread$ActivityClientRecord:pendingResults	Ljava/util/List;
    //   75: aload_2
    //   76: invokeinterface 1612 2 0
    //   81: pop
    //   82: aload_3
    //   83: ifnull +212 -> 295
    //   86: aload 13
    //   88: getfield 1608	android/app/ActivityThread$ActivityClientRecord:pendingIntents	Ljava/util/List;
    //   91: ifnull +170 -> 261
    //   94: aload 13
    //   96: getfield 1608	android/app/ActivityThread$ActivityClientRecord:pendingIntents	Ljava/util/List;
    //   99: aload_3
    //   100: invokeinterface 1612 2 0
    //   105: pop
    //   106: aload 12
    //   108: astore 14
    //   110: aload 14
    //   112: ifnonnull +176 -> 288
    //   115: new 531	android/app/ActivityThread$ActivityClientRecord
    //   118: dup
    //   119: invokespecial 2601	android/app/ActivityThread$ActivityClientRecord:<init>	()V
    //   122: astore 15
    //   124: aload 15
    //   126: aload_1
    //   127: putfield 584	android/app/ActivityThread$ActivityClientRecord:token	Landroid/os/IBinder;
    //   130: aload 15
    //   132: aload_2
    //   133: putfield 1605	android/app/ActivityThread$ActivityClientRecord:pendingResults	Ljava/util/List;
    //   136: aload 15
    //   138: aload_3
    //   139: putfield 1608	android/app/ActivityThread$ActivityClientRecord:pendingIntents	Ljava/util/List;
    //   142: iload 7
    //   144: ifne +37 -> 181
    //   147: aload_0
    //   148: getfield 175	android/app/ActivityThread:mActivities	Ljava/util/HashMap;
    //   151: aload_1
    //   152: invokevirtual 782	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   155: checkcast 531	android/app/ActivityThread$ActivityClientRecord
    //   158: astore 16
    //   160: aload 16
    //   162: ifnull +13 -> 175
    //   165: aload 15
    //   167: aload 16
    //   169: getfield 1488	android/app/ActivityThread$ActivityClientRecord:paused	Z
    //   172: putfield 1464	android/app/ActivityThread$ActivityClientRecord:startsNotResumed	Z
    //   175: aload 15
    //   177: iconst_1
    //   178: putfield 1328	android/app/ActivityThread$ActivityClientRecord:onlyLocalRequest	Z
    //   181: aload_0
    //   182: getfield 212	android/app/ActivityThread:mRelaunchingActivities	Ljava/util/ArrayList;
    //   185: aload 15
    //   187: invokevirtual 504	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   190: pop
    //   191: aload_0
    //   192: bipush 126
    //   194: aload 15
    //   196: invokespecial 367	android/app/ActivityThread:queueOrSendMessage	(ILjava/lang/Object;)V
    //   199: iload 7
    //   201: ifeq +16 -> 217
    //   204: aload 15
    //   206: iload 5
    //   208: putfield 1464	android/app/ActivityThread$ActivityClientRecord:startsNotResumed	Z
    //   211: aload 15
    //   213: iconst_0
    //   214: putfield 1328	android/app/ActivityThread$ActivityClientRecord:onlyLocalRequest	Z
    //   217: aload 6
    //   219: ifnull +10 -> 229
    //   222: aload 15
    //   224: aload 6
    //   226: putfield 1452	android/app/ActivityThread$ActivityClientRecord:createdConfig	Landroid/content/res/Configuration;
    //   229: aload 15
    //   231: iload 4
    //   233: aload 15
    //   235: getfield 1562	android/app/ActivityThread$ActivityClientRecord:pendingConfigChanges	I
    //   238: ior
    //   239: putfield 1562	android/app/ActivityThread$ActivityClientRecord:pendingConfigChanges	I
    //   242: aload 8
    //   244: monitorexit
    //   245: return
    //   246: aload 13
    //   248: aload_2
    //   249: putfield 1605	android/app/ActivityThread$ActivityClientRecord:pendingResults	Ljava/util/List;
    //   252: goto -170 -> 82
    //   255: aload 8
    //   257: monitorexit
    //   258: aload 10
    //   260: athrow
    //   261: aload 13
    //   263: aload_3
    //   264: putfield 1608	android/app/ActivityThread$ActivityClientRecord:pendingIntents	Ljava/util/List;
    //   267: aload 12
    //   269: astore 14
    //   271: goto -161 -> 110
    //   274: iinc 9 1
    //   277: goto -265 -> 12
    //   280: astore 10
    //   282: aload 14
    //   284: pop
    //   285: goto -30 -> 255
    //   288: aload 14
    //   290: astore 15
    //   292: goto -93 -> 199
    //   295: aload 12
    //   297: astore 14
    //   299: goto -189 -> 110
    //   302: astore 10
    //   304: goto -49 -> 255
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	307	0	this	ActivityThread
    //   0	307	1	paramIBinder	IBinder
    //   0	307	2	paramList	List<ResultInfo>
    //   0	307	3	paramList1	List<Intent>
    //   0	307	4	paramInt	int
    //   0	307	5	paramBoolean1	boolean
    //   0	307	6	paramConfiguration	Configuration
    //   0	307	7	paramBoolean2	boolean
    //   4	252	8	localHashMap	HashMap
    //   10	265	9	i	int
    //   258	1	10	localObject1	Object
    //   280	1	10	localObject2	Object
    //   302	1	10	localObject3	Object
    //   19	10	11	j	int
    //   22	274	12	localObject4	Object
    //   43	219	13	localActivityClientRecord1	ActivityClientRecord
    //   108	190	14	localObject5	Object
    //   122	169	15	localObject6	Object
    //   158	10	16	localActivityClientRecord2	ActivityClientRecord
    // Exception table:
    //   from	to	target	type
    //   115	124	280	finally
    //   12	21	302	finally
    //   31	54	302	finally
    //   62	82	302	finally
    //   86	106	302	finally
    //   124	142	302	finally
    //   147	160	302	finally
    //   165	175	302	finally
    //   175	181	302	finally
    //   181	199	302	finally
    //   204	217	302	finally
    //   222	229	302	finally
    //   229	245	302	finally
    //   246	252	302	finally
    //   255	258	302	finally
    //   261	267	302	finally
  }
  
  public final ActivityInfo resolveActivityInfo(Intent paramIntent)
  {
    ActivityInfo localActivityInfo = paramIntent.resolveActivityInfo(this.mInitialApplication.getPackageManager(), 1024);
    if (localActivityInfo == null) {
      Instrumentation.checkStartActivityResult(-2, paramIntent);
    }
    return localActivityInfo;
  }
  
  final void scheduleContextCleanup(ContextImpl paramContextImpl, String paramString1, String paramString2)
  {
    ContextCleanupInfo localContextCleanupInfo = new ContextCleanupInfo();
    localContextCleanupInfo.context = paramContextImpl;
    localContextCleanupInfo.who = paramString1;
    localContextCleanupInfo.what = paramString2;
    queueOrSendMessage(119, localContextCleanupInfo);
  }
  
  void scheduleGcIdler()
  {
    if (!this.mGcIdlerScheduled)
    {
      this.mGcIdlerScheduled = true;
      Looper.myQueue().addIdleHandler(this.mGcIdler);
    }
    this.mH.removeMessages(120);
  }
  
  public final void sendActivityResult(IBinder paramIBinder, String paramString, int paramInt1, int paramInt2, Intent paramIntent)
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(new ResultInfo(paramString, paramInt1, paramInt2, paramIntent));
    this.mAppThread.scheduleSendResult(paramIBinder, localArrayList);
  }
  
  public final Activity startActivityNow(Activity paramActivity, String paramString, Intent paramIntent, ActivityInfo paramActivityInfo, IBinder paramIBinder, Bundle paramBundle, Activity.NonConfigurationInstances paramNonConfigurationInstances)
  {
    ActivityClientRecord localActivityClientRecord = new ActivityClientRecord();
    localActivityClientRecord.token = paramIBinder;
    localActivityClientRecord.ident = 0;
    localActivityClientRecord.intent = paramIntent;
    localActivityClientRecord.state = paramBundle;
    localActivityClientRecord.parent = paramActivity;
    localActivityClientRecord.embeddedID = paramString;
    localActivityClientRecord.activityInfo = paramActivityInfo;
    localActivityClientRecord.lastNonConfigurationInstances = paramNonConfigurationInstances;
    return performLaunchActivity(localActivityClientRecord, null);
  }
  
  public void unregisterOnActivityPausedListener(Activity paramActivity, OnActivityPausedListener paramOnActivityPausedListener)
  {
    synchronized (this.mOnPauseListeners)
    {
      ArrayList localArrayList = (ArrayList)this.mOnPauseListeners.get(paramActivity);
      if (localArrayList != null) {
        localArrayList.remove(paramOnActivityPausedListener);
      }
      return;
    }
  }
  
  void unscheduleGcIdler()
  {
    if (this.mGcIdlerScheduled)
    {
      this.mGcIdlerScheduled = false;
      Looper.myQueue().removeIdleHandler(this.mGcIdler);
    }
    this.mH.removeMessages(120);
  }
  
  static final class ActivityClientRecord
  {
    Activity activity;
    ActivityInfo activityInfo;
    boolean autoStopProfiler;
    CompatibilityInfo compatInfo;
    Configuration createdConfig;
    String embeddedID = null;
    boolean hideForNow = false;
    int ident;
    Intent intent;
    boolean isForward;
    Activity.NonConfigurationInstances lastNonConfigurationInstances;
    View mPendingRemoveWindow;
    WindowManager mPendingRemoveWindowManager;
    Configuration newConfig;
    ActivityClientRecord nextIdle = null;
    boolean onlyLocalRequest;
    LoadedApk packageInfo;
    Activity parent = null;
    boolean paused = false;
    int pendingConfigChanges;
    List<Intent> pendingIntents;
    List<ResultInfo> pendingResults;
    ParcelFileDescriptor profileFd;
    String profileFile;
    boolean startsNotResumed;
    Bundle state;
    boolean stopped = false;
    IBinder token;
    Window window;
    
    public boolean isPreHoneycomb()
    {
      Activity localActivity = this.activity;
      boolean bool = false;
      if (localActivity != null)
      {
        int i = this.activity.getApplicationInfo().targetSdkVersion;
        bool = false;
        if (i < 11) {
          bool = true;
        }
      }
      return bool;
    }
    
    public String toString()
    {
      ComponentName localComponentName;
      StringBuilder localStringBuilder;
      if (this.intent != null)
      {
        localComponentName = this.intent.getComponent();
        localStringBuilder = new StringBuilder().append("ActivityRecord{").append(Integer.toHexString(System.identityHashCode(this))).append(" token=").append(this.token).append(" ");
        if (localComponentName != null) {
          break label81;
        }
      }
      label81:
      for (String str = "no component name";; str = localComponentName.toShortString())
      {
        return str + "}";
        localComponentName = null;
        break;
      }
    }
  }
  
  static final class AppBindData
  {
    ApplicationInfo appInfo;
    CompatibilityInfo compatInfo;
    Configuration config;
    int debugMode;
    boolean enableOpenGlTrace;
    LoadedApk info;
    boolean initAutoStopProfiler;
    ParcelFileDescriptor initProfileFd;
    String initProfileFile;
    Bundle instrumentationArgs;
    ComponentName instrumentationName;
    IInstrumentationWatcher instrumentationWatcher;
    boolean persistent;
    String processName;
    List<ProviderInfo> providers;
    boolean restrictedBackupMode;
    
    public String toString()
    {
      return "AppBindData{appInfo=" + this.appInfo + "}";
    }
  }
  
  private class ApplicationThread
    extends ApplicationThreadNative
  {
    private static final int ACTIVITY_THREAD_CHECKIN_VERSION = 1;
    private static final String DB_INFO_FORMAT = "  %8s %8s %14s %14s  %s";
    private static final String HEAP_COLUMN = "%13s %8s %8s %8s %8s %8s %8s";
    private static final String ONE_COUNT_COLUMN = "%21s %8d";
    private static final String TWO_COUNT_COLUMNS = "%21s %8d %21s %8d";
    
    private ApplicationThread() {}
    
    private Debug.MemoryInfo dumpMemInfo(PrintWriter paramPrintWriter, boolean paramBoolean1, boolean paramBoolean2)
    {
      long l1 = Debug.getNativeHeapSize() / 1024L;
      long l2 = Debug.getNativeHeapAllocatedSize() / 1024L;
      long l3 = Debug.getNativeHeapFreeSize() / 1024L;
      Debug.MemoryInfo localMemoryInfo = new Debug.MemoryInfo();
      Debug.getMemoryInfo(localMemoryInfo);
      if (!paramBoolean2) {}
      label2030:
      label2056:
      label2127:
      label2135:
      String str1;
      do
      {
        return localMemoryInfo;
        Runtime localRuntime = Runtime.getRuntime();
        long l4 = localRuntime.totalMemory() / 1024L;
        long l5 = localRuntime.freeMemory() / 1024L;
        long l6 = l4 - l5;
        long l7 = ViewDebug.getViewInstanceCount();
        long l8 = ViewDebug.getViewRootImplCount();
        long l9 = Debug.countInstancesOfClass(ContextImpl.class);
        long l10 = Debug.countInstancesOfClass(Activity.class);
        int i = AssetManager.getGlobalAssetCount();
        int j = AssetManager.getGlobalAssetManagerCount();
        int k = Debug.getBinderLocalObjectCount();
        int m = Debug.getBinderProxyObjectCount();
        int n = Debug.getBinderDeathObjectCount();
        long l11 = Debug.countInstancesOfClass(OpenSSLSocketImpl.class);
        SQLiteDebug.PagerStats localPagerStats = SQLiteDebug.getDatabaseInfo();
        if (paramBoolean1)
        {
          if (ActivityThread.this.mBoundApplication != null) {}
          for (String str5 = ActivityThread.this.mBoundApplication.processName;; str5 = "unknown")
          {
            paramPrintWriter.print(1);
            paramPrintWriter.print(',');
            paramPrintWriter.print(Process.myPid());
            paramPrintWriter.print(',');
            paramPrintWriter.print(str5);
            paramPrintWriter.print(',');
            paramPrintWriter.print(l1);
            paramPrintWriter.print(',');
            paramPrintWriter.print(l4);
            paramPrintWriter.print(',');
            paramPrintWriter.print("N/A,");
            paramPrintWriter.print(l1 + l4);
            paramPrintWriter.print(',');
            paramPrintWriter.print(l2);
            paramPrintWriter.print(',');
            paramPrintWriter.print(l6);
            paramPrintWriter.print(',');
            paramPrintWriter.print("N/A,");
            paramPrintWriter.print(l2 + l6);
            paramPrintWriter.print(',');
            paramPrintWriter.print(l3);
            paramPrintWriter.print(',');
            paramPrintWriter.print(l5);
            paramPrintWriter.print(',');
            paramPrintWriter.print("N/A,");
            paramPrintWriter.print(l3 + l5);
            paramPrintWriter.print(',');
            paramPrintWriter.print(localMemoryInfo.nativePss);
            paramPrintWriter.print(',');
            paramPrintWriter.print(localMemoryInfo.dalvikPss);
            paramPrintWriter.print(',');
            paramPrintWriter.print(localMemoryInfo.otherPss);
            paramPrintWriter.print(',');
            paramPrintWriter.print(localMemoryInfo.nativePss + localMemoryInfo.dalvikPss + localMemoryInfo.otherPss);
            paramPrintWriter.print(',');
            paramPrintWriter.print(localMemoryInfo.nativeSharedDirty);
            paramPrintWriter.print(',');
            paramPrintWriter.print(localMemoryInfo.dalvikSharedDirty);
            paramPrintWriter.print(',');
            paramPrintWriter.print(localMemoryInfo.otherSharedDirty);
            paramPrintWriter.print(',');
            paramPrintWriter.print(localMemoryInfo.nativeSharedDirty + localMemoryInfo.dalvikSharedDirty + localMemoryInfo.otherSharedDirty);
            paramPrintWriter.print(',');
            paramPrintWriter.print(localMemoryInfo.nativePrivateDirty);
            paramPrintWriter.print(',');
            paramPrintWriter.print(localMemoryInfo.dalvikPrivateDirty);
            paramPrintWriter.print(',');
            paramPrintWriter.print(localMemoryInfo.otherPrivateDirty);
            paramPrintWriter.print(',');
            paramPrintWriter.print(localMemoryInfo.nativePrivateDirty + localMemoryInfo.dalvikPrivateDirty + localMemoryInfo.otherPrivateDirty);
            paramPrintWriter.print(',');
            paramPrintWriter.print(l7);
            paramPrintWriter.print(',');
            paramPrintWriter.print(l8);
            paramPrintWriter.print(',');
            paramPrintWriter.print(l9);
            paramPrintWriter.print(',');
            paramPrintWriter.print(l10);
            paramPrintWriter.print(',');
            paramPrintWriter.print(i);
            paramPrintWriter.print(',');
            paramPrintWriter.print(j);
            paramPrintWriter.print(',');
            paramPrintWriter.print(k);
            paramPrintWriter.print(',');
            paramPrintWriter.print(m);
            paramPrintWriter.print(',');
            paramPrintWriter.print(n);
            paramPrintWriter.print(',');
            paramPrintWriter.print(l11);
            paramPrintWriter.print(',');
            paramPrintWriter.print(localPagerStats.memoryUsed / 1024);
            paramPrintWriter.print(',');
            paramPrintWriter.print(localPagerStats.memoryUsed / 1024);
            paramPrintWriter.print(',');
            paramPrintWriter.print(localPagerStats.pageCacheOverflow / 1024);
            paramPrintWriter.print(',');
            paramPrintWriter.print(localPagerStats.largestMemAlloc / 1024);
            for (int i7 = 0;; i7++)
            {
              int i8 = localPagerStats.dbStats.size();
              if (i7 >= i8) {
                break;
              }
              SQLiteDebug.DbStats localDbStats2 = (SQLiteDebug.DbStats)localPagerStats.dbStats.get(i7);
              paramPrintWriter.print(',');
              paramPrintWriter.print(localDbStats2.dbName);
              paramPrintWriter.print(',');
              paramPrintWriter.print(localDbStats2.pageSize);
              paramPrintWriter.print(',');
              paramPrintWriter.print(localDbStats2.dbSize);
              paramPrintWriter.print(',');
              paramPrintWriter.print(localDbStats2.lookaside);
              paramPrintWriter.print(',');
              paramPrintWriter.print(localDbStats2.cache);
              paramPrintWriter.print(',');
              paramPrintWriter.print(localDbStats2.cache);
            }
          }
          paramPrintWriter.println();
          return localMemoryInfo;
        }
        printRow(paramPrintWriter, "%13s %8s %8s %8s %8s %8s %8s", new Object[] { "", "", "Shared", "Private", "Heap", "Heap", "Heap" });
        printRow(paramPrintWriter, "%13s %8s %8s %8s %8s %8s %8s", new Object[] { "", "Pss", "Dirty", "Dirty", "Size", "Alloc", "Free" });
        printRow(paramPrintWriter, "%13s %8s %8s %8s %8s %8s %8s", new Object[] { "", "------", "------", "------", "------", "------", "------" });
        Object[] arrayOfObject1 = new Object[7];
        arrayOfObject1[0] = "Native";
        arrayOfObject1[1] = Integer.valueOf(localMemoryInfo.nativePss);
        arrayOfObject1[2] = Integer.valueOf(localMemoryInfo.nativeSharedDirty);
        arrayOfObject1[3] = Integer.valueOf(localMemoryInfo.nativePrivateDirty);
        arrayOfObject1[4] = Long.valueOf(l1);
        arrayOfObject1[5] = Long.valueOf(l2);
        arrayOfObject1[6] = Long.valueOf(l3);
        printRow(paramPrintWriter, "%13s %8s %8s %8s %8s %8s %8s", arrayOfObject1);
        Object[] arrayOfObject2 = new Object[7];
        arrayOfObject2[0] = "Dalvik";
        arrayOfObject2[1] = Integer.valueOf(localMemoryInfo.dalvikPss);
        arrayOfObject2[2] = Integer.valueOf(localMemoryInfo.dalvikSharedDirty);
        arrayOfObject2[3] = Integer.valueOf(localMemoryInfo.dalvikPrivateDirty);
        arrayOfObject2[4] = Long.valueOf(l4);
        arrayOfObject2[5] = Long.valueOf(l6);
        arrayOfObject2[6] = Long.valueOf(l5);
        printRow(paramPrintWriter, "%13s %8s %8s %8s %8s %8s %8s", arrayOfObject2);
        int i1 = localMemoryInfo.otherPss;
        int i2 = localMemoryInfo.otherSharedDirty;
        int i3 = localMemoryInfo.otherPrivateDirty;
        for (int i4 = 0; i4 < 9; i4++)
        {
          Object[] arrayOfObject14 = new Object[7];
          arrayOfObject14[0] = Debug.MemoryInfo.getOtherLabel(i4);
          arrayOfObject14[1] = Integer.valueOf(localMemoryInfo.getOtherPss(i4));
          arrayOfObject14[2] = Integer.valueOf(localMemoryInfo.getOtherSharedDirty(i4));
          arrayOfObject14[3] = Integer.valueOf(localMemoryInfo.getOtherPrivateDirty(i4));
          arrayOfObject14[4] = "";
          arrayOfObject14[5] = "";
          arrayOfObject14[6] = "";
          printRow(paramPrintWriter, "%13s %8s %8s %8s %8s %8s %8s", arrayOfObject14);
          i1 -= localMemoryInfo.getOtherPss(i4);
          i2 -= localMemoryInfo.getOtherSharedDirty(i4);
          i3 -= localMemoryInfo.getOtherPrivateDirty(i4);
        }
        Object[] arrayOfObject3 = new Object[7];
        arrayOfObject3[0] = "Unknown";
        arrayOfObject3[1] = Integer.valueOf(i1);
        arrayOfObject3[2] = Integer.valueOf(i2);
        arrayOfObject3[3] = Integer.valueOf(i3);
        arrayOfObject3[4] = "";
        arrayOfObject3[5] = "";
        arrayOfObject3[6] = "";
        printRow(paramPrintWriter, "%13s %8s %8s %8s %8s %8s %8s", arrayOfObject3);
        Object[] arrayOfObject4 = new Object[7];
        arrayOfObject4[0] = "TOTAL";
        arrayOfObject4[1] = Integer.valueOf(localMemoryInfo.getTotalPss());
        arrayOfObject4[2] = Integer.valueOf(localMemoryInfo.getTotalSharedDirty());
        arrayOfObject4[3] = Integer.valueOf(localMemoryInfo.getTotalPrivateDirty());
        arrayOfObject4[4] = Long.valueOf(l1 + l4);
        arrayOfObject4[5] = Long.valueOf(l2 + l6);
        arrayOfObject4[6] = Long.valueOf(l3 + l5);
        printRow(paramPrintWriter, "%13s %8s %8s %8s %8s %8s %8s", arrayOfObject4);
        paramPrintWriter.println(" ");
        paramPrintWriter.println(" Objects");
        Object[] arrayOfObject5 = new Object[4];
        arrayOfObject5[0] = "Views:";
        arrayOfObject5[1] = Long.valueOf(l7);
        arrayOfObject5[2] = "ViewRootImpl:";
        arrayOfObject5[3] = Long.valueOf(l8);
        printRow(paramPrintWriter, "%21s %8d %21s %8d", arrayOfObject5);
        Object[] arrayOfObject6 = new Object[4];
        arrayOfObject6[0] = "AppContexts:";
        arrayOfObject6[1] = Long.valueOf(l9);
        arrayOfObject6[2] = "Activities:";
        arrayOfObject6[3] = Long.valueOf(l10);
        printRow(paramPrintWriter, "%21s %8d %21s %8d", arrayOfObject6);
        Object[] arrayOfObject7 = new Object[4];
        arrayOfObject7[0] = "Assets:";
        arrayOfObject7[1] = Integer.valueOf(i);
        arrayOfObject7[2] = "AssetManagers:";
        arrayOfObject7[3] = Integer.valueOf(j);
        printRow(paramPrintWriter, "%21s %8d %21s %8d", arrayOfObject7);
        Object[] arrayOfObject8 = new Object[4];
        arrayOfObject8[0] = "Local Binders:";
        arrayOfObject8[1] = Integer.valueOf(k);
        arrayOfObject8[2] = "Proxy Binders:";
        arrayOfObject8[3] = Integer.valueOf(m);
        printRow(paramPrintWriter, "%21s %8d %21s %8d", arrayOfObject8);
        Object[] arrayOfObject9 = new Object[2];
        arrayOfObject9[0] = "Death Recipients:";
        arrayOfObject9[1] = Integer.valueOf(n);
        printRow(paramPrintWriter, "%21s %8d", arrayOfObject9);
        Object[] arrayOfObject10 = new Object[2];
        arrayOfObject10[0] = "OpenSSL Sockets:";
        arrayOfObject10[1] = Long.valueOf(l11);
        printRow(paramPrintWriter, "%21s %8d", arrayOfObject10);
        paramPrintWriter.println(" ");
        paramPrintWriter.println(" SQL");
        Object[] arrayOfObject11 = new Object[2];
        arrayOfObject11[0] = "MEMORY_USED:";
        arrayOfObject11[1] = Integer.valueOf(localPagerStats.memoryUsed / 1024);
        printRow(paramPrintWriter, "%21s %8d", arrayOfObject11);
        Object[] arrayOfObject12 = new Object[4];
        arrayOfObject12[0] = "PAGECACHE_OVERFLOW:";
        arrayOfObject12[1] = Integer.valueOf(localPagerStats.pageCacheOverflow / 1024);
        arrayOfObject12[2] = "MALLOC_SIZE:";
        arrayOfObject12[3] = Integer.valueOf(localPagerStats.largestMemAlloc / 1024);
        printRow(paramPrintWriter, "%21s %8d %21s %8d", arrayOfObject12);
        paramPrintWriter.println(" ");
        int i5 = localPagerStats.dbStats.size();
        if (i5 > 0)
        {
          paramPrintWriter.println(" DATABASES");
          printRow(paramPrintWriter, "  %8s %8s %14s %14s  %s", new Object[] { "pgsz", "dbsz", "Lookaside(b)", "cache", "Dbname" });
          int i6 = 0;
          if (i6 < i5)
          {
            SQLiteDebug.DbStats localDbStats1 = (SQLiteDebug.DbStats)localPagerStats.dbStats.get(i6);
            Object[] arrayOfObject13 = new Object[5];
            String str2;
            String str3;
            if (localDbStats1.pageSize > 0L)
            {
              str2 = String.valueOf(localDbStats1.pageSize);
              arrayOfObject13[0] = str2;
              if (localDbStats1.dbSize <= 0L) {
                break label2127;
              }
              str3 = String.valueOf(localDbStats1.dbSize);
              arrayOfObject13[1] = str3;
              if (localDbStats1.lookaside <= 0) {
                break label2135;
              }
            }
            for (String str4 = String.valueOf(localDbStats1.lookaside);; str4 = " ")
            {
              arrayOfObject13[2] = str4;
              arrayOfObject13[3] = localDbStats1.cache;
              arrayOfObject13[4] = localDbStats1.dbName;
              printRow(paramPrintWriter, "  %8s %8s %14s %14s  %s", arrayOfObject13);
              i6++;
              break;
              str2 = " ";
              break label2030;
              str3 = " ";
              break label2056;
            }
          }
        }
        str1 = AssetManager.getAssetAllocations();
      } while (str1 == null);
      paramPrintWriter.println(" ");
      paramPrintWriter.println(" Asset Allocations");
      paramPrintWriter.print(str1);
      return localMemoryInfo;
    }
    
    private void printRow(PrintWriter paramPrintWriter, String paramString, Object... paramVarArgs)
    {
      paramPrintWriter.println(String.format(paramString, paramVarArgs));
    }
    
    private void updatePendingConfiguration(Configuration paramConfiguration)
    {
      synchronized (ActivityThread.this.mPackages)
      {
        if ((ActivityThread.this.mPendingConfiguration == null) || (ActivityThread.this.mPendingConfiguration.isOtherSeqNewer(paramConfiguration))) {
          ActivityThread.this.mPendingConfiguration = paramConfiguration;
        }
        return;
      }
    }
    
    public final void bindApplication(String paramString1, ApplicationInfo paramApplicationInfo, List<ProviderInfo> paramList, ComponentName paramComponentName, String paramString2, ParcelFileDescriptor paramParcelFileDescriptor, boolean paramBoolean1, Bundle paramBundle1, IInstrumentationWatcher paramIInstrumentationWatcher, int paramInt, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, Configuration paramConfiguration, CompatibilityInfo paramCompatibilityInfo, Map<String, IBinder> paramMap, Bundle paramBundle2)
    {
      if (paramMap != null) {
        ServiceManager.initServiceCache(paramMap);
      }
      setCoreSettings(paramBundle2);
      ActivityThread.AppBindData localAppBindData = new ActivityThread.AppBindData();
      localAppBindData.processName = paramString1;
      localAppBindData.appInfo = paramApplicationInfo;
      localAppBindData.providers = paramList;
      localAppBindData.instrumentationName = paramComponentName;
      localAppBindData.instrumentationArgs = paramBundle1;
      localAppBindData.instrumentationWatcher = paramIInstrumentationWatcher;
      localAppBindData.debugMode = paramInt;
      localAppBindData.enableOpenGlTrace = paramBoolean2;
      localAppBindData.restrictedBackupMode = paramBoolean3;
      localAppBindData.persistent = paramBoolean4;
      localAppBindData.config = paramConfiguration;
      localAppBindData.compatInfo = paramCompatibilityInfo;
      localAppBindData.initProfileFile = paramString2;
      localAppBindData.initProfileFd = paramParcelFileDescriptor;
      localAppBindData.initAutoStopProfiler = false;
      ActivityThread.this.queueOrSendMessage(110, localAppBindData);
    }
    
    public void clearDnsCache() {}
    
    public void dispatchPackageBroadcast(int paramInt, String[] paramArrayOfString)
    {
      ActivityThread.this.queueOrSendMessage(133, paramArrayOfString, paramInt);
    }
    
    public void dumpActivity(FileDescriptor paramFileDescriptor, IBinder paramIBinder, String paramString, String[] paramArrayOfString)
    {
      ActivityThread.DumpComponentInfo localDumpComponentInfo = new ActivityThread.DumpComponentInfo();
      try
      {
        localDumpComponentInfo.fd = ParcelFileDescriptor.dup(paramFileDescriptor);
        localDumpComponentInfo.token = paramIBinder;
        localDumpComponentInfo.prefix = paramString;
        localDumpComponentInfo.args = paramArrayOfString;
        ActivityThread.this.queueOrSendMessage(136, localDumpComponentInfo);
        return;
      }
      catch (IOException localIOException)
      {
        Slog.w("ActivityThread", "dumpActivity failed", localIOException);
      }
    }
    
    public void dumpDbInfo(FileDescriptor paramFileDescriptor, String[] paramArrayOfString)
    {
      PrintWriter localPrintWriter = new PrintWriter(new FileOutputStream(paramFileDescriptor));
      SQLiteDebug.dump(new PrintWriterPrinter(localPrintWriter), paramArrayOfString);
      localPrintWriter.flush();
    }
    
    public void dumpGfxInfo(FileDescriptor paramFileDescriptor, String[] paramArrayOfString)
    {
      ActivityThread.this.dumpGraphicsInfo(paramFileDescriptor);
      WindowManagerGlobal.getInstance().dumpGfxInfo(paramFileDescriptor);
    }
    
    public void dumpHeap(boolean paramBoolean, String paramString, ParcelFileDescriptor paramParcelFileDescriptor)
    {
      ActivityThread.DumpHeapData localDumpHeapData = new ActivityThread.DumpHeapData();
      localDumpHeapData.path = paramString;
      localDumpHeapData.fd = paramParcelFileDescriptor;
      ActivityThread localActivityThread = ActivityThread.this;
      if (paramBoolean) {}
      for (int i = 1;; i = 0)
      {
        localActivityThread.queueOrSendMessage(135, localDumpHeapData, i);
        return;
      }
    }
    
    public Debug.MemoryInfo dumpMemInfo(FileDescriptor paramFileDescriptor, boolean paramBoolean1, boolean paramBoolean2, String[] paramArrayOfString)
    {
      PrintWriter localPrintWriter = new PrintWriter(new FileOutputStream(paramFileDescriptor));
      try
      {
        Debug.MemoryInfo localMemoryInfo = dumpMemInfo(localPrintWriter, paramBoolean1, paramBoolean2);
        return localMemoryInfo;
      }
      finally
      {
        localPrintWriter.flush();
      }
    }
    
    public void dumpProvider(FileDescriptor paramFileDescriptor, IBinder paramIBinder, String[] paramArrayOfString)
    {
      ActivityThread.DumpComponentInfo localDumpComponentInfo = new ActivityThread.DumpComponentInfo();
      try
      {
        localDumpComponentInfo.fd = ParcelFileDescriptor.dup(paramFileDescriptor);
        localDumpComponentInfo.token = paramIBinder;
        localDumpComponentInfo.args = paramArrayOfString;
        ActivityThread.this.queueOrSendMessage(141, localDumpComponentInfo);
        return;
      }
      catch (IOException localIOException)
      {
        Slog.w("ActivityThread", "dumpProvider failed", localIOException);
      }
    }
    
    public void dumpService(FileDescriptor paramFileDescriptor, IBinder paramIBinder, String[] paramArrayOfString)
    {
      ActivityThread.DumpComponentInfo localDumpComponentInfo = new ActivityThread.DumpComponentInfo();
      try
      {
        localDumpComponentInfo.fd = ParcelFileDescriptor.dup(paramFileDescriptor);
        localDumpComponentInfo.token = paramIBinder;
        localDumpComponentInfo.args = paramArrayOfString;
        ActivityThread.this.queueOrSendMessage(123, localDumpComponentInfo);
        return;
      }
      catch (IOException localIOException)
      {
        Slog.w("ActivityThread", "dumpService failed", localIOException);
      }
    }
    
    public void getMemoryInfo(Debug.MemoryInfo paramMemoryInfo)
    {
      Debug.getMemoryInfo(paramMemoryInfo);
    }
    
    public void processInBackground()
    {
      ActivityThread.this.mH.removeMessages(120);
      ActivityThread.this.mH.sendMessage(ActivityThread.this.mH.obtainMessage(120));
    }
    
    public void profilerControl(boolean paramBoolean, String paramString, ParcelFileDescriptor paramParcelFileDescriptor, int paramInt)
    {
      ActivityThread.ProfilerControlData localProfilerControlData = new ActivityThread.ProfilerControlData();
      localProfilerControlData.path = paramString;
      localProfilerControlData.fd = paramParcelFileDescriptor;
      ActivityThread localActivityThread = ActivityThread.this;
      if (paramBoolean) {}
      for (int i = 1;; i = 0)
      {
        localActivityThread.queueOrSendMessage(127, localProfilerControlData, i, paramInt);
        return;
      }
    }
    
    public void requestThumbnail(IBinder paramIBinder)
    {
      ActivityThread.this.queueOrSendMessage(117, paramIBinder);
    }
    
    public void scheduleActivityConfigurationChanged(IBinder paramIBinder)
    {
      ActivityThread.this.queueOrSendMessage(125, paramIBinder);
    }
    
    public final void scheduleBindService(IBinder paramIBinder, Intent paramIntent, boolean paramBoolean)
    {
      ActivityThread.BindServiceData localBindServiceData = new ActivityThread.BindServiceData();
      localBindServiceData.token = paramIBinder;
      localBindServiceData.intent = paramIntent;
      localBindServiceData.rebind = paramBoolean;
      ActivityThread.this.queueOrSendMessage(121, localBindServiceData);
    }
    
    public void scheduleConfigurationChanged(Configuration paramConfiguration)
    {
      updatePendingConfiguration(paramConfiguration);
      ActivityThread.this.queueOrSendMessage(118, paramConfiguration);
    }
    
    public void scheduleCrash(String paramString)
    {
      ActivityThread.this.queueOrSendMessage(134, paramString);
    }
    
    public final void scheduleCreateBackupAgent(ApplicationInfo paramApplicationInfo, CompatibilityInfo paramCompatibilityInfo, int paramInt)
    {
      ActivityThread.CreateBackupAgentData localCreateBackupAgentData = new ActivityThread.CreateBackupAgentData();
      localCreateBackupAgentData.appInfo = paramApplicationInfo;
      localCreateBackupAgentData.compatInfo = paramCompatibilityInfo;
      localCreateBackupAgentData.backupMode = paramInt;
      ActivityThread.this.queueOrSendMessage(128, localCreateBackupAgentData);
    }
    
    public final void scheduleCreateService(IBinder paramIBinder, ServiceInfo paramServiceInfo, CompatibilityInfo paramCompatibilityInfo)
    {
      ActivityThread.CreateServiceData localCreateServiceData = new ActivityThread.CreateServiceData();
      localCreateServiceData.token = paramIBinder;
      localCreateServiceData.info = paramServiceInfo;
      localCreateServiceData.compatInfo = paramCompatibilityInfo;
      ActivityThread.this.queueOrSendMessage(114, localCreateServiceData);
    }
    
    public final void scheduleDestroyActivity(IBinder paramIBinder, boolean paramBoolean, int paramInt)
    {
      ActivityThread localActivityThread = ActivityThread.this;
      if (paramBoolean) {}
      for (int i = 1;; i = 0)
      {
        localActivityThread.queueOrSendMessage(109, paramIBinder, i, paramInt);
        return;
      }
    }
    
    public final void scheduleDestroyBackupAgent(ApplicationInfo paramApplicationInfo, CompatibilityInfo paramCompatibilityInfo)
    {
      ActivityThread.CreateBackupAgentData localCreateBackupAgentData = new ActivityThread.CreateBackupAgentData();
      localCreateBackupAgentData.appInfo = paramApplicationInfo;
      localCreateBackupAgentData.compatInfo = paramCompatibilityInfo;
      ActivityThread.this.queueOrSendMessage(129, localCreateBackupAgentData);
    }
    
    public final void scheduleExit()
    {
      ActivityThread.this.queueOrSendMessage(111, null);
    }
    
    public final void scheduleLaunchActivity(Intent paramIntent, IBinder paramIBinder, int paramInt, ActivityInfo paramActivityInfo, Configuration paramConfiguration, CompatibilityInfo paramCompatibilityInfo, Bundle paramBundle, List<ResultInfo> paramList, List<Intent> paramList1, boolean paramBoolean1, boolean paramBoolean2, String paramString, ParcelFileDescriptor paramParcelFileDescriptor, boolean paramBoolean3)
    {
      ActivityThread.ActivityClientRecord localActivityClientRecord = new ActivityThread.ActivityClientRecord();
      localActivityClientRecord.token = paramIBinder;
      localActivityClientRecord.ident = paramInt;
      localActivityClientRecord.intent = paramIntent;
      localActivityClientRecord.activityInfo = paramActivityInfo;
      localActivityClientRecord.compatInfo = paramCompatibilityInfo;
      localActivityClientRecord.state = paramBundle;
      localActivityClientRecord.pendingResults = paramList;
      localActivityClientRecord.pendingIntents = paramList1;
      localActivityClientRecord.startsNotResumed = paramBoolean1;
      localActivityClientRecord.isForward = paramBoolean2;
      localActivityClientRecord.profileFile = paramString;
      localActivityClientRecord.profileFd = paramParcelFileDescriptor;
      localActivityClientRecord.autoStopProfiler = paramBoolean3;
      updatePendingConfiguration(paramConfiguration);
      ActivityThread.this.queueOrSendMessage(100, localActivityClientRecord);
    }
    
    public void scheduleLowMemory()
    {
      ActivityThread.this.queueOrSendMessage(124, null);
    }
    
    public final void scheduleNewIntent(List<Intent> paramList, IBinder paramIBinder)
    {
      ActivityThread.NewIntentData localNewIntentData = new ActivityThread.NewIntentData();
      localNewIntentData.intents = paramList;
      localNewIntentData.token = paramIBinder;
      ActivityThread.this.queueOrSendMessage(112, localNewIntentData);
    }
    
    public final void schedulePauseActivity(IBinder paramIBinder, boolean paramBoolean1, boolean paramBoolean2, int paramInt)
    {
      ActivityThread localActivityThread = ActivityThread.this;
      int i;
      if (paramBoolean1)
      {
        i = 102;
        if (!paramBoolean2) {
          break label41;
        }
      }
      label41:
      for (int j = 1;; j = 0)
      {
        localActivityThread.queueOrSendMessage(i, paramIBinder, j, paramInt);
        return;
        i = 101;
        break;
      }
    }
    
    public final void scheduleReceiver(Intent paramIntent, ActivityInfo paramActivityInfo, CompatibilityInfo paramCompatibilityInfo, int paramInt1, String paramString, Bundle paramBundle, boolean paramBoolean, int paramInt2)
    {
      ActivityThread.ReceiverData localReceiverData = new ActivityThread.ReceiverData(paramIntent, paramInt1, paramString, paramBundle, paramBoolean, false, ActivityThread.this.mAppThread.asBinder(), paramInt2);
      localReceiverData.info = paramActivityInfo;
      localReceiverData.compatInfo = paramCompatibilityInfo;
      ActivityThread.this.queueOrSendMessage(113, localReceiverData);
    }
    
    public void scheduleRegisteredReceiver(IIntentReceiver paramIIntentReceiver, Intent paramIntent, int paramInt1, String paramString, Bundle paramBundle, boolean paramBoolean1, boolean paramBoolean2, int paramInt2)
      throws RemoteException
    {
      paramIIntentReceiver.performReceive(paramIntent, paramInt1, paramString, paramBundle, paramBoolean1, paramBoolean2, paramInt2);
    }
    
    public final void scheduleRelaunchActivity(IBinder paramIBinder, List<ResultInfo> paramList, List<Intent> paramList1, int paramInt, boolean paramBoolean, Configuration paramConfiguration)
    {
      ActivityThread.this.requestRelaunchActivity(paramIBinder, paramList, paramList1, paramInt, paramBoolean, paramConfiguration, true);
    }
    
    public final void scheduleResumeActivity(IBinder paramIBinder, boolean paramBoolean)
    {
      ActivityThread localActivityThread = ActivityThread.this;
      if (paramBoolean) {}
      for (int i = 1;; i = 0)
      {
        localActivityThread.queueOrSendMessage(107, paramIBinder, i);
        return;
      }
    }
    
    public final void scheduleSendResult(IBinder paramIBinder, List<ResultInfo> paramList)
    {
      ActivityThread.ResultData localResultData = new ActivityThread.ResultData();
      localResultData.token = paramIBinder;
      localResultData.results = paramList;
      ActivityThread.this.queueOrSendMessage(108, localResultData);
    }
    
    public final void scheduleServiceArgs(IBinder paramIBinder, boolean paramBoolean, int paramInt1, int paramInt2, Intent paramIntent)
    {
      ActivityThread.ServiceArgsData localServiceArgsData = new ActivityThread.ServiceArgsData();
      localServiceArgsData.token = paramIBinder;
      localServiceArgsData.taskRemoved = paramBoolean;
      localServiceArgsData.startId = paramInt1;
      localServiceArgsData.flags = paramInt2;
      localServiceArgsData.args = paramIntent;
      ActivityThread.this.queueOrSendMessage(115, localServiceArgsData);
    }
    
    public final void scheduleSleeping(IBinder paramIBinder, boolean paramBoolean)
    {
      ActivityThread localActivityThread = ActivityThread.this;
      if (paramBoolean) {}
      for (int i = 1;; i = 0)
      {
        localActivityThread.queueOrSendMessage(137, paramIBinder, i);
        return;
      }
    }
    
    public final void scheduleStopActivity(IBinder paramIBinder, boolean paramBoolean, int paramInt)
    {
      ActivityThread localActivityThread = ActivityThread.this;
      if (paramBoolean) {}
      for (int i = 103;; i = 104)
      {
        localActivityThread.queueOrSendMessage(i, paramIBinder, 0, paramInt);
        return;
      }
    }
    
    public final void scheduleStopService(IBinder paramIBinder)
    {
      ActivityThread.this.queueOrSendMessage(116, paramIBinder);
    }
    
    public final void scheduleSuicide()
    {
      ActivityThread.this.queueOrSendMessage(130, null);
    }
    
    public void scheduleTrimMemory(int paramInt)
    {
      ActivityThread.this.queueOrSendMessage(140, null, paramInt);
    }
    
    public final void scheduleUnbindService(IBinder paramIBinder, Intent paramIntent)
    {
      ActivityThread.BindServiceData localBindServiceData = new ActivityThread.BindServiceData();
      localBindServiceData.token = paramIBinder;
      localBindServiceData.intent = paramIntent;
      ActivityThread.this.queueOrSendMessage(122, localBindServiceData);
    }
    
    public final void scheduleWindowVisibility(IBinder paramIBinder, boolean paramBoolean)
    {
      ActivityThread localActivityThread = ActivityThread.this;
      if (paramBoolean) {}
      for (int i = 105;; i = 106)
      {
        localActivityThread.queueOrSendMessage(i, paramIBinder);
        return;
      }
    }
    
    public void setCoreSettings(Bundle paramBundle)
    {
      ActivityThread.this.queueOrSendMessage(138, paramBundle);
    }
    
    public void setHttpProxy(String paramString1, String paramString2, String paramString3)
    {
      Proxy.setHttpProxySystemProperty(paramString1, paramString2, paramString3);
    }
    
    public void setSchedulingGroup(int paramInt)
    {
      try
      {
        Process.setProcessGroup(Process.myPid(), paramInt);
        return;
      }
      catch (Exception localException)
      {
        Slog.w("ActivityThread", "Failed setting process group to " + paramInt, localException);
      }
    }
    
    public void unstableProviderDied(IBinder paramIBinder)
    {
      ActivityThread.this.queueOrSendMessage(142, paramIBinder);
    }
    
    public void updatePackageCompatibilityInfo(String paramString, CompatibilityInfo paramCompatibilityInfo)
    {
      ActivityThread.UpdateCompatibilityData localUpdateCompatibilityData = new ActivityThread.UpdateCompatibilityData();
      localUpdateCompatibilityData.pkg = paramString;
      localUpdateCompatibilityData.info = paramCompatibilityInfo;
      ActivityThread.this.queueOrSendMessage(139, localUpdateCompatibilityData);
    }
    
    public void updateTimeZone()
    {
      TimeZone.setDefault(null);
    }
  }
  
  static final class BindServiceData
  {
    Intent intent;
    boolean rebind;
    IBinder token;
    
    public String toString()
    {
      return "BindServiceData{token=" + this.token + " intent=" + this.intent + "}";
    }
  }
  
  static final class ContextCleanupInfo
  {
    ContextImpl context;
    String what;
    String who;
  }
  
  static final class CreateBackupAgentData
  {
    ApplicationInfo appInfo;
    int backupMode;
    CompatibilityInfo compatInfo;
    
    public String toString()
    {
      return "CreateBackupAgentData{appInfo=" + this.appInfo + " backupAgent=" + this.appInfo.backupAgentName + " mode=" + this.backupMode + "}";
    }
  }
  
  static final class CreateServiceData
  {
    CompatibilityInfo compatInfo;
    ServiceInfo info;
    Intent intent;
    IBinder token;
    
    public String toString()
    {
      return "CreateServiceData{token=" + this.token + " className=" + this.info.name + " packageName=" + this.info.packageName + " intent=" + this.intent + "}";
    }
  }
  
  private class DropBoxReporter
    implements DropBox.Reporter
  {
    private DropBoxManager dropBox = (DropBoxManager)ActivityThread.this.getSystemContext().getSystemService("dropbox");
    
    public DropBoxReporter() {}
    
    public void addData(String paramString, byte[] paramArrayOfByte, int paramInt)
    {
      this.dropBox.addData(paramString, paramArrayOfByte, paramInt);
    }
    
    public void addText(String paramString1, String paramString2)
    {
      this.dropBox.addText(paramString1, paramString2);
    }
  }
  
  static final class DumpComponentInfo
  {
    String[] args;
    ParcelFileDescriptor fd;
    String prefix;
    IBinder token;
  }
  
  static final class DumpHeapData
  {
    ParcelFileDescriptor fd;
    String path;
  }
  
  private static class EventLoggingReporter
    implements EventLogger.Reporter
  {
    public void report(int paramInt, Object... paramVarArgs)
    {
      EventLog.writeEvent(paramInt, paramVarArgs);
    }
  }
  
  final class GcIdler
    implements MessageQueue.IdleHandler
  {
    GcIdler() {}
    
    public final boolean queueIdle()
    {
      ActivityThread.this.doGcIfNeeded();
      return false;
    }
  }
  
  private class H
    extends Handler
  {
    public static final int ACTIVITY_CONFIGURATION_CHANGED = 125;
    public static final int BIND_APPLICATION = 110;
    public static final int BIND_SERVICE = 121;
    public static final int CLEAN_UP_CONTEXT = 119;
    public static final int CONFIGURATION_CHANGED = 118;
    public static final int CREATE_BACKUP_AGENT = 128;
    public static final int CREATE_SERVICE = 114;
    public static final int DESTROY_ACTIVITY = 109;
    public static final int DESTROY_BACKUP_AGENT = 129;
    public static final int DISPATCH_PACKAGE_BROADCAST = 133;
    public static final int DUMP_ACTIVITY = 136;
    public static final int DUMP_HEAP = 135;
    public static final int DUMP_PROVIDER = 141;
    public static final int DUMP_SERVICE = 123;
    public static final int ENABLE_JIT = 132;
    public static final int EXIT_APPLICATION = 111;
    public static final int GC_WHEN_IDLE = 120;
    public static final int HIDE_WINDOW = 106;
    public static final int LAUNCH_ACTIVITY = 100;
    public static final int LOW_MEMORY = 124;
    public static final int NEW_INTENT = 112;
    public static final int PAUSE_ACTIVITY = 101;
    public static final int PAUSE_ACTIVITY_FINISHING = 102;
    public static final int PROFILER_CONTROL = 127;
    public static final int RECEIVER = 113;
    public static final int RELAUNCH_ACTIVITY = 126;
    public static final int REMOVE_PROVIDER = 131;
    public static final int REQUEST_THUMBNAIL = 117;
    public static final int RESUME_ACTIVITY = 107;
    public static final int SCHEDULE_CRASH = 134;
    public static final int SEND_RESULT = 108;
    public static final int SERVICE_ARGS = 115;
    public static final int SET_CORE_SETTINGS = 138;
    public static final int SHOW_WINDOW = 105;
    public static final int SLEEPING = 137;
    public static final int STOP_ACTIVITY_HIDE = 104;
    public static final int STOP_ACTIVITY_SHOW = 103;
    public static final int STOP_SERVICE = 116;
    public static final int SUICIDE = 130;
    public static final int TRIM_MEMORY = 140;
    public static final int UNBIND_SERVICE = 122;
    public static final int UNSTABLE_PROVIDER_DIED = 142;
    public static final int UPDATE_PACKAGE_COMPATIBILITY_INFO = 139;
    
    private H() {}
    
    private void maybeSnapshot()
    {
      if ((ActivityThread.this.mBoundApplication != null) && (SamplingProfilerIntegration.isEnabled()))
      {
        String str = ActivityThread.this.mBoundApplication.info.mPackageName;
        PackageInfo localPackageInfo;
        for (Object localObject = null;; localObject = localPackageInfo)
        {
          PackageManager localPackageManager;
          try
          {
            ContextImpl localContextImpl = ActivityThread.this.getSystemContext();
            if (localContextImpl == null)
            {
              Log.e("ActivityThread", "cannot get a valid context");
              return;
            }
            localPackageManager = localContextImpl.getPackageManager();
            if (localPackageManager == null)
            {
              Log.e("ActivityThread", "cannot get a valid PackageManager");
              return;
            }
          }
          catch (PackageManager.NameNotFoundException localNameNotFoundException)
          {
            Log.e("ActivityThread", "cannot get package info for " + str, localNameNotFoundException);
            SamplingProfilerIntegration.writeSnapshot(ActivityThread.this.mBoundApplication.processName, (PackageInfo)localObject);
            return;
          }
          localPackageInfo = localPackageManager.getPackageInfo(str, 1);
        }
      }
    }
    
    String codeToString(int paramInt)
    {
      return Integer.toString(paramInt);
    }
    
    public void handleMessage(Message paramMessage)
    {
      boolean bool1 = true;
      switch (paramMessage.what)
      {
      default: 
        return;
      case 100: 
        Trace.traceBegin(64L, "activityStart");
        ActivityThread.ActivityClientRecord localActivityClientRecord2 = (ActivityThread.ActivityClientRecord)paramMessage.obj;
        localActivityClientRecord2.packageInfo = ActivityThread.this.getPackageInfoNoCheck(localActivityClientRecord2.activityInfo.applicationInfo, localActivityClientRecord2.compatInfo);
        ActivityThread.this.handleLaunchActivity(localActivityClientRecord2, null);
        Trace.traceEnd(64L);
        return;
      case 126: 
        Trace.traceBegin(64L, "activityRestart");
        ActivityThread.ActivityClientRecord localActivityClientRecord1 = (ActivityThread.ActivityClientRecord)paramMessage.obj;
        ActivityThread.this.handleRelaunchActivity(localActivityClientRecord1);
        Trace.traceEnd(64L);
        return;
      case 101: 
        Trace.traceBegin(64L, "activityPause");
        ActivityThread localActivityThread6 = ActivityThread.this;
        IBinder localIBinder5 = (IBinder)paramMessage.obj;
        if (paramMessage.arg1 != 0) {}
        for (;;)
        {
          localActivityThread6.handlePauseActivity(localIBinder5, false, bool1, paramMessage.arg2);
          maybeSnapshot();
          Trace.traceEnd(64L);
          return;
          bool1 = false;
        }
      case 102: 
        Trace.traceBegin(64L, "activityPause");
        ActivityThread localActivityThread5 = ActivityThread.this;
        IBinder localIBinder4 = (IBinder)paramMessage.obj;
        int j = paramMessage.arg1;
        boolean bool3 = false;
        if (j != 0) {
          bool3 = bool1;
        }
        localActivityThread5.handlePauseActivity(localIBinder4, bool1, bool3, paramMessage.arg2);
        Trace.traceEnd(64L);
        return;
      case 103: 
        Trace.traceBegin(64L, "activityStop");
        ActivityThread.this.handleStopActivity((IBinder)paramMessage.obj, bool1, paramMessage.arg2);
        Trace.traceEnd(64L);
        return;
      case 104: 
        Trace.traceBegin(64L, "activityStop");
        ActivityThread.this.handleStopActivity((IBinder)paramMessage.obj, false, paramMessage.arg2);
        Trace.traceEnd(64L);
        return;
      case 105: 
        Trace.traceBegin(64L, "activityShowWindow");
        ActivityThread.this.handleWindowVisibility((IBinder)paramMessage.obj, bool1);
        Trace.traceEnd(64L);
        return;
      case 106: 
        Trace.traceBegin(64L, "activityHideWindow");
        ActivityThread.this.handleWindowVisibility((IBinder)paramMessage.obj, false);
        Trace.traceEnd(64L);
        return;
      case 107: 
        Trace.traceBegin(64L, "activityResume");
        ActivityThread localActivityThread4 = ActivityThread.this;
        IBinder localIBinder3 = (IBinder)paramMessage.obj;
        int i = paramMessage.arg1;
        boolean bool2 = false;
        if (i != 0) {
          bool2 = bool1;
        }
        localActivityThread4.handleResumeActivity(localIBinder3, bool1, bool2, bool1);
        Trace.traceEnd(64L);
        return;
      case 108: 
        Trace.traceBegin(64L, "activityDeliverResult");
        ActivityThread.this.handleSendResult((ActivityThread.ResultData)paramMessage.obj);
        Trace.traceEnd(64L);
        return;
      case 109: 
        Trace.traceBegin(64L, "activityDestroy");
        ActivityThread localActivityThread3 = ActivityThread.this;
        IBinder localIBinder2 = (IBinder)paramMessage.obj;
        if (paramMessage.arg1 != 0) {}
        for (;;)
        {
          localActivityThread3.handleDestroyActivity(localIBinder2, bool1, paramMessage.arg2, false);
          Trace.traceEnd(64L);
          return;
          bool1 = false;
        }
      case 110: 
        Trace.traceBegin(64L, "bindApplication");
        ActivityThread.AppBindData localAppBindData = (ActivityThread.AppBindData)paramMessage.obj;
        ActivityThread.this.handleBindApplication(localAppBindData);
        Trace.traceEnd(64L);
        return;
      case 111: 
        if (ActivityThread.this.mInitialApplication != null) {
          ActivityThread.this.mInitialApplication.onTerminate();
        }
        Looper.myLooper().quit();
        return;
      case 112: 
        Trace.traceBegin(64L, "activityNewIntent");
        ActivityThread.this.handleNewIntent((ActivityThread.NewIntentData)paramMessage.obj);
        Trace.traceEnd(64L);
        return;
      case 113: 
        Trace.traceBegin(64L, "broadcastReceiveComp");
        ActivityThread.this.handleReceiver((ActivityThread.ReceiverData)paramMessage.obj);
        maybeSnapshot();
        Trace.traceEnd(64L);
        return;
      case 114: 
        Trace.traceBegin(64L, "serviceCreate");
        ActivityThread.this.handleCreateService((ActivityThread.CreateServiceData)paramMessage.obj);
        Trace.traceEnd(64L);
        return;
      case 121: 
        Trace.traceBegin(64L, "serviceBind");
        ActivityThread.this.handleBindService((ActivityThread.BindServiceData)paramMessage.obj);
        Trace.traceEnd(64L);
        return;
      case 122: 
        Trace.traceBegin(64L, "serviceUnbind");
        ActivityThread.this.handleUnbindService((ActivityThread.BindServiceData)paramMessage.obj);
        Trace.traceEnd(64L);
        return;
      case 115: 
        Trace.traceBegin(64L, "serviceStart");
        ActivityThread.this.handleServiceArgs((ActivityThread.ServiceArgsData)paramMessage.obj);
        Trace.traceEnd(64L);
        return;
      case 116: 
        Trace.traceBegin(64L, "serviceStop");
        ActivityThread.this.handleStopService((IBinder)paramMessage.obj);
        maybeSnapshot();
        Trace.traceEnd(64L);
        return;
      case 117: 
        Trace.traceBegin(64L, "requestThumbnail");
        ActivityThread.this.handleRequestThumbnail((IBinder)paramMessage.obj);
        Trace.traceEnd(64L);
        return;
      case 118: 
        Trace.traceBegin(64L, "configChanged");
        ActivityThread.this.mCurDefaultDisplayDpi = ((Configuration)paramMessage.obj).densityDpi;
        ActivityThread.this.handleConfigurationChanged((Configuration)paramMessage.obj, null);
        Trace.traceEnd(64L);
        return;
      case 119: 
        ActivityThread.ContextCleanupInfo localContextCleanupInfo = (ActivityThread.ContextCleanupInfo)paramMessage.obj;
        localContextCleanupInfo.context.performFinalCleanup(localContextCleanupInfo.who, localContextCleanupInfo.what);
        return;
      case 120: 
        ActivityThread.this.scheduleGcIdler();
        return;
      case 123: 
        ActivityThread.this.handleDumpService((ActivityThread.DumpComponentInfo)paramMessage.obj);
        return;
      case 124: 
        Trace.traceBegin(64L, "lowMemory");
        ActivityThread.this.handleLowMemory();
        Trace.traceEnd(64L);
        return;
      case 125: 
        Trace.traceBegin(64L, "activityConfigChanged");
        ActivityThread.this.handleActivityConfigurationChanged((IBinder)paramMessage.obj);
        Trace.traceEnd(64L);
        return;
      case 127: 
        ActivityThread localActivityThread2 = ActivityThread.this;
        if (paramMessage.arg1 != 0) {}
        for (;;)
        {
          localActivityThread2.handleProfilerControl(bool1, (ActivityThread.ProfilerControlData)paramMessage.obj, paramMessage.arg2);
          return;
          bool1 = false;
        }
      case 128: 
        Trace.traceBegin(64L, "backupCreateAgent");
        ActivityThread.this.handleCreateBackupAgent((ActivityThread.CreateBackupAgentData)paramMessage.obj);
        Trace.traceEnd(64L);
        return;
      case 129: 
        Trace.traceBegin(64L, "backupDestroyAgent");
        ActivityThread.this.handleDestroyBackupAgent((ActivityThread.CreateBackupAgentData)paramMessage.obj);
        Trace.traceEnd(64L);
        return;
      case 130: 
        Process.killProcess(Process.myPid());
        return;
      case 131: 
        Trace.traceBegin(64L, "providerRemove");
        ActivityThread.this.completeRemoveProvider((ActivityThread.ProviderRefCount)paramMessage.obj);
        Trace.traceEnd(64L);
        return;
      case 132: 
        ActivityThread.this.ensureJitEnabled();
        return;
      case 133: 
        Trace.traceBegin(64L, "broadcastPackage");
        ActivityThread.this.handleDispatchPackageBroadcast(paramMessage.arg1, (String[])paramMessage.obj);
        Trace.traceEnd(64L);
        return;
      case 134: 
        throw new RemoteServiceException((String)paramMessage.obj);
      case 135: 
        if (paramMessage.arg1 != 0) {}
        for (;;)
        {
          ActivityThread.handleDumpHeap(bool1, (ActivityThread.DumpHeapData)paramMessage.obj);
          return;
          bool1 = false;
        }
      case 136: 
        ActivityThread.this.handleDumpActivity((ActivityThread.DumpComponentInfo)paramMessage.obj);
        return;
      case 141: 
        ActivityThread.this.handleDumpProvider((ActivityThread.DumpComponentInfo)paramMessage.obj);
        return;
      case 137: 
        Trace.traceBegin(64L, "sleeping");
        ActivityThread localActivityThread1 = ActivityThread.this;
        IBinder localIBinder1 = (IBinder)paramMessage.obj;
        if (paramMessage.arg1 != 0) {}
        for (;;)
        {
          localActivityThread1.handleSleeping(localIBinder1, bool1);
          Trace.traceEnd(64L);
          return;
          bool1 = false;
        }
      case 138: 
        Trace.traceBegin(64L, "setCoreSettings");
        ActivityThread.this.handleSetCoreSettings((Bundle)paramMessage.obj);
        Trace.traceEnd(64L);
        return;
      case 139: 
        ActivityThread.this.handleUpdatePackageCompatibilityInfo((ActivityThread.UpdateCompatibilityData)paramMessage.obj);
        return;
      case 140: 
        Trace.traceBegin(64L, "trimMemory");
        ActivityThread.this.handleTrimMemory(paramMessage.arg1);
        Trace.traceEnd(64L);
        return;
      }
      ActivityThread.this.handleUnstableProviderDied((IBinder)paramMessage.obj, false);
    }
  }
  
  private class Idler
    implements MessageQueue.IdleHandler
  {
    private Idler() {}
    
    public final boolean queueIdle()
    {
      ActivityThread.ActivityClientRecord localActivityClientRecord1 = ActivityThread.this.mNewActivities;
      ActivityThread.AppBindData localAppBindData = ActivityThread.this.mBoundApplication;
      boolean bool1 = false;
      if (localAppBindData != null)
      {
        ParcelFileDescriptor localParcelFileDescriptor = ActivityThread.this.mProfiler.profileFd;
        bool1 = false;
        if (localParcelFileDescriptor != null)
        {
          boolean bool2 = ActivityThread.this.mProfiler.autoStopProfiler;
          bool1 = false;
          if (bool2) {
            bool1 = true;
          }
        }
      }
      IActivityManager localIActivityManager;
      if (localActivityClientRecord1 != null)
      {
        ActivityThread.this.mNewActivities = null;
        localIActivityManager = ActivityManagerNative.getDefault();
      }
      for (;;)
      {
        if ((localActivityClientRecord1.activity != null) && (!localActivityClientRecord1.activity.mFinished)) {}
        try
        {
          localIActivityManager.activityIdle(localActivityClientRecord1.token, localActivityClientRecord1.createdConfig, bool1);
          localActivityClientRecord1.createdConfig = null;
          ActivityThread.ActivityClientRecord localActivityClientRecord2 = localActivityClientRecord1;
          localActivityClientRecord1 = localActivityClientRecord1.nextIdle;
          localActivityClientRecord2.nextIdle = null;
          if (localActivityClientRecord1 != null) {
            continue;
          }
          if (bool1) {
            ActivityThread.this.mProfiler.stopProfiling();
          }
          ActivityThread.this.ensureJitEnabled();
          return false;
        }
        catch (RemoteException localRemoteException)
        {
          for (;;) {}
        }
      }
    }
  }
  
  static final class NewIntentData
  {
    List<Intent> intents;
    IBinder token;
    
    public String toString()
    {
      return "NewIntentData{intents=" + this.intents + " token=" + this.token + "}";
    }
  }
  
  static final class Profiler
  {
    boolean autoStopProfiler;
    boolean handlingProfiling;
    ParcelFileDescriptor profileFd;
    String profileFile;
    boolean profiling;
    
    /* Error */
    public void setProfiler(String paramString, ParcelFileDescriptor paramParcelFileDescriptor)
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 22	android/app/ActivityThread$Profiler:profiling	Z
      //   4: ifeq +12 -> 16
      //   7: aload_2
      //   8: ifnull +7 -> 15
      //   11: aload_2
      //   12: invokevirtual 27	android/os/ParcelFileDescriptor:close	()V
      //   15: return
      //   16: aload_0
      //   17: getfield 29	android/app/ActivityThread$Profiler:profileFd	Landroid/os/ParcelFileDescriptor;
      //   20: ifnull +10 -> 30
      //   23: aload_0
      //   24: getfield 29	android/app/ActivityThread$Profiler:profileFd	Landroid/os/ParcelFileDescriptor;
      //   27: invokevirtual 27	android/os/ParcelFileDescriptor:close	()V
      //   30: aload_0
      //   31: aload_1
      //   32: putfield 31	android/app/ActivityThread$Profiler:profileFile	Ljava/lang/String;
      //   35: aload_0
      //   36: aload_2
      //   37: putfield 29	android/app/ActivityThread$Profiler:profileFd	Landroid/os/ParcelFileDescriptor;
      //   40: return
      //   41: astore 4
      //   43: return
      //   44: astore_3
      //   45: goto -15 -> 30
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	48	0	this	Profiler
      //   0	48	1	paramString	String
      //   0	48	2	paramParcelFileDescriptor	ParcelFileDescriptor
      //   44	1	3	localIOException1	IOException
      //   41	1	4	localIOException2	IOException
      // Exception table:
      //   from	to	target	type
      //   11	15	41	java/io/IOException
      //   23	30	44	java/io/IOException
    }
    
    public void startProfiling()
    {
      if ((this.profileFd == null) || (this.profiling)) {
        return;
      }
      try
      {
        Debug.startMethodTracing(this.profileFile, this.profileFd.getFileDescriptor(), 8388608, 0);
        this.profiling = true;
        return;
      }
      catch (RuntimeException localRuntimeException)
      {
        Slog.w("ActivityThread", "Profiling failed on path " + this.profileFile);
        try
        {
          this.profileFd.close();
          this.profileFd = null;
          return;
        }
        catch (IOException localIOException)
        {
          Slog.w("ActivityThread", "Failure closing profile fd", localIOException);
        }
      }
    }
    
    public void stopProfiling()
    {
      if (this.profiling)
      {
        this.profiling = false;
        Debug.stopMethodTracing();
        if (this.profileFd == null) {}
      }
      try
      {
        this.profileFd.close();
        this.profileFd = null;
        this.profileFile = null;
        return;
      }
      catch (IOException localIOException)
      {
        for (;;) {}
      }
    }
  }
  
  static final class ProfilerControlData
  {
    ParcelFileDescriptor fd;
    String path;
  }
  
  final class ProviderClientRecord
  {
    final IActivityManager.ContentProviderHolder mHolder;
    final ContentProvider mLocalProvider;
    final String[] mNames;
    final IContentProvider mProvider;
    
    ProviderClientRecord(String[] paramArrayOfString, IContentProvider paramIContentProvider, ContentProvider paramContentProvider, IActivityManager.ContentProviderHolder paramContentProviderHolder)
    {
      this.mNames = paramArrayOfString;
      this.mProvider = paramIContentProvider;
      this.mLocalProvider = paramContentProvider;
      this.mHolder = paramContentProviderHolder;
    }
  }
  
  private static final class ProviderKey
  {
    final String authority;
    final int userId;
    
    public ProviderKey(String paramString, int paramInt)
    {
      this.authority = paramString;
      this.userId = paramInt;
    }
    
    public boolean equals(Object paramObject)
    {
      boolean bool1 = paramObject instanceof ProviderKey;
      boolean bool2 = false;
      if (bool1)
      {
        ProviderKey localProviderKey = (ProviderKey)paramObject;
        boolean bool3 = Objects.equal(this.authority, localProviderKey.authority);
        bool2 = false;
        if (bool3)
        {
          int i = this.userId;
          int j = localProviderKey.userId;
          bool2 = false;
          if (i == j) {
            bool2 = true;
          }
        }
      }
      return bool2;
    }
    
    public int hashCode()
    {
      if (this.authority != null) {}
      for (int i = this.authority.hashCode();; i = 0) {
        return i ^ this.userId;
      }
    }
  }
  
  private static final class ProviderRefCount
  {
    public final ActivityThread.ProviderClientRecord client;
    public final IActivityManager.ContentProviderHolder holder;
    public boolean removePending;
    public int stableCount;
    public int unstableCount;
    
    ProviderRefCount(IActivityManager.ContentProviderHolder paramContentProviderHolder, ActivityThread.ProviderClientRecord paramProviderClientRecord, int paramInt1, int paramInt2)
    {
      this.holder = paramContentProviderHolder;
      this.client = paramProviderClientRecord;
      this.stableCount = paramInt1;
      this.unstableCount = paramInt2;
    }
  }
  
  static final class ReceiverData
    extends BroadcastReceiver.PendingResult
  {
    CompatibilityInfo compatInfo;
    ActivityInfo info;
    Intent intent;
    
    public ReceiverData(Intent paramIntent, int paramInt1, String paramString, Bundle paramBundle, boolean paramBoolean1, boolean paramBoolean2, IBinder paramIBinder, int paramInt2)
    {
      super(paramString, paramBundle, 0, paramBoolean1, paramBoolean2, paramIBinder, paramInt2);
      this.intent = paramIntent;
    }
    
    public String toString()
    {
      return "ReceiverData{intent=" + this.intent + " packageName=" + this.info.packageName + " resultCode=" + getResultCode() + " resultData=" + getResultData() + " resultExtras=" + getResultExtras(false) + "}";
    }
  }
  
  private static class ResourcesKey
  {
    private final int mDisplayId;
    private final int mHash;
    private final Configuration mOverrideConfiguration;
    private final String mResDir;
    private final float mScale;
    
    ResourcesKey(String paramString, int paramInt, Configuration paramConfiguration, float paramFloat)
    {
      this.mResDir = paramString;
      this.mDisplayId = paramInt;
      if ((paramConfiguration != null) && (Configuration.EMPTY.equals(paramConfiguration))) {
        paramConfiguration = null;
      }
      this.mOverrideConfiguration = paramConfiguration;
      this.mScale = paramFloat;
      int i = 31 * (31 * (527 + this.mResDir.hashCode()) + this.mDisplayId);
      if (this.mOverrideConfiguration != null) {}
      for (int j = this.mOverrideConfiguration.hashCode();; j = 0)
      {
        this.mHash = (31 * (i + j) + Float.floatToIntBits(this.mScale));
        return;
      }
    }
    
    public boolean equals(Object paramObject)
    {
      if (!(paramObject instanceof ResourcesKey)) {}
      ResourcesKey localResourcesKey;
      do
      {
        return false;
        localResourcesKey = (ResourcesKey)paramObject;
      } while ((!this.mResDir.equals(localResourcesKey.mResDir)) || (this.mDisplayId != localResourcesKey.mDisplayId) || ((this.mOverrideConfiguration != localResourcesKey.mOverrideConfiguration) && ((this.mOverrideConfiguration == null) || (localResourcesKey.mOverrideConfiguration == null) || (!this.mOverrideConfiguration.equals(localResourcesKey.mOverrideConfiguration)))) || (this.mScale != localResourcesKey.mScale));
      return true;
    }
    
    public int hashCode()
    {
      return this.mHash;
    }
  }
  
  static final class ResultData
  {
    List<ResultInfo> results;
    IBinder token;
    
    public String toString()
    {
      return "ResultData{token=" + this.token + " results" + this.results + "}";
    }
  }
  
  static final class ServiceArgsData
  {
    Intent args;
    int flags;
    int startId;
    boolean taskRemoved;
    IBinder token;
    
    public String toString()
    {
      return "ServiceArgsData{token=" + this.token + " startId=" + this.startId + " args=" + this.args + "}";
    }
  }
  
  private static class StopInfo
    implements Runnable
  {
    ActivityThread.ActivityClientRecord activity;
    CharSequence description;
    Bundle state;
    Bitmap thumbnail;
    
    public void run()
    {
      try
      {
        ActivityManagerNative.getDefault().activityStopped(this.activity.token, this.state, this.thumbnail, this.description);
        return;
      }
      catch (RemoteException localRemoteException) {}
    }
  }
  
  static final class UpdateCompatibilityData
  {
    CompatibilityInfo info;
    String pkg;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\ActivityThread.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
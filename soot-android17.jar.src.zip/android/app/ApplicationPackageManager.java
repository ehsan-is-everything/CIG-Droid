package android.app;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.ContainerEncryptionParams;
import android.content.pm.FeatureInfo;
import android.content.pm.IPackageDataObserver;
import android.content.pm.IPackageDeleteObserver;
import android.content.pm.IPackageInstallObserver;
import android.content.pm.IPackageManager;
import android.content.pm.IPackageMoveObserver;
import android.content.pm.IPackageStatsObserver;
import android.content.pm.InstrumentationInfo;
import android.content.pm.ManifestDigest;
import android.content.pm.PackageInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.PermissionGroupInfo;
import android.content.pm.PermissionInfo;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.content.pm.VerificationParams;
import android.content.pm.VerifierDeviceIdentity;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.net.Uri;
import android.os.Process;
import android.os.RemoteException;
import android.util.Log;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

final class ApplicationPackageManager
  extends PackageManager
{
  private static final boolean DEBUG = false;
  private static final boolean DEBUG_ICONS = false;
  private static final String TAG = "ApplicationPackageManager";
  private static HashMap<ResourceName, WeakReference<Drawable.ConstantState>> sIconCache = new HashMap();
  private static HashMap<ResourceName, WeakReference<CharSequence>> sStringCache = new HashMap();
  private static final Object sSync = new Object();
  int mCachedSafeMode = -1;
  private final ContextImpl mContext;
  private final IPackageManager mPM;
  
  ApplicationPackageManager(ContextImpl paramContextImpl, IPackageManager paramIPackageManager)
  {
    this.mContext = paramContextImpl;
    this.mPM = paramIPackageManager;
  }
  
  static void configurationChanged()
  {
    synchronized (sSync)
    {
      sIconCache.clear();
      sStringCache.clear();
      return;
    }
  }
  
  private Drawable getCachedIcon(ResourceName paramResourceName)
  {
    synchronized (sSync)
    {
      WeakReference localWeakReference = (WeakReference)sIconCache.get(paramResourceName);
      if (localWeakReference != null)
      {
        Drawable.ConstantState localConstantState = (Drawable.ConstantState)localWeakReference.get();
        if (localConstantState != null)
        {
          Drawable localDrawable = localConstantState.newDrawable();
          return localDrawable;
        }
        sIconCache.remove(paramResourceName);
      }
      return null;
    }
  }
  
  private CharSequence getCachedString(ResourceName paramResourceName)
  {
    synchronized (sSync)
    {
      WeakReference localWeakReference = (WeakReference)sStringCache.get(paramResourceName);
      if (localWeakReference != null)
      {
        CharSequence localCharSequence = (CharSequence)localWeakReference.get();
        if (localCharSequence != null) {
          return localCharSequence;
        }
        sStringCache.remove(paramResourceName);
      }
      return null;
    }
  }
  
  static void handlePackageBroadcast(int paramInt, String[] paramArrayOfString, boolean paramBoolean)
  {
    int i = 0;
    if (paramInt == 1) {
      i = 1;
    }
    if ((paramArrayOfString != null) && (paramArrayOfString.length > 0))
    {
      int j = 0;
      int k = paramArrayOfString.length;
      int m = 0;
      while (m < k)
      {
        String str = paramArrayOfString[m];
        synchronized (sSync)
        {
          if (sIconCache.size() > 0)
          {
            Iterator localIterator2 = sIconCache.keySet().iterator();
            while (localIterator2.hasNext()) {
              if (((ResourceName)localIterator2.next()).packageName.equals(str))
              {
                localIterator2.remove();
                j = 1;
              }
            }
          }
          if (sStringCache.size() > 0)
          {
            Iterator localIterator1 = sStringCache.keySet().iterator();
            while (localIterator1.hasNext()) {
              if (((ResourceName)localIterator1.next()).packageName.equals(str))
              {
                localIterator1.remove();
                j = 1;
              }
            }
          }
          m++;
        }
      }
      if ((j != 0) || (paramBoolean))
      {
        if (i == 0) {
          break label218;
        }
        Runtime.getRuntime().gc();
      }
    }
    return;
    label218:
    ActivityThread.currentActivityThread().scheduleGcIdler();
  }
  
  private void putCachedIcon(ResourceName paramResourceName, Drawable paramDrawable)
  {
    synchronized (sSync)
    {
      sIconCache.put(paramResourceName, new WeakReference(paramDrawable.getConstantState()));
      return;
    }
  }
  
  private void putCachedString(ResourceName paramResourceName, CharSequence paramCharSequence)
  {
    synchronized (sSync)
    {
      sStringCache.put(paramResourceName, new WeakReference(paramCharSequence));
      return;
    }
  }
  
  public void addPackageToPreferred(String paramString)
  {
    try
    {
      this.mPM.addPackageToPreferred(paramString);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public boolean addPermission(PermissionInfo paramPermissionInfo)
  {
    try
    {
      boolean bool = this.mPM.addPermission(paramPermissionInfo);
      return bool;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public boolean addPermissionAsync(PermissionInfo paramPermissionInfo)
  {
    try
    {
      boolean bool = this.mPM.addPermissionAsync(paramPermissionInfo);
      return bool;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public void addPreferredActivity(IntentFilter paramIntentFilter, int paramInt, ComponentName[] paramArrayOfComponentName, ComponentName paramComponentName)
  {
    try
    {
      this.mPM.addPreferredActivity(paramIntentFilter, paramInt, paramArrayOfComponentName, paramComponentName, this.mContext.getUserId());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void addPreferredActivity(IntentFilter paramIntentFilter, int paramInt1, ComponentName[] paramArrayOfComponentName, ComponentName paramComponentName, int paramInt2)
  {
    try
    {
      this.mPM.addPreferredActivity(paramIntentFilter, paramInt1, paramArrayOfComponentName, paramComponentName, paramInt2);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public String[] canonicalToCurrentPackageNames(String[] paramArrayOfString)
  {
    try
    {
      String[] arrayOfString = this.mPM.canonicalToCurrentPackageNames(paramArrayOfString);
      return arrayOfString;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public int checkPermission(String paramString1, String paramString2)
  {
    try
    {
      int i = this.mPM.checkPermission(paramString1, paramString2);
      return i;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public int checkSignatures(int paramInt1, int paramInt2)
  {
    try
    {
      int i = this.mPM.checkUidSignatures(paramInt1, paramInt2);
      return i;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public int checkSignatures(String paramString1, String paramString2)
  {
    try
    {
      int i = this.mPM.checkSignatures(paramString1, paramString2);
      return i;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public void clearApplicationUserData(String paramString, IPackageDataObserver paramIPackageDataObserver)
  {
    try
    {
      this.mPM.clearApplicationUserData(paramString, paramIPackageDataObserver, this.mContext.getUserId());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void clearPackagePreferredActivities(String paramString)
  {
    try
    {
      this.mPM.clearPackagePreferredActivities(paramString);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public String[] currentToCanonicalPackageNames(String[] paramArrayOfString)
  {
    try
    {
      String[] arrayOfString = this.mPM.currentToCanonicalPackageNames(paramArrayOfString);
      return arrayOfString;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public void deleteApplicationCacheFiles(String paramString, IPackageDataObserver paramIPackageDataObserver)
  {
    try
    {
      this.mPM.deleteApplicationCacheFiles(paramString, paramIPackageDataObserver);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void deletePackage(String paramString, IPackageDeleteObserver paramIPackageDeleteObserver, int paramInt)
  {
    try
    {
      this.mPM.deletePackage(paramString, paramIPackageDeleteObserver, paramInt);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void extendVerificationTimeout(int paramInt1, int paramInt2, long paramLong)
  {
    try
    {
      this.mPM.extendVerificationTimeout(paramInt1, paramInt2, paramLong);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void freeStorage(long paramLong, IntentSender paramIntentSender)
  {
    try
    {
      this.mPM.freeStorage(paramLong, paramIntentSender);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void freeStorageAndNotify(long paramLong, IPackageDataObserver paramIPackageDataObserver)
  {
    try
    {
      this.mPM.freeStorageAndNotify(paramLong, paramIPackageDataObserver);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public Drawable getActivityIcon(ComponentName paramComponentName)
    throws PackageManager.NameNotFoundException
  {
    return getActivityInfo(paramComponentName, 0).loadIcon(this);
  }
  
  public Drawable getActivityIcon(Intent paramIntent)
    throws PackageManager.NameNotFoundException
  {
    if (paramIntent.getComponent() != null) {
      return getActivityIcon(paramIntent.getComponent());
    }
    ResolveInfo localResolveInfo = resolveActivity(paramIntent, 65536);
    if (localResolveInfo != null) {
      return localResolveInfo.activityInfo.loadIcon(this);
    }
    throw new PackageManager.NameNotFoundException(paramIntent.toUri(0));
  }
  
  public ActivityInfo getActivityInfo(ComponentName paramComponentName, int paramInt)
    throws PackageManager.NameNotFoundException
  {
    try
    {
      ActivityInfo localActivityInfo = this.mPM.getActivityInfo(paramComponentName, paramInt, this.mContext.getUserId());
      if (localActivityInfo != null) {
        return localActivityInfo;
      }
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
    throw new PackageManager.NameNotFoundException(paramComponentName.toString());
  }
  
  public Drawable getActivityLogo(ComponentName paramComponentName)
    throws PackageManager.NameNotFoundException
  {
    return getActivityInfo(paramComponentName, 0).loadLogo(this);
  }
  
  public Drawable getActivityLogo(Intent paramIntent)
    throws PackageManager.NameNotFoundException
  {
    if (paramIntent.getComponent() != null) {
      return getActivityLogo(paramIntent.getComponent());
    }
    ResolveInfo localResolveInfo = resolveActivity(paramIntent, 65536);
    if (localResolveInfo != null) {
      return localResolveInfo.activityInfo.loadLogo(this);
    }
    throw new PackageManager.NameNotFoundException(paramIntent.toUri(0));
  }
  
  public List<PermissionGroupInfo> getAllPermissionGroups(int paramInt)
  {
    try
    {
      List localList = this.mPM.getAllPermissionGroups(paramInt);
      return localList;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public int getApplicationEnabledSetting(String paramString)
  {
    try
    {
      int i = this.mPM.getApplicationEnabledSetting(paramString, this.mContext.getUserId());
      return i;
    }
    catch (RemoteException localRemoteException) {}
    return 0;
  }
  
  public Drawable getApplicationIcon(ApplicationInfo paramApplicationInfo)
  {
    return paramApplicationInfo.loadIcon(this);
  }
  
  public Drawable getApplicationIcon(String paramString)
    throws PackageManager.NameNotFoundException
  {
    return getApplicationIcon(getApplicationInfo(paramString, 0));
  }
  
  public ApplicationInfo getApplicationInfo(String paramString, int paramInt)
    throws PackageManager.NameNotFoundException
  {
    try
    {
      ApplicationInfo localApplicationInfo = this.mPM.getApplicationInfo(paramString, paramInt, this.mContext.getUserId());
      if (localApplicationInfo != null) {
        return localApplicationInfo;
      }
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
    throw new PackageManager.NameNotFoundException(paramString);
  }
  
  public CharSequence getApplicationLabel(ApplicationInfo paramApplicationInfo)
  {
    return paramApplicationInfo.loadLabel(this);
  }
  
  public Drawable getApplicationLogo(ApplicationInfo paramApplicationInfo)
  {
    return paramApplicationInfo.loadLogo(this);
  }
  
  public Drawable getApplicationLogo(String paramString)
    throws PackageManager.NameNotFoundException
  {
    return getApplicationLogo(getApplicationInfo(paramString, 0));
  }
  
  public int getComponentEnabledSetting(ComponentName paramComponentName)
  {
    try
    {
      int i = this.mPM.getComponentEnabledSetting(paramComponentName, this.mContext.getUserId());
      return i;
    }
    catch (RemoteException localRemoteException) {}
    return 0;
  }
  
  public Drawable getDefaultActivityIcon()
  {
    return Resources.getSystem().getDrawable(17301651);
  }
  
  public Drawable getDrawable(String paramString, int paramInt, ApplicationInfo paramApplicationInfo)
  {
    ResourceName localResourceName = new ResourceName(paramString, paramInt);
    Drawable localDrawable1 = getCachedIcon(localResourceName);
    if (localDrawable1 != null) {
      return localDrawable1;
    }
    if (paramApplicationInfo == null) {}
    try
    {
      ApplicationInfo localApplicationInfo = getApplicationInfo(paramString, 0);
      paramApplicationInfo = localApplicationInfo;
      Drawable localDrawable2;
      return null;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException2)
    {
      try
      {
        localDrawable2 = getResourcesForApplication(paramApplicationInfo).getDrawable(paramInt);
        putCachedIcon(localResourceName, localDrawable2);
        return localDrawable2;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException1)
      {
        Log.w("PackageManager", "Failure retrieving resources for" + paramApplicationInfo.packageName);
        return null;
      }
      catch (Resources.NotFoundException localNotFoundException)
      {
        Log.w("PackageManager", "Failure retrieving resources for" + paramApplicationInfo.packageName + ": " + localNotFoundException.getMessage());
        return null;
      }
      catch (RuntimeException localRuntimeException)
      {
        Log.w("PackageManager", "Failure retrieving icon 0x" + Integer.toHexString(paramInt) + " in package " + paramString, localRuntimeException);
      }
      localNameNotFoundException2 = localNameNotFoundException2;
      return null;
    }
  }
  
  /* Error */
  public List<ApplicationInfo> getInstalledApplications(int paramInt)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 47	android/app/ApplicationPackageManager:mContext	Landroid/app/ContextImpl;
    //   4: invokevirtual 179	android/app/ContextImpl:getUserId	()I
    //   7: istore_2
    //   8: new 387	java/util/ArrayList
    //   11: dup
    //   12: invokespecial 388	java/util/ArrayList:<init>	()V
    //   15: astore_3
    //   16: aconst_null
    //   17: astore 4
    //   19: aload 4
    //   21: ifnull +53 -> 74
    //   24: aload 4
    //   26: getfield 361	android/content/pm/PackageItemInfo:packageName	Ljava/lang/String;
    //   29: astore 6
    //   31: aload_0
    //   32: getfield 49	android/app/ApplicationPackageManager:mPM	Landroid/content/pm/IPackageManager;
    //   35: iload_1
    //   36: aload 6
    //   38: iload_2
    //   39: invokeinterface 391 4 0
    //   44: astore 7
    //   46: aload 7
    //   48: aload_3
    //   49: getstatic 395	android/content/pm/ApplicationInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   52: invokevirtual 401	android/content/pm/ParceledListSlice:populateList	(Ljava/util/List;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;
    //   55: checkcast 295	android/content/pm/ApplicationInfo
    //   58: astore 4
    //   60: aload 7
    //   62: invokevirtual 404	android/content/pm/ParceledListSlice:isLastSlice	()Z
    //   65: istore 8
    //   67: iload 8
    //   69: ifeq -50 -> 19
    //   72: aload_3
    //   73: areturn
    //   74: aconst_null
    //   75: astore 6
    //   77: goto -46 -> 31
    //   80: astore 5
    //   82: new 164	java/lang/RuntimeException
    //   85: dup
    //   86: ldc -90
    //   88: aload 5
    //   90: invokespecial 169	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   93: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	94	0	this	ApplicationPackageManager
    //   0	94	1	paramInt	int
    //   7	32	2	i	int
    //   15	58	3	localArrayList	ArrayList
    //   17	42	4	localApplicationInfo	ApplicationInfo
    //   80	9	5	localRemoteException	RemoteException
    //   29	47	6	str	String
    //   44	17	7	localParceledListSlice	android.content.pm.ParceledListSlice
    //   65	3	8	bool	boolean
    // Exception table:
    //   from	to	target	type
    //   8	16	80	android/os/RemoteException
    //   24	31	80	android/os/RemoteException
    //   31	67	80	android/os/RemoteException
  }
  
  public List<PackageInfo> getInstalledPackages(int paramInt)
  {
    return getInstalledPackages(paramInt, this.mContext.getUserId());
  }
  
  /* Error */
  public List<PackageInfo> getInstalledPackages(int paramInt1, int paramInt2)
  {
    // Byte code:
    //   0: new 387	java/util/ArrayList
    //   3: dup
    //   4: invokespecial 388	java/util/ArrayList:<init>	()V
    //   7: astore_3
    //   8: aconst_null
    //   9: astore 4
    //   11: aload 4
    //   13: ifnull +53 -> 66
    //   16: aload 4
    //   18: getfield 411	android/content/pm/PackageInfo:packageName	Ljava/lang/String;
    //   21: astore 6
    //   23: aload_0
    //   24: getfield 49	android/app/ApplicationPackageManager:mPM	Landroid/content/pm/IPackageManager;
    //   27: iload_1
    //   28: aload 6
    //   30: iload_2
    //   31: invokeinterface 413 4 0
    //   36: astore 7
    //   38: aload 7
    //   40: aload_3
    //   41: getstatic 414	android/content/pm/PackageInfo:CREATOR	Landroid/os/Parcelable$Creator;
    //   44: invokevirtual 401	android/content/pm/ParceledListSlice:populateList	(Ljava/util/List;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;
    //   47: checkcast 410	android/content/pm/PackageInfo
    //   50: astore 4
    //   52: aload 7
    //   54: invokevirtual 404	android/content/pm/ParceledListSlice:isLastSlice	()Z
    //   57: istore 8
    //   59: iload 8
    //   61: ifeq -50 -> 11
    //   64: aload_3
    //   65: areturn
    //   66: aconst_null
    //   67: astore 6
    //   69: goto -46 -> 23
    //   72: astore 5
    //   74: new 164	java/lang/RuntimeException
    //   77: dup
    //   78: ldc -90
    //   80: aload 5
    //   82: invokespecial 169	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   85: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	86	0	this	ApplicationPackageManager
    //   0	86	1	paramInt1	int
    //   0	86	2	paramInt2	int
    //   7	58	3	localArrayList	ArrayList
    //   9	42	4	localPackageInfo	PackageInfo
    //   72	9	5	localRemoteException	RemoteException
    //   21	47	6	str	String
    //   36	17	7	localParceledListSlice	android.content.pm.ParceledListSlice
    //   57	3	8	bool	boolean
    // Exception table:
    //   from	to	target	type
    //   0	8	72	android/os/RemoteException
    //   16	23	72	android/os/RemoteException
    //   23	59	72	android/os/RemoteException
  }
  
  public String getInstallerPackageName(String paramString)
  {
    try
    {
      String str = this.mPM.getInstallerPackageName(paramString);
      return str;
    }
    catch (RemoteException localRemoteException) {}
    return null;
  }
  
  public InstrumentationInfo getInstrumentationInfo(ComponentName paramComponentName, int paramInt)
    throws PackageManager.NameNotFoundException
  {
    try
    {
      InstrumentationInfo localInstrumentationInfo = this.mPM.getInstrumentationInfo(paramComponentName, paramInt);
      if (localInstrumentationInfo != null) {
        return localInstrumentationInfo;
      }
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
    throw new PackageManager.NameNotFoundException(paramComponentName.toString());
  }
  
  public Intent getLaunchIntentForPackage(String paramString)
  {
    Intent localIntent1 = new Intent("android.intent.action.MAIN");
    localIntent1.addCategory("android.intent.category.INFO");
    localIntent1.setPackage(paramString);
    List localList = queryIntentActivities(localIntent1, 0);
    if ((localList == null) || (localList.size() <= 0))
    {
      localIntent1.removeCategory("android.intent.category.INFO");
      localIntent1.addCategory("android.intent.category.LAUNCHER");
      localIntent1.setPackage(paramString);
      localList = queryIntentActivities(localIntent1, 0);
    }
    if ((localList == null) || (localList.size() <= 0)) {
      return null;
    }
    Intent localIntent2 = new Intent(localIntent1);
    localIntent2.setFlags(268435456);
    localIntent2.setClassName(((ResolveInfo)localList.get(0)).activityInfo.packageName, ((ResolveInfo)localList.get(0)).activityInfo.name);
    return localIntent2;
  }
  
  public String getNameForUid(int paramInt)
  {
    try
    {
      String str = this.mPM.getNameForUid(paramInt);
      return str;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public int[] getPackageGids(String paramString)
    throws PackageManager.NameNotFoundException
  {
    try
    {
      int[] arrayOfInt = this.mPM.getPackageGids(paramString);
      if (arrayOfInt != null)
      {
        int i = arrayOfInt.length;
        if (i <= 0) {}
      }
      else
      {
        return arrayOfInt;
      }
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
    throw new PackageManager.NameNotFoundException(paramString);
  }
  
  public PackageInfo getPackageInfo(String paramString, int paramInt)
    throws PackageManager.NameNotFoundException
  {
    try
    {
      PackageInfo localPackageInfo = this.mPM.getPackageInfo(paramString, paramInt, this.mContext.getUserId());
      if (localPackageInfo != null) {
        return localPackageInfo;
      }
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
    throw new PackageManager.NameNotFoundException(paramString);
  }
  
  public void getPackageSizeInfo(String paramString, int paramInt, IPackageStatsObserver paramIPackageStatsObserver)
  {
    try
    {
      this.mPM.getPackageSizeInfo(paramString, paramInt, paramIPackageStatsObserver);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public String[] getPackagesForUid(int paramInt)
  {
    try
    {
      String[] arrayOfString = this.mPM.getPackagesForUid(paramInt);
      return arrayOfString;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public PermissionGroupInfo getPermissionGroupInfo(String paramString, int paramInt)
    throws PackageManager.NameNotFoundException
  {
    try
    {
      PermissionGroupInfo localPermissionGroupInfo = this.mPM.getPermissionGroupInfo(paramString, paramInt);
      if (localPermissionGroupInfo != null) {
        return localPermissionGroupInfo;
      }
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
    throw new PackageManager.NameNotFoundException(paramString);
  }
  
  public PermissionInfo getPermissionInfo(String paramString, int paramInt)
    throws PackageManager.NameNotFoundException
  {
    try
    {
      PermissionInfo localPermissionInfo = this.mPM.getPermissionInfo(paramString, paramInt);
      if (localPermissionInfo != null) {
        return localPermissionInfo;
      }
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
    throw new PackageManager.NameNotFoundException(paramString);
  }
  
  public int getPreferredActivities(List<IntentFilter> paramList, List<ComponentName> paramList1, String paramString)
  {
    try
    {
      int i = this.mPM.getPreferredActivities(paramList, paramList1, paramString);
      return i;
    }
    catch (RemoteException localRemoteException) {}
    return 0;
  }
  
  public List<PackageInfo> getPreferredPackages(int paramInt)
  {
    try
    {
      List localList = this.mPM.getPreferredPackages(paramInt);
      return localList;
    }
    catch (RemoteException localRemoteException) {}
    return new ArrayList();
  }
  
  public ProviderInfo getProviderInfo(ComponentName paramComponentName, int paramInt)
    throws PackageManager.NameNotFoundException
  {
    try
    {
      ProviderInfo localProviderInfo = this.mPM.getProviderInfo(paramComponentName, paramInt, this.mContext.getUserId());
      if (localProviderInfo != null) {
        return localProviderInfo;
      }
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
    throw new PackageManager.NameNotFoundException(paramComponentName.toString());
  }
  
  public ActivityInfo getReceiverInfo(ComponentName paramComponentName, int paramInt)
    throws PackageManager.NameNotFoundException
  {
    try
    {
      ActivityInfo localActivityInfo = this.mPM.getReceiverInfo(paramComponentName, paramInt, this.mContext.getUserId());
      if (localActivityInfo != null) {
        return localActivityInfo;
      }
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
    throw new PackageManager.NameNotFoundException(paramComponentName.toString());
  }
  
  public Resources getResourcesForActivity(ComponentName paramComponentName)
    throws PackageManager.NameNotFoundException
  {
    return getResourcesForApplication(getActivityInfo(paramComponentName, 0).applicationInfo);
  }
  
  public Resources getResourcesForApplication(ApplicationInfo paramApplicationInfo)
    throws PackageManager.NameNotFoundException
  {
    Resources localResources;
    if (paramApplicationInfo.packageName.equals("system"))
    {
      localResources = this.mContext.mMainThread.getSystemContext().getResources();
      return localResources;
    }
    ActivityThread localActivityThread = this.mContext.mMainThread;
    if (paramApplicationInfo.uid == Process.myUid()) {}
    for (String str = paramApplicationInfo.sourceDir;; str = paramApplicationInfo.publicSourceDir)
    {
      localResources = localActivityThread.getTopLevelResources(str, 0, null, this.mContext.mPackageInfo);
      if (localResources != null) {
        break;
      }
      throw new PackageManager.NameNotFoundException("Unable to open " + paramApplicationInfo.publicSourceDir);
    }
  }
  
  public Resources getResourcesForApplication(String paramString)
    throws PackageManager.NameNotFoundException
  {
    return getResourcesForApplication(getApplicationInfo(paramString, 0));
  }
  
  public Resources getResourcesForApplicationAsUser(String paramString, int paramInt)
    throws PackageManager.NameNotFoundException
  {
    if (paramInt < 0) {
      throw new IllegalArgumentException("Call does not support special user #" + paramInt);
    }
    if ("system".equals(paramString)) {
      return this.mContext.mMainThread.getSystemContext().getResources();
    }
    try
    {
      ApplicationInfo localApplicationInfo = this.mPM.getApplicationInfo(paramString, 0, paramInt);
      if (localApplicationInfo != null)
      {
        Resources localResources = getResourcesForApplication(localApplicationInfo);
        return localResources;
      }
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
    throw new PackageManager.NameNotFoundException("Package " + paramString + " doesn't exist");
  }
  
  public ServiceInfo getServiceInfo(ComponentName paramComponentName, int paramInt)
    throws PackageManager.NameNotFoundException
  {
    try
    {
      ServiceInfo localServiceInfo = this.mPM.getServiceInfo(paramComponentName, paramInt, this.mContext.getUserId());
      if (localServiceInfo != null) {
        return localServiceInfo;
      }
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
    throw new PackageManager.NameNotFoundException(paramComponentName.toString());
  }
  
  public FeatureInfo[] getSystemAvailableFeatures()
  {
    try
    {
      FeatureInfo[] arrayOfFeatureInfo = this.mPM.getSystemAvailableFeatures();
      return arrayOfFeatureInfo;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public String[] getSystemSharedLibraryNames()
  {
    try
    {
      String[] arrayOfString = this.mPM.getSystemSharedLibraryNames();
      return arrayOfString;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public CharSequence getText(String paramString, int paramInt, ApplicationInfo paramApplicationInfo)
  {
    ResourceName localResourceName = new ResourceName(paramString, paramInt);
    CharSequence localCharSequence1 = getCachedString(localResourceName);
    if (localCharSequence1 != null) {
      return localCharSequence1;
    }
    if (paramApplicationInfo == null) {}
    try
    {
      ApplicationInfo localApplicationInfo = getApplicationInfo(paramString, 0);
      paramApplicationInfo = localApplicationInfo;
      CharSequence localCharSequence2;
      return null;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException2)
    {
      try
      {
        localCharSequence2 = getResourcesForApplication(paramApplicationInfo).getText(paramInt);
        putCachedString(localResourceName, localCharSequence2);
        return localCharSequence2;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException1)
      {
        Log.w("PackageManager", "Failure retrieving resources for" + paramApplicationInfo.packageName);
        return null;
      }
      catch (RuntimeException localRuntimeException)
      {
        Log.w("PackageManager", "Failure retrieving text 0x" + Integer.toHexString(paramInt) + " in package " + paramString, localRuntimeException);
      }
      localNameNotFoundException2 = localNameNotFoundException2;
      return null;
    }
  }
  
  public int getUidForSharedUser(String paramString)
    throws PackageManager.NameNotFoundException
  {
    try
    {
      int i = this.mPM.getUidForSharedUser(paramString);
      if (i != -1) {
        return i;
      }
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
    throw new PackageManager.NameNotFoundException("No shared userid for user:" + paramString);
  }
  
  public VerifierDeviceIdentity getVerifierDeviceIdentity()
  {
    try
    {
      VerifierDeviceIdentity localVerifierDeviceIdentity = this.mPM.getVerifierDeviceIdentity();
      return localVerifierDeviceIdentity;
    }
    catch (RemoteException localRemoteException) {}
    return null;
  }
  
  /* Error */
  public android.content.res.XmlResourceParser getXml(String paramString, int paramInt, ApplicationInfo paramApplicationInfo)
  {
    // Byte code:
    //   0: aload_3
    //   1: ifnonnull +14 -> 15
    //   4: aload_0
    //   5: aload_1
    //   6: iconst_0
    //   7: invokevirtual 301	android/app/ApplicationPackageManager:getApplicationInfo	(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    //   10: astore 10
    //   12: aload 10
    //   14: astore_3
    //   15: aload_0
    //   16: aload_3
    //   17: invokevirtual 345	android/app/ApplicationPackageManager:getResourcesForApplication	(Landroid/content/pm/ApplicationInfo;)Landroid/content/res/Resources;
    //   20: iload_2
    //   21: invokevirtual 606	android/content/res/Resources:getXml	(I)Landroid/content/res/XmlResourceParser;
    //   24: astore 8
    //   26: aload 8
    //   28: areturn
    //   29: astore 9
    //   31: aconst_null
    //   32: areturn
    //   33: astore 6
    //   35: ldc_w 349
    //   38: new 351	java/lang/StringBuilder
    //   41: dup
    //   42: invokespecial 352	java/lang/StringBuilder:<init>	()V
    //   45: ldc_w 608
    //   48: invokevirtual 358	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: iload_2
    //   52: invokestatic 379	java/lang/Integer:toHexString	(I)Ljava/lang/String;
    //   55: invokevirtual 358	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   58: ldc_w 381
    //   61: invokevirtual 358	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: aload_1
    //   65: invokevirtual 358	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: invokevirtual 362	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   71: aload 6
    //   73: invokestatic 384	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   76: pop
    //   77: aconst_null
    //   78: areturn
    //   79: astore 4
    //   81: ldc_w 349
    //   84: new 351	java/lang/StringBuilder
    //   87: dup
    //   88: invokespecial 352	java/lang/StringBuilder:<init>	()V
    //   91: ldc_w 610
    //   94: invokevirtual 358	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   97: aload_3
    //   98: getfield 361	android/content/pm/PackageItemInfo:packageName	Ljava/lang/String;
    //   101: invokevirtual 358	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   104: invokevirtual 362	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   107: invokestatic 367	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   110: pop
    //   111: aconst_null
    //   112: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	113	0	this	ApplicationPackageManager
    //   0	113	1	paramString	String
    //   0	113	2	paramInt	int
    //   0	113	3	paramApplicationInfo	ApplicationInfo
    //   79	1	4	localNameNotFoundException1	PackageManager.NameNotFoundException
    //   33	39	6	localRuntimeException	RuntimeException
    //   24	3	8	localXmlResourceParser	android.content.res.XmlResourceParser
    //   29	1	9	localNameNotFoundException2	PackageManager.NameNotFoundException
    //   10	3	10	localApplicationInfo	ApplicationInfo
    // Exception table:
    //   from	to	target	type
    //   4	12	29	android/content/pm/PackageManager$NameNotFoundException
    //   15	26	33	java/lang/RuntimeException
    //   15	26	79	android/content/pm/PackageManager$NameNotFoundException
  }
  
  public void grantPermission(String paramString1, String paramString2)
  {
    try
    {
      this.mPM.grantPermission(paramString1, paramString2);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public boolean hasSystemFeature(String paramString)
  {
    try
    {
      boolean bool = this.mPM.hasSystemFeature(paramString);
      return bool;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public int installExistingPackage(String paramString)
    throws PackageManager.NameNotFoundException
  {
    int i;
    try
    {
      i = this.mPM.installExistingPackage(paramString);
      if (i == -3) {
        throw new PackageManager.NameNotFoundException("Package " + paramString + " doesn't exist");
      }
    }
    catch (RemoteException localRemoteException)
    {
      throw new PackageManager.NameNotFoundException("Package " + paramString + " doesn't exist");
    }
    return i;
  }
  
  public void installPackage(Uri paramUri, IPackageInstallObserver paramIPackageInstallObserver, int paramInt, String paramString)
  {
    try
    {
      this.mPM.installPackage(paramUri, paramIPackageInstallObserver, paramInt, paramString);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void installPackageWithVerification(Uri paramUri1, IPackageInstallObserver paramIPackageInstallObserver, int paramInt, String paramString, Uri paramUri2, ManifestDigest paramManifestDigest, ContainerEncryptionParams paramContainerEncryptionParams)
  {
    try
    {
      this.mPM.installPackageWithVerification(paramUri1, paramIPackageInstallObserver, paramInt, paramString, paramUri2, paramManifestDigest, paramContainerEncryptionParams);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void installPackageWithVerificationAndEncryption(Uri paramUri, IPackageInstallObserver paramIPackageInstallObserver, int paramInt, String paramString, VerificationParams paramVerificationParams, ContainerEncryptionParams paramContainerEncryptionParams)
  {
    try
    {
      this.mPM.installPackageWithVerificationAndEncryption(paramUri, paramIPackageInstallObserver, paramInt, paramString, paramVerificationParams, paramContainerEncryptionParams);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public boolean isSafeMode()
  {
    try
    {
      if (this.mCachedSafeMode < 0) {
        if (!this.mPM.isSafeMode()) {
          break label37;
        }
      }
      label37:
      for (int j = 1;; j = 0)
      {
        this.mCachedSafeMode = j;
        int i = this.mCachedSafeMode;
        if (i == 0) {
          break;
        }
        return true;
      }
      return false;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public void movePackage(String paramString, IPackageMoveObserver paramIPackageMoveObserver, int paramInt)
  {
    try
    {
      this.mPM.movePackage(paramString, paramIPackageMoveObserver, paramInt);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public List<ResolveInfo> queryBroadcastReceivers(Intent paramIntent, int paramInt)
  {
    return queryBroadcastReceivers(paramIntent, paramInt, this.mContext.getUserId());
  }
  
  public List<ResolveInfo> queryBroadcastReceivers(Intent paramIntent, int paramInt1, int paramInt2)
  {
    try
    {
      List localList = this.mPM.queryIntentReceivers(paramIntent, paramIntent.resolveTypeIfNeeded(this.mContext.getContentResolver()), paramInt1, paramInt2);
      return localList;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public List<ProviderInfo> queryContentProviders(String paramString, int paramInt1, int paramInt2)
  {
    try
    {
      List localList = this.mPM.queryContentProviders(paramString, paramInt1, paramInt2);
      return localList;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public List<InstrumentationInfo> queryInstrumentation(String paramString, int paramInt)
  {
    try
    {
      List localList = this.mPM.queryInstrumentation(paramString, paramInt);
      return localList;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public List<ResolveInfo> queryIntentActivities(Intent paramIntent, int paramInt)
  {
    return queryIntentActivitiesAsUser(paramIntent, paramInt, this.mContext.getUserId());
  }
  
  public List<ResolveInfo> queryIntentActivitiesAsUser(Intent paramIntent, int paramInt1, int paramInt2)
  {
    try
    {
      List localList = this.mPM.queryIntentActivities(paramIntent, paramIntent.resolveTypeIfNeeded(this.mContext.getContentResolver()), paramInt1, paramInt2);
      return localList;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public List<ResolveInfo> queryIntentActivityOptions(ComponentName paramComponentName, Intent[] paramArrayOfIntent, Intent paramIntent, int paramInt)
  {
    ContentResolver localContentResolver = this.mContext.getContentResolver();
    String[] arrayOfString = null;
    if (paramArrayOfIntent != null)
    {
      int i = paramArrayOfIntent.length;
      for (int j = 0; j < i; j++)
      {
        Intent localIntent = paramArrayOfIntent[j];
        if (localIntent != null)
        {
          String str = localIntent.resolveTypeIfNeeded(localContentResolver);
          if (str != null)
          {
            if (arrayOfString == null) {
              arrayOfString = new String[i];
            }
            arrayOfString[j] = str;
          }
        }
      }
    }
    try
    {
      List localList = this.mPM.queryIntentActivityOptions(paramComponentName, paramArrayOfIntent, arrayOfString, paramIntent, paramIntent.resolveTypeIfNeeded(localContentResolver), paramInt, this.mContext.getUserId());
      return localList;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public List<ResolveInfo> queryIntentServices(Intent paramIntent, int paramInt)
  {
    return queryIntentServicesAsUser(paramIntent, paramInt, this.mContext.getUserId());
  }
  
  public List<ResolveInfo> queryIntentServicesAsUser(Intent paramIntent, int paramInt1, int paramInt2)
  {
    try
    {
      List localList = this.mPM.queryIntentServices(paramIntent, paramIntent.resolveTypeIfNeeded(this.mContext.getContentResolver()), paramInt1, paramInt2);
      return localList;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public List<PermissionInfo> queryPermissionsByGroup(String paramString, int paramInt)
    throws PackageManager.NameNotFoundException
  {
    try
    {
      List localList = this.mPM.queryPermissionsByGroup(paramString, paramInt);
      if (localList != null) {
        return localList;
      }
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
    throw new PackageManager.NameNotFoundException(paramString);
  }
  
  public void removePackageFromPreferred(String paramString)
  {
    try
    {
      this.mPM.removePackageFromPreferred(paramString);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void removePermission(String paramString)
  {
    try
    {
      this.mPM.removePermission(paramString);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public void replacePreferredActivity(IntentFilter paramIntentFilter, int paramInt, ComponentName[] paramArrayOfComponentName, ComponentName paramComponentName)
  {
    try
    {
      this.mPM.replacePreferredActivity(paramIntentFilter, paramInt, paramArrayOfComponentName, paramComponentName);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public ResolveInfo resolveActivity(Intent paramIntent, int paramInt)
  {
    return resolveActivityAsUser(paramIntent, paramInt, this.mContext.getUserId());
  }
  
  public ResolveInfo resolveActivityAsUser(Intent paramIntent, int paramInt1, int paramInt2)
  {
    try
    {
      ResolveInfo localResolveInfo = this.mPM.resolveIntent(paramIntent, paramIntent.resolveTypeIfNeeded(this.mContext.getContentResolver()), paramInt1, paramInt2);
      return localResolveInfo;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public ProviderInfo resolveContentProvider(String paramString, int paramInt)
  {
    try
    {
      ProviderInfo localProviderInfo = this.mPM.resolveContentProvider(paramString, paramInt, this.mContext.getUserId());
      return localProviderInfo;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public ResolveInfo resolveService(Intent paramIntent, int paramInt)
  {
    try
    {
      ResolveInfo localResolveInfo = this.mPM.resolveService(paramIntent, paramIntent.resolveTypeIfNeeded(this.mContext.getContentResolver()), paramInt, this.mContext.getUserId());
      return localResolveInfo;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public void revokePermission(String paramString1, String paramString2)
  {
    try
    {
      this.mPM.revokePermission(paramString1, paramString2);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Package manager has died", localRemoteException);
    }
  }
  
  public void setApplicationEnabledSetting(String paramString, int paramInt1, int paramInt2)
  {
    try
    {
      this.mPM.setApplicationEnabledSetting(paramString, paramInt1, paramInt2, this.mContext.getUserId());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void setComponentEnabledSetting(ComponentName paramComponentName, int paramInt1, int paramInt2)
  {
    try
    {
      this.mPM.setComponentEnabledSetting(paramComponentName, paramInt1, paramInt2, this.mContext.getUserId());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void setInstallerPackageName(String paramString1, String paramString2)
  {
    try
    {
      this.mPM.setInstallerPackageName(paramString1, paramString2);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void verifyPendingInstall(int paramInt1, int paramInt2)
  {
    try
    {
      this.mPM.verifyPendingInstall(paramInt1, paramInt2);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  private static final class ResourceName
  {
    final int iconId;
    final String packageName;
    
    ResourceName(ApplicationInfo paramApplicationInfo, int paramInt)
    {
      this(paramApplicationInfo.packageName, paramInt);
    }
    
    ResourceName(ComponentInfo paramComponentInfo, int paramInt)
    {
      this(paramComponentInfo.applicationInfo.packageName, paramInt);
    }
    
    ResourceName(ResolveInfo paramResolveInfo, int paramInt)
    {
      this(paramResolveInfo.activityInfo.applicationInfo.packageName, paramInt);
    }
    
    ResourceName(String paramString, int paramInt)
    {
      this.packageName = paramString;
      this.iconId = paramInt;
    }
    
    public boolean equals(Object paramObject)
    {
      if (this == paramObject) {}
      ResourceName localResourceName;
      do
      {
        return true;
        if ((paramObject == null) || (getClass() != paramObject.getClass())) {
          return false;
        }
        localResourceName = (ResourceName)paramObject;
        if (this.iconId != localResourceName.iconId) {
          return false;
        }
        if (this.packageName == null) {
          break;
        }
      } while (this.packageName.equals(localResourceName.packageName));
      while (localResourceName.packageName != null) {
        return false;
      }
      return true;
    }
    
    public int hashCode()
    {
      return 31 * this.packageName.hashCode() + this.iconId;
    }
    
    public String toString()
    {
      return "{ResourceName " + this.packageName + " / " + this.iconId + "}";
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\ApplicationPackageManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.app;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.ParcelFileDescriptor;
import android.os.ParcelFileDescriptor.AutoCloseOutputStream;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.IWindowSession;
import android.view.WindowManager;
import android.view.WindowManagerGlobal;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class WallpaperManager
{
  public static final String ACTION_CHANGE_LIVE_WALLPAPER = "android.service.wallpaper.CHANGE_LIVE_WALLPAPER";
  public static final String ACTION_LIVE_WALLPAPER_CHOOSER = "android.service.wallpaper.LIVE_WALLPAPER_CHOOSER";
  public static final String COMMAND_DROP = "android.home.drop";
  public static final String COMMAND_SECONDARY_TAP = "android.wallpaper.secondaryTap";
  public static final String COMMAND_TAP = "android.wallpaper.tap";
  private static boolean DEBUG = false;
  public static final String EXTRA_LIVE_WALLPAPER_COMPONENT = "android.service.wallpaper.extra.LIVE_WALLPAPER_COMPONENT";
  private static String TAG = "WallpaperManager";
  public static final String WALLPAPER_PREVIEW_META_DATA = "android.wallpaper.preview";
  private static Globals sGlobals;
  private static final Object sSync = new Object[0];
  private final Context mContext;
  private float mWallpaperXStep = -1.0F;
  private float mWallpaperYStep = -1.0F;
  
  WallpaperManager(Context paramContext, Handler paramHandler)
  {
    this.mContext = paramContext;
    initGlobals(paramContext.getMainLooper());
  }
  
  static Bitmap generateBitmap(Context paramContext, Bitmap paramBitmap, int paramInt1, int paramInt2)
  {
    if (paramBitmap == null) {
      paramBitmap = null;
    }
    DisplayMetrics localDisplayMetrics;
    do
    {
      return paramBitmap;
      WindowManager localWindowManager = (WindowManager)paramContext.getSystemService("window");
      localDisplayMetrics = new DisplayMetrics();
      localWindowManager.getDefaultDisplay().getMetrics(localDisplayMetrics);
      paramBitmap.setDensity(localDisplayMetrics.noncompatDensityDpi);
    } while ((paramInt1 <= 0) || (paramInt2 <= 0) || ((paramBitmap.getWidth() == paramInt1) && (paramBitmap.getHeight() == paramInt2)));
    try
    {
      Bitmap localBitmap = Bitmap.createBitmap(paramInt1, paramInt2, Bitmap.Config.ARGB_8888);
      localBitmap.setDensity(localDisplayMetrics.noncompatDensityDpi);
      Canvas localCanvas = new Canvas(localBitmap);
      Rect localRect = new Rect();
      localRect.right = paramBitmap.getWidth();
      localRect.bottom = paramBitmap.getHeight();
      int i = paramInt1 - localRect.right;
      int j = paramInt2 - localRect.bottom;
      if ((i > 0) || (j > 0)) {
        if (i <= j) {
          break label293;
        }
      }
      label293:
      float f2;
      int k;
      for (float f1 = paramInt1 / localRect.right;; f1 = f2 / k)
      {
        localRect.right = ((int)(f1 * localRect.right));
        localRect.bottom = ((int)(f1 * localRect.bottom));
        i = paramInt1 - localRect.right;
        j = paramInt2 - localRect.bottom;
        localRect.offset(i / 2, j / 2);
        Paint localPaint = new Paint();
        localPaint.setFilterBitmap(true);
        localPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
        localCanvas.drawBitmap(paramBitmap, null, localRect, localPaint);
        paramBitmap.recycle();
        localCanvas.setBitmap(null);
        return localBitmap;
        f2 = paramInt2;
        k = localRect.bottom;
      }
      return paramBitmap;
    }
    catch (OutOfMemoryError localOutOfMemoryError)
    {
      Log.w(TAG, "Can't generate default bitmap", localOutOfMemoryError);
    }
  }
  
  public static WallpaperManager getInstance(Context paramContext)
  {
    return (WallpaperManager)paramContext.getSystemService("wallpaper");
  }
  
  static void initGlobals(Looper paramLooper)
  {
    synchronized (sSync)
    {
      if (sGlobals == null) {
        sGlobals = new Globals(paramLooper);
      }
      return;
    }
  }
  
  private void setWallpaper(InputStream paramInputStream, FileOutputStream paramFileOutputStream)
    throws IOException
  {
    byte[] arrayOfByte = new byte[32768];
    for (;;)
    {
      int i = paramInputStream.read(arrayOfByte);
      if (i <= 0) {
        break;
      }
      paramFileOutputStream.write(arrayOfByte, 0, i);
    }
  }
  
  public void clear()
    throws IOException
  {
    setResource(17302046);
  }
  
  public void clearWallpaperOffsets(IBinder paramIBinder)
  {
    try
    {
      WindowManagerGlobal.getWindowSession(this.mContext.getMainLooper()).setWallpaperPosition(paramIBinder, -1.0F, -1.0F, -1.0F, -1.0F);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void forgetLoadedWallpaper()
  {
    sGlobals.forgetLoadedWallpaper();
  }
  
  public Bitmap getBitmap()
  {
    return sGlobals.peekWallpaperBitmap(this.mContext, true);
  }
  
  public int getDesiredMinimumHeight()
  {
    if (sGlobals.mService == null)
    {
      Log.w(TAG, "WallpaperService not running");
      return 0;
    }
    try
    {
      int i = sGlobals.mService.getHeightHint();
      return i;
    }
    catch (RemoteException localRemoteException) {}
    return 0;
  }
  
  public int getDesiredMinimumWidth()
  {
    if (sGlobals.mService == null)
    {
      Log.w(TAG, "WallpaperService not running");
      return 0;
    }
    try
    {
      int i = sGlobals.mService.getWidthHint();
      return i;
    }
    catch (RemoteException localRemoteException) {}
    return 0;
  }
  
  public Drawable getDrawable()
  {
    Bitmap localBitmap = sGlobals.peekWallpaperBitmap(this.mContext, true);
    if (localBitmap != null)
    {
      BitmapDrawable localBitmapDrawable = new BitmapDrawable(this.mContext.getResources(), localBitmap);
      localBitmapDrawable.setDither(false);
      return localBitmapDrawable;
    }
    return null;
  }
  
  public Drawable getFastDrawable()
  {
    Bitmap localBitmap = sGlobals.peekWallpaperBitmap(this.mContext, true);
    if (localBitmap != null) {
      return new FastBitmapDrawable(localBitmap, null);
    }
    return null;
  }
  
  public IWallpaperManager getIWallpaperManager()
  {
    return sGlobals.mService;
  }
  
  public WallpaperInfo getWallpaperInfo()
  {
    try
    {
      if (sGlobals.mService == null)
      {
        Log.w(TAG, "WallpaperService not running");
        return null;
      }
      WallpaperInfo localWallpaperInfo = sGlobals.mService.getWallpaperInfo();
      return localWallpaperInfo;
    }
    catch (RemoteException localRemoteException) {}
    return null;
  }
  
  public boolean hasResourceWallpaper(int paramInt)
  {
    if (sGlobals.mService == null)
    {
      Log.w(TAG, "WallpaperService not running");
      return false;
    }
    try
    {
      Resources localResources = this.mContext.getResources();
      String str = "res:" + localResources.getResourceName(paramInt);
      boolean bool = sGlobals.mService.hasNamedWallpaper(str);
      return bool;
    }
    catch (RemoteException localRemoteException) {}
    return false;
  }
  
  public Drawable peekDrawable()
  {
    Bitmap localBitmap = sGlobals.peekWallpaperBitmap(this.mContext, false);
    if (localBitmap != null)
    {
      BitmapDrawable localBitmapDrawable = new BitmapDrawable(this.mContext.getResources(), localBitmap);
      localBitmapDrawable.setDither(false);
      return localBitmapDrawable;
    }
    return null;
  }
  
  public Drawable peekFastDrawable()
  {
    Bitmap localBitmap = sGlobals.peekWallpaperBitmap(this.mContext, false);
    if (localBitmap != null) {
      return new FastBitmapDrawable(localBitmap, null);
    }
    return null;
  }
  
  public void sendWallpaperCommand(IBinder paramIBinder, String paramString, int paramInt1, int paramInt2, int paramInt3, Bundle paramBundle)
  {
    try
    {
      WindowManagerGlobal.getWindowSession(this.mContext.getMainLooper()).sendWallpaperCommand(paramIBinder, paramString, paramInt1, paramInt2, paramInt3, paramBundle, false);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void setBitmap(Bitmap paramBitmap)
    throws IOException
  {
    if (sGlobals.mService == null) {
      Log.w(TAG, "WallpaperService not running");
    }
    for (;;)
    {
      return;
      for (;;)
      {
        try
        {
          localParcelFileDescriptor = sGlobals.mService.setWallpaper(null);
          if (localParcelFileDescriptor == null) {
            break;
          }
        }
        catch (RemoteException localRemoteException)
        {
          ParcelFileDescriptor localParcelFileDescriptor;
          ParcelFileDescriptor.AutoCloseOutputStream localAutoCloseOutputStream1;
          Object localObject1;
          return;
        }
        try
        {
          localAutoCloseOutputStream1 = new ParcelFileDescriptor.AutoCloseOutputStream(localParcelFileDescriptor);
        }
        finally
        {
          localAutoCloseOutputStream2 = null;
          continue;
        }
        try
        {
          paramBitmap.compress(Bitmap.CompressFormat.PNG, 90, localAutoCloseOutputStream1);
          if (localAutoCloseOutputStream1 == null) {
            break;
          }
          localAutoCloseOutputStream1.close();
          return;
        }
        finally
        {
          localAutoCloseOutputStream2 = localAutoCloseOutputStream1;
        }
      }
    }
    if (localAutoCloseOutputStream2 != null) {
      localAutoCloseOutputStream2.close();
    }
    throw ((Throwable)localObject1);
  }
  
  public void setResource(int paramInt)
    throws IOException
  {
    if (sGlobals.mService == null) {
      Log.w(TAG, "WallpaperService not running");
    }
    for (;;)
    {
      return;
      for (;;)
      {
        try
        {
          localResources = this.mContext.getResources();
          localParcelFileDescriptor = sGlobals.mService.setWallpaper("res:" + localResources.getResourceName(paramInt));
          if (localParcelFileDescriptor == null) {
            break;
          }
        }
        catch (RemoteException localRemoteException)
        {
          Resources localResources;
          ParcelFileDescriptor localParcelFileDescriptor;
          ParcelFileDescriptor.AutoCloseOutputStream localAutoCloseOutputStream1;
          Object localObject1;
          return;
        }
        try
        {
          localAutoCloseOutputStream1 = new ParcelFileDescriptor.AutoCloseOutputStream(localParcelFileDescriptor);
        }
        finally
        {
          localAutoCloseOutputStream2 = null;
          continue;
        }
        try
        {
          setWallpaper(localResources.openRawResource(paramInt), localAutoCloseOutputStream1);
          if (localAutoCloseOutputStream1 == null) {
            break;
          }
          localAutoCloseOutputStream1.close();
          return;
        }
        finally
        {
          localAutoCloseOutputStream2 = localAutoCloseOutputStream1;
        }
      }
    }
    if (localAutoCloseOutputStream2 != null) {
      localAutoCloseOutputStream2.close();
    }
    throw ((Throwable)localObject1);
  }
  
  public void setStream(InputStream paramInputStream)
    throws IOException
  {
    if (sGlobals.mService == null) {
      Log.w(TAG, "WallpaperService not running");
    }
    for (;;)
    {
      return;
      for (;;)
      {
        try
        {
          localParcelFileDescriptor = sGlobals.mService.setWallpaper(null);
          if (localParcelFileDescriptor == null) {
            break;
          }
        }
        catch (RemoteException localRemoteException)
        {
          ParcelFileDescriptor localParcelFileDescriptor;
          ParcelFileDescriptor.AutoCloseOutputStream localAutoCloseOutputStream1;
          Object localObject1;
          return;
        }
        try
        {
          localAutoCloseOutputStream1 = new ParcelFileDescriptor.AutoCloseOutputStream(localParcelFileDescriptor);
        }
        finally
        {
          localAutoCloseOutputStream2 = null;
          continue;
        }
        try
        {
          setWallpaper(paramInputStream, localAutoCloseOutputStream1);
          if (localAutoCloseOutputStream1 == null) {
            break;
          }
          localAutoCloseOutputStream1.close();
          return;
        }
        finally
        {
          localAutoCloseOutputStream2 = localAutoCloseOutputStream1;
        }
      }
    }
    if (localAutoCloseOutputStream2 != null) {
      localAutoCloseOutputStream2.close();
    }
    throw ((Throwable)localObject1);
  }
  
  public void setWallpaperOffsetSteps(float paramFloat1, float paramFloat2)
  {
    this.mWallpaperXStep = paramFloat1;
    this.mWallpaperYStep = paramFloat2;
  }
  
  public void setWallpaperOffsets(IBinder paramIBinder, float paramFloat1, float paramFloat2)
  {
    try
    {
      WindowManagerGlobal.getWindowSession(this.mContext.getMainLooper()).setWallpaperPosition(paramIBinder, paramFloat1, paramFloat2, this.mWallpaperXStep, this.mWallpaperYStep);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void suggestDesiredDimensions(int paramInt1, int paramInt2)
  {
    try
    {
      if (sGlobals.mService == null)
      {
        Log.w(TAG, "WallpaperService not running");
        return;
      }
      sGlobals.mService.setDimensionHints(paramInt1, paramInt2);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  static class FastBitmapDrawable
    extends Drawable
  {
    private final Bitmap mBitmap;
    private int mDrawLeft;
    private int mDrawTop;
    private final int mHeight;
    private final Paint mPaint;
    private final int mWidth;
    
    private FastBitmapDrawable(Bitmap paramBitmap)
    {
      this.mBitmap = paramBitmap;
      this.mWidth = paramBitmap.getWidth();
      this.mHeight = paramBitmap.getHeight();
      setBounds(0, 0, this.mWidth, this.mHeight);
      this.mPaint = new Paint();
      this.mPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
    }
    
    public void draw(Canvas paramCanvas)
    {
      paramCanvas.drawBitmap(this.mBitmap, this.mDrawLeft, this.mDrawTop, this.mPaint);
    }
    
    public int getIntrinsicHeight()
    {
      return this.mHeight;
    }
    
    public int getIntrinsicWidth()
    {
      return this.mWidth;
    }
    
    public int getMinimumHeight()
    {
      return this.mHeight;
    }
    
    public int getMinimumWidth()
    {
      return this.mWidth;
    }
    
    public int getOpacity()
    {
      return -1;
    }
    
    public void setAlpha(int paramInt)
    {
      throw new UnsupportedOperationException("Not supported with this drawable");
    }
    
    public void setBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      this.mDrawLeft = (paramInt1 + (paramInt3 - paramInt1 - this.mWidth) / 2);
      this.mDrawTop = (paramInt2 + (paramInt4 - paramInt2 - this.mHeight) / 2);
    }
    
    public void setColorFilter(ColorFilter paramColorFilter)
    {
      throw new UnsupportedOperationException("Not supported with this drawable");
    }
    
    public void setDither(boolean paramBoolean)
    {
      throw new UnsupportedOperationException("Not supported with this drawable");
    }
    
    public void setFilterBitmap(boolean paramBoolean)
    {
      throw new UnsupportedOperationException("Not supported with this drawable");
    }
  }
  
  static class Globals
    extends IWallpaperManagerCallback.Stub
  {
    private static final int MSG_CLEAR_WALLPAPER = 1;
    private Bitmap mDefaultWallpaper;
    private final Handler mHandler;
    private IWallpaperManager mService = IWallpaperManager.Stub.asInterface(ServiceManager.getService("wallpaper"));
    private Bitmap mWallpaper;
    
    Globals(Looper paramLooper)
    {
      this.mHandler = new Handler(paramLooper)
      {
        public void handleMessage(Message paramAnonymousMessage)
        {
          switch (paramAnonymousMessage.what)
          {
          default: 
            return;
          }
          try
          {
            WallpaperManager.Globals.access$002(WallpaperManager.Globals.this, null);
            WallpaperManager.Globals.access$102(WallpaperManager.Globals.this, null);
            return;
          }
          finally {}
        }
      };
    }
    
    /* Error */
    private Bitmap getCurrentWallpaperLocked(Context paramContext)
    {
      // Byte code:
      //   0: new 61	android/os/Bundle
      //   3: dup
      //   4: invokespecial 62	android/os/Bundle:<init>	()V
      //   7: astore_2
      //   8: aload_0
      //   9: getfield 35	android/app/WallpaperManager$Globals:mService	Landroid/app/IWallpaperManager;
      //   12: aload_0
      //   13: aload_2
      //   14: invokeinterface 68 3 0
      //   19: astore 4
      //   21: aload 4
      //   23: ifnull +77 -> 100
      //   26: aload_2
      //   27: ldc 70
      //   29: iconst_0
      //   30: invokevirtual 74	android/os/Bundle:getInt	(Ljava/lang/String;I)I
      //   33: istore 5
      //   35: aload_2
      //   36: ldc 76
      //   38: iconst_0
      //   39: invokevirtual 74	android/os/Bundle:getInt	(Ljava/lang/String;I)I
      //   42: istore 6
      //   44: new 78	android/graphics/BitmapFactory$Options
      //   47: dup
      //   48: invokespecial 79	android/graphics/BitmapFactory$Options:<init>	()V
      //   51: astore 7
      //   53: aload_1
      //   54: aload 4
      //   56: invokevirtual 85	android/os/ParcelFileDescriptor:getFileDescriptor	()Ljava/io/FileDescriptor;
      //   59: aconst_null
      //   60: aload 7
      //   62: invokestatic 91	android/graphics/BitmapFactory:decodeFileDescriptor	(Ljava/io/FileDescriptor;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
      //   65: iload 5
      //   67: iload 6
      //   69: invokestatic 97	android/app/WallpaperManager:generateBitmap	(Landroid/content/Context;Landroid/graphics/Bitmap;II)Landroid/graphics/Bitmap;
      //   72: astore 13
      //   74: aload 4
      //   76: invokevirtual 100	android/os/ParcelFileDescriptor:close	()V
      //   79: aload 13
      //   81: areturn
      //   82: astore 10
      //   84: invokestatic 104	android/app/WallpaperManager:access$200	()Ljava/lang/String;
      //   87: ldc 106
      //   89: aload 10
      //   91: invokestatic 112	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   94: pop
      //   95: aload 4
      //   97: invokevirtual 100	android/os/ParcelFileDescriptor:close	()V
      //   100: aconst_null
      //   101: areturn
      //   102: astore 8
      //   104: aload 4
      //   106: invokevirtual 100	android/os/ParcelFileDescriptor:close	()V
      //   109: aload 8
      //   111: athrow
      //   112: astore_3
      //   113: goto -13 -> 100
      //   116: astore 9
      //   118: goto -9 -> 109
      //   121: astore 12
      //   123: goto -23 -> 100
      //   126: astore 14
      //   128: aload 13
      //   130: areturn
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	131	0	this	Globals
      //   0	131	1	paramContext	Context
      //   7	29	2	localBundle	Bundle
      //   112	1	3	localRemoteException	RemoteException
      //   19	86	4	localParcelFileDescriptor	ParcelFileDescriptor
      //   33	33	5	i	int
      //   42	26	6	j	int
      //   51	10	7	localOptions	android.graphics.BitmapFactory.Options
      //   102	8	8	localObject	Object
      //   116	1	9	localIOException1	IOException
      //   82	8	10	localOutOfMemoryError	OutOfMemoryError
      //   121	1	12	localIOException2	IOException
      //   72	57	13	localBitmap	Bitmap
      //   126	1	14	localIOException3	IOException
      // Exception table:
      //   from	to	target	type
      //   44	74	82	java/lang/OutOfMemoryError
      //   44	74	102	finally
      //   84	95	102	finally
      //   0	21	112	android/os/RemoteException
      //   26	44	112	android/os/RemoteException
      //   74	79	112	android/os/RemoteException
      //   95	100	112	android/os/RemoteException
      //   104	109	112	android/os/RemoteException
      //   109	112	112	android/os/RemoteException
      //   104	109	116	java/io/IOException
      //   95	100	121	java/io/IOException
      //   74	79	126	java/io/IOException
    }
    
    /* Error */
    private Bitmap getDefaultWallpaperLocked(Context paramContext)
    {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual 119	android/content/Context:getResources	()Landroid/content/res/Resources;
      //   4: ldc 120
      //   6: invokevirtual 126	android/content/res/Resources:openRawResource	(I)Ljava/io/InputStream;
      //   9: astore_3
      //   10: aload_3
      //   11: ifnull +71 -> 82
      //   14: aload_0
      //   15: getfield 35	android/app/WallpaperManager$Globals:mService	Landroid/app/IWallpaperManager;
      //   18: invokeinterface 130 1 0
      //   23: istore 4
      //   25: aload_0
      //   26: getfield 35	android/app/WallpaperManager$Globals:mService	Landroid/app/IWallpaperManager;
      //   29: invokeinterface 133 1 0
      //   34: istore 5
      //   36: aload_1
      //   37: aload_3
      //   38: aconst_null
      //   39: new 78	android/graphics/BitmapFactory$Options
      //   42: dup
      //   43: invokespecial 79	android/graphics/BitmapFactory$Options:<init>	()V
      //   46: invokestatic 137	android/graphics/BitmapFactory:decodeStream	(Ljava/io/InputStream;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
      //   49: iload 4
      //   51: iload 5
      //   53: invokestatic 97	android/app/WallpaperManager:generateBitmap	(Landroid/content/Context;Landroid/graphics/Bitmap;II)Landroid/graphics/Bitmap;
      //   56: astore 11
      //   58: aload_3
      //   59: invokevirtual 140	java/io/InputStream:close	()V
      //   62: aload 11
      //   64: areturn
      //   65: astore 8
      //   67: invokestatic 104	android/app/WallpaperManager:access$200	()Ljava/lang/String;
      //   70: ldc -114
      //   72: aload 8
      //   74: invokestatic 112	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   77: pop
      //   78: aload_3
      //   79: invokevirtual 140	java/io/InputStream:close	()V
      //   82: aconst_null
      //   83: areturn
      //   84: astore 6
      //   86: aload_3
      //   87: invokevirtual 140	java/io/InputStream:close	()V
      //   90: aload 6
      //   92: athrow
      //   93: astore_2
      //   94: goto -12 -> 82
      //   97: astore 7
      //   99: goto -9 -> 90
      //   102: astore 10
      //   104: goto -22 -> 82
      //   107: astore 12
      //   109: aload 11
      //   111: areturn
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	112	0	this	Globals
      //   0	112	1	paramContext	Context
      //   93	1	2	localRemoteException	RemoteException
      //   9	78	3	localInputStream	InputStream
      //   23	27	4	i	int
      //   34	18	5	j	int
      //   84	7	6	localObject	Object
      //   97	1	7	localIOException1	IOException
      //   65	8	8	localOutOfMemoryError	OutOfMemoryError
      //   102	1	10	localIOException2	IOException
      //   56	54	11	localBitmap	Bitmap
      //   107	1	12	localIOException3	IOException
      // Exception table:
      //   from	to	target	type
      //   36	58	65	java/lang/OutOfMemoryError
      //   36	58	84	finally
      //   67	78	84	finally
      //   0	10	93	android/os/RemoteException
      //   14	36	93	android/os/RemoteException
      //   58	62	93	android/os/RemoteException
      //   78	82	93	android/os/RemoteException
      //   86	90	93	android/os/RemoteException
      //   90	93	93	android/os/RemoteException
      //   86	90	97	java/io/IOException
      //   78	82	102	java/io/IOException
      //   58	62	107	java/io/IOException
    }
    
    public void forgetLoadedWallpaper()
    {
      try
      {
        this.mWallpaper = null;
        this.mDefaultWallpaper = null;
        return;
      }
      finally {}
    }
    
    public void onWallpaperChanged()
    {
      this.mHandler.sendEmptyMessage(1);
    }
    
    public Bitmap peekWallpaperBitmap(Context paramContext, boolean paramBoolean)
    {
      try
      {
        if (this.mWallpaper != null)
        {
          Bitmap localBitmap4 = this.mWallpaper;
          return localBitmap4;
        }
        if (this.mDefaultWallpaper != null)
        {
          Bitmap localBitmap3 = this.mDefaultWallpaper;
          return localBitmap3;
        }
      }
      finally {}
      this.mWallpaper = null;
      try
      {
        this.mWallpaper = getCurrentWallpaperLocked(paramContext);
        if (paramBoolean) {
          if (this.mWallpaper == null)
          {
            this.mDefaultWallpaper = getDefaultWallpaperLocked(paramContext);
            Bitmap localBitmap2 = this.mDefaultWallpaper;
            return localBitmap2;
          }
        }
      }
      catch (OutOfMemoryError localOutOfMemoryError)
      {
        for (;;)
        {
          Log.w(WallpaperManager.TAG, "No memory load current wallpaper", localOutOfMemoryError);
        }
        this.mDefaultWallpaper = null;
        Bitmap localBitmap1 = this.mWallpaper;
        return localBitmap1;
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\WallpaperManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
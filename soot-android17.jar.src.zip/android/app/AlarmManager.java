package android.app;

import android.os.RemoteException;

public class AlarmManager
{
  public static final int ELAPSED_REALTIME = 3;
  public static final int ELAPSED_REALTIME_WAKEUP = 2;
  public static final long INTERVAL_DAY = 86400000L;
  public static final long INTERVAL_FIFTEEN_MINUTES = 900000L;
  public static final long INTERVAL_HALF_DAY = 43200000L;
  public static final long INTERVAL_HALF_HOUR = 1800000L;
  public static final long INTERVAL_HOUR = 3600000L;
  public static final int RTC = 1;
  public static final int RTC_WAKEUP;
  private final IAlarmManager mService;
  
  AlarmManager(IAlarmManager paramIAlarmManager)
  {
    this.mService = paramIAlarmManager;
  }
  
  public void cancel(PendingIntent paramPendingIntent)
  {
    try
    {
      this.mService.remove(paramPendingIntent);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void set(int paramInt, long paramLong, PendingIntent paramPendingIntent)
  {
    try
    {
      this.mService.set(paramInt, paramLong, paramPendingIntent);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void setInexactRepeating(int paramInt, long paramLong1, long paramLong2, PendingIntent paramPendingIntent)
  {
    try
    {
      this.mService.setInexactRepeating(paramInt, paramLong1, paramLong2, paramPendingIntent);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void setRepeating(int paramInt, long paramLong1, long paramLong2, PendingIntent paramPendingIntent)
  {
    try
    {
      this.mService.setRepeating(paramInt, paramLong1, paramLong2, paramPendingIntent);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void setTime(long paramLong)
  {
    try
    {
      this.mService.setTime(paramLong);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void setTimeZone(String paramString)
  {
    try
    {
      this.mService.setTimeZone(paramString);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\AlarmManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnKeyListener;
import android.content.DialogInterface.OnShowListener;
import android.content.res.Resources.Theme;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.KeyEvent.Callback;
import android.view.KeyEvent.DispatcherState;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.Window.Callback;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.view.accessibility.AccessibilityEvent;
import com.android.internal.app.ActionBarImpl;
import com.android.internal.policy.PolicyManager;
import java.lang.ref.WeakReference;

public class Dialog
  implements DialogInterface, Window.Callback, KeyEvent.Callback, View.OnCreateContextMenuListener
{
  private static final int CANCEL = 68;
  private static final String DIALOG_HIERARCHY_TAG = "android:dialogHierarchy";
  private static final String DIALOG_SHOWING_TAG = "android:dialogShowing";
  private static final int DISMISS = 67;
  private static final int SHOW = 69;
  private static final String TAG = "Dialog";
  private ActionBarImpl mActionBar;
  private ActionMode mActionMode;
  private String mCancelAndDismissTaken;
  private Message mCancelMessage;
  protected boolean mCancelable = true;
  private boolean mCanceled = false;
  final Context mContext;
  private boolean mCreated = false;
  View mDecor;
  private final Runnable mDismissAction = new Runnable()
  {
    public void run()
    {
      Dialog.this.dismissDialog();
    }
  };
  private Message mDismissMessage;
  private final Handler mHandler = new Handler();
  private Handler mListenersHandler;
  private DialogInterface.OnKeyListener mOnKeyListener;
  private Activity mOwnerActivity;
  private Message mShowMessage;
  private boolean mShowing = false;
  Window mWindow;
  final WindowManager mWindowManager;
  
  public Dialog(Context paramContext)
  {
    this(paramContext, 0, true);
  }
  
  public Dialog(Context paramContext, int paramInt)
  {
    this(paramContext, paramInt, true);
  }
  
  Dialog(Context paramContext, int paramInt, boolean paramBoolean)
  {
    if (paramBoolean) {
      if (paramInt == 0)
      {
        TypedValue localTypedValue = new TypedValue();
        paramContext.getTheme().resolveAttribute(16843528, localTypedValue, true);
        paramInt = localTypedValue.resourceId;
      }
    }
    for (this.mContext = new ContextThemeWrapper(paramContext, paramInt);; this.mContext = paramContext)
    {
      this.mWindowManager = ((WindowManager)paramContext.getSystemService("window"));
      Window localWindow = PolicyManager.makeNewWindow(this.mContext);
      this.mWindow = localWindow;
      localWindow.setCallback(this);
      localWindow.setWindowManager(this.mWindowManager, null, null);
      localWindow.setGravity(17);
      this.mListenersHandler = new ListenersHandler(this);
      return;
    }
  }
  
  protected Dialog(Context paramContext, boolean paramBoolean, DialogInterface.OnCancelListener paramOnCancelListener)
  {
    this(paramContext);
    setOnCancelListener(paramOnCancelListener);
  }
  
  @Deprecated
  protected Dialog(Context paramContext, boolean paramBoolean, Message paramMessage)
  {
    this(paramContext);
    this.mCancelMessage = paramMessage;
  }
  
  private ComponentName getAssociatedActivity()
  {
    Activity localActivity = this.mOwnerActivity;
    Context localContext = getContext();
    while ((localActivity == null) && (localContext != null)) {
      if ((localContext instanceof Activity))
      {
        localActivity = (Activity)localContext;
      }
      else
      {
        if ((localContext instanceof ContextWrapper)) {}
        for (localContext = ((ContextWrapper)localContext).getBaseContext();; localContext = null) {
          break;
        }
      }
    }
    if (localActivity == null) {
      return null;
    }
    return localActivity.getComponentName();
  }
  
  private void sendDismissMessage()
  {
    if (this.mDismissMessage != null) {
      Message.obtain(this.mDismissMessage).sendToTarget();
    }
  }
  
  private void sendShowMessage()
  {
    if (this.mShowMessage != null) {
      Message.obtain(this.mShowMessage).sendToTarget();
    }
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    this.mWindow.addContentView(paramView, paramLayoutParams);
  }
  
  public void cancel()
  {
    if ((!this.mCanceled) && (this.mCancelMessage != null))
    {
      this.mCanceled = true;
      Message.obtain(this.mCancelMessage).sendToTarget();
    }
    dismiss();
  }
  
  public void closeOptionsMenu()
  {
    this.mWindow.closePanel(0);
  }
  
  public void dismiss()
  {
    if (Looper.myLooper() == this.mHandler.getLooper())
    {
      dismissDialog();
      return;
    }
    this.mHandler.post(this.mDismissAction);
  }
  
  void dismissDialog()
  {
    if ((this.mDecor == null) || (!this.mShowing)) {
      return;
    }
    if (this.mWindow.isDestroyed())
    {
      Log.e("Dialog", "Tried to dismissDialog() but the Dialog's window was already destroyed!");
      return;
    }
    try
    {
      this.mWindowManager.removeView(this.mDecor);
      return;
    }
    finally
    {
      if (this.mActionMode != null) {
        this.mActionMode.finish();
      }
      this.mDecor = null;
      this.mWindow.closeAllPanels();
      onStop();
      this.mShowing = false;
      sendDismissMessage();
    }
  }
  
  public boolean dispatchGenericMotionEvent(MotionEvent paramMotionEvent)
  {
    if (this.mWindow.superDispatchGenericMotionEvent(paramMotionEvent)) {
      return true;
    }
    return onGenericMotionEvent(paramMotionEvent);
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent)
  {
    if ((this.mOnKeyListener != null) && (this.mOnKeyListener.onKey(this, paramKeyEvent.getKeyCode(), paramKeyEvent))) {}
    while (this.mWindow.superDispatchKeyEvent(paramKeyEvent)) {
      return true;
    }
    if (this.mDecor != null) {}
    for (KeyEvent.DispatcherState localDispatcherState = this.mDecor.getKeyDispatcherState();; localDispatcherState = null) {
      return paramKeyEvent.dispatch(this, localDispatcherState, this);
    }
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent)
  {
    if (this.mWindow.superDispatchKeyShortcutEvent(paramKeyEvent)) {
      return true;
    }
    return onKeyShortcut(paramKeyEvent.getKeyCode(), paramKeyEvent);
  }
  
  void dispatchOnCreate(Bundle paramBundle)
  {
    if (!this.mCreated)
    {
      onCreate(paramBundle);
      this.mCreated = true;
    }
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
  {
    paramAccessibilityEvent.setClassName(getClass().getName());
    paramAccessibilityEvent.setPackageName(this.mContext.getPackageName());
    WindowManager.LayoutParams localLayoutParams = getWindow().getAttributes();
    if ((localLayoutParams.width == -1) && (localLayoutParams.height == -1)) {}
    for (boolean bool = true;; bool = false)
    {
      paramAccessibilityEvent.setFullScreen(bool);
      return false;
    }
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent)
  {
    if (this.mWindow.superDispatchTouchEvent(paramMotionEvent)) {
      return true;
    }
    return onTouchEvent(paramMotionEvent);
  }
  
  public boolean dispatchTrackballEvent(MotionEvent paramMotionEvent)
  {
    if (this.mWindow.superDispatchTrackballEvent(paramMotionEvent)) {
      return true;
    }
    return onTrackballEvent(paramMotionEvent);
  }
  
  public View findViewById(int paramInt)
  {
    return this.mWindow.findViewById(paramInt);
  }
  
  public ActionBar getActionBar()
  {
    return this.mActionBar;
  }
  
  public final Context getContext()
  {
    return this.mContext;
  }
  
  public View getCurrentFocus()
  {
    if (this.mWindow != null) {
      return this.mWindow.getCurrentFocus();
    }
    return null;
  }
  
  public LayoutInflater getLayoutInflater()
  {
    return getWindow().getLayoutInflater();
  }
  
  public final Activity getOwnerActivity()
  {
    return this.mOwnerActivity;
  }
  
  public final int getVolumeControlStream()
  {
    return getWindow().getVolumeControlStream();
  }
  
  public Window getWindow()
  {
    return this.mWindow;
  }
  
  public void hide()
  {
    if (this.mDecor != null) {
      this.mDecor.setVisibility(8);
    }
  }
  
  public void invalidateOptionsMenu()
  {
    this.mWindow.invalidatePanelMenu(0);
  }
  
  public boolean isShowing()
  {
    return this.mShowing;
  }
  
  public void onActionModeFinished(ActionMode paramActionMode)
  {
    if (paramActionMode == this.mActionMode) {
      this.mActionMode = null;
    }
  }
  
  public void onActionModeStarted(ActionMode paramActionMode)
  {
    this.mActionMode = paramActionMode;
  }
  
  public void onAttachedToWindow() {}
  
  public void onBackPressed()
  {
    if (this.mCancelable) {
      cancel();
    }
  }
  
  public void onContentChanged() {}
  
  public boolean onContextItemSelected(MenuItem paramMenuItem)
  {
    return false;
  }
  
  public void onContextMenuClosed(Menu paramMenu) {}
  
  protected void onCreate(Bundle paramBundle) {}
  
  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo) {}
  
  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    return true;
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu)
  {
    if (paramInt == 0) {
      return onCreateOptionsMenu(paramMenu);
    }
    return false;
  }
  
  public View onCreatePanelView(int paramInt)
  {
    return null;
  }
  
  public void onDetachedFromWindow() {}
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent)
  {
    return false;
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      paramKeyEvent.startTracking();
      return true;
    }
    return false;
  }
  
  public boolean onKeyLongPress(int paramInt, KeyEvent paramKeyEvent)
  {
    return false;
  }
  
  public boolean onKeyMultiple(int paramInt1, int paramInt2, KeyEvent paramKeyEvent)
  {
    return false;
  }
  
  public boolean onKeyShortcut(int paramInt, KeyEvent paramKeyEvent)
  {
    return false;
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramInt == 4) && (paramKeyEvent.isTracking()) && (!paramKeyEvent.isCanceled()))
    {
      onBackPressed();
      return true;
    }
    return false;
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem)
  {
    return false;
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu)
  {
    if (paramInt == 8) {
      this.mActionBar.dispatchMenuVisibilityChanged(true);
    }
    return true;
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    return false;
  }
  
  public void onOptionsMenuClosed(Menu paramMenu) {}
  
  public void onPanelClosed(int paramInt, Menu paramMenu)
  {
    if (paramInt == 8) {
      this.mActionBar.dispatchMenuVisibilityChanged(false);
    }
  }
  
  public boolean onPrepareOptionsMenu(Menu paramMenu)
  {
    return true;
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu)
  {
    return (paramInt != 0) || (paramMenu == null) || ((onPrepareOptionsMenu(paramMenu)) && (paramMenu.hasVisibleItems()));
  }
  
  public void onRestoreInstanceState(Bundle paramBundle)
  {
    Bundle localBundle = paramBundle.getBundle("android:dialogHierarchy");
    if (localBundle == null) {}
    do
    {
      return;
      dispatchOnCreate(paramBundle);
      this.mWindow.restoreHierarchyState(localBundle);
    } while (!paramBundle.getBoolean("android:dialogShowing"));
    show();
  }
  
  public Bundle onSaveInstanceState()
  {
    Bundle localBundle = new Bundle();
    localBundle.putBoolean("android:dialogShowing", this.mShowing);
    if (this.mCreated) {
      localBundle.putBundle("android:dialogHierarchy", this.mWindow.saveHierarchyState());
    }
    return localBundle;
  }
  
  public boolean onSearchRequested()
  {
    SearchManager localSearchManager = (SearchManager)this.mContext.getSystemService("search");
    ComponentName localComponentName = getAssociatedActivity();
    boolean bool = false;
    if (localComponentName != null)
    {
      SearchableInfo localSearchableInfo = localSearchManager.getSearchableInfo(localComponentName);
      bool = false;
      if (localSearchableInfo != null)
      {
        localSearchManager.startSearch(null, false, localComponentName, null, false);
        dismiss();
        bool = true;
      }
    }
    return bool;
  }
  
  protected void onStart()
  {
    if (this.mActionBar != null) {
      this.mActionBar.setShowHideAnimationEnabled(true);
    }
  }
  
  protected void onStop()
  {
    if (this.mActionBar != null) {
      this.mActionBar.setShowHideAnimationEnabled(false);
    }
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    if ((this.mCancelable) && (this.mShowing) && (this.mWindow.shouldCloseOnTouch(this.mContext, paramMotionEvent)))
    {
      cancel();
      return true;
    }
    return false;
  }
  
  public boolean onTrackballEvent(MotionEvent paramMotionEvent)
  {
    return false;
  }
  
  public void onWindowAttributesChanged(WindowManager.LayoutParams paramLayoutParams)
  {
    if (this.mDecor != null) {
      this.mWindowManager.updateViewLayout(this.mDecor, paramLayoutParams);
    }
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {}
  
  public ActionMode onWindowStartingActionMode(ActionMode.Callback paramCallback)
  {
    if (this.mActionBar != null) {
      return this.mActionBar.startActionMode(paramCallback);
    }
    return null;
  }
  
  public void openContextMenu(View paramView)
  {
    paramView.showContextMenu();
  }
  
  public void openOptionsMenu()
  {
    this.mWindow.openPanel(0, null);
  }
  
  public void registerForContextMenu(View paramView)
  {
    paramView.setOnCreateContextMenuListener(this);
  }
  
  public final boolean requestWindowFeature(int paramInt)
  {
    return getWindow().requestFeature(paramInt);
  }
  
  public void setCancelMessage(Message paramMessage)
  {
    this.mCancelMessage = paramMessage;
  }
  
  public void setCancelable(boolean paramBoolean)
  {
    this.mCancelable = paramBoolean;
  }
  
  public void setCanceledOnTouchOutside(boolean paramBoolean)
  {
    if ((paramBoolean) && (!this.mCancelable)) {
      this.mCancelable = true;
    }
    this.mWindow.setCloseOnTouchOutside(paramBoolean);
  }
  
  public void setContentView(int paramInt)
  {
    this.mWindow.setContentView(paramInt);
  }
  
  public void setContentView(View paramView)
  {
    this.mWindow.setContentView(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    this.mWindow.setContentView(paramView, paramLayoutParams);
  }
  
  public void setDismissMessage(Message paramMessage)
  {
    this.mDismissMessage = paramMessage;
  }
  
  public final void setFeatureDrawable(int paramInt, Drawable paramDrawable)
  {
    getWindow().setFeatureDrawable(paramInt, paramDrawable);
  }
  
  public final void setFeatureDrawableAlpha(int paramInt1, int paramInt2)
  {
    getWindow().setFeatureDrawableAlpha(paramInt1, paramInt2);
  }
  
  public final void setFeatureDrawableResource(int paramInt1, int paramInt2)
  {
    getWindow().setFeatureDrawableResource(paramInt1, paramInt2);
  }
  
  public final void setFeatureDrawableUri(int paramInt, Uri paramUri)
  {
    getWindow().setFeatureDrawableUri(paramInt, paramUri);
  }
  
  public void setOnCancelListener(DialogInterface.OnCancelListener paramOnCancelListener)
  {
    if (this.mCancelAndDismissTaken != null) {
      throw new IllegalStateException("OnCancelListener is already taken by " + this.mCancelAndDismissTaken + " and can not be replaced.");
    }
    if (paramOnCancelListener != null)
    {
      this.mCancelMessage = this.mListenersHandler.obtainMessage(68, paramOnCancelListener);
      return;
    }
    this.mCancelMessage = null;
  }
  
  public void setOnDismissListener(DialogInterface.OnDismissListener paramOnDismissListener)
  {
    if (this.mCancelAndDismissTaken != null) {
      throw new IllegalStateException("OnDismissListener is already taken by " + this.mCancelAndDismissTaken + " and can not be replaced.");
    }
    if (paramOnDismissListener != null)
    {
      this.mDismissMessage = this.mListenersHandler.obtainMessage(67, paramOnDismissListener);
      return;
    }
    this.mDismissMessage = null;
  }
  
  public void setOnKeyListener(DialogInterface.OnKeyListener paramOnKeyListener)
  {
    this.mOnKeyListener = paramOnKeyListener;
  }
  
  public void setOnShowListener(DialogInterface.OnShowListener paramOnShowListener)
  {
    if (paramOnShowListener != null)
    {
      this.mShowMessage = this.mListenersHandler.obtainMessage(69, paramOnShowListener);
      return;
    }
    this.mShowMessage = null;
  }
  
  public final void setOwnerActivity(Activity paramActivity)
  {
    this.mOwnerActivity = paramActivity;
    getWindow().setVolumeControlStream(this.mOwnerActivity.getVolumeControlStream());
  }
  
  public void setTitle(int paramInt)
  {
    setTitle(this.mContext.getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence)
  {
    this.mWindow.setTitle(paramCharSequence);
    this.mWindow.getAttributes().setTitle(paramCharSequence);
  }
  
  public final void setVolumeControlStream(int paramInt)
  {
    getWindow().setVolumeControlStream(paramInt);
  }
  
  public void show()
  {
    if (this.mShowing)
    {
      if (this.mDecor != null)
      {
        if (this.mWindow.hasFeature(8)) {
          this.mWindow.invalidatePanelMenu(8);
        }
        this.mDecor.setVisibility(0);
      }
      return;
    }
    this.mCanceled = false;
    if (!this.mCreated) {
      dispatchOnCreate(null);
    }
    onStart();
    this.mDecor = this.mWindow.getDecorView();
    if ((this.mActionBar == null) && (this.mWindow.hasFeature(8))) {
      this.mActionBar = new ActionBarImpl(this);
    }
    Object localObject1 = this.mWindow.getAttributes();
    if ((0x100 & ((WindowManager.LayoutParams)localObject1).softInputMode) == 0)
    {
      WindowManager.LayoutParams localLayoutParams = new WindowManager.LayoutParams();
      localLayoutParams.copyFrom((WindowManager.LayoutParams)localObject1);
      localLayoutParams.softInputMode = (0x100 | localLayoutParams.softInputMode);
      localObject1 = localLayoutParams;
    }
    try
    {
      this.mWindowManager.addView(this.mDecor, (ViewGroup.LayoutParams)localObject1);
      this.mShowing = true;
      sendShowMessage();
      return;
    }
    finally {}
  }
  
  public boolean takeCancelAndDismissListeners(String paramString, DialogInterface.OnCancelListener paramOnCancelListener, DialogInterface.OnDismissListener paramOnDismissListener)
  {
    if (this.mCancelAndDismissTaken != null) {
      this.mCancelAndDismissTaken = null;
    }
    while ((this.mCancelMessage == null) && (this.mDismissMessage == null))
    {
      setOnCancelListener(paramOnCancelListener);
      setOnDismissListener(paramOnDismissListener);
      this.mCancelAndDismissTaken = paramString;
      return true;
    }
    return false;
  }
  
  public void takeKeyEvents(boolean paramBoolean)
  {
    this.mWindow.takeKeyEvents(paramBoolean);
  }
  
  public void unregisterForContextMenu(View paramView)
  {
    paramView.setOnCreateContextMenuListener(null);
  }
  
  private static final class ListenersHandler
    extends Handler
  {
    private WeakReference<DialogInterface> mDialog;
    
    public ListenersHandler(Dialog paramDialog)
    {
      this.mDialog = new WeakReference(paramDialog);
    }
    
    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default: 
        return;
      case 67: 
        ((DialogInterface.OnDismissListener)paramMessage.obj).onDismiss((DialogInterface)this.mDialog.get());
        return;
      case 68: 
        ((DialogInterface.OnCancelListener)paramMessage.obj).onCancel((DialogInterface)this.mDialog.get());
        return;
      }
      ((DialogInterface.OnShowListener)paramMessage.obj).onShow((DialogInterface)this.mDialog.get());
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\Dialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
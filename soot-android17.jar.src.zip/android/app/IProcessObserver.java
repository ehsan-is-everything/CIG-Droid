package android.app;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface IProcessObserver
  extends IInterface
{
  public abstract void onForegroundActivitiesChanged(int paramInt1, int paramInt2, boolean paramBoolean)
    throws RemoteException;
  
  public abstract void onImportanceChanged(int paramInt1, int paramInt2, int paramInt3)
    throws RemoteException;
  
  public abstract void onProcessDied(int paramInt1, int paramInt2)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IProcessObserver
  {
    private static final String DESCRIPTOR = "android.app.IProcessObserver";
    static final int TRANSACTION_onForegroundActivitiesChanged = 1;
    static final int TRANSACTION_onImportanceChanged = 2;
    static final int TRANSACTION_onProcessDied = 3;
    
    public Stub()
    {
      attachInterface(this, "android.app.IProcessObserver");
    }
    
    public static IProcessObserver asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.app.IProcessObserver");
      if ((localIInterface != null) && ((localIInterface instanceof IProcessObserver))) {
        return (IProcessObserver)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.app.IProcessObserver");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.app.IProcessObserver");
        int i = paramParcel1.readInt();
        int j = paramParcel1.readInt();
        if (paramParcel1.readInt() != 0) {}
        for (boolean bool = true;; bool = false)
        {
          onForegroundActivitiesChanged(i, j, bool);
          return true;
        }
      case 2: 
        paramParcel1.enforceInterface("android.app.IProcessObserver");
        onImportanceChanged(paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readInt());
        return true;
      }
      paramParcel1.enforceInterface("android.app.IProcessObserver");
      onProcessDied(paramParcel1.readInt(), paramParcel1.readInt());
      return true;
    }
    
    private static class Proxy
      implements IProcessObserver
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.app.IProcessObserver";
      }
      
      /* Error */
      public void onForegroundActivitiesChanged(int paramInt1, int paramInt2, boolean paramBoolean)
        throws RemoteException
      {
        // Byte code:
        //   0: iconst_1
        //   1: istore 4
        //   3: invokestatic 31	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   6: astore 5
        //   8: aload 5
        //   10: ldc 21
        //   12: invokevirtual 35	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload 5
        //   17: iload_1
        //   18: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   21: aload 5
        //   23: iload_2
        //   24: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   27: iload_3
        //   28: ifeq +31 -> 59
        //   31: aload 5
        //   33: iload 4
        //   35: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   38: aload_0
        //   39: getfield 15	android/app/IProcessObserver$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   42: iconst_1
        //   43: aload 5
        //   45: aconst_null
        //   46: iconst_1
        //   47: invokeinterface 45 5 0
        //   52: pop
        //   53: aload 5
        //   55: invokevirtual 48	android/os/Parcel:recycle	()V
        //   58: return
        //   59: iconst_0
        //   60: istore 4
        //   62: goto -31 -> 31
        //   65: astore 6
        //   67: aload 5
        //   69: invokevirtual 48	android/os/Parcel:recycle	()V
        //   72: aload 6
        //   74: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	75	0	this	Proxy
        //   0	75	1	paramInt1	int
        //   0	75	2	paramInt2	int
        //   0	75	3	paramBoolean	boolean
        //   1	60	4	i	int
        //   6	62	5	localParcel	Parcel
        //   65	8	6	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   8	27	65	finally
        //   31	53	65	finally
      }
      
      public void onImportanceChanged(int paramInt1, int paramInt2, int paramInt3)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.app.IProcessObserver");
          localParcel.writeInt(paramInt1);
          localParcel.writeInt(paramInt2);
          localParcel.writeInt(paramInt3);
          this.mRemote.transact(2, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }
      
      public void onProcessDied(int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.app.IProcessObserver");
          localParcel.writeInt(paramInt1);
          localParcel.writeInt(paramInt2);
          this.mRemote.transact(3, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\IProcessObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
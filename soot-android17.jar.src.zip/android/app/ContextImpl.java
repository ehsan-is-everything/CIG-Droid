package android.app;

import android.accounts.AccountManager;
import android.accounts.IAccountManager.Stub;
import android.app.admin.DevicePolicyManager;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.IContentProvider;
import android.content.IIntentReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.IntentSender.SendIntentException;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.IPackageManager;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.AssetManager;
import android.content.res.CompatibilityInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.hardware.ISerialManager.Stub;
import android.hardware.SerialManager;
import android.hardware.SystemSensorManager;
import android.hardware.display.DisplayManager;
import android.hardware.input.InputManager;
import android.hardware.usb.IUsbManager.Stub;
import android.hardware.usb.UsbManager;
import android.location.CountryDetector;
import android.location.ICountryDetector.Stub;
import android.location.ILocationManager.Stub;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.MediaRouter;
import android.net.ConnectivityManager;
import android.net.IConnectivityManager.Stub;
import android.net.INetworkPolicyManager.Stub;
import android.net.IThrottleManager.Stub;
import android.net.NetworkPolicyManager;
import android.net.ThrottleManager;
import android.net.Uri;
import android.net.nsd.INsdManager;
import android.net.nsd.INsdManager.Stub;
import android.net.nsd.NsdManager;
import android.net.wifi.IWifiManager;
import android.net.wifi.IWifiManager.Stub;
import android.net.wifi.WifiManager;
import android.net.wifi.p2p.IWifiP2pManager.Stub;
import android.net.wifi.p2p.WifiP2pManager;
import android.nfc.NfcManager;
import android.os.Binder;
import android.os.Bundle;
import android.os.Debug;
import android.os.DropBoxManager;
import android.os.Environment;
import android.os.FileUtils;
import android.os.Handler;
import android.os.IBinder;
import android.os.IPowerManager;
import android.os.IPowerManager.Stub;
import android.os.IUserManager.Stub;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.SystemVibrator;
import android.os.UserHandle;
import android.os.UserManager;
import android.os.storage.StorageManager;
import android.telephony.TelephonyManager;
import android.util.AndroidRuntimeException;
import android.util.Log;
import android.util.Slog;
import android.view.CompatibilityInfoHolder;
import android.view.ContextThemeWrapper;
import android.view.Display;
import android.view.WindowManagerImpl;
import android.view.accessibility.AccessibilityManager;
import android.view.inputmethod.InputMethodManager;
import android.view.textservice.TextServicesManager;
import com.android.internal.os.IDropBoxManagerService;
import com.android.internal.os.IDropBoxManagerService.Stub;
import com.android.internal.policy.PolicyManager;
import com.android.internal.util.Preconditions;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

class ContextImpl
  extends Context
{
  private static final boolean DEBUG = false;
  private static final String[] EMPTY_FILE_LIST;
  private static final HashMap<String, ServiceFetcher> SYSTEM_SERVICE_MAP;
  private static final String TAG = "ApplicationContext";
  private static ServiceFetcher WALLPAPER_FETCHER;
  private static int sNextPerContextServiceCacheIndex;
  private static final HashMap<String, SharedPreferencesImpl> sSharedPrefs = new HashMap();
  private IBinder mActivityToken = null;
  private String mBasePackageName;
  private File mCacheDir;
  private ApplicationContentResolver mContentResolver;
  private File mDatabasesDir;
  private Display mDisplay;
  private File mExternalCacheDir;
  private File mExternalFilesDir;
  private File mFilesDir;
  ActivityThread mMainThread;
  private File mObbDir;
  private Context mOuterContext;
  LoadedApk mPackageInfo;
  private PackageManager mPackageManager;
  private File mPreferencesDir;
  private Context mReceiverRestrictedContext = null;
  private Resources mResources;
  private boolean mRestricted;
  final ArrayList<Object> mServiceCache = new ArrayList();
  private final Object mSync = new Object();
  private Resources.Theme mTheme = null;
  private int mThemeResource = 0;
  private UserHandle mUser;
  
  static
  {
    EMPTY_FILE_LIST = new String[0];
    SYSTEM_SERVICE_MAP = new HashMap();
    sNextPerContextServiceCacheIndex = 0;
    WALLPAPER_FETCHER = new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new WallpaperManager(paramAnonymousContextImpl.getOuterContext(), paramAnonymousContextImpl.mMainThread.getHandler());
      }
    };
    registerService("accessibility", new ServiceFetcher()
    {
      public Object getService(ContextImpl paramAnonymousContextImpl)
      {
        return AccessibilityManager.getInstance(paramAnonymousContextImpl);
      }
    });
    registerService("account", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new AccountManager(paramAnonymousContextImpl, IAccountManager.Stub.asInterface(ServiceManager.getService("account")));
      }
    });
    registerService("activity", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new ActivityManager(paramAnonymousContextImpl.getOuterContext(), paramAnonymousContextImpl.mMainThread.getHandler());
      }
    });
    registerService("alarm", new StaticServiceFetcher()
    {
      public Object createStaticService()
      {
        return new AlarmManager(IAlarmManager.Stub.asInterface(ServiceManager.getService("alarm")));
      }
    });
    registerService("audio", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new AudioManager(paramAnonymousContextImpl);
      }
    });
    registerService("media_router", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new MediaRouter(paramAnonymousContextImpl);
      }
    });
    registerService("bluetooth", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return BluetoothAdapter.getDefaultAdapter();
      }
    });
    registerService("clipboard", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new ClipboardManager(paramAnonymousContextImpl.getOuterContext(), paramAnonymousContextImpl.mMainThread.getHandler());
      }
    });
    registerService("connectivity", new StaticServiceFetcher()
    {
      public Object createStaticService()
      {
        return new ConnectivityManager(IConnectivityManager.Stub.asInterface(ServiceManager.getService("connectivity")));
      }
    });
    registerService("country_detector", new StaticServiceFetcher()
    {
      public Object createStaticService()
      {
        return new CountryDetector(ICountryDetector.Stub.asInterface(ServiceManager.getService("country_detector")));
      }
    });
    registerService("device_policy", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return DevicePolicyManager.create(paramAnonymousContextImpl, paramAnonymousContextImpl.mMainThread.getHandler());
      }
    });
    registerService("download", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new DownloadManager(paramAnonymousContextImpl.getContentResolver(), paramAnonymousContextImpl.getPackageName());
      }
    });
    registerService("nfc", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new NfcManager(paramAnonymousContextImpl);
      }
    });
    registerService("dropbox", new StaticServiceFetcher()
    {
      public Object createStaticService()
      {
        return ContextImpl.createDropBoxManager();
      }
    });
    registerService("input", new StaticServiceFetcher()
    {
      public Object createStaticService()
      {
        return InputManager.getInstance();
      }
    });
    registerService("display", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new DisplayManager(paramAnonymousContextImpl.getOuterContext());
      }
    });
    registerService("input_method", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return InputMethodManager.getInstance(paramAnonymousContextImpl);
      }
    });
    registerService("textservices", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return TextServicesManager.getInstance();
      }
    });
    registerService("keyguard", new ServiceFetcher()
    {
      public Object getService(ContextImpl paramAnonymousContextImpl)
      {
        return new KeyguardManager();
      }
    });
    registerService("layout_inflater", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return PolicyManager.makeNewLayoutInflater(paramAnonymousContextImpl.getOuterContext());
      }
    });
    registerService("location", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new LocationManager(paramAnonymousContextImpl, ILocationManager.Stub.asInterface(ServiceManager.getService("location")));
      }
    });
    registerService("netpolicy", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new NetworkPolicyManager(INetworkPolicyManager.Stub.asInterface(ServiceManager.getService("netpolicy")));
      }
    });
    registerService("notification", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        Context localContext = paramAnonymousContextImpl.getOuterContext();
        return new NotificationManager(new ContextThemeWrapper(localContext, Resources.selectSystemTheme(0, localContext.getApplicationInfo().targetSdkVersion, 16973835, 16973935, 16974126)), paramAnonymousContextImpl.mMainThread.getHandler());
      }
    });
    registerService("servicediscovery", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        INsdManager localINsdManager = INsdManager.Stub.asInterface(ServiceManager.getService("servicediscovery"));
        return new NsdManager(paramAnonymousContextImpl.getOuterContext(), localINsdManager);
      }
    });
    registerService("power", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        IPowerManager localIPowerManager = IPowerManager.Stub.asInterface(ServiceManager.getService("power"));
        return new PowerManager(paramAnonymousContextImpl.getOuterContext(), localIPowerManager, paramAnonymousContextImpl.mMainThread.getHandler());
      }
    });
    registerService("search", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new SearchManager(paramAnonymousContextImpl.getOuterContext(), paramAnonymousContextImpl.mMainThread.getHandler());
      }
    });
    registerService("sensor", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new SystemSensorManager(paramAnonymousContextImpl.mMainThread.getHandler().getLooper());
      }
    });
    registerService("statusbar", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new StatusBarManager(paramAnonymousContextImpl.getOuterContext());
      }
    });
    registerService("storage", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        try
        {
          StorageManager localStorageManager = new StorageManager(paramAnonymousContextImpl.mMainThread.getHandler().getLooper());
          return localStorageManager;
        }
        catch (RemoteException localRemoteException)
        {
          Log.e("ApplicationContext", "Failed to create StorageManager", localRemoteException);
        }
        return null;
      }
    });
    registerService("phone", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new TelephonyManager(paramAnonymousContextImpl.getOuterContext());
      }
    });
    registerService("throttle", new StaticServiceFetcher()
    {
      public Object createStaticService()
      {
        return new ThrottleManager(IThrottleManager.Stub.asInterface(ServiceManager.getService("throttle")));
      }
    });
    registerService("uimode", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new UiModeManager();
      }
    });
    registerService("usb", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new UsbManager(paramAnonymousContextImpl, IUsbManager.Stub.asInterface(ServiceManager.getService("usb")));
      }
    });
    registerService("serial", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new SerialManager(paramAnonymousContextImpl, ISerialManager.Stub.asInterface(ServiceManager.getService("serial")));
      }
    });
    registerService("vibrator", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new SystemVibrator();
      }
    });
    registerService("wallpaper", WALLPAPER_FETCHER);
    registerService("wifi", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        IWifiManager localIWifiManager = IWifiManager.Stub.asInterface(ServiceManager.getService("wifi"));
        return new WifiManager(paramAnonymousContextImpl.getOuterContext(), localIWifiManager);
      }
    });
    registerService("wifip2p", new ServiceFetcher()
    {
      public Object createService(ContextImpl paramAnonymousContextImpl)
      {
        return new WifiP2pManager(IWifiP2pManager.Stub.asInterface(ServiceManager.getService("wifip2p")));
      }
    });
    registerService("window", new ServiceFetcher()
    {
      public Object getService(ContextImpl paramAnonymousContextImpl)
      {
        Display localDisplay = paramAnonymousContextImpl.mDisplay;
        if (localDisplay == null) {
          localDisplay = ((DisplayManager)paramAnonymousContextImpl.getOuterContext().getSystemService("display")).getDisplay(0);
        }
        return new WindowManagerImpl(localDisplay);
      }
    });
    registerService("user", new ServiceFetcher()
    {
      public Object getService(ContextImpl paramAnonymousContextImpl)
      {
        return new UserManager(paramAnonymousContextImpl, IUserManager.Stub.asInterface(ServiceManager.getService("user")));
      }
    });
  }
  
  ContextImpl()
  {
    this.mOuterContext = this;
  }
  
  public ContextImpl(ContextImpl paramContextImpl)
  {
    this.mPackageInfo = paramContextImpl.mPackageInfo;
    this.mBasePackageName = paramContextImpl.mBasePackageName;
    this.mResources = paramContextImpl.mResources;
    this.mMainThread = paramContextImpl.mMainThread;
    this.mContentResolver = paramContextImpl.mContentResolver;
    this.mUser = paramContextImpl.mUser;
    this.mDisplay = paramContextImpl.mDisplay;
    this.mOuterContext = this;
  }
  
  static DropBoxManager createDropBoxManager()
  {
    IDropBoxManagerService localIDropBoxManagerService = IDropBoxManagerService.Stub.asInterface(ServiceManager.getService("dropbox"));
    if (localIDropBoxManagerService == null) {
      return null;
    }
    return new DropBoxManager(localIDropBoxManagerService);
  }
  
  static ContextImpl createSystemContext(ActivityThread paramActivityThread)
  {
    ContextImpl localContextImpl = new ContextImpl();
    localContextImpl.init(Resources.getSystem(), paramActivityThread, Process.myUserHandle());
    return localContextImpl;
  }
  
  private void enforce(String paramString1, int paramInt1, boolean paramBoolean, int paramInt2, String paramString2)
  {
    if (paramInt1 != 0)
    {
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str1;
      StringBuilder localStringBuilder2;
      if (paramString2 != null)
      {
        str1 = paramString2 + ": ";
        localStringBuilder2 = localStringBuilder1.append(str1);
        if (!paramBoolean) {
          break label119;
        }
      }
      label119:
      for (String str2 = "Neither user " + paramInt2 + " nor current process has ";; str2 = "uid " + paramInt2 + " does not have ")
      {
        throw new SecurityException(str2 + paramString1 + ".");
        str1 = "";
        break;
      }
    }
  }
  
  private void enforceForUri(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, Uri paramUri, String paramString)
  {
    if (paramInt2 != 0)
    {
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str1;
      StringBuilder localStringBuilder2;
      if (paramString != null)
      {
        str1 = paramString + ": ";
        localStringBuilder2 = localStringBuilder1.append(str1);
        if (!paramBoolean) {
          break label134;
        }
      }
      label134:
      for (String str2 = "Neither user " + paramInt3 + " nor current process has ";; str2 = "User " + paramInt3 + " does not have ")
      {
        throw new SecurityException(str2 + uriModeFlagToString(paramInt1) + " permission on " + paramUri + ".");
        str1 = "";
        break;
      }
    }
  }
  
  private File getDataDirFile()
  {
    if (this.mPackageInfo != null) {
      return this.mPackageInfo.getDataDirFile();
    }
    throw new RuntimeException("Not supported in system context");
  }
  
  private File getDatabasesDir()
  {
    synchronized (this.mSync)
    {
      if (this.mDatabasesDir == null) {
        this.mDatabasesDir = new File(getDataDirFile(), "databases");
      }
      if (this.mDatabasesDir.getPath().equals("databases")) {
        this.mDatabasesDir = new File("/data/system");
      }
      File localFile = this.mDatabasesDir;
      return localFile;
    }
  }
  
  private int getDisplayId()
  {
    if (this.mDisplay != null) {
      return this.mDisplay.getDisplayId();
    }
    return 0;
  }
  
  static ContextImpl getImpl(Context paramContext)
  {
    while ((paramContext instanceof ContextWrapper))
    {
      Context localContext = ((ContextWrapper)paramContext).getBaseContext();
      if (localContext == null) {
        break;
      }
      paramContext = localContext;
    }
    return (ContextImpl)paramContext;
  }
  
  private File getPreferencesDir()
  {
    synchronized (this.mSync)
    {
      if (this.mPreferencesDir == null) {
        this.mPreferencesDir = new File(getDataDirFile(), "shared_prefs");
      }
      File localFile = this.mPreferencesDir;
      return localFile;
    }
  }
  
  private WallpaperManager getWallpaperManager()
  {
    return (WallpaperManager)WALLPAPER_FETCHER.getService(this);
  }
  
  private File makeFilename(File paramFile, String paramString)
  {
    if (paramString.indexOf(File.separatorChar) < 0) {
      return new File(paramFile, paramString);
    }
    throw new IllegalArgumentException("File " + paramString + " contains a path separator");
  }
  
  private Intent registerReceiverInternal(BroadcastReceiver paramBroadcastReceiver, int paramInt, IntentFilter paramIntentFilter, String paramString, Handler paramHandler, Context paramContext)
  {
    IIntentReceiver localIIntentReceiver = null;
    LoadedApk localLoadedApk;
    Instrumentation localInstrumentation;
    if (paramBroadcastReceiver != null)
    {
      if ((this.mPackageInfo == null) || (paramContext == null)) {
        break label93;
      }
      if (paramHandler == null) {
        paramHandler = this.mMainThread.getHandler();
      }
      localLoadedApk = this.mPackageInfo;
      localInstrumentation = this.mMainThread.getInstrumentation();
    }
    for (localIIntentReceiver = localLoadedApk.getReceiverDispatcher(paramBroadcastReceiver, paramContext, paramHandler, localInstrumentation, true);; localIIntentReceiver = new LoadedApk.ReceiverDispatcher(paramBroadcastReceiver, paramContext, paramHandler, null, true).getIIntentReceiver())
    {
      label93:
      try
      {
        Intent localIntent = ActivityManagerNative.getDefault().registerReceiver(this.mMainThread.getApplicationThread(), this.mBasePackageName, localIIntentReceiver, paramIntentFilter, paramString, paramInt);
        return localIntent;
      }
      catch (RemoteException localRemoteException) {}
      if (paramHandler == null) {
        paramHandler = this.mMainThread.getHandler();
      }
    }
    return null;
  }
  
  private static void registerService(String paramString, ServiceFetcher paramServiceFetcher)
  {
    if (!(paramServiceFetcher instanceof StaticServiceFetcher))
    {
      int i = sNextPerContextServiceCacheIndex;
      sNextPerContextServiceCacheIndex = i + 1;
      paramServiceFetcher.mContextCacheIndex = i;
    }
    SYSTEM_SERVICE_MAP.put(paramString, paramServiceFetcher);
  }
  
  static void setFilePermissionsFromMode(String paramString, int paramInt1, int paramInt2)
  {
    int i = paramInt2 | 0x1B0;
    if ((paramInt1 & 0x1) != 0) {
      i |= 0x4;
    }
    if ((paramInt1 & 0x2) != 0) {
      i |= 0x2;
    }
    FileUtils.setPermissions(paramString, i, -1, -1);
  }
  
  private String uriModeFlagToString(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      throw new IllegalArgumentException("Unknown permission mode flags: " + paramInt);
    case 3: 
      return "read and write";
    case 1: 
      return "read";
    }
    return "write";
  }
  
  private File validateFilePath(String paramString, boolean paramBoolean)
  {
    File localFile1;
    if (paramString.charAt(0) == File.separatorChar) {
      localFile1 = new File(paramString.substring(0, paramString.lastIndexOf(File.separatorChar)));
    }
    for (File localFile2 = new File(localFile1, paramString.substring(paramString.lastIndexOf(File.separatorChar)));; localFile2 = makeFilename(localFile1, paramString))
    {
      if ((paramBoolean) && (!localFile1.isDirectory()) && (localFile1.mkdir())) {
        FileUtils.setPermissions(localFile1.getPath(), 505, -1, -1);
      }
      return localFile2;
      localFile1 = getDatabasesDir();
    }
  }
  
  private void warnIfCallingFromSystemProcess()
  {
    if (Process.myUid() == 1000) {
      Slog.w("ApplicationContext", "Calling a method in the system process without a qualified user: " + Debug.getCallers(3));
    }
  }
  
  public boolean bindService(Intent paramIntent, ServiceConnection paramServiceConnection, int paramInt)
  {
    warnIfCallingFromSystemProcess();
    return bindService(paramIntent, paramServiceConnection, paramInt, UserHandle.getUserId(Process.myUid()));
  }
  
  public boolean bindService(Intent paramIntent, ServiceConnection paramServiceConnection, int paramInt1, int paramInt2)
  {
    if (paramServiceConnection == null) {
      throw new IllegalArgumentException("connection is null");
    }
    int i;
    if (this.mPackageInfo != null)
    {
      IServiceConnection localIServiceConnection = this.mPackageInfo.getServiceDispatcher(paramServiceConnection, getOuterContext(), this.mMainThread.getHandler(), paramInt1);
      try
      {
        if ((getActivityToken() == null) && ((paramInt1 & 0x1) == 0) && (this.mPackageInfo != null) && (this.mPackageInfo.getApplicationInfo().targetSdkVersion < 14)) {
          paramInt1 |= 0x20;
        }
        paramIntent.setAllowFds(false);
        i = ActivityManagerNative.getDefault().bindService(this.mMainThread.getApplicationThread(), getActivityToken(), paramIntent, paramIntent.resolveTypeIfNeeded(getContentResolver()), localIServiceConnection, paramInt1, paramInt2);
        if (i >= 0) {
          break label172;
        }
        throw new SecurityException("Not allowed to bind to service " + paramIntent);
      }
      catch (RemoteException localRemoteException)
      {
        return false;
      }
    }
    throw new RuntimeException("Not supported in system context");
    label172:
    return i != 0;
  }
  
  public int checkCallingOrSelfPermission(String paramString)
  {
    if (paramString == null) {
      throw new IllegalArgumentException("permission is null");
    }
    return checkPermission(paramString, Binder.getCallingPid(), Binder.getCallingUid());
  }
  
  public int checkCallingOrSelfUriPermission(Uri paramUri, int paramInt)
  {
    return checkUriPermission(paramUri, Binder.getCallingPid(), Binder.getCallingUid(), paramInt);
  }
  
  public int checkCallingPermission(String paramString)
  {
    if (paramString == null) {
      throw new IllegalArgumentException("permission is null");
    }
    int i = Binder.getCallingPid();
    if (i != Process.myPid()) {
      return checkPermission(paramString, i, Binder.getCallingUid());
    }
    return -1;
  }
  
  public int checkCallingUriPermission(Uri paramUri, int paramInt)
  {
    int i = Binder.getCallingPid();
    if (i != Process.myPid()) {
      return checkUriPermission(paramUri, i, Binder.getCallingUid(), paramInt);
    }
    return -1;
  }
  
  public int checkPermission(String paramString, int paramInt1, int paramInt2)
  {
    if (paramString == null) {
      throw new IllegalArgumentException("permission is null");
    }
    try
    {
      int i = ActivityManagerNative.getDefault().checkPermission(paramString, paramInt1, paramInt2);
      return i;
    }
    catch (RemoteException localRemoteException) {}
    return -1;
  }
  
  public int checkUriPermission(Uri paramUri, int paramInt1, int paramInt2, int paramInt3)
  {
    try
    {
      int i = ActivityManagerNative.getDefault().checkUriPermission(paramUri, paramInt1, paramInt2, paramInt3);
      return i;
    }
    catch (RemoteException localRemoteException) {}
    return -1;
  }
  
  public int checkUriPermission(Uri paramUri, String paramString1, String paramString2, int paramInt1, int paramInt2, int paramInt3)
  {
    if (((paramInt3 & 0x1) != 0) && ((paramString1 == null) || (checkPermission(paramString1, paramInt1, paramInt2) == 0))) {}
    while (((paramInt3 & 0x2) != 0) && ((paramString2 == null) || (checkPermission(paramString2, paramInt1, paramInt2) == 0))) {
      return 0;
    }
    if (paramUri != null) {
      return checkUriPermission(paramUri, paramInt1, paramInt2, paramInt3);
    }
    return -1;
  }
  
  public void clearWallpaper()
    throws IOException
  {
    getWallpaperManager().clear();
  }
  
  public Context createConfigurationContext(Configuration paramConfiguration)
  {
    if (paramConfiguration == null) {
      throw new IllegalArgumentException("overrideConfiguration must not be null");
    }
    ContextImpl localContextImpl = new ContextImpl();
    localContextImpl.init(this.mPackageInfo, null, this.mMainThread);
    localContextImpl.mResources = this.mMainThread.getTopLevelResources(this.mPackageInfo.getResDir(), getDisplayId(), paramConfiguration, this.mResources.getCompatibilityInfo());
    return localContextImpl;
  }
  
  public Context createDisplayContext(Display paramDisplay)
  {
    if (paramDisplay == null) {
      throw new IllegalArgumentException("display must not be null");
    }
    int i = paramDisplay.getDisplayId();
    CompatibilityInfo localCompatibilityInfo = CompatibilityInfo.DEFAULT_COMPATIBILITY_INFO;
    CompatibilityInfoHolder localCompatibilityInfoHolder = getCompatibilityInfo(i);
    if (localCompatibilityInfoHolder != null) {
      localCompatibilityInfo = localCompatibilityInfoHolder.get();
    }
    ContextImpl localContextImpl = new ContextImpl();
    localContextImpl.init(this.mPackageInfo, null, this.mMainThread);
    localContextImpl.mDisplay = paramDisplay;
    localContextImpl.mResources = this.mMainThread.getTopLevelResources(this.mPackageInfo.getResDir(), i, null, localCompatibilityInfo);
    return localContextImpl;
  }
  
  public Context createPackageContext(String paramString, int paramInt)
    throws PackageManager.NameNotFoundException
  {
    if (this.mUser != null) {}
    for (UserHandle localUserHandle = this.mUser;; localUserHandle = Process.myUserHandle()) {
      return createPackageContextAsUser(paramString, paramInt, localUserHandle);
    }
  }
  
  public Context createPackageContextAsUser(String paramString, int paramInt, UserHandle paramUserHandle)
    throws PackageManager.NameNotFoundException
  {
    boolean bool = true;
    ContextImpl localContextImpl2;
    if ((paramString.equals("system")) || (paramString.equals("android")))
    {
      ContextImpl localContextImpl1 = new ContextImpl(this.mMainThread.getSystemContext());
      if ((paramInt & 0x4) == 4) {}
      for (;;)
      {
        localContextImpl1.mRestricted = bool;
        localContextImpl1.init(this.mPackageInfo, null, this.mMainThread, this.mResources, this.mBasePackageName, paramUserHandle);
        localContextImpl2 = localContextImpl1;
        return localContextImpl2;
        bool = false;
      }
    }
    LoadedApk localLoadedApk = this.mMainThread.getPackageInfo(paramString, this.mResources.getCompatibilityInfo(), paramInt, paramUserHandle.getIdentifier());
    if (localLoadedApk != null)
    {
      localContextImpl2 = new ContextImpl();
      if ((paramInt & 0x4) != 4) {
        break label202;
      }
    }
    for (;;)
    {
      localContextImpl2.mRestricted = bool;
      localContextImpl2.init(localLoadedApk, null, this.mMainThread, this.mResources, this.mBasePackageName, paramUserHandle);
      if (localContextImpl2.mResources != null) {
        break;
      }
      throw new PackageManager.NameNotFoundException("Application package " + paramString + " not found");
      label202:
      bool = false;
    }
  }
  
  public String[] databaseList()
  {
    String[] arrayOfString = getDatabasesDir().list();
    if (arrayOfString != null) {
      return arrayOfString;
    }
    return EMPTY_FILE_LIST;
  }
  
  public boolean deleteDatabase(String paramString)
  {
    try
    {
      boolean bool = SQLiteDatabase.deleteDatabase(validateFilePath(paramString, false));
      return bool;
    }
    catch (Exception localException) {}
    return false;
  }
  
  public boolean deleteFile(String paramString)
  {
    return makeFilename(getFilesDir(), paramString).delete();
  }
  
  public void enforceCallingOrSelfPermission(String paramString1, String paramString2)
  {
    enforce(paramString1, checkCallingOrSelfPermission(paramString1), true, Binder.getCallingUid(), paramString2);
  }
  
  public void enforceCallingOrSelfUriPermission(Uri paramUri, int paramInt, String paramString)
  {
    enforceForUri(paramInt, checkCallingOrSelfUriPermission(paramUri, paramInt), true, Binder.getCallingUid(), paramUri, paramString);
  }
  
  public void enforceCallingPermission(String paramString1, String paramString2)
  {
    enforce(paramString1, checkCallingPermission(paramString1), false, Binder.getCallingUid(), paramString2);
  }
  
  public void enforceCallingUriPermission(Uri paramUri, int paramInt, String paramString)
  {
    enforceForUri(paramInt, checkCallingUriPermission(paramUri, paramInt), false, Binder.getCallingUid(), paramUri, paramString);
  }
  
  public void enforcePermission(String paramString1, int paramInt1, int paramInt2, String paramString2)
  {
    enforce(paramString1, checkPermission(paramString1, paramInt1, paramInt2), false, paramInt2, paramString2);
  }
  
  public void enforceUriPermission(Uri paramUri, int paramInt1, int paramInt2, int paramInt3, String paramString)
  {
    enforceForUri(paramInt3, checkUriPermission(paramUri, paramInt1, paramInt2, paramInt3), false, paramInt2, paramUri, paramString);
  }
  
  public void enforceUriPermission(Uri paramUri, String paramString1, String paramString2, int paramInt1, int paramInt2, int paramInt3, String paramString3)
  {
    enforceForUri(paramInt3, checkUriPermission(paramUri, paramString1, paramString2, paramInt1, paramInt2, paramInt3), false, paramInt2, paramUri, paramString3);
  }
  
  public String[] fileList()
  {
    String[] arrayOfString = getFilesDir().list();
    if (arrayOfString != null) {
      return arrayOfString;
    }
    return EMPTY_FILE_LIST;
  }
  
  final IBinder getActivityToken()
  {
    return this.mActivityToken;
  }
  
  public Context getApplicationContext()
  {
    if (this.mPackageInfo != null) {
      return this.mPackageInfo.getApplication();
    }
    return this.mMainThread.getApplication();
  }
  
  public ApplicationInfo getApplicationInfo()
  {
    if (this.mPackageInfo != null) {
      return this.mPackageInfo.getApplicationInfo();
    }
    throw new RuntimeException("Not supported in system context");
  }
  
  public AssetManager getAssets()
  {
    return getResources().getAssets();
  }
  
  public File getCacheDir()
  {
    synchronized (this.mSync)
    {
      if (this.mCacheDir == null) {
        this.mCacheDir = new File(getDataDirFile(), "cache");
      }
      if (!this.mCacheDir.exists())
      {
        if (!this.mCacheDir.mkdirs())
        {
          Log.w("ApplicationContext", "Unable to create cache directory " + this.mCacheDir.getAbsolutePath());
          return null;
        }
        FileUtils.setPermissions(this.mCacheDir.getPath(), 505, -1, -1);
      }
      return this.mCacheDir;
    }
  }
  
  public ClassLoader getClassLoader()
  {
    if (this.mPackageInfo != null) {
      return this.mPackageInfo.getClassLoader();
    }
    return ClassLoader.getSystemClassLoader();
  }
  
  public CompatibilityInfoHolder getCompatibilityInfo(int paramInt)
  {
    if (paramInt == 0) {
      return this.mPackageInfo.mCompatibilityInfo;
    }
    return null;
  }
  
  public ContentResolver getContentResolver()
  {
    return this.mContentResolver;
  }
  
  public File getDatabasePath(String paramString)
  {
    return validateFilePath(paramString, false);
  }
  
  public File getDir(String paramString, int paramInt)
  {
    String str = "app_" + paramString;
    File localFile = makeFilename(getDataDirFile(), str);
    if (!localFile.exists())
    {
      localFile.mkdir();
      setFilePermissionsFromMode(localFile.getPath(), paramInt, 505);
    }
    return localFile;
  }
  
  public File getExternalCacheDir()
  {
    synchronized (this.mSync)
    {
      if (this.mExternalCacheDir == null) {
        this.mExternalCacheDir = Environment.getExternalStorageAppCacheDirectory(getPackageName());
      }
      boolean bool = this.mExternalCacheDir.exists();
      if (bool) {}
    }
    try
    {
      new File(Environment.getExternalStorageAndroidDataDir(), ".nomedia").createNewFile();
      if (!this.mExternalCacheDir.mkdirs())
      {
        Log.w("ApplicationContext", "Unable to create external cache directory");
        return null;
      }
      File localFile = this.mExternalCacheDir;
      return localFile;
      localObject2 = finally;
      throw ((Throwable)localObject2);
    }
    catch (IOException localIOException)
    {
      for (;;) {}
    }
  }
  
  public File getExternalFilesDir(String paramString)
  {
    synchronized (this.mSync)
    {
      if (this.mExternalFilesDir == null) {
        this.mExternalFilesDir = Environment.getExternalStorageAppFilesDirectory(getPackageName());
      }
      boolean bool = this.mExternalFilesDir.exists();
      if (bool) {}
    }
    try
    {
      new File(Environment.getExternalStorageAndroidDataDir(), ".nomedia").createNewFile();
      if (!this.mExternalFilesDir.mkdirs())
      {
        Log.w("ApplicationContext", "Unable to create external files directory");
        return null;
      }
      if (paramString == null)
      {
        File localFile1 = this.mExternalFilesDir;
        return localFile1;
        localObject2 = finally;
        throw ((Throwable)localObject2);
      }
      File localFile2 = new File(this.mExternalFilesDir, paramString);
      if ((!localFile2.exists()) && (!localFile2.mkdirs()))
      {
        Log.w("ApplicationContext", "Unable to create external media directory " + localFile2);
        return null;
      }
      return localFile2;
    }
    catch (IOException localIOException)
    {
      for (;;) {}
    }
  }
  
  public File getFileStreamPath(String paramString)
  {
    return makeFilename(getFilesDir(), paramString);
  }
  
  public File getFilesDir()
  {
    synchronized (this.mSync)
    {
      if (this.mFilesDir == null) {
        this.mFilesDir = new File(getDataDirFile(), "files");
      }
      if (!this.mFilesDir.exists())
      {
        if (!this.mFilesDir.mkdirs())
        {
          Log.w("ApplicationContext", "Unable to create files directory " + this.mFilesDir.getPath());
          return null;
        }
        FileUtils.setPermissions(this.mFilesDir.getPath(), 505, -1, -1);
      }
      File localFile = this.mFilesDir;
      return localFile;
    }
  }
  
  public Looper getMainLooper()
  {
    return this.mMainThread.getLooper();
  }
  
  public File getObbDir()
  {
    synchronized (this.mSync)
    {
      if (this.mObbDir == null) {
        this.mObbDir = Environment.getExternalStorageAppObbDirectory(getPackageName());
      }
      File localFile = this.mObbDir;
      return localFile;
    }
  }
  
  final Context getOuterContext()
  {
    return this.mOuterContext;
  }
  
  public String getPackageCodePath()
  {
    if (this.mPackageInfo != null) {
      return this.mPackageInfo.getAppDir();
    }
    throw new RuntimeException("Not supported in system context");
  }
  
  public PackageManager getPackageManager()
  {
    if (this.mPackageManager != null) {
      return this.mPackageManager;
    }
    IPackageManager localIPackageManager = ActivityThread.getPackageManager();
    if (localIPackageManager != null)
    {
      ApplicationPackageManager localApplicationPackageManager = new ApplicationPackageManager(this, localIPackageManager);
      this.mPackageManager = localApplicationPackageManager;
      return localApplicationPackageManager;
    }
    return null;
  }
  
  public String getPackageName()
  {
    if (this.mPackageInfo != null) {
      return this.mPackageInfo.getPackageName();
    }
    throw new RuntimeException("Not supported in system context");
  }
  
  public String getPackageResourcePath()
  {
    if (this.mPackageInfo != null) {
      return this.mPackageInfo.getResDir();
    }
    throw new RuntimeException("Not supported in system context");
  }
  
  final Context getReceiverRestrictedContext()
  {
    if (this.mReceiverRestrictedContext != null) {
      return this.mReceiverRestrictedContext;
    }
    ReceiverRestrictedContext localReceiverRestrictedContext = new ReceiverRestrictedContext(getOuterContext());
    this.mReceiverRestrictedContext = localReceiverRestrictedContext;
    return localReceiverRestrictedContext;
  }
  
  public Resources getResources()
  {
    return this.mResources;
  }
  
  public SharedPreferences getSharedPreferences(String paramString, int paramInt)
  {
    synchronized (sSharedPrefs)
    {
      SharedPreferencesImpl localSharedPreferencesImpl1 = (SharedPreferencesImpl)sSharedPrefs.get(paramString);
      if (localSharedPreferencesImpl1 == null)
      {
        SharedPreferencesImpl localSharedPreferencesImpl2 = new SharedPreferencesImpl(getSharedPrefsFile(paramString), paramInt);
        sSharedPrefs.put(paramString, localSharedPreferencesImpl2);
        return localSharedPreferencesImpl2;
      }
      if (((paramInt & 0x4) != 0) || (getApplicationInfo().targetSdkVersion < 11)) {
        localSharedPreferencesImpl1.startReloadIfChangedUnexpectedly();
      }
      return localSharedPreferencesImpl1;
    }
  }
  
  public File getSharedPrefsFile(String paramString)
  {
    return makeFilename(getPreferencesDir(), paramString + ".xml");
  }
  
  public Object getSystemService(String paramString)
  {
    ServiceFetcher localServiceFetcher = (ServiceFetcher)SYSTEM_SERVICE_MAP.get(paramString);
    if (localServiceFetcher == null) {
      return null;
    }
    return localServiceFetcher.getService(this);
  }
  
  public Resources.Theme getTheme()
  {
    if (this.mTheme == null)
    {
      this.mThemeResource = Resources.selectDefaultTheme(this.mThemeResource, getOuterContext().getApplicationInfo().targetSdkVersion);
      this.mTheme = this.mResources.newTheme();
      this.mTheme.applyStyle(this.mThemeResource, true);
    }
    return this.mTheme;
  }
  
  public int getThemeResId()
  {
    return this.mThemeResource;
  }
  
  public int getUserId()
  {
    return this.mUser.getIdentifier();
  }
  
  public Drawable getWallpaper()
  {
    return getWallpaperManager().getDrawable();
  }
  
  public int getWallpaperDesiredMinimumHeight()
  {
    return getWallpaperManager().getDesiredMinimumHeight();
  }
  
  public int getWallpaperDesiredMinimumWidth()
  {
    return getWallpaperManager().getDesiredMinimumWidth();
  }
  
  public void grantUriPermission(String paramString, Uri paramUri, int paramInt)
  {
    try
    {
      ActivityManagerNative.getDefault().grantUriPermission(this.mMainThread.getApplicationThread(), paramString, paramUri, paramInt);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  final void init(LoadedApk paramLoadedApk, IBinder paramIBinder, ActivityThread paramActivityThread)
  {
    init(paramLoadedApk, paramIBinder, paramActivityThread, null, null, Process.myUserHandle());
  }
  
  final void init(LoadedApk paramLoadedApk, IBinder paramIBinder, ActivityThread paramActivityThread, Resources paramResources, String paramString, UserHandle paramUserHandle)
  {
    this.mPackageInfo = paramLoadedApk;
    if (paramString != null) {}
    for (;;)
    {
      this.mBasePackageName = paramString;
      this.mResources = this.mPackageInfo.getResources(paramActivityThread);
      if ((this.mResources != null) && (paramResources != null) && (paramResources.getCompatibilityInfo().applicationScale != this.mResources.getCompatibilityInfo().applicationScale)) {
        this.mResources = paramActivityThread.getTopLevelResources(this.mPackageInfo.getResDir(), 0, null, paramResources.getCompatibilityInfo());
      }
      this.mMainThread = paramActivityThread;
      this.mActivityToken = paramIBinder;
      this.mContentResolver = new ApplicationContentResolver(this, paramActivityThread, paramUserHandle);
      this.mUser = paramUserHandle;
      return;
      paramString = paramLoadedApk.mPackageName;
    }
  }
  
  final void init(Resources paramResources, ActivityThread paramActivityThread, UserHandle paramUserHandle)
  {
    this.mPackageInfo = null;
    this.mBasePackageName = null;
    this.mResources = paramResources;
    this.mMainThread = paramActivityThread;
    this.mContentResolver = new ApplicationContentResolver(this, paramActivityThread, paramUserHandle);
    this.mUser = paramUserHandle;
  }
  
  public boolean isRestricted()
  {
    return this.mRestricted;
  }
  
  public FileInputStream openFileInput(String paramString)
    throws FileNotFoundException
  {
    return new FileInputStream(makeFilename(getFilesDir(), paramString));
  }
  
  public FileOutputStream openFileOutput(String paramString, int paramInt)
    throws FileNotFoundException
  {
    if ((0x8000 & paramInt) != 0) {}
    for (bool = true;; bool = false)
    {
      File localFile1 = makeFilename(getFilesDir(), paramString);
      try
      {
        FileOutputStream localFileOutputStream1 = new FileOutputStream(localFile1, bool);
        setFilePermissionsFromMode(localFile1.getPath(), paramInt, 0);
        return localFileOutputStream1;
      }
      catch (FileNotFoundException localFileNotFoundException)
      {
        File localFile2 = localFile1.getParentFile();
        localFile2.mkdir();
        FileUtils.setPermissions(localFile2.getPath(), 505, -1, -1);
        FileOutputStream localFileOutputStream2 = new FileOutputStream(localFile1, bool);
        setFilePermissionsFromMode(localFile1.getPath(), paramInt, 0);
        return localFileOutputStream2;
      }
    }
  }
  
  public SQLiteDatabase openOrCreateDatabase(String paramString, int paramInt, SQLiteDatabase.CursorFactory paramCursorFactory)
  {
    return openOrCreateDatabase(paramString, paramInt, paramCursorFactory, null);
  }
  
  public SQLiteDatabase openOrCreateDatabase(String paramString, int paramInt, SQLiteDatabase.CursorFactory paramCursorFactory, DatabaseErrorHandler paramDatabaseErrorHandler)
  {
    File localFile = validateFilePath(paramString, true);
    int i = 268435456;
    if ((paramInt & 0x8) != 0) {
      i |= 0x20000000;
    }
    SQLiteDatabase localSQLiteDatabase = SQLiteDatabase.openDatabase(localFile.getPath(), paramCursorFactory, i, paramDatabaseErrorHandler);
    setFilePermissionsFromMode(localFile.getPath(), paramInt, 0);
    return localSQLiteDatabase;
  }
  
  public Drawable peekWallpaper()
  {
    return getWallpaperManager().peekDrawable();
  }
  
  final void performFinalCleanup(String paramString1, String paramString2)
  {
    this.mPackageInfo.removeContextRegistrations(getOuterContext(), paramString1, paramString2);
  }
  
  public Intent registerReceiver(BroadcastReceiver paramBroadcastReceiver, IntentFilter paramIntentFilter)
  {
    return registerReceiver(paramBroadcastReceiver, paramIntentFilter, null, null);
  }
  
  public Intent registerReceiver(BroadcastReceiver paramBroadcastReceiver, IntentFilter paramIntentFilter, String paramString, Handler paramHandler)
  {
    return registerReceiverInternal(paramBroadcastReceiver, getUserId(), paramIntentFilter, paramString, paramHandler, getOuterContext());
  }
  
  public Intent registerReceiverAsUser(BroadcastReceiver paramBroadcastReceiver, UserHandle paramUserHandle, IntentFilter paramIntentFilter, String paramString, Handler paramHandler)
  {
    return registerReceiverInternal(paramBroadcastReceiver, paramUserHandle.getIdentifier(), paramIntentFilter, paramString, paramHandler, getOuterContext());
  }
  
  public void removeStickyBroadcast(Intent paramIntent)
  {
    String str = paramIntent.resolveTypeIfNeeded(getContentResolver());
    if (str != null)
    {
      Intent localIntent = new Intent(paramIntent);
      localIntent.setDataAndType(localIntent.getData(), str);
      paramIntent = localIntent;
    }
    try
    {
      paramIntent.setAllowFds(false);
      ActivityManagerNative.getDefault().unbroadcastIntent(this.mMainThread.getApplicationThread(), paramIntent, getUserId());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void removeStickyBroadcastAsUser(Intent paramIntent, UserHandle paramUserHandle)
  {
    String str = paramIntent.resolveTypeIfNeeded(getContentResolver());
    if (str != null)
    {
      Intent localIntent = new Intent(paramIntent);
      localIntent.setDataAndType(localIntent.getData(), str);
      paramIntent = localIntent;
    }
    try
    {
      paramIntent.setAllowFds(false);
      ActivityManagerNative.getDefault().unbroadcastIntent(this.mMainThread.getApplicationThread(), paramIntent, paramUserHandle.getIdentifier());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void revokeUriPermission(Uri paramUri, int paramInt)
  {
    try
    {
      ActivityManagerNative.getDefault().revokeUriPermission(this.mMainThread.getApplicationThread(), paramUri, paramInt);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  final void scheduleFinalCleanup(String paramString1, String paramString2)
  {
    this.mMainThread.scheduleContextCleanup(this, paramString1, paramString2);
  }
  
  public void sendBroadcast(Intent paramIntent)
  {
    warnIfCallingFromSystemProcess();
    String str = paramIntent.resolveTypeIfNeeded(getContentResolver());
    try
    {
      paramIntent.setAllowFds(false);
      ActivityManagerNative.getDefault().broadcastIntent(this.mMainThread.getApplicationThread(), paramIntent, str, null, -1, null, null, null, false, false, getUserId());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void sendBroadcast(Intent paramIntent, String paramString)
  {
    warnIfCallingFromSystemProcess();
    String str = paramIntent.resolveTypeIfNeeded(getContentResolver());
    try
    {
      paramIntent.setAllowFds(false);
      ActivityManagerNative.getDefault().broadcastIntent(this.mMainThread.getApplicationThread(), paramIntent, str, null, -1, null, null, paramString, false, false, getUserId());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void sendBroadcastAsUser(Intent paramIntent, UserHandle paramUserHandle)
  {
    String str = paramIntent.resolveTypeIfNeeded(getContentResolver());
    try
    {
      paramIntent.setAllowFds(false);
      ActivityManagerNative.getDefault().broadcastIntent(this.mMainThread.getApplicationThread(), paramIntent, str, null, -1, null, null, null, false, false, paramUserHandle.getIdentifier());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void sendBroadcastAsUser(Intent paramIntent, UserHandle paramUserHandle, String paramString)
  {
    String str = paramIntent.resolveTypeIfNeeded(getContentResolver());
    try
    {
      paramIntent.setAllowFds(false);
      ActivityManagerNative.getDefault().broadcastIntent(this.mMainThread.getApplicationThread(), paramIntent, str, null, -1, null, null, paramString, false, false, paramUserHandle.getIdentifier());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void sendOrderedBroadcast(Intent paramIntent, String paramString)
  {
    warnIfCallingFromSystemProcess();
    String str = paramIntent.resolveTypeIfNeeded(getContentResolver());
    try
    {
      paramIntent.setAllowFds(false);
      ActivityManagerNative.getDefault().broadcastIntent(this.mMainThread.getApplicationThread(), paramIntent, str, null, -1, null, null, paramString, true, false, getUserId());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void sendOrderedBroadcast(Intent paramIntent, String paramString1, BroadcastReceiver paramBroadcastReceiver, Handler paramHandler, int paramInt, String paramString2, Bundle paramBundle)
  {
    warnIfCallingFromSystemProcess();
    IIntentReceiver localIIntentReceiver = null;
    LoadedApk localLoadedApk;
    Context localContext;
    Instrumentation localInstrumentation;
    if (paramBroadcastReceiver != null)
    {
      if (this.mPackageInfo == null) {
        break label118;
      }
      if (paramHandler == null) {
        paramHandler = this.mMainThread.getHandler();
      }
      localLoadedApk = this.mPackageInfo;
      localContext = getOuterContext();
      localInstrumentation = this.mMainThread.getInstrumentation();
    }
    for (localIIntentReceiver = localLoadedApk.getReceiverDispatcher(paramBroadcastReceiver, localContext, paramHandler, localInstrumentation, false);; localIIntentReceiver = new LoadedApk.ReceiverDispatcher(paramBroadcastReceiver, getOuterContext(), paramHandler, null, false).getIIntentReceiver())
    {
      String str = paramIntent.resolveTypeIfNeeded(getContentResolver());
      label118:
      try
      {
        paramIntent.setAllowFds(false);
        ActivityManagerNative.getDefault().broadcastIntent(this.mMainThread.getApplicationThread(), paramIntent, str, localIIntentReceiver, paramInt, paramString2, paramBundle, paramString1, true, false, getUserId());
        return;
      }
      catch (RemoteException localRemoteException) {}
      if (paramHandler == null) {
        paramHandler = this.mMainThread.getHandler();
      }
    }
  }
  
  public void sendOrderedBroadcastAsUser(Intent paramIntent, UserHandle paramUserHandle, String paramString1, BroadcastReceiver paramBroadcastReceiver, Handler paramHandler, int paramInt, String paramString2, Bundle paramBundle)
  {
    IIntentReceiver localIIntentReceiver = null;
    LoadedApk localLoadedApk;
    Context localContext;
    Instrumentation localInstrumentation;
    if (paramBroadcastReceiver != null)
    {
      if (this.mPackageInfo == null) {
        break label116;
      }
      if (paramHandler == null) {
        paramHandler = this.mMainThread.getHandler();
      }
      localLoadedApk = this.mPackageInfo;
      localContext = getOuterContext();
      localInstrumentation = this.mMainThread.getInstrumentation();
    }
    for (localIIntentReceiver = localLoadedApk.getReceiverDispatcher(paramBroadcastReceiver, localContext, paramHandler, localInstrumentation, false);; localIIntentReceiver = new LoadedApk.ReceiverDispatcher(paramBroadcastReceiver, getOuterContext(), paramHandler, null, false).getIIntentReceiver())
    {
      String str = paramIntent.resolveTypeIfNeeded(getContentResolver());
      label116:
      try
      {
        paramIntent.setAllowFds(false);
        ActivityManagerNative.getDefault().broadcastIntent(this.mMainThread.getApplicationThread(), paramIntent, str, localIIntentReceiver, paramInt, paramString2, paramBundle, paramString1, true, false, paramUserHandle.getIdentifier());
        return;
      }
      catch (RemoteException localRemoteException) {}
      if (paramHandler == null) {
        paramHandler = this.mMainThread.getHandler();
      }
    }
  }
  
  public void sendStickyBroadcast(Intent paramIntent)
  {
    warnIfCallingFromSystemProcess();
    String str = paramIntent.resolveTypeIfNeeded(getContentResolver());
    try
    {
      paramIntent.setAllowFds(false);
      ActivityManagerNative.getDefault().broadcastIntent(this.mMainThread.getApplicationThread(), paramIntent, str, null, -1, null, null, null, false, true, getUserId());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void sendStickyBroadcastAsUser(Intent paramIntent, UserHandle paramUserHandle)
  {
    String str = paramIntent.resolveTypeIfNeeded(getContentResolver());
    try
    {
      paramIntent.setAllowFds(false);
      ActivityManagerNative.getDefault().broadcastIntent(this.mMainThread.getApplicationThread(), paramIntent, str, null, -1, null, null, null, false, true, paramUserHandle.getIdentifier());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void sendStickyOrderedBroadcast(Intent paramIntent, BroadcastReceiver paramBroadcastReceiver, Handler paramHandler, int paramInt, String paramString, Bundle paramBundle)
  {
    warnIfCallingFromSystemProcess();
    IIntentReceiver localIIntentReceiver = null;
    LoadedApk localLoadedApk;
    Context localContext;
    Instrumentation localInstrumentation;
    if (paramBroadcastReceiver != null)
    {
      if (this.mPackageInfo == null) {
        break label115;
      }
      if (paramHandler == null) {
        paramHandler = this.mMainThread.getHandler();
      }
      localLoadedApk = this.mPackageInfo;
      localContext = getOuterContext();
      localInstrumentation = this.mMainThread.getInstrumentation();
    }
    for (localIIntentReceiver = localLoadedApk.getReceiverDispatcher(paramBroadcastReceiver, localContext, paramHandler, localInstrumentation, false);; localIIntentReceiver = new LoadedApk.ReceiverDispatcher(paramBroadcastReceiver, getOuterContext(), paramHandler, null, false).getIIntentReceiver())
    {
      String str = paramIntent.resolveTypeIfNeeded(getContentResolver());
      label115:
      try
      {
        paramIntent.setAllowFds(false);
        ActivityManagerNative.getDefault().broadcastIntent(this.mMainThread.getApplicationThread(), paramIntent, str, localIIntentReceiver, paramInt, paramString, paramBundle, null, true, true, getUserId());
        return;
      }
      catch (RemoteException localRemoteException) {}
      if (paramHandler == null) {
        paramHandler = this.mMainThread.getHandler();
      }
    }
  }
  
  public void sendStickyOrderedBroadcastAsUser(Intent paramIntent, UserHandle paramUserHandle, BroadcastReceiver paramBroadcastReceiver, Handler paramHandler, int paramInt, String paramString, Bundle paramBundle)
  {
    IIntentReceiver localIIntentReceiver = null;
    LoadedApk localLoadedApk;
    Context localContext;
    Instrumentation localInstrumentation;
    if (paramBroadcastReceiver != null)
    {
      if (this.mPackageInfo == null) {
        break label114;
      }
      if (paramHandler == null) {
        paramHandler = this.mMainThread.getHandler();
      }
      localLoadedApk = this.mPackageInfo;
      localContext = getOuterContext();
      localInstrumentation = this.mMainThread.getInstrumentation();
    }
    for (localIIntentReceiver = localLoadedApk.getReceiverDispatcher(paramBroadcastReceiver, localContext, paramHandler, localInstrumentation, false);; localIIntentReceiver = new LoadedApk.ReceiverDispatcher(paramBroadcastReceiver, getOuterContext(), paramHandler, null, false).getIIntentReceiver())
    {
      String str = paramIntent.resolveTypeIfNeeded(getContentResolver());
      label114:
      try
      {
        paramIntent.setAllowFds(false);
        ActivityManagerNative.getDefault().broadcastIntent(this.mMainThread.getApplicationThread(), paramIntent, str, localIIntentReceiver, paramInt, paramString, paramBundle, null, true, true, paramUserHandle.getIdentifier());
        return;
      }
      catch (RemoteException localRemoteException) {}
      if (paramHandler == null) {
        paramHandler = this.mMainThread.getHandler();
      }
    }
  }
  
  final void setOuterContext(Context paramContext)
  {
    this.mOuterContext = paramContext;
  }
  
  public void setTheme(int paramInt)
  {
    this.mThemeResource = paramInt;
  }
  
  public void setWallpaper(Bitmap paramBitmap)
    throws IOException
  {
    getWallpaperManager().setBitmap(paramBitmap);
  }
  
  public void setWallpaper(InputStream paramInputStream)
    throws IOException
  {
    getWallpaperManager().setStream(paramInputStream);
  }
  
  public void startActivities(Intent[] paramArrayOfIntent)
  {
    warnIfCallingFromSystemProcess();
    startActivities(paramArrayOfIntent, null);
  }
  
  public void startActivities(Intent[] paramArrayOfIntent, Bundle paramBundle)
  {
    warnIfCallingFromSystemProcess();
    if ((0x10000000 & paramArrayOfIntent[0].getFlags()) == 0) {
      throw new AndroidRuntimeException("Calling startActivities() from outside of an Activity  context requires the FLAG_ACTIVITY_NEW_TASK flag on first Intent. Is this really what you want?");
    }
    this.mMainThread.getInstrumentation().execStartActivities(getOuterContext(), this.mMainThread.getApplicationThread(), null, (Activity)null, paramArrayOfIntent, paramBundle);
  }
  
  public void startActivitiesAsUser(Intent[] paramArrayOfIntent, Bundle paramBundle, UserHandle paramUserHandle)
  {
    if ((0x10000000 & paramArrayOfIntent[0].getFlags()) == 0) {
      throw new AndroidRuntimeException("Calling startActivities() from outside of an Activity  context requires the FLAG_ACTIVITY_NEW_TASK flag on first Intent. Is this really what you want?");
    }
    this.mMainThread.getInstrumentation().execStartActivitiesAsUser(getOuterContext(), this.mMainThread.getApplicationThread(), null, (Activity)null, paramArrayOfIntent, paramBundle, paramUserHandle.getIdentifier());
  }
  
  public void startActivity(Intent paramIntent)
  {
    warnIfCallingFromSystemProcess();
    startActivity(paramIntent, null);
  }
  
  public void startActivity(Intent paramIntent, Bundle paramBundle)
  {
    warnIfCallingFromSystemProcess();
    if ((0x10000000 & paramIntent.getFlags()) == 0) {
      throw new AndroidRuntimeException("Calling startActivity() from outside of an Activity  context requires the FLAG_ACTIVITY_NEW_TASK flag. Is this really what you want?");
    }
    this.mMainThread.getInstrumentation().execStartActivity(getOuterContext(), this.mMainThread.getApplicationThread(), null, (Activity)null, paramIntent, -1, paramBundle);
  }
  
  public void startActivityAsUser(Intent paramIntent, Bundle paramBundle, UserHandle paramUserHandle)
  {
    try
    {
      ActivityManagerNative.getDefault().startActivityAsUser(this.mMainThread.getApplicationThread(), paramIntent, paramIntent.resolveTypeIfNeeded(getContentResolver()), null, null, 0, 268435456, null, null, paramBundle, paramUserHandle.getIdentifier());
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public void startActivityAsUser(Intent paramIntent, UserHandle paramUserHandle)
  {
    startActivityAsUser(paramIntent, null, paramUserHandle);
  }
  
  public boolean startInstrumentation(ComponentName paramComponentName, String paramString, Bundle paramBundle)
  {
    if (paramBundle != null) {}
    try
    {
      paramBundle.setAllowFds(false);
      boolean bool = ActivityManagerNative.getDefault().startInstrumentation(paramComponentName, paramString, 0, paramBundle, null, getUserId());
      return bool;
    }
    catch (RemoteException localRemoteException) {}
    return false;
  }
  
  public void startIntentSender(IntentSender paramIntentSender, Intent paramIntent, int paramInt1, int paramInt2, int paramInt3)
    throws IntentSender.SendIntentException
  {
    startIntentSender(paramIntentSender, paramIntent, paramInt1, paramInt2, paramInt3, null);
  }
  
  public void startIntentSender(IntentSender paramIntentSender, Intent paramIntent, int paramInt1, int paramInt2, int paramInt3, Bundle paramBundle)
    throws IntentSender.SendIntentException
  {
    String str = null;
    if (paramIntent != null) {}
    try
    {
      paramIntent.setAllowFds(false);
      str = paramIntent.resolveTypeIfNeeded(getContentResolver());
      int i = ActivityManagerNative.getDefault().startActivityIntentSender(this.mMainThread.getApplicationThread(), paramIntentSender, paramIntent, str, null, null, 0, paramInt1, paramInt2, paramBundle);
      if (i == -6) {
        throw new IntentSender.SendIntentException();
      }
      Instrumentation.checkStartActivityResult(i, null);
      return;
    }
    catch (RemoteException localRemoteException) {}
  }
  
  public ComponentName startService(Intent paramIntent)
  {
    warnIfCallingFromSystemProcess();
    return startServiceAsUser(paramIntent, this.mUser);
  }
  
  public ComponentName startServiceAsUser(Intent paramIntent, UserHandle paramUserHandle)
  {
    ComponentName localComponentName;
    try
    {
      paramIntent.setAllowFds(false);
      localComponentName = ActivityManagerNative.getDefault().startService(this.mMainThread.getApplicationThread(), paramIntent, paramIntent.resolveTypeIfNeeded(getContentResolver()), paramUserHandle.getIdentifier());
      if (localComponentName != null)
      {
        if (localComponentName.getPackageName().equals("!")) {
          throw new SecurityException("Not allowed to start service " + paramIntent + " without permission " + localComponentName.getClassName());
        }
        if (localComponentName.getPackageName().equals("!!")) {
          throw new SecurityException("Unable to start service " + paramIntent + ": " + localComponentName.getClassName());
        }
      }
    }
    catch (RemoteException localRemoteException)
    {
      localComponentName = null;
    }
    return localComponentName;
  }
  
  public boolean stopService(Intent paramIntent)
  {
    warnIfCallingFromSystemProcess();
    return stopServiceAsUser(paramIntent, this.mUser);
  }
  
  public boolean stopServiceAsUser(Intent paramIntent, UserHandle paramUserHandle)
  {
    int i;
    do
    {
      try
      {
        paramIntent.setAllowFds(false);
        i = ActivityManagerNative.getDefault().stopService(this.mMainThread.getApplicationThread(), paramIntent, paramIntent.resolveTypeIfNeeded(getContentResolver()), paramUserHandle.getIdentifier());
        if (i < 0) {
          throw new SecurityException("Not allowed to stop service " + paramIntent);
        }
      }
      catch (RemoteException localRemoteException)
      {
        return false;
      }
    } while (i == 0);
    return true;
  }
  
  public void unbindService(ServiceConnection paramServiceConnection)
  {
    if (paramServiceConnection == null) {
      throw new IllegalArgumentException("connection is null");
    }
    IServiceConnection localIServiceConnection;
    if (this.mPackageInfo != null) {
      localIServiceConnection = this.mPackageInfo.forgetServiceDispatcher(getOuterContext(), paramServiceConnection);
    }
    try
    {
      ActivityManagerNative.getDefault().unbindService(localIServiceConnection);
      return;
    }
    catch (RemoteException localRemoteException) {}
    throw new RuntimeException("Not supported in system context");
  }
  
  public void unregisterReceiver(BroadcastReceiver paramBroadcastReceiver)
  {
    IIntentReceiver localIIntentReceiver;
    if (this.mPackageInfo != null) {
      localIIntentReceiver = this.mPackageInfo.forgetReceiverDispatcher(getOuterContext(), paramBroadcastReceiver);
    }
    try
    {
      ActivityManagerNative.getDefault().unregisterReceiver(localIIntentReceiver);
      return;
    }
    catch (RemoteException localRemoteException) {}
    throw new RuntimeException("Not supported in system context");
  }
  
  private static final class ApplicationContentResolver
    extends ContentResolver
  {
    private final ActivityThread mMainThread;
    private final UserHandle mUser;
    
    public ApplicationContentResolver(Context paramContext, ActivityThread paramActivityThread, UserHandle paramUserHandle)
    {
      super();
      this.mMainThread = ((ActivityThread)Preconditions.checkNotNull(paramActivityThread));
      this.mUser = ((UserHandle)Preconditions.checkNotNull(paramUserHandle));
    }
    
    protected IContentProvider acquireExistingProvider(Context paramContext, String paramString)
    {
      return this.mMainThread.acquireExistingProvider(paramContext, paramString, this.mUser.getIdentifier(), true);
    }
    
    protected IContentProvider acquireProvider(Context paramContext, String paramString)
    {
      return this.mMainThread.acquireProvider(paramContext, paramString, this.mUser.getIdentifier(), true);
    }
    
    protected IContentProvider acquireUnstableProvider(Context paramContext, String paramString)
    {
      return this.mMainThread.acquireProvider(paramContext, paramString, this.mUser.getIdentifier(), false);
    }
    
    public boolean releaseProvider(IContentProvider paramIContentProvider)
    {
      return this.mMainThread.releaseProvider(paramIContentProvider, true);
    }
    
    public boolean releaseUnstableProvider(IContentProvider paramIContentProvider)
    {
      return this.mMainThread.releaseProvider(paramIContentProvider, false);
    }
    
    public void unstableProviderDied(IContentProvider paramIContentProvider)
    {
      this.mMainThread.handleUnstableProviderDied(paramIContentProvider.asBinder(), true);
    }
  }
  
  static class ServiceFetcher
  {
    int mContextCacheIndex = -1;
    
    public Object createService(ContextImpl paramContextImpl)
    {
      throw new RuntimeException("Not implemented");
    }
    
    public Object getService(ContextImpl paramContextImpl)
    {
      synchronized (paramContextImpl.mServiceCache)
      {
        if (???.size() == 0) {
          for (int i = 0; i < ContextImpl.sNextPerContextServiceCacheIndex; i++) {
            ???.add(null);
          }
        }
        Object localObject3 = ???.get(this.mContextCacheIndex);
        if (localObject3 != null) {
          return localObject3;
        }
        Object localObject2 = createService(paramContextImpl);
        ???.set(this.mContextCacheIndex, localObject2);
        return localObject2;
      }
    }
  }
  
  static abstract class StaticServiceFetcher
    extends ContextImpl.ServiceFetcher
  {
    private Object mCachedInstance;
    
    public abstract Object createStaticService();
    
    public final Object getService(ContextImpl paramContextImpl)
    {
      try
      {
        Object localObject2 = this.mCachedInstance;
        if (localObject2 != null) {
          return localObject2;
        }
        Object localObject3 = createStaticService();
        this.mCachedInstance = localObject3;
        return localObject3;
      }
      finally {}
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\app\ContextImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
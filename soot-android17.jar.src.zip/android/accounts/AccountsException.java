package android.accounts;

public class AccountsException
  extends Exception
{
  public AccountsException() {}
  
  public AccountsException(String paramString)
  {
    super(paramString);
  }
  
  public AccountsException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
  
  public AccountsException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\accounts\AccountsException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.accounts;

import android.app.ActivityManager;
import android.app.ActivityManagerNative;
import android.app.IActivityManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.RegisteredServicesCache.ServiceInfo;
import android.content.pm.RegisteredServicesCacheListener;
import android.content.pm.UserInfo;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Binder;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.IBinder.DeathRecipient;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.os.RemoteException;
import android.os.SystemClock;
import android.os.UserHandle;
import android.os.UserManager;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import android.util.Slog;
import android.util.SparseArray;
import com.android.internal.util.IndentingPrintWriter;
import com.google.android.collect.Lists;
import com.google.android.collect.Sets;
import java.io.File;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public class AccountManagerService
  extends IAccountManager.Stub
  implements RegisteredServicesCacheListener<AuthenticatorDescription>
{
  private static final Intent ACCOUNTS_CHANGED_INTENT;
  private static final String ACCOUNTS_ID = "_id";
  private static final String ACCOUNTS_NAME = "name";
  private static final String ACCOUNTS_PASSWORD = "password";
  private static final String ACCOUNTS_TYPE = "type";
  private static final String ACCOUNTS_TYPE_COUNT = "count(type)";
  private static final String[] ACCOUNT_TYPE_COUNT_PROJECTION = { "type", "count(type)" };
  private static final String AUTHTOKENS_ACCOUNTS_ID = "accounts_id";
  private static final String AUTHTOKENS_AUTHTOKEN = "authtoken";
  private static final String AUTHTOKENS_ID = "_id";
  private static final String AUTHTOKENS_TYPE = "type";
  private static final String[] COLUMNS_AUTHTOKENS_TYPE_AND_AUTHTOKEN = { "type", "authtoken" };
  private static final String[] COLUMNS_EXTRAS_KEY_AND_VALUE = { "key", "value" };
  private static final String COUNT_OF_MATCHING_GRANTS = "SELECT COUNT(*) FROM grants, accounts WHERE accounts_id=_id AND uid=? AND auth_token_type=? AND name=? AND type=?";
  private static final String DATABASE_NAME = "accounts.db";
  private static final int DATABASE_VERSION = 4;
  private static final Account[] EMPTY_ACCOUNT_ARRAY;
  private static final String EXTRAS_ACCOUNTS_ID = "accounts_id";
  private static final String EXTRAS_ID = "_id";
  private static final String EXTRAS_KEY = "key";
  private static final String EXTRAS_VALUE = "value";
  private static final String GRANTS_ACCOUNTS_ID = "accounts_id";
  private static final String GRANTS_AUTH_TOKEN_TYPE = "auth_token_type";
  private static final String GRANTS_GRANTEE_UID = "uid";
  private static final int MESSAGE_TIMED_OUT = 3;
  private static final String META_KEY = "key";
  private static final String META_VALUE = "value";
  private static final String SELECTION_AUTHTOKENS_BY_ACCOUNT = "accounts_id=(select _id FROM accounts WHERE name=? AND type=?)";
  private static final String SELECTION_USERDATA_BY_ACCOUNT = "accounts_id=(select _id FROM accounts WHERE name=? AND type=?)";
  private static final String TABLE_ACCOUNTS = "accounts";
  private static final String TABLE_AUTHTOKENS = "authtokens";
  private static final String TABLE_EXTRAS = "extras";
  private static final String TABLE_GRANTS = "grants";
  private static final String TABLE_META = "meta";
  private static final String TAG = "AccountManagerService";
  private static final int TIMEOUT_DELAY_MS = 60000;
  private static AtomicReference<AccountManagerService> sThis = new AtomicReference();
  private final IAccountAuthenticatorCache mAuthenticatorCache;
  private final Context mContext;
  private final MessageHandler mMessageHandler;
  private HandlerThread mMessageThread;
  private final AtomicInteger mNotificationIds = new AtomicInteger(1);
  private final PackageManager mPackageManager;
  private final LinkedHashMap<String, Session> mSessions = new LinkedHashMap();
  private UserManager mUserManager;
  private final SparseArray<UserAccounts> mUsers = new SparseArray();
  
  static
  {
    EMPTY_ACCOUNT_ARRAY = new Account[0];
    ACCOUNTS_CHANGED_INTENT = new Intent("android.accounts.LOGIN_ACCOUNTS_CHANGED");
    ACCOUNTS_CHANGED_INTENT.setFlags(134217728);
  }
  
  public AccountManagerService(Context paramContext)
  {
    this(paramContext, paramContext.getPackageManager(), new AccountAuthenticatorCache(paramContext));
  }
  
  public AccountManagerService(Context paramContext, PackageManager paramPackageManager, IAccountAuthenticatorCache paramIAccountAuthenticatorCache)
  {
    this.mContext = paramContext;
    this.mPackageManager = paramPackageManager;
    this.mMessageThread = new HandlerThread("AccountManagerService");
    this.mMessageThread.start();
    this.mMessageHandler = new MessageHandler(this.mMessageThread.getLooper());
    this.mAuthenticatorCache = paramIAccountAuthenticatorCache;
    this.mAuthenticatorCache.setListener(this, null);
    sThis.set(this);
    IntentFilter localIntentFilter1 = new IntentFilter();
    localIntentFilter1.addAction("android.intent.action.PACKAGE_REMOVED");
    localIntentFilter1.addDataScheme("package");
    this.mContext.registerReceiver(new BroadcastReceiver()
    {
      public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
      {
        AccountManagerService.this.purgeOldGrantsAll();
      }
    }, localIntentFilter1);
    IntentFilter localIntentFilter2 = new IntentFilter();
    localIntentFilter2.addAction("android.intent.action.USER_REMOVED");
    this.mContext.registerReceiver(new BroadcastReceiver()
    {
      public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
      {
        AccountManagerService.this.onUserRemoved(paramAnonymousIntent);
      }
    }, localIntentFilter2);
  }
  
  private boolean addAccountInternal(UserAccounts paramUserAccounts, Account paramAccount, String paramString, Bundle paramBundle)
  {
    if (paramAccount == null) {
      return false;
    }
    SQLiteDatabase localSQLiteDatabase;
    synchronized (paramUserAccounts.cacheLock)
    {
      localSQLiteDatabase = paramUserAccounts.openHelper.getWritableDatabase();
      localSQLiteDatabase.beginTransaction();
    }
    try
    {
      String[] arrayOfString = new String[2];
      arrayOfString[0] = paramAccount.name;
      arrayOfString[1] = paramAccount.type;
      if (DatabaseUtils.longForQuery(localSQLiteDatabase, "select count(*) from accounts WHERE name=? AND type=?", arrayOfString) > 0L)
      {
        Log.w("AccountManagerService", "insertAccountIntoDatabase: " + paramAccount + ", skipping since the account already exists");
        localSQLiteDatabase.endTransaction();
        return false;
        localObject2 = finally;
        throw ((Throwable)localObject2);
      }
      ContentValues localContentValues = new ContentValues();
      localContentValues.put("name", paramAccount.name);
      localContentValues.put("type", paramAccount.type);
      localContentValues.put("password", paramString);
      long l = localSQLiteDatabase.insert("accounts", "name", localContentValues);
      if (l < 0L)
      {
        Log.w("AccountManagerService", "insertAccountIntoDatabase: " + paramAccount + ", skipping the DB insert failed");
        localSQLiteDatabase.endTransaction();
        return false;
      }
      if (paramBundle != null)
      {
        Iterator localIterator = paramBundle.keySet().iterator();
        while (localIterator.hasNext())
        {
          String str = (String)localIterator.next();
          if (insertExtraLocked(localSQLiteDatabase, l, str, paramBundle.getString(str)) < 0L)
          {
            Log.w("AccountManagerService", "insertAccountIntoDatabase: " + paramAccount + ", skipping since insertExtra failed for key " + str);
            localSQLiteDatabase.endTransaction();
            return false;
          }
        }
      }
      localSQLiteDatabase.setTransactionSuccessful();
      insertAccountIntoCacheLocked(paramUserAccounts, paramAccount);
      localSQLiteDatabase.endTransaction();
      sendAccountsChangedBroadcast(paramUserAccounts.userId);
      return true;
    }
    finally
    {
      localSQLiteDatabase.endTransaction();
    }
  }
  
  private void checkAuthenticateAccountsPermission(Account paramAccount)
  {
    checkBinderPermission(new String[] { "android.permission.AUTHENTICATE_ACCOUNTS" });
    checkCallingUidAgainstAuthenticator(paramAccount);
  }
  
  private void checkBinderPermission(String... paramVarArgs)
  {
    int i = Binder.getCallingUid();
    int j = paramVarArgs.length;
    for (int k = 0; k < j; k++)
    {
      String str2 = paramVarArgs[k];
      if (this.mContext.checkCallingOrSelfPermission(str2) == 0)
      {
        if (Log.isLoggable("AccountManagerService", 2)) {
          Log.v("AccountManagerService", "  caller uid " + i + " has " + str2);
        }
        return;
      }
    }
    String str1 = "caller uid " + i + " lacks any of " + TextUtils.join(",", paramVarArgs);
    Log.w("AccountManagerService", "  " + str1);
    throw new SecurityException(str1);
  }
  
  private void checkCallingUidAgainstAuthenticator(Account paramAccount)
  {
    int i = Binder.getCallingUid();
    if ((paramAccount == null) || (!hasAuthenticatorUid(paramAccount.type, i)))
    {
      String str = "caller uid " + i + " is different than the authenticator's uid";
      Log.w("AccountManagerService", str);
      throw new SecurityException(str);
    }
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", "caller uid " + i + " is the same as the authenticator's uid");
    }
  }
  
  private void checkManageAccountsOrUseCredentialsPermissions()
  {
    checkBinderPermission(new String[] { "android.permission.MANAGE_ACCOUNTS", "android.permission.USE_CREDENTIALS" });
  }
  
  private void checkManageAccountsPermission()
  {
    checkBinderPermission(new String[] { "android.permission.MANAGE_ACCOUNTS" });
  }
  
  private void checkReadAccountsPermission()
  {
    checkBinderPermission(new String[] { "android.permission.GET_ACCOUNTS" });
  }
  
  private void createNoCredentialsPermissionNotification(Account paramAccount, Intent paramIntent, int paramInt)
  {
    int i = paramIntent.getIntExtra("uid", -1);
    String str1 = paramIntent.getStringExtra("authTokenType");
    paramIntent.getStringExtra("authTokenLabel");
    Notification localNotification = new Notification(17301642, null, 0L);
    Context localContext = this.mContext;
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = paramAccount.name;
    String str2 = localContext.getString(17040512, arrayOfObject);
    int j = str2.indexOf('\n');
    String str3 = str2;
    String str4 = "";
    if (j > 0)
    {
      str3 = str2.substring(0, j);
      str4 = str2.substring(j + 1);
    }
    UserHandle localUserHandle = new UserHandle(paramInt);
    localNotification.setLatestEventInfo(this.mContext, str3, str4, PendingIntent.getActivityAsUser(this.mContext, 0, paramIntent, 268435456, null, localUserHandle));
    installNotification(getCredentialPermissionNotificationId(paramAccount, str1, i).intValue(), localNotification, localUserHandle);
  }
  
  /* Error */
  private void doNotification(UserAccounts paramUserAccounts, Account paramAccount, CharSequence paramCharSequence, Intent paramIntent, int paramInt)
  {
    // Byte code:
    //   0: invokestatic 552	android/accounts/AccountManagerService:clearCallingIdentity	()J
    //   3: lstore 6
    //   5: ldc 89
    //   7: iconst_2
    //   8: invokestatic 441	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   11: ifeq +40 -> 51
    //   14: ldc 89
    //   16: new 333	java/lang/StringBuilder
    //   19: dup
    //   20: invokespecial 334	java/lang/StringBuilder:<init>	()V
    //   23: ldc_w 554
    //   26: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   29: aload_3
    //   30: invokevirtual 343	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   33: ldc_w 556
    //   36: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   39: aload 4
    //   41: invokevirtual 343	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   44: invokevirtual 349	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   47: invokestatic 451	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   50: pop
    //   51: aload 4
    //   53: invokevirtual 560	android/content/Intent:getComponent	()Landroid/content/ComponentName;
    //   56: ifnull +38 -> 94
    //   59: ldc_w 562
    //   62: invokevirtual 567	java/lang/Class:getName	()Ljava/lang/String;
    //   65: aload 4
    //   67: invokevirtual 560	android/content/Intent:getComponent	()Landroid/content/ComponentName;
    //   70: invokevirtual 572	android/content/ComponentName:getClassName	()Ljava/lang/String;
    //   73: invokevirtual 576	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   76: ifeq +18 -> 94
    //   79: aload_0
    //   80: aload_2
    //   81: aload 4
    //   83: iload 5
    //   85: invokespecial 578	android/accounts/AccountManagerService:createNoCredentialsPermissionNotification	(Landroid/accounts/Account;Landroid/content/Intent;I)V
    //   88: lload 6
    //   90: invokestatic 582	android/accounts/AccountManagerService:restoreCallingIdentity	(J)V
    //   93: return
    //   94: aload_0
    //   95: aload_1
    //   96: aload_2
    //   97: invokespecial 283	android/accounts/AccountManagerService:getSigninRequiredNotificationId	(Landroid/accounts/AccountManagerService$UserAccounts;Landroid/accounts/Account;)Ljava/lang/Integer;
    //   100: astore 9
    //   102: aload 4
    //   104: aload 9
    //   106: invokestatic 586	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   109: invokevirtual 590	android/content/Intent:addCategory	(Ljava/lang/String;)Landroid/content/Intent;
    //   112: pop
    //   113: new 499	android/app/Notification
    //   116: dup
    //   117: ldc_w 500
    //   120: aconst_null
    //   121: lconst_0
    //   122: invokespecial 503	android/app/Notification:<init>	(ILjava/lang/CharSequence;J)V
    //   125: astore 11
    //   127: new 523	android/os/UserHandle
    //   130: dup
    //   131: iload 5
    //   133: invokespecial 524	android/os/UserHandle:<init>	(I)V
    //   136: astore 12
    //   138: aload_0
    //   139: getfield 183	android/accounts/AccountManagerService:mContext	Landroid/content/Context;
    //   142: ldc_w 591
    //   145: invokevirtual 595	android/content/Context:getText	(I)Ljava/lang/CharSequence;
    //   148: invokevirtual 596	java/lang/Object:toString	()Ljava/lang/String;
    //   151: astore 13
    //   153: aload_0
    //   154: getfield 183	android/accounts/AccountManagerService:mContext	Landroid/content/Context;
    //   157: astore 14
    //   159: iconst_1
    //   160: anewarray 505	java/lang/Object
    //   163: astore 15
    //   165: aload 15
    //   167: iconst_0
    //   168: aload_2
    //   169: getfield 321	android/accounts/Account:name	Ljava/lang/String;
    //   172: aastore
    //   173: aload 11
    //   175: aload 14
    //   177: aload 13
    //   179: aload 15
    //   181: invokestatic 600	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   184: aload_3
    //   185: aload_0
    //   186: getfield 183	android/accounts/AccountManagerService:mContext	Landroid/content/Context;
    //   189: iconst_0
    //   190: aload 4
    //   192: ldc_w 525
    //   195: aconst_null
    //   196: aload 12
    //   198: invokestatic 531	android/app/PendingIntent:getActivityAsUser	(Landroid/content/Context;ILandroid/content/Intent;ILandroid/os/Bundle;Landroid/os/UserHandle;)Landroid/app/PendingIntent;
    //   201: invokevirtual 535	android/app/Notification:setLatestEventInfo	(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Landroid/app/PendingIntent;)V
    //   204: aload_0
    //   205: aload 9
    //   207: invokevirtual 544	java/lang/Integer:intValue	()I
    //   210: aload 11
    //   212: aload 12
    //   214: invokevirtual 548	android/accounts/AccountManagerService:installNotification	(ILandroid/app/Notification;Landroid/os/UserHandle;)V
    //   217: goto -129 -> 88
    //   220: astore 8
    //   222: lload 6
    //   224: invokestatic 582	android/accounts/AccountManagerService:restoreCallingIdentity	(J)V
    //   227: aload 8
    //   229: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	230	0	this	AccountManagerService
    //   0	230	1	paramUserAccounts	UserAccounts
    //   0	230	2	paramAccount	Account
    //   0	230	3	paramCharSequence	CharSequence
    //   0	230	4	paramIntent	Intent
    //   0	230	5	paramInt	int
    //   3	220	6	l	long
    //   220	8	8	localObject	Object
    //   100	106	9	localInteger	Integer
    //   125	86	11	localNotification	Notification
    //   136	77	12	localUserHandle	UserHandle
    //   151	27	13	str	String
    //   157	19	14	localContext	Context
    //   163	17	15	arrayOfObject	Object[]
    // Exception table:
    //   from	to	target	type
    //   5	51	220	finally
    //   51	88	220	finally
    //   94	217	220	finally
  }
  
  /* Error */
  private void dumpUser(UserAccounts paramUserAccounts, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString, boolean paramBoolean)
  {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic 304	android/accounts/AccountManagerService$UserAccounts:access$200	(Landroid/accounts/AccountManagerService$UserAccounts;)Ljava/lang/Object;
    //   4: astore 6
    //   6: aload 6
    //   8: monitorenter
    //   9: aload_1
    //   10: invokestatic 308	android/accounts/AccountManagerService$UserAccounts:access$300	(Landroid/accounts/AccountManagerService$UserAccounts;)Landroid/accounts/AccountManagerService$DatabaseHelper;
    //   13: invokevirtual 605	android/accounts/AccountManagerService$DatabaseHelper:getReadableDatabase	()Landroid/database/sqlite/SQLiteDatabase;
    //   16: astore 8
    //   18: iload 5
    //   20: ifeq +101 -> 121
    //   23: aload 8
    //   25: ldc 74
    //   27: getstatic 120	android/accounts/AccountManagerService:ACCOUNT_TYPE_COUNT_PROJECTION	[Ljava/lang/String;
    //   30: aconst_null
    //   31: aconst_null
    //   32: ldc 22
    //   34: aconst_null
    //   35: aconst_null
    //   36: invokevirtual 609	android/database/sqlite/SQLiteDatabase:query	(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   39: astore 9
    //   41: aload 9
    //   43: invokeinterface 614 1 0
    //   48: ifeq +313 -> 361
    //   51: aload_3
    //   52: new 333	java/lang/StringBuilder
    //   55: dup
    //   56: invokespecial 334	java/lang/StringBuilder:<init>	()V
    //   59: aload 9
    //   61: iconst_0
    //   62: invokeinterface 616 2 0
    //   67: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   70: ldc_w 457
    //   73: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: aload 9
    //   78: iconst_1
    //   79: invokeinterface 616 2 0
    //   84: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   87: invokevirtual 349	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   90: invokevirtual 621	java/io/PrintWriter:println	(Ljava/lang/String;)V
    //   93: goto -52 -> 41
    //   96: astore 10
    //   98: aload 9
    //   100: ifnull +10 -> 110
    //   103: aload 9
    //   105: invokeinterface 624 1 0
    //   110: aload 10
    //   112: athrow
    //   113: astore 7
    //   115: aload 6
    //   117: monitorexit
    //   118: aload 7
    //   120: athrow
    //   121: aload_0
    //   122: aload_1
    //   123: aconst_null
    //   124: invokevirtual 628	android/accounts/AccountManagerService:getAccountsFromCacheLocked	(Landroid/accounts/AccountManagerService$UserAccounts;Ljava/lang/String;)[Landroid/accounts/Account;
    //   127: astore 11
    //   129: aload_3
    //   130: new 333	java/lang/StringBuilder
    //   133: dup
    //   134: invokespecial 334	java/lang/StringBuilder:<init>	()V
    //   137: ldc_w 630
    //   140: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   143: aload 11
    //   145: arraylength
    //   146: invokevirtual 446	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   149: invokevirtual 349	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   152: invokevirtual 621	java/io/PrintWriter:println	(Ljava/lang/String;)V
    //   155: aload 11
    //   157: arraylength
    //   158: istore 12
    //   160: iconst_0
    //   161: istore 13
    //   163: iload 13
    //   165: iload 12
    //   167: if_icmpge +41 -> 208
    //   170: aload 11
    //   172: iload 13
    //   174: aaload
    //   175: astore 14
    //   177: aload_3
    //   178: new 333	java/lang/StringBuilder
    //   181: dup
    //   182: invokespecial 334	java/lang/StringBuilder:<init>	()V
    //   185: ldc_w 465
    //   188: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   191: aload 14
    //   193: invokevirtual 343	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   196: invokevirtual 349	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   199: invokevirtual 621	java/io/PrintWriter:println	(Ljava/lang/String;)V
    //   202: iinc 13 1
    //   205: goto -42 -> 163
    //   208: aload_3
    //   209: invokevirtual 632	java/io/PrintWriter:println	()V
    //   212: aload_0
    //   213: getfield 169	android/accounts/AccountManagerService:mSessions	Ljava/util/LinkedHashMap;
    //   216: astore 15
    //   218: aload 15
    //   220: monitorenter
    //   221: invokestatic 637	android/os/SystemClock:elapsedRealtime	()J
    //   224: lstore 17
    //   226: aload_3
    //   227: new 333	java/lang/StringBuilder
    //   230: dup
    //   231: invokespecial 334	java/lang/StringBuilder:<init>	()V
    //   234: ldc_w 639
    //   237: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   240: aload_0
    //   241: getfield 169	android/accounts/AccountManagerService:mSessions	Ljava/util/LinkedHashMap;
    //   244: invokevirtual 642	java/util/LinkedHashMap:size	()I
    //   247: invokevirtual 446	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   250: invokevirtual 349	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   253: invokevirtual 621	java/io/PrintWriter:println	(Ljava/lang/String;)V
    //   256: aload_0
    //   257: getfield 169	android/accounts/AccountManagerService:mSessions	Ljava/util/LinkedHashMap;
    //   260: invokevirtual 646	java/util/LinkedHashMap:values	()Ljava/util/Collection;
    //   263: invokeinterface 649 1 0
    //   268: astore 19
    //   270: aload 19
    //   272: invokeinterface 389 1 0
    //   277: ifeq +56 -> 333
    //   280: aload 19
    //   282: invokeinterface 393 1 0
    //   287: checkcast 651	android/accounts/AccountManagerService$Session
    //   290: astore 20
    //   292: aload_3
    //   293: new 333	java/lang/StringBuilder
    //   296: dup
    //   297: invokespecial 334	java/lang/StringBuilder:<init>	()V
    //   300: ldc_w 465
    //   303: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   306: aload 20
    //   308: lload 17
    //   310: invokevirtual 655	android/accounts/AccountManagerService$Session:toDebugString	(J)Ljava/lang/String;
    //   313: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   316: invokevirtual 349	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   319: invokevirtual 621	java/io/PrintWriter:println	(Ljava/lang/String;)V
    //   322: goto -52 -> 270
    //   325: astore 16
    //   327: aload 15
    //   329: monitorexit
    //   330: aload 16
    //   332: athrow
    //   333: aload 15
    //   335: monitorexit
    //   336: aload_3
    //   337: invokevirtual 632	java/io/PrintWriter:println	()V
    //   340: aload_0
    //   341: getfield 206	android/accounts/AccountManagerService:mAuthenticatorCache	Landroid/accounts/IAccountAuthenticatorCache;
    //   344: aload_2
    //   345: aload_3
    //   346: aload 4
    //   348: aload_1
    //   349: invokestatic 413	android/accounts/AccountManagerService$UserAccounts:access$400	(Landroid/accounts/AccountManagerService$UserAccounts;)I
    //   352: invokeinterface 659 5 0
    //   357: aload 6
    //   359: monitorexit
    //   360: return
    //   361: aload 9
    //   363: ifnull -6 -> 357
    //   366: aload 9
    //   368: invokeinterface 624 1 0
    //   373: goto -16 -> 357
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	376	0	this	AccountManagerService
    //   0	376	1	paramUserAccounts	UserAccounts
    //   0	376	2	paramFileDescriptor	FileDescriptor
    //   0	376	3	paramPrintWriter	PrintWriter
    //   0	376	4	paramArrayOfString	String[]
    //   0	376	5	paramBoolean	boolean
    //   4	354	6	localObject1	Object
    //   113	6	7	localObject2	Object
    //   16	8	8	localSQLiteDatabase	SQLiteDatabase
    //   39	328	9	localCursor	Cursor
    //   96	15	10	localObject3	Object
    //   127	44	11	arrayOfAccount	Account[]
    //   158	10	12	i	int
    //   161	42	13	j	int
    //   175	17	14	localAccount	Account
    //   325	6	16	localObject4	Object
    //   224	85	17	l	long
    //   268	13	19	localIterator	Iterator
    //   290	17	20	localSession	Session
    // Exception table:
    //   from	to	target	type
    //   41	93	96	finally
    //   9	18	113	finally
    //   23	41	113	finally
    //   103	110	113	finally
    //   110	113	113	finally
    //   115	118	113	finally
    //   121	160	113	finally
    //   170	202	113	finally
    //   208	221	113	finally
    //   330	333	113	finally
    //   336	357	113	finally
    //   357	360	113	finally
    //   366	373	113	finally
    //   221	270	325	finally
    //   270	322	325	finally
    //   327	330	325	finally
    //   333	336	325	finally
  }
  
  /* Error */
  private long getAccountIdLocked(SQLiteDatabase paramSQLiteDatabase, Account paramAccount)
  {
    // Byte code:
    //   0: iconst_1
    //   1: anewarray 118	java/lang/String
    //   4: dup
    //   5: iconst_0
    //   6: ldc 13
    //   8: aastore
    //   9: astore_3
    //   10: iconst_2
    //   11: anewarray 118	java/lang/String
    //   14: astore 4
    //   16: aload 4
    //   18: iconst_0
    //   19: aload_2
    //   20: getfield 321	android/accounts/Account:name	Ljava/lang/String;
    //   23: aastore
    //   24: aload 4
    //   26: iconst_1
    //   27: aload_2
    //   28: getfield 323	android/accounts/Account:type	Ljava/lang/String;
    //   31: aastore
    //   32: aload_1
    //   33: ldc 74
    //   35: aload_3
    //   36: ldc_w 663
    //   39: aload 4
    //   41: aconst_null
    //   42: aconst_null
    //   43: aconst_null
    //   44: invokevirtual 609	android/database/sqlite/SQLiteDatabase:query	(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   47: astore 5
    //   49: aload 5
    //   51: invokeinterface 614 1 0
    //   56: ifeq +27 -> 83
    //   59: aload 5
    //   61: iconst_0
    //   62: invokeinterface 667 2 0
    //   67: lstore 9
    //   69: lload 9
    //   71: lstore 7
    //   73: aload 5
    //   75: invokeinterface 624 1 0
    //   80: lload 7
    //   82: lreturn
    //   83: ldc2_w 668
    //   86: lstore 7
    //   88: goto -15 -> 73
    //   91: astore 6
    //   93: aload 5
    //   95: invokeinterface 624 1 0
    //   100: aload 6
    //   102: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	103	0	this	AccountManagerService
    //   0	103	1	paramSQLiteDatabase	SQLiteDatabase
    //   0	103	2	paramAccount	Account
    //   9	27	3	arrayOfString1	String[]
    //   14	26	4	arrayOfString2	String[]
    //   47	47	5	localCursor	Cursor
    //   91	10	6	localObject	Object
    //   71	16	7	l1	long
    //   67	3	9	l2	long
    // Exception table:
    //   from	to	target	type
    //   49	69	91	finally
  }
  
  private AccountAndUser[] getAccounts(int[] paramArrayOfInt)
  {
    ArrayList localArrayList = Lists.newArrayList();
    for (;;)
    {
      int j;
      synchronized (this.mUsers)
      {
        int i = paramArrayOfInt.length;
        j = 0;
        if (j < i)
        {
          int k = paramArrayOfInt[j];
          UserAccounts localUserAccounts = getUserAccounts(k);
          if (localUserAccounts == null) {
            break label140;
          }
          synchronized (localUserAccounts.cacheLock)
          {
            Account[] arrayOfAccount = getAccountsFromCacheLocked(localUserAccounts, null);
            int m = 0;
            if (m < arrayOfAccount.length)
            {
              localArrayList.add(new AccountAndUser(arrayOfAccount[m], k));
              m++;
              continue;
            }
          }
        }
      }
      return (AccountAndUser[])localArrayList.toArray(new AccountAndUser[localArrayList.size()]);
      label140:
      j++;
    }
  }
  
  private Integer getCredentialPermissionNotificationId(Account paramAccount, String paramString, int paramInt)
  {
    UserAccounts localUserAccounts = getUserAccounts(UserHandle.getUserId(paramInt));
    synchronized (localUserAccounts.credentialsPermissionNotificationIds)
    {
      Pair localPair = new Pair(new Pair(paramAccount, paramString), Integer.valueOf(paramInt));
      Integer localInteger = (Integer)localUserAccounts.credentialsPermissionNotificationIds.get(localPair);
      if (localInteger == null)
      {
        localInteger = Integer.valueOf(this.mNotificationIds.incrementAndGet());
        localUserAccounts.credentialsPermissionNotificationIds.put(localPair, localInteger);
      }
      return localInteger;
    }
  }
  
  private static String getDatabaseName(int paramInt)
  {
    File localFile1 = Environment.getSystemSecureDirectory();
    File localFile2 = new File(Environment.getUserSystemDirectory(paramInt), "accounts.db");
    if (paramInt == 0)
    {
      File localFile3 = new File(localFile1, "accounts.db");
      if ((localFile3.exists()) && (!localFile2.exists()))
      {
        File localFile4 = Environment.getUserSystemDirectory(paramInt);
        if ((!localFile4.exists()) && (!localFile4.mkdirs())) {
          throw new IllegalStateException("User dir cannot be created: " + localFile4);
        }
        if (!localFile3.renameTo(localFile2)) {
          throw new IllegalStateException("User dir cannot be migrated: " + localFile2);
        }
      }
    }
    return localFile2.getPath();
  }
  
  /* Error */
  private long getExtrasIdLocked(SQLiteDatabase paramSQLiteDatabase, long paramLong, String paramString)
  {
    // Byte code:
    //   0: aload_1
    //   1: ldc 80
    //   3: iconst_1
    //   4: anewarray 118	java/lang/String
    //   7: dup
    //   8: iconst_0
    //   9: ldc 13
    //   11: aastore
    //   12: new 333	java/lang/StringBuilder
    //   15: dup
    //   16: invokespecial 334	java/lang/StringBuilder:<init>	()V
    //   19: ldc_w 764
    //   22: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   25: lload_2
    //   26: invokevirtual 767	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   29: ldc_w 769
    //   32: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   35: ldc 53
    //   37: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   40: ldc_w 771
    //   43: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   46: invokevirtual 349	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   49: iconst_1
    //   50: anewarray 118	java/lang/String
    //   53: dup
    //   54: iconst_0
    //   55: aload 4
    //   57: aastore
    //   58: aconst_null
    //   59: aconst_null
    //   60: aconst_null
    //   61: invokevirtual 609	android/database/sqlite/SQLiteDatabase:query	(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   64: astore 5
    //   66: aload 5
    //   68: invokeinterface 614 1 0
    //   73: ifeq +27 -> 100
    //   76: aload 5
    //   78: iconst_0
    //   79: invokeinterface 667 2 0
    //   84: lstore 9
    //   86: lload 9
    //   88: lstore 7
    //   90: aload 5
    //   92: invokeinterface 624 1 0
    //   97: lload 7
    //   99: lreturn
    //   100: ldc2_w 668
    //   103: lstore 7
    //   105: goto -15 -> 90
    //   108: astore 6
    //   110: aload 5
    //   112: invokeinterface 624 1 0
    //   117: aload 6
    //   119: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	120	0	this	AccountManagerService
    //   0	120	1	paramSQLiteDatabase	SQLiteDatabase
    //   0	120	2	paramLong	long
    //   0	120	4	paramString	String
    //   64	47	5	localCursor	Cursor
    //   108	10	6	localObject	Object
    //   88	16	7	l1	long
    //   84	3	9	l2	long
    // Exception table:
    //   from	to	target	type
    //   66	86	108	finally
  }
  
  private Integer getSigninRequiredNotificationId(UserAccounts paramUserAccounts, Account paramAccount)
  {
    synchronized (paramUserAccounts.signinRequiredNotificationIds)
    {
      Integer localInteger = (Integer)paramUserAccounts.signinRequiredNotificationIds.get(paramAccount);
      if (localInteger == null)
      {
        localInteger = Integer.valueOf(this.mNotificationIds.incrementAndGet());
        paramUserAccounts.signinRequiredNotificationIds.put(paramAccount, localInteger);
      }
      return localInteger;
    }
  }
  
  public static AccountManagerService getSingleton()
  {
    return (AccountManagerService)sThis.get();
  }
  
  private UserAccounts getUserAccountsForCaller()
  {
    return getUserAccounts(UserHandle.getCallingUserId());
  }
  
  private UserManager getUserManager()
  {
    if (this.mUserManager == null) {
      this.mUserManager = ((UserManager)this.mContext.getSystemService("user"));
    }
    return this.mUserManager;
  }
  
  private void grantAppPermission(Account paramAccount, String paramString, int paramInt)
  {
    if ((paramAccount == null) || (paramString == null))
    {
      Log.e("AccountManagerService", "grantAppPermission: called with invalid arguments", new Exception());
      return;
    }
    UserAccounts localUserAccounts = getUserAccounts(UserHandle.getUserId(paramInt));
    long l;
    ContentValues localContentValues;
    synchronized (localUserAccounts.cacheLock)
    {
      localSQLiteDatabase = localUserAccounts.openHelper.getWritableDatabase();
      localSQLiteDatabase.beginTransaction();
    }
  }
  
  private boolean hasAuthenticatorUid(String paramString, int paramInt)
  {
    int i = UserHandle.getUserId(paramInt);
    Iterator localIterator = this.mAuthenticatorCache.getAllServices(i).iterator();
    while (localIterator.hasNext())
    {
      RegisteredServicesCache.ServiceInfo localServiceInfo = (RegisteredServicesCache.ServiceInfo)localIterator.next();
      if (((AuthenticatorDescription)localServiceInfo.type).type.equals(paramString)) {
        return (localServiceInfo.uid == paramInt) || (this.mPackageManager.checkSignatures(localServiceInfo.uid, paramInt) == 0);
      }
    }
    return false;
  }
  
  private boolean hasExplicitlyGrantedPermission(Account paramAccount, String paramString, int paramInt)
  {
    if (paramInt == 1000) {
      return true;
    }
    UserAccounts localUserAccounts = getUserAccountsForCaller();
    synchronized (localUserAccounts.cacheLock)
    {
      SQLiteDatabase localSQLiteDatabase = localUserAccounts.openHelper.getReadableDatabase();
      String[] arrayOfString = new String[4];
      arrayOfString[0] = String.valueOf(paramInt);
      arrayOfString[1] = paramString;
      arrayOfString[2] = paramAccount.name;
      arrayOfString[3] = paramAccount.type;
      boolean bool1 = DatabaseUtils.longForQuery(localSQLiteDatabase, "SELECT COUNT(*) FROM grants, accounts WHERE accounts_id=_id AND uid=? AND auth_token_type=? AND name=? AND type=?", arrayOfString) < 0L;
      boolean bool2 = false;
      if (bool1) {
        bool2 = true;
      }
      if ((!bool2) && (ActivityManager.isRunningInTestHarness()))
      {
        Log.d("AccountManagerService", "no credentials permission for usage of " + paramAccount + ", " + paramString + " by uid " + paramInt + " but ignoring since device is in test harness.");
        return true;
      }
      return bool2;
    }
  }
  
  private boolean inSystemImage(int paramInt)
  {
    int i = UserHandle.getUserId(paramInt);
    label107:
    for (;;)
    {
      try
      {
        PackageManager localPackageManager = this.mContext.createPackageContextAsUser("android", 0, new UserHandle(i)).getPackageManager();
        String[] arrayOfString = localPackageManager.getPackagesForUid(paramInt);
        int j = arrayOfString.length;
        int k = 0;
        boolean bool = false;
        String str;
        if (k < j) {
          str = arrayOfString[k];
        }
        PackageInfo localPackageInfo;
        int m;
        k++;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException1)
      {
        try
        {
          localPackageInfo = localPackageManager.getPackageInfo(str, 0);
          if (localPackageInfo == null) {
            break label107;
          }
          m = localPackageInfo.applicationInfo.flags;
          if ((m & 0x1) == 0) {
            break label107;
          }
          bool = true;
          return bool;
        }
        catch (PackageManager.NameNotFoundException localNameNotFoundException2)
        {
          return false;
        }
        localNameNotFoundException1 = localNameNotFoundException1;
        return false;
      }
    }
  }
  
  private UserAccounts initUser(int paramInt)
  {
    synchronized (this.mUsers)
    {
      UserAccounts localUserAccounts = (UserAccounts)this.mUsers.get(paramInt);
      if (localUserAccounts == null)
      {
        localUserAccounts = new UserAccounts(this.mContext, paramInt);
        this.mUsers.append(paramInt, localUserAccounts);
        purgeOldGrants(localUserAccounts);
        validateAccountsInternal(localUserAccounts, true);
      }
      return localUserAccounts;
    }
  }
  
  private void insertAccountIntoCacheLocked(UserAccounts paramUserAccounts, Account paramAccount)
  {
    Account[] arrayOfAccount1 = (Account[])paramUserAccounts.accountCache.get(paramAccount.type);
    if (arrayOfAccount1 != null) {}
    for (int i = arrayOfAccount1.length;; i = 0)
    {
      Account[] arrayOfAccount2 = new Account[i + 1];
      if (arrayOfAccount1 != null) {
        System.arraycopy(arrayOfAccount1, 0, arrayOfAccount2, 0, i);
      }
      arrayOfAccount2[i] = paramAccount;
      paramUserAccounts.accountCache.put(paramAccount.type, arrayOfAccount2);
      return;
    }
  }
  
  private long insertExtraLocked(SQLiteDatabase paramSQLiteDatabase, long paramLong, String paramString1, String paramString2)
  {
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("key", paramString1);
    localContentValues.put("accounts_id", Long.valueOf(paramLong));
    localContentValues.put("value", paramString2);
    return paramSQLiteDatabase.insert("extras", "key", localContentValues);
  }
  
  /* Error */
  private void invalidateAuthTokenLocked(UserAccounts paramUserAccounts, SQLiteDatabase paramSQLiteDatabase, String paramString1, String paramString2)
  {
    // Byte code:
    //   0: aload 4
    //   2: ifnull +7 -> 9
    //   5: aload_3
    //   6: ifnonnull +4 -> 10
    //   9: return
    //   10: aload_2
    //   11: ldc_w 926
    //   14: iconst_2
    //   15: anewarray 118	java/lang/String
    //   18: dup
    //   19: iconst_0
    //   20: aload 4
    //   22: aastore
    //   23: dup
    //   24: iconst_1
    //   25: aload_3
    //   26: aastore
    //   27: invokevirtual 930	android/database/sqlite/SQLiteDatabase:rawQuery	(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;
    //   30: astore 5
    //   32: aload 5
    //   34: invokeinterface 614 1 0
    //   39: ifeq +96 -> 135
    //   42: aload 5
    //   44: iconst_0
    //   45: invokeinterface 667 2 0
    //   50: lstore 7
    //   52: aload 5
    //   54: iconst_1
    //   55: invokeinterface 616 2 0
    //   60: astore 9
    //   62: aload 5
    //   64: iconst_2
    //   65: invokeinterface 616 2 0
    //   70: astore 10
    //   72: aload_2
    //   73: ldc 77
    //   75: new 333	java/lang/StringBuilder
    //   78: dup
    //   79: invokespecial 334	java/lang/StringBuilder:<init>	()V
    //   82: ldc_w 932
    //   85: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   88: lload 7
    //   90: invokevirtual 767	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   93: invokevirtual 349	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   96: aconst_null
    //   97: invokevirtual 936	android/database/sqlite/SQLiteDatabase:delete	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I
    //   100: pop
    //   101: aload_0
    //   102: aload_1
    //   103: aload_2
    //   104: new 133	android/accounts/Account
    //   107: dup
    //   108: aload 9
    //   110: aload_3
    //   111: invokespecial 938	android/accounts/Account:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   114: aload 10
    //   116: aconst_null
    //   117: invokevirtual 942	android/accounts/AccountManagerService:writeAuthTokenIntoCacheLocked	(Landroid/accounts/AccountManagerService$UserAccounts;Landroid/database/sqlite/SQLiteDatabase;Landroid/accounts/Account;Ljava/lang/String;Ljava/lang/String;)V
    //   120: goto -88 -> 32
    //   123: astore 6
    //   125: aload 5
    //   127: invokeinterface 624 1 0
    //   132: aload 6
    //   134: athrow
    //   135: aload 5
    //   137: invokeinterface 624 1 0
    //   142: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	143	0	this	AccountManagerService
    //   0	143	1	paramUserAccounts	UserAccounts
    //   0	143	2	paramSQLiteDatabase	SQLiteDatabase
    //   0	143	3	paramString1	String
    //   0	143	4	paramString2	String
    //   30	106	5	localCursor	Cursor
    //   123	10	6	localObject	Object
    //   50	39	7	l	long
    //   60	49	9	str1	String
    //   70	45	10	str2	String
    // Exception table:
    //   from	to	target	type
    //   32	120	123	finally
  }
  
  private Intent newGrantCredentialsPermissionIntent(Account paramAccount, int paramInt, AccountAuthenticatorResponse paramAccountAuthenticatorResponse, String paramString1, String paramString2)
  {
    Intent localIntent = new Intent(this.mContext, GrantCredentialsPermissionActivity.class);
    localIntent.setFlags(268435456);
    localIntent.addCategory(String.valueOf(getCredentialPermissionNotificationId(paramAccount, paramString1, paramInt)));
    localIntent.putExtra("account", paramAccount);
    localIntent.putExtra("authTokenType", paramString1);
    localIntent.putExtra("response", paramAccountAuthenticatorResponse);
    localIntent.putExtra("uid", paramInt);
    return localIntent;
  }
  
  private void onResult(IAccountManagerResponse paramIAccountManagerResponse, Bundle paramBundle)
  {
    if (paramBundle == null) {
      Log.e("AccountManagerService", "the result is unexpectedly null", new Exception());
    }
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", getClass().getSimpleName() + " calling onResult() on response " + paramIAccountManagerResponse);
    }
    try
    {
      paramIAccountManagerResponse.onResult(paramBundle);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      while (!Log.isLoggable("AccountManagerService", 2)) {}
      Log.v("AccountManagerService", "failure while notifying response", localRemoteException);
    }
  }
  
  private void onUserRemoved(Intent paramIntent)
  {
    int i = paramIntent.getIntExtra("android.intent.extra.user_handle", -1);
    if (i < 1) {
      return;
    }
    UserAccounts localUserAccounts;
    synchronized (this.mUsers)
    {
      localUserAccounts = (UserAccounts)this.mUsers.get(i);
      this.mUsers.remove(i);
      if (localUserAccounts == null)
      {
        new File(getDatabaseName(i)).delete();
        return;
      }
    }
    synchronized (localUserAccounts.cacheLock)
    {
      localUserAccounts.openHelper.close();
      new File(getDatabaseName(i)).delete();
      return;
    }
  }
  
  private boolean permissionIsGranted(Account paramAccount, String paramString, int paramInt)
  {
    boolean bool1 = inSystemImage(paramInt);
    boolean bool2;
    if ((paramAccount != null) && (hasAuthenticatorUid(paramAccount.type, paramInt)))
    {
      bool2 = true;
      if ((paramAccount == null) || (!hasExplicitlyGrantedPermission(paramAccount, paramString, paramInt))) {
        break label140;
      }
    }
    label140:
    for (boolean bool3 = true;; bool3 = false)
    {
      if (Log.isLoggable("AccountManagerService", 2)) {
        Log.v("AccountManagerService", "checkGrantsOrCallingUidAgainstAuthenticator: caller uid " + paramInt + ", " + paramAccount + ": is authenticator? " + bool2 + ", has explicit permission? " + bool3);
      }
      boolean bool4;
      if ((!bool2) && (!bool3))
      {
        bool4 = false;
        if (!bool1) {}
      }
      else
      {
        bool4 = true;
      }
      return bool4;
      bool2 = false;
      break;
    }
  }
  
  private void purgeOldGrants(UserAccounts paramUserAccounts)
  {
    Cursor localCursor;
    for (;;)
    {
      synchronized (paramUserAccounts.cacheLock)
      {
        SQLiteDatabase localSQLiteDatabase = paramUserAccounts.openHelper.getWritableDatabase();
        localCursor = localSQLiteDatabase.query("grants", new String[] { "uid" }, null, null, "uid", null, null);
        try
        {
          if (!localCursor.moveToNext()) {
            break;
          }
          int i = localCursor.getInt(0);
          if (this.mPackageManager.getPackagesForUid(i) != null)
          {
            j = 1;
            if (j != 0) {
              continue;
            }
            Log.d("AccountManagerService", "deleting grants for UID " + i + " because its package is no longer installed");
            String[] arrayOfString = new String[1];
            arrayOfString[0] = Integer.toString(i);
            localSQLiteDatabase.delete("grants", "uid=?", arrayOfString);
            continue;
            localObject2 = finally;
          }
        }
        finally
        {
          localCursor.close();
        }
      }
      int j = 0;
    }
    localCursor.close();
  }
  
  private void purgeOldGrantsAll()
  {
    SparseArray localSparseArray = this.mUsers;
    int i = 0;
    try
    {
      while (i < this.mUsers.size())
      {
        purgeOldGrants((UserAccounts)this.mUsers.valueAt(i));
        i++;
      }
      return;
    }
    finally {}
  }
  
  private String readPasswordInternal(UserAccounts paramUserAccounts, Account paramAccount)
  {
    if (paramAccount == null) {
      return null;
    }
    Cursor localCursor;
    synchronized (paramUserAccounts.cacheLock)
    {
      SQLiteDatabase localSQLiteDatabase = paramUserAccounts.openHelper.getReadableDatabase();
      String[] arrayOfString1 = { "password" };
      String[] arrayOfString2 = new String[2];
      arrayOfString2[0] = paramAccount.name;
      arrayOfString2[1] = paramAccount.type;
      localCursor = localSQLiteDatabase.query("accounts", arrayOfString1, "name=? AND type=?", arrayOfString2, null, null, null);
    }
    try
    {
      if (localCursor.moveToNext())
      {
        String str = localCursor.getString(0);
        localCursor.close();
        return str;
        localObject2 = finally;
        throw ((Throwable)localObject2);
      }
      localCursor.close();
      return null;
    }
    finally
    {
      localObject3 = finally;
      localCursor.close();
      throw ((Throwable)localObject3);
    }
  }
  
  private void removeAccountFromCacheLocked(UserAccounts paramUserAccounts, Account paramAccount)
  {
    Account[] arrayOfAccount1 = (Account[])paramUserAccounts.accountCache.get(paramAccount.type);
    ArrayList localArrayList;
    if (arrayOfAccount1 != null)
    {
      localArrayList = new ArrayList();
      int i = arrayOfAccount1.length;
      for (int j = 0; j < i; j++)
      {
        Account localAccount = arrayOfAccount1[j];
        if (!localAccount.equals(paramAccount)) {
          localArrayList.add(localAccount);
        }
      }
      if (!localArrayList.isEmpty()) {
        break label110;
      }
      paramUserAccounts.accountCache.remove(paramAccount.type);
    }
    for (;;)
    {
      paramUserAccounts.userDataCache.remove(paramAccount);
      paramUserAccounts.authTokenCache.remove(paramAccount);
      return;
      label110:
      Account[] arrayOfAccount2 = (Account[])localArrayList.toArray(new Account[localArrayList.size()]);
      paramUserAccounts.accountCache.put(paramAccount.type, arrayOfAccount2);
    }
  }
  
  private void removeAccountInternal(UserAccounts paramUserAccounts, Account paramAccount)
  {
    synchronized (paramUserAccounts.cacheLock)
    {
      SQLiteDatabase localSQLiteDatabase = paramUserAccounts.openHelper.getWritableDatabase();
      String[] arrayOfString = new String[2];
      arrayOfString[0] = paramAccount.name;
      arrayOfString[1] = paramAccount.type;
      localSQLiteDatabase.delete("accounts", "name=? AND type=?", arrayOfString);
      removeAccountFromCacheLocked(paramUserAccounts, paramAccount);
      sendAccountsChangedBroadcast(paramUserAccounts.userId);
      return;
    }
  }
  
  private void revokeAppPermission(Account paramAccount, String paramString, int paramInt)
  {
    if ((paramAccount == null) || (paramString == null))
    {
      Log.e("AccountManagerService", "revokeAppPermission: called with invalid arguments", new Exception());
      return;
    }
    UserAccounts localUserAccounts = getUserAccounts(UserHandle.getUserId(paramInt));
    long l;
    String[] arrayOfString;
    synchronized (localUserAccounts.cacheLock)
    {
      localSQLiteDatabase = localUserAccounts.openHelper.getWritableDatabase();
      localSQLiteDatabase.beginTransaction();
    }
  }
  
  private boolean saveAuthTokenToDatabase(UserAccounts paramUserAccounts, Account paramAccount, String paramString1, String paramString2)
  {
    if ((paramAccount == null) || (paramString1 == null)) {
      return false;
    }
    cancelNotification(getSigninRequiredNotificationId(paramUserAccounts, paramAccount).intValue(), new UserHandle(paramUserAccounts.userId));
    SQLiteDatabase localSQLiteDatabase;
    synchronized (paramUserAccounts.cacheLock)
    {
      localSQLiteDatabase = paramUserAccounts.openHelper.getWritableDatabase();
      localSQLiteDatabase.beginTransaction();
    }
    try
    {
      long l = getAccountIdLocked(localSQLiteDatabase, paramAccount);
      if (l < 0L)
      {
        localSQLiteDatabase.endTransaction();
        return false;
        localObject2 = finally;
        throw ((Throwable)localObject2);
      }
      localSQLiteDatabase.delete("authtokens", "accounts_id=" + l + " AND " + "type" + "=?", new String[] { paramString1 });
      ContentValues localContentValues = new ContentValues();
      localContentValues.put("accounts_id", Long.valueOf(l));
      localContentValues.put("type", paramString1);
      localContentValues.put("authtoken", paramString2);
      if (localSQLiteDatabase.insert("authtokens", "authtoken", localContentValues) >= 0L)
      {
        localSQLiteDatabase.setTransactionSuccessful();
        writeAuthTokenIntoCacheLocked(paramUserAccounts, localSQLiteDatabase, paramAccount, paramString1, paramString2);
        localSQLiteDatabase.endTransaction();
        return true;
      }
      localSQLiteDatabase.endTransaction();
      return false;
    }
    finally
    {
      localSQLiteDatabase.endTransaction();
    }
  }
  
  private static boolean scanArgs(String[] paramArrayOfString, String paramString)
  {
    if (paramArrayOfString != null)
    {
      int i = paramArrayOfString.length;
      for (int j = 0; j < i; j++) {
        if (paramString.equals(paramArrayOfString[j])) {
          return true;
        }
      }
    }
    return false;
  }
  
  private void sendAccountsChangedBroadcast(int paramInt)
  {
    Log.i("AccountManagerService", "the accounts changed, sending broadcast of " + ACCOUNTS_CHANGED_INTENT.getAction());
    this.mContext.sendBroadcastAsUser(ACCOUNTS_CHANGED_INTENT, new UserHandle(paramInt));
  }
  
  private void setPasswordInternal(UserAccounts paramUserAccounts, Account paramAccount, String paramString)
  {
    if (paramAccount == null) {
      return;
    }
    ContentValues localContentValues;
    long l;
    String[] arrayOfString;
    synchronized (paramUserAccounts.cacheLock)
    {
      localSQLiteDatabase = paramUserAccounts.openHelper.getWritableDatabase();
      localSQLiteDatabase.beginTransaction();
    }
  }
  
  private void setUserdataInternal(UserAccounts paramUserAccounts, Account paramAccount, String paramString1, String paramString2)
  {
    if ((paramAccount == null) || (paramString1 == null)) {
      return;
    }
    SQLiteDatabase localSQLiteDatabase;
    synchronized (paramUserAccounts.cacheLock)
    {
      localSQLiteDatabase = paramUserAccounts.openHelper.getWritableDatabase();
      localSQLiteDatabase.beginTransaction();
    }
    try
    {
      long l1 = getAccountIdLocked(localSQLiteDatabase, paramAccount);
      if (l1 < 0L)
      {
        localSQLiteDatabase.endTransaction();
        return;
        localObject2 = finally;
        throw ((Throwable)localObject2);
      }
      long l2 = getExtrasIdLocked(localSQLiteDatabase, l1, paramString1);
      if (l2 < 0L)
      {
        long l3 = insertExtraLocked(localSQLiteDatabase, l1, paramString1, paramString2);
        if (l3 < 0L) {
          localSQLiteDatabase.endTransaction();
        }
      }
      else
      {
        ContentValues localContentValues = new ContentValues();
        localContentValues.put("value", paramString2);
        int i = localSQLiteDatabase.update("extras", localContentValues, "_id=" + l2, null);
        if (1 != i)
        {
          localSQLiteDatabase.endTransaction();
          return;
        }
      }
      writeUserDataIntoCacheLocked(paramUserAccounts, localSQLiteDatabase, paramAccount, paramString1, paramString2);
      localSQLiteDatabase.setTransactionSuccessful();
      localSQLiteDatabase.endTransaction();
      return;
    }
    finally
    {
      localSQLiteDatabase.endTransaction();
    }
  }
  
  private static final String stringArrayToString(String[] paramArrayOfString)
  {
    if (paramArrayOfString != null) {
      return "[" + TextUtils.join(",", paramArrayOfString) + "]";
    }
    return null;
  }
  
  private void validateAccountsInternal(UserAccounts paramUserAccounts, boolean paramBoolean)
  {
    if (paramBoolean) {
      this.mAuthenticatorCache.invalidateCache(paramUserAccounts.userId);
    }
    HashSet localHashSet = Sets.newHashSet();
    Iterator localIterator1 = this.mAuthenticatorCache.getAllServices(paramUserAccounts.userId).iterator();
    while (localIterator1.hasNext()) {
      localHashSet.add(((RegisteredServicesCache.ServiceInfo)localIterator1.next()).type);
    }
    int i;
    Cursor localCursor;
    LinkedHashMap localLinkedHashMap;
    for (;;)
    {
      String str2;
      String str3;
      synchronized (paramUserAccounts.cacheLock)
      {
        SQLiteDatabase localSQLiteDatabase = paramUserAccounts.openHelper.getWritableDatabase();
        i = 0;
        localCursor = localSQLiteDatabase.query("accounts", new String[] { "_id", "type", "name" }, null, null, null, null, null);
        try
        {
          paramUserAccounts.accountCache.clear();
          localLinkedHashMap = new LinkedHashMap();
          if (!localCursor.moveToNext()) {
            break;
          }
          long l = localCursor.getLong(0);
          str2 = localCursor.getString(1);
          str3 = localCursor.getString(2);
          if (!localHashSet.contains(AuthenticatorDescription.newKey(str2)))
          {
            Slog.w("AccountManagerService", "deleting account " + str3 + " because type " + str2 + " no longer has a registered authenticator");
            localSQLiteDatabase.delete("accounts", "_id=" + l, null);
            i = 1;
            Account localAccount = new Account(str3, str2);
            paramUserAccounts.userDataCache.remove(localAccount);
            paramUserAccounts.authTokenCache.remove(localAccount);
            continue;
            localObject2 = finally;
          }
        }
        finally
        {
          localCursor.close();
          if (i != 0) {
            sendAccountsChangedBroadcast(paramUserAccounts.userId);
          }
        }
      }
      ArrayList localArrayList2 = (ArrayList)localLinkedHashMap.get(str2);
      if (localArrayList2 == null)
      {
        localArrayList2 = new ArrayList();
        localLinkedHashMap.put(str2, localArrayList2);
      }
      localArrayList2.add(str3);
    }
    Iterator localIterator2 = localLinkedHashMap.entrySet().iterator();
    while (localIterator2.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator2.next();
      String str1 = (String)localEntry.getKey();
      ArrayList localArrayList1 = (ArrayList)localEntry.getValue();
      Account[] arrayOfAccount = new Account[localArrayList1.size()];
      int j = 0;
      Iterator localIterator3 = localArrayList1.iterator();
      while (localIterator3.hasNext())
      {
        arrayOfAccount[j] = new Account((String)localIterator3.next(), str1);
        j++;
      }
      paramUserAccounts.accountCache.put(str1, arrayOfAccount);
    }
    localCursor.close();
    if (i != 0) {
      sendAccountsChangedBroadcast(paramUserAccounts.userId);
    }
  }
  
  public boolean addAccount(Account paramAccount, String paramString, Bundle paramBundle)
  {
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", "addAccount: " + paramAccount + ", caller's uid " + Binder.getCallingUid() + ", pid " + Binder.getCallingPid());
    }
    if (paramAccount == null) {
      throw new IllegalArgumentException("account is null");
    }
    checkAuthenticateAccountsPermission(paramAccount);
    UserAccounts localUserAccounts = getUserAccountsForCaller();
    long l = clearCallingIdentity();
    try
    {
      boolean bool = addAccountInternal(localUserAccounts, paramAccount, paramString, paramBundle);
      return bool;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  /* Error */
  public void addAcount(IAccountManagerResponse paramIAccountManagerResponse, final String paramString1, final String paramString2, final String[] paramArrayOfString, boolean paramBoolean, Bundle paramBundle)
  {
    // Byte code:
    //   0: ldc 89
    //   2: iconst_2
    //   3: invokestatic 441	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   6: ifeq +98 -> 104
    //   9: ldc 89
    //   11: new 333	java/lang/StringBuilder
    //   14: dup
    //   15: invokespecial 334	java/lang/StringBuilder:<init>	()V
    //   18: ldc_w 1152
    //   21: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: aload_2
    //   25: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   28: ldc_w 1154
    //   31: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   34: aload_1
    //   35: invokevirtual 343	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   38: ldc_w 1156
    //   41: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   44: aload_3
    //   45: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   48: ldc_w 1158
    //   51: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   54: aload 4
    //   56: invokestatic 1160	android/accounts/AccountManagerService:stringArrayToString	([Ljava/lang/String;)Ljava/lang/String;
    //   59: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   62: ldc_w 1162
    //   65: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: iload 5
    //   70: invokevirtual 1004	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   73: ldc_w 1134
    //   76: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   79: invokestatic 433	android/os/Binder:getCallingUid	()I
    //   82: invokevirtual 446	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   85: ldc_w 1136
    //   88: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   91: invokestatic 1139	android/os/Binder:getCallingPid	()I
    //   94: invokevirtual 446	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   97: invokevirtual 349	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   100: invokestatic 451	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   103: pop
    //   104: aload_1
    //   105: ifnonnull +14 -> 119
    //   108: new 1141	java/lang/IllegalArgumentException
    //   111: dup
    //   112: ldc_w 1164
    //   115: invokespecial 1144	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   118: athrow
    //   119: aload_2
    //   120: ifnonnull +14 -> 134
    //   123: new 1141	java/lang/IllegalArgumentException
    //   126: dup
    //   127: ldc_w 1166
    //   130: invokespecial 1144	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   133: athrow
    //   134: aload_0
    //   135: invokespecial 1168	android/accounts/AccountManagerService:checkManageAccountsPermission	()V
    //   138: aload_0
    //   139: invokespecial 847	android/accounts/AccountManagerService:getUserAccountsForCaller	()Landroid/accounts/AccountManagerService$UserAccounts;
    //   142: astore 7
    //   144: invokestatic 1139	android/os/Binder:getCallingPid	()I
    //   147: istore 8
    //   149: invokestatic 433	android/os/Binder:getCallingUid	()I
    //   152: istore 9
    //   154: aload 6
    //   156: ifnonnull +67 -> 223
    //   159: new 373	android/os/Bundle
    //   162: dup
    //   163: invokespecial 1169	android/os/Bundle:<init>	()V
    //   166: astore 10
    //   168: aload 10
    //   170: ldc_w 1171
    //   173: iload 9
    //   175: invokevirtual 1175	android/os/Bundle:putInt	(Ljava/lang/String;I)V
    //   178: aload 10
    //   180: ldc_w 1177
    //   183: iload 8
    //   185: invokevirtual 1175	android/os/Bundle:putInt	(Ljava/lang/String;I)V
    //   188: invokestatic 552	android/accounts/AccountManagerService:clearCallingIdentity	()J
    //   191: lstore 11
    //   193: new 1179	android/accounts/AccountManagerService$5
    //   196: dup
    //   197: aload_0
    //   198: aload 7
    //   200: aload_1
    //   201: aload_2
    //   202: iload 5
    //   204: iconst_1
    //   205: aload_3
    //   206: aload 4
    //   208: aload 10
    //   210: aload_2
    //   211: invokespecial 1182	android/accounts/AccountManagerService$5:<init>	(Landroid/accounts/AccountManagerService;Landroid/accounts/AccountManagerService$UserAccounts;Landroid/accounts/IAccountManagerResponse;Ljava/lang/String;ZZLjava/lang/String;[Ljava/lang/String;Landroid/os/Bundle;Ljava/lang/String;)V
    //   214: invokevirtual 1185	android/accounts/AccountManagerService$5:bind	()V
    //   217: lload 11
    //   219: invokestatic 582	android/accounts/AccountManagerService:restoreCallingIdentity	(J)V
    //   222: return
    //   223: aload 6
    //   225: astore 10
    //   227: goto -59 -> 168
    //   230: astore 13
    //   232: lload 11
    //   234: invokestatic 582	android/accounts/AccountManagerService:restoreCallingIdentity	(J)V
    //   237: aload 13
    //   239: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	240	0	this	AccountManagerService
    //   0	240	1	paramIAccountManagerResponse	IAccountManagerResponse
    //   0	240	2	paramString1	String
    //   0	240	3	paramString2	String
    //   0	240	4	paramArrayOfString	String[]
    //   0	240	5	paramBoolean	boolean
    //   0	240	6	paramBundle	Bundle
    //   142	57	7	localUserAccounts	UserAccounts
    //   147	37	8	i	int
    //   152	22	9	j	int
    //   166	60	10	localBundle	Bundle
    //   191	42	11	l	long
    //   230	8	13	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   193	217	230	finally
  }
  
  protected void cancelNotification(int paramInt, UserHandle paramUserHandle)
  {
    long l = clearCallingIdentity();
    try
    {
      ((NotificationManager)this.mContext.getSystemService("notification")).cancelAsUser(null, paramInt, paramUserHandle);
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public void clearPassword(Account paramAccount)
  {
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", "clearPassword: " + paramAccount + ", caller's uid " + Binder.getCallingUid() + ", pid " + Binder.getCallingPid());
    }
    if (paramAccount == null) {
      throw new IllegalArgumentException("account is null");
    }
    checkManageAccountsPermission();
    UserAccounts localUserAccounts = getUserAccountsForCaller();
    long l = clearCallingIdentity();
    try
    {
      setPasswordInternal(localUserAccounts, paramAccount, null);
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public void confirmCredentialsAsUser(IAccountManagerResponse paramIAccountManagerResponse, final Account paramAccount, final Bundle paramBundle, boolean paramBoolean, int paramInt)
  {
    if ((paramInt != UserHandle.getCallingUserId()) && (Binder.getCallingUid() != Process.myUid())) {
      throw new SecurityException("User " + UserHandle.getCallingUserId() + " trying to confirm account credentials for " + paramInt);
    }
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", "confirmCredentials: " + paramAccount + ", response " + paramIAccountManagerResponse + ", expectActivityLaunch " + paramBoolean + ", caller's uid " + Binder.getCallingUid() + ", pid " + Binder.getCallingPid());
    }
    if (paramIAccountManagerResponse == null) {
      throw new IllegalArgumentException("response is null");
    }
    if (paramAccount == null) {
      throw new IllegalArgumentException("account is null");
    }
    checkManageAccountsPermission();
    UserAccounts localUserAccounts = getUserAccounts(paramInt);
    long l = clearCallingIdentity();
    try
    {
      new Session(localUserAccounts, paramIAccountManagerResponse, paramAccount.type, paramBoolean, true, paramAccount)
      {
        public void run()
          throws RemoteException
        {
          this.mAuthenticator.confirmCredentials(this, paramAccount, paramBundle);
        }
        
        protected String toDebugString(long paramAnonymousLong)
        {
          return super.toDebugString(paramAnonymousLong) + ", confirmCredentials" + ", " + paramAccount;
        }
      }.bind();
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  protected void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    if (this.mContext.checkCallingOrSelfPermission("android.permission.DUMP") != 0)
    {
      paramPrintWriter.println("Permission Denial: can't dump AccountsManager from from pid=" + Binder.getCallingPid() + ", uid=" + Binder.getCallingUid() + " without permission " + "android.permission.DUMP");
      return;
    }
    if ((scanArgs(paramArrayOfString, "--checkin")) || (scanArgs(paramArrayOfString, "-c"))) {}
    for (boolean bool = true;; bool = false)
    {
      IndentingPrintWriter localIndentingPrintWriter = new IndentingPrintWriter(paramPrintWriter, "  ");
      Iterator localIterator = getUserManager().getUsers().iterator();
      while (localIterator.hasNext())
      {
        UserInfo localUserInfo = (UserInfo)localIterator.next();
        localIndentingPrintWriter.println("User " + localUserInfo + ":");
        localIndentingPrintWriter.increaseIndent();
        dumpUser(getUserAccounts(localUserInfo.id), paramFileDescriptor, localIndentingPrintWriter, paramArrayOfString, bool);
        localIndentingPrintWriter.println();
        localIndentingPrintWriter.decreaseIndent();
      }
      break;
    }
  }
  
  public void editProperties(IAccountManagerResponse paramIAccountManagerResponse, final String paramString, boolean paramBoolean)
  {
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", "editProperties: accountType " + paramString + ", response " + paramIAccountManagerResponse + ", expectActivityLaunch " + paramBoolean + ", caller's uid " + Binder.getCallingUid() + ", pid " + Binder.getCallingPid());
    }
    if (paramIAccountManagerResponse == null) {
      throw new IllegalArgumentException("response is null");
    }
    if (paramString == null) {
      throw new IllegalArgumentException("accountType is null");
    }
    checkManageAccountsPermission();
    UserAccounts localUserAccounts = getUserAccountsForCaller();
    long l = clearCallingIdentity();
    try
    {
      new Session(localUserAccounts, paramIAccountManagerResponse, paramString, paramBoolean, true, paramString)
      {
        public void run()
          throws RemoteException
        {
          this.mAuthenticator.editProperties(this, this.mAccountType);
        }
        
        protected String toDebugString(long paramAnonymousLong)
        {
          return super.toDebugString(paramAnonymousLong) + ", editProperties" + ", accountType " + paramString;
        }
      }.bind();
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  /* Error */
  public Account[] getAccounts(int paramInt)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial 1276	android/accounts/AccountManagerService:checkReadAccountsPermission	()V
    //   4: aload_0
    //   5: iload_1
    //   6: invokevirtual 681	android/accounts/AccountManagerService:getUserAccounts	(I)Landroid/accounts/AccountManagerService$UserAccounts;
    //   9: astore_2
    //   10: invokestatic 552	android/accounts/AccountManagerService:clearCallingIdentity	()J
    //   13: lstore_3
    //   14: aload_2
    //   15: invokestatic 304	android/accounts/AccountManagerService$UserAccounts:access$200	(Landroid/accounts/AccountManagerService$UserAccounts;)Ljava/lang/Object;
    //   18: astore 6
    //   20: aload 6
    //   22: monitorenter
    //   23: aload_0
    //   24: aload_2
    //   25: aconst_null
    //   26: invokevirtual 628	android/accounts/AccountManagerService:getAccountsFromCacheLocked	(Landroid/accounts/AccountManagerService$UserAccounts;Ljava/lang/String;)[Landroid/accounts/Account;
    //   29: astore 8
    //   31: aload 6
    //   33: monitorexit
    //   34: lload_3
    //   35: invokestatic 582	android/accounts/AccountManagerService:restoreCallingIdentity	(J)V
    //   38: aload 8
    //   40: areturn
    //   41: astore 7
    //   43: aload 6
    //   45: monitorexit
    //   46: aload 7
    //   48: athrow
    //   49: astore 5
    //   51: lload_3
    //   52: invokestatic 582	android/accounts/AccountManagerService:restoreCallingIdentity	(J)V
    //   55: aload 5
    //   57: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	58	0	this	AccountManagerService
    //   0	58	1	paramInt	int
    //   9	16	2	localUserAccounts	UserAccounts
    //   13	39	3	l	long
    //   49	7	5	localObject1	Object
    //   41	6	7	localObject3	Object
    //   29	10	8	arrayOfAccount	Account[]
    // Exception table:
    //   from	to	target	type
    //   23	34	41	finally
    //   43	46	41	finally
    //   14	23	49	finally
    //   46	49	49	finally
  }
  
  public Account[] getAccounts(String paramString)
  {
    return getAccountsAsUser(paramString, UserHandle.getCallingUserId());
  }
  
  /* Error */
  public Account[] getAccountsAsUser(String paramString, int paramInt)
  {
    // Byte code:
    //   0: iload_2
    //   1: invokestatic 783	android/os/UserHandle:getCallingUserId	()I
    //   4: if_icmpeq +52 -> 56
    //   7: invokestatic 433	android/os/Binder:getCallingUid	()I
    //   10: invokestatic 1205	android/os/Process:myUid	()I
    //   13: if_icmpeq +43 -> 56
    //   16: new 467	java/lang/SecurityException
    //   19: dup
    //   20: new 333	java/lang/StringBuilder
    //   23: dup
    //   24: invokespecial 334	java/lang/StringBuilder:<init>	()V
    //   27: ldc_w 1207
    //   30: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   33: invokestatic 783	android/os/UserHandle:getCallingUserId	()I
    //   36: invokevirtual 446	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   39: ldc_w 1283
    //   42: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   45: iload_2
    //   46: invokevirtual 446	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   49: invokevirtual 349	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   52: invokespecial 468	java/lang/SecurityException:<init>	(Ljava/lang/String;)V
    //   55: athrow
    //   56: ldc 89
    //   58: iconst_2
    //   59: invokestatic 441	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   62: ifeq +53 -> 115
    //   65: ldc 89
    //   67: new 333	java/lang/StringBuilder
    //   70: dup
    //   71: invokespecial 334	java/lang/StringBuilder:<init>	()V
    //   74: ldc_w 1285
    //   77: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: aload_1
    //   81: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   84: ldc_w 1134
    //   87: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   90: invokestatic 433	android/os/Binder:getCallingUid	()I
    //   93: invokevirtual 446	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   96: ldc_w 1136
    //   99: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   102: invokestatic 1139	android/os/Binder:getCallingPid	()I
    //   105: invokevirtual 446	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   108: invokevirtual 349	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   111: invokestatic 451	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   114: pop
    //   115: aload_0
    //   116: invokespecial 1276	android/accounts/AccountManagerService:checkReadAccountsPermission	()V
    //   119: aload_0
    //   120: iload_2
    //   121: invokevirtual 681	android/accounts/AccountManagerService:getUserAccounts	(I)Landroid/accounts/AccountManagerService$UserAccounts;
    //   124: astore_3
    //   125: invokestatic 552	android/accounts/AccountManagerService:clearCallingIdentity	()J
    //   128: lstore 4
    //   130: aload_3
    //   131: invokestatic 304	android/accounts/AccountManagerService$UserAccounts:access$200	(Landroid/accounts/AccountManagerService$UserAccounts;)Ljava/lang/Object;
    //   134: astore 7
    //   136: aload 7
    //   138: monitorenter
    //   139: aload_0
    //   140: aload_3
    //   141: aload_1
    //   142: invokevirtual 628	android/accounts/AccountManagerService:getAccountsFromCacheLocked	(Landroid/accounts/AccountManagerService$UserAccounts;Ljava/lang/String;)[Landroid/accounts/Account;
    //   145: astore 9
    //   147: aload 7
    //   149: monitorexit
    //   150: lload 4
    //   152: invokestatic 582	android/accounts/AccountManagerService:restoreCallingIdentity	(J)V
    //   155: aload 9
    //   157: areturn
    //   158: astore 8
    //   160: aload 7
    //   162: monitorexit
    //   163: aload 8
    //   165: athrow
    //   166: astore 6
    //   168: lload 4
    //   170: invokestatic 582	android/accounts/AccountManagerService:restoreCallingIdentity	(J)V
    //   173: aload 6
    //   175: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	176	0	this	AccountManagerService
    //   0	176	1	paramString	String
    //   0	176	2	paramInt	int
    //   124	17	3	localUserAccounts	UserAccounts
    //   128	41	4	l	long
    //   166	8	6	localObject1	Object
    //   158	6	8	localObject3	Object
    //   145	11	9	arrayOfAccount	Account[]
    // Exception table:
    //   from	to	target	type
    //   139	150	158	finally
    //   160	163	158	finally
    //   130	139	166	finally
    //   163	166	166	finally
  }
  
  public void getAccountsByFeatures(IAccountManagerResponse paramIAccountManagerResponse, String paramString, String[] paramArrayOfString)
  {
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", "getAccounts: accountType " + paramString + ", response " + paramIAccountManagerResponse + ", features " + stringArrayToString(paramArrayOfString) + ", caller's uid " + Binder.getCallingUid() + ", pid " + Binder.getCallingPid());
    }
    if (paramIAccountManagerResponse == null) {
      throw new IllegalArgumentException("response is null");
    }
    if (paramString == null) {
      throw new IllegalArgumentException("accountType is null");
    }
    checkReadAccountsPermission();
    UserAccounts localUserAccounts = getUserAccountsForCaller();
    long l = clearCallingIdentity();
    if (paramArrayOfString != null) {}
    for (;;)
    {
      try
      {
        if (paramArrayOfString.length == 0) {
          synchronized (localUserAccounts.cacheLock)
          {
            Account[] arrayOfAccount = getAccountsFromCacheLocked(localUserAccounts, paramString);
            Bundle localBundle = new Bundle();
            localBundle.putParcelableArray("accounts", arrayOfAccount);
            onResult(paramIAccountManagerResponse, localBundle);
            return;
          }
        }
        new GetAccountsByTypeAndFeatureSession(localUserAccounts, paramIAccountManagerResponse, paramString, paramArrayOfString).bind();
      }
      finally
      {
        restoreCallingIdentity(l);
      }
    }
  }
  
  protected Account[] getAccountsFromCacheLocked(UserAccounts paramUserAccounts, String paramString)
  {
    if (paramString != null)
    {
      Account[] arrayOfAccount3 = (Account[])paramUserAccounts.accountCache.get(paramString);
      if (arrayOfAccount3 == null) {
        return EMPTY_ACCOUNT_ARRAY;
      }
      return (Account[])Arrays.copyOf(arrayOfAccount3, arrayOfAccount3.length);
    }
    int i = 0;
    Iterator localIterator1 = paramUserAccounts.accountCache.values().iterator();
    while (localIterator1.hasNext()) {
      i += ((Account[])localIterator1.next()).length;
    }
    if (i == 0) {
      return EMPTY_ACCOUNT_ARRAY;
    }
    Account[] arrayOfAccount1 = new Account[i];
    int j = 0;
    Iterator localIterator2 = paramUserAccounts.accountCache.values().iterator();
    while (localIterator2.hasNext())
    {
      Account[] arrayOfAccount2 = (Account[])localIterator2.next();
      System.arraycopy(arrayOfAccount2, 0, arrayOfAccount1, j, arrayOfAccount2.length);
      j += arrayOfAccount2.length;
    }
    return arrayOfAccount1;
  }
  
  public AccountAndUser[] getAllAccounts()
  {
    List localList = getUserManager().getUsers();
    int[] arrayOfInt = new int[localList.size()];
    for (int i = 0; i < arrayOfInt.length; i++) {
      arrayOfInt[i] = ((UserInfo)localList.get(i)).id;
    }
    return getAccounts(arrayOfInt);
  }
  
  /* Error */
  public void getAuthToken(IAccountManagerResponse paramIAccountManagerResponse, final Account paramAccount, final String paramString, final boolean paramBoolean1, boolean paramBoolean2, Bundle paramBundle)
  {
    // Byte code:
    //   0: ldc 89
    //   2: iconst_2
    //   3: invokestatic 441	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   6: ifeq +95 -> 101
    //   9: ldc 89
    //   11: new 333	java/lang/StringBuilder
    //   14: dup
    //   15: invokespecial 334	java/lang/StringBuilder:<init>	()V
    //   18: ldc_w 1318
    //   21: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: aload_2
    //   25: invokevirtual 343	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   28: ldc_w 1154
    //   31: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   34: aload_1
    //   35: invokevirtual 343	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   38: ldc_w 1156
    //   41: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   44: aload_3
    //   45: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   48: ldc_w 1320
    //   51: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   54: iload 4
    //   56: invokevirtual 1004	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   59: ldc_w 1162
    //   62: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   65: iload 5
    //   67: invokevirtual 1004	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   70: ldc_w 1134
    //   73: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: invokestatic 433	android/os/Binder:getCallingUid	()I
    //   79: invokevirtual 446	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   82: ldc_w 1136
    //   85: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   88: invokestatic 1139	android/os/Binder:getCallingPid	()I
    //   91: invokevirtual 446	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   94: invokevirtual 349	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   97: invokestatic 451	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   100: pop
    //   101: aload_1
    //   102: ifnonnull +14 -> 116
    //   105: new 1141	java/lang/IllegalArgumentException
    //   108: dup
    //   109: ldc_w 1164
    //   112: invokespecial 1144	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   115: athrow
    //   116: aload_2
    //   117: ifnonnull +14 -> 131
    //   120: new 1141	java/lang/IllegalArgumentException
    //   123: dup
    //   124: ldc_w 1143
    //   127: invokespecial 1144	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   130: athrow
    //   131: aload_3
    //   132: ifnonnull +14 -> 146
    //   135: new 1141	java/lang/IllegalArgumentException
    //   138: dup
    //   139: ldc_w 1322
    //   142: invokespecial 1144	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   145: athrow
    //   146: aload_0
    //   147: iconst_1
    //   148: anewarray 118	java/lang/String
    //   151: dup
    //   152: iconst_0
    //   153: ldc_w 480
    //   156: aastore
    //   157: invokespecial 424	android/accounts/AccountManagerService:checkBinderPermission	([Ljava/lang/String;)V
    //   160: aload_0
    //   161: invokespecial 847	android/accounts/AccountManagerService:getUserAccountsForCaller	()Landroid/accounts/AccountManagerService$UserAccounts;
    //   164: astore 7
    //   166: aload_0
    //   167: getfield 206	android/accounts/AccountManagerService:mAuthenticatorCache	Landroid/accounts/IAccountAuthenticatorCache;
    //   170: aload_2
    //   171: getfield 323	android/accounts/Account:type	Ljava/lang/String;
    //   174: invokestatic 1102	android/accounts/AuthenticatorDescription:newKey	(Ljava/lang/String;)Landroid/accounts/AuthenticatorDescription;
    //   177: aload 7
    //   179: invokestatic 413	android/accounts/AccountManagerService$UserAccounts:access$400	(Landroid/accounts/AccountManagerService$UserAccounts;)I
    //   182: invokeinterface 1326 3 0
    //   187: astore 8
    //   189: aload 8
    //   191: ifnull +178 -> 369
    //   194: aload 8
    //   196: getfield 832	android/content/pm/RegisteredServicesCache$ServiceInfo:type	Ljava/lang/Object;
    //   199: checkcast 834	android/accounts/AuthenticatorDescription
    //   202: getfield 1330	android/accounts/AuthenticatorDescription:customTokens	Z
    //   205: ifeq +164 -> 369
    //   208: iconst_1
    //   209: istore 9
    //   211: invokestatic 433	android/os/Binder:getCallingUid	()I
    //   214: istore 10
    //   216: iload 9
    //   218: ifne +14 -> 232
    //   221: aload_0
    //   222: aload_2
    //   223: aload_3
    //   224: iload 10
    //   226: invokespecial 1332	android/accounts/AccountManagerService:permissionIsGranted	(Landroid/accounts/Account;Ljava/lang/String;I)Z
    //   229: ifeq +146 -> 375
    //   232: iconst_1
    //   233: istore 11
    //   235: aload 6
    //   237: ifnonnull +144 -> 381
    //   240: new 373	android/os/Bundle
    //   243: dup
    //   244: invokespecial 1169	android/os/Bundle:<init>	()V
    //   247: astore 12
    //   249: aload 12
    //   251: ldc_w 1171
    //   254: iload 10
    //   256: invokevirtual 1175	android/os/Bundle:putInt	(Ljava/lang/String;I)V
    //   259: aload 12
    //   261: ldc_w 1177
    //   264: invokestatic 1139	android/os/Binder:getCallingPid	()I
    //   267: invokevirtual 1175	android/os/Bundle:putInt	(Ljava/lang/String;I)V
    //   270: iload 4
    //   272: ifeq +12 -> 284
    //   275: aload 12
    //   277: ldc_w 1334
    //   280: iconst_1
    //   281: invokevirtual 1338	android/os/Bundle:putBoolean	(Ljava/lang/String;Z)V
    //   284: invokestatic 552	android/accounts/AccountManagerService:clearCallingIdentity	()J
    //   287: lstore 13
    //   289: iload 9
    //   291: ifne +97 -> 388
    //   294: iload 11
    //   296: ifeq +92 -> 388
    //   299: aload_0
    //   300: aload 7
    //   302: aload_2
    //   303: aload_3
    //   304: invokevirtual 1342	android/accounts/AccountManagerService:readAuthTokenInternal	(Landroid/accounts/AccountManagerService$UserAccounts;Landroid/accounts/Account;Ljava/lang/String;)Ljava/lang/String;
    //   307: astore 16
    //   309: aload 16
    //   311: ifnull +77 -> 388
    //   314: new 373	android/os/Bundle
    //   317: dup
    //   318: invokespecial 1169	android/os/Bundle:<init>	()V
    //   321: astore 17
    //   323: aload 17
    //   325: ldc 33
    //   327: aload 16
    //   329: invokevirtual 1345	android/os/Bundle:putString	(Ljava/lang/String;Ljava/lang/String;)V
    //   332: aload 17
    //   334: ldc_w 1347
    //   337: aload_2
    //   338: getfield 321	android/accounts/Account:name	Ljava/lang/String;
    //   341: invokevirtual 1345	android/os/Bundle:putString	(Ljava/lang/String;Ljava/lang/String;)V
    //   344: aload 17
    //   346: ldc_w 1349
    //   349: aload_2
    //   350: getfield 323	android/accounts/Account:type	Ljava/lang/String;
    //   353: invokevirtual 1345	android/os/Bundle:putString	(Ljava/lang/String;Ljava/lang/String;)V
    //   356: aload_0
    //   357: aload_1
    //   358: aload 17
    //   360: invokespecial 1295	android/accounts/AccountManagerService:onResult	(Landroid/accounts/IAccountManagerResponse;Landroid/os/Bundle;)V
    //   363: lload 13
    //   365: invokestatic 582	android/accounts/AccountManagerService:restoreCallingIdentity	(J)V
    //   368: return
    //   369: iconst_0
    //   370: istore 9
    //   372: goto -161 -> 211
    //   375: iconst_0
    //   376: istore 11
    //   378: goto -143 -> 235
    //   381: aload 6
    //   383: astore 12
    //   385: goto -136 -> 249
    //   388: new 1351	android/accounts/AccountManagerService$4
    //   391: dup
    //   392: aload_0
    //   393: aload 7
    //   395: aload_1
    //   396: aload_2
    //   397: getfield 323	android/accounts/Account:type	Ljava/lang/String;
    //   400: iload 5
    //   402: iconst_0
    //   403: aload 12
    //   405: aload_2
    //   406: aload_3
    //   407: iload 4
    //   409: iload 11
    //   411: iload 10
    //   413: iload 9
    //   415: aload 7
    //   417: invokespecial 1354	android/accounts/AccountManagerService$4:<init>	(Landroid/accounts/AccountManagerService;Landroid/accounts/AccountManagerService$UserAccounts;Landroid/accounts/IAccountManagerResponse;Ljava/lang/String;ZZLandroid/os/Bundle;Landroid/accounts/Account;Ljava/lang/String;ZZIZLandroid/accounts/AccountManagerService$UserAccounts;)V
    //   420: invokevirtual 1355	android/accounts/AccountManagerService$4:bind	()V
    //   423: goto -60 -> 363
    //   426: astore 15
    //   428: lload 13
    //   430: invokestatic 582	android/accounts/AccountManagerService:restoreCallingIdentity	(J)V
    //   433: aload 15
    //   435: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	436	0	this	AccountManagerService
    //   0	436	1	paramIAccountManagerResponse	IAccountManagerResponse
    //   0	436	2	paramAccount	Account
    //   0	436	3	paramString	String
    //   0	436	4	paramBoolean1	boolean
    //   0	436	5	paramBoolean2	boolean
    //   0	436	6	paramBundle	Bundle
    //   164	252	7	localUserAccounts	UserAccounts
    //   187	8	8	localServiceInfo	RegisteredServicesCache.ServiceInfo
    //   209	205	9	bool1	boolean
    //   214	198	10	i	int
    //   233	177	11	bool2	boolean
    //   247	157	12	localBundle1	Bundle
    //   287	142	13	l	long
    //   426	8	15	localObject	Object
    //   307	21	16	str	String
    //   321	38	17	localBundle2	Bundle
    // Exception table:
    //   from	to	target	type
    //   299	309	426	finally
    //   314	363	426	finally
    //   388	423	426	finally
  }
  
  public void getAuthTokenLabel(IAccountManagerResponse paramIAccountManagerResponse, final String paramString1, final String paramString2)
    throws RemoteException
  {
    if (paramString1 == null) {
      throw new IllegalArgumentException("accountType is null");
    }
    if (paramString2 == null) {
      throw new IllegalArgumentException("authTokenType is null");
    }
    int i = getCallingUid();
    clearCallingIdentity();
    if (i != 1000) {
      throw new SecurityException("can only call from system");
    }
    UserAccounts localUserAccounts = getUserAccounts(UserHandle.getUserId(i));
    long l = clearCallingIdentity();
    try
    {
      new Session(localUserAccounts, paramIAccountManagerResponse, paramString1, false, false, paramString1)
      {
        public void onResult(Bundle paramAnonymousBundle)
        {
          if (paramAnonymousBundle != null)
          {
            String str = paramAnonymousBundle.getString("authTokenLabelKey");
            Bundle localBundle = new Bundle();
            localBundle.putString("authTokenLabelKey", str);
            super.onResult(localBundle);
            return;
          }
          super.onResult(paramAnonymousBundle);
        }
        
        public void run()
          throws RemoteException
        {
          this.mAuthenticator.getAuthTokenLabel(this, paramString2);
        }
        
        protected String toDebugString(long paramAnonymousLong)
        {
          return super.toDebugString(paramAnonymousLong) + ", getAuthTokenLabel" + ", " + paramString1 + ", authTokenType " + paramString2;
        }
      }.bind();
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public AuthenticatorDescription[] getAuthenticatorTypes()
  {
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", "getAuthenticatorTypes: caller's uid " + Binder.getCallingUid() + ", pid " + Binder.getCallingPid());
    }
    int i = UserHandle.getCallingUserId();
    long l = clearCallingIdentity();
    AuthenticatorDescription[] arrayOfAuthenticatorDescription;
    try
    {
      Collection localCollection = this.mAuthenticatorCache.getAllServices(i);
      arrayOfAuthenticatorDescription = new AuthenticatorDescription[localCollection.size()];
      int j = 0;
      Iterator localIterator = localCollection.iterator();
      while (localIterator.hasNext())
      {
        arrayOfAuthenticatorDescription[j] = ((AuthenticatorDescription)((RegisteredServicesCache.ServiceInfo)localIterator.next()).type);
        j++;
      }
    }
    finally
    {
      restoreCallingIdentity(l);
    }
    return arrayOfAuthenticatorDescription;
  }
  
  public String getPassword(Account paramAccount)
  {
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", "getPassword: " + paramAccount + ", caller's uid " + Binder.getCallingUid() + ", pid " + Binder.getCallingPid());
    }
    if (paramAccount == null) {
      throw new IllegalArgumentException("account is null");
    }
    checkAuthenticateAccountsPermission(paramAccount);
    UserAccounts localUserAccounts = getUserAccountsForCaller();
    long l = clearCallingIdentity();
    try
    {
      String str = readPasswordInternal(localUserAccounts, paramAccount);
      return str;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public AccountAndUser[] getRunningAccounts()
  {
    try
    {
      int[] arrayOfInt = ActivityManagerNative.getDefault().getRunningUserIds();
      return getAccounts(arrayOfInt);
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException(localRemoteException);
    }
  }
  
  protected UserAccounts getUserAccounts(int paramInt)
  {
    synchronized (this.mUsers)
    {
      UserAccounts localUserAccounts = (UserAccounts)this.mUsers.get(paramInt);
      if (localUserAccounts == null)
      {
        localUserAccounts = initUser(paramInt);
        this.mUsers.append(paramInt, localUserAccounts);
      }
      return localUserAccounts;
    }
  }
  
  public String getUserData(Account paramAccount, String paramString)
  {
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", "getUserData: " + paramAccount + ", key " + paramString + ", caller's uid " + Binder.getCallingUid() + ", pid " + Binder.getCallingPid());
    }
    if (paramAccount == null) {
      throw new IllegalArgumentException("account is null");
    }
    if (paramString == null) {
      throw new IllegalArgumentException("key is null");
    }
    checkAuthenticateAccountsPermission(paramAccount);
    UserAccounts localUserAccounts = getUserAccountsForCaller();
    long l = clearCallingIdentity();
    try
    {
      String str = readUserDataInternal(localUserAccounts, paramAccount, paramString);
      return str;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public void hasFeatures(IAccountManagerResponse paramIAccountManagerResponse, Account paramAccount, String[] paramArrayOfString)
  {
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", "hasFeatures: " + paramAccount + ", response " + paramIAccountManagerResponse + ", features " + stringArrayToString(paramArrayOfString) + ", caller's uid " + Binder.getCallingUid() + ", pid " + Binder.getCallingPid());
    }
    if (paramIAccountManagerResponse == null) {
      throw new IllegalArgumentException("response is null");
    }
    if (paramAccount == null) {
      throw new IllegalArgumentException("account is null");
    }
    if (paramArrayOfString == null) {
      throw new IllegalArgumentException("features is null");
    }
    checkReadAccountsPermission();
    UserAccounts localUserAccounts = getUserAccountsForCaller();
    long l = clearCallingIdentity();
    try
    {
      new TestFeaturesSession(localUserAccounts, paramIAccountManagerResponse, paramAccount, paramArrayOfString).bind();
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  protected void installNotification(int paramInt, Notification paramNotification, UserHandle paramUserHandle)
  {
    ((NotificationManager)this.mContext.getSystemService("notification")).notifyAsUser(null, paramInt, paramNotification, paramUserHandle);
  }
  
  /* Error */
  public void invalidateAuthToken(String paramString1, String paramString2)
  {
    // Byte code:
    //   0: ldc 89
    //   2: iconst_2
    //   3: invokestatic 441	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   6: ifeq +53 -> 59
    //   9: ldc 89
    //   11: new 333	java/lang/StringBuilder
    //   14: dup
    //   15: invokespecial 334	java/lang/StringBuilder:<init>	()V
    //   18: ldc_w 1427
    //   21: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: aload_1
    //   25: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   28: ldc_w 1134
    //   31: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   34: invokestatic 433	android/os/Binder:getCallingUid	()I
    //   37: invokevirtual 446	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   40: ldc_w 1136
    //   43: invokevirtual 340	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   46: invokestatic 1139	android/os/Binder:getCallingPid	()I
    //   49: invokevirtual 446	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   52: invokevirtual 349	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   55: invokestatic 451	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   58: pop
    //   59: aload_1
    //   60: ifnonnull +14 -> 74
    //   63: new 1141	java/lang/IllegalArgumentException
    //   66: dup
    //   67: ldc_w 1166
    //   70: invokespecial 1144	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   73: athrow
    //   74: aload_2
    //   75: ifnonnull +14 -> 89
    //   78: new 1141	java/lang/IllegalArgumentException
    //   81: dup
    //   82: ldc_w 1429
    //   85: invokespecial 1144	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   88: athrow
    //   89: aload_0
    //   90: invokespecial 1431	android/accounts/AccountManagerService:checkManageAccountsOrUseCredentialsPermissions	()V
    //   93: aload_0
    //   94: invokespecial 847	android/accounts/AccountManagerService:getUserAccountsForCaller	()Landroid/accounts/AccountManagerService$UserAccounts;
    //   97: astore_3
    //   98: invokestatic 552	android/accounts/AccountManagerService:clearCallingIdentity	()J
    //   101: lstore 4
    //   103: aload_3
    //   104: invokestatic 304	android/accounts/AccountManagerService$UserAccounts:access$200	(Landroid/accounts/AccountManagerService$UserAccounts;)Ljava/lang/Object;
    //   107: astore 7
    //   109: aload 7
    //   111: monitorenter
    //   112: aload_3
    //   113: invokestatic 308	android/accounts/AccountManagerService$UserAccounts:access$300	(Landroid/accounts/AccountManagerService$UserAccounts;)Landroid/accounts/AccountManagerService$DatabaseHelper;
    //   116: invokevirtual 314	android/accounts/AccountManagerService$DatabaseHelper:getWritableDatabase	()Landroid/database/sqlite/SQLiteDatabase;
    //   119: astore 9
    //   121: aload 9
    //   123: invokevirtual 319	android/database/sqlite/SQLiteDatabase:beginTransaction	()V
    //   126: aload_0
    //   127: aload_3
    //   128: aload 9
    //   130: aload_1
    //   131: aload_2
    //   132: invokespecial 1433	android/accounts/AccountManagerService:invalidateAuthTokenLocked	(Landroid/accounts/AccountManagerService$UserAccounts;Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;Ljava/lang/String;)V
    //   135: aload 9
    //   137: invokevirtual 406	android/database/sqlite/SQLiteDatabase:setTransactionSuccessful	()V
    //   140: aload 9
    //   142: invokevirtual 358	android/database/sqlite/SQLiteDatabase:endTransaction	()V
    //   145: aload 7
    //   147: monitorexit
    //   148: lload 4
    //   150: invokestatic 582	android/accounts/AccountManagerService:restoreCallingIdentity	(J)V
    //   153: return
    //   154: astore 10
    //   156: aload 9
    //   158: invokevirtual 358	android/database/sqlite/SQLiteDatabase:endTransaction	()V
    //   161: aload 10
    //   163: athrow
    //   164: astore 8
    //   166: aload 7
    //   168: monitorexit
    //   169: aload 8
    //   171: athrow
    //   172: astore 6
    //   174: lload 4
    //   176: invokestatic 582	android/accounts/AccountManagerService:restoreCallingIdentity	(J)V
    //   179: aload 6
    //   181: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	182	0	this	AccountManagerService
    //   0	182	1	paramString1	String
    //   0	182	2	paramString2	String
    //   97	31	3	localUserAccounts	UserAccounts
    //   101	74	4	l	long
    //   172	8	6	localObject1	Object
    //   164	6	8	localObject3	Object
    //   119	38	9	localSQLiteDatabase	SQLiteDatabase
    //   154	8	10	localObject4	Object
    // Exception table:
    //   from	to	target	type
    //   126	140	154	finally
    //   112	126	164	finally
    //   140	148	164	finally
    //   156	164	164	finally
    //   166	169	164	finally
    //   103	112	172	finally
    //   169	172	172	finally
  }
  
  public IBinder onBind(Intent paramIntent)
  {
    return asBinder();
  }
  
  public void onServiceChanged(AuthenticatorDescription paramAuthenticatorDescription, int paramInt, boolean paramBoolean)
  {
    Slog.d("AccountManagerService", "onServiceChanged() for userId " + paramInt);
    validateAccountsInternal(getUserAccounts(paramInt), false);
  }
  
  public String peekAuthToken(Account paramAccount, String paramString)
  {
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", "peekAuthToken: " + paramAccount + ", authTokenType " + paramString + ", caller's uid " + Binder.getCallingUid() + ", pid " + Binder.getCallingPid());
    }
    if (paramAccount == null) {
      throw new IllegalArgumentException("account is null");
    }
    if (paramString == null) {
      throw new IllegalArgumentException("authTokenType is null");
    }
    checkAuthenticateAccountsPermission(paramAccount);
    UserAccounts localUserAccounts = getUserAccountsForCaller();
    long l = clearCallingIdentity();
    try
    {
      String str = readAuthTokenInternal(localUserAccounts, paramAccount, paramString);
      return str;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  protected String readAuthTokenInternal(UserAccounts paramUserAccounts, Account paramAccount, String paramString)
  {
    synchronized (paramUserAccounts.cacheLock)
    {
      HashMap localHashMap = (HashMap)paramUserAccounts.authTokenCache.get(paramAccount);
      if (localHashMap == null)
      {
        localHashMap = readAuthTokensForAccountFromDatabaseLocked(paramUserAccounts.openHelper.getReadableDatabase(), paramAccount);
        paramUserAccounts.authTokenCache.put(paramAccount, localHashMap);
      }
      String str = (String)localHashMap.get(paramString);
      return str;
    }
  }
  
  /* Error */
  protected HashMap<String, String> readAuthTokensForAccountFromDatabaseLocked(SQLiteDatabase paramSQLiteDatabase, Account paramAccount)
  {
    // Byte code:
    //   0: new 715	java/util/HashMap
    //   3: dup
    //   4: invokespecial 1455	java/util/HashMap:<init>	()V
    //   7: astore_3
    //   8: getstatic 122	android/accounts/AccountManagerService:COLUMNS_AUTHTOKENS_TYPE_AND_AUTHTOKEN	[Ljava/lang/String;
    //   11: astore 4
    //   13: iconst_2
    //   14: anewarray 118	java/lang/String
    //   17: astore 5
    //   19: aload 5
    //   21: iconst_0
    //   22: aload_2
    //   23: getfield 321	android/accounts/Account:name	Ljava/lang/String;
    //   26: aastore
    //   27: aload 5
    //   29: iconst_1
    //   30: aload_2
    //   31: getfield 323	android/accounts/Account:type	Ljava/lang/String;
    //   34: aastore
    //   35: aload_1
    //   36: ldc 77
    //   38: aload 4
    //   40: ldc 70
    //   42: aload 5
    //   44: aconst_null
    //   45: aconst_null
    //   46: aconst_null
    //   47: invokevirtual 609	android/database/sqlite/SQLiteDatabase:query	(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   50: astore 6
    //   52: aload 6
    //   54: invokeinterface 614 1 0
    //   59: ifeq +39 -> 98
    //   62: aload_3
    //   63: aload 6
    //   65: iconst_0
    //   66: invokeinterface 616 2 0
    //   71: aload 6
    //   73: iconst_1
    //   74: invokeinterface 616 2 0
    //   79: invokevirtual 725	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   82: pop
    //   83: goto -31 -> 52
    //   86: astore 7
    //   88: aload 6
    //   90: invokeinterface 624 1 0
    //   95: aload 7
    //   97: athrow
    //   98: aload 6
    //   100: invokeinterface 624 1 0
    //   105: aload_3
    //   106: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	107	0	this	AccountManagerService
    //   0	107	1	paramSQLiteDatabase	SQLiteDatabase
    //   0	107	2	paramAccount	Account
    //   7	99	3	localHashMap	HashMap
    //   11	28	4	arrayOfString1	String[]
    //   17	26	5	arrayOfString2	String[]
    //   50	49	6	localCursor	Cursor
    //   86	10	7	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   52	83	86	finally
  }
  
  /* Error */
  protected HashMap<String, String> readUserDataForAccountFromDatabaseLocked(SQLiteDatabase paramSQLiteDatabase, Account paramAccount)
  {
    // Byte code:
    //   0: new 715	java/util/HashMap
    //   3: dup
    //   4: invokespecial 1455	java/util/HashMap:<init>	()V
    //   7: astore_3
    //   8: getstatic 124	android/accounts/AccountManagerService:COLUMNS_EXTRAS_KEY_AND_VALUE	[Ljava/lang/String;
    //   11: astore 4
    //   13: iconst_2
    //   14: anewarray 118	java/lang/String
    //   17: astore 5
    //   19: aload 5
    //   21: iconst_0
    //   22: aload_2
    //   23: getfield 321	android/accounts/Account:name	Ljava/lang/String;
    //   26: aastore
    //   27: aload 5
    //   29: iconst_1
    //   30: aload_2
    //   31: getfield 323	android/accounts/Account:type	Ljava/lang/String;
    //   34: aastore
    //   35: aload_1
    //   36: ldc 80
    //   38: aload 4
    //   40: ldc 70
    //   42: aload 5
    //   44: aconst_null
    //   45: aconst_null
    //   46: aconst_null
    //   47: invokevirtual 609	android/database/sqlite/SQLiteDatabase:query	(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   50: astore 6
    //   52: aload 6
    //   54: invokeinterface 614 1 0
    //   59: ifeq +39 -> 98
    //   62: aload_3
    //   63: aload 6
    //   65: iconst_0
    //   66: invokeinterface 616 2 0
    //   71: aload 6
    //   73: iconst_1
    //   74: invokeinterface 616 2 0
    //   79: invokevirtual 725	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   82: pop
    //   83: goto -31 -> 52
    //   86: astore 7
    //   88: aload 6
    //   90: invokeinterface 624 1 0
    //   95: aload 7
    //   97: athrow
    //   98: aload 6
    //   100: invokeinterface 624 1 0
    //   105: aload_3
    //   106: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	107	0	this	AccountManagerService
    //   0	107	1	paramSQLiteDatabase	SQLiteDatabase
    //   0	107	2	paramAccount	Account
    //   7	99	3	localHashMap	HashMap
    //   11	28	4	arrayOfString1	String[]
    //   17	26	5	arrayOfString2	String[]
    //   50	49	6	localCursor	Cursor
    //   86	10	7	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   52	83	86	finally
  }
  
  protected String readUserDataInternal(UserAccounts paramUserAccounts, Account paramAccount, String paramString)
  {
    synchronized (paramUserAccounts.cacheLock)
    {
      HashMap localHashMap = (HashMap)paramUserAccounts.userDataCache.get(paramAccount);
      if (localHashMap == null)
      {
        localHashMap = readUserDataForAccountFromDatabaseLocked(paramUserAccounts.openHelper.getReadableDatabase(), paramAccount);
        paramUserAccounts.userDataCache.put(paramAccount, localHashMap);
      }
      String str = (String)localHashMap.get(paramString);
      return str;
    }
  }
  
  public void removeAccount(IAccountManagerResponse paramIAccountManagerResponse, Account paramAccount)
  {
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", "removeAccount: " + paramAccount + ", response " + paramIAccountManagerResponse + ", caller's uid " + Binder.getCallingUid() + ", pid " + Binder.getCallingPid());
    }
    if (paramIAccountManagerResponse == null) {
      throw new IllegalArgumentException("response is null");
    }
    if (paramAccount == null) {
      throw new IllegalArgumentException("account is null");
    }
    checkManageAccountsPermission();
    UserHandle localUserHandle = Binder.getCallingUserHandle();
    UserAccounts localUserAccounts = getUserAccountsForCaller();
    long l = clearCallingIdentity();
    cancelNotification(getSigninRequiredNotificationId(localUserAccounts, paramAccount).intValue(), localUserHandle);
    synchronized (localUserAccounts.credentialsPermissionNotificationIds)
    {
      Iterator localIterator = localUserAccounts.credentialsPermissionNotificationIds.keySet().iterator();
      while (localIterator.hasNext())
      {
        Pair localPair = (Pair)localIterator.next();
        if (paramAccount.equals(((Pair)localPair.first).first)) {
          cancelNotification(((Integer)localUserAccounts.credentialsPermissionNotificationIds.get(localPair)).intValue(), localUserHandle);
        }
      }
    }
    try
    {
      new RemoveAccountSession(localUserAccounts, paramIAccountManagerResponse, paramAccount).bind();
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  protected void removeAccountInternal(Account paramAccount)
  {
    removeAccountInternal(getUserAccountsForCaller(), paramAccount);
  }
  
  public void setAuthToken(Account paramAccount, String paramString1, String paramString2)
  {
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", "setAuthToken: " + paramAccount + ", authTokenType " + paramString1 + ", caller's uid " + Binder.getCallingUid() + ", pid " + Binder.getCallingPid());
    }
    if (paramAccount == null) {
      throw new IllegalArgumentException("account is null");
    }
    if (paramString1 == null) {
      throw new IllegalArgumentException("authTokenType is null");
    }
    checkAuthenticateAccountsPermission(paramAccount);
    UserAccounts localUserAccounts = getUserAccountsForCaller();
    long l = clearCallingIdentity();
    try
    {
      saveAuthTokenToDatabase(localUserAccounts, paramAccount, paramString1, paramString2);
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public void setPassword(Account paramAccount, String paramString)
  {
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", "setAuthToken: " + paramAccount + ", caller's uid " + Binder.getCallingUid() + ", pid " + Binder.getCallingPid());
    }
    if (paramAccount == null) {
      throw new IllegalArgumentException("account is null");
    }
    checkAuthenticateAccountsPermission(paramAccount);
    UserAccounts localUserAccounts = getUserAccountsForCaller();
    long l = clearCallingIdentity();
    try
    {
      setPasswordInternal(localUserAccounts, paramAccount, paramString);
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public void setUserData(Account paramAccount, String paramString1, String paramString2)
  {
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", "setUserData: " + paramAccount + ", key " + paramString1 + ", caller's uid " + Binder.getCallingUid() + ", pid " + Binder.getCallingPid());
    }
    if (paramString1 == null) {
      throw new IllegalArgumentException("key is null");
    }
    if (paramAccount == null) {
      throw new IllegalArgumentException("account is null");
    }
    checkAuthenticateAccountsPermission(paramAccount);
    UserAccounts localUserAccounts = getUserAccountsForCaller();
    long l = clearCallingIdentity();
    try
    {
      setUserdataInternal(localUserAccounts, paramAccount, paramString1, paramString2);
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public void systemReady() {}
  
  public void updateAppPermission(Account paramAccount, String paramString, int paramInt, boolean paramBoolean)
    throws RemoteException
  {
    if (getCallingUid() != 1000) {
      throw new SecurityException();
    }
    if (paramBoolean)
    {
      grantAppPermission(paramAccount, paramString, paramInt);
      return;
    }
    revokeAppPermission(paramAccount, paramString, paramInt);
  }
  
  public void updateCredentials(IAccountManagerResponse paramIAccountManagerResponse, final Account paramAccount, final String paramString, boolean paramBoolean, final Bundle paramBundle)
  {
    if (Log.isLoggable("AccountManagerService", 2)) {
      Log.v("AccountManagerService", "updateCredentials: " + paramAccount + ", response " + paramIAccountManagerResponse + ", authTokenType " + paramString + ", expectActivityLaunch " + paramBoolean + ", caller's uid " + Binder.getCallingUid() + ", pid " + Binder.getCallingPid());
    }
    if (paramIAccountManagerResponse == null) {
      throw new IllegalArgumentException("response is null");
    }
    if (paramAccount == null) {
      throw new IllegalArgumentException("account is null");
    }
    if (paramString == null) {
      throw new IllegalArgumentException("authTokenType is null");
    }
    checkManageAccountsPermission();
    UserAccounts localUserAccounts = getUserAccountsForCaller();
    long l = clearCallingIdentity();
    try
    {
      new Session(localUserAccounts, paramIAccountManagerResponse, paramAccount.type, paramBoolean, true, paramAccount)
      {
        public void run()
          throws RemoteException
        {
          this.mAuthenticator.updateCredentials(this, paramAccount, paramString, paramBundle);
        }
        
        protected String toDebugString(long paramAnonymousLong)
        {
          if (paramBundle != null) {
            paramBundle.keySet();
          }
          return super.toDebugString(paramAnonymousLong) + ", updateCredentials" + ", " + paramAccount + ", authTokenType " + paramString + ", loginOptions " + paramBundle;
        }
      }.bind();
      return;
    }
    finally
    {
      restoreCallingIdentity(l);
    }
  }
  
  public void validateAccounts(int paramInt)
  {
    validateAccountsInternal(getUserAccounts(paramInt), true);
  }
  
  protected void writeAuthTokenIntoCacheLocked(UserAccounts paramUserAccounts, SQLiteDatabase paramSQLiteDatabase, Account paramAccount, String paramString1, String paramString2)
  {
    HashMap localHashMap = (HashMap)paramUserAccounts.authTokenCache.get(paramAccount);
    if (localHashMap == null)
    {
      localHashMap = readAuthTokensForAccountFromDatabaseLocked(paramSQLiteDatabase, paramAccount);
      paramUserAccounts.authTokenCache.put(paramAccount, localHashMap);
    }
    if (paramString2 == null)
    {
      localHashMap.remove(paramString1);
      return;
    }
    localHashMap.put(paramString1, paramString2);
  }
  
  protected void writeUserDataIntoCacheLocked(UserAccounts paramUserAccounts, SQLiteDatabase paramSQLiteDatabase, Account paramAccount, String paramString1, String paramString2)
  {
    HashMap localHashMap = (HashMap)paramUserAccounts.userDataCache.get(paramAccount);
    if (localHashMap == null)
    {
      localHashMap = readUserDataForAccountFromDatabaseLocked(paramSQLiteDatabase, paramAccount);
      paramUserAccounts.userDataCache.put(paramAccount, localHashMap);
    }
    if (paramString2 == null)
    {
      localHashMap.remove(paramString1);
      return;
    }
    localHashMap.put(paramString1, paramString2);
  }
  
  static class DatabaseHelper
    extends SQLiteOpenHelper
  {
    public DatabaseHelper(Context paramContext, int paramInt)
    {
      super(AccountManagerService.getDatabaseName(paramInt), null, 4);
    }
    
    private void createAccountsDeletionTrigger(SQLiteDatabase paramSQLiteDatabase)
    {
      paramSQLiteDatabase.execSQL(" CREATE TRIGGER accountsDelete DELETE ON accounts BEGIN   DELETE FROM authtokens     WHERE accounts_id=OLD._id ;   DELETE FROM extras     WHERE accounts_id=OLD._id ;   DELETE FROM grants     WHERE accounts_id=OLD._id ; END");
    }
    
    private void createGrantsTable(SQLiteDatabase paramSQLiteDatabase)
    {
      paramSQLiteDatabase.execSQL("CREATE TABLE grants (  accounts_id INTEGER NOT NULL, auth_token_type STRING NOT NULL,  uid INTEGER NOT NULL,  UNIQUE (accounts_id,auth_token_type,uid))");
    }
    
    public void onCreate(SQLiteDatabase paramSQLiteDatabase)
    {
      paramSQLiteDatabase.execSQL("CREATE TABLE accounts ( _id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, type TEXT NOT NULL, password TEXT, UNIQUE(name,type))");
      paramSQLiteDatabase.execSQL("CREATE TABLE authtokens (  _id INTEGER PRIMARY KEY AUTOINCREMENT,  accounts_id INTEGER NOT NULL, type TEXT NOT NULL,  authtoken TEXT,  UNIQUE (accounts_id,type))");
      createGrantsTable(paramSQLiteDatabase);
      paramSQLiteDatabase.execSQL("CREATE TABLE extras ( _id INTEGER PRIMARY KEY AUTOINCREMENT, accounts_id INTEGER, key TEXT NOT NULL, value TEXT, UNIQUE(accounts_id,key))");
      paramSQLiteDatabase.execSQL("CREATE TABLE meta ( key TEXT PRIMARY KEY NOT NULL, value TEXT)");
      createAccountsDeletionTrigger(paramSQLiteDatabase);
    }
    
    public void onOpen(SQLiteDatabase paramSQLiteDatabase)
    {
      if (Log.isLoggable("AccountManagerService", 2)) {
        Log.v("AccountManagerService", "opened database accounts.db");
      }
    }
    
    public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2)
    {
      Log.e("AccountManagerService", "upgrade from version " + paramInt1 + " to version " + paramInt2);
      if (paramInt1 == 1) {
        paramInt1++;
      }
      if (paramInt1 == 2)
      {
        createGrantsTable(paramSQLiteDatabase);
        paramSQLiteDatabase.execSQL("DROP TRIGGER accountsDelete");
        createAccountsDeletionTrigger(paramSQLiteDatabase);
        paramInt1++;
      }
      if (paramInt1 == 3)
      {
        paramSQLiteDatabase.execSQL("UPDATE accounts SET type = 'com.google' WHERE type == 'com.google.GAIA'");
        (paramInt1 + 1);
      }
    }
  }
  
  private class GetAccountsByTypeAndFeatureSession
    extends AccountManagerService.Session
  {
    private volatile Account[] mAccountsOfType = null;
    private volatile ArrayList<Account> mAccountsWithFeatures = null;
    private volatile int mCurrentAccount = 0;
    private final String[] mFeatures;
    
    public GetAccountsByTypeAndFeatureSession(AccountManagerService.UserAccounts paramUserAccounts, IAccountManagerResponse paramIAccountManagerResponse, String paramString, String[] paramArrayOfString)
    {
      super(paramUserAccounts, paramIAccountManagerResponse, paramString, false, true);
      this.mFeatures = paramArrayOfString;
    }
    
    public void checkAccount()
    {
      if (this.mCurrentAccount >= this.mAccountsOfType.length) {
        sendResult();
      }
      IAccountAuthenticator localIAccountAuthenticator;
      do
      {
        return;
        localIAccountAuthenticator = this.mAuthenticator;
        if (localIAccountAuthenticator != null) {
          break;
        }
      } while (!Log.isLoggable("AccountManagerService", 2));
      Log.v("AccountManagerService", "checkAccount: aborting session since we are no longer connected to the authenticator, " + toDebugString());
      return;
      try
      {
        localIAccountAuthenticator.hasFeatures(this, this.mAccountsOfType[this.mCurrentAccount], this.mFeatures);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        onError(1, "remote exception");
      }
    }
    
    public void onResult(Bundle paramBundle)
    {
      this.mNumResults = (1 + this.mNumResults);
      if (paramBundle == null)
      {
        onError(5, "null bundle");
        return;
      }
      if (paramBundle.getBoolean("booleanResult", false)) {
        this.mAccountsWithFeatures.add(this.mAccountsOfType[this.mCurrentAccount]);
      }
      this.mCurrentAccount = (1 + this.mCurrentAccount);
      checkAccount();
    }
    
    public void run()
      throws RemoteException
    {
      synchronized (AccountManagerService.UserAccounts.access$200(this.mAccounts))
      {
        this.mAccountsOfType = AccountManagerService.this.getAccountsFromCacheLocked(this.mAccounts, this.mAccountType);
        this.mAccountsWithFeatures = new ArrayList(this.mAccountsOfType.length);
        this.mCurrentAccount = 0;
        checkAccount();
        return;
      }
    }
    
    public void sendResult()
    {
      IAccountManagerResponse localIAccountManagerResponse = getResponseAndClose();
      if (localIAccountManagerResponse != null) {}
      try
      {
        Account[] arrayOfAccount = new Account[this.mAccountsWithFeatures.size()];
        for (int i = 0; i < arrayOfAccount.length; i++) {
          arrayOfAccount[i] = ((Account)this.mAccountsWithFeatures.get(i));
        }
        if (Log.isLoggable("AccountManagerService", 2)) {
          Log.v("AccountManagerService", getClass().getSimpleName() + " calling onResult() on response " + localIAccountManagerResponse);
        }
        Bundle localBundle = new Bundle();
        localBundle.putParcelableArray("accounts", arrayOfAccount);
        localIAccountManagerResponse.onResult(localBundle);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        while (!Log.isLoggable("AccountManagerService", 2)) {}
        Log.v("AccountManagerService", "failure while notifying response", localRemoteException);
      }
    }
    
    protected String toDebugString(long paramLong)
    {
      StringBuilder localStringBuilder = new StringBuilder().append(super.toDebugString(paramLong)).append(", getAccountsByTypeAndFeatures").append(", ");
      if (this.mFeatures != null) {}
      for (String str = TextUtils.join(",", this.mFeatures);; str = null) {
        return str;
      }
    }
  }
  
  private class MessageHandler
    extends Handler
  {
    MessageHandler(Looper paramLooper)
    {
      super();
    }
    
    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default: 
        throw new IllegalStateException("unhandled message: " + paramMessage.what);
      }
      ((AccountManagerService.Session)paramMessage.obj).onTimedOut();
    }
  }
  
  private class RemoveAccountSession
    extends AccountManagerService.Session
  {
    final Account mAccount;
    
    public RemoveAccountSession(AccountManagerService.UserAccounts paramUserAccounts, IAccountManagerResponse paramIAccountManagerResponse, Account paramAccount)
    {
      super(paramUserAccounts, paramIAccountManagerResponse, paramAccount.type, false, true);
      this.mAccount = paramAccount;
    }
    
    public void onResult(Bundle paramBundle)
    {
      IAccountManagerResponse localIAccountManagerResponse;
      Bundle localBundle;
      if ((paramBundle != null) && (paramBundle.containsKey("booleanResult")) && (!paramBundle.containsKey("intent")))
      {
        boolean bool = paramBundle.getBoolean("booleanResult");
        if (bool) {
          AccountManagerService.this.removeAccountInternal(this.mAccounts, this.mAccount);
        }
        localIAccountManagerResponse = getResponseAndClose();
        if (localIAccountManagerResponse != null)
        {
          if (Log.isLoggable("AccountManagerService", 2)) {
            Log.v("AccountManagerService", getClass().getSimpleName() + " calling onResult() on response " + localIAccountManagerResponse);
          }
          localBundle = new Bundle();
          localBundle.putBoolean("booleanResult", bool);
        }
      }
      try
      {
        localIAccountManagerResponse.onResult(localBundle);
        super.onResult(paramBundle);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        for (;;) {}
      }
    }
    
    public void run()
      throws RemoteException
    {
      this.mAuthenticator.getAccountRemovalAllowed(this, this.mAccount);
    }
    
    protected String toDebugString(long paramLong)
    {
      return super.toDebugString(paramLong) + ", removeAccount" + ", account " + this.mAccount;
    }
  }
  
  private abstract class Session
    extends IAccountAuthenticatorResponse.Stub
    implements IBinder.DeathRecipient, ServiceConnection
  {
    final String mAccountType;
    protected final AccountManagerService.UserAccounts mAccounts;
    IAccountAuthenticator mAuthenticator = null;
    final long mCreationTime;
    final boolean mExpectActivityLaunch;
    private int mNumErrors = 0;
    private int mNumRequestContinued = 0;
    public int mNumResults = 0;
    IAccountManagerResponse mResponse;
    private final boolean mStripAuthTokenFromResult;
    
    public Session(AccountManagerService.UserAccounts paramUserAccounts, IAccountManagerResponse paramIAccountManagerResponse, String paramString, boolean paramBoolean1, boolean paramBoolean2)
    {
      if (paramIAccountManagerResponse == null) {
        throw new IllegalArgumentException("response is null");
      }
      if (paramString == null) {
        throw new IllegalArgumentException("accountType is null");
      }
      this.mAccounts = paramUserAccounts;
      this.mStripAuthTokenFromResult = paramBoolean2;
      this.mResponse = paramIAccountManagerResponse;
      this.mAccountType = paramString;
      this.mExpectActivityLaunch = paramBoolean1;
      this.mCreationTime = SystemClock.elapsedRealtime();
      synchronized (AccountManagerService.this.mSessions)
      {
        AccountManagerService.this.mSessions.put(toString(), this);
      }
    }
    
    private boolean bindToAuthenticator(String paramString)
    {
      RegisteredServicesCache.ServiceInfo localServiceInfo = AccountManagerService.this.mAuthenticatorCache.getServiceInfo(AuthenticatorDescription.newKey(paramString), AccountManagerService.UserAccounts.access$400(this.mAccounts));
      if (localServiceInfo == null) {
        if (Log.isLoggable("AccountManagerService", 2)) {
          Log.v("AccountManagerService", "there is no authenticator for " + paramString + ", bailing out");
        }
      }
      do
      {
        return false;
        Intent localIntent = new Intent();
        localIntent.setAction("android.accounts.AccountAuthenticator");
        localIntent.setComponent(localServiceInfo.componentName);
        if (Log.isLoggable("AccountManagerService", 2)) {
          Log.v("AccountManagerService", "performing bindService to " + localServiceInfo.componentName);
        }
        if (AccountManagerService.this.mContext.bindService(localIntent, this, 1, AccountManagerService.UserAccounts.access$400(this.mAccounts))) {
          break;
        }
      } while (!Log.isLoggable("AccountManagerService", 2));
      Log.v("AccountManagerService", "bindService to " + localServiceInfo.componentName + " failed");
      return false;
      return true;
    }
    
    private void close()
    {
      synchronized (AccountManagerService.this.mSessions)
      {
        if (AccountManagerService.this.mSessions.remove(toString()) == null) {
          return;
        }
        if (this.mResponse != null)
        {
          this.mResponse.asBinder().unlinkToDeath(this, 0);
          this.mResponse = null;
        }
        cancelTimeout();
        unbind();
        return;
      }
    }
    
    private void unbind()
    {
      if (this.mAuthenticator != null)
      {
        this.mAuthenticator = null;
        AccountManagerService.this.mContext.unbindService(this);
      }
    }
    
    void bind()
    {
      if (Log.isLoggable("AccountManagerService", 2)) {
        Log.v("AccountManagerService", "initiating bind to authenticator type " + this.mAccountType);
      }
      if (!bindToAuthenticator(this.mAccountType))
      {
        Log.d("AccountManagerService", "bind attempt failed for " + toDebugString());
        onError(1, "bind failure");
      }
    }
    
    public void binderDied()
    {
      this.mResponse = null;
      close();
    }
    
    public void cancelTimeout()
    {
      AccountManagerService.this.mMessageHandler.removeMessages(3, this);
    }
    
    IAccountManagerResponse getResponseAndClose()
    {
      if (this.mResponse == null) {
        return null;
      }
      IAccountManagerResponse localIAccountManagerResponse = this.mResponse;
      close();
      return localIAccountManagerResponse;
    }
    
    public void onError(int paramInt, String paramString)
    {
      this.mNumErrors = (1 + this.mNumErrors);
      IAccountManagerResponse localIAccountManagerResponse = getResponseAndClose();
      if (localIAccountManagerResponse != null) {
        if (Log.isLoggable("AccountManagerService", 2)) {
          Log.v("AccountManagerService", getClass().getSimpleName() + " calling onError() on response " + localIAccountManagerResponse);
        }
      }
      while (!Log.isLoggable("AccountManagerService", 2)) {
        try
        {
          localIAccountManagerResponse.onError(paramInt, paramString);
          return;
        }
        catch (RemoteException localRemoteException)
        {
          while (!Log.isLoggable("AccountManagerService", 2)) {}
          Log.v("AccountManagerService", "Session.onError: caught RemoteException while responding", localRemoteException);
          return;
        }
      }
      Log.v("AccountManagerService", "Session.onError: already closed");
    }
    
    public void onRequestContinued()
    {
      this.mNumRequestContinued = (1 + this.mNumRequestContinued);
    }
    
    public void onResult(Bundle paramBundle)
    {
      this.mNumResults = (1 + this.mNumResults);
      if ((paramBundle != null) && (!TextUtils.isEmpty(paramBundle.getString("authtoken"))))
      {
        String str1 = paramBundle.getString("authAccount");
        String str2 = paramBundle.getString("accountType");
        if ((!TextUtils.isEmpty(str1)) && (!TextUtils.isEmpty(str2)))
        {
          Account localAccount = new Account(str1, str2);
          AccountManagerService.this.cancelNotification(AccountManagerService.this.getSigninRequiredNotificationId(this.mAccounts, localAccount).intValue(), new UserHandle(AccountManagerService.UserAccounts.access$400(this.mAccounts)));
        }
      }
      if ((this.mExpectActivityLaunch) && (paramBundle != null) && (paramBundle.containsKey("intent"))) {}
      for (IAccountManagerResponse localIAccountManagerResponse = this.mResponse; (localIAccountManagerResponse == null) || (paramBundle == null); localIAccountManagerResponse = getResponseAndClose()) {
        try
        {
          if (Log.isLoggable("AccountManagerService", 2)) {
            Log.v("AccountManagerService", getClass().getSimpleName() + " calling onError() on response " + localIAccountManagerResponse);
          }
          localIAccountManagerResponse.onError(5, "null bundle returned");
          return;
        }
        catch (RemoteException localRemoteException)
        {
          while (!Log.isLoggable("AccountManagerService", 2)) {}
          Log.v("AccountManagerService", "failure while notifying response", localRemoteException);
        }
      }
      if (this.mStripAuthTokenFromResult) {
        paramBundle.remove("authtoken");
      }
      if (Log.isLoggable("AccountManagerService", 2)) {
        Log.v("AccountManagerService", getClass().getSimpleName() + " calling onResult() on response " + localIAccountManagerResponse);
      }
      localIAccountManagerResponse.onResult(paramBundle);
      return;
    }
    
    public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
    {
      this.mAuthenticator = IAccountAuthenticator.Stub.asInterface(paramIBinder);
      try
      {
        run();
        return;
      }
      catch (RemoteException localRemoteException)
      {
        onError(1, "remote exception");
      }
    }
    
    public void onServiceDisconnected(ComponentName paramComponentName)
    {
      this.mAuthenticator = null;
      IAccountManagerResponse localIAccountManagerResponse = getResponseAndClose();
      if (localIAccountManagerResponse != null) {}
      try
      {
        localIAccountManagerResponse.onError(1, "disconnected");
        return;
      }
      catch (RemoteException localRemoteException)
      {
        while (!Log.isLoggable("AccountManagerService", 2)) {}
        Log.v("AccountManagerService", "Session.onServiceDisconnected: caught RemoteException while responding", localRemoteException);
      }
    }
    
    public void onTimedOut()
    {
      IAccountManagerResponse localIAccountManagerResponse = getResponseAndClose();
      if (localIAccountManagerResponse != null) {}
      try
      {
        localIAccountManagerResponse.onError(1, "timeout");
        return;
      }
      catch (RemoteException localRemoteException)
      {
        while (!Log.isLoggable("AccountManagerService", 2)) {}
        Log.v("AccountManagerService", "Session.onTimedOut: caught RemoteException while responding", localRemoteException);
      }
    }
    
    public abstract void run()
      throws RemoteException;
    
    public void scheduleTimeout()
    {
      AccountManagerService.this.mMessageHandler.sendMessageDelayed(AccountManagerService.this.mMessageHandler.obtainMessage(3, this), 60000L);
    }
    
    protected String toDebugString()
    {
      return toDebugString(SystemClock.elapsedRealtime());
    }
    
    protected String toDebugString(long paramLong)
    {
      StringBuilder localStringBuilder = new StringBuilder().append("Session: expectLaunch ").append(this.mExpectActivityLaunch).append(", connected ");
      if (this.mAuthenticator != null) {}
      for (boolean bool = true;; bool = false) {
        return bool + ", stats (" + this.mNumResults + "/" + this.mNumRequestContinued + "/" + this.mNumErrors + ")" + ", lifetime " + (paramLong - this.mCreationTime) / 1000.0D;
      }
    }
  }
  
  private class TestFeaturesSession
    extends AccountManagerService.Session
  {
    private final Account mAccount;
    private final String[] mFeatures;
    
    public TestFeaturesSession(AccountManagerService.UserAccounts paramUserAccounts, IAccountManagerResponse paramIAccountManagerResponse, Account paramAccount, String[] paramArrayOfString)
    {
      super(paramUserAccounts, paramIAccountManagerResponse, paramAccount.type, false, true);
      this.mFeatures = paramArrayOfString;
      this.mAccount = paramAccount;
    }
    
    public void onResult(Bundle paramBundle)
    {
      IAccountManagerResponse localIAccountManagerResponse = getResponseAndClose();
      if (localIAccountManagerResponse != null)
      {
        if (paramBundle == null) {}
        try
        {
          localIAccountManagerResponse.onError(5, "null bundle");
          return;
        }
        catch (RemoteException localRemoteException)
        {
          Bundle localBundle;
          if (!Log.isLoggable("AccountManagerService", 2)) {
            return;
          }
          Log.v("AccountManagerService", "failure while notifying response", localRemoteException);
        }
        if (Log.isLoggable("AccountManagerService", 2)) {
          Log.v("AccountManagerService", getClass().getSimpleName() + " calling onResult() on response " + localIAccountManagerResponse);
        }
        localBundle = new Bundle();
        localBundle.putBoolean("booleanResult", paramBundle.getBoolean("booleanResult", false));
        localIAccountManagerResponse.onResult(localBundle);
        return;
      }
    }
    
    public void run()
      throws RemoteException
    {
      try
      {
        this.mAuthenticator.hasFeatures(this, this.mAccount, this.mFeatures);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        onError(1, "remote exception");
      }
    }
    
    protected String toDebugString(long paramLong)
    {
      StringBuilder localStringBuilder = new StringBuilder().append(super.toDebugString(paramLong)).append(", hasFeatures").append(", ").append(this.mAccount).append(", ");
      if (this.mFeatures != null) {}
      for (String str = TextUtils.join(",", this.mFeatures);; str = null) {
        return str;
      }
    }
  }
  
  static class UserAccounts
  {
    private final HashMap<String, Account[]> accountCache = new LinkedHashMap();
    private HashMap<Account, HashMap<String, String>> authTokenCache = new HashMap();
    private final Object cacheLock = new Object();
    private final HashMap<Pair<Pair<Account, String>, Integer>, Integer> credentialsPermissionNotificationIds = new HashMap();
    private final AccountManagerService.DatabaseHelper openHelper;
    private final HashMap<Account, Integer> signinRequiredNotificationIds = new HashMap();
    private HashMap<Account, HashMap<String, String>> userDataCache = new HashMap();
    private final int userId;
    
    UserAccounts(Context paramContext, int paramInt)
    {
      this.userId = paramInt;
      synchronized (this.cacheLock)
      {
        this.openHelper = new AccountManagerService.DatabaseHelper(paramContext, paramInt);
        return;
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\accounts\AccountManagerService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
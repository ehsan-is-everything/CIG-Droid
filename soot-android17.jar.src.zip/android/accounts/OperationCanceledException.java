package android.accounts;

public class OperationCanceledException
  extends AccountsException
{
  public OperationCanceledException() {}
  
  public OperationCanceledException(String paramString)
  {
    super(paramString);
  }
  
  public OperationCanceledException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
  
  public OperationCanceledException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\accounts\OperationCanceledException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
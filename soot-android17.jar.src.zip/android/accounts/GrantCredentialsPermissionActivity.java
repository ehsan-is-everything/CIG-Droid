package android.accounts;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources.NotFoundException;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import java.io.IOException;

public class GrantCredentialsPermissionActivity
  extends Activity
  implements View.OnClickListener
{
  public static final String EXTRAS_ACCOUNT = "account";
  public static final String EXTRAS_ACCOUNT_TYPE_LABEL = "accountTypeLabel";
  public static final String EXTRAS_AUTH_TOKEN_LABEL = "authTokenLabel";
  public static final String EXTRAS_AUTH_TOKEN_TYPE = "authTokenType";
  public static final String EXTRAS_PACKAGES = "application";
  public static final String EXTRAS_REQUESTING_UID = "uid";
  public static final String EXTRAS_RESPONSE = "response";
  private Account mAccount;
  private String mAuthTokenType;
  protected LayoutInflater mInflater;
  private Bundle mResultBundle = null;
  private int mUid;
  
  private String getAccountLabel(Account paramAccount)
  {
    AuthenticatorDescription[] arrayOfAuthenticatorDescription = AccountManager.get(this).getAuthenticatorTypes();
    int i = 0;
    int j = arrayOfAuthenticatorDescription.length;
    while (i < j)
    {
      AuthenticatorDescription localAuthenticatorDescription = arrayOfAuthenticatorDescription[i];
      if (localAuthenticatorDescription.type.equals(paramAccount.type)) {
        try
        {
          String str = createPackageContext(localAuthenticatorDescription.packageName, 0).getString(localAuthenticatorDescription.labelId);
          return str;
        }
        catch (PackageManager.NameNotFoundException localNameNotFoundException)
        {
          return paramAccount.type;
        }
        catch (Resources.NotFoundException localNotFoundException)
        {
          return paramAccount.type;
        }
      }
      i++;
    }
    return paramAccount.type;
  }
  
  private View newPackageView(String paramString)
  {
    View localView = this.mInflater.inflate(17367193, null);
    ((TextView)localView.findViewById(16909115)).setText(paramString);
    return localView;
  }
  
  public void finish()
  {
    AccountAuthenticatorResponse localAccountAuthenticatorResponse = (AccountAuthenticatorResponse)getIntent().getParcelableExtra("response");
    if (localAccountAuthenticatorResponse != null)
    {
      if (this.mResultBundle == null) {
        break label37;
      }
      localAccountAuthenticatorResponse.onResult(this.mResultBundle);
    }
    for (;;)
    {
      super.finish();
      return;
      label37:
      localAccountAuthenticatorResponse.onError(4, "canceled");
    }
  }
  
  public void onClick(View paramView)
  {
    switch (paramView.getId())
    {
    }
    for (;;)
    {
      finish();
      return;
      AccountManager.get(this).updateAppPermission(this.mAccount, this.mAuthTokenType, this.mUid, true);
      Intent localIntent = new Intent();
      localIntent.putExtra("retry", true);
      setResult(-1, localIntent);
      setAccountAuthenticatorResult(localIntent.getExtras());
      continue;
      AccountManager.get(this).updateAppPermission(this.mAccount, this.mAuthTokenType, this.mUid, false);
      setResult(0);
    }
  }
  
  /* Error */
  protected void onCreate(Bundle paramBundle)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial 181	android/app/Activity:onCreate	(Landroid/os/Bundle;)V
    //   5: aload_0
    //   6: ldc -74
    //   8: invokevirtual 185	android/accounts/GrantCredentialsPermissionActivity:setContentView	(I)V
    //   11: aload_0
    //   12: ldc -70
    //   14: invokevirtual 189	android/accounts/GrantCredentialsPermissionActivity:setTitle	(I)V
    //   17: aload_0
    //   18: aload_0
    //   19: ldc -65
    //   21: invokevirtual 195	android/accounts/GrantCredentialsPermissionActivity:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   24: checkcast 96	android/view/LayoutInflater
    //   27: putfield 93	android/accounts/GrantCredentialsPermissionActivity:mInflater	Landroid/view/LayoutInflater;
    //   30: aload_0
    //   31: invokevirtual 118	android/accounts/GrantCredentialsPermissionActivity:getIntent	()Landroid/content/Intent;
    //   34: invokevirtual 170	android/content/Intent:getExtras	()Landroid/os/Bundle;
    //   37: astore_2
    //   38: aload_2
    //   39: ifnonnull +13 -> 52
    //   42: aload_0
    //   43: iconst_0
    //   44: invokevirtual 176	android/accounts/GrantCredentialsPermissionActivity:setResult	(I)V
    //   47: aload_0
    //   48: invokevirtual 145	android/accounts/GrantCredentialsPermissionActivity:finish	()V
    //   51: return
    //   52: aload_0
    //   53: aload_2
    //   54: ldc 10
    //   56: invokevirtual 200	android/os/Bundle:getParcelable	(Ljava/lang/String;)Landroid/os/Parcelable;
    //   59: checkcast 66	android/accounts/Account
    //   62: putfield 147	android/accounts/GrantCredentialsPermissionActivity:mAccount	Landroid/accounts/Account;
    //   65: aload_0
    //   66: aload_2
    //   67: ldc 19
    //   69: invokevirtual 203	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   72: putfield 149	android/accounts/GrantCredentialsPermissionActivity:mAuthTokenType	Ljava/lang/String;
    //   75: aload_0
    //   76: aload_2
    //   77: ldc 25
    //   79: invokevirtual 207	android/os/Bundle:getInt	(Ljava/lang/String;)I
    //   82: putfield 151	android/accounts/GrantCredentialsPermissionActivity:mUid	I
    //   85: aload_0
    //   86: invokevirtual 211	android/accounts/GrantCredentialsPermissionActivity:getPackageManager	()Landroid/content/pm/PackageManager;
    //   89: astore_3
    //   90: aload_3
    //   91: aload_0
    //   92: getfield 151	android/accounts/GrantCredentialsPermissionActivity:mUid	I
    //   95: invokevirtual 217	android/content/pm/PackageManager:getPackagesForUid	(I)[Ljava/lang/String;
    //   98: astore 4
    //   100: aload_0
    //   101: getfield 147	android/accounts/GrantCredentialsPermissionActivity:mAccount	Landroid/accounts/Account;
    //   104: ifnull +15 -> 119
    //   107: aload_0
    //   108: getfield 149	android/accounts/GrantCredentialsPermissionActivity:mAuthTokenType	Ljava/lang/String;
    //   111: ifnull +8 -> 119
    //   114: aload 4
    //   116: ifnonnull +13 -> 129
    //   119: aload_0
    //   120: iconst_0
    //   121: invokevirtual 176	android/accounts/GrantCredentialsPermissionActivity:setResult	(I)V
    //   124: aload_0
    //   125: invokevirtual 145	android/accounts/GrantCredentialsPermissionActivity:finish	()V
    //   128: return
    //   129: aload_0
    //   130: aload_0
    //   131: getfield 147	android/accounts/GrantCredentialsPermissionActivity:mAccount	Landroid/accounts/Account;
    //   134: invokespecial 219	android/accounts/GrantCredentialsPermissionActivity:getAccountLabel	(Landroid/accounts/Account;)Ljava/lang/String;
    //   137: astore 6
    //   139: aload_0
    //   140: ldc -36
    //   142: invokevirtual 221	android/accounts/GrantCredentialsPermissionActivity:findViewById	(I)Landroid/view/View;
    //   145: checkcast 109	android/widget/TextView
    //   148: astore 7
    //   150: aload 7
    //   152: bipush 8
    //   154: invokevirtual 224	android/widget/TextView:setVisibility	(I)V
    //   157: new 226	android/accounts/GrantCredentialsPermissionActivity$1
    //   160: dup
    //   161: aload_0
    //   162: aload 7
    //   164: invokespecial 229	android/accounts/GrantCredentialsPermissionActivity$1:<init>	(Landroid/accounts/GrantCredentialsPermissionActivity;Landroid/widget/TextView;)V
    //   167: astore 8
    //   169: aload_0
    //   170: invokestatic 55	android/accounts/AccountManager:get	(Landroid/content/Context;)Landroid/accounts/AccountManager;
    //   173: aload_0
    //   174: getfield 147	android/accounts/GrantCredentialsPermissionActivity:mAccount	Landroid/accounts/Account;
    //   177: getfield 67	android/accounts/Account:type	Ljava/lang/String;
    //   180: aload_0
    //   181: getfield 149	android/accounts/GrantCredentialsPermissionActivity:mAuthTokenType	Ljava/lang/String;
    //   184: aload 8
    //   186: aconst_null
    //   187: invokevirtual 233	android/accounts/AccountManager:getAuthTokenLabel	(Ljava/lang/String;Ljava/lang/String;Landroid/accounts/AccountManagerCallback;Landroid/os/Handler;)Landroid/accounts/AccountManagerFuture;
    //   190: pop
    //   191: aload_0
    //   192: ldc -22
    //   194: invokevirtual 221	android/accounts/GrantCredentialsPermissionActivity:findViewById	(I)Landroid/view/View;
    //   197: aload_0
    //   198: invokevirtual 238	android/view/View:setOnClickListener	(Landroid/view/View$OnClickListener;)V
    //   201: aload_0
    //   202: ldc -17
    //   204: invokevirtual 221	android/accounts/GrantCredentialsPermissionActivity:findViewById	(I)Landroid/view/View;
    //   207: aload_0
    //   208: invokevirtual 238	android/view/View:setOnClickListener	(Landroid/view/View$OnClickListener;)V
    //   211: aload_0
    //   212: ldc -16
    //   214: invokevirtual 221	android/accounts/GrantCredentialsPermissionActivity:findViewById	(I)Landroid/view/View;
    //   217: checkcast 242	android/widget/LinearLayout
    //   220: astore 10
    //   222: aload 4
    //   224: arraylength
    //   225: istore 11
    //   227: iconst_0
    //   228: istore 12
    //   230: iload 12
    //   232: iload 11
    //   234: if_icmpge +68 -> 302
    //   237: aload 4
    //   239: iload 12
    //   241: aaload
    //   242: astore 13
    //   244: aload_3
    //   245: aload_3
    //   246: aload 13
    //   248: iconst_0
    //   249: invokevirtual 246	android/content/pm/PackageManager:getApplicationInfo	(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    //   252: invokevirtual 250	android/content/pm/PackageManager:getApplicationLabel	(Landroid/content/pm/ApplicationInfo;)Ljava/lang/CharSequence;
    //   255: invokevirtual 256	java/lang/Object:toString	()Ljava/lang/String;
    //   258: astore 16
    //   260: aload 16
    //   262: astore 15
    //   264: aload 10
    //   266: aload_0
    //   267: aload 15
    //   269: invokespecial 258	android/accounts/GrantCredentialsPermissionActivity:newPackageView	(Ljava/lang/String;)Landroid/view/View;
    //   272: invokevirtual 261	android/widget/LinearLayout:addView	(Landroid/view/View;)V
    //   275: iinc 12 1
    //   278: goto -48 -> 230
    //   281: astore 5
    //   283: aload_0
    //   284: iconst_0
    //   285: invokevirtual 176	android/accounts/GrantCredentialsPermissionActivity:setResult	(I)V
    //   288: aload_0
    //   289: invokevirtual 145	android/accounts/GrantCredentialsPermissionActivity:finish	()V
    //   292: return
    //   293: astore 14
    //   295: aload 13
    //   297: astore 15
    //   299: goto -35 -> 264
    //   302: aload_0
    //   303: ldc_w 262
    //   306: invokevirtual 221	android/accounts/GrantCredentialsPermissionActivity:findViewById	(I)Landroid/view/View;
    //   309: checkcast 109	android/widget/TextView
    //   312: aload_0
    //   313: getfield 147	android/accounts/GrantCredentialsPermissionActivity:mAccount	Landroid/accounts/Account;
    //   316: getfield 265	android/accounts/Account:name	Ljava/lang/String;
    //   319: invokevirtual 113	android/widget/TextView:setText	(Ljava/lang/CharSequence;)V
    //   322: aload_0
    //   323: ldc_w 266
    //   326: invokevirtual 221	android/accounts/GrantCredentialsPermissionActivity:findViewById	(I)Landroid/view/View;
    //   329: checkcast 109	android/widget/TextView
    //   332: aload 6
    //   334: invokevirtual 113	android/widget/TextView:setText	(Ljava/lang/CharSequence;)V
    //   337: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	338	0	this	GrantCredentialsPermissionActivity
    //   0	338	1	paramBundle	Bundle
    //   37	40	2	localBundle	Bundle
    //   89	157	3	localPackageManager	android.content.pm.PackageManager
    //   98	140	4	arrayOfString	String[]
    //   281	1	5	localIllegalArgumentException	IllegalArgumentException
    //   137	196	6	str1	String
    //   148	15	7	localTextView	TextView
    //   167	18	8	local1	1
    //   220	45	10	localLinearLayout	android.widget.LinearLayout
    //   225	10	11	i	int
    //   228	48	12	j	int
    //   242	54	13	str2	String
    //   293	1	14	localNameNotFoundException	PackageManager.NameNotFoundException
    //   262	36	15	str3	String
    //   258	3	16	str4	String
    // Exception table:
    //   from	to	target	type
    //   129	139	281	java/lang/IllegalArgumentException
    //   244	260	293	android/content/pm/PackageManager$NameNotFoundException
  }
  
  public final void setAccountAuthenticatorResult(Bundle paramBundle)
  {
    this.mResultBundle = paramBundle;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\accounts\GrantCredentialsPermissionActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
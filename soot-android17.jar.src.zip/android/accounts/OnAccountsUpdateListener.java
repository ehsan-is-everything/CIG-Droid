package android.accounts;

public abstract interface OnAccountsUpdateListener
{
  public abstract void onAccountsUpdated(Account[] paramArrayOfAccount);
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\accounts\OnAccountsUpdateListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
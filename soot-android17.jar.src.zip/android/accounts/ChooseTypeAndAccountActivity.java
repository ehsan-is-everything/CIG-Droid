package android.accounts;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import com.google.android.collect.Sets;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class ChooseTypeAndAccountActivity
  extends Activity
  implements AccountManagerCallback<Bundle>
{
  public static final String EXTRA_ADD_ACCOUNT_AUTH_TOKEN_TYPE_STRING = "authTokenType";
  public static final String EXTRA_ADD_ACCOUNT_OPTIONS_BUNDLE = "addAccountOptions";
  public static final String EXTRA_ADD_ACCOUNT_REQUIRED_FEATURES_STRING_ARRAY = "addAccountRequiredFeatures";
  public static final String EXTRA_ALLOWABLE_ACCOUNTS_ARRAYLIST = "allowableAccounts";
  public static final String EXTRA_ALLOWABLE_ACCOUNT_TYPES_STRING_ARRAY = "allowableAccountTypes";
  public static final String EXTRA_ALWAYS_PROMPT_FOR_ACCOUNT = "alwaysPromptForAccount";
  public static final String EXTRA_DESCRIPTION_TEXT_OVERRIDE = "descriptionTextOverride";
  public static final String EXTRA_SELECTED_ACCOUNT = "selectedAccount";
  private static final String KEY_INSTANCE_STATE_EXISTING_ACCOUNTS = "existingAccounts";
  private static final String KEY_INSTANCE_STATE_PENDING_REQUEST = "pendingRequest";
  private static final String KEY_INSTANCE_STATE_SELECTED_ACCOUNT_NAME = "selectedAccountName";
  private static final String KEY_INSTANCE_STATE_SELECTED_ADD_ACCOUNT = "selectedAddAccount";
  public static final int REQUEST_ADD_ACCOUNT = 2;
  public static final int REQUEST_CHOOSE_TYPE = 1;
  public static final int REQUEST_NULL = 0;
  private static final int SELECTED_ITEM_NONE = -1;
  private static final String TAG = "AccountChooser";
  private ArrayList<Account> mAccounts;
  private boolean mAlwaysPromptForAccount = false;
  private String mDescriptionOverride;
  private Parcelable[] mExistingAccounts = null;
  private Button mOkButton;
  private int mPendingRequest = 0;
  private String mSelectedAccountName = null;
  private boolean mSelectedAddNewAccount = false;
  private int mSelectedItemIndex;
  private Set<Account> mSetOfAllowableAccounts;
  private Set<String> mSetOfRelevantAccountTypes;
  
  private ArrayList<Account> getAcceptableAccountChoices(AccountManager paramAccountManager)
  {
    Account[] arrayOfAccount = paramAccountManager.getAccounts();
    ArrayList localArrayList = new ArrayList(arrayOfAccount.length);
    int i = arrayOfAccount.length;
    int j = 0;
    if (j < i)
    {
      Account localAccount = arrayOfAccount[j];
      if ((this.mSetOfAllowableAccounts != null) && (!this.mSetOfAllowableAccounts.contains(localAccount))) {}
      for (;;)
      {
        j++;
        break;
        if ((this.mSetOfRelevantAccountTypes == null) || (this.mSetOfRelevantAccountTypes.contains(localAccount.type))) {
          localArrayList.add(localAccount);
        }
      }
    }
    return localArrayList;
  }
  
  private Set<Account> getAllowableAccountSet(Intent paramIntent)
  {
    ArrayList localArrayList = paramIntent.getParcelableArrayListExtra("allowableAccounts");
    HashSet localHashSet = null;
    if (localArrayList != null)
    {
      localHashSet = new HashSet(localArrayList.size());
      Iterator localIterator = localArrayList.iterator();
      while (localIterator.hasNext()) {
        localHashSet.add((Account)localIterator.next());
      }
    }
    return localHashSet;
  }
  
  private int getItemIndexToSelect(ArrayList<Account> paramArrayList, String paramString, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      i = paramArrayList.size();
      return i;
    }
    for (int i = 0;; i++)
    {
      if (i >= paramArrayList.size()) {
        break label50;
      }
      if (((Account)paramArrayList.get(i)).name.equals(paramString)) {
        break;
      }
    }
    label50:
    return -1;
  }
  
  private String[] getListOfDisplayableOptions(ArrayList<Account> paramArrayList)
  {
    String[] arrayOfString = new String[1 + paramArrayList.size()];
    for (int i = 0; i < paramArrayList.size(); i++) {
      arrayOfString[i] = ((Account)paramArrayList.get(i)).name;
    }
    arrayOfString[paramArrayList.size()] = getResources().getString(17040570);
    return arrayOfString;
  }
  
  private Set<String> getReleventAccountTypes(Intent paramIntent)
  {
    String[] arrayOfString = paramIntent.getStringArrayExtra("allowableAccountTypes");
    HashSet localHashSet1 = null;
    if (arrayOfString != null)
    {
      localHashSet1 = Sets.newHashSet(arrayOfString);
      AuthenticatorDescription[] arrayOfAuthenticatorDescription = AccountManager.get(this).getAuthenticatorTypes();
      HashSet localHashSet2 = new HashSet(arrayOfAuthenticatorDescription.length);
      int i = arrayOfAuthenticatorDescription.length;
      for (int j = 0; j < i; j++) {
        localHashSet2.add(arrayOfAuthenticatorDescription[j].type);
      }
      localHashSet1.retainAll(localHashSet2);
    }
    return localHashSet1;
  }
  
  private void onAccountSelected(Account paramAccount)
  {
    Log.d("AccountChooser", "selected account " + paramAccount);
    setResultAndFinish(paramAccount.name, paramAccount.type);
  }
  
  private void overrideDescriptionIfSupplied(String paramString)
  {
    TextView localTextView = (TextView)findViewById(16908919);
    if (!TextUtils.isEmpty(paramString))
    {
      localTextView.setText(paramString);
      return;
    }
    localTextView.setVisibility(8);
  }
  
  private final void populateUIAccountList(String[] paramArrayOfString)
  {
    ListView localListView = (ListView)findViewById(16908298);
    localListView.setAdapter(new ArrayAdapter(this, 17367055, paramArrayOfString));
    localListView.setChoiceMode(1);
    localListView.setItemsCanFocus(false);
    localListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
    {
      public void onItemClick(AdapterView<?> paramAnonymousAdapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong)
      {
        ChooseTypeAndAccountActivity.access$002(ChooseTypeAndAccountActivity.this, paramAnonymousInt);
        ChooseTypeAndAccountActivity.this.mOkButton.setEnabled(true);
      }
    });
    if (this.mSelectedItemIndex != -1)
    {
      localListView.setItemChecked(this.mSelectedItemIndex, true);
      if (Log.isLoggable("AccountChooser", 2)) {
        Log.v("AccountChooser", "List item " + this.mSelectedItemIndex + " should be selected");
      }
    }
  }
  
  private void setResultAndFinish(String paramString1, String paramString2)
  {
    Bundle localBundle = new Bundle();
    localBundle.putString("authAccount", paramString1);
    localBundle.putString("accountType", paramString2);
    setResult(-1, new Intent().putExtras(localBundle));
    if (Log.isLoggable("AccountChooser", 2)) {
      Log.v("AccountChooser", "ChooseTypeAndAccountActivity.setResultAndFinish: selected account " + paramString1 + ", " + paramString2);
    }
    finish();
  }
  
  private void startChooseAccountTypeActivity()
  {
    if (Log.isLoggable("AccountChooser", 2)) {
      Log.v("AccountChooser", "ChooseAccountTypeActivity.startChooseAccountTypeActivity()");
    }
    Intent localIntent = new Intent(this, ChooseAccountTypeActivity.class);
    localIntent.setFlags(524288);
    localIntent.putExtra("allowableAccountTypes", getIntent().getStringArrayExtra("allowableAccountTypes"));
    localIntent.putExtra("addAccountOptions", getIntent().getBundleExtra("addAccountOptions"));
    localIntent.putExtra("addAccountRequiredFeatures", getIntent().getStringArrayExtra("addAccountRequiredFeatures"));
    localIntent.putExtra("authTokenType", getIntent().getStringExtra("authTokenType"));
    startActivityForResult(localIntent, 1);
    this.mPendingRequest = 1;
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    if (Log.isLoggable("AccountChooser", 2))
    {
      if ((paramIntent != null) && (paramIntent.getExtras() != null)) {
        paramIntent.getExtras().keySet();
      }
      if (paramIntent == null) {
        break label120;
      }
    }
    label120:
    for (Bundle localBundle = paramIntent.getExtras();; localBundle = null)
    {
      Log.v("AccountChooser", "ChooseTypeAndAccountActivity.onActivityResult(reqCode=" + paramInt1 + ", resCode=" + paramInt2 + ", extras=" + localBundle + ")");
      this.mPendingRequest = 0;
      if (paramInt2 != 0) {
        break;
      }
      if (this.mAccounts.isEmpty())
      {
        setResult(0);
        finish();
      }
      return;
    }
    if (paramInt2 == -1)
    {
      if (paramInt1 != 1) {
        break label207;
      }
      if (paramIntent != null)
      {
        str3 = paramIntent.getStringExtra("accountType");
        if (str3 != null)
        {
          runAddAccountForAuthenticator(str3);
          return;
        }
      }
      Log.d("AccountChooser", "ChooseTypeAndAccountActivity.onActivityResult: unable to find account type, pretending the request was canceled");
    }
    label207:
    while (paramInt1 != 2)
    {
      String str3;
      Log.d("AccountChooser", "ChooseTypeAndAccountActivity.onActivityResult: unable to find added account, pretending the request was canceled");
      if (Log.isLoggable("AccountChooser", 2)) {
        Log.v("AccountChooser", "ChooseTypeAndAccountActivity.onActivityResult: canceled");
      }
      setResult(0);
      finish();
      return;
    }
    String str1 = null;
    String str2 = null;
    if (paramIntent != null)
    {
      str1 = paramIntent.getStringExtra("authAccount");
      str2 = paramIntent.getStringExtra("accountType");
    }
    Account[] arrayOfAccount;
    HashSet localHashSet;
    int k;
    if ((str1 == null) || (str2 == null))
    {
      arrayOfAccount = AccountManager.get(this).getAccounts();
      localHashSet = new HashSet();
      Parcelable[] arrayOfParcelable = this.mExistingAccounts;
      int i = arrayOfParcelable.length;
      for (int j = 0; j < i; j++) {
        localHashSet.add((Account)arrayOfParcelable[j]);
      }
      k = arrayOfAccount.length;
    }
    for (int m = 0;; m++) {
      if (m < k)
      {
        Account localAccount = arrayOfAccount[m];
        if (!localHashSet.contains(localAccount))
        {
          str1 = localAccount.name;
          str2 = localAccount.type;
        }
      }
      else
      {
        if ((str1 == null) && (str2 == null)) {
          break;
        }
        setResultAndFinish(str1, str2);
        return;
      }
    }
  }
  
  public void onCancelButtonClicked(View paramView)
  {
    onBackPressed();
  }
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    if (Log.isLoggable("AccountChooser", 2)) {
      Log.v("AccountChooser", "ChooseTypeAndAccountActivity.onCreate(savedInstanceState=" + paramBundle + ")");
    }
    Intent localIntent = getIntent();
    if (paramBundle != null)
    {
      this.mPendingRequest = paramBundle.getInt("pendingRequest");
      this.mExistingAccounts = paramBundle.getParcelableArray("existingAccounts");
      this.mSelectedAccountName = paramBundle.getString("selectedAccountName");
      this.mSelectedAddNewAccount = paramBundle.getBoolean("selectedAddAccount", false);
    }
    for (;;)
    {
      if (Log.isLoggable("AccountChooser", 2)) {
        Log.v("AccountChooser", "selected account name is " + this.mSelectedAccountName);
      }
      this.mSetOfAllowableAccounts = getAllowableAccountSet(localIntent);
      this.mSetOfRelevantAccountTypes = getReleventAccountTypes(localIntent);
      this.mAlwaysPromptForAccount = localIntent.getBooleanExtra("alwaysPromptForAccount", false);
      this.mDescriptionOverride = localIntent.getStringExtra("descriptionTextOverride");
      return;
      this.mPendingRequest = 0;
      this.mExistingAccounts = null;
      Account localAccount = (Account)localIntent.getParcelableExtra("selectedAccount");
      if (localAccount != null) {
        this.mSelectedAccountName = localAccount.name;
      }
    }
  }
  
  protected void onDestroy()
  {
    if (Log.isLoggable("AccountChooser", 2)) {
      Log.v("AccountChooser", "ChooseTypeAndAccountActivity.onDestroy()");
    }
    super.onDestroy();
  }
  
  public void onOkButtonClicked(View paramView)
  {
    if (this.mSelectedItemIndex == this.mAccounts.size()) {
      startChooseAccountTypeActivity();
    }
    while (this.mSelectedItemIndex == -1) {
      return;
    }
    onAccountSelected((Account)this.mAccounts.get(this.mSelectedItemIndex));
  }
  
  protected void onResume()
  {
    super.onResume();
    this.mAccounts = getAcceptableAccountChoices(AccountManager.get(this));
    if (this.mPendingRequest == 0)
    {
      if (this.mAccounts.isEmpty())
      {
        if (this.mSetOfRelevantAccountTypes.size() == 1)
        {
          runAddAccountForAuthenticator((String)this.mSetOfRelevantAccountTypes.iterator().next());
          return;
        }
        startChooseAccountTypeActivity();
        return;
      }
      if ((!this.mAlwaysPromptForAccount) && (this.mAccounts.size() == 1))
      {
        Account localAccount = (Account)this.mAccounts.get(0);
        setResultAndFinish(localAccount.name, localAccount.type);
        return;
      }
    }
    String[] arrayOfString = getListOfDisplayableOptions(this.mAccounts);
    this.mSelectedItemIndex = getItemIndexToSelect(this.mAccounts, this.mSelectedAccountName, this.mSelectedAddNewAccount);
    setContentView(17367093);
    overrideDescriptionIfSupplied(this.mDescriptionOverride);
    populateUIAccountList(arrayOfString);
    this.mOkButton = ((Button)findViewById(16908314));
    Button localButton = this.mOkButton;
    if (this.mSelectedItemIndex != -1) {}
    for (boolean bool = true;; bool = false)
    {
      localButton.setEnabled(bool);
      return;
    }
  }
  
  protected void onSaveInstanceState(Bundle paramBundle)
  {
    super.onSaveInstanceState(paramBundle);
    paramBundle.putInt("pendingRequest", this.mPendingRequest);
    if (this.mPendingRequest == 2) {
      paramBundle.putParcelableArray("existingAccounts", this.mExistingAccounts);
    }
    if (this.mSelectedItemIndex != -1)
    {
      if (this.mSelectedItemIndex == this.mAccounts.size()) {
        paramBundle.putBoolean("selectedAddAccount", true);
      }
    }
    else {
      return;
    }
    paramBundle.putBoolean("selectedAddAccount", false);
    paramBundle.putString("selectedAccountName", ((Account)this.mAccounts.get(this.mSelectedItemIndex)).name);
  }
  
  public void run(AccountManagerFuture<Bundle> paramAccountManagerFuture)
  {
    try
    {
      Intent localIntent = (Intent)((Bundle)paramAccountManagerFuture.getResult()).getParcelable("intent");
      if (localIntent != null)
      {
        this.mPendingRequest = 2;
        this.mExistingAccounts = AccountManager.get(this).getAccounts();
        localIntent.setFlags(0xEFFFFFFF & localIntent.getFlags());
        startActivityForResult(localIntent, 2);
        return;
      }
    }
    catch (OperationCanceledException localOperationCanceledException)
    {
      setResult(0);
      finish();
      return;
    }
    catch (AuthenticatorException localAuthenticatorException)
    {
      Bundle localBundle = new Bundle();
      localBundle.putString("errorMessage", "error communicating with server");
      setResult(-1, new Intent().putExtras(localBundle));
      finish();
      return;
    }
    catch (IOException localIOException)
    {
      for (;;) {}
    }
  }
  
  protected void runAddAccountForAuthenticator(String paramString)
  {
    if (Log.isLoggable("AccountChooser", 2)) {
      Log.v("AccountChooser", "runAddAccountForAuthenticator: " + paramString);
    }
    Bundle localBundle = getIntent().getBundleExtra("addAccountOptions");
    String[] arrayOfString = getIntent().getStringArrayExtra("addAccountRequiredFeatures");
    String str = getIntent().getStringExtra("authTokenType");
    AccountManager.get(this).addAccount(paramString, str, arrayOfString, localBundle, null, this, null);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\accounts\ChooseTypeAndAccountActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
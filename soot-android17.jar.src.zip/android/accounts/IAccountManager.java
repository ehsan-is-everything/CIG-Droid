package android.accounts;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface IAccountManager
  extends IInterface
{
  public abstract boolean addAccount(Account paramAccount, String paramString, Bundle paramBundle)
    throws RemoteException;
  
  public abstract void addAcount(IAccountManagerResponse paramIAccountManagerResponse, String paramString1, String paramString2, String[] paramArrayOfString, boolean paramBoolean, Bundle paramBundle)
    throws RemoteException;
  
  public abstract void clearPassword(Account paramAccount)
    throws RemoteException;
  
  public abstract void confirmCredentialsAsUser(IAccountManagerResponse paramIAccountManagerResponse, Account paramAccount, Bundle paramBundle, boolean paramBoolean, int paramInt)
    throws RemoteException;
  
  public abstract void editProperties(IAccountManagerResponse paramIAccountManagerResponse, String paramString, boolean paramBoolean)
    throws RemoteException;
  
  public abstract Account[] getAccounts(String paramString)
    throws RemoteException;
  
  public abstract Account[] getAccountsAsUser(String paramString, int paramInt)
    throws RemoteException;
  
  public abstract void getAccountsByFeatures(IAccountManagerResponse paramIAccountManagerResponse, String paramString, String[] paramArrayOfString)
    throws RemoteException;
  
  public abstract void getAuthToken(IAccountManagerResponse paramIAccountManagerResponse, Account paramAccount, String paramString, boolean paramBoolean1, boolean paramBoolean2, Bundle paramBundle)
    throws RemoteException;
  
  public abstract void getAuthTokenLabel(IAccountManagerResponse paramIAccountManagerResponse, String paramString1, String paramString2)
    throws RemoteException;
  
  public abstract AuthenticatorDescription[] getAuthenticatorTypes()
    throws RemoteException;
  
  public abstract String getPassword(Account paramAccount)
    throws RemoteException;
  
  public abstract String getUserData(Account paramAccount, String paramString)
    throws RemoteException;
  
  public abstract void hasFeatures(IAccountManagerResponse paramIAccountManagerResponse, Account paramAccount, String[] paramArrayOfString)
    throws RemoteException;
  
  public abstract void invalidateAuthToken(String paramString1, String paramString2)
    throws RemoteException;
  
  public abstract String peekAuthToken(Account paramAccount, String paramString)
    throws RemoteException;
  
  public abstract void removeAccount(IAccountManagerResponse paramIAccountManagerResponse, Account paramAccount)
    throws RemoteException;
  
  public abstract void setAuthToken(Account paramAccount, String paramString1, String paramString2)
    throws RemoteException;
  
  public abstract void setPassword(Account paramAccount, String paramString)
    throws RemoteException;
  
  public abstract void setUserData(Account paramAccount, String paramString1, String paramString2)
    throws RemoteException;
  
  public abstract void updateAppPermission(Account paramAccount, String paramString, int paramInt, boolean paramBoolean)
    throws RemoteException;
  
  public abstract void updateCredentials(IAccountManagerResponse paramIAccountManagerResponse, Account paramAccount, String paramString, boolean paramBoolean, Bundle paramBundle)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IAccountManager
  {
    private static final String DESCRIPTOR = "android.accounts.IAccountManager";
    static final int TRANSACTION_addAccount = 8;
    static final int TRANSACTION_addAcount = 18;
    static final int TRANSACTION_clearPassword = 14;
    static final int TRANSACTION_confirmCredentialsAsUser = 21;
    static final int TRANSACTION_editProperties = 20;
    static final int TRANSACTION_getAccounts = 4;
    static final int TRANSACTION_getAccountsAsUser = 5;
    static final int TRANSACTION_getAccountsByFeatures = 7;
    static final int TRANSACTION_getAuthToken = 17;
    static final int TRANSACTION_getAuthTokenLabel = 22;
    static final int TRANSACTION_getAuthenticatorTypes = 3;
    static final int TRANSACTION_getPassword = 1;
    static final int TRANSACTION_getUserData = 2;
    static final int TRANSACTION_hasFeatures = 6;
    static final int TRANSACTION_invalidateAuthToken = 10;
    static final int TRANSACTION_peekAuthToken = 11;
    static final int TRANSACTION_removeAccount = 9;
    static final int TRANSACTION_setAuthToken = 12;
    static final int TRANSACTION_setPassword = 13;
    static final int TRANSACTION_setUserData = 15;
    static final int TRANSACTION_updateAppPermission = 16;
    static final int TRANSACTION_updateCredentials = 19;
    
    public Stub()
    {
      attachInterface(this, "android.accounts.IAccountManager");
    }
    
    public static IAccountManager asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.accounts.IAccountManager");
      if ((localIInterface != null) && ((localIInterface instanceof IAccountManager))) {
        return (IAccountManager)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.accounts.IAccountManager");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        if (paramParcel1.readInt() != 0) {}
        for (Account localAccount14 = (Account)Account.CREATOR.createFromParcel(paramParcel1);; localAccount14 = null)
        {
          String str10 = getPassword(localAccount14);
          paramParcel2.writeNoException();
          paramParcel2.writeString(str10);
          return true;
        }
      case 2: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        if (paramParcel1.readInt() != 0) {}
        for (Account localAccount13 = (Account)Account.CREATOR.createFromParcel(paramParcel1);; localAccount13 = null)
        {
          String str9 = getUserData(localAccount13, paramParcel1.readString());
          paramParcel2.writeNoException();
          paramParcel2.writeString(str9);
          return true;
        }
      case 3: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        AuthenticatorDescription[] arrayOfAuthenticatorDescription = getAuthenticatorTypes();
        paramParcel2.writeNoException();
        paramParcel2.writeTypedArray(arrayOfAuthenticatorDescription, 1);
        return true;
      case 4: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        Account[] arrayOfAccount2 = getAccounts(paramParcel1.readString());
        paramParcel2.writeNoException();
        paramParcel2.writeTypedArray(arrayOfAccount2, 1);
        return true;
      case 5: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        Account[] arrayOfAccount1 = getAccountsAsUser(paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeTypedArray(arrayOfAccount1, 1);
        return true;
      case 6: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        IAccountManagerResponse localIAccountManagerResponse7 = IAccountManagerResponse.Stub.asInterface(paramParcel1.readStrongBinder());
        if (paramParcel1.readInt() != 0) {}
        for (Account localAccount12 = (Account)Account.CREATOR.createFromParcel(paramParcel1);; localAccount12 = null)
        {
          hasFeatures(localIAccountManagerResponse7, localAccount12, paramParcel1.createStringArray());
          paramParcel2.writeNoException();
          return true;
        }
      case 7: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        getAccountsByFeatures(IAccountManagerResponse.Stub.asInterface(paramParcel1.readStrongBinder()), paramParcel1.readString(), paramParcel1.createStringArray());
        paramParcel2.writeNoException();
        return true;
      case 8: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        Account localAccount11;
        String str8;
        if (paramParcel1.readInt() != 0)
        {
          localAccount11 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          str8 = paramParcel1.readString();
          if (paramParcel1.readInt() == 0) {
            break label597;
          }
        }
        for (Bundle localBundle5 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);; localBundle5 = null)
        {
          boolean bool8 = addAccount(localAccount11, str8, localBundle5);
          paramParcel2.writeNoException();
          int j = 0;
          if (bool8) {
            j = 1;
          }
          paramParcel2.writeInt(j);
          return true;
          localAccount11 = null;
          break;
        }
      case 9: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        IAccountManagerResponse localIAccountManagerResponse6 = IAccountManagerResponse.Stub.asInterface(paramParcel1.readStrongBinder());
        if (paramParcel1.readInt() != 0) {}
        for (Account localAccount10 = (Account)Account.CREATOR.createFromParcel(paramParcel1);; localAccount10 = null)
        {
          removeAccount(localIAccountManagerResponse6, localAccount10);
          paramParcel2.writeNoException();
          return true;
        }
      case 10: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        invalidateAuthToken(paramParcel1.readString(), paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 11: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        if (paramParcel1.readInt() != 0) {}
        for (Account localAccount9 = (Account)Account.CREATOR.createFromParcel(paramParcel1);; localAccount9 = null)
        {
          String str7 = peekAuthToken(localAccount9, paramParcel1.readString());
          paramParcel2.writeNoException();
          paramParcel2.writeString(str7);
          return true;
        }
      case 12: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        if (paramParcel1.readInt() != 0) {}
        for (Account localAccount8 = (Account)Account.CREATOR.createFromParcel(paramParcel1);; localAccount8 = null)
        {
          setAuthToken(localAccount8, paramParcel1.readString(), paramParcel1.readString());
          paramParcel2.writeNoException();
          return true;
        }
      case 13: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        if (paramParcel1.readInt() != 0) {}
        for (Account localAccount7 = (Account)Account.CREATOR.createFromParcel(paramParcel1);; localAccount7 = null)
        {
          setPassword(localAccount7, paramParcel1.readString());
          paramParcel2.writeNoException();
          return true;
        }
      case 14: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        if (paramParcel1.readInt() != 0) {}
        for (Account localAccount6 = (Account)Account.CREATOR.createFromParcel(paramParcel1);; localAccount6 = null)
        {
          clearPassword(localAccount6);
          paramParcel2.writeNoException();
          return true;
        }
      case 15: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        if (paramParcel1.readInt() != 0) {}
        for (Account localAccount5 = (Account)Account.CREATOR.createFromParcel(paramParcel1);; localAccount5 = null)
        {
          setUserData(localAccount5, paramParcel1.readString(), paramParcel1.readString());
          paramParcel2.writeNoException();
          return true;
        }
      case 16: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        Account localAccount4;
        String str6;
        int i;
        if (paramParcel1.readInt() != 0)
        {
          localAccount4 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          str6 = paramParcel1.readString();
          i = paramParcel1.readInt();
          if (paramParcel1.readInt() == 0) {
            break label1013;
          }
        }
        for (boolean bool7 = true;; bool7 = false)
        {
          updateAppPermission(localAccount4, str6, i, bool7);
          paramParcel2.writeNoException();
          return true;
          localAccount4 = null;
          break;
        }
      case 17: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        IAccountManagerResponse localIAccountManagerResponse5 = IAccountManagerResponse.Stub.asInterface(paramParcel1.readStrongBinder());
        Account localAccount3;
        String str5;
        boolean bool5;
        boolean bool6;
        if (paramParcel1.readInt() != 0)
        {
          localAccount3 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          str5 = paramParcel1.readString();
          if (paramParcel1.readInt() == 0) {
            break label1130;
          }
          bool5 = true;
          if (paramParcel1.readInt() == 0) {
            break label1136;
          }
          bool6 = true;
          if (paramParcel1.readInt() == 0) {
            break label1142;
          }
        }
        for (Bundle localBundle4 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);; localBundle4 = null)
        {
          getAuthToken(localIAccountManagerResponse5, localAccount3, str5, bool5, bool6, localBundle4);
          paramParcel2.writeNoException();
          return true;
          localAccount3 = null;
          break;
          bool5 = false;
          break label1071;
          bool6 = false;
          break label1081;
        }
      case 18: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        IAccountManagerResponse localIAccountManagerResponse4 = IAccountManagerResponse.Stub.asInterface(paramParcel1.readStrongBinder());
        String str3 = paramParcel1.readString();
        String str4 = paramParcel1.readString();
        String[] arrayOfString = paramParcel1.createStringArray();
        boolean bool4;
        if (paramParcel1.readInt() != 0)
        {
          bool4 = true;
          if (paramParcel1.readInt() == 0) {
            break label1240;
          }
        }
        for (Bundle localBundle3 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);; localBundle3 = null)
        {
          addAcount(localIAccountManagerResponse4, str3, str4, arrayOfString, bool4, localBundle3);
          paramParcel2.writeNoException();
          return true;
          bool4 = false;
          break;
        }
      case 19: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        IAccountManagerResponse localIAccountManagerResponse3 = IAccountManagerResponse.Stub.asInterface(paramParcel1.readStrongBinder());
        Account localAccount2;
        String str2;
        boolean bool3;
        if (paramParcel1.readInt() != 0)
        {
          localAccount2 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          str2 = paramParcel1.readString();
          if (paramParcel1.readInt() == 0) {
            break label1345;
          }
          bool3 = true;
          if (paramParcel1.readInt() == 0) {
            break label1351;
          }
        }
        for (Bundle localBundle2 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);; localBundle2 = null)
        {
          updateCredentials(localIAccountManagerResponse3, localAccount2, str2, bool3, localBundle2);
          paramParcel2.writeNoException();
          return true;
          localAccount2 = null;
          break;
          bool3 = false;
          break label1298;
        }
      case 20: 
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        IAccountManagerResponse localIAccountManagerResponse2 = IAccountManagerResponse.Stub.asInterface(paramParcel1.readStrongBinder());
        String str1 = paramParcel1.readString();
        if (paramParcel1.readInt() != 0) {}
        for (boolean bool2 = true;; bool2 = false)
        {
          editProperties(localIAccountManagerResponse2, str1, bool2);
          paramParcel2.writeNoException();
          return true;
        }
      case 21: 
        label597:
        label1013:
        label1071:
        label1081:
        label1130:
        label1136:
        label1142:
        label1240:
        label1298:
        label1345:
        label1351:
        paramParcel1.enforceInterface("android.accounts.IAccountManager");
        IAccountManagerResponse localIAccountManagerResponse1 = IAccountManagerResponse.Stub.asInterface(paramParcel1.readStrongBinder());
        Account localAccount1;
        Bundle localBundle1;
        if (paramParcel1.readInt() != 0)
        {
          localAccount1 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label1505;
          }
          localBundle1 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
          label1467:
          if (paramParcel1.readInt() == 0) {
            break label1511;
          }
        }
        label1505:
        label1511:
        for (boolean bool1 = true;; bool1 = false)
        {
          confirmCredentialsAsUser(localIAccountManagerResponse1, localAccount1, localBundle1, bool1, paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
          localAccount1 = null;
          break;
          localBundle1 = null;
          break label1467;
        }
      }
      paramParcel1.enforceInterface("android.accounts.IAccountManager");
      getAuthTokenLabel(IAccountManagerResponse.Stub.asInterface(paramParcel1.readStrongBinder()), paramParcel1.readString(), paramParcel1.readString());
      paramParcel2.writeNoException();
      return true;
    }
    
    private static class Proxy
      implements IAccountManager
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public boolean addAccount(Account paramAccount, String paramString, Bundle paramBundle)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.accounts.IAccountManager");
            if (paramAccount != null)
            {
              localParcel1.writeInt(1);
              paramAccount.writeToParcel(localParcel1, 0);
              localParcel1.writeString(paramString);
              if (paramBundle != null)
              {
                localParcel1.writeInt(1);
                paramBundle.writeToParcel(localParcel1, 0);
                this.mRemote.transact(8, localParcel1, localParcel2, 0);
                localParcel2.readException();
                int i = localParcel2.readInt();
                if (i == 0) {
                  break label140;
                }
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            localParcel1.writeInt(0);
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          continue;
          label140:
          bool = false;
        }
      }
      
      /* Error */
      public void addAcount(IAccountManagerResponse paramIAccountManagerResponse, String paramString1, String paramString2, String[] paramArrayOfString, boolean paramBoolean, Bundle paramBundle)
        throws RemoteException
      {
        // Byte code:
        //   0: iconst_1
        //   1: istore 7
        //   3: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   6: astore 8
        //   8: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   11: astore 9
        //   13: aload 8
        //   15: ldc 27
        //   17: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   20: aload_1
        //   21: ifnull +101 -> 122
        //   24: aload_1
        //   25: invokeinterface 71 1 0
        //   30: astore 11
        //   32: aload 8
        //   34: aload 11
        //   36: invokevirtual 74	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   39: aload 8
        //   41: aload_2
        //   42: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   45: aload 8
        //   47: aload_3
        //   48: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   51: aload 8
        //   53: aload 4
        //   55: invokevirtual 78	android/os/Parcel:writeStringArray	([Ljava/lang/String;)V
        //   58: iload 5
        //   60: ifeq +68 -> 128
        //   63: aload 8
        //   65: iload 7
        //   67: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   70: aload 6
        //   72: ifnull +62 -> 134
        //   75: aload 8
        //   77: iconst_1
        //   78: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   81: aload 6
        //   83: aload 8
        //   85: iconst_0
        //   86: invokevirtual 47	android/os/Bundle:writeToParcel	(Landroid/os/Parcel;I)V
        //   89: aload_0
        //   90: getfield 15	android/accounts/IAccountManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   93: bipush 18
        //   95: aload 8
        //   97: aload 9
        //   99: iconst_0
        //   100: invokeinterface 53 5 0
        //   105: pop
        //   106: aload 9
        //   108: invokevirtual 56	android/os/Parcel:readException	()V
        //   111: aload 9
        //   113: invokevirtual 63	android/os/Parcel:recycle	()V
        //   116: aload 8
        //   118: invokevirtual 63	android/os/Parcel:recycle	()V
        //   121: return
        //   122: aconst_null
        //   123: astore 11
        //   125: goto -93 -> 32
        //   128: iconst_0
        //   129: istore 7
        //   131: goto -68 -> 63
        //   134: aload 8
        //   136: iconst_0
        //   137: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   140: goto -51 -> 89
        //   143: astore 10
        //   145: aload 9
        //   147: invokevirtual 63	android/os/Parcel:recycle	()V
        //   150: aload 8
        //   152: invokevirtual 63	android/os/Parcel:recycle	()V
        //   155: aload 10
        //   157: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	158	0	this	Proxy
        //   0	158	1	paramIAccountManagerResponse	IAccountManagerResponse
        //   0	158	2	paramString1	String
        //   0	158	3	paramString2	String
        //   0	158	4	paramArrayOfString	String[]
        //   0	158	5	paramBoolean	boolean
        //   0	158	6	paramBundle	Bundle
        //   1	129	7	i	int
        //   6	145	8	localParcel1	Parcel
        //   11	135	9	localParcel2	Parcel
        //   143	13	10	localObject	Object
        //   30	94	11	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   13	20	143	finally
        //   24	32	143	finally
        //   32	58	143	finally
        //   63	70	143	finally
        //   75	89	143	finally
        //   89	111	143	finally
        //   134	140	143	finally
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      /* Error */
      public void clearPassword(Account paramAccount)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +42 -> 57
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 41	android/accounts/Account:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/accounts/IAccountManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: bipush 14
        //   35: aload_2
        //   36: aload_3
        //   37: iconst_0
        //   38: invokeinterface 53 5 0
        //   43: pop
        //   44: aload_3
        //   45: invokevirtual 56	android/os/Parcel:readException	()V
        //   48: aload_3
        //   49: invokevirtual 63	android/os/Parcel:recycle	()V
        //   52: aload_2
        //   53: invokevirtual 63	android/os/Parcel:recycle	()V
        //   56: return
        //   57: aload_2
        //   58: iconst_0
        //   59: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   62: goto -33 -> 29
        //   65: astore 4
        //   67: aload_3
        //   68: invokevirtual 63	android/os/Parcel:recycle	()V
        //   71: aload_2
        //   72: invokevirtual 63	android/os/Parcel:recycle	()V
        //   75: aload 4
        //   77: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	78	0	this	Proxy
        //   0	78	1	paramAccount	Account
        //   3	69	2	localParcel1	Parcel
        //   7	61	3	localParcel2	Parcel
        //   65	11	4	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   8	14	65	finally
        //   18	29	65	finally
        //   29	48	65	finally
        //   57	62	65	finally
      }
      
      public void confirmCredentialsAsUser(IAccountManagerResponse paramIAccountManagerResponse, Account paramAccount, Bundle paramBundle, boolean paramBoolean, int paramInt)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.accounts.IAccountManager");
            IBinder localIBinder;
            if (paramIAccountManagerResponse != null)
            {
              localIBinder = paramIAccountManagerResponse.asBinder();
              localParcel1.writeStrongBinder(localIBinder);
              if (paramAccount != null)
              {
                localParcel1.writeInt(1);
                paramAccount.writeToParcel(localParcel1, 0);
                if (paramBundle == null) {
                  break label153;
                }
                localParcel1.writeInt(1);
                paramBundle.writeToParcel(localParcel1, 0);
                break label168;
                localParcel1.writeInt(i);
                localParcel1.writeInt(paramInt);
                this.mRemote.transact(21, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localIBinder = null;
              continue;
            }
            localParcel1.writeInt(0);
            continue;
            localParcel1.writeInt(0);
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          label153:
          label168:
          while (!paramBoolean)
          {
            i = 0;
            break;
          }
        }
      }
      
      /* Error */
      public void editProperties(IAccountManagerResponse paramIAccountManagerResponse, String paramString, boolean paramBoolean)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +74 -> 92
        //   21: aload_1
        //   22: invokeinterface 71 1 0
        //   27: astore 7
        //   29: aload 4
        //   31: aload 7
        //   33: invokevirtual 74	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   36: aload 4
        //   38: aload_2
        //   39: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   42: iconst_0
        //   43: istore 8
        //   45: iload_3
        //   46: ifeq +6 -> 52
        //   49: iconst_1
        //   50: istore 8
        //   52: aload 4
        //   54: iload 8
        //   56: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   59: aload_0
        //   60: getfield 15	android/accounts/IAccountManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   63: bipush 20
        //   65: aload 4
        //   67: aload 5
        //   69: iconst_0
        //   70: invokeinterface 53 5 0
        //   75: pop
        //   76: aload 5
        //   78: invokevirtual 56	android/os/Parcel:readException	()V
        //   81: aload 5
        //   83: invokevirtual 63	android/os/Parcel:recycle	()V
        //   86: aload 4
        //   88: invokevirtual 63	android/os/Parcel:recycle	()V
        //   91: return
        //   92: aconst_null
        //   93: astore 7
        //   95: goto -66 -> 29
        //   98: astore 6
        //   100: aload 5
        //   102: invokevirtual 63	android/os/Parcel:recycle	()V
        //   105: aload 4
        //   107: invokevirtual 63	android/os/Parcel:recycle	()V
        //   110: aload 6
        //   112: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	113	0	this	Proxy
        //   0	113	1	paramIAccountManagerResponse	IAccountManagerResponse
        //   0	113	2	paramString	String
        //   0	113	3	paramBoolean	boolean
        //   3	103	4	localParcel1	Parcel
        //   8	93	5	localParcel2	Parcel
        //   98	13	6	localObject	Object
        //   27	67	7	localIBinder	IBinder
        //   43	12	8	i	int
        // Exception table:
        //   from	to	target	type
        //   10	17	98	finally
        //   21	29	98	finally
        //   29	42	98	finally
        //   52	81	98	finally
      }
      
      public Account[] getAccounts(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.accounts.IAccountManager");
          localParcel1.writeString(paramString);
          this.mRemote.transact(4, localParcel1, localParcel2, 0);
          localParcel2.readException();
          Account[] arrayOfAccount = (Account[])localParcel2.createTypedArray(Account.CREATOR);
          return arrayOfAccount;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public Account[] getAccountsAsUser(String paramString, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.accounts.IAccountManager");
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          Account[] arrayOfAccount = (Account[])localParcel2.createTypedArray(Account.CREATOR);
          return arrayOfAccount;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public void getAccountsByFeatures(IAccountManagerResponse paramIAccountManagerResponse, String paramString, String[] paramArrayOfString)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +63 -> 81
        //   21: aload_1
        //   22: invokeinterface 71 1 0
        //   27: astore 7
        //   29: aload 4
        //   31: aload 7
        //   33: invokevirtual 74	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   36: aload 4
        //   38: aload_2
        //   39: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   42: aload 4
        //   44: aload_3
        //   45: invokevirtual 78	android/os/Parcel:writeStringArray	([Ljava/lang/String;)V
        //   48: aload_0
        //   49: getfield 15	android/accounts/IAccountManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   52: bipush 7
        //   54: aload 4
        //   56: aload 5
        //   58: iconst_0
        //   59: invokeinterface 53 5 0
        //   64: pop
        //   65: aload 5
        //   67: invokevirtual 56	android/os/Parcel:readException	()V
        //   70: aload 5
        //   72: invokevirtual 63	android/os/Parcel:recycle	()V
        //   75: aload 4
        //   77: invokevirtual 63	android/os/Parcel:recycle	()V
        //   80: return
        //   81: aconst_null
        //   82: astore 7
        //   84: goto -55 -> 29
        //   87: astore 6
        //   89: aload 5
        //   91: invokevirtual 63	android/os/Parcel:recycle	()V
        //   94: aload 4
        //   96: invokevirtual 63	android/os/Parcel:recycle	()V
        //   99: aload 6
        //   101: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	102	0	this	Proxy
        //   0	102	1	paramIAccountManagerResponse	IAccountManagerResponse
        //   0	102	2	paramString	String
        //   0	102	3	paramArrayOfString	String[]
        //   3	92	4	localParcel1	Parcel
        //   8	82	5	localParcel2	Parcel
        //   87	13	6	localObject	Object
        //   27	56	7	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   10	17	87	finally
        //   21	29	87	finally
        //   29	70	87	finally
      }
      
      public void getAuthToken(IAccountManagerResponse paramIAccountManagerResponse, Account paramAccount, String paramString, boolean paramBoolean1, boolean paramBoolean2, Bundle paramBundle)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.accounts.IAccountManager");
            IBinder localIBinder;
            if (paramIAccountManagerResponse != null)
            {
              localIBinder = paramIAccountManagerResponse.asBinder();
              localParcel1.writeStrongBinder(localIBinder);
              if (paramAccount != null)
              {
                localParcel1.writeInt(1);
                paramAccount.writeToParcel(localParcel1, 0);
                localParcel1.writeString(paramString);
                if (!paramBoolean1) {
                  break label172;
                }
                j = i;
                localParcel1.writeInt(j);
                if (!paramBoolean2) {
                  break label178;
                }
                localParcel1.writeInt(i);
                if (paramBundle == null) {
                  break label184;
                }
                localParcel1.writeInt(1);
                paramBundle.writeToParcel(localParcel1, 0);
                this.mRemote.transact(17, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localIBinder = null;
              continue;
            }
            localParcel1.writeInt(0);
            continue;
            int j = 0;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          label172:
          continue;
          label178:
          i = 0;
          continue;
          label184:
          localParcel1.writeInt(0);
        }
      }
      
      /* Error */
      public void getAuthTokenLabel(IAccountManagerResponse paramIAccountManagerResponse, String paramString1, String paramString2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +63 -> 81
        //   21: aload_1
        //   22: invokeinterface 71 1 0
        //   27: astore 7
        //   29: aload 4
        //   31: aload 7
        //   33: invokevirtual 74	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   36: aload 4
        //   38: aload_2
        //   39: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   42: aload 4
        //   44: aload_3
        //   45: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   48: aload_0
        //   49: getfield 15	android/accounts/IAccountManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   52: bipush 22
        //   54: aload 4
        //   56: aload 5
        //   58: iconst_0
        //   59: invokeinterface 53 5 0
        //   64: pop
        //   65: aload 5
        //   67: invokevirtual 56	android/os/Parcel:readException	()V
        //   70: aload 5
        //   72: invokevirtual 63	android/os/Parcel:recycle	()V
        //   75: aload 4
        //   77: invokevirtual 63	android/os/Parcel:recycle	()V
        //   80: return
        //   81: aconst_null
        //   82: astore 7
        //   84: goto -55 -> 29
        //   87: astore 6
        //   89: aload 5
        //   91: invokevirtual 63	android/os/Parcel:recycle	()V
        //   94: aload 4
        //   96: invokevirtual 63	android/os/Parcel:recycle	()V
        //   99: aload 6
        //   101: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	102	0	this	Proxy
        //   0	102	1	paramIAccountManagerResponse	IAccountManagerResponse
        //   0	102	2	paramString1	String
        //   0	102	3	paramString2	String
        //   3	92	4	localParcel1	Parcel
        //   8	82	5	localParcel2	Parcel
        //   87	13	6	localObject	Object
        //   27	56	7	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   10	17	87	finally
        //   21	29	87	finally
        //   29	70	87	finally
      }
      
      public AuthenticatorDescription[] getAuthenticatorTypes()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.accounts.IAccountManager");
          this.mRemote.transact(3, localParcel1, localParcel2, 0);
          localParcel2.readException();
          AuthenticatorDescription[] arrayOfAuthenticatorDescription = (AuthenticatorDescription[])localParcel2.createTypedArray(AuthenticatorDescription.CREATOR);
          return arrayOfAuthenticatorDescription;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.accounts.IAccountManager";
      }
      
      /* Error */
      public String getPassword(Account paramAccount)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +49 -> 64
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 41	android/accounts/Account:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/accounts/IAccountManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: iconst_1
        //   34: aload_2
        //   35: aload_3
        //   36: iconst_0
        //   37: invokeinterface 53 5 0
        //   42: pop
        //   43: aload_3
        //   44: invokevirtual 56	android/os/Parcel:readException	()V
        //   47: aload_3
        //   48: invokevirtual 118	android/os/Parcel:readString	()Ljava/lang/String;
        //   51: astore 6
        //   53: aload_3
        //   54: invokevirtual 63	android/os/Parcel:recycle	()V
        //   57: aload_2
        //   58: invokevirtual 63	android/os/Parcel:recycle	()V
        //   61: aload 6
        //   63: areturn
        //   64: aload_2
        //   65: iconst_0
        //   66: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   69: goto -40 -> 29
        //   72: astore 4
        //   74: aload_3
        //   75: invokevirtual 63	android/os/Parcel:recycle	()V
        //   78: aload_2
        //   79: invokevirtual 63	android/os/Parcel:recycle	()V
        //   82: aload 4
        //   84: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	85	0	this	Proxy
        //   0	85	1	paramAccount	Account
        //   3	76	2	localParcel1	Parcel
        //   7	68	3	localParcel2	Parcel
        //   72	11	4	localObject	Object
        //   51	11	6	str	String
        // Exception table:
        //   from	to	target	type
        //   8	14	72	finally
        //   18	29	72	finally
        //   29	53	72	finally
        //   64	69	72	finally
      }
      
      /* Error */
      public String getUserData(Account paramAccount, String paramString)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +58 -> 74
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 41	android/accounts/Account:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: aload_2
        //   32: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   35: aload_0
        //   36: getfield 15	android/accounts/IAccountManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: iconst_2
        //   40: aload_3
        //   41: aload 4
        //   43: iconst_0
        //   44: invokeinterface 53 5 0
        //   49: pop
        //   50: aload 4
        //   52: invokevirtual 56	android/os/Parcel:readException	()V
        //   55: aload 4
        //   57: invokevirtual 118	android/os/Parcel:readString	()Ljava/lang/String;
        //   60: astore 7
        //   62: aload 4
        //   64: invokevirtual 63	android/os/Parcel:recycle	()V
        //   67: aload_3
        //   68: invokevirtual 63	android/os/Parcel:recycle	()V
        //   71: aload 7
        //   73: areturn
        //   74: aload_3
        //   75: iconst_0
        //   76: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   79: goto -49 -> 30
        //   82: astore 5
        //   84: aload 4
        //   86: invokevirtual 63	android/os/Parcel:recycle	()V
        //   89: aload_3
        //   90: invokevirtual 63	android/os/Parcel:recycle	()V
        //   93: aload 5
        //   95: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	96	0	this	Proxy
        //   0	96	1	paramAccount	Account
        //   0	96	2	paramString	String
        //   3	87	3	localParcel1	Parcel
        //   7	78	4	localParcel2	Parcel
        //   82	12	5	localObject	Object
        //   60	12	7	str	String
        // Exception table:
        //   from	to	target	type
        //   9	15	82	finally
        //   19	30	82	finally
        //   30	62	82	finally
        //   74	79	82	finally
      }
      
      /* Error */
      public void hasFeatures(IAccountManagerResponse paramIAccountManagerResponse, Account paramAccount, String[] paramArrayOfString)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +74 -> 92
        //   21: aload_1
        //   22: invokeinterface 71 1 0
        //   27: astore 7
        //   29: aload 4
        //   31: aload 7
        //   33: invokevirtual 74	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   36: aload_2
        //   37: ifnull +61 -> 98
        //   40: aload 4
        //   42: iconst_1
        //   43: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   46: aload_2
        //   47: aload 4
        //   49: iconst_0
        //   50: invokevirtual 41	android/accounts/Account:writeToParcel	(Landroid/os/Parcel;I)V
        //   53: aload 4
        //   55: aload_3
        //   56: invokevirtual 78	android/os/Parcel:writeStringArray	([Ljava/lang/String;)V
        //   59: aload_0
        //   60: getfield 15	android/accounts/IAccountManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   63: bipush 6
        //   65: aload 4
        //   67: aload 5
        //   69: iconst_0
        //   70: invokeinterface 53 5 0
        //   75: pop
        //   76: aload 5
        //   78: invokevirtual 56	android/os/Parcel:readException	()V
        //   81: aload 5
        //   83: invokevirtual 63	android/os/Parcel:recycle	()V
        //   86: aload 4
        //   88: invokevirtual 63	android/os/Parcel:recycle	()V
        //   91: return
        //   92: aconst_null
        //   93: astore 7
        //   95: goto -66 -> 29
        //   98: aload 4
        //   100: iconst_0
        //   101: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   104: goto -51 -> 53
        //   107: astore 6
        //   109: aload 5
        //   111: invokevirtual 63	android/os/Parcel:recycle	()V
        //   114: aload 4
        //   116: invokevirtual 63	android/os/Parcel:recycle	()V
        //   119: aload 6
        //   121: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	122	0	this	Proxy
        //   0	122	1	paramIAccountManagerResponse	IAccountManagerResponse
        //   0	122	2	paramAccount	Account
        //   0	122	3	paramArrayOfString	String[]
        //   3	112	4	localParcel1	Parcel
        //   8	102	5	localParcel2	Parcel
        //   107	13	6	localObject	Object
        //   27	67	7	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   10	17	107	finally
        //   21	29	107	finally
        //   29	36	107	finally
        //   40	53	107	finally
        //   53	81	107	finally
        //   98	104	107	finally
      }
      
      public void invalidateAuthToken(String paramString1, String paramString2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.accounts.IAccountManager");
          localParcel1.writeString(paramString1);
          localParcel1.writeString(paramString2);
          this.mRemote.transact(10, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public String peekAuthToken(Account paramAccount, String paramString)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +59 -> 75
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 41	android/accounts/Account:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: aload_2
        //   32: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   35: aload_0
        //   36: getfield 15	android/accounts/IAccountManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 11
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 53 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 56	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 118	android/os/Parcel:readString	()Ljava/lang/String;
        //   61: astore 7
        //   63: aload 4
        //   65: invokevirtual 63	android/os/Parcel:recycle	()V
        //   68: aload_3
        //   69: invokevirtual 63	android/os/Parcel:recycle	()V
        //   72: aload 7
        //   74: areturn
        //   75: aload_3
        //   76: iconst_0
        //   77: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   80: goto -50 -> 30
        //   83: astore 5
        //   85: aload 4
        //   87: invokevirtual 63	android/os/Parcel:recycle	()V
        //   90: aload_3
        //   91: invokevirtual 63	android/os/Parcel:recycle	()V
        //   94: aload 5
        //   96: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	97	0	this	Proxy
        //   0	97	1	paramAccount	Account
        //   0	97	2	paramString	String
        //   3	88	3	localParcel1	Parcel
        //   7	79	4	localParcel2	Parcel
        //   83	12	5	localObject	Object
        //   61	12	7	str	String
        // Exception table:
        //   from	to	target	type
        //   9	15	83	finally
        //   19	30	83	finally
        //   30	63	83	finally
        //   75	80	83	finally
      }
      
      /* Error */
      public void removeAccount(IAccountManagerResponse paramIAccountManagerResponse, Account paramAccount)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +63 -> 79
        //   19: aload_1
        //   20: invokeinterface 71 1 0
        //   25: astore 6
        //   27: aload_3
        //   28: aload 6
        //   30: invokevirtual 74	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   33: aload_2
        //   34: ifnull +51 -> 85
        //   37: aload_3
        //   38: iconst_1
        //   39: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   42: aload_2
        //   43: aload_3
        //   44: iconst_0
        //   45: invokevirtual 41	android/accounts/Account:writeToParcel	(Landroid/os/Parcel;I)V
        //   48: aload_0
        //   49: getfield 15	android/accounts/IAccountManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   52: bipush 9
        //   54: aload_3
        //   55: aload 4
        //   57: iconst_0
        //   58: invokeinterface 53 5 0
        //   63: pop
        //   64: aload 4
        //   66: invokevirtual 56	android/os/Parcel:readException	()V
        //   69: aload 4
        //   71: invokevirtual 63	android/os/Parcel:recycle	()V
        //   74: aload_3
        //   75: invokevirtual 63	android/os/Parcel:recycle	()V
        //   78: return
        //   79: aconst_null
        //   80: astore 6
        //   82: goto -55 -> 27
        //   85: aload_3
        //   86: iconst_0
        //   87: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   90: goto -42 -> 48
        //   93: astore 5
        //   95: aload 4
        //   97: invokevirtual 63	android/os/Parcel:recycle	()V
        //   100: aload_3
        //   101: invokevirtual 63	android/os/Parcel:recycle	()V
        //   104: aload 5
        //   106: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	107	0	this	Proxy
        //   0	107	1	paramIAccountManagerResponse	IAccountManagerResponse
        //   0	107	2	paramAccount	Account
        //   3	98	3	localParcel1	Parcel
        //   7	89	4	localParcel2	Parcel
        //   93	12	5	localObject	Object
        //   25	56	6	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   9	15	93	finally
        //   19	27	93	finally
        //   27	33	93	finally
        //   37	48	93	finally
        //   48	69	93	finally
        //   85	90	93	finally
      }
      
      /* Error */
      public void setAuthToken(Account paramAccount, String paramString1, String paramString2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +61 -> 79
        //   21: aload 4
        //   23: iconst_1
        //   24: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 4
        //   30: iconst_0
        //   31: invokevirtual 41	android/accounts/Account:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 4
        //   36: aload_2
        //   37: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   40: aload 4
        //   42: aload_3
        //   43: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   46: aload_0
        //   47: getfield 15	android/accounts/IAccountManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   50: bipush 12
        //   52: aload 4
        //   54: aload 5
        //   56: iconst_0
        //   57: invokeinterface 53 5 0
        //   62: pop
        //   63: aload 5
        //   65: invokevirtual 56	android/os/Parcel:readException	()V
        //   68: aload 5
        //   70: invokevirtual 63	android/os/Parcel:recycle	()V
        //   73: aload 4
        //   75: invokevirtual 63	android/os/Parcel:recycle	()V
        //   78: return
        //   79: aload 4
        //   81: iconst_0
        //   82: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   85: goto -51 -> 34
        //   88: astore 6
        //   90: aload 5
        //   92: invokevirtual 63	android/os/Parcel:recycle	()V
        //   95: aload 4
        //   97: invokevirtual 63	android/os/Parcel:recycle	()V
        //   100: aload 6
        //   102: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	103	0	this	Proxy
        //   0	103	1	paramAccount	Account
        //   0	103	2	paramString1	String
        //   0	103	3	paramString2	String
        //   3	93	4	localParcel1	Parcel
        //   8	83	5	localParcel2	Parcel
        //   88	13	6	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	88	finally
        //   21	34	88	finally
        //   34	68	88	finally
        //   79	85	88	finally
      }
      
      /* Error */
      public void setPassword(Account paramAccount, String paramString)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 27
        //   12: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +50 -> 66
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 41	android/accounts/Account:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: aload_2
        //   32: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   35: aload_0
        //   36: getfield 15	android/accounts/IAccountManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: bipush 13
        //   41: aload_3
        //   42: aload 4
        //   44: iconst_0
        //   45: invokeinterface 53 5 0
        //   50: pop
        //   51: aload 4
        //   53: invokevirtual 56	android/os/Parcel:readException	()V
        //   56: aload 4
        //   58: invokevirtual 63	android/os/Parcel:recycle	()V
        //   61: aload_3
        //   62: invokevirtual 63	android/os/Parcel:recycle	()V
        //   65: return
        //   66: aload_3
        //   67: iconst_0
        //   68: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   71: goto -41 -> 30
        //   74: astore 5
        //   76: aload 4
        //   78: invokevirtual 63	android/os/Parcel:recycle	()V
        //   81: aload_3
        //   82: invokevirtual 63	android/os/Parcel:recycle	()V
        //   85: aload 5
        //   87: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	88	0	this	Proxy
        //   0	88	1	paramAccount	Account
        //   0	88	2	paramString	String
        //   3	79	3	localParcel1	Parcel
        //   7	70	4	localParcel2	Parcel
        //   74	12	5	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   9	15	74	finally
        //   19	30	74	finally
        //   30	56	74	finally
        //   66	71	74	finally
      }
      
      /* Error */
      public void setUserData(Account paramAccount, String paramString1, String paramString2)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 5
        //   10: aload 4
        //   12: ldc 27
        //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +61 -> 79
        //   21: aload 4
        //   23: iconst_1
        //   24: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 4
        //   30: iconst_0
        //   31: invokevirtual 41	android/accounts/Account:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 4
        //   36: aload_2
        //   37: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   40: aload 4
        //   42: aload_3
        //   43: invokevirtual 44	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   46: aload_0
        //   47: getfield 15	android/accounts/IAccountManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   50: bipush 15
        //   52: aload 4
        //   54: aload 5
        //   56: iconst_0
        //   57: invokeinterface 53 5 0
        //   62: pop
        //   63: aload 5
        //   65: invokevirtual 56	android/os/Parcel:readException	()V
        //   68: aload 5
        //   70: invokevirtual 63	android/os/Parcel:recycle	()V
        //   73: aload 4
        //   75: invokevirtual 63	android/os/Parcel:recycle	()V
        //   78: return
        //   79: aload 4
        //   81: iconst_0
        //   82: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   85: goto -51 -> 34
        //   88: astore 6
        //   90: aload 5
        //   92: invokevirtual 63	android/os/Parcel:recycle	()V
        //   95: aload 4
        //   97: invokevirtual 63	android/os/Parcel:recycle	()V
        //   100: aload 6
        //   102: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	103	0	this	Proxy
        //   0	103	1	paramAccount	Account
        //   0	103	2	paramString1	String
        //   0	103	3	paramString2	String
        //   3	93	4	localParcel1	Parcel
        //   8	83	5	localParcel2	Parcel
        //   88	13	6	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	88	finally
        //   21	34	88	finally
        //   34	68	88	finally
        //   79	85	88	finally
      }
      
      public void updateAppPermission(Account paramAccount, String paramString, int paramInt, boolean paramBoolean)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.accounts.IAccountManager");
            if (paramAccount != null)
            {
              localParcel1.writeInt(1);
              paramAccount.writeToParcel(localParcel1, 0);
              localParcel1.writeString(paramString);
              localParcel1.writeInt(paramInt);
              if (paramBoolean)
              {
                localParcel1.writeInt(i);
                this.mRemote.transact(16, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            i = 0;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public void updateCredentials(IAccountManagerResponse paramIAccountManagerResponse, Account paramAccount, String paramString, boolean paramBoolean, Bundle paramBundle)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.accounts.IAccountManager");
            IBinder localIBinder;
            if (paramIAccountManagerResponse != null)
            {
              localIBinder = paramIAccountManagerResponse.asBinder();
              localParcel1.writeStrongBinder(localIBinder);
              if (paramAccount != null)
              {
                localParcel1.writeInt(1);
                paramAccount.writeToParcel(localParcel1, 0);
                localParcel1.writeString(paramString);
                if (!paramBoolean) {
                  break label156;
                }
                localParcel1.writeInt(i);
                if (paramBundle == null) {
                  break label162;
                }
                localParcel1.writeInt(1);
                paramBundle.writeToParcel(localParcel1, 0);
                this.mRemote.transact(19, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localIBinder = null;
              continue;
            }
            localParcel1.writeInt(0);
            continue;
            i = 0;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          label156:
          continue;
          label162:
          localParcel1.writeInt(0);
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\accounts\IAccountManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
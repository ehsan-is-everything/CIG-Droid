package android.accounts;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface IAccountAuthenticator
  extends IInterface
{
  public abstract void addAccount(IAccountAuthenticatorResponse paramIAccountAuthenticatorResponse, String paramString1, String paramString2, String[] paramArrayOfString, Bundle paramBundle)
    throws RemoteException;
  
  public abstract void confirmCredentials(IAccountAuthenticatorResponse paramIAccountAuthenticatorResponse, Account paramAccount, Bundle paramBundle)
    throws RemoteException;
  
  public abstract void editProperties(IAccountAuthenticatorResponse paramIAccountAuthenticatorResponse, String paramString)
    throws RemoteException;
  
  public abstract void getAccountRemovalAllowed(IAccountAuthenticatorResponse paramIAccountAuthenticatorResponse, Account paramAccount)
    throws RemoteException;
  
  public abstract void getAuthToken(IAccountAuthenticatorResponse paramIAccountAuthenticatorResponse, Account paramAccount, String paramString, Bundle paramBundle)
    throws RemoteException;
  
  public abstract void getAuthTokenLabel(IAccountAuthenticatorResponse paramIAccountAuthenticatorResponse, String paramString)
    throws RemoteException;
  
  public abstract void hasFeatures(IAccountAuthenticatorResponse paramIAccountAuthenticatorResponse, Account paramAccount, String[] paramArrayOfString)
    throws RemoteException;
  
  public abstract void updateCredentials(IAccountAuthenticatorResponse paramIAccountAuthenticatorResponse, Account paramAccount, String paramString, Bundle paramBundle)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IAccountAuthenticator
  {
    private static final String DESCRIPTOR = "android.accounts.IAccountAuthenticator";
    static final int TRANSACTION_addAccount = 1;
    static final int TRANSACTION_confirmCredentials = 2;
    static final int TRANSACTION_editProperties = 6;
    static final int TRANSACTION_getAccountRemovalAllowed = 8;
    static final int TRANSACTION_getAuthToken = 3;
    static final int TRANSACTION_getAuthTokenLabel = 4;
    static final int TRANSACTION_hasFeatures = 7;
    static final int TRANSACTION_updateCredentials = 5;
    
    public Stub()
    {
      attachInterface(this, "android.accounts.IAccountAuthenticator");
    }
    
    public static IAccountAuthenticator asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.accounts.IAccountAuthenticator");
      if ((localIInterface != null) && ((localIInterface instanceof IAccountAuthenticator))) {
        return (IAccountAuthenticator)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.accounts.IAccountAuthenticator");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.accounts.IAccountAuthenticator");
        IAccountAuthenticatorResponse localIAccountAuthenticatorResponse6 = IAccountAuthenticatorResponse.Stub.asInterface(paramParcel1.readStrongBinder());
        String str3 = paramParcel1.readString();
        String str4 = paramParcel1.readString();
        String[] arrayOfString = paramParcel1.createStringArray();
        if (paramParcel1.readInt() != 0) {}
        for (Bundle localBundle4 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);; localBundle4 = null)
        {
          addAccount(localIAccountAuthenticatorResponse6, str3, str4, arrayOfString, localBundle4);
          return true;
        }
      case 2: 
        paramParcel1.enforceInterface("android.accounts.IAccountAuthenticator");
        IAccountAuthenticatorResponse localIAccountAuthenticatorResponse5 = IAccountAuthenticatorResponse.Stub.asInterface(paramParcel1.readStrongBinder());
        Account localAccount5;
        if (paramParcel1.readInt() != 0)
        {
          localAccount5 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label253;
          }
        }
        for (Bundle localBundle3 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);; localBundle3 = null)
        {
          confirmCredentials(localIAccountAuthenticatorResponse5, localAccount5, localBundle3);
          return true;
          localAccount5 = null;
          break;
        }
      case 3: 
        paramParcel1.enforceInterface("android.accounts.IAccountAuthenticator");
        IAccountAuthenticatorResponse localIAccountAuthenticatorResponse4 = IAccountAuthenticatorResponse.Stub.asInterface(paramParcel1.readStrongBinder());
        Account localAccount4;
        String str2;
        if (paramParcel1.readInt() != 0)
        {
          localAccount4 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          str2 = paramParcel1.readString();
          if (paramParcel1.readInt() == 0) {
            break label342;
          }
        }
        for (Bundle localBundle2 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);; localBundle2 = null)
        {
          getAuthToken(localIAccountAuthenticatorResponse4, localAccount4, str2, localBundle2);
          return true;
          localAccount4 = null;
          break;
        }
      case 4: 
        paramParcel1.enforceInterface("android.accounts.IAccountAuthenticator");
        getAuthTokenLabel(IAccountAuthenticatorResponse.Stub.asInterface(paramParcel1.readStrongBinder()), paramParcel1.readString());
        return true;
      case 5: 
        paramParcel1.enforceInterface("android.accounts.IAccountAuthenticator");
        IAccountAuthenticatorResponse localIAccountAuthenticatorResponse3 = IAccountAuthenticatorResponse.Stub.asInterface(paramParcel1.readStrongBinder());
        Account localAccount3;
        String str1;
        if (paramParcel1.readInt() != 0)
        {
          localAccount3 = (Account)Account.CREATOR.createFromParcel(paramParcel1);
          str1 = paramParcel1.readString();
          if (paramParcel1.readInt() == 0) {
            break label454;
          }
        }
        for (Bundle localBundle1 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);; localBundle1 = null)
        {
          updateCredentials(localIAccountAuthenticatorResponse3, localAccount3, str1, localBundle1);
          return true;
          localAccount3 = null;
          break;
        }
      case 6: 
        paramParcel1.enforceInterface("android.accounts.IAccountAuthenticator");
        editProperties(IAccountAuthenticatorResponse.Stub.asInterface(paramParcel1.readStrongBinder()), paramParcel1.readString());
        return true;
      case 7: 
        label253:
        label342:
        label454:
        paramParcel1.enforceInterface("android.accounts.IAccountAuthenticator");
        IAccountAuthenticatorResponse localIAccountAuthenticatorResponse2 = IAccountAuthenticatorResponse.Stub.asInterface(paramParcel1.readStrongBinder());
        if (paramParcel1.readInt() != 0) {}
        for (Account localAccount2 = (Account)Account.CREATOR.createFromParcel(paramParcel1);; localAccount2 = null)
        {
          hasFeatures(localIAccountAuthenticatorResponse2, localAccount2, paramParcel1.createStringArray());
          return true;
        }
      }
      paramParcel1.enforceInterface("android.accounts.IAccountAuthenticator");
      IAccountAuthenticatorResponse localIAccountAuthenticatorResponse1 = IAccountAuthenticatorResponse.Stub.asInterface(paramParcel1.readStrongBinder());
      if (paramParcel1.readInt() != 0) {}
      for (Account localAccount1 = (Account)Account.CREATOR.createFromParcel(paramParcel1);; localAccount1 = null)
      {
        getAccountRemovalAllowed(localIAccountAuthenticatorResponse1, localAccount1);
        return true;
      }
    }
    
    private static class Proxy
      implements IAccountAuthenticator
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      /* Error */
      public void addAccount(IAccountAuthenticatorResponse paramIAccountAuthenticatorResponse, String paramString1, String paramString2, String[] paramArrayOfString, Bundle paramBundle)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 6
        //   5: aload 6
        //   7: ldc 27
        //   9: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   12: aconst_null
        //   13: astore 8
        //   15: aload_1
        //   16: ifnull +11 -> 27
        //   19: aload_1
        //   20: invokeinterface 37 1 0
        //   25: astore 8
        //   27: aload 6
        //   29: aload 8
        //   31: invokevirtual 40	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   34: aload 6
        //   36: aload_2
        //   37: invokevirtual 43	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   40: aload 6
        //   42: aload_3
        //   43: invokevirtual 43	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   46: aload 6
        //   48: aload 4
        //   50: invokevirtual 47	android/os/Parcel:writeStringArray	([Ljava/lang/String;)V
        //   53: aload 5
        //   55: ifnull +38 -> 93
        //   58: aload 6
        //   60: iconst_1
        //   61: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   64: aload 5
        //   66: aload 6
        //   68: iconst_0
        //   69: invokevirtual 57	android/os/Bundle:writeToParcel	(Landroid/os/Parcel;I)V
        //   72: aload_0
        //   73: getfield 15	android/accounts/IAccountAuthenticator$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   76: iconst_1
        //   77: aload 6
        //   79: aconst_null
        //   80: iconst_1
        //   81: invokeinterface 63 5 0
        //   86: pop
        //   87: aload 6
        //   89: invokevirtual 66	android/os/Parcel:recycle	()V
        //   92: return
        //   93: aload 6
        //   95: iconst_0
        //   96: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   99: goto -27 -> 72
        //   102: astore 7
        //   104: aload 6
        //   106: invokevirtual 66	android/os/Parcel:recycle	()V
        //   109: aload 7
        //   111: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	112	0	this	Proxy
        //   0	112	1	paramIAccountAuthenticatorResponse	IAccountAuthenticatorResponse
        //   0	112	2	paramString1	String
        //   0	112	3	paramString2	String
        //   0	112	4	paramArrayOfString	String[]
        //   0	112	5	paramBundle	Bundle
        //   3	102	6	localParcel	Parcel
        //   102	8	7	localObject	Object
        //   13	17	8	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   5	12	102	finally
        //   19	27	102	finally
        //   27	53	102	finally
        //   58	72	102	finally
        //   72	87	102	finally
        //   93	99	102	finally
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public void confirmCredentials(IAccountAuthenticatorResponse paramIAccountAuthenticatorResponse, Account paramAccount, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel.writeInterfaceToken("android.accounts.IAccountAuthenticator");
            IBinder localIBinder = null;
            if (paramIAccountAuthenticatorResponse != null) {
              localIBinder = paramIAccountAuthenticatorResponse.asBinder();
            }
            localParcel.writeStrongBinder(localIBinder);
            if (paramAccount != null)
            {
              localParcel.writeInt(1);
              paramAccount.writeToParcel(localParcel, 0);
              if (paramBundle != null)
              {
                localParcel.writeInt(1);
                paramBundle.writeToParcel(localParcel, 0);
                this.mRemote.transact(2, localParcel, null, 1);
              }
            }
            else
            {
              localParcel.writeInt(0);
              continue;
            }
            localParcel.writeInt(0);
          }
          finally
          {
            localParcel.recycle();
          }
        }
      }
      
      public void editProperties(IAccountAuthenticatorResponse paramIAccountAuthenticatorResponse, String paramString)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.accounts.IAccountAuthenticator");
          IBinder localIBinder = null;
          if (paramIAccountAuthenticatorResponse != null) {
            localIBinder = paramIAccountAuthenticatorResponse.asBinder();
          }
          localParcel.writeStrongBinder(localIBinder);
          localParcel.writeString(paramString);
          this.mRemote.transact(6, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }
      
      /* Error */
      public void getAccountRemovalAllowed(IAccountAuthenticatorResponse paramIAccountAuthenticatorResponse, Account paramAccount)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: aload_3
        //   5: ldc 27
        //   7: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   10: aconst_null
        //   11: astore 5
        //   13: aload_1
        //   14: ifnull +11 -> 25
        //   17: aload_1
        //   18: invokeinterface 37 1 0
        //   23: astore 5
        //   25: aload_3
        //   26: aload 5
        //   28: invokevirtual 40	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   31: aload_2
        //   32: ifnull +34 -> 66
        //   35: aload_3
        //   36: iconst_1
        //   37: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   40: aload_2
        //   41: aload_3
        //   42: iconst_0
        //   43: invokevirtual 71	android/accounts/Account:writeToParcel	(Landroid/os/Parcel;I)V
        //   46: aload_0
        //   47: getfield 15	android/accounts/IAccountAuthenticator$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   50: bipush 8
        //   52: aload_3
        //   53: aconst_null
        //   54: iconst_1
        //   55: invokeinterface 63 5 0
        //   60: pop
        //   61: aload_3
        //   62: invokevirtual 66	android/os/Parcel:recycle	()V
        //   65: return
        //   66: aload_3
        //   67: iconst_0
        //   68: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   71: goto -25 -> 46
        //   74: astore 4
        //   76: aload_3
        //   77: invokevirtual 66	android/os/Parcel:recycle	()V
        //   80: aload 4
        //   82: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	83	0	this	Proxy
        //   0	83	1	paramIAccountAuthenticatorResponse	IAccountAuthenticatorResponse
        //   0	83	2	paramAccount	Account
        //   3	74	3	localParcel	Parcel
        //   74	7	4	localObject	Object
        //   11	16	5	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   4	10	74	finally
        //   17	25	74	finally
        //   25	31	74	finally
        //   35	46	74	finally
        //   46	61	74	finally
        //   66	71	74	finally
      }
      
      public void getAuthToken(IAccountAuthenticatorResponse paramIAccountAuthenticatorResponse, Account paramAccount, String paramString, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel.writeInterfaceToken("android.accounts.IAccountAuthenticator");
            IBinder localIBinder = null;
            if (paramIAccountAuthenticatorResponse != null) {
              localIBinder = paramIAccountAuthenticatorResponse.asBinder();
            }
            localParcel.writeStrongBinder(localIBinder);
            if (paramAccount != null)
            {
              localParcel.writeInt(1);
              paramAccount.writeToParcel(localParcel, 0);
              localParcel.writeString(paramString);
              if (paramBundle != null)
              {
                localParcel.writeInt(1);
                paramBundle.writeToParcel(localParcel, 0);
                this.mRemote.transact(3, localParcel, null, 1);
              }
            }
            else
            {
              localParcel.writeInt(0);
              continue;
            }
            localParcel.writeInt(0);
          }
          finally
          {
            localParcel.recycle();
          }
        }
      }
      
      public void getAuthTokenLabel(IAccountAuthenticatorResponse paramIAccountAuthenticatorResponse, String paramString)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.accounts.IAccountAuthenticator");
          IBinder localIBinder = null;
          if (paramIAccountAuthenticatorResponse != null) {
            localIBinder = paramIAccountAuthenticatorResponse.asBinder();
          }
          localParcel.writeStrongBinder(localIBinder);
          localParcel.writeString(paramString);
          this.mRemote.transact(4, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.accounts.IAccountAuthenticator";
      }
      
      /* Error */
      public void hasFeatures(IAccountAuthenticatorResponse paramIAccountAuthenticatorResponse, Account paramAccount, String[] paramArrayOfString)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 4
        //   5: aload 4
        //   7: ldc 27
        //   9: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   12: aconst_null
        //   13: astore 6
        //   15: aload_1
        //   16: ifnull +11 -> 27
        //   19: aload_1
        //   20: invokeinterface 37 1 0
        //   25: astore 6
        //   27: aload 4
        //   29: aload 6
        //   31: invokevirtual 40	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   34: aload_2
        //   35: ifnull +44 -> 79
        //   38: aload 4
        //   40: iconst_1
        //   41: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   44: aload_2
        //   45: aload 4
        //   47: iconst_0
        //   48: invokevirtual 71	android/accounts/Account:writeToParcel	(Landroid/os/Parcel;I)V
        //   51: aload 4
        //   53: aload_3
        //   54: invokevirtual 47	android/os/Parcel:writeStringArray	([Ljava/lang/String;)V
        //   57: aload_0
        //   58: getfield 15	android/accounts/IAccountAuthenticator$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   61: bipush 7
        //   63: aload 4
        //   65: aconst_null
        //   66: iconst_1
        //   67: invokeinterface 63 5 0
        //   72: pop
        //   73: aload 4
        //   75: invokevirtual 66	android/os/Parcel:recycle	()V
        //   78: return
        //   79: aload 4
        //   81: iconst_0
        //   82: invokevirtual 51	android/os/Parcel:writeInt	(I)V
        //   85: goto -34 -> 51
        //   88: astore 5
        //   90: aload 4
        //   92: invokevirtual 66	android/os/Parcel:recycle	()V
        //   95: aload 5
        //   97: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	98	0	this	Proxy
        //   0	98	1	paramIAccountAuthenticatorResponse	IAccountAuthenticatorResponse
        //   0	98	2	paramAccount	Account
        //   0	98	3	paramArrayOfString	String[]
        //   3	88	4	localParcel	Parcel
        //   88	8	5	localObject	Object
        //   13	17	6	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   5	12	88	finally
        //   19	27	88	finally
        //   27	34	88	finally
        //   38	51	88	finally
        //   51	73	88	finally
        //   79	85	88	finally
      }
      
      public void updateCredentials(IAccountAuthenticatorResponse paramIAccountAuthenticatorResponse, Account paramAccount, String paramString, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel.writeInterfaceToken("android.accounts.IAccountAuthenticator");
            IBinder localIBinder = null;
            if (paramIAccountAuthenticatorResponse != null) {
              localIBinder = paramIAccountAuthenticatorResponse.asBinder();
            }
            localParcel.writeStrongBinder(localIBinder);
            if (paramAccount != null)
            {
              localParcel.writeInt(1);
              paramAccount.writeToParcel(localParcel, 0);
              localParcel.writeString(paramString);
              if (paramBundle != null)
              {
                localParcel.writeInt(1);
                paramBundle.writeToParcel(localParcel, 0);
                this.mRemote.transact(5, localParcel, null, 1);
              }
            }
            else
            {
              localParcel.writeInt(0);
              continue;
            }
            localParcel.writeInt(0);
          }
          finally
          {
            localParcel.recycle();
          }
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\accounts\IAccountAuthenticator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.accounts;

public class AuthenticatorException
  extends AccountsException
{
  public AuthenticatorException() {}
  
  public AuthenticatorException(String paramString)
  {
    super(paramString);
  }
  
  public AuthenticatorException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
  
  public AuthenticatorException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\accounts\AuthenticatorException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
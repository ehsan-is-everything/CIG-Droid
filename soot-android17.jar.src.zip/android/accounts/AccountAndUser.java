package android.accounts;

public class AccountAndUser
{
  public Account account;
  public int userId;
  
  public AccountAndUser(Account paramAccount, int paramInt)
  {
    this.account = paramAccount;
    this.userId = paramInt;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    AccountAndUser localAccountAndUser;
    do
    {
      return true;
      if (!(paramObject instanceof AccountAndUser)) {
        return false;
      }
      localAccountAndUser = (AccountAndUser)paramObject;
    } while ((this.account.equals(localAccountAndUser.account)) && (this.userId == localAccountAndUser.userId));
    return false;
  }
  
  public int hashCode()
  {
    return this.account.hashCode() + this.userId;
  }
  
  public String toString()
  {
    return this.account.toString() + " u" + this.userId;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\accounts\AccountAndUser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.accounts;

import android.content.Context;
import android.content.pm.RegisteredServicesCache;
import android.content.pm.XmlSerializerAndParser;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

class AccountAuthenticatorCache
  extends RegisteredServicesCache<AuthenticatorDescription>
  implements IAccountAuthenticatorCache
{
  private static final String TAG = "Account";
  private static final MySerializer sSerializer = new MySerializer(null);
  
  public AccountAuthenticatorCache(Context paramContext)
  {
    super(paramContext, "android.accounts.AccountAuthenticator", "android.accounts.AccountAuthenticator", "account-authenticator", sSerializer);
  }
  
  /* Error */
  public AuthenticatorDescription parseServiceAttributes(android.content.res.Resources paramResources, String paramString, android.util.AttributeSet paramAttributeSet)
  {
    // Byte code:
    //   0: aload_1
    //   1: aload_3
    //   2: getstatic 44	com/android/internal/R$styleable:AccountAuthenticator	[I
    //   5: invokevirtual 50	android/content/res/Resources:obtainAttributes	(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   8: astore 4
    //   10: aload 4
    //   12: iconst_2
    //   13: invokevirtual 56	android/content/res/TypedArray:getString	(I)Ljava/lang/String;
    //   16: astore 6
    //   18: aload 4
    //   20: iconst_0
    //   21: iconst_0
    //   22: invokevirtual 60	android/content/res/TypedArray:getResourceId	(II)I
    //   25: istore 7
    //   27: aload 4
    //   29: iconst_1
    //   30: iconst_0
    //   31: invokevirtual 60	android/content/res/TypedArray:getResourceId	(II)I
    //   34: istore 8
    //   36: aload 4
    //   38: iconst_3
    //   39: iconst_0
    //   40: invokevirtual 60	android/content/res/TypedArray:getResourceId	(II)I
    //   43: istore 9
    //   45: aload 4
    //   47: iconst_4
    //   48: iconst_0
    //   49: invokevirtual 60	android/content/res/TypedArray:getResourceId	(II)I
    //   52: istore 10
    //   54: aload 4
    //   56: iconst_5
    //   57: iconst_0
    //   58: invokevirtual 64	android/content/res/TypedArray:getBoolean	(IZ)Z
    //   61: istore 11
    //   63: aload 6
    //   65: invokestatic 70	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   68: istore 12
    //   70: iload 12
    //   72: ifeq +14 -> 86
    //   75: aconst_null
    //   76: astore 13
    //   78: aload 4
    //   80: invokevirtual 73	android/content/res/TypedArray:recycle	()V
    //   83: aload 13
    //   85: areturn
    //   86: new 75	android/accounts/AuthenticatorDescription
    //   89: dup
    //   90: aload 6
    //   92: aload_2
    //   93: iload 7
    //   95: iload 8
    //   97: iload 9
    //   99: iload 10
    //   101: iload 11
    //   103: invokespecial 78	android/accounts/AuthenticatorDescription:<init>	(Ljava/lang/String;Ljava/lang/String;IIIIZ)V
    //   106: astore 13
    //   108: goto -30 -> 78
    //   111: astore 5
    //   113: aload 4
    //   115: invokevirtual 73	android/content/res/TypedArray:recycle	()V
    //   118: aload 5
    //   120: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	121	0	this	AccountAuthenticatorCache
    //   0	121	1	paramResources	android.content.res.Resources
    //   0	121	2	paramString	String
    //   0	121	3	paramAttributeSet	android.util.AttributeSet
    //   8	106	4	localTypedArray	android.content.res.TypedArray
    //   111	8	5	localObject	Object
    //   16	75	6	str	String
    //   25	69	7	i	int
    //   34	62	8	j	int
    //   43	55	9	k	int
    //   52	48	10	m	int
    //   61	41	11	bool1	boolean
    //   68	3	12	bool2	boolean
    //   76	31	13	localAuthenticatorDescription	AuthenticatorDescription
    // Exception table:
    //   from	to	target	type
    //   10	70	111	finally
    //   86	108	111	finally
  }
  
  private static class MySerializer
    implements XmlSerializerAndParser<AuthenticatorDescription>
  {
    public AuthenticatorDescription createFromXml(XmlPullParser paramXmlPullParser)
      throws IOException, XmlPullParserException
    {
      return AuthenticatorDescription.newKey(paramXmlPullParser.getAttributeValue(null, "type"));
    }
    
    public void writeAsXml(AuthenticatorDescription paramAuthenticatorDescription, XmlSerializer paramXmlSerializer)
      throws IOException
    {
      paramXmlSerializer.attribute(null, "type", paramAuthenticatorDescription.type);
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\accounts\AccountAuthenticatorCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
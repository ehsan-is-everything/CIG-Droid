package android.accounts;

public class NetworkErrorException
  extends AccountsException
{
  public NetworkErrorException() {}
  
  public NetworkErrorException(String paramString)
  {
    super(paramString);
  }
  
  public NetworkErrorException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
  
  public NetworkErrorException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\accounts\NetworkErrorException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.animation;

public abstract interface TimeInterpolator
{
  public abstract float getInterpolation(float paramFloat);
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\animation\TimeInterpolator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.animation;

import android.view.View;
import android.view.View.OnLayoutChangeListener;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnPreDrawListener;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

public class LayoutTransition
{
  public static final int APPEARING = 2;
  public static final int CHANGE_APPEARING = 0;
  public static final int CHANGE_DISAPPEARING = 1;
  public static final int CHANGING = 4;
  private static long DEFAULT_DURATION = 300L;
  public static final int DISAPPEARING = 3;
  private static final int FLAG_APPEARING = 1;
  private static final int FLAG_CHANGE_APPEARING = 4;
  private static final int FLAG_CHANGE_DISAPPEARING = 8;
  private static final int FLAG_CHANGING = 16;
  private static final int FLAG_DISAPPEARING = 2;
  private static ObjectAnimator defaultChange;
  private static ObjectAnimator defaultChangeIn;
  private static ObjectAnimator defaultChangeOut;
  private static ObjectAnimator defaultFadeIn;
  private static ObjectAnimator defaultFadeOut;
  private final LinkedHashMap<View, Animator> currentAppearingAnimations = new LinkedHashMap();
  private final LinkedHashMap<View, Animator> currentChangingAnimations = new LinkedHashMap();
  private final LinkedHashMap<View, Animator> currentDisappearingAnimations = new LinkedHashMap();
  private final HashMap<View, View.OnLayoutChangeListener> layoutChangeListenerMap = new HashMap();
  private boolean mAnimateParentHierarchy = true;
  private Animator mAppearingAnim = null;
  private long mAppearingDelay = DEFAULT_DURATION;
  private long mAppearingDuration = DEFAULT_DURATION;
  private TimeInterpolator mAppearingInterpolator = new AccelerateDecelerateInterpolator();
  private Animator mChangingAnim = null;
  private Animator mChangingAppearingAnim = null;
  private long mChangingAppearingDelay = 0L;
  private long mChangingAppearingDuration = DEFAULT_DURATION;
  private TimeInterpolator mChangingAppearingInterpolator = new DecelerateInterpolator();
  private long mChangingAppearingStagger = 0L;
  private long mChangingDelay = 0L;
  private Animator mChangingDisappearingAnim = null;
  private long mChangingDisappearingDelay = DEFAULT_DURATION;
  private long mChangingDisappearingDuration = DEFAULT_DURATION;
  private TimeInterpolator mChangingDisappearingInterpolator = new DecelerateInterpolator();
  private long mChangingDisappearingStagger = 0L;
  private long mChangingDuration = DEFAULT_DURATION;
  private TimeInterpolator mChangingInterpolator = new DecelerateInterpolator();
  private long mChangingStagger = 0L;
  private Animator mDisappearingAnim = null;
  private long mDisappearingDelay = 0L;
  private long mDisappearingDuration = DEFAULT_DURATION;
  private TimeInterpolator mDisappearingInterpolator = new AccelerateDecelerateInterpolator();
  private ArrayList<TransitionListener> mListeners;
  private int mTransitionTypes = 15;
  private final HashMap<View, Animator> pendingAnimations = new HashMap();
  private long staggerDelay;
  
  public LayoutTransition()
  {
    if (defaultChangeIn == null)
    {
      PropertyValuesHolder localPropertyValuesHolder1 = PropertyValuesHolder.ofInt("left", new int[] { 0, 1 });
      PropertyValuesHolder localPropertyValuesHolder2 = PropertyValuesHolder.ofInt("top", new int[] { 0, 1 });
      PropertyValuesHolder localPropertyValuesHolder3 = PropertyValuesHolder.ofInt("right", new int[] { 0, 1 });
      PropertyValuesHolder localPropertyValuesHolder4 = PropertyValuesHolder.ofInt("bottom", new int[] { 0, 1 });
      PropertyValuesHolder localPropertyValuesHolder5 = PropertyValuesHolder.ofInt("scrollX", new int[] { 0, 1 });
      PropertyValuesHolder localPropertyValuesHolder6 = PropertyValuesHolder.ofInt("scrollY", new int[] { 0, 1 });
      defaultChangeIn = ObjectAnimator.ofPropertyValuesHolder((Object)null, new PropertyValuesHolder[] { localPropertyValuesHolder1, localPropertyValuesHolder2, localPropertyValuesHolder3, localPropertyValuesHolder4, localPropertyValuesHolder5, localPropertyValuesHolder6 });
      defaultChangeIn.setDuration(DEFAULT_DURATION);
      defaultChangeIn.setStartDelay(this.mChangingAppearingDelay);
      defaultChangeIn.setInterpolator(this.mChangingAppearingInterpolator);
      defaultChangeOut = defaultChangeIn.clone();
      defaultChangeOut.setStartDelay(this.mChangingDisappearingDelay);
      defaultChangeOut.setInterpolator(this.mChangingDisappearingInterpolator);
      defaultChange = defaultChangeIn.clone();
      defaultChange.setStartDelay(this.mChangingDelay);
      defaultChange.setInterpolator(this.mChangingInterpolator);
      defaultFadeIn = ObjectAnimator.ofFloat(null, "alpha", new float[] { 0.0F, 1.0F });
      defaultFadeIn.setDuration(DEFAULT_DURATION);
      defaultFadeIn.setStartDelay(this.mAppearingDelay);
      defaultFadeIn.setInterpolator(this.mAppearingInterpolator);
      defaultFadeOut = ObjectAnimator.ofFloat(null, "alpha", new float[] { 1.0F, 0.0F });
      defaultFadeOut.setDuration(DEFAULT_DURATION);
      defaultFadeOut.setStartDelay(this.mDisappearingDelay);
      defaultFadeOut.setInterpolator(this.mDisappearingInterpolator);
    }
    this.mChangingAppearingAnim = defaultChangeIn;
    this.mChangingDisappearingAnim = defaultChangeOut;
    this.mChangingAnim = defaultChange;
    this.mAppearingAnim = defaultFadeIn;
    this.mDisappearingAnim = defaultFadeOut;
  }
  
  private void addChild(ViewGroup paramViewGroup, View paramView, boolean paramBoolean)
  {
    if (paramViewGroup.getWindowVisibility() != 0) {}
    do
    {
      return;
      if ((0x1 & this.mTransitionTypes) == 1) {
        cancel(3);
      }
      if ((paramBoolean) && ((0x4 & this.mTransitionTypes) == 4))
      {
        cancel(0);
        cancel(4);
      }
      if ((hasListeners()) && ((0x1 & this.mTransitionTypes) == 1))
      {
        Iterator localIterator = ((ArrayList)this.mListeners.clone()).iterator();
        while (localIterator.hasNext()) {
          ((TransitionListener)localIterator.next()).startTransition(this, paramViewGroup, paramView, 2);
        }
      }
      if ((paramBoolean) && ((0x4 & this.mTransitionTypes) == 4)) {
        runChangeTransition(paramViewGroup, paramView, 2);
      }
    } while ((0x1 & this.mTransitionTypes) != 1);
    runAppearingTransition(paramViewGroup, paramView);
  }
  
  private boolean hasListeners()
  {
    return (this.mListeners != null) && (this.mListeners.size() > 0);
  }
  
  private void removeChild(ViewGroup paramViewGroup, View paramView, boolean paramBoolean)
  {
    if (paramViewGroup.getWindowVisibility() != 0) {}
    do
    {
      return;
      if ((0x2 & this.mTransitionTypes) == 2) {
        cancel(2);
      }
      if ((paramBoolean) && ((0x8 & this.mTransitionTypes) == 8))
      {
        cancel(1);
        cancel(4);
      }
      if ((hasListeners()) && ((0x2 & this.mTransitionTypes) == 2))
      {
        Iterator localIterator = ((ArrayList)this.mListeners.clone()).iterator();
        while (localIterator.hasNext()) {
          ((TransitionListener)localIterator.next()).startTransition(this, paramViewGroup, paramView, 3);
        }
      }
      if ((paramBoolean) && ((0x8 & this.mTransitionTypes) == 8)) {
        runChangeTransition(paramViewGroup, paramView, 3);
      }
    } while ((0x2 & this.mTransitionTypes) != 2);
    runDisappearingTransition(paramViewGroup, paramView);
  }
  
  private void runAppearingTransition(final ViewGroup paramViewGroup, final View paramView)
  {
    Animator localAnimator1 = (Animator)this.currentDisappearingAnimations.get(paramView);
    if (localAnimator1 != null) {
      localAnimator1.cancel();
    }
    if (this.mAppearingAnim == null)
    {
      if (hasListeners())
      {
        Iterator localIterator = ((ArrayList)this.mListeners.clone()).iterator();
        while (localIterator.hasNext()) {
          ((TransitionListener)localIterator.next()).endTransition(this, paramViewGroup, paramView, 2);
        }
      }
    }
    else
    {
      Animator localAnimator2 = this.mAppearingAnim.clone();
      localAnimator2.setTarget(paramView);
      localAnimator2.setStartDelay(this.mAppearingDelay);
      localAnimator2.setDuration(this.mAppearingDuration);
      if ((localAnimator2 instanceof ObjectAnimator)) {
        ((ObjectAnimator)localAnimator2).setCurrentPlayTime(0L);
      }
      localAnimator2.addListener(new AnimatorListenerAdapter()
      {
        public void onAnimationEnd(Animator paramAnonymousAnimator)
        {
          LayoutTransition.this.currentAppearingAnimations.remove(paramView);
          if (LayoutTransition.this.hasListeners())
          {
            Iterator localIterator = ((ArrayList)LayoutTransition.this.mListeners.clone()).iterator();
            while (localIterator.hasNext()) {
              ((LayoutTransition.TransitionListener)localIterator.next()).endTransition(LayoutTransition.this, paramViewGroup, paramView, 2);
            }
          }
        }
      });
      this.currentAppearingAnimations.put(paramView, localAnimator2);
      localAnimator2.start();
    }
  }
  
  private void runChangeTransition(final ViewGroup paramViewGroup, View paramView, int paramInt)
  {
    Animator localAnimator = null;
    ObjectAnimator localObjectAnimator = null;
    long l;
    switch (paramInt)
    {
    default: 
      l = 0L;
      if (localAnimator != null) {
        break;
      }
    }
    ViewTreeObserver localViewTreeObserver;
    do
    {
      return;
      localAnimator = this.mChangingAppearingAnim;
      l = this.mChangingAppearingDuration;
      localObjectAnimator = defaultChangeIn;
      break;
      localAnimator = this.mChangingDisappearingAnim;
      l = this.mChangingDisappearingDuration;
      localObjectAnimator = defaultChangeOut;
      break;
      localAnimator = this.mChangingAnim;
      l = this.mChangingDuration;
      localObjectAnimator = defaultChange;
      break;
      this.staggerDelay = 0L;
      localViewTreeObserver = paramViewGroup.getViewTreeObserver();
    } while (!localViewTreeObserver.isAlive());
    int i = paramViewGroup.getChildCount();
    for (int j = 0; j < i; j++)
    {
      View localView = paramViewGroup.getChildAt(j);
      if (localView != paramView) {
        setupChangeAnimation(paramViewGroup, paramInt, localAnimator, l, localView);
      }
    }
    if (this.mAnimateParentHierarchy)
    {
      ViewGroup localViewGroup = paramViewGroup;
      while (localViewGroup != null)
      {
        ViewParent localViewParent = localViewGroup.getParent();
        if ((localViewParent instanceof ViewGroup))
        {
          setupChangeAnimation((ViewGroup)localViewParent, paramInt, localObjectAnimator, l, localViewGroup);
          localViewGroup = (ViewGroup)localViewParent;
        }
        else
        {
          localViewGroup = null;
        }
      }
    }
    localViewTreeObserver.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener()
    {
      public boolean onPreDraw()
      {
        paramViewGroup.getViewTreeObserver().removeOnPreDrawListener(this);
        if (LayoutTransition.this.layoutChangeListenerMap.size() > 0)
        {
          Iterator localIterator = LayoutTransition.this.layoutChangeListenerMap.keySet().iterator();
          while (localIterator.hasNext())
          {
            View localView = (View)localIterator.next();
            localView.removeOnLayoutChangeListener((View.OnLayoutChangeListener)LayoutTransition.this.layoutChangeListenerMap.get(localView));
          }
        }
        LayoutTransition.this.layoutChangeListenerMap.clear();
        return true;
      }
    });
  }
  
  private void runDisappearingTransition(final ViewGroup paramViewGroup, final View paramView)
  {
    Animator localAnimator1 = (Animator)this.currentAppearingAnimations.get(paramView);
    if (localAnimator1 != null) {
      localAnimator1.cancel();
    }
    if (this.mDisappearingAnim == null)
    {
      if (hasListeners())
      {
        Iterator localIterator = ((ArrayList)this.mListeners.clone()).iterator();
        while (localIterator.hasNext()) {
          ((TransitionListener)localIterator.next()).endTransition(this, paramViewGroup, paramView, 3);
        }
      }
    }
    else
    {
      Animator localAnimator2 = this.mDisappearingAnim.clone();
      localAnimator2.setStartDelay(this.mDisappearingDelay);
      localAnimator2.setDuration(this.mDisappearingDuration);
      localAnimator2.setTarget(paramView);
      localAnimator2.addListener(new AnimatorListenerAdapter()
      {
        public void onAnimationEnd(Animator paramAnonymousAnimator)
        {
          LayoutTransition.this.currentDisappearingAnimations.remove(paramView);
          paramView.setAlpha(this.val$preAnimAlpha);
          if (LayoutTransition.this.hasListeners())
          {
            Iterator localIterator = ((ArrayList)LayoutTransition.this.mListeners.clone()).iterator();
            while (localIterator.hasNext()) {
              ((LayoutTransition.TransitionListener)localIterator.next()).endTransition(LayoutTransition.this, paramViewGroup, paramView, 3);
            }
          }
        }
      });
      if ((localAnimator2 instanceof ObjectAnimator)) {
        ((ObjectAnimator)localAnimator2).setCurrentPlayTime(0L);
      }
      this.currentDisappearingAnimations.put(paramView, localAnimator2);
      localAnimator2.start();
    }
  }
  
  private void setupChangeAnimation(final ViewGroup paramViewGroup, final int paramInt, Animator paramAnimator, final long paramLong, final View paramView)
  {
    if (this.layoutChangeListenerMap.get(paramView) != null) {}
    while ((paramView.getWidth() == 0) && (paramView.getHeight() == 0)) {
      return;
    }
    final Animator localAnimator1 = paramAnimator.clone();
    localAnimator1.setTarget(paramView);
    localAnimator1.setupStartValues();
    Animator localAnimator2 = (Animator)this.pendingAnimations.get(paramView);
    if (localAnimator2 != null)
    {
      localAnimator2.cancel();
      this.pendingAnimations.remove(paramView);
    }
    this.pendingAnimations.put(paramView, localAnimator1);
    ValueAnimator localValueAnimator = ValueAnimator.ofFloat(new float[] { 0.0F, 1.0F }).setDuration(100L + paramLong);
    localValueAnimator.addListener(new AnimatorListenerAdapter()
    {
      public void onAnimationEnd(Animator paramAnonymousAnimator)
      {
        LayoutTransition.this.pendingAnimations.remove(paramView);
      }
    });
    localValueAnimator.start();
    final View.OnLayoutChangeListener local3 = new View.OnLayoutChangeListener()
    {
      public void onLayoutChange(View paramAnonymousView, int paramAnonymousInt1, int paramAnonymousInt2, int paramAnonymousInt3, int paramAnonymousInt4, int paramAnonymousInt5, int paramAnonymousInt6, int paramAnonymousInt7, int paramAnonymousInt8)
      {
        localAnimator1.setupEndValues();
        if ((localAnimator1 instanceof ValueAnimator))
        {
          int i = 0;
          PropertyValuesHolder[] arrayOfPropertyValuesHolder = ((ValueAnimator)localAnimator1).getValues();
          for (int j = 0; j < arrayOfPropertyValuesHolder.length; j++)
          {
            KeyframeSet localKeyframeSet = arrayOfPropertyValuesHolder[j].mKeyframeSet;
            if ((localKeyframeSet.mFirstKeyframe == null) || (localKeyframeSet.mLastKeyframe == null) || (!localKeyframeSet.mFirstKeyframe.getValue().equals(localKeyframeSet.mLastKeyframe.getValue()))) {
              i = 1;
            }
          }
          if (i == 0) {
            return;
          }
        }
        long l = 0L;
        switch (paramInt)
        {
        }
        for (;;)
        {
          localAnimator1.setStartDelay(l);
          localAnimator1.setDuration(paramLong);
          Animator localAnimator = (Animator)LayoutTransition.this.currentChangingAnimations.get(paramViewGroup);
          if (localAnimator != null) {
            localAnimator.cancel();
          }
          if ((Animator)LayoutTransition.this.pendingAnimations.get(paramViewGroup) != null) {
            LayoutTransition.this.pendingAnimations.remove(paramViewGroup);
          }
          LayoutTransition.this.currentChangingAnimations.put(paramViewGroup, localAnimator1);
          this.val$parent.requestTransitionStart(LayoutTransition.this);
          paramViewGroup.removeOnLayoutChangeListener(this);
          LayoutTransition.this.layoutChangeListenerMap.remove(paramViewGroup);
          return;
          l = LayoutTransition.this.mChangingAppearingDelay + LayoutTransition.this.staggerDelay;
          LayoutTransition.access$314(LayoutTransition.this, LayoutTransition.this.mChangingAppearingStagger);
          continue;
          l = LayoutTransition.this.mChangingDisappearingDelay + LayoutTransition.this.staggerDelay;
          LayoutTransition.access$314(LayoutTransition.this, LayoutTransition.this.mChangingDisappearingStagger);
          continue;
          l = LayoutTransition.this.mChangingDelay + LayoutTransition.this.staggerDelay;
          LayoutTransition.access$314(LayoutTransition.this, LayoutTransition.this.mChangingStagger);
        }
      }
    };
    localAnimator1.addListener(new AnimatorListenerAdapter()
    {
      public void onAnimationCancel(Animator paramAnonymousAnimator)
      {
        paramView.removeOnLayoutChangeListener(local3);
        LayoutTransition.this.layoutChangeListenerMap.remove(paramView);
      }
      
      public void onAnimationEnd(Animator paramAnonymousAnimator)
      {
        LayoutTransition.this.currentChangingAnimations.remove(paramView);
        if (LayoutTransition.this.hasListeners())
        {
          Iterator localIterator = ((ArrayList)LayoutTransition.this.mListeners.clone()).iterator();
          if (localIterator.hasNext())
          {
            LayoutTransition.TransitionListener localTransitionListener = (LayoutTransition.TransitionListener)localIterator.next();
            LayoutTransition localLayoutTransition = LayoutTransition.this;
            ViewGroup localViewGroup = paramViewGroup;
            View localView = paramView;
            int i;
            if (paramInt == 2) {
              i = 0;
            }
            for (;;)
            {
              localTransitionListener.endTransition(localLayoutTransition, localViewGroup, localView, i);
              break;
              if (paramInt == 3) {
                i = 1;
              } else {
                i = 4;
              }
            }
          }
        }
      }
      
      public void onAnimationStart(Animator paramAnonymousAnimator)
      {
        if (LayoutTransition.this.hasListeners())
        {
          Iterator localIterator = ((ArrayList)LayoutTransition.this.mListeners.clone()).iterator();
          if (localIterator.hasNext())
          {
            LayoutTransition.TransitionListener localTransitionListener = (LayoutTransition.TransitionListener)localIterator.next();
            LayoutTransition localLayoutTransition = LayoutTransition.this;
            ViewGroup localViewGroup = paramViewGroup;
            View localView = paramView;
            int i;
            if (paramInt == 2) {
              i = 0;
            }
            for (;;)
            {
              localTransitionListener.startTransition(localLayoutTransition, localViewGroup, localView, i);
              break;
              if (paramInt == 3) {
                i = 1;
              } else {
                i = 4;
              }
            }
          }
        }
      }
    });
    paramView.addOnLayoutChangeListener(local3);
    this.layoutChangeListenerMap.put(paramView, local3);
  }
  
  public void addChild(ViewGroup paramViewGroup, View paramView)
  {
    addChild(paramViewGroup, paramView, true);
  }
  
  public void addTransitionListener(TransitionListener paramTransitionListener)
  {
    if (this.mListeners == null) {
      this.mListeners = new ArrayList();
    }
    this.mListeners.add(paramTransitionListener);
  }
  
  public void cancel()
  {
    if (this.currentChangingAnimations.size() > 0)
    {
      Iterator localIterator3 = ((LinkedHashMap)this.currentChangingAnimations.clone()).values().iterator();
      while (localIterator3.hasNext()) {
        ((Animator)localIterator3.next()).cancel();
      }
      this.currentChangingAnimations.clear();
    }
    if (this.currentAppearingAnimations.size() > 0)
    {
      Iterator localIterator2 = ((LinkedHashMap)this.currentAppearingAnimations.clone()).values().iterator();
      while (localIterator2.hasNext()) {
        ((Animator)localIterator2.next()).end();
      }
      this.currentAppearingAnimations.clear();
    }
    if (this.currentDisappearingAnimations.size() > 0)
    {
      Iterator localIterator1 = ((LinkedHashMap)this.currentDisappearingAnimations.clone()).values().iterator();
      while (localIterator1.hasNext()) {
        ((Animator)localIterator1.next()).end();
      }
      this.currentDisappearingAnimations.clear();
    }
  }
  
  public void cancel(int paramInt)
  {
    switch (paramInt)
    {
    }
    do
    {
      do
      {
        do
        {
          return;
        } while (this.currentChangingAnimations.size() <= 0);
        Iterator localIterator3 = ((LinkedHashMap)this.currentChangingAnimations.clone()).values().iterator();
        while (localIterator3.hasNext()) {
          ((Animator)localIterator3.next()).cancel();
        }
        this.currentChangingAnimations.clear();
        return;
      } while (this.currentAppearingAnimations.size() <= 0);
      Iterator localIterator2 = ((LinkedHashMap)this.currentAppearingAnimations.clone()).values().iterator();
      while (localIterator2.hasNext()) {
        ((Animator)localIterator2.next()).end();
      }
      this.currentAppearingAnimations.clear();
      return;
    } while (this.currentDisappearingAnimations.size() <= 0);
    Iterator localIterator1 = ((LinkedHashMap)this.currentDisappearingAnimations.clone()).values().iterator();
    while (localIterator1.hasNext()) {
      ((Animator)localIterator1.next()).end();
    }
    this.currentDisappearingAnimations.clear();
  }
  
  public void disableTransitionType(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return;
    case 2: 
      this.mTransitionTypes = (0xFFFFFFFE & this.mTransitionTypes);
      return;
    case 3: 
      this.mTransitionTypes = (0xFFFFFFFD & this.mTransitionTypes);
      return;
    case 0: 
      this.mTransitionTypes = (0xFFFFFFFB & this.mTransitionTypes);
      return;
    case 1: 
      this.mTransitionTypes = (0xFFFFFFF7 & this.mTransitionTypes);
      return;
    }
    this.mTransitionTypes = (0xFFFFFFEF & this.mTransitionTypes);
  }
  
  public void enableTransitionType(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return;
    case 2: 
      this.mTransitionTypes = (0x1 | this.mTransitionTypes);
      return;
    case 3: 
      this.mTransitionTypes = (0x2 | this.mTransitionTypes);
      return;
    case 0: 
      this.mTransitionTypes = (0x4 | this.mTransitionTypes);
      return;
    case 1: 
      this.mTransitionTypes = (0x8 | this.mTransitionTypes);
      return;
    }
    this.mTransitionTypes = (0x10 | this.mTransitionTypes);
  }
  
  public void endChangingAnimations()
  {
    Iterator localIterator = ((LinkedHashMap)this.currentChangingAnimations.clone()).values().iterator();
    while (localIterator.hasNext())
    {
      Animator localAnimator = (Animator)localIterator.next();
      localAnimator.start();
      localAnimator.end();
    }
    this.currentChangingAnimations.clear();
  }
  
  public Animator getAnimator(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return null;
    case 0: 
      return this.mChangingAppearingAnim;
    case 1: 
      return this.mChangingDisappearingAnim;
    case 4: 
      return this.mChangingAnim;
    case 2: 
      return this.mAppearingAnim;
    }
    return this.mDisappearingAnim;
  }
  
  public long getDuration(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return 0L;
    case 0: 
      return this.mChangingAppearingDuration;
    case 1: 
      return this.mChangingDisappearingDuration;
    case 4: 
      return this.mChangingDuration;
    case 2: 
      return this.mAppearingDuration;
    }
    return this.mDisappearingDuration;
  }
  
  public TimeInterpolator getInterpolator(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return null;
    case 0: 
      return this.mChangingAppearingInterpolator;
    case 1: 
      return this.mChangingDisappearingInterpolator;
    case 4: 
      return this.mChangingInterpolator;
    case 2: 
      return this.mAppearingInterpolator;
    }
    return this.mDisappearingInterpolator;
  }
  
  public long getStagger(int paramInt)
  {
    switch (paramInt)
    {
    case 2: 
    case 3: 
    default: 
      return 0L;
    case 0: 
      return this.mChangingAppearingStagger;
    case 1: 
      return this.mChangingDisappearingStagger;
    }
    return this.mChangingStagger;
  }
  
  public long getStartDelay(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return 0L;
    case 0: 
      return this.mChangingAppearingDelay;
    case 1: 
      return this.mChangingDisappearingDelay;
    case 4: 
      return this.mChangingDelay;
    case 2: 
      return this.mAppearingDelay;
    }
    return this.mDisappearingDelay;
  }
  
  public List<TransitionListener> getTransitionListeners()
  {
    return this.mListeners;
  }
  
  @Deprecated
  public void hideChild(ViewGroup paramViewGroup, View paramView)
  {
    removeChild(paramViewGroup, paramView, true);
  }
  
  public void hideChild(ViewGroup paramViewGroup, View paramView, int paramInt)
  {
    if (paramInt == 8) {}
    for (boolean bool = true;; bool = false)
    {
      removeChild(paramViewGroup, paramView, bool);
      return;
    }
  }
  
  public boolean isChangingLayout()
  {
    return this.currentChangingAnimations.size() > 0;
  }
  
  public boolean isRunning()
  {
    return (this.currentChangingAnimations.size() > 0) || (this.currentAppearingAnimations.size() > 0) || (this.currentDisappearingAnimations.size() > 0);
  }
  
  public boolean isTransitionTypeEnabled(int paramInt)
  {
    int i = 1;
    switch (paramInt)
    {
    default: 
      i = 0;
    }
    do
    {
      do
      {
        do
        {
          do
          {
            do
            {
              return i;
            } while ((0x1 & this.mTransitionTypes) == i);
            return false;
          } while ((0x2 & this.mTransitionTypes) == 2);
          return false;
        } while ((0x4 & this.mTransitionTypes) == 4);
        return false;
      } while ((0x8 & this.mTransitionTypes) == 8);
      return false;
    } while ((0x10 & this.mTransitionTypes) == 16);
    return false;
  }
  
  public void layoutChange(ViewGroup paramViewGroup)
  {
    if (paramViewGroup.getWindowVisibility() != 0) {}
    while (((0x10 & this.mTransitionTypes) != 16) || (isRunning())) {
      return;
    }
    runChangeTransition(paramViewGroup, null, 4);
  }
  
  public void removeChild(ViewGroup paramViewGroup, View paramView)
  {
    removeChild(paramViewGroup, paramView, true);
  }
  
  public void removeTransitionListener(TransitionListener paramTransitionListener)
  {
    if (this.mListeners == null) {
      return;
    }
    this.mListeners.remove(paramTransitionListener);
  }
  
  public void setAnimateParentHierarchy(boolean paramBoolean)
  {
    this.mAnimateParentHierarchy = paramBoolean;
  }
  
  public void setAnimator(int paramInt, Animator paramAnimator)
  {
    switch (paramInt)
    {
    default: 
      return;
    case 0: 
      this.mChangingAppearingAnim = paramAnimator;
      return;
    case 1: 
      this.mChangingDisappearingAnim = paramAnimator;
      return;
    case 4: 
      this.mChangingAnim = paramAnimator;
      return;
    case 2: 
      this.mAppearingAnim = paramAnimator;
      return;
    }
    this.mDisappearingAnim = paramAnimator;
  }
  
  public void setDuration(int paramInt, long paramLong)
  {
    switch (paramInt)
    {
    default: 
      return;
    case 0: 
      this.mChangingAppearingDuration = paramLong;
      return;
    case 1: 
      this.mChangingDisappearingDuration = paramLong;
      return;
    case 4: 
      this.mChangingDuration = paramLong;
      return;
    case 2: 
      this.mAppearingDuration = paramLong;
      return;
    }
    this.mDisappearingDuration = paramLong;
  }
  
  public void setDuration(long paramLong)
  {
    this.mChangingAppearingDuration = paramLong;
    this.mChangingDisappearingDuration = paramLong;
    this.mChangingDuration = paramLong;
    this.mAppearingDuration = paramLong;
    this.mDisappearingDuration = paramLong;
  }
  
  public void setInterpolator(int paramInt, TimeInterpolator paramTimeInterpolator)
  {
    switch (paramInt)
    {
    default: 
      return;
    case 0: 
      this.mChangingAppearingInterpolator = paramTimeInterpolator;
      return;
    case 1: 
      this.mChangingDisappearingInterpolator = paramTimeInterpolator;
      return;
    case 4: 
      this.mChangingInterpolator = paramTimeInterpolator;
      return;
    case 2: 
      this.mAppearingInterpolator = paramTimeInterpolator;
      return;
    }
    this.mDisappearingInterpolator = paramTimeInterpolator;
  }
  
  public void setStagger(int paramInt, long paramLong)
  {
    switch (paramInt)
    {
    case 2: 
    case 3: 
    default: 
      return;
    case 0: 
      this.mChangingAppearingStagger = paramLong;
      return;
    case 1: 
      this.mChangingDisappearingStagger = paramLong;
      return;
    }
    this.mChangingStagger = paramLong;
  }
  
  public void setStartDelay(int paramInt, long paramLong)
  {
    switch (paramInt)
    {
    default: 
      return;
    case 0: 
      this.mChangingAppearingDelay = paramLong;
      return;
    case 1: 
      this.mChangingDisappearingDelay = paramLong;
      return;
    case 4: 
      this.mChangingDelay = paramLong;
      return;
    case 2: 
      this.mAppearingDelay = paramLong;
      return;
    }
    this.mDisappearingDelay = paramLong;
  }
  
  @Deprecated
  public void showChild(ViewGroup paramViewGroup, View paramView)
  {
    addChild(paramViewGroup, paramView, true);
  }
  
  public void showChild(ViewGroup paramViewGroup, View paramView, int paramInt)
  {
    if (paramInt == 8) {}
    for (boolean bool = true;; bool = false)
    {
      addChild(paramViewGroup, paramView, bool);
      return;
    }
  }
  
  public void startChangingAnimations()
  {
    Iterator localIterator = ((LinkedHashMap)this.currentChangingAnimations.clone()).values().iterator();
    while (localIterator.hasNext())
    {
      Animator localAnimator = (Animator)localIterator.next();
      if ((localAnimator instanceof ObjectAnimator)) {
        ((ObjectAnimator)localAnimator).setCurrentPlayTime(0L);
      }
      localAnimator.start();
    }
  }
  
  public static abstract interface TransitionListener
  {
    public abstract void endTransition(LayoutTransition paramLayoutTransition, ViewGroup paramViewGroup, View paramView, int paramInt);
    
    public abstract void startTransition(LayoutTransition paramLayoutTransition, ViewGroup paramViewGroup, View paramView, int paramInt);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\animation\LayoutTransition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
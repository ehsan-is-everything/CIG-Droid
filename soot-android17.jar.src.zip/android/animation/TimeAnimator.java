package android.animation;

public class TimeAnimator
  extends ValueAnimator
{
  private TimeListener mListener;
  private long mPreviousTime = -1L;
  
  void animateValue(float paramFloat) {}
  
  boolean animationFrame(long paramLong)
  {
    long l1 = 0L;
    long l2;
    if (this.mListener != null)
    {
      l2 = paramLong - this.mStartTime;
      if (this.mPreviousTime >= l1) {
        break label46;
      }
    }
    for (;;)
    {
      this.mPreviousTime = paramLong;
      this.mListener.onTimeUpdate(this, l2, l1);
      return false;
      label46:
      l1 = paramLong - this.mPreviousTime;
    }
  }
  
  void initAnimation() {}
  
  public void setTimeListener(TimeListener paramTimeListener)
  {
    this.mListener = paramTimeListener;
  }
  
  public void start()
  {
    this.mPreviousTime = -1L;
    super.start();
  }
  
  public static abstract interface TimeListener
  {
    public abstract void onTimeUpdate(TimeAnimator paramTimeAnimator, long paramLong1, long paramLong2);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\animation\TimeAnimator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
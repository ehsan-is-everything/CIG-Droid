package android.animation;

import android.os.Looper;
import android.util.AndroidRuntimeException;
import android.view.Choreographer;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class ValueAnimator
  extends Animator
{
  public static final int INFINITE = -1;
  public static final int RESTART = 1;
  public static final int REVERSE = 2;
  static final int RUNNING = 1;
  static final int SEEKED = 2;
  static final int STOPPED;
  private static ThreadLocal<AnimationHandler> sAnimationHandler = new ThreadLocal();
  private static final TimeInterpolator sDefaultInterpolator = new AccelerateDecelerateInterpolator();
  private static float sDurationScale = 1.0F;
  private float mCurrentFraction = 0.0F;
  private int mCurrentIteration = 0;
  private long mDelayStartTime;
  private long mDuration = (300.0F * sDurationScale);
  boolean mInitialized = false;
  private TimeInterpolator mInterpolator = sDefaultInterpolator;
  private boolean mPlayingBackwards = false;
  int mPlayingState = 0;
  private int mRepeatCount = 0;
  private int mRepeatMode = 1;
  private boolean mRunning = false;
  long mSeekTime = -1L;
  private long mStartDelay = 0L;
  private boolean mStartListenersCalled = false;
  long mStartTime;
  private boolean mStarted = false;
  private boolean mStartedDelay = false;
  private long mUnscaledDuration = 300L;
  private long mUnscaledStartDelay = 0L;
  private ArrayList<AnimatorUpdateListener> mUpdateListeners = null;
  PropertyValuesHolder[] mValues;
  HashMap<String, PropertyValuesHolder> mValuesMap;
  
  public static void clearAllAnimations()
  {
    AnimationHandler localAnimationHandler = (AnimationHandler)sAnimationHandler.get();
    if (localAnimationHandler != null)
    {
      localAnimationHandler.mAnimations.clear();
      localAnimationHandler.mPendingAnimations.clear();
      localAnimationHandler.mDelayedAnims.clear();
    }
  }
  
  private boolean delayedAnimationFrame(long paramLong)
  {
    if (!this.mStartedDelay)
    {
      this.mStartedDelay = true;
      this.mDelayStartTime = paramLong;
    }
    long l;
    do
    {
      return false;
      l = paramLong - this.mDelayStartTime;
    } while (l <= this.mStartDelay);
    this.mStartTime = (paramLong - (l - this.mStartDelay));
    this.mPlayingState = 1;
    return true;
  }
  
  private void endAnimation(AnimationHandler paramAnimationHandler)
  {
    paramAnimationHandler.mAnimations.remove(this);
    paramAnimationHandler.mPendingAnimations.remove(this);
    paramAnimationHandler.mDelayedAnims.remove(this);
    this.mPlayingState = 0;
    if (((this.mStarted) || (this.mRunning)) && (this.mListeners != null))
    {
      if (!this.mRunning) {
        notifyStartListeners();
      }
      ArrayList localArrayList = (ArrayList)this.mListeners.clone();
      int i = localArrayList.size();
      for (int j = 0; j < i; j++) {
        ((Animator.AnimatorListener)localArrayList.get(j)).onAnimationEnd(this);
      }
    }
    this.mRunning = false;
    this.mStarted = false;
    this.mStartListenersCalled = false;
  }
  
  public static int getCurrentAnimationsCount()
  {
    AnimationHandler localAnimationHandler = (AnimationHandler)sAnimationHandler.get();
    if (localAnimationHandler != null) {
      return localAnimationHandler.mAnimations.size();
    }
    return 0;
  }
  
  public static float getDurationScale()
  {
    return sDurationScale;
  }
  
  public static long getFrameDelay()
  {
    return Choreographer.getFrameDelay();
  }
  
  private AnimationHandler getOrCreateAnimationHandler()
  {
    AnimationHandler localAnimationHandler = (AnimationHandler)sAnimationHandler.get();
    if (localAnimationHandler == null)
    {
      localAnimationHandler = new AnimationHandler(null);
      sAnimationHandler.set(localAnimationHandler);
    }
    return localAnimationHandler;
  }
  
  private void notifyStartListeners()
  {
    if ((this.mListeners != null) && (!this.mStartListenersCalled))
    {
      ArrayList localArrayList = (ArrayList)this.mListeners.clone();
      int i = localArrayList.size();
      for (int j = 0; j < i; j++) {
        ((Animator.AnimatorListener)localArrayList.get(j)).onAnimationStart(this);
      }
    }
    this.mStartListenersCalled = true;
  }
  
  public static ValueAnimator ofFloat(float... paramVarArgs)
  {
    ValueAnimator localValueAnimator = new ValueAnimator();
    localValueAnimator.setFloatValues(paramVarArgs);
    return localValueAnimator;
  }
  
  public static ValueAnimator ofInt(int... paramVarArgs)
  {
    ValueAnimator localValueAnimator = new ValueAnimator();
    localValueAnimator.setIntValues(paramVarArgs);
    return localValueAnimator;
  }
  
  public static ValueAnimator ofObject(TypeEvaluator paramTypeEvaluator, Object... paramVarArgs)
  {
    ValueAnimator localValueAnimator = new ValueAnimator();
    localValueAnimator.setObjectValues(paramVarArgs);
    localValueAnimator.setEvaluator(paramTypeEvaluator);
    return localValueAnimator;
  }
  
  public static ValueAnimator ofPropertyValuesHolder(PropertyValuesHolder... paramVarArgs)
  {
    ValueAnimator localValueAnimator = new ValueAnimator();
    localValueAnimator.setValues(paramVarArgs);
    return localValueAnimator;
  }
  
  public static void setDurationScale(float paramFloat)
  {
    sDurationScale = paramFloat;
  }
  
  public static void setFrameDelay(long paramLong)
  {
    Choreographer.setFrameDelay(paramLong);
  }
  
  private void start(boolean paramBoolean)
  {
    if (Looper.myLooper() == null) {
      throw new AndroidRuntimeException("Animators may only be run on Looper threads");
    }
    this.mPlayingBackwards = paramBoolean;
    this.mCurrentIteration = 0;
    this.mPlayingState = 0;
    this.mStarted = true;
    this.mStartedDelay = false;
    AnimationHandler localAnimationHandler = getOrCreateAnimationHandler();
    localAnimationHandler.mPendingAnimations.add(this);
    if (this.mStartDelay == 0L)
    {
      setCurrentPlayTime(0L);
      this.mPlayingState = 0;
      this.mRunning = true;
      notifyStartListeners();
    }
    localAnimationHandler.start();
  }
  
  private void startAnimation(AnimationHandler paramAnimationHandler)
  {
    initAnimation();
    paramAnimationHandler.mAnimations.add(this);
    if ((this.mStartDelay > 0L) && (this.mListeners != null)) {
      notifyStartListeners();
    }
  }
  
  public void addUpdateListener(AnimatorUpdateListener paramAnimatorUpdateListener)
  {
    if (this.mUpdateListeners == null) {
      this.mUpdateListeners = new ArrayList();
    }
    this.mUpdateListeners.add(paramAnimatorUpdateListener);
  }
  
  void animateValue(float paramFloat)
  {
    float f = this.mInterpolator.getInterpolation(paramFloat);
    this.mCurrentFraction = f;
    int i = this.mValues.length;
    for (int j = 0; j < i; j++) {
      this.mValues[j].calculateValue(f);
    }
    if (this.mUpdateListeners != null)
    {
      int k = this.mUpdateListeners.size();
      for (int m = 0; m < k; m++) {
        ((AnimatorUpdateListener)this.mUpdateListeners.get(m)).onAnimationUpdate(this);
      }
    }
  }
  
  boolean animationFrame(long paramLong)
  {
    switch (this.mPlayingState)
    {
    default: 
      return false;
    }
    if (this.mDuration > 0L) {}
    boolean bool2;
    for (float f = (float)(paramLong - this.mStartTime) / (float)this.mDuration;; f = 1.0F)
    {
      boolean bool1 = f < 1.0F;
      bool2 = false;
      if (bool1) {
        break label192;
      }
      if ((this.mCurrentIteration >= this.mRepeatCount) && (this.mRepeatCount != -1)) {
        break label217;
      }
      if (this.mListeners == null) {
        break;
      }
      int i = this.mListeners.size();
      for (int j = 0; j < i; j++) {
        ((Animator.AnimatorListener)this.mListeners.get(j)).onAnimationRepeat(this);
      }
    }
    boolean bool3;
    if (this.mRepeatMode == 2)
    {
      if (this.mPlayingBackwards)
      {
        bool3 = false;
        this.mPlayingBackwards = bool3;
      }
    }
    else
    {
      this.mCurrentIteration += (int)f;
      f %= 1.0F;
      this.mStartTime += this.mDuration;
    }
    for (;;)
    {
      label192:
      if (this.mPlayingBackwards) {
        f = 1.0F - f;
      }
      animateValue(f);
      return bool2;
      bool3 = true;
      break;
      label217:
      bool2 = true;
      f = Math.min(f, 1.0F);
    }
  }
  
  public void cancel()
  {
    AnimationHandler localAnimationHandler = getOrCreateAnimationHandler();
    if ((this.mPlayingState != 0) || (localAnimationHandler.mPendingAnimations.contains(this)) || (localAnimationHandler.mDelayedAnims.contains(this)))
    {
      if (((this.mStarted) || (this.mRunning)) && (this.mListeners != null))
      {
        if (!this.mRunning) {
          notifyStartListeners();
        }
        Iterator localIterator = ((ArrayList)this.mListeners.clone()).iterator();
        while (localIterator.hasNext()) {
          ((Animator.AnimatorListener)localIterator.next()).onAnimationCancel(this);
        }
      }
      endAnimation(localAnimationHandler);
    }
  }
  
  public ValueAnimator clone()
  {
    ValueAnimator localValueAnimator = (ValueAnimator)super.clone();
    if (this.mUpdateListeners != null)
    {
      ArrayList localArrayList = this.mUpdateListeners;
      localValueAnimator.mUpdateListeners = new ArrayList();
      int k = localArrayList.size();
      for (int m = 0; m < k; m++) {
        localValueAnimator.mUpdateListeners.add(localArrayList.get(m));
      }
    }
    localValueAnimator.mSeekTime = -1L;
    localValueAnimator.mPlayingBackwards = false;
    localValueAnimator.mCurrentIteration = 0;
    localValueAnimator.mInitialized = false;
    localValueAnimator.mPlayingState = 0;
    localValueAnimator.mStartedDelay = false;
    PropertyValuesHolder[] arrayOfPropertyValuesHolder = this.mValues;
    if (arrayOfPropertyValuesHolder != null)
    {
      int i = arrayOfPropertyValuesHolder.length;
      localValueAnimator.mValues = new PropertyValuesHolder[i];
      localValueAnimator.mValuesMap = new HashMap(i);
      for (int j = 0; j < i; j++)
      {
        PropertyValuesHolder localPropertyValuesHolder = arrayOfPropertyValuesHolder[j].clone();
        localValueAnimator.mValues[j] = localPropertyValuesHolder;
        localValueAnimator.mValuesMap.put(localPropertyValuesHolder.getPropertyName(), localPropertyValuesHolder);
      }
    }
    return localValueAnimator;
  }
  
  final boolean doAnimationFrame(long paramLong)
  {
    if (this.mPlayingState == 0)
    {
      this.mPlayingState = 1;
      if (this.mSeekTime >= 0L) {
        break label39;
      }
      this.mStartTime = paramLong;
    }
    for (;;)
    {
      return animationFrame(Math.max(paramLong, this.mStartTime));
      label39:
      this.mStartTime = (paramLong - this.mSeekTime);
      this.mSeekTime = -1L;
    }
  }
  
  public void end()
  {
    AnimationHandler localAnimationHandler = getOrCreateAnimationHandler();
    if ((!localAnimationHandler.mAnimations.contains(this)) && (!localAnimationHandler.mPendingAnimations.contains(this)))
    {
      this.mStartedDelay = false;
      startAnimation(localAnimationHandler);
      this.mStarted = true;
      if (!this.mPlayingBackwards) {
        break label76;
      }
    }
    label76:
    for (float f = 0.0F;; f = 1.0F)
    {
      animateValue(f);
      endAnimation(localAnimationHandler);
      return;
      if (this.mInitialized) {
        break;
      }
      initAnimation();
      break;
    }
  }
  
  public float getAnimatedFraction()
  {
    return this.mCurrentFraction;
  }
  
  public Object getAnimatedValue()
  {
    if ((this.mValues != null) && (this.mValues.length > 0)) {
      return this.mValues[0].getAnimatedValue();
    }
    return null;
  }
  
  public Object getAnimatedValue(String paramString)
  {
    PropertyValuesHolder localPropertyValuesHolder = (PropertyValuesHolder)this.mValuesMap.get(paramString);
    if (localPropertyValuesHolder != null) {
      return localPropertyValuesHolder.getAnimatedValue();
    }
    return null;
  }
  
  public long getCurrentPlayTime()
  {
    if ((!this.mInitialized) || (this.mPlayingState == 0)) {
      return 0L;
    }
    return AnimationUtils.currentAnimationTimeMillis() - this.mStartTime;
  }
  
  public long getDuration()
  {
    return this.mUnscaledDuration;
  }
  
  public TimeInterpolator getInterpolator()
  {
    return this.mInterpolator;
  }
  
  public int getRepeatCount()
  {
    return this.mRepeatCount;
  }
  
  public int getRepeatMode()
  {
    return this.mRepeatMode;
  }
  
  public long getStartDelay()
  {
    return this.mUnscaledStartDelay;
  }
  
  public PropertyValuesHolder[] getValues()
  {
    return this.mValues;
  }
  
  void initAnimation()
  {
    if (!this.mInitialized)
    {
      int i = this.mValues.length;
      for (int j = 0; j < i; j++) {
        this.mValues[j].init();
      }
      this.mInitialized = true;
    }
  }
  
  public boolean isRunning()
  {
    return (this.mPlayingState == 1) || (this.mRunning);
  }
  
  public boolean isStarted()
  {
    return this.mStarted;
  }
  
  public void removeAllUpdateListeners()
  {
    if (this.mUpdateListeners == null) {
      return;
    }
    this.mUpdateListeners.clear();
    this.mUpdateListeners = null;
  }
  
  public void removeUpdateListener(AnimatorUpdateListener paramAnimatorUpdateListener)
  {
    if (this.mUpdateListeners == null) {}
    do
    {
      return;
      this.mUpdateListeners.remove(paramAnimatorUpdateListener);
    } while (this.mUpdateListeners.size() != 0);
    this.mUpdateListeners = null;
  }
  
  public void reverse()
  {
    if (!this.mPlayingBackwards) {}
    for (boolean bool = true;; bool = false)
    {
      this.mPlayingBackwards = bool;
      if (this.mPlayingState != 1) {
        break;
      }
      long l1 = AnimationUtils.currentAnimationTimeMillis();
      long l2 = l1 - this.mStartTime;
      this.mStartTime = (l1 - (this.mDuration - l2));
      return;
    }
    start(true);
  }
  
  public void setCurrentPlayTime(long paramLong)
  {
    initAnimation();
    long l = AnimationUtils.currentAnimationTimeMillis();
    if (this.mPlayingState != 1)
    {
      this.mSeekTime = paramLong;
      this.mPlayingState = 2;
    }
    this.mStartTime = (l - paramLong);
    doAnimationFrame(l);
  }
  
  public ValueAnimator setDuration(long paramLong)
  {
    if (paramLong < 0L) {
      throw new IllegalArgumentException("Animators cannot have negative duration: " + paramLong);
    }
    this.mUnscaledDuration = paramLong;
    this.mDuration = (((float)paramLong * sDurationScale));
    return this;
  }
  
  public void setEvaluator(TypeEvaluator paramTypeEvaluator)
  {
    if ((paramTypeEvaluator != null) && (this.mValues != null) && (this.mValues.length > 0)) {
      this.mValues[0].setEvaluator(paramTypeEvaluator);
    }
  }
  
  public void setFloatValues(float... paramVarArgs)
  {
    if ((paramVarArgs == null) || (paramVarArgs.length == 0)) {
      return;
    }
    if ((this.mValues == null) || (this.mValues.length == 0))
    {
      PropertyValuesHolder[] arrayOfPropertyValuesHolder = new PropertyValuesHolder[1];
      arrayOfPropertyValuesHolder[0] = PropertyValuesHolder.ofFloat("", paramVarArgs);
      setValues(arrayOfPropertyValuesHolder);
    }
    for (;;)
    {
      this.mInitialized = false;
      return;
      this.mValues[0].setFloatValues(paramVarArgs);
    }
  }
  
  public void setIntValues(int... paramVarArgs)
  {
    if ((paramVarArgs == null) || (paramVarArgs.length == 0)) {
      return;
    }
    if ((this.mValues == null) || (this.mValues.length == 0))
    {
      PropertyValuesHolder[] arrayOfPropertyValuesHolder = new PropertyValuesHolder[1];
      arrayOfPropertyValuesHolder[0] = PropertyValuesHolder.ofInt("", paramVarArgs);
      setValues(arrayOfPropertyValuesHolder);
    }
    for (;;)
    {
      this.mInitialized = false;
      return;
      this.mValues[0].setIntValues(paramVarArgs);
    }
  }
  
  public void setInterpolator(TimeInterpolator paramTimeInterpolator)
  {
    if (paramTimeInterpolator != null)
    {
      this.mInterpolator = paramTimeInterpolator;
      return;
    }
    this.mInterpolator = new LinearInterpolator();
  }
  
  public void setObjectValues(Object... paramVarArgs)
  {
    if ((paramVarArgs == null) || (paramVarArgs.length == 0)) {
      return;
    }
    if ((this.mValues == null) || (this.mValues.length == 0))
    {
      PropertyValuesHolder[] arrayOfPropertyValuesHolder = new PropertyValuesHolder[1];
      arrayOfPropertyValuesHolder[0] = PropertyValuesHolder.ofObject("", (TypeEvaluator)null, paramVarArgs);
      setValues(arrayOfPropertyValuesHolder);
    }
    for (;;)
    {
      this.mInitialized = false;
      return;
      this.mValues[0].setObjectValues(paramVarArgs);
    }
  }
  
  public void setRepeatCount(int paramInt)
  {
    this.mRepeatCount = paramInt;
  }
  
  public void setRepeatMode(int paramInt)
  {
    this.mRepeatMode = paramInt;
  }
  
  public void setStartDelay(long paramLong)
  {
    this.mStartDelay = (((float)paramLong * sDurationScale));
    this.mUnscaledStartDelay = paramLong;
  }
  
  public void setValues(PropertyValuesHolder... paramVarArgs)
  {
    int i = paramVarArgs.length;
    this.mValues = paramVarArgs;
    this.mValuesMap = new HashMap(i);
    for (int j = 0; j < i; j++)
    {
      PropertyValuesHolder localPropertyValuesHolder = paramVarArgs[j];
      this.mValuesMap.put(localPropertyValuesHolder.getPropertyName(), localPropertyValuesHolder);
    }
    this.mInitialized = false;
  }
  
  public void start()
  {
    start(false);
  }
  
  public String toString()
  {
    String str = "ValueAnimator@" + Integer.toHexString(hashCode());
    if (this.mValues != null) {
      for (int i = 0; i < this.mValues.length; i++) {
        str = str + "\n    " + this.mValues[i].toString();
      }
    }
    return str;
  }
  
  private static class AnimationHandler
    implements Runnable
  {
    private boolean mAnimationScheduled;
    private final ArrayList<ValueAnimator> mAnimations = new ArrayList();
    private final Choreographer mChoreographer = Choreographer.getInstance();
    private final ArrayList<ValueAnimator> mDelayedAnims = new ArrayList();
    private final ArrayList<ValueAnimator> mEndingAnims = new ArrayList();
    private final ArrayList<ValueAnimator> mPendingAnimations = new ArrayList();
    private final ArrayList<ValueAnimator> mReadyAnims = new ArrayList();
    private final ArrayList<ValueAnimator> mTmpAnimations = new ArrayList();
    
    private void doAnimationFrame(long paramLong)
    {
      while (this.mPendingAnimations.size() > 0)
      {
        ArrayList localArrayList = (ArrayList)this.mPendingAnimations.clone();
        this.mPendingAnimations.clear();
        int i4 = localArrayList.size();
        int i5 = 0;
        if (i5 < i4)
        {
          ValueAnimator localValueAnimator4 = (ValueAnimator)localArrayList.get(i5);
          if (localValueAnimator4.mStartDelay == 0L) {
            localValueAnimator4.startAnimation(this);
          }
          for (;;)
          {
            i5++;
            break;
            this.mDelayedAnims.add(localValueAnimator4);
          }
        }
      }
      int i = this.mDelayedAnims.size();
      for (int j = 0; j < i; j++)
      {
        ValueAnimator localValueAnimator3 = (ValueAnimator)this.mDelayedAnims.get(j);
        if (localValueAnimator3.delayedAnimationFrame(paramLong)) {
          this.mReadyAnims.add(localValueAnimator3);
        }
      }
      int k = this.mReadyAnims.size();
      if (k > 0)
      {
        for (int i3 = 0; i3 < k; i3++)
        {
          ValueAnimator localValueAnimator2 = (ValueAnimator)this.mReadyAnims.get(i3);
          localValueAnimator2.startAnimation(this);
          ValueAnimator.access$302(localValueAnimator2, true);
          this.mDelayedAnims.remove(localValueAnimator2);
        }
        this.mReadyAnims.clear();
      }
      int m = this.mAnimations.size();
      for (int n = 0; n < m; n++) {
        this.mTmpAnimations.add(this.mAnimations.get(n));
      }
      for (int i1 = 0; i1 < m; i1++)
      {
        ValueAnimator localValueAnimator1 = (ValueAnimator)this.mTmpAnimations.get(i1);
        if ((this.mAnimations.contains(localValueAnimator1)) && (localValueAnimator1.doAnimationFrame(paramLong))) {
          this.mEndingAnims.add(localValueAnimator1);
        }
      }
      this.mTmpAnimations.clear();
      if (this.mEndingAnims.size() > 0)
      {
        for (int i2 = 0; i2 < this.mEndingAnims.size(); i2++) {
          ((ValueAnimator)this.mEndingAnims.get(i2)).endAnimation(this);
        }
        this.mEndingAnims.clear();
      }
      if ((!this.mAnimations.isEmpty()) || (!this.mDelayedAnims.isEmpty())) {
        scheduleAnimation();
      }
    }
    
    private void scheduleAnimation()
    {
      if (!this.mAnimationScheduled)
      {
        this.mChoreographer.postCallback(1, this, null);
        this.mAnimationScheduled = true;
      }
    }
    
    public void run()
    {
      this.mAnimationScheduled = false;
      doAnimationFrame(this.mChoreographer.getFrameTime());
    }
    
    public void start()
    {
      scheduleAnimation();
    }
  }
  
  public static abstract interface AnimatorUpdateListener
  {
    public abstract void onAnimationUpdate(ValueAnimator paramValueAnimator);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\animation\ValueAnimator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
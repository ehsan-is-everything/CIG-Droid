package android.database;

import android.content.ContentValues;
import android.content.Context;
import android.content.OperationApplicationException;
import android.database.sqlite.SQLiteAbortException;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabaseCorruptException;
import android.database.sqlite.SQLiteDiskIOException;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteFullException;
import android.database.sqlite.SQLiteProgram;
import android.database.sqlite.SQLiteStatement;
import android.os.OperationCanceledException;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.util.Log;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.text.CollationKey;
import java.text.Collator;
import java.util.HashMap;
import java.util.Locale;
import org.apache.commons.codec.binary.Hex;

public class DatabaseUtils
{
  private static final boolean DEBUG = false;
  public static final int STATEMENT_ABORT = 6;
  public static final int STATEMENT_ATTACH = 3;
  public static final int STATEMENT_BEGIN = 4;
  public static final int STATEMENT_COMMIT = 5;
  public static final int STATEMENT_DDL = 8;
  public static final int STATEMENT_OTHER = 99;
  public static final int STATEMENT_PRAGMA = 7;
  public static final int STATEMENT_SELECT = 1;
  public static final int STATEMENT_UNPREPARED = 9;
  public static final int STATEMENT_UPDATE = 2;
  private static final String TAG = "DatabaseUtils";
  private static Collator mColl = null;
  
  public static void appendEscapedSQLString(StringBuilder paramStringBuilder, String paramString)
  {
    paramStringBuilder.append('\'');
    if (paramString.indexOf('\'') != -1)
    {
      int i = paramString.length();
      for (int j = 0; j < i; j++)
      {
        char c = paramString.charAt(j);
        if (c == '\'') {
          paramStringBuilder.append('\'');
        }
        paramStringBuilder.append(c);
      }
    }
    paramStringBuilder.append(paramString);
    paramStringBuilder.append('\'');
  }
  
  public static String[] appendSelectionArgs(String[] paramArrayOfString1, String[] paramArrayOfString2)
  {
    if ((paramArrayOfString1 == null) || (paramArrayOfString1.length == 0)) {
      return paramArrayOfString2;
    }
    String[] arrayOfString = new String[paramArrayOfString1.length + paramArrayOfString2.length];
    System.arraycopy(paramArrayOfString1, 0, arrayOfString, 0, paramArrayOfString1.length);
    System.arraycopy(paramArrayOfString2, 0, arrayOfString, paramArrayOfString1.length, paramArrayOfString2.length);
    return arrayOfString;
  }
  
  public static final void appendValueToSql(StringBuilder paramStringBuilder, Object paramObject)
  {
    if (paramObject == null)
    {
      paramStringBuilder.append("NULL");
      return;
    }
    if ((paramObject instanceof Boolean))
    {
      if (((Boolean)paramObject).booleanValue())
      {
        paramStringBuilder.append('1');
        return;
      }
      paramStringBuilder.append('0');
      return;
    }
    appendEscapedSQLString(paramStringBuilder, paramObject.toString());
  }
  
  public static void bindObjectToProgram(SQLiteProgram paramSQLiteProgram, int paramInt, Object paramObject)
  {
    if (paramObject == null)
    {
      paramSQLiteProgram.bindNull(paramInt);
      return;
    }
    if (((paramObject instanceof Double)) || ((paramObject instanceof Float)))
    {
      paramSQLiteProgram.bindDouble(paramInt, ((Number)paramObject).doubleValue());
      return;
    }
    if ((paramObject instanceof Number))
    {
      paramSQLiteProgram.bindLong(paramInt, ((Number)paramObject).longValue());
      return;
    }
    if ((paramObject instanceof Boolean))
    {
      if (((Boolean)paramObject).booleanValue())
      {
        paramSQLiteProgram.bindLong(paramInt, 1L);
        return;
      }
      paramSQLiteProgram.bindLong(paramInt, 0L);
      return;
    }
    if ((paramObject instanceof byte[]))
    {
      paramSQLiteProgram.bindBlob(paramInt, (byte[])paramObject);
      return;
    }
    paramSQLiteProgram.bindString(paramInt, paramObject.toString());
  }
  
  public static ParcelFileDescriptor blobFileDescriptorForQuery(SQLiteDatabase paramSQLiteDatabase, String paramString, String[] paramArrayOfString)
  {
    SQLiteStatement localSQLiteStatement = paramSQLiteDatabase.compileStatement(paramString);
    try
    {
      ParcelFileDescriptor localParcelFileDescriptor = blobFileDescriptorForQuery(localSQLiteStatement, paramArrayOfString);
      return localParcelFileDescriptor;
    }
    finally
    {
      localSQLiteStatement.close();
    }
  }
  
  public static ParcelFileDescriptor blobFileDescriptorForQuery(SQLiteStatement paramSQLiteStatement, String[] paramArrayOfString)
  {
    paramSQLiteStatement.bindAllArgsAsStrings(paramArrayOfString);
    return paramSQLiteStatement.simpleQueryForBlobFileDescriptor();
  }
  
  public static String concatenateWhere(String paramString1, String paramString2)
  {
    if (TextUtils.isEmpty(paramString1)) {
      return paramString2;
    }
    if (TextUtils.isEmpty(paramString2)) {
      return paramString1;
    }
    return "(" + paramString1 + ") AND (" + paramString2 + ")";
  }
  
  public static void createDbFromSqlStatements(Context paramContext, String paramString1, int paramInt, String paramString2)
  {
    SQLiteDatabase localSQLiteDatabase = paramContext.openOrCreateDatabase(paramString1, 0, null);
    String[] arrayOfString = TextUtils.split(paramString2, ";\n");
    int i = arrayOfString.length;
    int j = 0;
    if (j < i)
    {
      String str = arrayOfString[j];
      if (TextUtils.isEmpty(str)) {}
      for (;;)
      {
        j++;
        break;
        localSQLiteDatabase.execSQL(str);
      }
    }
    localSQLiteDatabase.setVersion(paramInt);
    localSQLiteDatabase.close();
  }
  
  public static void cursorDoubleToContentValues(Cursor paramCursor, String paramString1, ContentValues paramContentValues, String paramString2)
  {
    int i = paramCursor.getColumnIndex(paramString1);
    if (!paramCursor.isNull(i))
    {
      paramContentValues.put(paramString2, Double.valueOf(paramCursor.getDouble(i)));
      return;
    }
    paramContentValues.put(paramString2, (Double)null);
  }
  
  public static void cursorDoubleToContentValuesIfPresent(Cursor paramCursor, ContentValues paramContentValues, String paramString)
  {
    int i = paramCursor.getColumnIndex(paramString);
    if ((i != -1) && (!paramCursor.isNull(i))) {
      paramContentValues.put(paramString, Double.valueOf(paramCursor.getDouble(i)));
    }
  }
  
  public static void cursorDoubleToCursorValues(Cursor paramCursor, String paramString, ContentValues paramContentValues)
  {
    cursorDoubleToContentValues(paramCursor, paramString, paramContentValues, paramString);
  }
  
  public static void cursorFillWindow(Cursor paramCursor, int paramInt, CursorWindow paramCursorWindow)
  {
    if ((paramInt < 0) || (paramInt >= paramCursor.getCount())) {
      return;
    }
    int i = paramCursor.getPosition();
    int j = paramCursor.getColumnCount();
    paramCursorWindow.clear();
    paramCursorWindow.setStartPosition(paramInt);
    paramCursorWindow.setNumColumns(j);
    if (paramCursor.moveToPosition(paramInt))
    {
      if (paramCursorWindow.allocRow()) {}
    }
    else
    {
      label63:
      paramCursor.moveToPosition(i);
      return;
    }
    label279:
    for (int k = 0;; k++)
    {
      boolean bool;
      if (k < j) {
        switch (paramCursor.getType(k))
        {
        case 3: 
        default: 
          String str = paramCursor.getString(k);
          if (str != null) {
            bool = paramCursorWindow.putString(str, paramInt, k);
          }
          break;
        }
      }
      for (;;)
      {
        if (bool) {
          break label279;
        }
        paramCursorWindow.freeLastRow();
        paramInt++;
        if (paramCursor.moveToNext()) {
          break;
        }
        break label63;
        bool = paramCursorWindow.putNull(paramInt, k);
        continue;
        bool = paramCursorWindow.putLong(paramCursor.getLong(k), paramInt, k);
        continue;
        bool = paramCursorWindow.putDouble(paramCursor.getDouble(k), paramInt, k);
        continue;
        byte[] arrayOfByte = paramCursor.getBlob(k);
        if (arrayOfByte != null) {}
        for (bool = paramCursorWindow.putBlob(arrayOfByte, paramInt, k);; bool = paramCursorWindow.putNull(paramInt, k)) {
          break;
        }
        bool = paramCursorWindow.putNull(paramInt, k);
      }
    }
  }
  
  public static void cursorFloatToContentValuesIfPresent(Cursor paramCursor, ContentValues paramContentValues, String paramString)
  {
    int i = paramCursor.getColumnIndex(paramString);
    if ((i != -1) && (!paramCursor.isNull(i))) {
      paramContentValues.put(paramString, Float.valueOf(paramCursor.getFloat(i)));
    }
  }
  
  public static void cursorIntToContentValues(Cursor paramCursor, String paramString, ContentValues paramContentValues)
  {
    cursorIntToContentValues(paramCursor, paramString, paramContentValues, paramString);
  }
  
  public static void cursorIntToContentValues(Cursor paramCursor, String paramString1, ContentValues paramContentValues, String paramString2)
  {
    int i = paramCursor.getColumnIndex(paramString1);
    if (!paramCursor.isNull(i))
    {
      paramContentValues.put(paramString2, Integer.valueOf(paramCursor.getInt(i)));
      return;
    }
    paramContentValues.put(paramString2, (Integer)null);
  }
  
  public static void cursorIntToContentValuesIfPresent(Cursor paramCursor, ContentValues paramContentValues, String paramString)
  {
    int i = paramCursor.getColumnIndex(paramString);
    if ((i != -1) && (!paramCursor.isNull(i))) {
      paramContentValues.put(paramString, Integer.valueOf(paramCursor.getInt(i)));
    }
  }
  
  public static void cursorLongToContentValues(Cursor paramCursor, String paramString, ContentValues paramContentValues)
  {
    cursorLongToContentValues(paramCursor, paramString, paramContentValues, paramString);
  }
  
  public static void cursorLongToContentValues(Cursor paramCursor, String paramString1, ContentValues paramContentValues, String paramString2)
  {
    int i = paramCursor.getColumnIndex(paramString1);
    if (!paramCursor.isNull(i))
    {
      paramContentValues.put(paramString2, Long.valueOf(paramCursor.getLong(i)));
      return;
    }
    paramContentValues.put(paramString2, (Long)null);
  }
  
  public static void cursorLongToContentValuesIfPresent(Cursor paramCursor, ContentValues paramContentValues, String paramString)
  {
    int i = paramCursor.getColumnIndex(paramString);
    if ((i != -1) && (!paramCursor.isNull(i))) {
      paramContentValues.put(paramString, Long.valueOf(paramCursor.getLong(i)));
    }
  }
  
  public static int cursorPickFillWindowStartPosition(int paramInt1, int paramInt2)
  {
    return Math.max(paramInt1 - paramInt2 / 3, 0);
  }
  
  public static void cursorRowToContentValues(Cursor paramCursor, ContentValues paramContentValues)
  {
    AbstractWindowedCursor localAbstractWindowedCursor;
    String[] arrayOfString;
    int j;
    if ((paramCursor instanceof AbstractWindowedCursor))
    {
      localAbstractWindowedCursor = (AbstractWindowedCursor)paramCursor;
      arrayOfString = paramCursor.getColumnNames();
      int i = arrayOfString.length;
      j = 0;
      label26:
      if (j >= i) {
        return;
      }
      if ((localAbstractWindowedCursor == null) || (!localAbstractWindowedCursor.isBlob(j))) {
        break label73;
      }
      paramContentValues.put(arrayOfString[j], paramCursor.getBlob(j));
    }
    for (;;)
    {
      j++;
      break label26;
      localAbstractWindowedCursor = null;
      break;
      label73:
      paramContentValues.put(arrayOfString[j], paramCursor.getString(j));
    }
  }
  
  public static void cursorShortToContentValuesIfPresent(Cursor paramCursor, ContentValues paramContentValues, String paramString)
  {
    int i = paramCursor.getColumnIndex(paramString);
    if ((i != -1) && (!paramCursor.isNull(i))) {
      paramContentValues.put(paramString, Short.valueOf(paramCursor.getShort(i)));
    }
  }
  
  public static void cursorStringToContentValues(Cursor paramCursor, String paramString, ContentValues paramContentValues)
  {
    cursorStringToContentValues(paramCursor, paramString, paramContentValues, paramString);
  }
  
  public static void cursorStringToContentValues(Cursor paramCursor, String paramString1, ContentValues paramContentValues, String paramString2)
  {
    paramContentValues.put(paramString2, paramCursor.getString(paramCursor.getColumnIndexOrThrow(paramString1)));
  }
  
  public static void cursorStringToContentValuesIfPresent(Cursor paramCursor, ContentValues paramContentValues, String paramString)
  {
    int i = paramCursor.getColumnIndex(paramString);
    if ((i != -1) && (!paramCursor.isNull(i))) {
      paramContentValues.put(paramString, paramCursor.getString(i));
    }
  }
  
  public static void cursorStringToInsertHelper(Cursor paramCursor, String paramString, InsertHelper paramInsertHelper, int paramInt)
  {
    paramInsertHelper.bind(paramInt, paramCursor.getString(paramCursor.getColumnIndexOrThrow(paramString)));
  }
  
  public static void dumpCurrentRow(Cursor paramCursor)
  {
    dumpCurrentRow(paramCursor, System.out);
  }
  
  public static void dumpCurrentRow(Cursor paramCursor, PrintStream paramPrintStream)
  {
    String[] arrayOfString = paramCursor.getColumnNames();
    paramPrintStream.println("" + paramCursor.getPosition() + " {");
    int i = arrayOfString.length;
    for (int j = 0;; j++)
    {
      if (j >= i) {
        break label121;
      }
      try
      {
        String str2 = paramCursor.getString(j);
        str1 = str2;
      }
      catch (SQLiteException localSQLiteException)
      {
        for (;;)
        {
          String str1 = "<unprintable>";
        }
      }
      paramPrintStream.println("   " + arrayOfString[j] + '=' + str1);
    }
    label121:
    paramPrintStream.println("}");
  }
  
  public static void dumpCurrentRow(Cursor paramCursor, StringBuilder paramStringBuilder)
  {
    String[] arrayOfString = paramCursor.getColumnNames();
    paramStringBuilder.append("" + paramCursor.getPosition() + " {\n");
    int i = arrayOfString.length;
    for (int j = 0;; j++)
    {
      if (j >= i) {
        break label131;
      }
      try
      {
        String str2 = paramCursor.getString(j);
        str1 = str2;
      }
      catch (SQLiteException localSQLiteException)
      {
        for (;;)
        {
          String str1 = "<unprintable>";
        }
      }
      paramStringBuilder.append("   " + arrayOfString[j] + '=' + str1 + "\n");
    }
    label131:
    paramStringBuilder.append("}\n");
  }
  
  public static String dumpCurrentRowToString(Cursor paramCursor)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    dumpCurrentRow(paramCursor, localStringBuilder);
    return localStringBuilder.toString();
  }
  
  public static void dumpCursor(Cursor paramCursor)
  {
    dumpCursor(paramCursor, System.out);
  }
  
  public static void dumpCursor(Cursor paramCursor, PrintStream paramPrintStream)
  {
    paramPrintStream.println(">>>>> Dumping cursor " + paramCursor);
    if (paramCursor != null)
    {
      int i = paramCursor.getPosition();
      paramCursor.moveToPosition(-1);
      while (paramCursor.moveToNext()) {
        dumpCurrentRow(paramCursor, paramPrintStream);
      }
      paramCursor.moveToPosition(i);
    }
    paramPrintStream.println("<<<<<");
  }
  
  public static void dumpCursor(Cursor paramCursor, StringBuilder paramStringBuilder)
  {
    paramStringBuilder.append(">>>>> Dumping cursor " + paramCursor + "\n");
    if (paramCursor != null)
    {
      int i = paramCursor.getPosition();
      paramCursor.moveToPosition(-1);
      while (paramCursor.moveToNext()) {
        dumpCurrentRow(paramCursor, paramStringBuilder);
      }
      paramCursor.moveToPosition(i);
    }
    paramStringBuilder.append("<<<<<\n");
  }
  
  public static String dumpCursorToString(Cursor paramCursor)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    dumpCursor(paramCursor, localStringBuilder);
    return localStringBuilder.toString();
  }
  
  public static int findRowIdColumnIndex(String[] paramArrayOfString)
  {
    int i = paramArrayOfString.length;
    for (int j = 0; j < i; j++) {
      if (paramArrayOfString[j].equals("_id")) {
        return j;
      }
    }
    return -1;
  }
  
  public static String getCollationKey(String paramString)
  {
    byte[] arrayOfByte = getCollationKeyInBytes(paramString);
    try
    {
      String str = new String(arrayOfByte, 0, getKeyLen(arrayOfByte), "ISO8859_1");
      return str;
    }
    catch (Exception localException) {}
    return "";
  }
  
  private static byte[] getCollationKeyInBytes(String paramString)
  {
    if (mColl == null)
    {
      mColl = Collator.getInstance();
      mColl.setStrength(0);
    }
    return mColl.getCollationKey(paramString).toByteArray();
  }
  
  public static String getHexCollationKey(String paramString)
  {
    byte[] arrayOfByte = getCollationKeyInBytes(paramString);
    return new String(Hex.encodeHex(arrayOfByte), 0, 2 * getKeyLen(arrayOfByte));
  }
  
  private static int getKeyLen(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte[(-1 + paramArrayOfByte.length)] != 0) {
      return paramArrayOfByte.length;
    }
    return -1 + paramArrayOfByte.length;
  }
  
  public static int getSqlStatementType(String paramString)
  {
    String str1 = paramString.trim();
    if (str1.length() < 3) {}
    String str2;
    do
    {
      return 99;
      str2 = str1.substring(0, 3).toUpperCase(Locale.US);
      if (str2.equals("SEL")) {
        return 1;
      }
      if ((str2.equals("INS")) || (str2.equals("UPD")) || (str2.equals("REP")) || (str2.equals("DEL"))) {
        return 2;
      }
      if (str2.equals("ATT")) {
        return 3;
      }
      if (str2.equals("COM")) {
        return 5;
      }
      if (str2.equals("END")) {
        return 5;
      }
      if (str2.equals("ROL")) {
        return 6;
      }
      if (str2.equals("BEG")) {
        return 4;
      }
      if (str2.equals("PRA")) {
        return 7;
      }
      if ((str2.equals("CRE")) || (str2.equals("DRO")) || (str2.equals("ALT"))) {
        return 8;
      }
    } while ((!str2.equals("ANA")) && (!str2.equals("DET")));
    return 9;
  }
  
  public static int getTypeOfObject(Object paramObject)
  {
    if (paramObject == null) {
      return 0;
    }
    if ((paramObject instanceof byte[])) {
      return 4;
    }
    if (((paramObject instanceof Float)) || ((paramObject instanceof Double))) {
      return 2;
    }
    if (((paramObject instanceof Long)) || ((paramObject instanceof Integer)) || ((paramObject instanceof Short)) || ((paramObject instanceof Byte))) {
      return 1;
    }
    return 3;
  }
  
  public static long longForQuery(SQLiteDatabase paramSQLiteDatabase, String paramString, String[] paramArrayOfString)
  {
    SQLiteStatement localSQLiteStatement = paramSQLiteDatabase.compileStatement(paramString);
    try
    {
      long l = longForQuery(localSQLiteStatement, paramArrayOfString);
      return l;
    }
    finally
    {
      localSQLiteStatement.close();
    }
  }
  
  public static long longForQuery(SQLiteStatement paramSQLiteStatement, String[] paramArrayOfString)
  {
    paramSQLiteStatement.bindAllArgsAsStrings(paramArrayOfString);
    return paramSQLiteStatement.simpleQueryForLong();
  }
  
  public static long queryNumEntries(SQLiteDatabase paramSQLiteDatabase, String paramString)
  {
    return queryNumEntries(paramSQLiteDatabase, paramString, null, null);
  }
  
  public static long queryNumEntries(SQLiteDatabase paramSQLiteDatabase, String paramString1, String paramString2)
  {
    return queryNumEntries(paramSQLiteDatabase, paramString1, paramString2, null);
  }
  
  public static long queryNumEntries(SQLiteDatabase paramSQLiteDatabase, String paramString1, String paramString2, String[] paramArrayOfString)
  {
    if (!TextUtils.isEmpty(paramString2)) {}
    for (String str = " where " + paramString2;; str = "") {
      return longForQuery(paramSQLiteDatabase, "select count(*) from " + paramString1 + str, paramArrayOfString);
    }
  }
  
  public static final void readExceptionFromParcel(Parcel paramParcel)
  {
    int i = paramParcel.readExceptionCode();
    if (i == 0) {
      return;
    }
    readExceptionFromParcel(paramParcel, paramParcel.readString(), i);
  }
  
  private static final void readExceptionFromParcel(Parcel paramParcel, String paramString, int paramInt)
  {
    switch (paramInt)
    {
    case 10: 
    default: 
      paramParcel.readException(paramInt, paramString);
      return;
    case 2: 
      throw new IllegalArgumentException(paramString);
    case 3: 
      throw new UnsupportedOperationException(paramString);
    case 4: 
      throw new SQLiteAbortException(paramString);
    case 5: 
      throw new SQLiteConstraintException(paramString);
    case 6: 
      throw new SQLiteDatabaseCorruptException(paramString);
    case 7: 
      throw new SQLiteFullException(paramString);
    case 8: 
      throw new SQLiteDiskIOException(paramString);
    case 9: 
      throw new SQLiteException(paramString);
    }
    throw new OperationCanceledException(paramString);
  }
  
  public static void readExceptionWithFileNotFoundExceptionFromParcel(Parcel paramParcel)
    throws FileNotFoundException
  {
    int i = paramParcel.readExceptionCode();
    if (i == 0) {
      return;
    }
    String str = paramParcel.readString();
    if (i == 1) {
      throw new FileNotFoundException(str);
    }
    readExceptionFromParcel(paramParcel, str, i);
  }
  
  public static void readExceptionWithOperationApplicationExceptionFromParcel(Parcel paramParcel)
    throws OperationApplicationException
  {
    int i = paramParcel.readExceptionCode();
    if (i == 0) {
      return;
    }
    String str = paramParcel.readString();
    if (i == 10) {
      throw new OperationApplicationException(str);
    }
    readExceptionFromParcel(paramParcel, str, i);
  }
  
  public static String sqlEscapeString(String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    appendEscapedSQLString(localStringBuilder, paramString);
    return localStringBuilder.toString();
  }
  
  public static String stringForQuery(SQLiteDatabase paramSQLiteDatabase, String paramString, String[] paramArrayOfString)
  {
    SQLiteStatement localSQLiteStatement = paramSQLiteDatabase.compileStatement(paramString);
    try
    {
      String str = stringForQuery(localSQLiteStatement, paramArrayOfString);
      return str;
    }
    finally
    {
      localSQLiteStatement.close();
    }
  }
  
  public static String stringForQuery(SQLiteStatement paramSQLiteStatement, String[] paramArrayOfString)
  {
    paramSQLiteStatement.bindAllArgsAsStrings(paramArrayOfString);
    return paramSQLiteStatement.simpleQueryForString();
  }
  
  public static final void writeExceptionToParcel(Parcel paramParcel, Exception paramException)
  {
    int i = 1;
    int j;
    if ((paramException instanceof FileNotFoundException))
    {
      j = 1;
      i = 0;
    }
    for (;;)
    {
      paramParcel.writeInt(j);
      paramParcel.writeString(paramException.getMessage());
      if (i != 0) {
        Log.e("DatabaseUtils", "Writing exception to parcel", paramException);
      }
      return;
      if ((paramException instanceof IllegalArgumentException))
      {
        j = 2;
      }
      else if ((paramException instanceof UnsupportedOperationException))
      {
        j = 3;
      }
      else if ((paramException instanceof SQLiteAbortException))
      {
        j = 4;
      }
      else if ((paramException instanceof SQLiteConstraintException))
      {
        j = 5;
      }
      else if ((paramException instanceof SQLiteDatabaseCorruptException))
      {
        j = 6;
      }
      else if ((paramException instanceof SQLiteFullException))
      {
        j = 7;
      }
      else if ((paramException instanceof SQLiteDiskIOException))
      {
        j = 8;
      }
      else if ((paramException instanceof SQLiteException))
      {
        j = 9;
      }
      else if ((paramException instanceof OperationApplicationException))
      {
        j = 10;
      }
      else
      {
        if (!(paramException instanceof OperationCanceledException)) {
          break;
        }
        j = 11;
        i = 0;
      }
    }
    paramParcel.writeException(paramException);
    Log.e("DatabaseUtils", "Writing exception to parcel", paramException);
  }
  
  @Deprecated
  public static class InsertHelper
  {
    public static final int TABLE_INFO_PRAGMA_COLUMNNAME_INDEX = 1;
    public static final int TABLE_INFO_PRAGMA_DEFAULT_INDEX = 4;
    private HashMap<String, Integer> mColumns;
    private final SQLiteDatabase mDb;
    private String mInsertSQL = null;
    private SQLiteStatement mInsertStatement = null;
    private SQLiteStatement mPreparedStatement = null;
    private SQLiteStatement mReplaceStatement = null;
    private final String mTableName;
    
    public InsertHelper(SQLiteDatabase paramSQLiteDatabase, String paramString)
    {
      this.mDb = paramSQLiteDatabase;
      this.mTableName = paramString;
    }
    
    private void buildSQL()
      throws SQLException
    {
      StringBuilder localStringBuilder1 = new StringBuilder(128);
      localStringBuilder1.append("INSERT INTO ");
      localStringBuilder1.append(this.mTableName);
      localStringBuilder1.append(" (");
      StringBuilder localStringBuilder2 = new StringBuilder(128);
      localStringBuilder2.append("VALUES (");
      int i = 1;
      Cursor localCursor = null;
      for (;;)
      {
        try
        {
          localCursor = this.mDb.rawQuery("PRAGMA table_info(" + this.mTableName + ")", null);
          this.mColumns = new HashMap(localCursor.getCount());
          if (!localCursor.moveToNext()) {
            break;
          }
          String str1 = localCursor.getString(1);
          String str2 = localCursor.getString(4);
          this.mColumns.put(str1, Integer.valueOf(i));
          localStringBuilder1.append("'");
          localStringBuilder1.append(str1);
          localStringBuilder1.append("'");
          if (str2 == null)
          {
            localStringBuilder2.append("?");
            if (i == localCursor.getCount())
            {
              str3 = ") ";
              localStringBuilder1.append(str3);
              if (i != localCursor.getCount()) {
                break label298;
              }
              str4 = ");";
              localStringBuilder2.append(str4);
              i++;
            }
          }
          else
          {
            localStringBuilder2.append("COALESCE(?, ");
            localStringBuilder2.append(str2);
            localStringBuilder2.append(")");
            continue;
          }
          String str3 = ", ";
        }
        finally
        {
          if (localCursor != null) {
            localCursor.close();
          }
        }
        continue;
        label298:
        String str4 = ", ";
      }
      if (localCursor != null) {
        localCursor.close();
      }
      localStringBuilder1.append(localStringBuilder2);
      this.mInsertSQL = localStringBuilder1.toString();
    }
    
    private SQLiteStatement getStatement(boolean paramBoolean)
      throws SQLException
    {
      if (paramBoolean)
      {
        if (this.mReplaceStatement == null)
        {
          if (this.mInsertSQL == null) {
            buildSQL();
          }
          String str = "INSERT OR REPLACE" + this.mInsertSQL.substring(6);
          this.mReplaceStatement = this.mDb.compileStatement(str);
        }
        return this.mReplaceStatement;
      }
      if (this.mInsertStatement == null)
      {
        if (this.mInsertSQL == null) {
          buildSQL();
        }
        this.mInsertStatement = this.mDb.compileStatement(this.mInsertSQL);
      }
      return this.mInsertStatement;
    }
    
    /* Error */
    private long insertInternal(ContentValues paramContentValues, boolean paramBoolean)
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 37	android/database/DatabaseUtils$InsertHelper:mDb	Landroid/database/sqlite/SQLiteDatabase;
      //   4: invokevirtual 139	android/database/sqlite/SQLiteDatabase:beginTransactionNonExclusive	()V
      //   7: aload_0
      //   8: iload_2
      //   9: invokespecial 141	android/database/DatabaseUtils$InsertHelper:getStatement	(Z)Landroid/database/sqlite/SQLiteStatement;
      //   12: astore 6
      //   14: aload 6
      //   16: invokevirtual 146	android/database/sqlite/SQLiteStatement:clearBindings	()V
      //   19: aload_1
      //   20: invokevirtual 152	android/content/ContentValues:valueSet	()Ljava/util/Set;
      //   23: invokeinterface 158 1 0
      //   28: astore 7
      //   30: aload 7
      //   32: invokeinterface 163 1 0
      //   37: ifeq +96 -> 133
      //   40: aload 7
      //   42: invokeinterface 167 1 0
      //   47: checkcast 169	java/util/Map$Entry
      //   50: astore 10
      //   52: aload 6
      //   54: aload_0
      //   55: aload 10
      //   57: invokeinterface 172 1 0
      //   62: checkcast 127	java/lang/String
      //   65: invokevirtual 176	android/database/DatabaseUtils$InsertHelper:getColumnIndex	(Ljava/lang/String;)I
      //   68: aload 10
      //   70: invokeinterface 179 1 0
      //   75: invokestatic 185	android/database/DatabaseUtils:bindObjectToProgram	(Landroid/database/sqlite/SQLiteProgram;ILjava/lang/Object;)V
      //   78: goto -48 -> 30
      //   81: astore 4
      //   83: ldc -69
      //   85: new 44	java/lang/StringBuilder
      //   88: dup
      //   89: invokespecial 58	java/lang/StringBuilder:<init>	()V
      //   92: ldc -67
      //   94: invokevirtual 53	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   97: aload_1
      //   98: invokevirtual 192	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   101: ldc -62
      //   103: invokevirtual 53	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   106: aload_0
      //   107: getfield 39	android/database/DatabaseUtils$InsertHelper:mTableName	Ljava/lang/String;
      //   110: invokevirtual 53	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   113: invokevirtual 66	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   116: aload 4
      //   118: invokestatic 200	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   121: pop
      //   122: aload_0
      //   123: getfield 37	android/database/DatabaseUtils$InsertHelper:mDb	Landroid/database/sqlite/SQLiteDatabase;
      //   126: invokevirtual 203	android/database/sqlite/SQLiteDatabase:endTransaction	()V
      //   129: ldc2_w 204
      //   132: lreturn
      //   133: aload 6
      //   135: invokevirtual 209	android/database/sqlite/SQLiteStatement:executeInsert	()J
      //   138: lstore 8
      //   140: aload_0
      //   141: getfield 37	android/database/DatabaseUtils$InsertHelper:mDb	Landroid/database/sqlite/SQLiteDatabase;
      //   144: invokevirtual 212	android/database/sqlite/SQLiteDatabase:setTransactionSuccessful	()V
      //   147: aload_0
      //   148: getfield 37	android/database/DatabaseUtils$InsertHelper:mDb	Landroid/database/sqlite/SQLiteDatabase;
      //   151: invokevirtual 203	android/database/sqlite/SQLiteDatabase:endTransaction	()V
      //   154: lload 8
      //   156: lreturn
      //   157: astore_3
      //   158: aload_0
      //   159: getfield 37	android/database/DatabaseUtils$InsertHelper:mDb	Landroid/database/sqlite/SQLiteDatabase;
      //   162: invokevirtual 203	android/database/sqlite/SQLiteDatabase:endTransaction	()V
      //   165: aload_3
      //   166: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	167	0	this	InsertHelper
      //   0	167	1	paramContentValues	ContentValues
      //   0	167	2	paramBoolean	boolean
      //   157	9	3	localObject	Object
      //   81	36	4	localSQLException	SQLException
      //   12	122	6	localSQLiteStatement	SQLiteStatement
      //   28	13	7	localIterator	java.util.Iterator
      //   138	17	8	l	long
      //   50	19	10	localEntry	java.util.Map.Entry
      // Exception table:
      //   from	to	target	type
      //   7	30	81	android/database/SQLException
      //   30	78	81	android/database/SQLException
      //   133	147	81	android/database/SQLException
      //   7	30	157	finally
      //   30	78	157	finally
      //   83	122	157	finally
      //   133	147	157	finally
    }
    
    public void bind(int paramInt, double paramDouble)
    {
      this.mPreparedStatement.bindDouble(paramInt, paramDouble);
    }
    
    public void bind(int paramInt, float paramFloat)
    {
      this.mPreparedStatement.bindDouble(paramInt, paramFloat);
    }
    
    public void bind(int paramInt1, int paramInt2)
    {
      this.mPreparedStatement.bindLong(paramInt1, paramInt2);
    }
    
    public void bind(int paramInt, long paramLong)
    {
      this.mPreparedStatement.bindLong(paramInt, paramLong);
    }
    
    public void bind(int paramInt, String paramString)
    {
      if (paramString == null)
      {
        this.mPreparedStatement.bindNull(paramInt);
        return;
      }
      this.mPreparedStatement.bindString(paramInt, paramString);
    }
    
    public void bind(int paramInt, boolean paramBoolean)
    {
      SQLiteStatement localSQLiteStatement = this.mPreparedStatement;
      if (paramBoolean) {}
      for (long l = 1L;; l = 0L)
      {
        localSQLiteStatement.bindLong(paramInt, l);
        return;
      }
    }
    
    public void bind(int paramInt, byte[] paramArrayOfByte)
    {
      if (paramArrayOfByte == null)
      {
        this.mPreparedStatement.bindNull(paramInt);
        return;
      }
      this.mPreparedStatement.bindBlob(paramInt, paramArrayOfByte);
    }
    
    public void bindNull(int paramInt)
    {
      this.mPreparedStatement.bindNull(paramInt);
    }
    
    public void close()
    {
      if (this.mInsertStatement != null)
      {
        this.mInsertStatement.close();
        this.mInsertStatement = null;
      }
      if (this.mReplaceStatement != null)
      {
        this.mReplaceStatement.close();
        this.mReplaceStatement = null;
      }
      this.mInsertSQL = null;
      this.mColumns = null;
    }
    
    public long execute()
    {
      if (this.mPreparedStatement == null) {
        throw new IllegalStateException("you must prepare this inserter before calling execute");
      }
      try
      {
        long l = this.mPreparedStatement.executeInsert();
        return l;
      }
      catch (SQLException localSQLException)
      {
        Log.e("DatabaseUtils", "Error executing InsertHelper with table " + this.mTableName, localSQLException);
        return -1L;
      }
      finally
      {
        this.mPreparedStatement = null;
      }
    }
    
    public int getColumnIndex(String paramString)
    {
      getStatement(false);
      Integer localInteger = (Integer)this.mColumns.get(paramString);
      if (localInteger == null) {
        throw new IllegalArgumentException("column '" + paramString + "' is invalid");
      }
      return localInteger.intValue();
    }
    
    public long insert(ContentValues paramContentValues)
    {
      return insertInternal(paramContentValues, false);
    }
    
    public void prepareForInsert()
    {
      this.mPreparedStatement = getStatement(false);
      this.mPreparedStatement.clearBindings();
    }
    
    public void prepareForReplace()
    {
      this.mPreparedStatement = getStatement(true);
      this.mPreparedStatement.clearBindings();
    }
    
    public long replace(ContentValues paramContentValues)
    {
      return insertInternal(paramContentValues, true);
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\DatabaseUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
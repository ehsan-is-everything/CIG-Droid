package android.database;

import java.util.ArrayList;

public class DataSetObservable
  extends Observable<DataSetObserver>
{
  public void notifyChanged()
  {
    synchronized (this.mObservers)
    {
      for (int i = -1 + this.mObservers.size(); i >= 0; i--) {
        ((DataSetObserver)this.mObservers.get(i)).onChanged();
      }
      return;
    }
  }
  
  public void notifyInvalidated()
  {
    synchronized (this.mObservers)
    {
      for (int i = -1 + this.mObservers.size(); i >= 0; i--) {
        ((DataSetObserver)this.mObservers.get(i)).onInvalidated();
      }
      return;
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\DataSetObservable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
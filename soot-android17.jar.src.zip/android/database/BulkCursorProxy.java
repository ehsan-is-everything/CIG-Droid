package android.database;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;

final class BulkCursorProxy
  implements IBulkCursor
{
  private Bundle mExtras;
  private IBinder mRemote;
  
  public BulkCursorProxy(IBinder paramIBinder)
  {
    this.mRemote = paramIBinder;
    this.mExtras = null;
  }
  
  public IBinder asBinder()
  {
    return this.mRemote;
  }
  
  public void close()
    throws RemoteException
  {
    Parcel localParcel1 = Parcel.obtain();
    Parcel localParcel2 = Parcel.obtain();
    try
    {
      localParcel1.writeInterfaceToken("android.content.IBulkCursor");
      this.mRemote.transact(7, localParcel1, localParcel2, 0);
      DatabaseUtils.readExceptionFromParcel(localParcel2);
      return;
    }
    finally
    {
      localParcel1.recycle();
      localParcel2.recycle();
    }
  }
  
  public void deactivate()
    throws RemoteException
  {
    Parcel localParcel1 = Parcel.obtain();
    Parcel localParcel2 = Parcel.obtain();
    try
    {
      localParcel1.writeInterfaceToken("android.content.IBulkCursor");
      this.mRemote.transact(2, localParcel1, localParcel2, 0);
      DatabaseUtils.readExceptionFromParcel(localParcel2);
      return;
    }
    finally
    {
      localParcel1.recycle();
      localParcel2.recycle();
    }
  }
  
  public Bundle getExtras()
    throws RemoteException
  {
    Parcel localParcel1;
    Parcel localParcel2;
    if (this.mExtras == null)
    {
      localParcel1 = Parcel.obtain();
      localParcel2 = Parcel.obtain();
    }
    try
    {
      localParcel1.writeInterfaceToken("android.content.IBulkCursor");
      this.mRemote.transact(5, localParcel1, localParcel2, 0);
      DatabaseUtils.readExceptionFromParcel(localParcel2);
      this.mExtras = localParcel2.readBundle();
      return this.mExtras;
    }
    finally
    {
      localParcel1.recycle();
      localParcel2.recycle();
    }
  }
  
  public CursorWindow getWindow(int paramInt)
    throws RemoteException
  {
    Parcel localParcel1 = Parcel.obtain();
    Parcel localParcel2 = Parcel.obtain();
    try
    {
      localParcel1.writeInterfaceToken("android.content.IBulkCursor");
      localParcel1.writeInt(paramInt);
      this.mRemote.transact(1, localParcel1, localParcel2, 0);
      DatabaseUtils.readExceptionFromParcel(localParcel2);
      int i = localParcel2.readInt();
      Object localObject2 = null;
      if (i == 1)
      {
        CursorWindow localCursorWindow = CursorWindow.newFromParcel(localParcel2);
        localObject2 = localCursorWindow;
      }
      return (CursorWindow)localObject2;
    }
    finally
    {
      localParcel1.recycle();
      localParcel2.recycle();
    }
  }
  
  public void onMove(int paramInt)
    throws RemoteException
  {
    Parcel localParcel1 = Parcel.obtain();
    Parcel localParcel2 = Parcel.obtain();
    try
    {
      localParcel1.writeInterfaceToken("android.content.IBulkCursor");
      localParcel1.writeInt(paramInt);
      this.mRemote.transact(4, localParcel1, localParcel2, 0);
      DatabaseUtils.readExceptionFromParcel(localParcel2);
      return;
    }
    finally
    {
      localParcel1.recycle();
      localParcel2.recycle();
    }
  }
  
  /* Error */
  public int requery(IContentObserver paramIContentObserver)
    throws RemoteException
  {
    // Byte code:
    //   0: invokestatic 30	android/os/Parcel:obtain	()Landroid/os/Parcel;
    //   3: astore_2
    //   4: invokestatic 30	android/os/Parcel:obtain	()Landroid/os/Parcel;
    //   7: astore_3
    //   8: aload_2
    //   9: ldc 32
    //   11: invokevirtual 36	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
    //   14: aload_2
    //   15: aload_1
    //   16: invokevirtual 80	android/os/Parcel:writeStrongInterface	(Landroid/os/IInterface;)V
    //   19: aload_0
    //   20: getfield 17	android/database/BulkCursorProxy:mRemote	Landroid/os/IBinder;
    //   23: iconst_3
    //   24: aload_2
    //   25: aload_3
    //   26: iconst_0
    //   27: invokeinterface 42 5 0
    //   32: istore 5
    //   34: aload_3
    //   35: invokestatic 48	android/database/DatabaseUtils:readExceptionFromParcel	(Landroid/os/Parcel;)V
    //   38: iload 5
    //   40: ifne +17 -> 57
    //   43: iconst_m1
    //   44: istore 6
    //   46: aload_2
    //   47: invokevirtual 51	android/os/Parcel:recycle	()V
    //   50: aload_3
    //   51: invokevirtual 51	android/os/Parcel:recycle	()V
    //   54: iload 6
    //   56: ireturn
    //   57: aload_3
    //   58: invokevirtual 67	android/os/Parcel:readInt	()I
    //   61: istore 6
    //   63: aload_0
    //   64: aload_3
    //   65: invokevirtual 57	android/os/Parcel:readBundle	()Landroid/os/Bundle;
    //   68: putfield 19	android/database/BulkCursorProxy:mExtras	Landroid/os/Bundle;
    //   71: goto -25 -> 46
    //   74: astore 4
    //   76: aload_2
    //   77: invokevirtual 51	android/os/Parcel:recycle	()V
    //   80: aload_3
    //   81: invokevirtual 51	android/os/Parcel:recycle	()V
    //   84: aload 4
    //   86: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	87	0	this	BulkCursorProxy
    //   0	87	1	paramIContentObserver	IContentObserver
    //   3	74	2	localParcel1	Parcel
    //   7	74	3	localParcel2	Parcel
    //   74	11	4	localObject	Object
    //   32	7	5	bool	boolean
    //   44	18	6	i	int
    // Exception table:
    //   from	to	target	type
    //   8	38	74	finally
    //   57	71	74	finally
  }
  
  public Bundle respond(Bundle paramBundle)
    throws RemoteException
  {
    Parcel localParcel1 = Parcel.obtain();
    Parcel localParcel2 = Parcel.obtain();
    try
    {
      localParcel1.writeInterfaceToken("android.content.IBulkCursor");
      localParcel1.writeBundle(paramBundle);
      this.mRemote.transact(6, localParcel1, localParcel2, 0);
      DatabaseUtils.readExceptionFromParcel(localParcel2);
      Bundle localBundle = localParcel2.readBundle();
      return localBundle;
    }
    finally
    {
      localParcel1.recycle();
      localParcel2.recycle();
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\BulkCursorProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.database;

public class StaleDataException
  extends RuntimeException
{
  public StaleDataException() {}
  
  public StaleDataException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\StaleDataException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
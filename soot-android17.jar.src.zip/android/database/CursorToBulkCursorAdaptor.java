package android.database;

import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IBinder.DeathRecipient;
import android.os.RemoteException;

public final class CursorToBulkCursorAdaptor
  extends BulkCursorNative
  implements IBinder.DeathRecipient
{
  private static final String TAG = "Cursor";
  private CrossProcessCursor mCursor;
  private CursorWindow mFilledWindow;
  private final Object mLock = new Object();
  private ContentObserverProxy mObserver;
  private final String mProviderName;
  
  public CursorToBulkCursorAdaptor(Cursor paramCursor, IContentObserver paramIContentObserver, String paramString)
  {
    if ((paramCursor instanceof CrossProcessCursor)) {
      this.mCursor = ((CrossProcessCursor)paramCursor);
    }
    for (;;)
    {
      this.mProviderName = paramString;
      synchronized (this.mLock)
      {
        createAndRegisterObserverProxyLocked(paramIContentObserver);
        return;
        this.mCursor = new CrossProcessCursorWrapper(paramCursor);
      }
    }
  }
  
  private void closeFilledWindowLocked()
  {
    if (this.mFilledWindow != null)
    {
      this.mFilledWindow.close();
      this.mFilledWindow = null;
    }
  }
  
  private void createAndRegisterObserverProxyLocked(IContentObserver paramIContentObserver)
  {
    if (this.mObserver != null) {
      throw new IllegalStateException("an observer is already registered");
    }
    this.mObserver = new ContentObserverProxy(paramIContentObserver, this);
    this.mCursor.registerContentObserver(this.mObserver);
  }
  
  private void disposeLocked()
  {
    if (this.mCursor != null)
    {
      unregisterObserverProxyLocked();
      this.mCursor.close();
      this.mCursor = null;
    }
    closeFilledWindowLocked();
  }
  
  private void throwIfCursorIsClosed()
  {
    if (this.mCursor == null) {
      throw new StaleDataException("Attempted to access a cursor after it has been closed.");
    }
  }
  
  private void unregisterObserverProxyLocked()
  {
    if (this.mObserver != null)
    {
      this.mCursor.unregisterContentObserver(this.mObserver);
      this.mObserver.unlinkToDeath(this);
      this.mObserver = null;
    }
  }
  
  public void binderDied()
  {
    synchronized (this.mLock)
    {
      disposeLocked();
      return;
    }
  }
  
  public void close()
  {
    synchronized (this.mLock)
    {
      disposeLocked();
      return;
    }
  }
  
  public void deactivate()
  {
    synchronized (this.mLock)
    {
      if (this.mCursor != null)
      {
        unregisterObserverProxyLocked();
        this.mCursor.deactivate();
      }
      closeFilledWindowLocked();
      return;
    }
  }
  
  public BulkCursorDescriptor getBulkCursorDescriptor()
  {
    synchronized (this.mLock)
    {
      throwIfCursorIsClosed();
      BulkCursorDescriptor localBulkCursorDescriptor = new BulkCursorDescriptor();
      localBulkCursorDescriptor.cursor = this;
      localBulkCursorDescriptor.columnNames = this.mCursor.getColumnNames();
      localBulkCursorDescriptor.wantsAllOnMoveCalls = this.mCursor.getWantsAllOnMoveCalls();
      localBulkCursorDescriptor.count = this.mCursor.getCount();
      localBulkCursorDescriptor.window = this.mCursor.getWindow();
      if (localBulkCursorDescriptor.window != null) {
        localBulkCursorDescriptor.window.acquireReference();
      }
      return localBulkCursorDescriptor;
    }
  }
  
  public Bundle getExtras()
  {
    synchronized (this.mLock)
    {
      throwIfCursorIsClosed();
      Bundle localBundle = this.mCursor.getExtras();
      return localBundle;
    }
  }
  
  public CursorWindow getWindow(int paramInt)
  {
    synchronized (this.mLock)
    {
      throwIfCursorIsClosed();
      if (!this.mCursor.moveToPosition(paramInt))
      {
        closeFilledWindowLocked();
        return null;
      }
      localCursorWindow = this.mCursor.getWindow();
      if (localCursorWindow != null)
      {
        closeFilledWindowLocked();
        if (localCursorWindow != null) {
          localCursorWindow.acquireReference();
        }
        return localCursorWindow;
      }
    }
    CursorWindow localCursorWindow = this.mFilledWindow;
    if (localCursorWindow == null)
    {
      this.mFilledWindow = new CursorWindow(this.mProviderName);
      localCursorWindow = this.mFilledWindow;
    }
    for (;;)
    {
      this.mCursor.fillWindow(paramInt, localCursorWindow);
      break;
      if ((paramInt < localCursorWindow.getStartPosition()) || (paramInt >= localCursorWindow.getStartPosition() + localCursorWindow.getNumRows())) {
        localCursorWindow.clear();
      }
    }
  }
  
  public void onMove(int paramInt)
  {
    synchronized (this.mLock)
    {
      throwIfCursorIsClosed();
      this.mCursor.onMove(this.mCursor.getPosition(), paramInt);
      return;
    }
  }
  
  public int requery(IContentObserver paramIContentObserver)
  {
    synchronized (this.mLock)
    {
      throwIfCursorIsClosed();
      closeFilledWindowLocked();
      try
      {
        boolean bool = this.mCursor.requery();
        if (!bool) {
          return -1;
        }
      }
      catch (IllegalStateException localIllegalStateException)
      {
        throw new IllegalStateException(this.mProviderName + " Requery misuse db, mCursor isClosed:" + this.mCursor.isClosed(), localIllegalStateException);
      }
    }
    unregisterObserverProxyLocked();
    createAndRegisterObserverProxyLocked(paramIContentObserver);
    int i = this.mCursor.getCount();
    return i;
  }
  
  public Bundle respond(Bundle paramBundle)
  {
    synchronized (this.mLock)
    {
      throwIfCursorIsClosed();
      Bundle localBundle = this.mCursor.respond(paramBundle);
      return localBundle;
    }
  }
  
  private static final class ContentObserverProxy
    extends ContentObserver
  {
    protected IContentObserver mRemote;
    
    public ContentObserverProxy(IContentObserver paramIContentObserver, IBinder.DeathRecipient paramDeathRecipient)
    {
      super();
      this.mRemote = paramIContentObserver;
      try
      {
        paramIContentObserver.asBinder().linkToDeath(paramDeathRecipient, 0);
        return;
      }
      catch (RemoteException localRemoteException) {}
    }
    
    public boolean deliverSelfNotifications()
    {
      return false;
    }
    
    public void onChange(boolean paramBoolean, Uri paramUri)
    {
      try
      {
        this.mRemote.onChange(paramBoolean, paramUri);
        return;
      }
      catch (RemoteException localRemoteException) {}
    }
    
    public boolean unlinkToDeath(IBinder.DeathRecipient paramDeathRecipient)
    {
      return this.mRemote.asBinder().unlinkToDeath(paramDeathRecipient, 0);
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\CursorToBulkCursorAdaptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
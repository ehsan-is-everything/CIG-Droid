package android.database;

import android.util.Log;
import java.io.File;

public final class DefaultDatabaseErrorHandler
  implements DatabaseErrorHandler
{
  private static final String TAG = "DefaultDatabaseErrorHandler";
  
  private void deleteDatabaseFile(String paramString)
  {
    if ((paramString.equalsIgnoreCase(":memory:")) || (paramString.trim().length() == 0)) {
      return;
    }
    Log.e("DefaultDatabaseErrorHandler", "deleting the database file: " + paramString);
    try
    {
      new File(paramString).delete();
      return;
    }
    catch (Exception localException)
    {
      Log.w("DefaultDatabaseErrorHandler", "delete failed: " + localException.getMessage());
    }
  }
  
  /* Error */
  public void onCorruption(android.database.sqlite.SQLiteDatabase paramSQLiteDatabase)
  {
    // Byte code:
    //   0: ldc 10
    //   2: new 36	java/lang/StringBuilder
    //   5: dup
    //   6: invokespecial 37	java/lang/StringBuilder:<init>	()V
    //   9: ldc 74
    //   11: invokevirtual 43	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   14: aload_1
    //   15: invokevirtual 79	android/database/sqlite/SQLiteDatabase:getPath	()Ljava/lang/String;
    //   18: invokevirtual 43	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   21: invokevirtual 46	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   24: invokestatic 52	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   27: pop
    //   28: aload_1
    //   29: invokevirtual 82	android/database/sqlite/SQLiteDatabase:isOpen	()Z
    //   32: ifne +12 -> 44
    //   35: aload_0
    //   36: aload_1
    //   37: invokevirtual 79	android/database/sqlite/SQLiteDatabase:getPath	()Ljava/lang/String;
    //   40: invokespecial 84	android/database/DefaultDatabaseErrorHandler:deleteDatabaseFile	(Ljava/lang/String;)V
    //   43: return
    //   44: aconst_null
    //   45: astore_3
    //   46: aload_1
    //   47: invokevirtual 88	android/database/sqlite/SQLiteDatabase:getAttachedDbs	()Ljava/util/List;
    //   50: astore 9
    //   52: aload 9
    //   54: astore_3
    //   55: aload_1
    //   56: invokevirtual 91	android/database/sqlite/SQLiteDatabase:close	()V
    //   59: aload_3
    //   60: ifnull +44 -> 104
    //   63: aload_3
    //   64: invokeinterface 97 1 0
    //   69: astore 6
    //   71: aload 6
    //   73: invokeinterface 102 1 0
    //   78: ifeq -35 -> 43
    //   81: aload_0
    //   82: aload 6
    //   84: invokeinterface 106 1 0
    //   89: checkcast 108	android/util/Pair
    //   92: getfield 112	android/util/Pair:second	Ljava/lang/Object;
    //   95: checkcast 22	java/lang/String
    //   98: invokespecial 84	android/database/DefaultDatabaseErrorHandler:deleteDatabaseFile	(Ljava/lang/String;)V
    //   101: goto -30 -> 71
    //   104: aload_0
    //   105: aload_1
    //   106: invokevirtual 79	android/database/sqlite/SQLiteDatabase:getPath	()Ljava/lang/String;
    //   109: invokespecial 84	android/database/DefaultDatabaseErrorHandler:deleteDatabaseFile	(Ljava/lang/String;)V
    //   112: return
    //   113: astore 7
    //   115: aload_3
    //   116: ifnull +44 -> 160
    //   119: aload_3
    //   120: invokeinterface 97 1 0
    //   125: astore 8
    //   127: aload 8
    //   129: invokeinterface 102 1 0
    //   134: ifeq +34 -> 168
    //   137: aload_0
    //   138: aload 8
    //   140: invokeinterface 106 1 0
    //   145: checkcast 108	android/util/Pair
    //   148: getfield 112	android/util/Pair:second	Ljava/lang/Object;
    //   151: checkcast 22	java/lang/String
    //   154: invokespecial 84	android/database/DefaultDatabaseErrorHandler:deleteDatabaseFile	(Ljava/lang/String;)V
    //   157: goto -30 -> 127
    //   160: aload_0
    //   161: aload_1
    //   162: invokevirtual 79	android/database/sqlite/SQLiteDatabase:getPath	()Ljava/lang/String;
    //   165: invokespecial 84	android/database/DefaultDatabaseErrorHandler:deleteDatabaseFile	(Ljava/lang/String;)V
    //   168: aload 7
    //   170: athrow
    //   171: astore 4
    //   173: aconst_null
    //   174: astore_3
    //   175: goto -120 -> 55
    //   178: astore 5
    //   180: goto -121 -> 59
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	183	0	this	DefaultDatabaseErrorHandler
    //   0	183	1	paramSQLiteDatabase	android.database.sqlite.SQLiteDatabase
    //   45	130	3	localObject1	Object
    //   171	1	4	localSQLiteException1	android.database.sqlite.SQLiteException
    //   178	1	5	localSQLiteException2	android.database.sqlite.SQLiteException
    //   69	14	6	localIterator1	java.util.Iterator
    //   113	56	7	localObject2	Object
    //   125	14	8	localIterator2	java.util.Iterator
    //   50	3	9	localList	java.util.List
    // Exception table:
    //   from	to	target	type
    //   46	52	113	finally
    //   55	59	113	finally
    //   46	52	171	android/database/sqlite/SQLiteException
    //   55	59	178	android/database/sqlite/SQLiteException
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\DefaultDatabaseErrorHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
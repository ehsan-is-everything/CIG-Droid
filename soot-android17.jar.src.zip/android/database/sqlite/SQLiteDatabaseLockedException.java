package android.database.sqlite;

public class SQLiteDatabaseLockedException
  extends SQLiteException
{
  public SQLiteDatabaseLockedException() {}
  
  public SQLiteDatabaseLockedException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\sqlite\SQLiteDatabaseLockedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
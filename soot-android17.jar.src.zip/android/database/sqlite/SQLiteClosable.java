package android.database.sqlite;

import java.io.Closeable;

public abstract class SQLiteClosable
  implements Closeable
{
  private int mReferenceCount = 1;
  
  public void acquireReference()
  {
    try
    {
      if (this.mReferenceCount <= 0) {
        throw new IllegalStateException("attempt to re-open an already-closed object: " + this);
      }
    }
    finally {}
    this.mReferenceCount = (1 + this.mReferenceCount);
  }
  
  public void close()
  {
    releaseReference();
  }
  
  protected abstract void onAllReferencesReleased();
  
  @Deprecated
  protected void onAllReferencesReleasedFromContainer()
  {
    onAllReferencesReleased();
  }
  
  /* Error */
  public void releaseReference()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_m1
    //   3: aload_0
    //   4: getfield 14	android/database/sqlite/SQLiteClosable:mReferenceCount	I
    //   7: iadd
    //   8: istore_2
    //   9: aload_0
    //   10: iload_2
    //   11: putfield 14	android/database/sqlite/SQLiteClosable:mReferenceCount	I
    //   14: iload_2
    //   15: ifne +16 -> 31
    //   18: iconst_1
    //   19: istore_3
    //   20: aload_0
    //   21: monitorexit
    //   22: iload_3
    //   23: ifeq +7 -> 30
    //   26: aload_0
    //   27: invokevirtual 45	android/database/sqlite/SQLiteClosable:onAllReferencesReleased	()V
    //   30: return
    //   31: iconst_0
    //   32: istore_3
    //   33: goto -13 -> 20
    //   36: astore_1
    //   37: aload_0
    //   38: monitorexit
    //   39: aload_1
    //   40: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	41	0	this	SQLiteClosable
    //   36	4	1	localObject	Object
    //   8	7	2	i	int
    //   19	14	3	j	int
    // Exception table:
    //   from	to	target	type
    //   2	14	36	finally
    //   20	22	36	finally
    //   37	39	36	finally
  }
  
  /* Error */
  @Deprecated
  public void releaseReferenceFromContainer()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_m1
    //   3: aload_0
    //   4: getfield 14	android/database/sqlite/SQLiteClosable:mReferenceCount	I
    //   7: iadd
    //   8: istore_2
    //   9: aload_0
    //   10: iload_2
    //   11: putfield 14	android/database/sqlite/SQLiteClosable:mReferenceCount	I
    //   14: iload_2
    //   15: ifne +16 -> 31
    //   18: iconst_1
    //   19: istore_3
    //   20: aload_0
    //   21: monitorexit
    //   22: iload_3
    //   23: ifeq +7 -> 30
    //   26: aload_0
    //   27: invokevirtual 48	android/database/sqlite/SQLiteClosable:onAllReferencesReleasedFromContainer	()V
    //   30: return
    //   31: iconst_0
    //   32: istore_3
    //   33: goto -13 -> 20
    //   36: astore_1
    //   37: aload_0
    //   38: monitorexit
    //   39: aload_1
    //   40: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	41	0	this	SQLiteClosable
    //   36	4	1	localObject	Object
    //   8	7	2	i	int
    //   19	14	3	j	int
    // Exception table:
    //   from	to	target	type
    //   2	14	36	finally
    //   20	22	36	finally
    //   37	39	36	finally
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\sqlite\SQLiteClosable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
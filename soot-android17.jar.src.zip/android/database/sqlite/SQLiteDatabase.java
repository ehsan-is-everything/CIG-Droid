package android.database.sqlite;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.DatabaseUtils;
import android.database.DefaultDatabaseErrorHandler;
import android.database.SQLException;
import android.os.CancellationSignal;
import android.os.Looper;
import android.text.TextUtils;
import android.util.EventLog;
import android.util.Log;
import android.util.Pair;
import android.util.Printer;
import dalvik.system.CloseGuard;
import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

public final class SQLiteDatabase
  extends SQLiteClosable
{
  public static final int CONFLICT_ABORT = 2;
  public static final int CONFLICT_FAIL = 3;
  public static final int CONFLICT_IGNORE = 4;
  public static final int CONFLICT_NONE = 0;
  public static final int CONFLICT_REPLACE = 5;
  public static final int CONFLICT_ROLLBACK = 1;
  private static final String[] CONFLICT_VALUES;
  public static final int CREATE_IF_NECESSARY = 268435456;
  public static final int ENABLE_WRITE_AHEAD_LOGGING = 536870912;
  private static final int EVENT_DB_CORRUPT = 75004;
  public static final int MAX_SQL_CACHE_SIZE = 100;
  public static final int NO_LOCALIZED_COLLATORS = 16;
  public static final int OPEN_READONLY = 1;
  public static final int OPEN_READWRITE = 0;
  private static final int OPEN_READ_MASK = 1;
  public static final int SQLITE_MAX_LIKE_PATTERN_LENGTH = 50000;
  private static final String TAG = "SQLiteDatabase";
  private static WeakHashMap<SQLiteDatabase, Object> sActiveDatabases;
  private final CloseGuard mCloseGuardLocked = CloseGuard.get();
  private final SQLiteDatabaseConfiguration mConfigurationLocked;
  private SQLiteConnectionPool mConnectionPoolLocked;
  private final CursorFactory mCursorFactory;
  private final DatabaseErrorHandler mErrorHandler;
  private boolean mHasAttachedDbsLocked;
  private final Object mLock = new Object();
  private final ThreadLocal<SQLiteSession> mThreadSession = new ThreadLocal()
  {
    protected SQLiteSession initialValue()
    {
      return SQLiteDatabase.this.createSession();
    }
  };
  
  static
  {
    if (!SQLiteDatabase.class.desiredAssertionStatus()) {}
    for (boolean bool = true;; bool = false)
    {
      $assertionsDisabled = bool;
      sActiveDatabases = new WeakHashMap();
      CONFLICT_VALUES = new String[] { "", " OR ROLLBACK ", " OR ABORT ", " OR FAIL ", " OR IGNORE ", " OR REPLACE " };
      return;
    }
  }
  
  private SQLiteDatabase(String paramString, int paramInt, CursorFactory paramCursorFactory, DatabaseErrorHandler paramDatabaseErrorHandler)
  {
    this.mCursorFactory = paramCursorFactory;
    if (paramDatabaseErrorHandler != null) {}
    for (;;)
    {
      this.mErrorHandler = paramDatabaseErrorHandler;
      this.mConfigurationLocked = new SQLiteDatabaseConfiguration(paramString, paramInt);
      return;
      paramDatabaseErrorHandler = new DefaultDatabaseErrorHandler();
    }
  }
  
  /* Error */
  private void beginTransaction(SQLiteTransactionListener paramSQLiteTransactionListener, boolean paramBoolean)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 133	android/database/sqlite/SQLiteDatabase:acquireReference	()V
    //   4: aload_0
    //   5: invokevirtual 137	android/database/sqlite/SQLiteDatabase:getThreadSession	()Landroid/database/sqlite/SQLiteSession;
    //   8: astore 4
    //   10: iload_2
    //   11: ifeq +25 -> 36
    //   14: iconst_2
    //   15: istore 5
    //   17: aload 4
    //   19: iload 5
    //   21: aload_1
    //   22: aload_0
    //   23: iconst_0
    //   24: invokevirtual 141	android/database/sqlite/SQLiteDatabase:getThreadDefaultConnectionFlags	(Z)I
    //   27: aconst_null
    //   28: invokevirtual 146	android/database/sqlite/SQLiteSession:beginTransaction	(ILandroid/database/sqlite/SQLiteTransactionListener;ILandroid/os/CancellationSignal;)V
    //   31: aload_0
    //   32: invokevirtual 149	android/database/sqlite/SQLiteDatabase:releaseReference	()V
    //   35: return
    //   36: iconst_1
    //   37: istore 5
    //   39: goto -22 -> 17
    //   42: astore_3
    //   43: aload_0
    //   44: invokevirtual 149	android/database/sqlite/SQLiteDatabase:releaseReference	()V
    //   47: aload_3
    //   48: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	49	0	this	SQLiteDatabase
    //   0	49	1	paramSQLiteTransactionListener	SQLiteTransactionListener
    //   0	49	2	paramBoolean	boolean
    //   42	6	3	localObject	Object
    //   8	10	4	localSQLiteSession	SQLiteSession
    //   15	23	5	i	int
    // Exception table:
    //   from	to	target	type
    //   4	10	42	finally
    //   17	31	42	finally
  }
  
  private void collectDbStats(ArrayList<SQLiteDebug.DbStats> paramArrayList)
  {
    synchronized (this.mLock)
    {
      if (this.mConnectionPoolLocked != null) {
        this.mConnectionPoolLocked.collectDbStats(paramArrayList);
      }
      return;
    }
  }
  
  public static SQLiteDatabase create(CursorFactory paramCursorFactory)
  {
    return openDatabase(":memory:", paramCursorFactory, 268435456);
  }
  
  public static boolean deleteDatabase(File paramFile)
  {
    if (paramFile == null) {
      throw new IllegalArgumentException("file must not be null");
    }
    boolean bool = false | paramFile.delete() | new File(paramFile.getPath() + "-journal").delete() | new File(paramFile.getPath() + "-shm").delete() | new File(paramFile.getPath() + "-wal").delete();
    File localFile = paramFile.getParentFile();
    if (localFile != null)
    {
      File[] arrayOfFile = localFile.listFiles(new FileFilter()
      {
        public boolean accept(File paramAnonymousFile)
        {
          return paramAnonymousFile.getName().startsWith(this.val$prefix);
        }
      });
      int i = arrayOfFile.length;
      for (int j = 0; j < i; j++) {
        bool |= arrayOfFile[j].delete();
      }
    }
    return bool;
  }
  
  private void dispose(boolean paramBoolean)
  {
    SQLiteConnectionPool localSQLiteConnectionPool;
    synchronized (this.mLock)
    {
      if (this.mCloseGuardLocked != null)
      {
        if (paramBoolean) {
          this.mCloseGuardLocked.warnIfOpen();
        }
        this.mCloseGuardLocked.close();
      }
      localSQLiteConnectionPool = this.mConnectionPoolLocked;
      this.mConnectionPoolLocked = null;
      if (paramBoolean) {}
    }
    synchronized (sActiveDatabases)
    {
      sActiveDatabases.remove(this);
      if (localSQLiteConnectionPool != null) {
        localSQLiteConnectionPool.close();
      }
      return;
      localObject2 = finally;
      throw ((Throwable)localObject2);
    }
  }
  
  private void dump(Printer paramPrinter, boolean paramBoolean)
  {
    synchronized (this.mLock)
    {
      if (this.mConnectionPoolLocked != null)
      {
        paramPrinter.println("");
        this.mConnectionPoolLocked.dump(paramPrinter, paramBoolean);
      }
      return;
    }
  }
  
  static void dumpAll(Printer paramPrinter, boolean paramBoolean)
  {
    Iterator localIterator = getActiveDatabases().iterator();
    while (localIterator.hasNext()) {
      ((SQLiteDatabase)localIterator.next()).dump(paramPrinter, paramBoolean);
    }
  }
  
  /* Error */
  private int executeSql(String paramString, Object[] paramArrayOfObject)
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 133	android/database/sqlite/SQLiteDatabase:acquireReference	()V
    //   4: aload_1
    //   5: invokestatic 269	android/database/DatabaseUtils:getSqlStatementType	(Ljava/lang/String;)I
    //   8: iconst_3
    //   9: if_icmpne +46 -> 55
    //   12: aload_0
    //   13: getfield 106	android/database/sqlite/SQLiteDatabase:mLock	Ljava/lang/Object;
    //   16: astore 7
    //   18: aload 7
    //   20: monitorenter
    //   21: aload_0
    //   22: getfield 271	android/database/sqlite/SQLiteDatabase:mHasAttachedDbsLocked	Z
    //   25: istore 9
    //   27: iconst_0
    //   28: istore 10
    //   30: iload 9
    //   32: ifne +11 -> 43
    //   35: aload_0
    //   36: iconst_1
    //   37: putfield 271	android/database/sqlite/SQLiteDatabase:mHasAttachedDbsLocked	Z
    //   40: iconst_1
    //   41: istore 10
    //   43: aload 7
    //   45: monitorexit
    //   46: iload 10
    //   48: ifeq +7 -> 55
    //   51: aload_0
    //   52: invokevirtual 274	android/database/sqlite/SQLiteDatabase:disableWriteAheadLogging	()V
    //   55: new 276	android/database/sqlite/SQLiteStatement
    //   58: dup
    //   59: aload_0
    //   60: aload_1
    //   61: aload_2
    //   62: invokespecial 279	android/database/sqlite/SQLiteStatement:<init>	(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;[Ljava/lang/Object;)V
    //   65: astore 4
    //   67: aload 4
    //   69: invokevirtual 283	android/database/sqlite/SQLiteStatement:executeUpdateDelete	()I
    //   72: istore 6
    //   74: aload 4
    //   76: invokevirtual 284	android/database/sqlite/SQLiteStatement:close	()V
    //   79: aload_0
    //   80: invokevirtual 149	android/database/sqlite/SQLiteDatabase:releaseReference	()V
    //   83: iload 6
    //   85: ireturn
    //   86: astore 8
    //   88: aload 7
    //   90: monitorexit
    //   91: aload 8
    //   93: athrow
    //   94: astore_3
    //   95: aload_0
    //   96: invokevirtual 149	android/database/sqlite/SQLiteDatabase:releaseReference	()V
    //   99: aload_3
    //   100: athrow
    //   101: astore 5
    //   103: aload 4
    //   105: invokevirtual 284	android/database/sqlite/SQLiteStatement:close	()V
    //   108: aload 5
    //   110: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	111	0	this	SQLiteDatabase
    //   0	111	1	paramString	String
    //   0	111	2	paramArrayOfObject	Object[]
    //   94	6	3	localObject1	Object
    //   65	39	4	localSQLiteStatement	SQLiteStatement
    //   101	8	5	localObject2	Object
    //   72	12	6	i	int
    //   86	6	8	localObject4	Object
    //   25	6	9	bool	boolean
    //   28	19	10	j	int
    // Exception table:
    //   from	to	target	type
    //   21	27	86	finally
    //   35	40	86	finally
    //   43	46	86	finally
    //   88	91	86	finally
    //   4	21	94	finally
    //   51	55	94	finally
    //   55	67	94	finally
    //   74	79	94	finally
    //   91	94	94	finally
    //   103	111	94	finally
    //   67	74	101	finally
  }
  
  public static String findEditTable(String paramString)
  {
    if (!TextUtils.isEmpty(paramString))
    {
      int i = paramString.indexOf(' ');
      int j = paramString.indexOf(',');
      if ((i > 0) && ((i < j) || (j < 0))) {
        paramString = paramString.substring(0, i);
      }
      while ((j <= 0) || ((j >= i) && (i >= 0))) {
        return paramString;
      }
      return paramString.substring(0, j);
    }
    throw new IllegalStateException("Invalid tables");
  }
  
  private static ArrayList<SQLiteDatabase> getActiveDatabases()
  {
    ArrayList localArrayList = new ArrayList();
    synchronized (sActiveDatabases)
    {
      localArrayList.addAll(sActiveDatabases.keySet());
      return localArrayList;
    }
  }
  
  static ArrayList<SQLiteDebug.DbStats> getDbStats()
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = getActiveDatabases().iterator();
    while (localIterator.hasNext()) {
      ((SQLiteDatabase)localIterator.next()).collectDbStats(localArrayList);
    }
    return localArrayList;
  }
  
  private static boolean isMainThread()
  {
    Looper localLooper = Looper.myLooper();
    return (localLooper != null) && (localLooper == Looper.getMainLooper());
  }
  
  private boolean isReadOnlyLocked()
  {
    return (0x1 & this.mConfigurationLocked.openFlags) == 1;
  }
  
  private void open()
  {
    try
    {
      openInner();
      return;
    }
    catch (SQLiteDatabaseCorruptException localSQLiteDatabaseCorruptException)
    {
      onCorruption();
      openInner();
      return;
    }
    catch (SQLiteException localSQLiteException)
    {
      Log.e("SQLiteDatabase", "Failed to open database '" + getLabel() + "'.", localSQLiteException);
      close();
      throw localSQLiteException;
    }
  }
  
  public static SQLiteDatabase openDatabase(String paramString, CursorFactory paramCursorFactory, int paramInt)
  {
    return openDatabase(paramString, paramCursorFactory, paramInt, null);
  }
  
  public static SQLiteDatabase openDatabase(String paramString, CursorFactory paramCursorFactory, int paramInt, DatabaseErrorHandler paramDatabaseErrorHandler)
  {
    SQLiteDatabase localSQLiteDatabase = new SQLiteDatabase(paramString, paramInt, paramCursorFactory, paramDatabaseErrorHandler);
    localSQLiteDatabase.open();
    return localSQLiteDatabase;
  }
  
  private void openInner()
  {
    synchronized (this.mLock)
    {
      if ((!$assertionsDisabled) && (this.mConnectionPoolLocked != null)) {
        throw new AssertionError();
      }
    }
    this.mConnectionPoolLocked = SQLiteConnectionPool.open(this.mConfigurationLocked);
    this.mCloseGuardLocked.open("close");
    synchronized (sActiveDatabases)
    {
      sActiveDatabases.put(this, null);
      return;
    }
  }
  
  public static SQLiteDatabase openOrCreateDatabase(File paramFile, CursorFactory paramCursorFactory)
  {
    return openOrCreateDatabase(paramFile.getPath(), paramCursorFactory);
  }
  
  public static SQLiteDatabase openOrCreateDatabase(String paramString, CursorFactory paramCursorFactory)
  {
    return openDatabase(paramString, paramCursorFactory, 268435456, null);
  }
  
  public static SQLiteDatabase openOrCreateDatabase(String paramString, CursorFactory paramCursorFactory, DatabaseErrorHandler paramDatabaseErrorHandler)
  {
    return openDatabase(paramString, paramCursorFactory, 268435456, paramDatabaseErrorHandler);
  }
  
  public static int releaseMemory()
  {
    return SQLiteGlobal.releaseMemory();
  }
  
  private void throwIfNotOpenLocked()
  {
    if (this.mConnectionPoolLocked == null) {
      throw new IllegalStateException("The database '" + this.mConfigurationLocked.label + "' is not open.");
    }
  }
  
  private boolean yieldIfContendedHelper(boolean paramBoolean, long paramLong)
  {
    acquireReference();
    try
    {
      boolean bool = getThreadSession().yieldTransaction(paramLong, paramBoolean, null);
      return bool;
    }
    finally
    {
      releaseReference();
    }
  }
  
  public void addCustomFunction(String paramString, int paramInt, CustomFunction paramCustomFunction)
  {
    SQLiteCustomFunction localSQLiteCustomFunction = new SQLiteCustomFunction(paramString, paramInt, paramCustomFunction);
    synchronized (this.mLock)
    {
      throwIfNotOpenLocked();
      this.mConfigurationLocked.customFunctions.add(localSQLiteCustomFunction);
      try
      {
        this.mConnectionPoolLocked.reconfigure(this.mConfigurationLocked);
        return;
      }
      catch (RuntimeException localRuntimeException)
      {
        this.mConfigurationLocked.customFunctions.remove(localSQLiteCustomFunction);
        throw localRuntimeException;
      }
    }
  }
  
  public void beginTransaction()
  {
    beginTransaction(null, true);
  }
  
  public void beginTransactionNonExclusive()
  {
    beginTransaction(null, false);
  }
  
  public void beginTransactionWithListener(SQLiteTransactionListener paramSQLiteTransactionListener)
  {
    beginTransaction(paramSQLiteTransactionListener, true);
  }
  
  public void beginTransactionWithListenerNonExclusive(SQLiteTransactionListener paramSQLiteTransactionListener)
  {
    beginTransaction(paramSQLiteTransactionListener, false);
  }
  
  public SQLiteStatement compileStatement(String paramString)
    throws SQLException
  {
    acquireReference();
    try
    {
      SQLiteStatement localSQLiteStatement = new SQLiteStatement(this, paramString, null);
      return localSQLiteStatement;
    }
    finally
    {
      releaseReference();
    }
  }
  
  SQLiteSession createSession()
  {
    synchronized (this.mLock)
    {
      throwIfNotOpenLocked();
      SQLiteConnectionPool localSQLiteConnectionPool = this.mConnectionPoolLocked;
      return new SQLiteSession(localSQLiteConnectionPool);
    }
  }
  
  /* Error */
  public int delete(String paramString1, String paramString2, String[] paramArrayOfString)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 133	android/database/sqlite/SQLiteDatabase:acquireReference	()V
    //   4: new 181	java/lang/StringBuilder
    //   7: dup
    //   8: invokespecial 182	java/lang/StringBuilder:<init>	()V
    //   11: ldc_w 439
    //   14: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   17: aload_1
    //   18: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   21: astore 5
    //   23: aload_2
    //   24: invokestatic 292	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   27: ifne +65 -> 92
    //   30: new 181	java/lang/StringBuilder
    //   33: dup
    //   34: invokespecial 182	java/lang/StringBuilder:<init>	()V
    //   37: ldc_w 441
    //   40: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   43: aload_2
    //   44: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   47: invokevirtual 195	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   50: astore 6
    //   52: new 276	android/database/sqlite/SQLiteStatement
    //   55: dup
    //   56: aload_0
    //   57: aload 5
    //   59: aload 6
    //   61: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: invokevirtual 195	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   67: aload_3
    //   68: invokespecial 279	android/database/sqlite/SQLiteStatement:<init>	(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;[Ljava/lang/Object;)V
    //   71: astore 7
    //   73: aload 7
    //   75: invokevirtual 283	android/database/sqlite/SQLiteStatement:executeUpdateDelete	()I
    //   78: istore 9
    //   80: aload 7
    //   82: invokevirtual 284	android/database/sqlite/SQLiteStatement:close	()V
    //   85: aload_0
    //   86: invokevirtual 149	android/database/sqlite/SQLiteDatabase:releaseReference	()V
    //   89: iload 9
    //   91: ireturn
    //   92: ldc 80
    //   94: astore 6
    //   96: goto -44 -> 52
    //   99: astore 8
    //   101: aload 7
    //   103: invokevirtual 284	android/database/sqlite/SQLiteStatement:close	()V
    //   106: aload 8
    //   108: athrow
    //   109: astore 4
    //   111: aload_0
    //   112: invokevirtual 149	android/database/sqlite/SQLiteDatabase:releaseReference	()V
    //   115: aload 4
    //   117: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	118	0	this	SQLiteDatabase
    //   0	118	1	paramString1	String
    //   0	118	2	paramString2	String
    //   0	118	3	paramArrayOfString	String[]
    //   109	7	4	localObject1	Object
    //   21	37	5	localStringBuilder	StringBuilder
    //   50	45	6	str	String
    //   71	31	7	localSQLiteStatement	SQLiteStatement
    //   99	8	8	localObject2	Object
    //   78	12	9	i	int
    // Exception table:
    //   from	to	target	type
    //   73	80	99	finally
    //   4	52	109	finally
    //   52	73	109	finally
    //   80	85	109	finally
    //   101	109	109	finally
  }
  
  public void disableWriteAheadLogging()
  {
    synchronized (this.mLock)
    {
      throwIfNotOpenLocked();
      if ((0x20000000 & this.mConfigurationLocked.openFlags) == 0) {
        return;
      }
      SQLiteDatabaseConfiguration localSQLiteDatabaseConfiguration1 = this.mConfigurationLocked;
      localSQLiteDatabaseConfiguration1.openFlags = (0xDFFFFFFF & localSQLiteDatabaseConfiguration1.openFlags);
    }
  }
  
  public boolean enableWriteAheadLogging()
  {
    synchronized (this.mLock)
    {
      throwIfNotOpenLocked();
      if ((0x20000000 & this.mConfigurationLocked.openFlags) != 0) {
        return true;
      }
      if (isReadOnlyLocked()) {
        return false;
      }
      if (this.mConfigurationLocked.isInMemoryDb())
      {
        Log.i("SQLiteDatabase", "can't enable WAL for memory databases.");
        return false;
      }
      if (this.mHasAttachedDbsLocked)
      {
        if (Log.isLoggable("SQLiteDatabase", 3)) {
          Log.d("SQLiteDatabase", "this database: " + this.mConfigurationLocked.label + " has attached databases. can't  enable WAL.");
        }
        return false;
      }
      SQLiteDatabaseConfiguration localSQLiteDatabaseConfiguration1 = this.mConfigurationLocked;
      localSQLiteDatabaseConfiguration1.openFlags = (0x20000000 | localSQLiteDatabaseConfiguration1.openFlags);
    }
  }
  
  public void endTransaction()
  {
    acquireReference();
    try
    {
      getThreadSession().endTransaction(null);
      return;
    }
    finally
    {
      releaseReference();
    }
  }
  
  public void execSQL(String paramString)
    throws SQLException
  {
    executeSql(paramString, null);
  }
  
  public void execSQL(String paramString, Object[] paramArrayOfObject)
    throws SQLException
  {
    if (paramArrayOfObject == null) {
      throw new IllegalArgumentException("Empty bindArgs");
    }
    executeSql(paramString, paramArrayOfObject);
  }
  
  protected void finalize()
    throws Throwable
  {
    try
    {
      dispose(true);
      return;
    }
    finally
    {
      super.finalize();
    }
  }
  
  public List<Pair<String, String>> getAttachedDbs()
  {
    localArrayList = new ArrayList();
    synchronized (this.mLock)
    {
      if (this.mConnectionPoolLocked == null) {
        return null;
      }
      if (!this.mHasAttachedDbsLocked)
      {
        localArrayList.add(new Pair("main", this.mConfigurationLocked.path));
        return localArrayList;
      }
    }
    acquireReference();
    Cursor localCursor = null;
    try
    {
      localCursor = rawQuery("pragma database_list;", null);
      while (localCursor.moveToNext()) {
        localArrayList.add(new Pair(localCursor.getString(1), localCursor.getString(2)));
      }
      return localArrayList;
    }
    finally
    {
      if (localCursor != null) {}
      try
      {
        localCursor.close();
        throw ((Throwable)localObject3);
      }
      finally
      {
        releaseReference();
        throw ((Throwable)localObject4);
        if (localCursor == null) {}
      }
    }
  }
  
  String getLabel()
  {
    synchronized (this.mLock)
    {
      String str = this.mConfigurationLocked.label;
      return str;
    }
  }
  
  public long getMaximumSize()
  {
    return DatabaseUtils.longForQuery(this, "PRAGMA max_page_count;", null) * getPageSize();
  }
  
  public long getPageSize()
  {
    return DatabaseUtils.longForQuery(this, "PRAGMA page_size;", null);
  }
  
  public final String getPath()
  {
    synchronized (this.mLock)
    {
      String str = this.mConfigurationLocked.path;
      return str;
    }
  }
  
  @Deprecated
  public Map<String, String> getSyncedTables()
  {
    return new HashMap(0);
  }
  
  int getThreadDefaultConnectionFlags(boolean paramBoolean)
  {
    if (paramBoolean) {}
    for (int i = 1;; i = 2)
    {
      if (isMainThread()) {
        i |= 0x4;
      }
      return i;
    }
  }
  
  SQLiteSession getThreadSession()
  {
    return (SQLiteSession)this.mThreadSession.get();
  }
  
  public int getVersion()
  {
    return Long.valueOf(DatabaseUtils.longForQuery(this, "PRAGMA user_version;", null)).intValue();
  }
  
  public boolean inTransaction()
  {
    acquireReference();
    try
    {
      boolean bool = getThreadSession().hasTransaction();
      return bool;
    }
    finally
    {
      releaseReference();
    }
  }
  
  public long insert(String paramString1, String paramString2, ContentValues paramContentValues)
  {
    try
    {
      long l = insertWithOnConflict(paramString1, paramString2, paramContentValues, 0);
      return l;
    }
    catch (SQLException localSQLException)
    {
      Log.e("SQLiteDatabase", "Error inserting " + paramContentValues, localSQLException);
    }
    return -1L;
  }
  
  public long insertOrThrow(String paramString1, String paramString2, ContentValues paramContentValues)
    throws SQLException
  {
    return insertWithOnConflict(paramString1, paramString2, paramContentValues, 0);
  }
  
  public long insertWithOnConflict(String paramString1, String paramString2, ContentValues paramContentValues, int paramInt)
  {
    acquireReference();
    for (;;)
    {
      int i;
      int k;
      String str1;
      try
      {
        StringBuilder localStringBuilder = new StringBuilder();
        localStringBuilder.append("INSERT");
        localStringBuilder.append(CONFLICT_VALUES[paramInt]);
        localStringBuilder.append(" INTO ");
        localStringBuilder.append(paramString1);
        localStringBuilder.append('(');
        Object[] arrayOfObject = null;
        if ((paramContentValues != null) && (paramContentValues.size() > 0))
        {
          i = paramContentValues.size();
          if (i > 0)
          {
            arrayOfObject = new Object[i];
            Iterator localIterator = paramContentValues.keySet().iterator();
            int j = 0;
            if (localIterator.hasNext())
            {
              String str2 = (String)localIterator.next();
              if (j <= 0) {
                break label308;
              }
              str3 = ",";
              localStringBuilder.append(str3);
              localStringBuilder.append(str2);
              int m = j + 1;
              arrayOfObject[j] = paramContentValues.get(str2);
              j = m;
              continue;
            }
            localStringBuilder.append(')');
            localStringBuilder.append(" VALUES (");
            k = 0;
            break label315;
            localStringBuilder.append(str1);
            k++;
            break label315;
          }
          localStringBuilder.append(paramString2 + ") VALUES (NULL");
          localStringBuilder.append(')');
          SQLiteStatement localSQLiteStatement = new SQLiteStatement(this, localStringBuilder.toString(), arrayOfObject);
          try
          {
            long l = localSQLiteStatement.executeInsert();
            return l;
          }
          finally {}
        }
        i = 0;
      }
      finally
      {
        releaseReference();
      }
      continue;
      label308:
      String str3 = "";
      continue;
      label315:
      if (k < i) {
        if (k > 0) {
          str1 = ",?";
        } else {
          str1 = "?";
        }
      }
    }
  }
  
  /* Error */
  public boolean isDatabaseIntegrityOk()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 133	android/database/sqlite/SQLiteDatabase:acquireReference	()V
    //   4: aconst_null
    //   5: astore_1
    //   6: aload_0
    //   7: invokevirtual 602	android/database/sqlite/SQLiteDatabase:getAttachedDbs	()Ljava/util/List;
    //   10: astore_1
    //   11: aload_1
    //   12: ifnonnull +270 -> 282
    //   15: new 302	java/lang/IllegalStateException
    //   18: dup
    //   19: new 181	java/lang/StringBuilder
    //   22: dup
    //   23: invokespecial 182	java/lang/StringBuilder:<init>	()V
    //   26: ldc_w 604
    //   29: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   32: aload_0
    //   33: invokevirtual 605	android/database/sqlite/SQLiteDatabase:getPath	()Ljava/lang/String;
    //   36: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   39: ldc_w 607
    //   42: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   45: ldc_w 609
    //   48: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: invokevirtual 195	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   54: invokespecial 305	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   57: athrow
    //   58: astore_3
    //   59: aload_1
    //   60: pop
    //   61: new 245	java/util/ArrayList
    //   64: dup
    //   65: invokespecial 306	java/util/ArrayList:<init>	()V
    //   68: astore_1
    //   69: aload_1
    //   70: new 486	android/util/Pair
    //   73: dup
    //   74: ldc_w 488
    //   77: aload_0
    //   78: invokevirtual 605	android/database/sqlite/SQLiteDatabase:getPath	()Ljava/lang/String;
    //   81: invokespecial 494	android/util/Pair:<init>	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   84: invokeinterface 612 2 0
    //   89: pop
    //   90: goto +192 -> 282
    //   93: iload 6
    //   95: aload_1
    //   96: invokeinterface 613 1 0
    //   101: if_icmpge +171 -> 272
    //   104: aload_1
    //   105: iload 6
    //   107: invokeinterface 616 2 0
    //   112: checkcast 486	android/util/Pair
    //   115: astore 7
    //   117: aconst_null
    //   118: astore 8
    //   120: aload_0
    //   121: new 181	java/lang/StringBuilder
    //   124: dup
    //   125: invokespecial 182	java/lang/StringBuilder:<init>	()V
    //   128: ldc_w 618
    //   131: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   134: aload 7
    //   136: getfield 621	android/util/Pair:first	Ljava/lang/Object;
    //   139: checkcast 78	java/lang/String
    //   142: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   145: ldc_w 623
    //   148: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   151: invokevirtual 195	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   154: invokevirtual 625	android/database/sqlite/SQLiteDatabase:compileStatement	(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;
    //   157: astore 8
    //   159: aload 8
    //   161: invokevirtual 628	android/database/sqlite/SQLiteStatement:simpleQueryForString	()Ljava/lang/String;
    //   164: astore 10
    //   166: aload 10
    //   168: ldc_w 630
    //   171: invokevirtual 634	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   174: ifne +63 -> 237
    //   177: ldc 40
    //   179: new 181	java/lang/StringBuilder
    //   182: dup
    //   183: invokespecial 182	java/lang/StringBuilder:<init>	()V
    //   186: ldc_w 636
    //   189: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   192: aload 7
    //   194: getfield 639	android/util/Pair:second	Ljava/lang/Object;
    //   197: checkcast 78	java/lang/String
    //   200: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   203: ldc_w 641
    //   206: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   209: aload 10
    //   211: invokevirtual 190	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   214: invokevirtual 195	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   217: invokestatic 643	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   220: pop
    //   221: aload 8
    //   223: ifnull +8 -> 231
    //   226: aload 8
    //   228: invokevirtual 284	android/database/sqlite/SQLiteStatement:close	()V
    //   231: aload_0
    //   232: invokevirtual 149	android/database/sqlite/SQLiteDatabase:releaseReference	()V
    //   235: iconst_0
    //   236: ireturn
    //   237: aload 8
    //   239: ifnull +49 -> 288
    //   242: aload 8
    //   244: invokevirtual 284	android/database/sqlite/SQLiteStatement:close	()V
    //   247: goto +41 -> 288
    //   250: astore 9
    //   252: aload 8
    //   254: ifnull +8 -> 262
    //   257: aload 8
    //   259: invokevirtual 284	android/database/sqlite/SQLiteStatement:close	()V
    //   262: aload 9
    //   264: athrow
    //   265: astore_2
    //   266: aload_0
    //   267: invokevirtual 149	android/database/sqlite/SQLiteDatabase:releaseReference	()V
    //   270: aload_2
    //   271: athrow
    //   272: aload_0
    //   273: invokevirtual 149	android/database/sqlite/SQLiteDatabase:releaseReference	()V
    //   276: iconst_1
    //   277: ireturn
    //   278: astore_2
    //   279: goto -13 -> 266
    //   282: iconst_0
    //   283: istore 6
    //   285: goto -192 -> 93
    //   288: iinc 6 1
    //   291: goto -198 -> 93
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	294	0	this	SQLiteDatabase
    //   5	100	1	localObject1	Object
    //   265	6	2	localObject2	Object
    //   278	1	2	localObject3	Object
    //   58	1	3	localSQLiteException	SQLiteException
    //   93	196	6	i	int
    //   115	78	7	localPair	Pair
    //   118	140	8	localSQLiteStatement	SQLiteStatement
    //   250	13	9	localObject4	Object
    //   164	46	10	str	String
    // Exception table:
    //   from	to	target	type
    //   6	11	58	android/database/sqlite/SQLiteException
    //   15	58	58	android/database/sqlite/SQLiteException
    //   120	221	250	finally
    //   6	11	265	finally
    //   15	58	265	finally
    //   69	90	265	finally
    //   93	117	265	finally
    //   226	231	265	finally
    //   242	247	265	finally
    //   257	262	265	finally
    //   262	265	265	finally
    //   61	69	278	finally
  }
  
  public boolean isDbLockedByCurrentThread()
  {
    acquireReference();
    try
    {
      boolean bool = getThreadSession().hasConnection();
      return bool;
    }
    finally
    {
      releaseReference();
    }
  }
  
  @Deprecated
  public boolean isDbLockedByOtherThreads()
  {
    return false;
  }
  
  public boolean isInMemoryDatabase()
  {
    synchronized (this.mLock)
    {
      boolean bool = this.mConfigurationLocked.isInMemoryDb();
      return bool;
    }
  }
  
  public boolean isOpen()
  {
    for (;;)
    {
      synchronized (this.mLock)
      {
        if (this.mConnectionPoolLocked != null)
        {
          bool = true;
          return bool;
        }
      }
      boolean bool = false;
    }
  }
  
  public boolean isReadOnly()
  {
    synchronized (this.mLock)
    {
      boolean bool = isReadOnlyLocked();
      return bool;
    }
  }
  
  public boolean isWriteAheadLoggingEnabled()
  {
    for (;;)
    {
      synchronized (this.mLock)
      {
        throwIfNotOpenLocked();
        if ((0x20000000 & this.mConfigurationLocked.openFlags) != 0)
        {
          bool = true;
          return bool;
        }
      }
      boolean bool = false;
    }
  }
  
  @Deprecated
  public void markTableSyncable(String paramString1, String paramString2) {}
  
  @Deprecated
  public void markTableSyncable(String paramString1, String paramString2, String paramString3) {}
  
  public boolean needUpgrade(int paramInt)
  {
    return paramInt > getVersion();
  }
  
  protected void onAllReferencesReleased()
  {
    dispose(false);
  }
  
  void onCorruption()
  {
    EventLog.writeEvent(75004, getLabel());
    this.mErrorHandler.onCorruption(this);
  }
  
  public Cursor query(String paramString1, String[] paramArrayOfString1, String paramString2, String[] paramArrayOfString2, String paramString3, String paramString4, String paramString5)
  {
    return query(false, paramString1, paramArrayOfString1, paramString2, paramArrayOfString2, paramString3, paramString4, paramString5, null);
  }
  
  public Cursor query(String paramString1, String[] paramArrayOfString1, String paramString2, String[] paramArrayOfString2, String paramString3, String paramString4, String paramString5, String paramString6)
  {
    return query(false, paramString1, paramArrayOfString1, paramString2, paramArrayOfString2, paramString3, paramString4, paramString5, paramString6);
  }
  
  public Cursor query(boolean paramBoolean, String paramString1, String[] paramArrayOfString1, String paramString2, String[] paramArrayOfString2, String paramString3, String paramString4, String paramString5, String paramString6)
  {
    return queryWithFactory(null, paramBoolean, paramString1, paramArrayOfString1, paramString2, paramArrayOfString2, paramString3, paramString4, paramString5, paramString6, null);
  }
  
  public Cursor query(boolean paramBoolean, String paramString1, String[] paramArrayOfString1, String paramString2, String[] paramArrayOfString2, String paramString3, String paramString4, String paramString5, String paramString6, CancellationSignal paramCancellationSignal)
  {
    return queryWithFactory(null, paramBoolean, paramString1, paramArrayOfString1, paramString2, paramArrayOfString2, paramString3, paramString4, paramString5, paramString6, paramCancellationSignal);
  }
  
  public Cursor queryWithFactory(CursorFactory paramCursorFactory, boolean paramBoolean, String paramString1, String[] paramArrayOfString1, String paramString2, String[] paramArrayOfString2, String paramString3, String paramString4, String paramString5, String paramString6)
  {
    return queryWithFactory(paramCursorFactory, paramBoolean, paramString1, paramArrayOfString1, paramString2, paramArrayOfString2, paramString3, paramString4, paramString5, paramString6, null);
  }
  
  public Cursor queryWithFactory(CursorFactory paramCursorFactory, boolean paramBoolean, String paramString1, String[] paramArrayOfString1, String paramString2, String[] paramArrayOfString2, String paramString3, String paramString4, String paramString5, String paramString6, CancellationSignal paramCancellationSignal)
  {
    acquireReference();
    try
    {
      Cursor localCursor = rawQueryWithFactory(paramCursorFactory, SQLiteQueryBuilder.buildQueryString(paramBoolean, paramString1, paramArrayOfString1, paramString2, paramString3, paramString4, paramString5, paramString6), paramArrayOfString2, findEditTable(paramString1), paramCancellationSignal);
      return localCursor;
    }
    finally
    {
      releaseReference();
    }
  }
  
  public Cursor rawQuery(String paramString, String[] paramArrayOfString)
  {
    return rawQueryWithFactory(null, paramString, paramArrayOfString, null, null);
  }
  
  public Cursor rawQuery(String paramString, String[] paramArrayOfString, CancellationSignal paramCancellationSignal)
  {
    return rawQueryWithFactory(null, paramString, paramArrayOfString, null, paramCancellationSignal);
  }
  
  public Cursor rawQueryWithFactory(CursorFactory paramCursorFactory, String paramString1, String[] paramArrayOfString, String paramString2)
  {
    return rawQueryWithFactory(paramCursorFactory, paramString1, paramArrayOfString, paramString2, null);
  }
  
  /* Error */
  public Cursor rawQueryWithFactory(CursorFactory paramCursorFactory, String paramString1, String[] paramArrayOfString, String paramString2, CancellationSignal paramCancellationSignal)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 133	android/database/sqlite/SQLiteDatabase:acquireReference	()V
    //   4: new 698	android/database/sqlite/SQLiteDirectCursorDriver
    //   7: dup
    //   8: aload_0
    //   9: aload_2
    //   10: aload 4
    //   12: aload 5
    //   14: invokespecial 701	android/database/sqlite/SQLiteDirectCursorDriver:<init>	(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;Ljava/lang/String;Landroid/os/CancellationSignal;)V
    //   17: astore 6
    //   19: aload_1
    //   20: ifnull +21 -> 41
    //   23: aload 6
    //   25: aload_1
    //   26: aload_3
    //   27: invokeinterface 706 3 0
    //   32: astore 8
    //   34: aload_0
    //   35: invokevirtual 149	android/database/sqlite/SQLiteDatabase:releaseReference	()V
    //   38: aload 8
    //   40: areturn
    //   41: aload_0
    //   42: getfield 116	android/database/sqlite/SQLiteDatabase:mCursorFactory	Landroid/database/sqlite/SQLiteDatabase$CursorFactory;
    //   45: astore_1
    //   46: goto -23 -> 23
    //   49: astore 7
    //   51: aload_0
    //   52: invokevirtual 149	android/database/sqlite/SQLiteDatabase:releaseReference	()V
    //   55: aload 7
    //   57: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	58	0	this	SQLiteDatabase
    //   0	58	1	paramCursorFactory	CursorFactory
    //   0	58	2	paramString1	String
    //   0	58	3	paramArrayOfString	String[]
    //   0	58	4	paramString2	String
    //   0	58	5	paramCancellationSignal	CancellationSignal
    //   17	7	6	localSQLiteDirectCursorDriver	SQLiteDirectCursorDriver
    //   49	7	7	localObject	Object
    //   32	7	8	localCursor	Cursor
    // Exception table:
    //   from	to	target	type
    //   4	19	49	finally
    //   23	34	49	finally
    //   41	46	49	finally
  }
  
  public void reopenReadWrite()
  {
    synchronized (this.mLock)
    {
      throwIfNotOpenLocked();
      if (!isReadOnlyLocked()) {
        return;
      }
      i = this.mConfigurationLocked.openFlags;
      this.mConfigurationLocked.openFlags = (0x0 | 0xFFFFFFFE & this.mConfigurationLocked.openFlags);
    }
  }
  
  public long replace(String paramString1, String paramString2, ContentValues paramContentValues)
  {
    try
    {
      long l = insertWithOnConflict(paramString1, paramString2, paramContentValues, 5);
      return l;
    }
    catch (SQLException localSQLException)
    {
      Log.e("SQLiteDatabase", "Error inserting " + paramContentValues, localSQLException);
    }
    return -1L;
  }
  
  public long replaceOrThrow(String paramString1, String paramString2, ContentValues paramContentValues)
    throws SQLException
  {
    return insertWithOnConflict(paramString1, paramString2, paramContentValues, 5);
  }
  
  public void setForeignKeyConstraintsEnabled(boolean paramBoolean)
  {
    synchronized (this.mLock)
    {
      throwIfNotOpenLocked();
      if (this.mConfigurationLocked.foreignKeyConstraintsEnabled == paramBoolean) {
        return;
      }
      this.mConfigurationLocked.foreignKeyConstraintsEnabled = paramBoolean;
    }
    try
    {
      this.mConnectionPoolLocked.reconfigure(this.mConfigurationLocked);
      return;
    }
    catch (RuntimeException localRuntimeException)
    {
      localSQLiteDatabaseConfiguration = this.mConfigurationLocked;
      if (paramBoolean) {
        break label77;
      }
    }
    localObject2 = finally;
    throw ((Throwable)localObject2);
    SQLiteDatabaseConfiguration localSQLiteDatabaseConfiguration;
    label77:
    for (boolean bool = true;; bool = false)
    {
      localSQLiteDatabaseConfiguration.foreignKeyConstraintsEnabled = bool;
      throw localRuntimeException;
    }
  }
  
  public void setLocale(Locale paramLocale)
  {
    if (paramLocale == null) {
      throw new IllegalArgumentException("locale must not be null.");
    }
    synchronized (this.mLock)
    {
      throwIfNotOpenLocked();
      Locale localLocale = this.mConfigurationLocked.locale;
      this.mConfigurationLocked.locale = paramLocale;
      try
      {
        this.mConnectionPoolLocked.reconfigure(this.mConfigurationLocked);
        return;
      }
      catch (RuntimeException localRuntimeException)
      {
        this.mConfigurationLocked.locale = localLocale;
        throw localRuntimeException;
      }
    }
  }
  
  @Deprecated
  public void setLockingEnabled(boolean paramBoolean) {}
  
  public void setMaxSqlCacheSize(int paramInt)
  {
    if ((paramInt > 100) || (paramInt < 0)) {
      throw new IllegalStateException("expected value between 0 and 100");
    }
    synchronized (this.mLock)
    {
      throwIfNotOpenLocked();
      int i = this.mConfigurationLocked.maxSqlCacheSize;
      this.mConfigurationLocked.maxSqlCacheSize = paramInt;
      try
      {
        this.mConnectionPoolLocked.reconfigure(this.mConfigurationLocked);
        return;
      }
      catch (RuntimeException localRuntimeException)
      {
        this.mConfigurationLocked.maxSqlCacheSize = i;
        throw localRuntimeException;
      }
    }
  }
  
  public long setMaximumSize(long paramLong)
  {
    long l1 = getPageSize();
    long l2 = paramLong / l1;
    if (paramLong % l1 != 0L) {
      l2 += 1L;
    }
    return l1 * DatabaseUtils.longForQuery(this, "PRAGMA max_page_count = " + l2, null);
  }
  
  public void setPageSize(long paramLong)
  {
    execSQL("PRAGMA page_size = " + paramLong);
  }
  
  public void setTransactionSuccessful()
  {
    acquireReference();
    try
    {
      getThreadSession().setTransactionSuccessful();
      return;
    }
    finally
    {
      releaseReference();
    }
  }
  
  public void setVersion(int paramInt)
  {
    execSQL("PRAGMA user_version = " + paramInt);
  }
  
  public String toString()
  {
    return "SQLiteDatabase: " + getPath();
  }
  
  public int update(String paramString1, ContentValues paramContentValues, String paramString2, String[] paramArrayOfString)
  {
    return updateWithOnConflict(paramString1, paramContentValues, paramString2, paramArrayOfString, 0);
  }
  
  public int updateWithOnConflict(String paramString1, ContentValues paramContentValues, String paramString2, String[] paramArrayOfString, int paramInt)
  {
    if ((paramContentValues == null) || (paramContentValues.size() == 0)) {
      throw new IllegalArgumentException("Empty values");
    }
    acquireReference();
    int k;
    for (;;)
    {
      int i;
      int n;
      try
      {
        StringBuilder localStringBuilder = new StringBuilder(120);
        localStringBuilder.append("UPDATE ");
        localStringBuilder.append(CONFLICT_VALUES[paramInt]);
        localStringBuilder.append(paramString1);
        localStringBuilder.append(" SET ");
        i = paramContentValues.size();
        int j;
        Object[] arrayOfObject;
        if (paramArrayOfString == null)
        {
          j = i;
          arrayOfObject = new Object[j];
          Iterator localIterator = paramContentValues.keySet().iterator();
          k = 0;
          if (!localIterator.hasNext()) {
            break label313;
          }
          String str1 = (String)localIterator.next();
          if (k > 0)
          {
            str2 = ",";
            localStringBuilder.append(str2);
            localStringBuilder.append(str1);
            int i1 = k + 1;
            arrayOfObject[k] = paramContentValues.get(str1);
            localStringBuilder.append("=?");
            k = i1;
            continue;
          }
        }
        else
        {
          j = i + paramArrayOfString.length;
          continue;
          if (n < j)
          {
            arrayOfObject[n] = paramArrayOfString[(n - i)];
            n++;
            continue;
          }
          if (!TextUtils.isEmpty(paramString2))
          {
            localStringBuilder.append(" WHERE ");
            localStringBuilder.append(paramString2);
          }
          SQLiteStatement localSQLiteStatement = new SQLiteStatement(this, localStringBuilder.toString(), arrayOfObject);
          try
          {
            int m = localSQLiteStatement.executeUpdateDelete();
            return m;
          }
          finally {}
        }
        String str2 = "";
      }
      finally
      {
        releaseReference();
      }
      continue;
      label313:
      if (paramArrayOfString != null) {
        n = i;
      }
    }
  }
  
  @Deprecated
  public boolean yieldIfContended()
  {
    return yieldIfContendedHelper(false, -1L);
  }
  
  public boolean yieldIfContendedSafely()
  {
    return yieldIfContendedHelper(true, -1L);
  }
  
  public boolean yieldIfContendedSafely(long paramLong)
  {
    return yieldIfContendedHelper(true, paramLong);
  }
  
  public static abstract interface CursorFactory
  {
    public abstract Cursor newCursor(SQLiteDatabase paramSQLiteDatabase, SQLiteCursorDriver paramSQLiteCursorDriver, String paramString, SQLiteQuery paramSQLiteQuery);
  }
  
  public static abstract interface CustomFunction
  {
    public abstract void callback(String[] paramArrayOfString);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\sqlite\SQLiteDatabase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.database.sqlite;

import android.database.DatabaseUtils;
import android.os.CancellationSignal;
import android.os.CancellationSignal.OnCancelListener;
import android.util.Log;
import android.util.LruCache;
import android.util.Printer;
import dalvik.system.BlockGuard;
import dalvik.system.BlockGuard.Policy;
import dalvik.system.CloseGuard;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class SQLiteConnection
  implements CancellationSignal.OnCancelListener
{
  private static final boolean DEBUG = false;
  private static final byte[] EMPTY_BYTE_ARRAY;
  private static final String[] EMPTY_STRING_ARRAY;
  private static final String TAG = "SQLiteConnection";
  private static final Pattern TRIM_SQL_PATTERN;
  private int mCancellationSignalAttachCount;
  private final CloseGuard mCloseGuard = CloseGuard.get();
  private final SQLiteDatabaseConfiguration mConfiguration;
  private final int mConnectionId;
  private int mConnectionPtr;
  private final boolean mIsPrimaryConnection;
  private final boolean mIsReadOnlyConnection;
  private boolean mOnlyAllowReadOnlyOperations;
  private final SQLiteConnectionPool mPool;
  private final PreparedStatementCache mPreparedStatementCache;
  private PreparedStatement mPreparedStatementPool;
  private final OperationLog mRecentOperations = new OperationLog(null);
  
  static
  {
    if (!SQLiteConnection.class.desiredAssertionStatus()) {}
    for (boolean bool = true;; bool = false)
    {
      $assertionsDisabled = bool;
      EMPTY_STRING_ARRAY = new String[0];
      EMPTY_BYTE_ARRAY = new byte[0];
      TRIM_SQL_PATTERN = Pattern.compile("[\\s]*\\n+[\\s]*");
      return;
    }
  }
  
  private SQLiteConnection(SQLiteConnectionPool paramSQLiteConnectionPool, SQLiteDatabaseConfiguration paramSQLiteDatabaseConfiguration, int paramInt, boolean paramBoolean)
  {
    this.mPool = paramSQLiteConnectionPool;
    this.mConfiguration = new SQLiteDatabaseConfiguration(paramSQLiteDatabaseConfiguration);
    this.mConnectionId = paramInt;
    this.mIsPrimaryConnection = paramBoolean;
    if ((0x1 & paramSQLiteDatabaseConfiguration.openFlags) != 0) {}
    for (boolean bool = true;; bool = false)
    {
      this.mIsReadOnlyConnection = bool;
      this.mPreparedStatementCache = new PreparedStatementCache(this.mConfiguration.maxSqlCacheSize);
      this.mCloseGuard.open("close");
      return;
    }
  }
  
  private PreparedStatement acquirePreparedStatement(String paramString)
  {
    PreparedStatement localPreparedStatement = (PreparedStatement)this.mPreparedStatementCache.get(paramString);
    int i = 0;
    if (localPreparedStatement != null)
    {
      if (!localPreparedStatement.mInUse) {
        return localPreparedStatement;
      }
      i = 1;
    }
    int j = nativePrepareStatement(this.mConnectionPtr, paramString);
    try
    {
      int k = nativeGetParameterCount(this.mConnectionPtr, j);
      int m = DatabaseUtils.getSqlStatementType(paramString);
      localPreparedStatement = obtainPreparedStatement(paramString, j, k, m, nativeIsReadOnly(this.mConnectionPtr, j));
      if ((i == 0) && (isCacheable(m)))
      {
        this.mPreparedStatementCache.put(paramString, localPreparedStatement);
        localPreparedStatement.mInCache = true;
      }
      localPreparedStatement.mInUse = true;
      return localPreparedStatement;
    }
    catch (RuntimeException localRuntimeException)
    {
      if ((localPreparedStatement == null) || (!localPreparedStatement.mInCache)) {
        nativeFinalizeStatement(this.mConnectionPtr, j);
      }
      throw localRuntimeException;
    }
  }
  
  private void applyBlockGuardPolicy(PreparedStatement paramPreparedStatement)
  {
    if (!this.mConfiguration.isInMemoryDb())
    {
      if (paramPreparedStatement.mReadOnly) {
        BlockGuard.getThreadPolicy().onReadFromDisk();
      }
    }
    else {
      return;
    }
    BlockGuard.getThreadPolicy().onWriteToDisk();
  }
  
  private void attachCancellationSignal(CancellationSignal paramCancellationSignal)
  {
    if (paramCancellationSignal != null)
    {
      paramCancellationSignal.throwIfCanceled();
      this.mCancellationSignalAttachCount = (1 + this.mCancellationSignalAttachCount);
      if (this.mCancellationSignalAttachCount == 1)
      {
        nativeResetCancel(this.mConnectionPtr, true);
        paramCancellationSignal.setOnCancelListener(this);
      }
    }
  }
  
  private void bindArguments(PreparedStatement paramPreparedStatement, Object[] paramArrayOfObject)
  {
    if (paramArrayOfObject != null) {}
    for (int i = paramArrayOfObject.length; i != paramPreparedStatement.mNumParameters; i = 0) {
      throw new SQLiteBindOrColumnIndexOutOfRangeException("Expected " + paramPreparedStatement.mNumParameters + " bind arguments but " + paramArrayOfObject.length + " were provided.");
    }
    if (i == 0) {}
    int j;
    int k;
    do
    {
      return;
      j = paramPreparedStatement.mStatementPtr;
      k = 0;
    } while (k >= i);
    Object localObject = paramArrayOfObject[k];
    long l;
    switch (DatabaseUtils.getTypeOfObject(localObject))
    {
    case 3: 
    default: 
      if ((localObject instanceof Boolean))
      {
        int m = this.mConnectionPtr;
        int n = k + 1;
        if (((Boolean)localObject).booleanValue())
        {
          l = 1L;
          label166:
          nativeBindLong(m, j, n, l);
        }
      }
      break;
    }
    for (;;)
    {
      k++;
      break;
      nativeBindNull(this.mConnectionPtr, j, k + 1);
      continue;
      nativeBindLong(this.mConnectionPtr, j, k + 1, ((Number)localObject).longValue());
      continue;
      nativeBindDouble(this.mConnectionPtr, j, k + 1, ((Number)localObject).doubleValue());
      continue;
      nativeBindBlob(this.mConnectionPtr, j, k + 1, (byte[])localObject);
      continue;
      l = 0L;
      break label166;
      nativeBindString(this.mConnectionPtr, j, k + 1, localObject.toString());
    }
  }
  
  private static String canonicalizeSyncMode(String paramString)
  {
    if (paramString.equals("0")) {
      paramString = "OFF";
    }
    do
    {
      return paramString;
      if (paramString.equals("1")) {
        return "NORMAL";
      }
    } while (!paramString.equals("2"));
    return "FULL";
  }
  
  private void detachCancellationSignal(CancellationSignal paramCancellationSignal)
  {
    if (paramCancellationSignal != null)
    {
      assert (this.mCancellationSignalAttachCount > 0);
      this.mCancellationSignalAttachCount = (-1 + this.mCancellationSignalAttachCount);
      if (this.mCancellationSignalAttachCount == 0)
      {
        paramCancellationSignal.setOnCancelListener(null);
        nativeResetCancel(this.mConnectionPtr, false);
      }
    }
  }
  
  private void dispose(boolean paramBoolean)
  {
    if (this.mCloseGuard != null)
    {
      if (paramBoolean) {
        this.mCloseGuard.warnIfOpen();
      }
      this.mCloseGuard.close();
    }
    int i;
    if (this.mConnectionPtr != 0) {
      i = this.mRecentOperations.beginOperation("close", null, null);
    }
    try
    {
      this.mPreparedStatementCache.evictAll();
      nativeClose(this.mConnectionPtr);
      this.mConnectionPtr = 0;
      return;
    }
    finally
    {
      this.mRecentOperations.endOperation(i);
    }
  }
  
  private void finalizePreparedStatement(PreparedStatement paramPreparedStatement)
  {
    nativeFinalizeStatement(this.mConnectionPtr, paramPreparedStatement.mStatementPtr);
    recyclePreparedStatement(paramPreparedStatement);
  }
  
  private SQLiteDebug.DbStats getMainDbStatsUnsafe(int paramInt, long paramLong1, long paramLong2)
  {
    String str = this.mConfiguration.path;
    if (!this.mIsPrimaryConnection) {
      str = str + " (" + this.mConnectionId + ")";
    }
    return new SQLiteDebug.DbStats(str, paramLong1, paramLong2, paramInt, this.mPreparedStatementCache.hitCount(), this.mPreparedStatementCache.missCount(), this.mPreparedStatementCache.size());
  }
  
  private static boolean isCacheable(int paramInt)
  {
    return (paramInt == 2) || (paramInt == 1);
  }
  
  private static native void nativeBindBlob(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte);
  
  private static native void nativeBindDouble(int paramInt1, int paramInt2, int paramInt3, double paramDouble);
  
  private static native void nativeBindLong(int paramInt1, int paramInt2, int paramInt3, long paramLong);
  
  private static native void nativeBindNull(int paramInt1, int paramInt2, int paramInt3);
  
  private static native void nativeBindString(int paramInt1, int paramInt2, int paramInt3, String paramString);
  
  private static native void nativeCancel(int paramInt);
  
  private static native void nativeClose(int paramInt);
  
  private static native void nativeExecute(int paramInt1, int paramInt2);
  
  private static native int nativeExecuteForBlobFileDescriptor(int paramInt1, int paramInt2);
  
  private static native int nativeExecuteForChangedRowCount(int paramInt1, int paramInt2);
  
  private static native long nativeExecuteForCursorWindow(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean);
  
  private static native long nativeExecuteForLastInsertedRowId(int paramInt1, int paramInt2);
  
  private static native long nativeExecuteForLong(int paramInt1, int paramInt2);
  
  private static native String nativeExecuteForString(int paramInt1, int paramInt2);
  
  private static native void nativeFinalizeStatement(int paramInt1, int paramInt2);
  
  private static native int nativeGetColumnCount(int paramInt1, int paramInt2);
  
  private static native String nativeGetColumnName(int paramInt1, int paramInt2, int paramInt3);
  
  private static native int nativeGetDbLookaside(int paramInt);
  
  private static native int nativeGetParameterCount(int paramInt1, int paramInt2);
  
  private static native boolean nativeIsReadOnly(int paramInt1, int paramInt2);
  
  private static native int nativeOpen(String paramString1, int paramInt, String paramString2, boolean paramBoolean1, boolean paramBoolean2);
  
  private static native int nativePrepareStatement(int paramInt, String paramString);
  
  private static native void nativeRegisterCustomFunction(int paramInt, SQLiteCustomFunction paramSQLiteCustomFunction);
  
  private static native void nativeRegisterLocalizedCollators(int paramInt, String paramString);
  
  private static native void nativeResetCancel(int paramInt, boolean paramBoolean);
  
  private static native void nativeResetStatementAndClearBindings(int paramInt1, int paramInt2);
  
  private PreparedStatement obtainPreparedStatement(String paramString, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    PreparedStatement localPreparedStatement = this.mPreparedStatementPool;
    if (localPreparedStatement != null)
    {
      this.mPreparedStatementPool = localPreparedStatement.mPoolNext;
      localPreparedStatement.mPoolNext = null;
      localPreparedStatement.mInCache = false;
    }
    for (;;)
    {
      localPreparedStatement.mSql = paramString;
      localPreparedStatement.mStatementPtr = paramInt1;
      localPreparedStatement.mNumParameters = paramInt2;
      localPreparedStatement.mType = paramInt3;
      localPreparedStatement.mReadOnly = paramBoolean;
      return localPreparedStatement;
      localPreparedStatement = new PreparedStatement(null);
    }
  }
  
  static SQLiteConnection open(SQLiteConnectionPool paramSQLiteConnectionPool, SQLiteDatabaseConfiguration paramSQLiteDatabaseConfiguration, int paramInt, boolean paramBoolean)
  {
    SQLiteConnection localSQLiteConnection = new SQLiteConnection(paramSQLiteConnectionPool, paramSQLiteDatabaseConfiguration, paramInt, paramBoolean);
    try
    {
      localSQLiteConnection.open();
      return localSQLiteConnection;
    }
    catch (SQLiteException localSQLiteException)
    {
      localSQLiteConnection.dispose(false);
      throw localSQLiteException;
    }
  }
  
  private void open()
  {
    this.mConnectionPtr = nativeOpen(this.mConfiguration.path, this.mConfiguration.openFlags, this.mConfiguration.label, SQLiteDebug.DEBUG_SQL_STATEMENTS, SQLiteDebug.DEBUG_SQL_TIME);
    setPageSize();
    setForeignKeyModeFromConfiguration();
    setWalModeFromConfiguration();
    setJournalSizeLimit();
    setAutoCheckpointInterval();
    setLocaleFromConfiguration();
  }
  
  private void recyclePreparedStatement(PreparedStatement paramPreparedStatement)
  {
    paramPreparedStatement.mSql = null;
    paramPreparedStatement.mPoolNext = this.mPreparedStatementPool;
    this.mPreparedStatementPool = paramPreparedStatement;
  }
  
  private void releasePreparedStatement(PreparedStatement paramPreparedStatement)
  {
    paramPreparedStatement.mInUse = false;
    if (paramPreparedStatement.mInCache) {
      try
      {
        nativeResetStatementAndClearBindings(this.mConnectionPtr, paramPreparedStatement.mStatementPtr);
        return;
      }
      catch (SQLiteException localSQLiteException)
      {
        this.mPreparedStatementCache.remove(paramPreparedStatement.mSql);
        return;
      }
    }
    finalizePreparedStatement(paramPreparedStatement);
  }
  
  private void setAutoCheckpointInterval()
  {
    if ((!this.mConfiguration.isInMemoryDb()) && (!this.mIsReadOnlyConnection))
    {
      long l = SQLiteGlobal.getWALAutoCheckpoint();
      if (executeForLong("PRAGMA wal_autocheckpoint", null, null) != l) {
        executeForLong("PRAGMA wal_autocheckpoint=" + l, null, null);
      }
    }
  }
  
  private void setForeignKeyModeFromConfiguration()
  {
    if (!this.mIsReadOnlyConnection) {
      if (!this.mConfiguration.foreignKeyConstraintsEnabled) {
        break label60;
      }
    }
    label60:
    for (long l = 1L;; l = 0L)
    {
      if (executeForLong("PRAGMA foreign_keys", null, null) != l) {
        execute("PRAGMA foreign_keys=" + l, null, null);
      }
      return;
    }
  }
  
  private void setJournalMode(String paramString)
  {
    String str = executeForString("PRAGMA journal_mode", null, null);
    if (!str.equalsIgnoreCase(paramString)) {}
    try
    {
      boolean bool = executeForString("PRAGMA journal_mode=" + paramString, null, null).equalsIgnoreCase(paramString);
      if (bool) {
        return;
      }
    }
    catch (SQLiteDatabaseLockedException localSQLiteDatabaseLockedException)
    {
      Log.w("SQLiteConnection", "Could not change the database journal mode of '" + this.mConfiguration.label + "' from '" + str + "' to '" + paramString + "' because the database is locked.  This usually means that " + "there are other open connections to the database which prevents " + "the database from enabling or disabling write-ahead logging mode.  " + "Proceeding without changing the journal mode.");
    }
  }
  
  private void setJournalSizeLimit()
  {
    if ((!this.mConfiguration.isInMemoryDb()) && (!this.mIsReadOnlyConnection))
    {
      long l = SQLiteGlobal.getJournalSizeLimit();
      if (executeForLong("PRAGMA journal_size_limit", null, null) != l) {
        executeForLong("PRAGMA journal_size_limit=" + l, null, null);
      }
    }
  }
  
  /* Error */
  private void setLocaleFromConfiguration()
  {
    // Byte code:
    //   0: bipush 16
    //   2: aload_0
    //   3: getfield 93	android/database/sqlite/SQLiteConnection:mConfiguration	Landroid/database/sqlite/SQLiteDatabaseConfiguration;
    //   6: getfield 100	android/database/sqlite/SQLiteDatabaseConfiguration:openFlags	I
    //   9: iand
    //   10: ifeq +4 -> 14
    //   13: return
    //   14: aload_0
    //   15: getfield 93	android/database/sqlite/SQLiteConnection:mConfiguration	Landroid/database/sqlite/SQLiteDatabaseConfiguration;
    //   18: getfield 516	android/database/sqlite/SQLiteDatabaseConfiguration:locale	Ljava/util/Locale;
    //   21: invokevirtual 519	java/util/Locale:toString	()Ljava/lang/String;
    //   24: astore_1
    //   25: aload_0
    //   26: getfield 145	android/database/sqlite/SQLiteConnection:mConnectionPtr	I
    //   29: aload_1
    //   30: invokestatic 521	android/database/sqlite/SQLiteConnection:nativeRegisterLocalizedCollators	(ILjava/lang/String;)V
    //   33: aload_0
    //   34: getfield 102	android/database/sqlite/SQLiteConnection:mIsReadOnlyConnection	Z
    //   37: ifne -24 -> 13
    //   40: aload_0
    //   41: ldc_w 523
    //   44: aconst_null
    //   45: aconst_null
    //   46: invokevirtual 470	android/database/sqlite/SQLiteConnection:execute	(Ljava/lang/String;[Ljava/lang/Object;Landroid/os/CancellationSignal;)V
    //   49: aload_0
    //   50: ldc_w 525
    //   53: aconst_null
    //   54: aconst_null
    //   55: invokevirtual 479	android/database/sqlite/SQLiteConnection:executeForString	(Ljava/lang/String;[Ljava/lang/Object;Landroid/os/CancellationSignal;)Ljava/lang/String;
    //   58: astore_3
    //   59: aload_3
    //   60: ifnull +11 -> 71
    //   63: aload_3
    //   64: aload_1
    //   65: invokevirtual 300	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   68: ifne -55 -> 13
    //   71: aload_0
    //   72: ldc_w 527
    //   75: aconst_null
    //   76: aconst_null
    //   77: invokevirtual 470	android/database/sqlite/SQLiteConnection:execute	(Ljava/lang/String;[Ljava/lang/Object;Landroid/os/CancellationSignal;)V
    //   80: aload_0
    //   81: ldc_w 529
    //   84: aconst_null
    //   85: aconst_null
    //   86: invokevirtual 470	android/database/sqlite/SQLiteConnection:execute	(Ljava/lang/String;[Ljava/lang/Object;Landroid/os/CancellationSignal;)V
    //   89: aload_0
    //   90: ldc_w 531
    //   93: iconst_1
    //   94: anewarray 4	java/lang/Object
    //   97: dup
    //   98: iconst_0
    //   99: aload_1
    //   100: aastore
    //   101: aconst_null
    //   102: invokevirtual 470	android/database/sqlite/SQLiteConnection:execute	(Ljava/lang/String;[Ljava/lang/Object;Landroid/os/CancellationSignal;)V
    //   105: aload_0
    //   106: ldc_w 533
    //   109: aconst_null
    //   110: aconst_null
    //   111: invokevirtual 470	android/database/sqlite/SQLiteConnection:execute	(Ljava/lang/String;[Ljava/lang/Object;Landroid/os/CancellationSignal;)V
    //   114: iconst_1
    //   115: ifeq +69 -> 184
    //   118: ldc_w 535
    //   121: astore 6
    //   123: aload_0
    //   124: aload 6
    //   126: aconst_null
    //   127: aconst_null
    //   128: invokevirtual 470	android/database/sqlite/SQLiteConnection:execute	(Ljava/lang/String;[Ljava/lang/Object;Landroid/os/CancellationSignal;)V
    //   131: return
    //   132: astore_2
    //   133: new 400	android/database/sqlite/SQLiteException
    //   136: dup
    //   137: new 229	java/lang/StringBuilder
    //   140: dup
    //   141: invokespecial 230	java/lang/StringBuilder:<init>	()V
    //   144: ldc_w 537
    //   147: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   150: aload_0
    //   151: getfield 93	android/database/sqlite/SQLiteConnection:mConfiguration	Landroid/database/sqlite/SQLiteDatabaseConfiguration;
    //   154: getfield 409	android/database/sqlite/SQLiteDatabaseConfiguration:label	Ljava/lang/String;
    //   157: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: ldc_w 491
    //   163: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   166: aload_1
    //   167: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   170: ldc_w 539
    //   173: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   176: invokevirtual 247	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   179: aload_2
    //   180: invokespecial 542	android/database/sqlite/SQLiteException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   183: athrow
    //   184: ldc_w 544
    //   187: astore 6
    //   189: goto -66 -> 123
    //   192: aload_0
    //   193: aload 5
    //   195: aconst_null
    //   196: aconst_null
    //   197: invokevirtual 470	android/database/sqlite/SQLiteConnection:execute	(Ljava/lang/String;[Ljava/lang/Object;Landroid/os/CancellationSignal;)V
    //   200: aload 4
    //   202: athrow
    //   203: ldc_w 544
    //   206: astore 5
    //   208: goto -16 -> 192
    //   211: astore 4
    //   213: iconst_0
    //   214: ifeq -11 -> 203
    //   217: ldc_w 535
    //   220: astore 5
    //   222: goto -30 -> 192
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	225	0	this	SQLiteConnection
    //   24	143	1	str1	String
    //   132	48	2	localRuntimeException	RuntimeException
    //   58	6	3	str2	String
    //   200	1	4	localObject1	Object
    //   211	1	4	localObject2	Object
    //   193	28	5	str3	String
    //   121	67	6	str4	String
    // Exception table:
    //   from	to	target	type
    //   40	59	132	java/lang/RuntimeException
    //   63	71	132	java/lang/RuntimeException
    //   71	80	132	java/lang/RuntimeException
    //   123	131	132	java/lang/RuntimeException
    //   192	203	132	java/lang/RuntimeException
    //   80	114	211	finally
  }
  
  private void setPageSize()
  {
    if ((!this.mConfiguration.isInMemoryDb()) && (!this.mIsReadOnlyConnection))
    {
      long l = SQLiteGlobal.getDefaultPageSize();
      if (executeForLong("PRAGMA page_size", null, null) != l) {
        execute("PRAGMA page_size=" + l, null, null);
      }
    }
  }
  
  private void setSyncMode(String paramString)
  {
    if (!canonicalizeSyncMode(executeForString("PRAGMA synchronous", null, null)).equalsIgnoreCase(canonicalizeSyncMode(paramString))) {
      execute("PRAGMA synchronous=" + paramString, null, null);
    }
  }
  
  private void setWalModeFromConfiguration()
  {
    if ((!this.mConfiguration.isInMemoryDb()) && (!this.mIsReadOnlyConnection))
    {
      if ((0x20000000 & this.mConfiguration.openFlags) != 0)
      {
        setJournalMode("WAL");
        setSyncMode(SQLiteGlobal.getWALSyncMode());
      }
    }
    else {
      return;
    }
    setJournalMode(SQLiteGlobal.getDefaultJournalMode());
    setSyncMode(SQLiteGlobal.getDefaultSyncMode());
  }
  
  private void throwIfStatementForbidden(PreparedStatement paramPreparedStatement)
  {
    if ((this.mOnlyAllowReadOnlyOperations) && (!paramPreparedStatement.mReadOnly)) {
      throw new SQLiteException("Cannot execute this statement because it might modify the database but the connection is read-only.");
    }
  }
  
  private static String trimSqlForDisplay(String paramString)
  {
    return TRIM_SQL_PATTERN.matcher(paramString).replaceAll(" ");
  }
  
  void close()
  {
    dispose(false);
  }
  
  /* Error */
  void collectDbStats(ArrayList<SQLiteDebug.DbStats> paramArrayList)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 145	android/database/sqlite/SQLiteConnection:mConnectionPtr	I
    //   4: invokestatic 595	android/database/sqlite/SQLiteConnection:nativeGetDbLookaside	(I)I
    //   7: istore_2
    //   8: lconst_0
    //   9: lstore_3
    //   10: lconst_0
    //   11: lstore 5
    //   13: aload_0
    //   14: ldc_w 597
    //   17: aconst_null
    //   18: aconst_null
    //   19: invokevirtual 454	android/database/sqlite/SQLiteConnection:executeForLong	(Ljava/lang/String;[Ljava/lang/Object;Landroid/os/CancellationSignal;)J
    //   22: lstore_3
    //   23: aload_0
    //   24: ldc_w 599
    //   27: aconst_null
    //   28: aconst_null
    //   29: invokevirtual 454	android/database/sqlite/SQLiteConnection:executeForLong	(Ljava/lang/String;[Ljava/lang/Object;Landroid/os/CancellationSignal;)J
    //   32: lstore 26
    //   34: lload 26
    //   36: lstore 5
    //   38: aload_1
    //   39: aload_0
    //   40: iload_2
    //   41: lload_3
    //   42: lload 5
    //   44: invokespecial 601	android/database/sqlite/SQLiteConnection:getMainDbStatsUnsafe	(IJJ)Landroid/database/sqlite/SQLiteDebug$DbStats;
    //   47: invokevirtual 606	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   50: pop
    //   51: new 608	android/database/CursorWindow
    //   54: dup
    //   55: ldc_w 609
    //   58: invokespecial 610	android/database/CursorWindow:<init>	(Ljava/lang/String;)V
    //   61: astore 9
    //   63: aload_0
    //   64: ldc_w 612
    //   67: aconst_null
    //   68: aload 9
    //   70: iconst_0
    //   71: iconst_0
    //   72: iconst_0
    //   73: aconst_null
    //   74: invokevirtual 616	android/database/sqlite/SQLiteConnection:executeForCursorWindow	(Ljava/lang/String;[Ljava/lang/Object;Landroid/database/CursorWindow;IIZLandroid/os/CancellationSignal;)I
    //   77: pop
    //   78: iconst_1
    //   79: istore 13
    //   81: aload 9
    //   83: invokevirtual 619	android/database/CursorWindow:getNumRows	()I
    //   86: istore 14
    //   88: iload 13
    //   90: iload 14
    //   92: if_icmpge +190 -> 282
    //   95: aload 9
    //   97: iload 13
    //   99: iconst_1
    //   100: invokevirtual 622	android/database/CursorWindow:getString	(II)Ljava/lang/String;
    //   103: astore 15
    //   105: aload 9
    //   107: iload 13
    //   109: iconst_2
    //   110: invokevirtual 622	android/database/CursorWindow:getString	(II)Ljava/lang/String;
    //   113: astore 16
    //   115: lconst_0
    //   116: lstore 17
    //   118: lconst_0
    //   119: lstore 19
    //   121: aload_0
    //   122: new 229	java/lang/StringBuilder
    //   125: dup
    //   126: invokespecial 230	java/lang/StringBuilder:<init>	()V
    //   129: ldc_w 624
    //   132: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   135: aload 15
    //   137: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   140: ldc_w 626
    //   143: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   146: invokevirtual 247	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   149: aconst_null
    //   150: aconst_null
    //   151: invokevirtual 454	android/database/sqlite/SQLiteConnection:executeForLong	(Ljava/lang/String;[Ljava/lang/Object;Landroid/os/CancellationSignal;)J
    //   154: lstore 17
    //   156: aload_0
    //   157: new 229	java/lang/StringBuilder
    //   160: dup
    //   161: invokespecial 230	java/lang/StringBuilder:<init>	()V
    //   164: ldc_w 624
    //   167: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   170: aload 15
    //   172: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   175: ldc_w 628
    //   178: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: invokevirtual 247	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   184: aconst_null
    //   185: aconst_null
    //   186: invokevirtual 454	android/database/sqlite/SQLiteConnection:executeForLong	(Ljava/lang/String;[Ljava/lang/Object;Landroid/os/CancellationSignal;)J
    //   189: lstore 24
    //   191: lload 24
    //   193: lstore 19
    //   195: new 229	java/lang/StringBuilder
    //   198: dup
    //   199: invokespecial 230	java/lang/StringBuilder:<init>	()V
    //   202: ldc_w 630
    //   205: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   208: aload 15
    //   210: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   213: invokevirtual 247	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   216: astore 22
    //   218: aload 16
    //   220: invokevirtual 633	java/lang/String:isEmpty	()Z
    //   223: ifne +31 -> 254
    //   226: new 229	java/lang/StringBuilder
    //   229: dup
    //   230: invokespecial 230	java/lang/StringBuilder:<init>	()V
    //   233: aload 22
    //   235: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   238: ldc_w 635
    //   241: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   244: aload 16
    //   246: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   249: invokevirtual 247	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   252: astore 22
    //   254: aload_1
    //   255: new 349	android/database/sqlite/SQLiteDebug$DbStats
    //   258: dup
    //   259: aload 22
    //   261: lload 17
    //   263: lload 19
    //   265: iconst_0
    //   266: iconst_0
    //   267: iconst_0
    //   268: iconst_0
    //   269: invokespecial 362	android/database/sqlite/SQLiteDebug$DbStats:<init>	(Ljava/lang/String;JJIIII)V
    //   272: invokevirtual 606	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   275: pop
    //   276: iinc 13 1
    //   279: goto -198 -> 81
    //   282: aload 9
    //   284: invokevirtual 636	android/database/CursorWindow:close	()V
    //   287: return
    //   288: astore 11
    //   290: aload 9
    //   292: invokevirtual 636	android/database/CursorWindow:close	()V
    //   295: return
    //   296: astore 10
    //   298: aload 9
    //   300: invokevirtual 636	android/database/CursorWindow:close	()V
    //   303: aload 10
    //   305: athrow
    //   306: astore 21
    //   308: goto -113 -> 195
    //   311: astore 7
    //   313: goto -275 -> 38
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	316	0	this	SQLiteConnection
    //   0	316	1	paramArrayList	ArrayList<SQLiteDebug.DbStats>
    //   7	34	2	i	int
    //   9	33	3	l1	long
    //   11	32	5	l2	long
    //   311	1	7	localSQLiteException1	SQLiteException
    //   61	238	9	localCursorWindow	android.database.CursorWindow
    //   296	8	10	localObject	Object
    //   288	1	11	localSQLiteException2	SQLiteException
    //   79	198	13	j	int
    //   86	7	14	k	int
    //   103	106	15	str1	String
    //   113	132	16	str2	String
    //   116	146	17	l3	long
    //   119	145	19	l4	long
    //   306	1	21	localSQLiteException3	SQLiteException
    //   216	44	22	str3	String
    //   189	3	24	l5	long
    //   32	3	26	l6	long
    // Exception table:
    //   from	to	target	type
    //   63	78	288	android/database/sqlite/SQLiteException
    //   81	88	288	android/database/sqlite/SQLiteException
    //   95	115	288	android/database/sqlite/SQLiteException
    //   195	254	288	android/database/sqlite/SQLiteException
    //   254	276	288	android/database/sqlite/SQLiteException
    //   63	78	296	finally
    //   81	88	296	finally
    //   95	115	296	finally
    //   121	191	296	finally
    //   195	254	296	finally
    //   254	276	296	finally
    //   121	191	306	android/database/sqlite/SQLiteException
    //   13	34	311	android/database/sqlite/SQLiteException
  }
  
  void collectDbStatsUnsafe(ArrayList<SQLiteDebug.DbStats> paramArrayList)
  {
    paramArrayList.add(getMainDbStatsUnsafe(0, 0L, 0L));
  }
  
  String describeCurrentOperationUnsafe()
  {
    return this.mRecentOperations.describeCurrentOperation();
  }
  
  public void dump(Printer paramPrinter, boolean paramBoolean)
  {
    dumpUnsafe(paramPrinter, paramBoolean);
  }
  
  void dumpUnsafe(Printer paramPrinter, boolean paramBoolean)
  {
    paramPrinter.println("Connection #" + this.mConnectionId + ":");
    if (paramBoolean) {
      paramPrinter.println("  connectionPtr: 0x" + Integer.toHexString(this.mConnectionPtr));
    }
    paramPrinter.println("  isPrimaryConnection: " + this.mIsPrimaryConnection);
    paramPrinter.println("  onlyAllowReadOnlyOperations: " + this.mOnlyAllowReadOnlyOperations);
    this.mRecentOperations.dump(paramPrinter);
    if (paramBoolean) {
      this.mPreparedStatementCache.dump(paramPrinter);
    }
  }
  
  /* Error */
  public void execute(String paramString, Object[] paramArrayOfObject, CancellationSignal paramCancellationSignal)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +14 -> 15
    //   4: new 676	java/lang/IllegalArgumentException
    //   7: dup
    //   8: ldc_w 678
    //   11: invokespecial 679	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   14: athrow
    //   15: aload_0
    //   16: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   19: ldc_w 680
    //   22: aload_1
    //   23: aload_2
    //   24: invokevirtual 325	android/database/sqlite/SQLiteConnection$OperationLog:beginOperation	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)I
    //   27: istore 4
    //   29: aload_0
    //   30: aload_1
    //   31: invokespecial 682	android/database/sqlite/SQLiteConnection:acquirePreparedStatement	(Ljava/lang/String;)Landroid/database/sqlite/SQLiteConnection$PreparedStatement;
    //   34: astore 7
    //   36: aload_0
    //   37: aload 7
    //   39: invokespecial 684	android/database/sqlite/SQLiteConnection:throwIfStatementForbidden	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   42: aload_0
    //   43: aload 7
    //   45: aload_2
    //   46: invokespecial 686	android/database/sqlite/SQLiteConnection:bindArguments	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;[Ljava/lang/Object;)V
    //   49: aload_0
    //   50: aload 7
    //   52: invokespecial 688	android/database/sqlite/SQLiteConnection:applyBlockGuardPolicy	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   55: aload_0
    //   56: aload_3
    //   57: invokespecial 690	android/database/sqlite/SQLiteConnection:attachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   60: aload_0
    //   61: getfield 145	android/database/sqlite/SQLiteConnection:mConnectionPtr	I
    //   64: aload 7
    //   66: getfield 252	android/database/sqlite/SQLiteConnection$PreparedStatement:mStatementPtr	I
    //   69: invokestatic 692	android/database/sqlite/SQLiteConnection:nativeExecute	(II)V
    //   72: aload_0
    //   73: aload_3
    //   74: invokespecial 694	android/database/sqlite/SQLiteConnection:detachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   77: aload_0
    //   78: aload 7
    //   80: invokespecial 696	android/database/sqlite/SQLiteConnection:releasePreparedStatement	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   83: aload_0
    //   84: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   87: iload 4
    //   89: invokevirtual 335	android/database/sqlite/SQLiteConnection$OperationLog:endOperation	(I)V
    //   92: return
    //   93: astore 9
    //   95: aload_0
    //   96: aload_3
    //   97: invokespecial 694	android/database/sqlite/SQLiteConnection:detachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   100: aload 9
    //   102: athrow
    //   103: astore 8
    //   105: aload_0
    //   106: aload 7
    //   108: invokespecial 696	android/database/sqlite/SQLiteConnection:releasePreparedStatement	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   111: aload 8
    //   113: athrow
    //   114: astore 6
    //   116: aload_0
    //   117: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   120: iload 4
    //   122: aload 6
    //   124: invokevirtual 700	android/database/sqlite/SQLiteConnection$OperationLog:failOperation	(ILjava/lang/Exception;)V
    //   127: aload 6
    //   129: athrow
    //   130: astore 5
    //   132: aload_0
    //   133: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   136: iload 4
    //   138: invokevirtual 335	android/database/sqlite/SQLiteConnection$OperationLog:endOperation	(I)V
    //   141: aload 5
    //   143: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	144	0	this	SQLiteConnection
    //   0	144	1	paramString	String
    //   0	144	2	paramArrayOfObject	Object[]
    //   0	144	3	paramCancellationSignal	CancellationSignal
    //   27	110	4	i	int
    //   130	12	5	localObject1	Object
    //   114	14	6	localRuntimeException	RuntimeException
    //   34	73	7	localPreparedStatement	PreparedStatement
    //   103	9	8	localObject2	Object
    //   93	8	9	localObject3	Object
    // Exception table:
    //   from	to	target	type
    //   60	72	93	finally
    //   36	60	103	finally
    //   72	77	103	finally
    //   95	103	103	finally
    //   29	36	114	java/lang/RuntimeException
    //   77	83	114	java/lang/RuntimeException
    //   105	114	114	java/lang/RuntimeException
    //   29	36	130	finally
    //   77	83	130	finally
    //   105	114	130	finally
    //   116	130	130	finally
  }
  
  /* Error */
  public android.os.ParcelFileDescriptor executeForBlobFileDescriptor(String paramString, Object[] paramArrayOfObject, CancellationSignal paramCancellationSignal)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +14 -> 15
    //   4: new 676	java/lang/IllegalArgumentException
    //   7: dup
    //   8: ldc_w 678
    //   11: invokespecial 679	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   14: athrow
    //   15: aload_0
    //   16: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   19: ldc_w 703
    //   22: aload_1
    //   23: aload_2
    //   24: invokevirtual 325	android/database/sqlite/SQLiteConnection$OperationLog:beginOperation	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)I
    //   27: istore 4
    //   29: aload_0
    //   30: aload_1
    //   31: invokespecial 682	android/database/sqlite/SQLiteConnection:acquirePreparedStatement	(Ljava/lang/String;)Landroid/database/sqlite/SQLiteConnection$PreparedStatement;
    //   34: astore 7
    //   36: aload_0
    //   37: aload 7
    //   39: invokespecial 684	android/database/sqlite/SQLiteConnection:throwIfStatementForbidden	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   42: aload_0
    //   43: aload 7
    //   45: aload_2
    //   46: invokespecial 686	android/database/sqlite/SQLiteConnection:bindArguments	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;[Ljava/lang/Object;)V
    //   49: aload_0
    //   50: aload 7
    //   52: invokespecial 688	android/database/sqlite/SQLiteConnection:applyBlockGuardPolicy	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   55: aload_0
    //   56: aload_3
    //   57: invokespecial 690	android/database/sqlite/SQLiteConnection:attachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   60: aload_0
    //   61: getfield 145	android/database/sqlite/SQLiteConnection:mConnectionPtr	I
    //   64: aload 7
    //   66: getfield 252	android/database/sqlite/SQLiteConnection$PreparedStatement:mStatementPtr	I
    //   69: invokestatic 705	android/database/sqlite/SQLiteConnection:nativeExecuteForBlobFileDescriptor	(II)I
    //   72: istore 10
    //   74: iload 10
    //   76: iflt +37 -> 113
    //   79: iload 10
    //   81: invokestatic 711	android/os/ParcelFileDescriptor:adoptFd	(I)Landroid/os/ParcelFileDescriptor;
    //   84: astore 11
    //   86: aload 11
    //   88: astore 12
    //   90: aload_0
    //   91: aload_3
    //   92: invokespecial 694	android/database/sqlite/SQLiteConnection:detachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   95: aload_0
    //   96: aload 7
    //   98: invokespecial 696	android/database/sqlite/SQLiteConnection:releasePreparedStatement	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   101: aload_0
    //   102: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   105: iload 4
    //   107: invokevirtual 335	android/database/sqlite/SQLiteConnection$OperationLog:endOperation	(I)V
    //   110: aload 12
    //   112: areturn
    //   113: aconst_null
    //   114: astore 12
    //   116: goto -26 -> 90
    //   119: astore 9
    //   121: aload_0
    //   122: aload_3
    //   123: invokespecial 694	android/database/sqlite/SQLiteConnection:detachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   126: aload 9
    //   128: athrow
    //   129: astore 8
    //   131: aload_0
    //   132: aload 7
    //   134: invokespecial 696	android/database/sqlite/SQLiteConnection:releasePreparedStatement	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   137: aload 8
    //   139: athrow
    //   140: astore 6
    //   142: aload_0
    //   143: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   146: iload 4
    //   148: aload 6
    //   150: invokevirtual 700	android/database/sqlite/SQLiteConnection$OperationLog:failOperation	(ILjava/lang/Exception;)V
    //   153: aload 6
    //   155: athrow
    //   156: astore 5
    //   158: aload_0
    //   159: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   162: iload 4
    //   164: invokevirtual 335	android/database/sqlite/SQLiteConnection$OperationLog:endOperation	(I)V
    //   167: aload 5
    //   169: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	170	0	this	SQLiteConnection
    //   0	170	1	paramString	String
    //   0	170	2	paramArrayOfObject	Object[]
    //   0	170	3	paramCancellationSignal	CancellationSignal
    //   27	136	4	i	int
    //   156	12	5	localObject1	Object
    //   140	14	6	localRuntimeException	RuntimeException
    //   34	99	7	localPreparedStatement	PreparedStatement
    //   129	9	8	localObject2	Object
    //   119	8	9	localObject3	Object
    //   72	8	10	j	int
    //   84	3	11	localParcelFileDescriptor1	android.os.ParcelFileDescriptor
    //   88	27	12	localParcelFileDescriptor2	android.os.ParcelFileDescriptor
    // Exception table:
    //   from	to	target	type
    //   60	74	119	finally
    //   79	86	119	finally
    //   36	60	129	finally
    //   90	95	129	finally
    //   121	129	129	finally
    //   29	36	140	java/lang/RuntimeException
    //   95	101	140	java/lang/RuntimeException
    //   131	140	140	java/lang/RuntimeException
    //   29	36	156	finally
    //   95	101	156	finally
    //   131	140	156	finally
    //   142	156	156	finally
  }
  
  /* Error */
  public int executeForChangedRowCount(String paramString, Object[] paramArrayOfObject, CancellationSignal paramCancellationSignal)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +14 -> 15
    //   4: new 676	java/lang/IllegalArgumentException
    //   7: dup
    //   8: ldc_w 678
    //   11: invokespecial 679	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   14: athrow
    //   15: iconst_0
    //   16: istore 4
    //   18: aload_0
    //   19: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   22: ldc_w 714
    //   25: aload_1
    //   26: aload_2
    //   27: invokevirtual 325	android/database/sqlite/SQLiteConnection$OperationLog:beginOperation	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)I
    //   30: istore 5
    //   32: aload_0
    //   33: aload_1
    //   34: invokespecial 682	android/database/sqlite/SQLiteConnection:acquirePreparedStatement	(Ljava/lang/String;)Landroid/database/sqlite/SQLiteConnection$PreparedStatement;
    //   37: astore 8
    //   39: aload_0
    //   40: aload 8
    //   42: invokespecial 684	android/database/sqlite/SQLiteConnection:throwIfStatementForbidden	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   45: aload_0
    //   46: aload 8
    //   48: aload_2
    //   49: invokespecial 686	android/database/sqlite/SQLiteConnection:bindArguments	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;[Ljava/lang/Object;)V
    //   52: aload_0
    //   53: aload 8
    //   55: invokespecial 688	android/database/sqlite/SQLiteConnection:applyBlockGuardPolicy	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   58: aload_0
    //   59: aload_3
    //   60: invokespecial 690	android/database/sqlite/SQLiteConnection:attachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   63: aload_0
    //   64: getfield 145	android/database/sqlite/SQLiteConnection:mConnectionPtr	I
    //   67: aload 8
    //   69: getfield 252	android/database/sqlite/SQLiteConnection$PreparedStatement:mStatementPtr	I
    //   72: invokestatic 716	android/database/sqlite/SQLiteConnection:nativeExecuteForChangedRowCount	(II)I
    //   75: istore 11
    //   77: iload 11
    //   79: istore 4
    //   81: aload_0
    //   82: aload_3
    //   83: invokespecial 694	android/database/sqlite/SQLiteConnection:detachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   86: aload_0
    //   87: aload 8
    //   89: invokespecial 696	android/database/sqlite/SQLiteConnection:releasePreparedStatement	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   92: aload_0
    //   93: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   96: iload 5
    //   98: invokevirtual 719	android/database/sqlite/SQLiteConnection$OperationLog:endOperationDeferLog	(I)Z
    //   101: ifeq +33 -> 134
    //   104: aload_0
    //   105: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   108: iload 5
    //   110: new 229	java/lang/StringBuilder
    //   113: dup
    //   114: invokespecial 230	java/lang/StringBuilder:<init>	()V
    //   117: ldc_w 721
    //   120: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   123: iload 4
    //   125: invokevirtual 239	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   128: invokevirtual 247	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   131: invokevirtual 724	android/database/sqlite/SQLiteConnection$OperationLog:logOperation	(ILjava/lang/String;)V
    //   134: iload 4
    //   136: ireturn
    //   137: astore 10
    //   139: aload_0
    //   140: aload_3
    //   141: invokespecial 694	android/database/sqlite/SQLiteConnection:detachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   144: aload 10
    //   146: athrow
    //   147: astore 9
    //   149: aload_0
    //   150: aload 8
    //   152: invokespecial 696	android/database/sqlite/SQLiteConnection:releasePreparedStatement	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   155: aload 9
    //   157: athrow
    //   158: astore 7
    //   160: aload_0
    //   161: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   164: iload 5
    //   166: aload 7
    //   168: invokevirtual 700	android/database/sqlite/SQLiteConnection$OperationLog:failOperation	(ILjava/lang/Exception;)V
    //   171: aload 7
    //   173: athrow
    //   174: astore 6
    //   176: aload_0
    //   177: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   180: iload 5
    //   182: invokevirtual 719	android/database/sqlite/SQLiteConnection$OperationLog:endOperationDeferLog	(I)Z
    //   185: ifeq +33 -> 218
    //   188: aload_0
    //   189: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   192: iload 5
    //   194: new 229	java/lang/StringBuilder
    //   197: dup
    //   198: invokespecial 230	java/lang/StringBuilder:<init>	()V
    //   201: ldc_w 721
    //   204: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   207: iload 4
    //   209: invokevirtual 239	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   212: invokevirtual 247	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   215: invokevirtual 724	android/database/sqlite/SQLiteConnection$OperationLog:logOperation	(ILjava/lang/String;)V
    //   218: aload 6
    //   220: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	221	0	this	SQLiteConnection
    //   0	221	1	paramString	String
    //   0	221	2	paramArrayOfObject	Object[]
    //   0	221	3	paramCancellationSignal	CancellationSignal
    //   16	192	4	i	int
    //   30	163	5	j	int
    //   174	45	6	localObject1	Object
    //   158	14	7	localRuntimeException	RuntimeException
    //   37	114	8	localPreparedStatement	PreparedStatement
    //   147	9	9	localObject2	Object
    //   137	8	10	localObject3	Object
    //   75	3	11	k	int
    // Exception table:
    //   from	to	target	type
    //   63	77	137	finally
    //   39	63	147	finally
    //   81	86	147	finally
    //   139	147	147	finally
    //   32	39	158	java/lang/RuntimeException
    //   86	92	158	java/lang/RuntimeException
    //   149	158	158	java/lang/RuntimeException
    //   32	39	174	finally
    //   86	92	174	finally
    //   149	158	174	finally
    //   160	174	174	finally
  }
  
  /* Error */
  public int executeForCursorWindow(String paramString, Object[] paramArrayOfObject, android.database.CursorWindow paramCursorWindow, int paramInt1, int paramInt2, boolean paramBoolean, CancellationSignal paramCancellationSignal)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +14 -> 15
    //   4: new 676	java/lang/IllegalArgumentException
    //   7: dup
    //   8: ldc_w 678
    //   11: invokespecial 679	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   14: athrow
    //   15: aload_3
    //   16: ifnonnull +14 -> 30
    //   19: new 676	java/lang/IllegalArgumentException
    //   22: dup
    //   23: ldc_w 726
    //   26: invokespecial 679	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   29: athrow
    //   30: aload_3
    //   31: invokevirtual 729	android/database/CursorWindow:acquireReference	()V
    //   34: iconst_m1
    //   35: istore 8
    //   37: iconst_m1
    //   38: istore 9
    //   40: iconst_m1
    //   41: istore 10
    //   43: aload_0
    //   44: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   47: ldc_w 730
    //   50: aload_1
    //   51: aload_2
    //   52: invokevirtual 325	android/database/sqlite/SQLiteConnection$OperationLog:beginOperation	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)I
    //   55: istore 12
    //   57: aload_0
    //   58: aload_1
    //   59: invokespecial 682	android/database/sqlite/SQLiteConnection:acquirePreparedStatement	(Ljava/lang/String;)Landroid/database/sqlite/SQLiteConnection$PreparedStatement;
    //   62: astore 15
    //   64: aload_0
    //   65: aload 15
    //   67: invokespecial 684	android/database/sqlite/SQLiteConnection:throwIfStatementForbidden	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   70: aload_0
    //   71: aload 15
    //   73: aload_2
    //   74: invokespecial 686	android/database/sqlite/SQLiteConnection:bindArguments	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;[Ljava/lang/Object;)V
    //   77: aload_0
    //   78: aload 15
    //   80: invokespecial 688	android/database/sqlite/SQLiteConnection:applyBlockGuardPolicy	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   83: aload_0
    //   84: aload 7
    //   86: invokespecial 690	android/database/sqlite/SQLiteConnection:attachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   89: aload_0
    //   90: getfield 145	android/database/sqlite/SQLiteConnection:mConnectionPtr	I
    //   93: aload 15
    //   95: getfield 252	android/database/sqlite/SQLiteConnection$PreparedStatement:mStatementPtr	I
    //   98: aload_3
    //   99: getfield 733	android/database/CursorWindow:mWindowPtr	I
    //   102: iload 4
    //   104: iload 5
    //   106: iload 6
    //   108: invokestatic 735	android/database/sqlite/SQLiteConnection:nativeExecuteForCursorWindow	(IIIIIZ)J
    //   111: lstore 18
    //   113: lload 18
    //   115: bipush 32
    //   117: lshr
    //   118: l2i
    //   119: istore 8
    //   121: lload 18
    //   123: l2i
    //   124: istore 9
    //   126: aload_3
    //   127: invokevirtual 619	android/database/CursorWindow:getNumRows	()I
    //   130: istore 10
    //   132: aload_3
    //   133: iload 8
    //   135: invokevirtual 738	android/database/CursorWindow:setStartPosition	(I)V
    //   138: aload_0
    //   139: aload 7
    //   141: invokespecial 694	android/database/sqlite/SQLiteConnection:detachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   144: aload_0
    //   145: aload 15
    //   147: invokespecial 696	android/database/sqlite/SQLiteConnection:releasePreparedStatement	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   150: aload_0
    //   151: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   154: iload 12
    //   156: invokevirtual 719	android/database/sqlite/SQLiteConnection$OperationLog:endOperationDeferLog	(I)Z
    //   159: ifeq +76 -> 235
    //   162: aload_0
    //   163: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   166: iload 12
    //   168: new 229	java/lang/StringBuilder
    //   171: dup
    //   172: invokespecial 230	java/lang/StringBuilder:<init>	()V
    //   175: ldc_w 740
    //   178: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: aload_3
    //   182: invokevirtual 743	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   185: ldc_w 745
    //   188: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   191: iload 4
    //   193: invokevirtual 239	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   196: ldc_w 747
    //   199: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   202: iload 8
    //   204: invokevirtual 239	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   207: ldc_w 749
    //   210: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   213: iload 10
    //   215: invokevirtual 239	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   218: ldc_w 751
    //   221: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   224: iload 9
    //   226: invokevirtual 239	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   229: invokevirtual 247	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   232: invokevirtual 724	android/database/sqlite/SQLiteConnection$OperationLog:logOperation	(ILjava/lang/String;)V
    //   235: aload_3
    //   236: invokevirtual 754	android/database/CursorWindow:releaseReference	()V
    //   239: iload 9
    //   241: ireturn
    //   242: astore 17
    //   244: aload_0
    //   245: aload 7
    //   247: invokespecial 694	android/database/sqlite/SQLiteConnection:detachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   250: aload 17
    //   252: athrow
    //   253: astore 16
    //   255: aload_0
    //   256: aload 15
    //   258: invokespecial 696	android/database/sqlite/SQLiteConnection:releasePreparedStatement	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   261: aload 16
    //   263: athrow
    //   264: astore 14
    //   266: aload_0
    //   267: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   270: iload 12
    //   272: aload 14
    //   274: invokevirtual 700	android/database/sqlite/SQLiteConnection$OperationLog:failOperation	(ILjava/lang/Exception;)V
    //   277: aload 14
    //   279: athrow
    //   280: astore 13
    //   282: aload_0
    //   283: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   286: iload 12
    //   288: invokevirtual 719	android/database/sqlite/SQLiteConnection$OperationLog:endOperationDeferLog	(I)Z
    //   291: ifeq +76 -> 367
    //   294: aload_0
    //   295: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   298: iload 12
    //   300: new 229	java/lang/StringBuilder
    //   303: dup
    //   304: invokespecial 230	java/lang/StringBuilder:<init>	()V
    //   307: ldc_w 740
    //   310: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   313: aload_3
    //   314: invokevirtual 743	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   317: ldc_w 745
    //   320: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   323: iload 4
    //   325: invokevirtual 239	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   328: ldc_w 747
    //   331: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   334: iload 8
    //   336: invokevirtual 239	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   339: ldc_w 749
    //   342: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   345: iload 10
    //   347: invokevirtual 239	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   350: ldc_w 751
    //   353: invokevirtual 236	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   356: iload 9
    //   358: invokevirtual 239	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   361: invokevirtual 247	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   364: invokevirtual 724	android/database/sqlite/SQLiteConnection$OperationLog:logOperation	(ILjava/lang/String;)V
    //   367: aload 13
    //   369: athrow
    //   370: astore 11
    //   372: aload_3
    //   373: invokevirtual 754	android/database/CursorWindow:releaseReference	()V
    //   376: aload 11
    //   378: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	379	0	this	SQLiteConnection
    //   0	379	1	paramString	String
    //   0	379	2	paramArrayOfObject	Object[]
    //   0	379	3	paramCursorWindow	android.database.CursorWindow
    //   0	379	4	paramInt1	int
    //   0	379	5	paramInt2	int
    //   0	379	6	paramBoolean	boolean
    //   0	379	7	paramCancellationSignal	CancellationSignal
    //   35	300	8	i	int
    //   38	319	9	j	int
    //   41	305	10	k	int
    //   370	7	11	localObject1	Object
    //   55	244	12	m	int
    //   280	88	13	localObject2	Object
    //   264	14	14	localRuntimeException	RuntimeException
    //   62	195	15	localPreparedStatement	PreparedStatement
    //   253	9	16	localObject3	Object
    //   242	9	17	localObject4	Object
    //   111	11	18	l	long
    // Exception table:
    //   from	to	target	type
    //   89	113	242	finally
    //   126	138	242	finally
    //   64	89	253	finally
    //   138	144	253	finally
    //   244	253	253	finally
    //   57	64	264	java/lang/RuntimeException
    //   144	150	264	java/lang/RuntimeException
    //   255	264	264	java/lang/RuntimeException
    //   57	64	280	finally
    //   144	150	280	finally
    //   255	264	280	finally
    //   266	280	280	finally
    //   43	57	370	finally
    //   150	235	370	finally
    //   282	367	370	finally
    //   367	370	370	finally
  }
  
  /* Error */
  public long executeForLastInsertedRowId(String paramString, Object[] paramArrayOfObject, CancellationSignal paramCancellationSignal)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +14 -> 15
    //   4: new 676	java/lang/IllegalArgumentException
    //   7: dup
    //   8: ldc_w 678
    //   11: invokespecial 679	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   14: athrow
    //   15: aload_0
    //   16: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   19: ldc_w 756
    //   22: aload_1
    //   23: aload_2
    //   24: invokevirtual 325	android/database/sqlite/SQLiteConnection$OperationLog:beginOperation	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)I
    //   27: istore 4
    //   29: aload_0
    //   30: aload_1
    //   31: invokespecial 682	android/database/sqlite/SQLiteConnection:acquirePreparedStatement	(Ljava/lang/String;)Landroid/database/sqlite/SQLiteConnection$PreparedStatement;
    //   34: astore 7
    //   36: aload_0
    //   37: aload 7
    //   39: invokespecial 684	android/database/sqlite/SQLiteConnection:throwIfStatementForbidden	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   42: aload_0
    //   43: aload 7
    //   45: aload_2
    //   46: invokespecial 686	android/database/sqlite/SQLiteConnection:bindArguments	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;[Ljava/lang/Object;)V
    //   49: aload_0
    //   50: aload 7
    //   52: invokespecial 688	android/database/sqlite/SQLiteConnection:applyBlockGuardPolicy	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   55: aload_0
    //   56: aload_3
    //   57: invokespecial 690	android/database/sqlite/SQLiteConnection:attachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   60: aload_0
    //   61: getfield 145	android/database/sqlite/SQLiteConnection:mConnectionPtr	I
    //   64: aload 7
    //   66: getfield 252	android/database/sqlite/SQLiteConnection$PreparedStatement:mStatementPtr	I
    //   69: invokestatic 758	android/database/sqlite/SQLiteConnection:nativeExecuteForLastInsertedRowId	(II)J
    //   72: lstore 10
    //   74: aload_0
    //   75: aload_3
    //   76: invokespecial 694	android/database/sqlite/SQLiteConnection:detachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   79: aload_0
    //   80: aload 7
    //   82: invokespecial 696	android/database/sqlite/SQLiteConnection:releasePreparedStatement	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   85: aload_0
    //   86: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   89: iload 4
    //   91: invokevirtual 335	android/database/sqlite/SQLiteConnection$OperationLog:endOperation	(I)V
    //   94: lload 10
    //   96: lreturn
    //   97: astore 9
    //   99: aload_0
    //   100: aload_3
    //   101: invokespecial 694	android/database/sqlite/SQLiteConnection:detachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   104: aload 9
    //   106: athrow
    //   107: astore 8
    //   109: aload_0
    //   110: aload 7
    //   112: invokespecial 696	android/database/sqlite/SQLiteConnection:releasePreparedStatement	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   115: aload 8
    //   117: athrow
    //   118: astore 6
    //   120: aload_0
    //   121: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   124: iload 4
    //   126: aload 6
    //   128: invokevirtual 700	android/database/sqlite/SQLiteConnection$OperationLog:failOperation	(ILjava/lang/Exception;)V
    //   131: aload 6
    //   133: athrow
    //   134: astore 5
    //   136: aload_0
    //   137: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   140: iload 4
    //   142: invokevirtual 335	android/database/sqlite/SQLiteConnection$OperationLog:endOperation	(I)V
    //   145: aload 5
    //   147: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	148	0	this	SQLiteConnection
    //   0	148	1	paramString	String
    //   0	148	2	paramArrayOfObject	Object[]
    //   0	148	3	paramCancellationSignal	CancellationSignal
    //   27	114	4	i	int
    //   134	12	5	localObject1	Object
    //   118	14	6	localRuntimeException	RuntimeException
    //   34	77	7	localPreparedStatement	PreparedStatement
    //   107	9	8	localObject2	Object
    //   97	8	9	localObject3	Object
    //   72	23	10	l	long
    // Exception table:
    //   from	to	target	type
    //   60	74	97	finally
    //   36	60	107	finally
    //   74	79	107	finally
    //   99	107	107	finally
    //   29	36	118	java/lang/RuntimeException
    //   79	85	118	java/lang/RuntimeException
    //   109	118	118	java/lang/RuntimeException
    //   29	36	134	finally
    //   79	85	134	finally
    //   109	118	134	finally
    //   120	134	134	finally
  }
  
  /* Error */
  public long executeForLong(String paramString, Object[] paramArrayOfObject, CancellationSignal paramCancellationSignal)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +14 -> 15
    //   4: new 676	java/lang/IllegalArgumentException
    //   7: dup
    //   8: ldc_w 678
    //   11: invokespecial 679	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   14: athrow
    //   15: aload_0
    //   16: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   19: ldc_w 759
    //   22: aload_1
    //   23: aload_2
    //   24: invokevirtual 325	android/database/sqlite/SQLiteConnection$OperationLog:beginOperation	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)I
    //   27: istore 4
    //   29: aload_0
    //   30: aload_1
    //   31: invokespecial 682	android/database/sqlite/SQLiteConnection:acquirePreparedStatement	(Ljava/lang/String;)Landroid/database/sqlite/SQLiteConnection$PreparedStatement;
    //   34: astore 7
    //   36: aload_0
    //   37: aload 7
    //   39: invokespecial 684	android/database/sqlite/SQLiteConnection:throwIfStatementForbidden	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   42: aload_0
    //   43: aload 7
    //   45: aload_2
    //   46: invokespecial 686	android/database/sqlite/SQLiteConnection:bindArguments	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;[Ljava/lang/Object;)V
    //   49: aload_0
    //   50: aload 7
    //   52: invokespecial 688	android/database/sqlite/SQLiteConnection:applyBlockGuardPolicy	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   55: aload_0
    //   56: aload_3
    //   57: invokespecial 690	android/database/sqlite/SQLiteConnection:attachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   60: aload_0
    //   61: getfield 145	android/database/sqlite/SQLiteConnection:mConnectionPtr	I
    //   64: aload 7
    //   66: getfield 252	android/database/sqlite/SQLiteConnection$PreparedStatement:mStatementPtr	I
    //   69: invokestatic 761	android/database/sqlite/SQLiteConnection:nativeExecuteForLong	(II)J
    //   72: lstore 10
    //   74: aload_0
    //   75: aload_3
    //   76: invokespecial 694	android/database/sqlite/SQLiteConnection:detachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   79: aload_0
    //   80: aload 7
    //   82: invokespecial 696	android/database/sqlite/SQLiteConnection:releasePreparedStatement	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   85: aload_0
    //   86: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   89: iload 4
    //   91: invokevirtual 335	android/database/sqlite/SQLiteConnection$OperationLog:endOperation	(I)V
    //   94: lload 10
    //   96: lreturn
    //   97: astore 9
    //   99: aload_0
    //   100: aload_3
    //   101: invokespecial 694	android/database/sqlite/SQLiteConnection:detachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   104: aload 9
    //   106: athrow
    //   107: astore 8
    //   109: aload_0
    //   110: aload 7
    //   112: invokespecial 696	android/database/sqlite/SQLiteConnection:releasePreparedStatement	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   115: aload 8
    //   117: athrow
    //   118: astore 6
    //   120: aload_0
    //   121: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   124: iload 4
    //   126: aload 6
    //   128: invokevirtual 700	android/database/sqlite/SQLiteConnection$OperationLog:failOperation	(ILjava/lang/Exception;)V
    //   131: aload 6
    //   133: athrow
    //   134: astore 5
    //   136: aload_0
    //   137: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   140: iload 4
    //   142: invokevirtual 335	android/database/sqlite/SQLiteConnection$OperationLog:endOperation	(I)V
    //   145: aload 5
    //   147: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	148	0	this	SQLiteConnection
    //   0	148	1	paramString	String
    //   0	148	2	paramArrayOfObject	Object[]
    //   0	148	3	paramCancellationSignal	CancellationSignal
    //   27	114	4	i	int
    //   134	12	5	localObject1	Object
    //   118	14	6	localRuntimeException	RuntimeException
    //   34	77	7	localPreparedStatement	PreparedStatement
    //   107	9	8	localObject2	Object
    //   97	8	9	localObject3	Object
    //   72	23	10	l	long
    // Exception table:
    //   from	to	target	type
    //   60	74	97	finally
    //   36	60	107	finally
    //   74	79	107	finally
    //   99	107	107	finally
    //   29	36	118	java/lang/RuntimeException
    //   79	85	118	java/lang/RuntimeException
    //   109	118	118	java/lang/RuntimeException
    //   29	36	134	finally
    //   79	85	134	finally
    //   109	118	134	finally
    //   120	134	134	finally
  }
  
  /* Error */
  public String executeForString(String paramString, Object[] paramArrayOfObject, CancellationSignal paramCancellationSignal)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +14 -> 15
    //   4: new 676	java/lang/IllegalArgumentException
    //   7: dup
    //   8: ldc_w 678
    //   11: invokespecial 679	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   14: athrow
    //   15: aload_0
    //   16: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   19: ldc_w 762
    //   22: aload_1
    //   23: aload_2
    //   24: invokevirtual 325	android/database/sqlite/SQLiteConnection$OperationLog:beginOperation	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)I
    //   27: istore 4
    //   29: aload_0
    //   30: aload_1
    //   31: invokespecial 682	android/database/sqlite/SQLiteConnection:acquirePreparedStatement	(Ljava/lang/String;)Landroid/database/sqlite/SQLiteConnection$PreparedStatement;
    //   34: astore 7
    //   36: aload_0
    //   37: aload 7
    //   39: invokespecial 684	android/database/sqlite/SQLiteConnection:throwIfStatementForbidden	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   42: aload_0
    //   43: aload 7
    //   45: aload_2
    //   46: invokespecial 686	android/database/sqlite/SQLiteConnection:bindArguments	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;[Ljava/lang/Object;)V
    //   49: aload_0
    //   50: aload 7
    //   52: invokespecial 688	android/database/sqlite/SQLiteConnection:applyBlockGuardPolicy	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   55: aload_0
    //   56: aload_3
    //   57: invokespecial 690	android/database/sqlite/SQLiteConnection:attachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   60: aload_0
    //   61: getfield 145	android/database/sqlite/SQLiteConnection:mConnectionPtr	I
    //   64: aload 7
    //   66: getfield 252	android/database/sqlite/SQLiteConnection$PreparedStatement:mStatementPtr	I
    //   69: invokestatic 764	android/database/sqlite/SQLiteConnection:nativeExecuteForString	(II)Ljava/lang/String;
    //   72: astore 10
    //   74: aload_0
    //   75: aload_3
    //   76: invokespecial 694	android/database/sqlite/SQLiteConnection:detachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   79: aload_0
    //   80: aload 7
    //   82: invokespecial 696	android/database/sqlite/SQLiteConnection:releasePreparedStatement	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   85: aload_0
    //   86: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   89: iload 4
    //   91: invokevirtual 335	android/database/sqlite/SQLiteConnection$OperationLog:endOperation	(I)V
    //   94: aload 10
    //   96: areturn
    //   97: astore 9
    //   99: aload_0
    //   100: aload_3
    //   101: invokespecial 694	android/database/sqlite/SQLiteConnection:detachCancellationSignal	(Landroid/os/CancellationSignal;)V
    //   104: aload 9
    //   106: athrow
    //   107: astore 8
    //   109: aload_0
    //   110: aload 7
    //   112: invokespecial 696	android/database/sqlite/SQLiteConnection:releasePreparedStatement	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   115: aload 8
    //   117: athrow
    //   118: astore 6
    //   120: aload_0
    //   121: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   124: iload 4
    //   126: aload 6
    //   128: invokevirtual 700	android/database/sqlite/SQLiteConnection$OperationLog:failOperation	(ILjava/lang/Exception;)V
    //   131: aload 6
    //   133: athrow
    //   134: astore 5
    //   136: aload_0
    //   137: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   140: iload 4
    //   142: invokevirtual 335	android/database/sqlite/SQLiteConnection$OperationLog:endOperation	(I)V
    //   145: aload 5
    //   147: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	148	0	this	SQLiteConnection
    //   0	148	1	paramString	String
    //   0	148	2	paramArrayOfObject	Object[]
    //   0	148	3	paramCancellationSignal	CancellationSignal
    //   27	114	4	i	int
    //   134	12	5	localObject1	Object
    //   118	14	6	localRuntimeException	RuntimeException
    //   34	77	7	localPreparedStatement	PreparedStatement
    //   107	9	8	localObject2	Object
    //   97	8	9	localObject3	Object
    //   72	23	10	str	String
    // Exception table:
    //   from	to	target	type
    //   60	74	97	finally
    //   36	60	107	finally
    //   74	79	107	finally
    //   99	107	107	finally
    //   29	36	118	java/lang/RuntimeException
    //   79	85	118	java/lang/RuntimeException
    //   109	118	118	java/lang/RuntimeException
    //   29	36	134	finally
    //   79	85	134	finally
    //   109	118	134	finally
    //   120	134	134	finally
  }
  
  protected void finalize()
    throws Throwable
  {
    try
    {
      if ((this.mPool != null) && (this.mConnectionPtr != 0)) {
        this.mPool.onConnectionLeaked();
      }
      dispose(true);
      return;
    }
    finally
    {
      super.finalize();
    }
  }
  
  public int getConnectionId()
  {
    return this.mConnectionId;
  }
  
  boolean isPreparedStatementInCache(String paramString)
  {
    return this.mPreparedStatementCache.get(paramString) != null;
  }
  
  public boolean isPrimaryConnection()
  {
    return this.mIsPrimaryConnection;
  }
  
  public void onCancel()
  {
    nativeCancel(this.mConnectionPtr);
  }
  
  /* Error */
  public void prepare(String paramString, SQLiteStatementInfo paramSQLiteStatementInfo)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +14 -> 15
    //   4: new 676	java/lang/IllegalArgumentException
    //   7: dup
    //   8: ldc_w 678
    //   11: invokespecial 679	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   14: athrow
    //   15: aload_0
    //   16: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   19: ldc_w 783
    //   22: aload_1
    //   23: aconst_null
    //   24: invokevirtual 325	android/database/sqlite/SQLiteConnection$OperationLog:beginOperation	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)I
    //   27: istore_3
    //   28: aload_0
    //   29: aload_1
    //   30: invokespecial 682	android/database/sqlite/SQLiteConnection:acquirePreparedStatement	(Ljava/lang/String;)Landroid/database/sqlite/SQLiteConnection$PreparedStatement;
    //   33: astore 6
    //   35: aload_2
    //   36: ifnull +47 -> 83
    //   39: aload_2
    //   40: aload 6
    //   42: getfield 225	android/database/sqlite/SQLiteConnection$PreparedStatement:mNumParameters	I
    //   45: putfield 788	android/database/sqlite/SQLiteStatementInfo:numParameters	I
    //   48: aload_2
    //   49: aload 6
    //   51: getfield 189	android/database/sqlite/SQLiteConnection$PreparedStatement:mReadOnly	Z
    //   54: putfield 791	android/database/sqlite/SQLiteStatementInfo:readOnly	Z
    //   57: aload_0
    //   58: getfield 145	android/database/sqlite/SQLiteConnection:mConnectionPtr	I
    //   61: aload 6
    //   63: getfield 252	android/database/sqlite/SQLiteConnection$PreparedStatement:mStatementPtr	I
    //   66: invokestatic 793	android/database/sqlite/SQLiteConnection:nativeGetColumnCount	(II)I
    //   69: istore 8
    //   71: iload 8
    //   73: ifne +25 -> 98
    //   76: aload_2
    //   77: getstatic 53	android/database/sqlite/SQLiteConnection:EMPTY_STRING_ARRAY	[Ljava/lang/String;
    //   80: putfield 796	android/database/sqlite/SQLiteStatementInfo:columnNames	[Ljava/lang/String;
    //   83: aload_0
    //   84: aload 6
    //   86: invokespecial 696	android/database/sqlite/SQLiteConnection:releasePreparedStatement	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   89: aload_0
    //   90: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   93: iload_3
    //   94: invokevirtual 335	android/database/sqlite/SQLiteConnection$OperationLog:endOperation	(I)V
    //   97: return
    //   98: aload_2
    //   99: iload 8
    //   101: anewarray 51	java/lang/String
    //   104: putfield 796	android/database/sqlite/SQLiteStatementInfo:columnNames	[Ljava/lang/String;
    //   107: iconst_0
    //   108: istore 9
    //   110: iload 9
    //   112: iload 8
    //   114: if_icmpge -31 -> 83
    //   117: aload_2
    //   118: getfield 796	android/database/sqlite/SQLiteStatementInfo:columnNames	[Ljava/lang/String;
    //   121: iload 9
    //   123: aload_0
    //   124: getfield 145	android/database/sqlite/SQLiteConnection:mConnectionPtr	I
    //   127: aload 6
    //   129: getfield 252	android/database/sqlite/SQLiteConnection$PreparedStatement:mStatementPtr	I
    //   132: iload 9
    //   134: invokestatic 798	android/database/sqlite/SQLiteConnection:nativeGetColumnName	(III)Ljava/lang/String;
    //   137: aastore
    //   138: iinc 9 1
    //   141: goto -31 -> 110
    //   144: astore 7
    //   146: aload_0
    //   147: aload 6
    //   149: invokespecial 696	android/database/sqlite/SQLiteConnection:releasePreparedStatement	(Landroid/database/sqlite/SQLiteConnection$PreparedStatement;)V
    //   152: aload 7
    //   154: athrow
    //   155: astore 5
    //   157: aload_0
    //   158: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   161: iload_3
    //   162: aload 5
    //   164: invokevirtual 700	android/database/sqlite/SQLiteConnection$OperationLog:failOperation	(ILjava/lang/Exception;)V
    //   167: aload 5
    //   169: athrow
    //   170: astore 4
    //   172: aload_0
    //   173: getfield 84	android/database/sqlite/SQLiteConnection:mRecentOperations	Landroid/database/sqlite/SQLiteConnection$OperationLog;
    //   176: iload_3
    //   177: invokevirtual 335	android/database/sqlite/SQLiteConnection$OperationLog:endOperation	(I)V
    //   180: aload 4
    //   182: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	183	0	this	SQLiteConnection
    //   0	183	1	paramString	String
    //   0	183	2	paramSQLiteStatementInfo	SQLiteStatementInfo
    //   27	150	3	i	int
    //   170	11	4	localObject1	Object
    //   155	13	5	localRuntimeException	RuntimeException
    //   33	115	6	localPreparedStatement	PreparedStatement
    //   144	9	7	localObject2	Object
    //   69	46	8	j	int
    //   108	31	9	k	int
    // Exception table:
    //   from	to	target	type
    //   39	71	144	finally
    //   76	83	144	finally
    //   98	107	144	finally
    //   117	138	144	finally
    //   28	35	155	java/lang/RuntimeException
    //   83	89	155	java/lang/RuntimeException
    //   146	155	155	java/lang/RuntimeException
    //   28	35	170	finally
    //   83	89	170	finally
    //   146	155	170	finally
    //   157	170	170	finally
  }
  
  void reconfigure(SQLiteDatabaseConfiguration paramSQLiteDatabaseConfiguration)
  {
    this.mOnlyAllowReadOnlyOperations = false;
    int i = paramSQLiteDatabaseConfiguration.customFunctions.size();
    for (int j = 0; j < i; j++)
    {
      SQLiteCustomFunction localSQLiteCustomFunction = (SQLiteCustomFunction)paramSQLiteDatabaseConfiguration.customFunctions.get(j);
      if (!this.mConfiguration.customFunctions.contains(localSQLiteCustomFunction)) {
        nativeRegisterCustomFunction(this.mConnectionPtr, localSQLiteCustomFunction);
      }
    }
    int k;
    int m;
    if (paramSQLiteDatabaseConfiguration.foreignKeyConstraintsEnabled != this.mConfiguration.foreignKeyConstraintsEnabled)
    {
      k = 1;
      if ((0x20000000 & (paramSQLiteDatabaseConfiguration.openFlags ^ this.mConfiguration.openFlags)) == 0) {
        break label175;
      }
      m = 1;
      label102:
      if (paramSQLiteDatabaseConfiguration.locale.equals(this.mConfiguration.locale)) {
        break label181;
      }
    }
    label175:
    label181:
    for (int n = 1;; n = 0)
    {
      this.mConfiguration.updateParametersFrom(paramSQLiteDatabaseConfiguration);
      this.mPreparedStatementCache.resize(paramSQLiteDatabaseConfiguration.maxSqlCacheSize);
      if (k != 0) {
        setForeignKeyModeFromConfiguration();
      }
      if (m != 0) {
        setWalModeFromConfiguration();
      }
      if (n != 0) {
        setLocaleFromConfiguration();
      }
      return;
      k = 0;
      break;
      m = 0;
      break label102;
    }
  }
  
  void setOnlyAllowReadOnlyOperations(boolean paramBoolean)
  {
    this.mOnlyAllowReadOnlyOperations = paramBoolean;
  }
  
  public String toString()
  {
    return "SQLiteConnection: " + this.mConfiguration.path + " (" + this.mConnectionId + ")";
  }
  
  private static final class Operation
  {
    private static final SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    public ArrayList<Object> mBindArgs;
    public int mCookie;
    public long mEndTime;
    public Exception mException;
    public boolean mFinished;
    public String mKind;
    public String mSql;
    public long mStartTime;
    
    private String getFormattedStartTime()
    {
      return sDateFormat.format(new Date(this.mStartTime));
    }
    
    private String getStatus()
    {
      if (!this.mFinished) {
        return "running";
      }
      if (this.mException != null) {
        return "failed";
      }
      return "succeeded";
    }
    
    public void describe(StringBuilder paramStringBuilder)
    {
      paramStringBuilder.append(this.mKind);
      int j;
      label119:
      Object localObject;
      if (this.mFinished)
      {
        paramStringBuilder.append(" took ").append(this.mEndTime - this.mStartTime).append("ms");
        paramStringBuilder.append(" - ").append(getStatus());
        if (this.mSql != null) {
          paramStringBuilder.append(", sql=\"").append(SQLiteConnection.trimSqlForDisplay(this.mSql)).append("\"");
        }
        if ((this.mBindArgs == null) || (this.mBindArgs.size() == 0)) {
          break label259;
        }
        paramStringBuilder.append(", bindArgs=[");
        int i = this.mBindArgs.size();
        j = 0;
        if (j >= i) {
          break label252;
        }
        localObject = this.mBindArgs.get(j);
        if (j != 0) {
          paramStringBuilder.append(", ");
        }
        if (localObject != null) {
          break label193;
        }
        paramStringBuilder.append("null");
      }
      for (;;)
      {
        j++;
        break label119;
        paramStringBuilder.append(" started ").append(System.currentTimeMillis() - this.mStartTime).append("ms ago");
        break;
        label193:
        if ((localObject instanceof byte[])) {
          paramStringBuilder.append("<byte[]>");
        } else if ((localObject instanceof String)) {
          paramStringBuilder.append("\"").append((String)localObject).append("\"");
        } else {
          paramStringBuilder.append(localObject);
        }
      }
      label252:
      paramStringBuilder.append("]");
      label259:
      if (this.mException != null) {
        paramStringBuilder.append(", exception=\"").append(this.mException.getMessage()).append("\"");
      }
    }
  }
  
  private static final class OperationLog
  {
    private static final int COOKIE_GENERATION_SHIFT = 8;
    private static final int COOKIE_INDEX_MASK = 255;
    private static final int MAX_RECENT_OPERATIONS = 20;
    private int mGeneration;
    private int mIndex;
    private final SQLiteConnection.Operation[] mOperations = new SQLiteConnection.Operation[20];
    
    private boolean endOperationDeferLogLocked(int paramInt)
    {
      SQLiteConnection.Operation localOperation = getOperationLocked(paramInt);
      if (localOperation != null)
      {
        localOperation.mEndTime = System.currentTimeMillis();
        localOperation.mFinished = true;
        return (SQLiteDebug.DEBUG_LOG_SLOW_QUERIES) && (SQLiteDebug.shouldLogSlowQuery(localOperation.mEndTime - localOperation.mStartTime));
      }
      return false;
    }
    
    private SQLiteConnection.Operation getOperationLocked(int paramInt)
    {
      int i = paramInt & 0xFF;
      SQLiteConnection.Operation localOperation = this.mOperations[i];
      if (localOperation.mCookie == paramInt) {
        return localOperation;
      }
      return null;
    }
    
    private void logOperationLocked(int paramInt, String paramString)
    {
      SQLiteConnection.Operation localOperation = getOperationLocked(paramInt);
      StringBuilder localStringBuilder = new StringBuilder();
      localOperation.describe(localStringBuilder);
      if (paramString != null) {
        localStringBuilder.append(", ").append(paramString);
      }
      Log.d("SQLiteConnection", localStringBuilder.toString());
    }
    
    private int newOperationCookieLocked(int paramInt)
    {
      int i = this.mGeneration;
      this.mGeneration = (i + 1);
      return paramInt | i << 8;
    }
    
    public int beginOperation(String paramString1, String paramString2, Object[] paramArrayOfObject)
    {
      for (;;)
      {
        int i;
        SQLiteConnection.Operation localOperation;
        Object localObject2;
        synchronized (this.mOperations)
        {
          i = (1 + this.mIndex) % 20;
          localOperation = this.mOperations[i];
          if (localOperation == null)
          {
            localOperation = new SQLiteConnection.Operation(null);
            this.mOperations[i] = localOperation;
            localOperation.mStartTime = System.currentTimeMillis();
            localOperation.mKind = paramString1;
            localOperation.mSql = paramString2;
            if (paramArrayOfObject == null) {
              break label205;
            }
            if (localOperation.mBindArgs == null)
            {
              localOperation.mBindArgs = new ArrayList();
              break label235;
              if (j >= paramArrayOfObject.length) {
                break label205;
              }
              localObject2 = paramArrayOfObject[j];
              if ((localObject2 == null) || (!(localObject2 instanceof byte[]))) {
                break label191;
              }
              localOperation.mBindArgs.add(SQLiteConnection.EMPTY_BYTE_ARRAY);
              break label241;
            }
          }
          else
          {
            localOperation.mFinished = false;
            localOperation.mException = null;
            if (localOperation.mBindArgs == null) {
              continue;
            }
            localOperation.mBindArgs.clear();
          }
        }
        localOperation.mBindArgs.clear();
        break label235;
        label191:
        localOperation.mBindArgs.add(localObject2);
        break label241;
        label205:
        localOperation.mCookie = newOperationCookieLocked(i);
        this.mIndex = i;
        int k = localOperation.mCookie;
        return k;
        label235:
        int j = 0;
        continue;
        label241:
        j++;
      }
    }
    
    public String describeCurrentOperation()
    {
      synchronized (this.mOperations)
      {
        SQLiteConnection.Operation localOperation = this.mOperations[this.mIndex];
        if ((localOperation != null) && (!localOperation.mFinished))
        {
          StringBuilder localStringBuilder = new StringBuilder();
          localOperation.describe(localStringBuilder);
          String str = localStringBuilder.toString();
          return str;
        }
        return null;
      }
    }
    
    public void dump(Printer paramPrinter)
    {
      for (;;)
      {
        synchronized (this.mOperations)
        {
          paramPrinter.println("  Most recently executed operations:");
          i = this.mIndex;
          SQLiteConnection.Operation localOperation = this.mOperations[i];
          if (localOperation != null)
          {
            int j = 0;
            StringBuilder localStringBuilder = new StringBuilder();
            localStringBuilder.append("    ").append(j).append(": [");
            localStringBuilder.append(localOperation.getFormattedStartTime());
            localStringBuilder.append("] ");
            localOperation.describe(localStringBuilder);
            paramPrinter.println(localStringBuilder.toString());
            if (i > 0)
            {
              i--;
              j++;
              localOperation = this.mOperations[i];
              if ((localOperation != null) && (j < 20)) {
                continue;
              }
            }
          }
          else
          {
            paramPrinter.println("    <none>");
          }
        }
        int i = 19;
      }
    }
    
    public void endOperation(int paramInt)
    {
      synchronized (this.mOperations)
      {
        if (endOperationDeferLogLocked(paramInt)) {
          logOperationLocked(paramInt, null);
        }
        return;
      }
    }
    
    public boolean endOperationDeferLog(int paramInt)
    {
      synchronized (this.mOperations)
      {
        boolean bool = endOperationDeferLogLocked(paramInt);
        return bool;
      }
    }
    
    public void failOperation(int paramInt, Exception paramException)
    {
      synchronized (this.mOperations)
      {
        SQLiteConnection.Operation localOperation = getOperationLocked(paramInt);
        if (localOperation != null) {
          localOperation.mException = paramException;
        }
        return;
      }
    }
    
    public void logOperation(int paramInt, String paramString)
    {
      synchronized (this.mOperations)
      {
        logOperationLocked(paramInt, paramString);
        return;
      }
    }
  }
  
  private static final class PreparedStatement
  {
    public boolean mInCache;
    public boolean mInUse;
    public int mNumParameters;
    public PreparedStatement mPoolNext;
    public boolean mReadOnly;
    public String mSql;
    public int mStatementPtr;
    public int mType;
  }
  
  private final class PreparedStatementCache
    extends LruCache<String, SQLiteConnection.PreparedStatement>
  {
    public PreparedStatementCache(int paramInt)
    {
      super();
    }
    
    public void dump(Printer paramPrinter)
    {
      paramPrinter.println("  Prepared statement cache:");
      Map localMap = snapshot();
      if (!localMap.isEmpty())
      {
        int i = 0;
        Iterator localIterator = localMap.entrySet().iterator();
        while (localIterator.hasNext())
        {
          Map.Entry localEntry = (Map.Entry)localIterator.next();
          SQLiteConnection.PreparedStatement localPreparedStatement = (SQLiteConnection.PreparedStatement)localEntry.getValue();
          if (localPreparedStatement.mInCache)
          {
            String str = (String)localEntry.getKey();
            paramPrinter.println("    " + i + ": statementPtr=0x" + Integer.toHexString(localPreparedStatement.mStatementPtr) + ", numParameters=" + localPreparedStatement.mNumParameters + ", type=" + localPreparedStatement.mType + ", readOnly=" + localPreparedStatement.mReadOnly + ", sql=\"" + SQLiteConnection.trimSqlForDisplay(str) + "\"");
          }
          i++;
        }
      }
      paramPrinter.println("    <none>");
    }
    
    protected void entryRemoved(boolean paramBoolean, String paramString, SQLiteConnection.PreparedStatement paramPreparedStatement1, SQLiteConnection.PreparedStatement paramPreparedStatement2)
    {
      paramPreparedStatement1.mInCache = false;
      if (!paramPreparedStatement1.mInUse) {
        SQLiteConnection.this.finalizePreparedStatement(paramPreparedStatement1);
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\sqlite\SQLiteConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
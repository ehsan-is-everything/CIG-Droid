package android.database.sqlite;

import android.os.CancellationSignal;
import android.os.CancellationSignal.OnCancelListener;
import android.os.OperationCanceledException;
import android.os.SystemClock;
import android.util.Log;
import android.util.PrefixPrinter;
import android.util.Printer;
import dalvik.system.CloseGuard;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.LockSupport;

public final class SQLiteConnectionPool
  implements Closeable
{
  public static final int CONNECTION_FLAG_INTERACTIVE = 4;
  public static final int CONNECTION_FLAG_PRIMARY_CONNECTION_AFFINITY = 2;
  public static final int CONNECTION_FLAG_READ_ONLY = 1;
  private static final long CONNECTION_POOL_BUSY_MILLIS = 30000L;
  private static final String TAG = "SQLiteConnectionPool";
  private final WeakHashMap<SQLiteConnection, AcquiredConnectionStatus> mAcquiredConnections = new WeakHashMap();
  private final ArrayList<SQLiteConnection> mAvailableNonPrimaryConnections = new ArrayList();
  private SQLiteConnection mAvailablePrimaryConnection;
  private final CloseGuard mCloseGuard = CloseGuard.get();
  private final SQLiteDatabaseConfiguration mConfiguration;
  private final AtomicBoolean mConnectionLeaked = new AtomicBoolean();
  private ConnectionWaiter mConnectionWaiterPool;
  private ConnectionWaiter mConnectionWaiterQueue;
  private boolean mIsOpen;
  private final Object mLock = new Object();
  private int mMaxConnectionPoolSize;
  private int mNextConnectionId;
  
  static
  {
    if (!SQLiteConnectionPool.class.desiredAssertionStatus()) {}
    for (boolean bool = true;; bool = false)
    {
      $assertionsDisabled = bool;
      return;
    }
  }
  
  private SQLiteConnectionPool(SQLiteDatabaseConfiguration paramSQLiteDatabaseConfiguration)
  {
    this.mConfiguration = new SQLiteDatabaseConfiguration(paramSQLiteDatabaseConfiguration);
    setMaxConnectionPoolSizeLocked();
  }
  
  private void cancelConnectionWaiterLocked(ConnectionWaiter paramConnectionWaiter)
  {
    if ((paramConnectionWaiter.mAssignedConnection != null) || (paramConnectionWaiter.mException != null)) {
      return;
    }
    Object localObject = null;
    for (ConnectionWaiter localConnectionWaiter = this.mConnectionWaiterQueue; localConnectionWaiter != paramConnectionWaiter; localConnectionWaiter = localConnectionWaiter.mNext)
    {
      assert (localConnectionWaiter != null);
      localObject = localConnectionWaiter;
    }
    if (localObject != null) {
      ((ConnectionWaiter)localObject).mNext = paramConnectionWaiter.mNext;
    }
    for (;;)
    {
      paramConnectionWaiter.mException = new OperationCanceledException();
      LockSupport.unpark(paramConnectionWaiter.mThread);
      wakeConnectionWaitersLocked();
      return;
      this.mConnectionWaiterQueue = paramConnectionWaiter.mNext;
    }
  }
  
  private void closeAvailableConnectionsAndLogExceptionsLocked()
  {
    closeAvailableNonPrimaryConnectionsAndLogExceptionsLocked();
    if (this.mAvailablePrimaryConnection != null)
    {
      closeConnectionAndLogExceptionsLocked(this.mAvailablePrimaryConnection);
      this.mAvailablePrimaryConnection = null;
    }
  }
  
  private void closeAvailableNonPrimaryConnectionsAndLogExceptionsLocked()
  {
    int i = this.mAvailableNonPrimaryConnections.size();
    for (int j = 0; j < i; j++) {
      closeConnectionAndLogExceptionsLocked((SQLiteConnection)this.mAvailableNonPrimaryConnections.get(j));
    }
    this.mAvailableNonPrimaryConnections.clear();
  }
  
  private void closeConnectionAndLogExceptionsLocked(SQLiteConnection paramSQLiteConnection)
  {
    try
    {
      paramSQLiteConnection.close();
      return;
    }
    catch (RuntimeException localRuntimeException)
    {
      Log.e("SQLiteConnectionPool", "Failed to close connection, its fate is now in the hands of the merciful GC: " + paramSQLiteConnection, localRuntimeException);
    }
  }
  
  private void closeExcessConnectionsAndLogExceptionsLocked()
  {
    int j;
    for (int i = this.mAvailableNonPrimaryConnections.size();; i = j)
    {
      j = i - 1;
      if (i <= -1 + this.mMaxConnectionPoolSize) {
        break;
      }
      closeConnectionAndLogExceptionsLocked((SQLiteConnection)this.mAvailableNonPrimaryConnections.remove(j));
    }
  }
  
  private void discardAcquiredConnectionsLocked()
  {
    markAcquiredConnectionsLocked(AcquiredConnectionStatus.DISCARD);
  }
  
  private void dispose(boolean paramBoolean)
  {
    if (this.mCloseGuard != null)
    {
      if (paramBoolean) {
        this.mCloseGuard.warnIfOpen();
      }
      this.mCloseGuard.close();
    }
    if (!paramBoolean) {
      synchronized (this.mLock)
      {
        throwIfClosedLocked();
        this.mIsOpen = false;
        closeAvailableConnectionsAndLogExceptionsLocked();
        int i = this.mAcquiredConnections.size();
        if (i != 0) {
          Log.i("SQLiteConnectionPool", "The connection pool for " + this.mConfiguration.label + " has been closed but there are still " + i + " connections in use.  They will be closed " + "as they are released back to the pool.");
        }
        wakeConnectionWaitersLocked();
        return;
      }
    }
  }
  
  private void finishAcquireConnectionLocked(SQLiteConnection paramSQLiteConnection, int paramInt)
  {
    if ((paramInt & 0x1) != 0) {}
    for (boolean bool = true;; bool = false) {
      try
      {
        paramSQLiteConnection.setOnlyAllowReadOnlyOperations(bool);
        this.mAcquiredConnections.put(paramSQLiteConnection, AcquiredConnectionStatus.NORMAL);
        return;
      }
      catch (RuntimeException localRuntimeException)
      {
        Log.e("SQLiteConnectionPool", "Failed to prepare acquired connection for session, closing it: " + paramSQLiteConnection + ", connectionFlags=" + paramInt);
        closeConnectionAndLogExceptionsLocked(paramSQLiteConnection);
        throw localRuntimeException;
      }
    }
  }
  
  private static int getPriority(int paramInt)
  {
    if ((paramInt & 0x4) != 0) {
      return 1;
    }
    return 0;
  }
  
  private boolean isSessionBlockingImportantConnectionWaitersLocked(boolean paramBoolean, int paramInt)
  {
    ConnectionWaiter localConnectionWaiter = this.mConnectionWaiterQueue;
    if (localConnectionWaiter != null)
    {
      int i = getPriority(paramInt);
      if (i <= localConnectionWaiter.mPriority) {
        break label26;
      }
    }
    for (;;)
    {
      return false;
      label26:
      if ((paramBoolean) || (!localConnectionWaiter.mWantPrimaryConnection)) {
        return true;
      }
      localConnectionWaiter = localConnectionWaiter.mNext;
      if (localConnectionWaiter != null) {
        break;
      }
    }
  }
  
  private void logConnectionPoolBusyLocked(long paramLong, int paramInt)
  {
    Thread localThread = Thread.currentThread();
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("The connection pool for database '").append(this.mConfiguration.label);
    localStringBuilder.append("' has been unable to grant a connection to thread ");
    localStringBuilder.append(localThread.getId()).append(" (").append(localThread.getName()).append(") ");
    localStringBuilder.append("with flags 0x").append(Integer.toHexString(paramInt));
    localStringBuilder.append(" for ").append(0.001F * (float)paramLong).append(" seconds.\n");
    ArrayList localArrayList = new ArrayList();
    boolean bool = this.mAcquiredConnections.isEmpty();
    int i = 0;
    int j = 0;
    if (!bool)
    {
      Iterator localIterator2 = this.mAcquiredConnections.keySet().iterator();
      while (localIterator2.hasNext())
      {
        String str2 = ((SQLiteConnection)localIterator2.next()).describeCurrentOperationUnsafe();
        if (str2 != null)
        {
          localArrayList.add(str2);
          i++;
        }
        else
        {
          j++;
        }
      }
    }
    int k = this.mAvailableNonPrimaryConnections.size();
    if (this.mAvailablePrimaryConnection != null) {
      k++;
    }
    localStringBuilder.append("Connections: ").append(i).append(" active, ");
    localStringBuilder.append(j).append(" idle, ");
    localStringBuilder.append(k).append(" available.\n");
    if (!localArrayList.isEmpty())
    {
      localStringBuilder.append("\nRequests in progress:\n");
      Iterator localIterator1 = localArrayList.iterator();
      while (localIterator1.hasNext())
      {
        String str1 = (String)localIterator1.next();
        localStringBuilder.append("  ").append(str1).append("\n");
      }
    }
    Log.w("SQLiteConnectionPool", localStringBuilder.toString());
  }
  
  private void markAcquiredConnectionsLocked(AcquiredConnectionStatus paramAcquiredConnectionStatus)
  {
    if (!this.mAcquiredConnections.isEmpty())
    {
      ArrayList localArrayList = new ArrayList(this.mAcquiredConnections.size());
      Iterator localIterator = this.mAcquiredConnections.entrySet().iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        AcquiredConnectionStatus localAcquiredConnectionStatus = (AcquiredConnectionStatus)localEntry.getValue();
        if ((paramAcquiredConnectionStatus != localAcquiredConnectionStatus) && (localAcquiredConnectionStatus != AcquiredConnectionStatus.DISCARD)) {
          localArrayList.add(localEntry.getKey());
        }
      }
      int i = localArrayList.size();
      for (int j = 0; j < i; j++) {
        this.mAcquiredConnections.put(localArrayList.get(j), paramAcquiredConnectionStatus);
      }
    }
  }
  
  private ConnectionWaiter obtainConnectionWaiterLocked(Thread paramThread, long paramLong, int paramInt1, boolean paramBoolean, String paramString, int paramInt2)
  {
    ConnectionWaiter localConnectionWaiter = this.mConnectionWaiterPool;
    if (localConnectionWaiter != null)
    {
      this.mConnectionWaiterPool = localConnectionWaiter.mNext;
      localConnectionWaiter.mNext = null;
    }
    for (;;)
    {
      localConnectionWaiter.mThread = paramThread;
      localConnectionWaiter.mStartTime = paramLong;
      localConnectionWaiter.mPriority = paramInt1;
      localConnectionWaiter.mWantPrimaryConnection = paramBoolean;
      localConnectionWaiter.mSql = paramString;
      localConnectionWaiter.mConnectionFlags = paramInt2;
      return localConnectionWaiter;
      localConnectionWaiter = new ConnectionWaiter(null);
    }
  }
  
  public static SQLiteConnectionPool open(SQLiteDatabaseConfiguration paramSQLiteDatabaseConfiguration)
  {
    if (paramSQLiteDatabaseConfiguration == null) {
      throw new IllegalArgumentException("configuration must not be null.");
    }
    SQLiteConnectionPool localSQLiteConnectionPool = new SQLiteConnectionPool(paramSQLiteDatabaseConfiguration);
    localSQLiteConnectionPool.open();
    return localSQLiteConnectionPool;
  }
  
  private void open()
  {
    this.mAvailablePrimaryConnection = openConnectionLocked(this.mConfiguration, true);
    this.mIsOpen = true;
    this.mCloseGuard.open("close");
  }
  
  private SQLiteConnection openConnectionLocked(SQLiteDatabaseConfiguration paramSQLiteDatabaseConfiguration, boolean paramBoolean)
  {
    int i = this.mNextConnectionId;
    this.mNextConnectionId = (i + 1);
    return SQLiteConnection.open(this, paramSQLiteDatabaseConfiguration, i, paramBoolean);
  }
  
  private void reconfigureAllConnectionsLocked()
  {
    if (this.mAvailablePrimaryConnection != null) {}
    try
    {
      this.mAvailablePrimaryConnection.reconfigure(this.mConfiguration);
      i = this.mAvailableNonPrimaryConnections.size();
      for (j = 0;; j = k + 1)
      {
        if (j >= i) {
          break label172;
        }
        SQLiteConnection localSQLiteConnection = (SQLiteConnection)this.mAvailableNonPrimaryConnections.get(j);
        try
        {
          localSQLiteConnection.reconfigure(this.mConfiguration);
          k = j;
        }
        catch (RuntimeException localRuntimeException1)
        {
          for (;;)
          {
            Log.e("SQLiteConnectionPool", "Failed to reconfigure available non-primary connection, closing it: " + localSQLiteConnection, localRuntimeException1);
            closeConnectionAndLogExceptionsLocked(localSQLiteConnection);
            ArrayList localArrayList = this.mAvailableNonPrimaryConnections;
            int k = j - 1;
            localArrayList.remove(j);
            i--;
          }
        }
      }
    }
    catch (RuntimeException localRuntimeException2)
    {
      int i;
      int j;
      for (;;)
      {
        Log.e("SQLiteConnectionPool", "Failed to reconfigure available primary connection, closing it: " + this.mAvailablePrimaryConnection, localRuntimeException2);
        closeConnectionAndLogExceptionsLocked(this.mAvailablePrimaryConnection);
        this.mAvailablePrimaryConnection = null;
      }
      label172:
      markAcquiredConnectionsLocked(AcquiredConnectionStatus.RECONFIGURE);
    }
  }
  
  private boolean recycleConnectionLocked(SQLiteConnection paramSQLiteConnection, AcquiredConnectionStatus paramAcquiredConnectionStatus)
  {
    if (paramAcquiredConnectionStatus == AcquiredConnectionStatus.RECONFIGURE) {}
    try
    {
      paramSQLiteConnection.reconfigure(this.mConfiguration);
      if (paramAcquiredConnectionStatus == AcquiredConnectionStatus.DISCARD)
      {
        closeConnectionAndLogExceptionsLocked(paramSQLiteConnection);
        return false;
      }
    }
    catch (RuntimeException localRuntimeException)
    {
      for (;;)
      {
        Log.e("SQLiteConnectionPool", "Failed to reconfigure released connection, closing it: " + paramSQLiteConnection, localRuntimeException);
        paramAcquiredConnectionStatus = AcquiredConnectionStatus.DISCARD;
      }
    }
    return true;
  }
  
  private void recycleConnectionWaiterLocked(ConnectionWaiter paramConnectionWaiter)
  {
    paramConnectionWaiter.mNext = this.mConnectionWaiterPool;
    paramConnectionWaiter.mThread = null;
    paramConnectionWaiter.mSql = null;
    paramConnectionWaiter.mAssignedConnection = null;
    paramConnectionWaiter.mException = null;
    paramConnectionWaiter.mNonce = (1 + paramConnectionWaiter.mNonce);
    this.mConnectionWaiterPool = paramConnectionWaiter;
  }
  
  private void setMaxConnectionPoolSizeLocked()
  {
    if ((0x20000000 & this.mConfiguration.openFlags) != 0)
    {
      this.mMaxConnectionPoolSize = SQLiteGlobal.getWALConnectionPoolSize();
      return;
    }
    this.mMaxConnectionPoolSize = 1;
  }
  
  private void throwIfClosedLocked()
  {
    if (!this.mIsOpen) {
      throw new IllegalStateException("Cannot perform this operation because the connection pool has been closed.");
    }
  }
  
  private SQLiteConnection tryAcquireNonPrimaryConnectionLocked(String paramString, int paramInt)
  {
    int i = this.mAvailableNonPrimaryConnections.size();
    if ((i > 1) && (paramString != null)) {
      for (int k = 0; k < i; k++)
      {
        SQLiteConnection localSQLiteConnection3 = (SQLiteConnection)this.mAvailableNonPrimaryConnections.get(k);
        if (localSQLiteConnection3.isPreparedStatementInCache(paramString))
        {
          this.mAvailableNonPrimaryConnections.remove(k);
          finishAcquireConnectionLocked(localSQLiteConnection3, paramInt);
          return localSQLiteConnection3;
        }
      }
    }
    if (i > 0)
    {
      SQLiteConnection localSQLiteConnection2 = (SQLiteConnection)this.mAvailableNonPrimaryConnections.remove(i - 1);
      finishAcquireConnectionLocked(localSQLiteConnection2, paramInt);
      return localSQLiteConnection2;
    }
    int j = this.mAcquiredConnections.size();
    if (this.mAvailablePrimaryConnection != null) {
      j++;
    }
    if (j >= this.mMaxConnectionPoolSize) {
      return null;
    }
    SQLiteConnection localSQLiteConnection1 = openConnectionLocked(this.mConfiguration, false);
    finishAcquireConnectionLocked(localSQLiteConnection1, paramInt);
    return localSQLiteConnection1;
  }
  
  private SQLiteConnection tryAcquirePrimaryConnectionLocked(int paramInt)
  {
    SQLiteConnection localSQLiteConnection1 = this.mAvailablePrimaryConnection;
    if (localSQLiteConnection1 != null)
    {
      this.mAvailablePrimaryConnection = null;
      finishAcquireConnectionLocked(localSQLiteConnection1, paramInt);
      return localSQLiteConnection1;
    }
    Iterator localIterator = this.mAcquiredConnections.keySet().iterator();
    while (localIterator.hasNext()) {
      if (((SQLiteConnection)localIterator.next()).isPrimaryConnection()) {
        return null;
      }
    }
    SQLiteConnection localSQLiteConnection2 = openConnectionLocked(this.mConfiguration, true);
    finishAcquireConnectionLocked(localSQLiteConnection2, paramInt);
    return localSQLiteConnection2;
  }
  
  /* Error */
  private SQLiteConnection waitForConnection(String paramString, int paramInt, CancellationSignal paramCancellationSignal)
  {
    // Byte code:
    //   0: iload_2
    //   1: iconst_2
    //   2: iand
    //   3: ifeq +412 -> 415
    //   6: iconst_1
    //   7: istore 4
    //   9: aload_0
    //   10: getfield 70	android/database/sqlite/SQLiteConnectionPool:mLock	Ljava/lang/Object;
    //   13: astore 5
    //   15: aload 5
    //   17: monitorenter
    //   18: aload_0
    //   19: invokespecial 210	android/database/sqlite/SQLiteConnectionPool:throwIfClosedLocked	()V
    //   22: aload_3
    //   23: ifnull +7 -> 30
    //   26: aload_3
    //   27: invokevirtual 462	android/os/CancellationSignal:throwIfCanceled	()V
    //   30: aconst_null
    //   31: astore 7
    //   33: iload 4
    //   35: ifne +11 -> 46
    //   38: aload_0
    //   39: aload_1
    //   40: iload_2
    //   41: invokespecial 464	android/database/sqlite/SQLiteConnectionPool:tryAcquireNonPrimaryConnectionLocked	(Ljava/lang/String;I)Landroid/database/sqlite/SQLiteConnection;
    //   44: astore 7
    //   46: aload 7
    //   48: ifnonnull +10 -> 58
    //   51: aload_0
    //   52: iload_2
    //   53: invokespecial 466	android/database/sqlite/SQLiteConnectionPool:tryAcquirePrimaryConnectionLocked	(I)Landroid/database/sqlite/SQLiteConnection;
    //   56: astore 7
    //   58: aload 7
    //   60: ifnull +9 -> 69
    //   63: aload 5
    //   65: monitorexit
    //   66: aload 7
    //   68: areturn
    //   69: iload_2
    //   70: invokestatic 257	android/database/sqlite/SQLiteConnectionPool:getPriority	(I)I
    //   73: istore 8
    //   75: invokestatic 471	android/os/SystemClock:uptimeMillis	()J
    //   78: lstore 9
    //   80: aload_0
    //   81: invokestatic 271	java/lang/Thread:currentThread	()Ljava/lang/Thread;
    //   84: lload 9
    //   86: iload 8
    //   88: iload 4
    //   90: aload_1
    //   91: iload_2
    //   92: invokespecial 473	android/database/sqlite/SQLiteConnectionPool:obtainConnectionWaiterLocked	(Ljava/lang/Thread;JIZLjava/lang/String;I)Landroid/database/sqlite/SQLiteConnectionPool$ConnectionWaiter;
    //   95: astore 11
    //   97: aconst_null
    //   98: astore 12
    //   100: aload_0
    //   101: getfield 113	android/database/sqlite/SQLiteConnectionPool:mConnectionWaiterQueue	Landroid/database/sqlite/SQLiteConnectionPool$ConnectionWaiter;
    //   104: astore 13
    //   106: aload 13
    //   108: ifnull +20 -> 128
    //   111: iload 8
    //   113: aload 13
    //   115: getfield 260	android/database/sqlite/SQLiteConnectionPool$ConnectionWaiter:mPriority	I
    //   118: if_icmple +176 -> 294
    //   121: aload 11
    //   123: aload 13
    //   125: putfield 119	android/database/sqlite/SQLiteConnectionPool$ConnectionWaiter:mNext	Landroid/database/sqlite/SQLiteConnectionPool$ConnectionWaiter;
    //   128: aload 12
    //   130: ifnull +178 -> 308
    //   133: aload 12
    //   135: aload 11
    //   137: putfield 119	android/database/sqlite/SQLiteConnectionPool$ConnectionWaiter:mNext	Landroid/database/sqlite/SQLiteConnectionPool$ConnectionWaiter;
    //   140: aload 11
    //   142: getfield 428	android/database/sqlite/SQLiteConnectionPool$ConnectionWaiter:mNonce	I
    //   145: istore 14
    //   147: aload 5
    //   149: monitorexit
    //   150: aload_3
    //   151: ifnull +19 -> 170
    //   154: aload_3
    //   155: new 475	android/database/sqlite/SQLiteConnectionPool$1
    //   158: dup
    //   159: aload_0
    //   160: aload 11
    //   162: iload 14
    //   164: invokespecial 478	android/database/sqlite/SQLiteConnectionPool$1:<init>	(Landroid/database/sqlite/SQLiteConnectionPool;Landroid/database/sqlite/SQLiteConnectionPool$ConnectionWaiter;I)V
    //   167: invokevirtual 482	android/os/CancellationSignal:setOnCancelListener	(Landroid/os/CancellationSignal$OnCancelListener;)V
    //   170: ldc2_w 19
    //   173: lstore 15
    //   175: lload 15
    //   177: aload 11
    //   179: getfield 376	android/database/sqlite/SQLiteConnectionPool$ConnectionWaiter:mStartTime	J
    //   182: ladd
    //   183: lstore 18
    //   185: aload_0
    //   186: getfield 75	android/database/sqlite/SQLiteConnectionPool:mConnectionLeaked	Ljava/util/concurrent/atomic/AtomicBoolean;
    //   189: iconst_1
    //   190: iconst_0
    //   191: invokevirtual 486	java/util/concurrent/atomic/AtomicBoolean:compareAndSet	(ZZ)Z
    //   194: ifeq +19 -> 213
    //   197: aload_0
    //   198: getfield 70	android/database/sqlite/SQLiteConnectionPool:mLock	Ljava/lang/Object;
    //   201: astore 29
    //   203: aload 29
    //   205: monitorenter
    //   206: aload_0
    //   207: invokespecial 135	android/database/sqlite/SQLiteConnectionPool:wakeConnectionWaitersLocked	()V
    //   210: aload 29
    //   212: monitorexit
    //   213: ldc2_w 487
    //   216: lload 15
    //   218: lmul
    //   219: lstore 20
    //   221: aload_0
    //   222: lload 20
    //   224: invokestatic 492	java/util/concurrent/locks/LockSupport:parkNanos	(Ljava/lang/Object;J)V
    //   227: invokestatic 495	java/lang/Thread:interrupted	()Z
    //   230: pop
    //   231: aload_0
    //   232: getfield 70	android/database/sqlite/SQLiteConnectionPool:mLock	Ljava/lang/Object;
    //   235: astore 23
    //   237: aload 23
    //   239: monitorenter
    //   240: aload_0
    //   241: invokespecial 210	android/database/sqlite/SQLiteConnectionPool:throwIfClosedLocked	()V
    //   244: aload 11
    //   246: getfield 107	android/database/sqlite/SQLiteConnectionPool$ConnectionWaiter:mAssignedConnection	Landroid/database/sqlite/SQLiteConnection;
    //   249: astore 25
    //   251: aload 11
    //   253: getfield 111	android/database/sqlite/SQLiteConnectionPool$ConnectionWaiter:mException	Ljava/lang/RuntimeException;
    //   256: astore 26
    //   258: aload 25
    //   260: ifnonnull +8 -> 268
    //   263: aload 26
    //   265: ifnull +93 -> 358
    //   268: aload_0
    //   269: aload 11
    //   271: invokespecial 497	android/database/sqlite/SQLiteConnectionPool:recycleConnectionWaiterLocked	(Landroid/database/sqlite/SQLiteConnectionPool$ConnectionWaiter;)V
    //   274: aload 25
    //   276: ifnull +71 -> 347
    //   279: aload 23
    //   281: monitorexit
    //   282: aload_3
    //   283: ifnull +129 -> 412
    //   286: aload_3
    //   287: aconst_null
    //   288: invokevirtual 482	android/os/CancellationSignal:setOnCancelListener	(Landroid/os/CancellationSignal$OnCancelListener;)V
    //   291: aload 25
    //   293: areturn
    //   294: aload 13
    //   296: astore 12
    //   298: aload 13
    //   300: getfield 119	android/database/sqlite/SQLiteConnectionPool$ConnectionWaiter:mNext	Landroid/database/sqlite/SQLiteConnectionPool$ConnectionWaiter;
    //   303: astore 13
    //   305: goto -199 -> 106
    //   308: aload_0
    //   309: aload 11
    //   311: putfield 113	android/database/sqlite/SQLiteConnectionPool:mConnectionWaiterQueue	Landroid/database/sqlite/SQLiteConnectionPool$ConnectionWaiter;
    //   314: goto -174 -> 140
    //   317: astore 6
    //   319: aload 5
    //   321: monitorexit
    //   322: aload 6
    //   324: athrow
    //   325: astore 30
    //   327: aload 29
    //   329: monitorexit
    //   330: aload 30
    //   332: athrow
    //   333: astore 17
    //   335: aload_3
    //   336: ifnull +8 -> 344
    //   339: aload_3
    //   340: aconst_null
    //   341: invokevirtual 482	android/os/CancellationSignal:setOnCancelListener	(Landroid/os/CancellationSignal$OnCancelListener;)V
    //   344: aload 17
    //   346: athrow
    //   347: aload 26
    //   349: athrow
    //   350: astore 24
    //   352: aload 23
    //   354: monitorexit
    //   355: aload 24
    //   357: athrow
    //   358: invokestatic 471	android/os/SystemClock:uptimeMillis	()J
    //   361: lstore 27
    //   363: lload 27
    //   365: lload 18
    //   367: lcmp
    //   368: ifge +16 -> 384
    //   371: lload 27
    //   373: lload 18
    //   375: lsub
    //   376: lstore 15
    //   378: aload 23
    //   380: monitorexit
    //   381: goto -196 -> 185
    //   384: aload_0
    //   385: lload 27
    //   387: aload 11
    //   389: getfield 376	android/database/sqlite/SQLiteConnectionPool$ConnectionWaiter:mStartTime	J
    //   392: lsub
    //   393: iload_2
    //   394: invokespecial 499	android/database/sqlite/SQLiteConnectionPool:logConnectionPoolBusyLocked	(JI)V
    //   397: ldc2_w 19
    //   400: lstore 15
    //   402: lload 27
    //   404: lload 15
    //   406: ladd
    //   407: lstore 18
    //   409: goto -31 -> 378
    //   412: aload 25
    //   414: areturn
    //   415: iconst_0
    //   416: istore 4
    //   418: goto -409 -> 9
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	421	0	this	SQLiteConnectionPool
    //   0	421	1	paramString	String
    //   0	421	2	paramInt	int
    //   0	421	3	paramCancellationSignal	CancellationSignal
    //   7	410	4	bool	boolean
    //   13	307	5	localObject1	Object
    //   317	6	6	localObject2	Object
    //   31	36	7	localSQLiteConnection1	SQLiteConnection
    //   73	46	8	i	int
    //   78	7	9	l1	long
    //   95	293	11	localConnectionWaiter1	ConnectionWaiter
    //   98	199	12	localObject3	Object
    //   104	200	13	localConnectionWaiter2	ConnectionWaiter
    //   145	18	14	j	int
    //   173	232	15	l2	long
    //   333	12	17	localObject4	Object
    //   183	225	18	l3	long
    //   219	4	20	l4	long
    //   350	6	24	localObject6	Object
    //   249	164	25	localSQLiteConnection2	SQLiteConnection
    //   256	92	26	localRuntimeException	RuntimeException
    //   361	42	27	l5	long
    //   325	6	30	localObject8	Object
    // Exception table:
    //   from	to	target	type
    //   18	22	317	finally
    //   26	30	317	finally
    //   38	46	317	finally
    //   51	58	317	finally
    //   63	66	317	finally
    //   69	97	317	finally
    //   100	106	317	finally
    //   111	128	317	finally
    //   133	140	317	finally
    //   140	150	317	finally
    //   298	305	317	finally
    //   308	314	317	finally
    //   319	322	317	finally
    //   206	213	325	finally
    //   327	330	325	finally
    //   175	185	333	finally
    //   185	206	333	finally
    //   221	240	333	finally
    //   330	333	333	finally
    //   355	358	333	finally
    //   240	258	350	finally
    //   268	274	350	finally
    //   279	282	350	finally
    //   347	350	350	finally
    //   352	355	350	finally
    //   358	363	350	finally
    //   378	381	350	finally
    //   384	397	350	finally
  }
  
  private void wakeConnectionWaitersLocked()
  {
    Object localObject1 = null;
    Object localObject2 = this.mConnectionWaiterQueue;
    int i = 0;
    int j = 0;
    int k;
    label26:
    ConnectionWaiter localConnectionWaiter;
    if (localObject2 != null) {
      if (!this.mIsOpen)
      {
        k = 1;
        localConnectionWaiter = ((ConnectionWaiter)localObject2).mNext;
        if (k == 0) {
          break label191;
        }
        if (localObject1 == null) {
          break label182;
        }
        ((ConnectionWaiter)localObject1).mNext = localConnectionWaiter;
        label47:
        ((ConnectionWaiter)localObject2).mNext = null;
        LockSupport.unpark(((ConnectionWaiter)localObject2).mThread);
      }
    }
    for (;;)
    {
      localObject2 = localConnectionWaiter;
      break;
      try
      {
        boolean bool = ((ConnectionWaiter)localObject2).mWantPrimaryConnection;
        SQLiteConnection localSQLiteConnection = null;
        if (!bool)
        {
          localSQLiteConnection = null;
          if (j == 0)
          {
            localSQLiteConnection = tryAcquireNonPrimaryConnectionLocked(((ConnectionWaiter)localObject2).mSql, ((ConnectionWaiter)localObject2).mConnectionFlags);
            if (localSQLiteConnection == null) {
              j = 1;
            }
          }
        }
        if ((localSQLiteConnection == null) && (i == 0))
        {
          localSQLiteConnection = tryAcquirePrimaryConnectionLocked(((ConnectionWaiter)localObject2).mConnectionFlags);
          if (localSQLiteConnection == null) {
            i = 1;
          }
        }
        if (localSQLiteConnection != null)
        {
          ((ConnectionWaiter)localObject2).mAssignedConnection = localSQLiteConnection;
          k = 1;
          break label26;
        }
        k = 0;
        if (j == 0) {
          break label26;
        }
        k = 0;
        if (i == 0) {
          break label26;
        }
        return;
      }
      catch (RuntimeException localRuntimeException)
      {
        ((ConnectionWaiter)localObject2).mException = localRuntimeException;
        k = 1;
      }
      break label26;
      label182:
      this.mConnectionWaiterQueue = localConnectionWaiter;
      break label47;
      label191:
      localObject1 = localObject2;
    }
  }
  
  public SQLiteConnection acquireConnection(String paramString, int paramInt, CancellationSignal paramCancellationSignal)
  {
    return waitForConnection(paramString, paramInt, paramCancellationSignal);
  }
  
  public void close()
  {
    dispose(false);
  }
  
  public void collectDbStats(ArrayList<SQLiteDebug.DbStats> paramArrayList)
  {
    synchronized (this.mLock)
    {
      if (this.mAvailablePrimaryConnection != null) {
        this.mAvailablePrimaryConnection.collectDbStats(paramArrayList);
      }
      Iterator localIterator1 = this.mAvailableNonPrimaryConnections.iterator();
      if (localIterator1.hasNext()) {
        ((SQLiteConnection)localIterator1.next()).collectDbStats(paramArrayList);
      }
    }
    Iterator localIterator2 = this.mAcquiredConnections.keySet().iterator();
    while (localIterator2.hasNext()) {
      ((SQLiteConnection)localIterator2.next()).collectDbStatsUnsafe(paramArrayList);
    }
  }
  
  public void dump(Printer paramPrinter, boolean paramBoolean)
  {
    Printer localPrinter = PrefixPrinter.create(paramPrinter, "    ");
    synchronized (this.mLock)
    {
      paramPrinter.println("Connection pool for " + this.mConfiguration.path + ":");
      paramPrinter.println("  Open: " + this.mIsOpen);
      paramPrinter.println("  Max connections: " + this.mMaxConnectionPoolSize);
      paramPrinter.println("  Available primary connection:");
      if (this.mAvailablePrimaryConnection != null)
      {
        this.mAvailablePrimaryConnection.dump(localPrinter, paramBoolean);
        paramPrinter.println("  Available non-primary connections:");
        if (!this.mAvailableNonPrimaryConnections.isEmpty())
        {
          int j = this.mAvailableNonPrimaryConnections.size();
          for (int k = 0; k < j; k++) {
            ((SQLiteConnection)this.mAvailableNonPrimaryConnections.get(k)).dump(localPrinter, paramBoolean);
          }
        }
      }
      else
      {
        localPrinter.println("<none>");
      }
    }
    localPrinter.println("<none>");
    paramPrinter.println("  Acquired connections:");
    if (!this.mAcquiredConnections.isEmpty())
    {
      Iterator localIterator = this.mAcquiredConnections.entrySet().iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        ((SQLiteConnection)localEntry.getKey()).dumpUnsafe(localPrinter, paramBoolean);
        localPrinter.println("  Status: " + localEntry.getValue());
      }
    }
    localPrinter.println("<none>");
    paramPrinter.println("  Connection waiters:");
    if (this.mConnectionWaiterQueue != null)
    {
      int i = 0;
      long l = SystemClock.uptimeMillis();
      ConnectionWaiter localConnectionWaiter = this.mConnectionWaiterQueue;
      while (localConnectionWaiter != null)
      {
        localPrinter.println(i + ": waited for " + 0.001F * (float)(l - localConnectionWaiter.mStartTime) + " ms - thread=" + localConnectionWaiter.mThread + ", priority=" + localConnectionWaiter.mPriority + ", sql='" + localConnectionWaiter.mSql + "'");
        localConnectionWaiter = localConnectionWaiter.mNext;
        i++;
      }
    }
    localPrinter.println("<none>");
  }
  
  protected void finalize()
    throws Throwable
  {
    try
    {
      dispose(true);
      return;
    }
    finally
    {
      super.finalize();
    }
  }
  
  void onConnectionLeaked()
  {
    Log.w("SQLiteConnectionPool", "A SQLiteConnection object for database '" + this.mConfiguration.label + "' was leaked!  Please fix your application " + "to end transactions in progress properly and to close the database " + "when it is no longer needed.");
    this.mConnectionLeaked.set(true);
  }
  
  public void reconfigure(SQLiteDatabaseConfiguration paramSQLiteDatabaseConfiguration)
  {
    int i = 1;
    if (paramSQLiteDatabaseConfiguration == null) {
      throw new IllegalArgumentException("configuration must not be null.");
    }
    int j;
    for (;;)
    {
      synchronized (this.mLock)
      {
        throwIfClosedLocked();
        if ((0x20000000 & (paramSQLiteDatabaseConfiguration.openFlags ^ this.mConfiguration.openFlags)) != 0)
        {
          j = i;
          if (j == 0) {
            break label117;
          }
          if (this.mAcquiredConnections.isEmpty()) {
            break;
          }
          throw new IllegalStateException("Write Ahead Logging (WAL) mode cannot be enabled or disabled while there are transactions in progress.  Finish all transactions and release all active database connections first.");
        }
      }
      j = 0;
    }
    closeAvailableNonPrimaryConnectionsAndLogExceptionsLocked();
    assert (this.mAvailableNonPrimaryConnections.isEmpty());
    label117:
    if (paramSQLiteDatabaseConfiguration.foreignKeyConstraintsEnabled != this.mConfiguration.foreignKeyConstraintsEnabled) {}
    for (;;)
    {
      if ((i != 0) && (!this.mAcquiredConnections.isEmpty())) {
        throw new IllegalStateException("Foreign Key Constraints cannot be enabled or disabled while there are transactions in progress.  Finish all transactions and release all active database connections first.");
      }
      if (this.mConfiguration.openFlags != paramSQLiteDatabaseConfiguration.openFlags)
      {
        if (j != 0) {
          closeAvailableConnectionsAndLogExceptionsLocked();
        }
        SQLiteConnection localSQLiteConnection = openConnectionLocked(paramSQLiteDatabaseConfiguration, true);
        closeAvailableConnectionsAndLogExceptionsLocked();
        discardAcquiredConnectionsLocked();
        this.mAvailablePrimaryConnection = localSQLiteConnection;
        this.mConfiguration.updateParametersFrom(paramSQLiteDatabaseConfiguration);
        setMaxConnectionPoolSizeLocked();
      }
      for (;;)
      {
        wakeConnectionWaitersLocked();
        return;
        this.mConfiguration.updateParametersFrom(paramSQLiteDatabaseConfiguration);
        setMaxConnectionPoolSizeLocked();
        closeExcessConnectionsAndLogExceptionsLocked();
        reconfigureAllConnectionsLocked();
      }
      i = 0;
    }
  }
  
  public void releaseConnection(SQLiteConnection paramSQLiteConnection)
  {
    AcquiredConnectionStatus localAcquiredConnectionStatus;
    synchronized (this.mLock)
    {
      localAcquiredConnectionStatus = (AcquiredConnectionStatus)this.mAcquiredConnections.remove(paramSQLiteConnection);
      if (localAcquiredConnectionStatus == null) {
        throw new IllegalStateException("Cannot perform this operation because the specified connection was not acquired from this pool or has already been released.");
      }
    }
    if (!this.mIsOpen) {
      closeConnectionAndLogExceptionsLocked(paramSQLiteConnection);
    }
    for (;;)
    {
      return;
      if (paramSQLiteConnection.isPrimaryConnection())
      {
        if (recycleConnectionLocked(paramSQLiteConnection, localAcquiredConnectionStatus))
        {
          assert (this.mAvailablePrimaryConnection == null);
          this.mAvailablePrimaryConnection = paramSQLiteConnection;
        }
        wakeConnectionWaitersLocked();
      }
      else if (this.mAvailableNonPrimaryConnections.size() >= -1 + this.mMaxConnectionPoolSize)
      {
        closeConnectionAndLogExceptionsLocked(paramSQLiteConnection);
      }
      else
      {
        if (recycleConnectionLocked(paramSQLiteConnection, localAcquiredConnectionStatus)) {
          this.mAvailableNonPrimaryConnections.add(paramSQLiteConnection);
        }
        wakeConnectionWaitersLocked();
      }
    }
  }
  
  public boolean shouldYieldConnection(SQLiteConnection paramSQLiteConnection, int paramInt)
  {
    synchronized (this.mLock)
    {
      if (!this.mAcquiredConnections.containsKey(paramSQLiteConnection)) {
        throw new IllegalStateException("Cannot perform this operation because the specified connection was not acquired from this pool or has already been released.");
      }
    }
    if (!this.mIsOpen) {
      return false;
    }
    boolean bool = isSessionBlockingImportantConnectionWaitersLocked(paramSQLiteConnection.isPrimaryConnection(), paramInt);
    return bool;
  }
  
  public String toString()
  {
    return "SQLiteConnectionPool: " + this.mConfiguration.path;
  }
  
  static enum AcquiredConnectionStatus
  {
    static
    {
      DISCARD = new AcquiredConnectionStatus("DISCARD", 2);
      AcquiredConnectionStatus[] arrayOfAcquiredConnectionStatus = new AcquiredConnectionStatus[3];
      arrayOfAcquiredConnectionStatus[0] = NORMAL;
      arrayOfAcquiredConnectionStatus[1] = RECONFIGURE;
      arrayOfAcquiredConnectionStatus[2] = DISCARD;
      $VALUES = arrayOfAcquiredConnectionStatus;
    }
    
    private AcquiredConnectionStatus() {}
  }
  
  private static final class ConnectionWaiter
  {
    public SQLiteConnection mAssignedConnection;
    public int mConnectionFlags;
    public RuntimeException mException;
    public ConnectionWaiter mNext;
    public int mNonce;
    public int mPriority;
    public String mSql;
    public long mStartTime;
    public Thread mThread;
    public boolean mWantPrimaryConnection;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\sqlite\SQLiteConnectionPool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
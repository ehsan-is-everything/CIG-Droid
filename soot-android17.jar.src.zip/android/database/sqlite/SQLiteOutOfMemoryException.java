package android.database.sqlite;

public class SQLiteOutOfMemoryException
  extends SQLiteException
{
  public SQLiteOutOfMemoryException() {}
  
  public SQLiteOutOfMemoryException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\sqlite\SQLiteOutOfMemoryException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
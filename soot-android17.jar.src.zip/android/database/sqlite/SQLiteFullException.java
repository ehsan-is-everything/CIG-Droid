package android.database.sqlite;

public class SQLiteFullException
  extends SQLiteException
{
  public SQLiteFullException() {}
  
  public SQLiteFullException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\sqlite\SQLiteFullException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
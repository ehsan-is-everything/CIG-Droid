package android.database.sqlite;

public class SQLiteBindOrColumnIndexOutOfRangeException
  extends SQLiteException
{
  public SQLiteBindOrColumnIndexOutOfRangeException() {}
  
  public SQLiteBindOrColumnIndexOutOfRangeException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\sqlite\SQLiteBindOrColumnIndexOutOfRangeException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
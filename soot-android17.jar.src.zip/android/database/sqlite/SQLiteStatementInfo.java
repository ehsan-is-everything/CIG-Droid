package android.database.sqlite;

public final class SQLiteStatementInfo
{
  public String[] columnNames;
  public int numParameters;
  public boolean readOnly;
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\sqlite\SQLiteStatementInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
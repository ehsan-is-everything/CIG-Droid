package android.database.sqlite;

public class SQLiteDatabaseCorruptException
  extends SQLiteException
{
  public SQLiteDatabaseCorruptException() {}
  
  public SQLiteDatabaseCorruptException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\sqlite\SQLiteDatabaseCorruptException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
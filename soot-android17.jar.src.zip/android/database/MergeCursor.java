package android.database;

public class MergeCursor
  extends AbstractCursor
{
  private Cursor mCursor;
  private Cursor[] mCursors;
  private DataSetObserver mObserver = new DataSetObserver()
  {
    public void onChanged()
    {
      MergeCursor.this.mPos = -1;
    }
    
    public void onInvalidated()
    {
      MergeCursor.this.mPos = -1;
    }
  };
  
  public MergeCursor(Cursor[] paramArrayOfCursor)
  {
    this.mCursors = paramArrayOfCursor;
    this.mCursor = paramArrayOfCursor[0];
    int i = 0;
    if (i < this.mCursors.length)
    {
      if (this.mCursors[i] == null) {}
      for (;;)
      {
        i++;
        break;
        this.mCursors[i].registerDataSetObserver(this.mObserver);
      }
    }
  }
  
  public void close()
  {
    int i = this.mCursors.length;
    int j = 0;
    if (j < i)
    {
      if (this.mCursors[j] == null) {}
      for (;;)
      {
        j++;
        break;
        this.mCursors[j].close();
      }
    }
    super.close();
  }
  
  public void deactivate()
  {
    int i = this.mCursors.length;
    for (int j = 0; j < i; j++) {
      if (this.mCursors[j] != null) {
        this.mCursors[j].deactivate();
      }
    }
    super.deactivate();
  }
  
  public byte[] getBlob(int paramInt)
  {
    return this.mCursor.getBlob(paramInt);
  }
  
  public String[] getColumnNames()
  {
    if (this.mCursor != null) {
      return this.mCursor.getColumnNames();
    }
    return new String[0];
  }
  
  public int getCount()
  {
    int i = 0;
    int j = this.mCursors.length;
    for (int k = 0; k < j; k++) {
      if (this.mCursors[k] != null) {
        i += this.mCursors[k].getCount();
      }
    }
    return i;
  }
  
  public double getDouble(int paramInt)
  {
    return this.mCursor.getDouble(paramInt);
  }
  
  public float getFloat(int paramInt)
  {
    return this.mCursor.getFloat(paramInt);
  }
  
  public int getInt(int paramInt)
  {
    return this.mCursor.getInt(paramInt);
  }
  
  public long getLong(int paramInt)
  {
    return this.mCursor.getLong(paramInt);
  }
  
  public short getShort(int paramInt)
  {
    return this.mCursor.getShort(paramInt);
  }
  
  public String getString(int paramInt)
  {
    return this.mCursor.getString(paramInt);
  }
  
  public int getType(int paramInt)
  {
    return this.mCursor.getType(paramInt);
  }
  
  public boolean isNull(int paramInt)
  {
    return this.mCursor.isNull(paramInt);
  }
  
  public boolean onMove(int paramInt1, int paramInt2)
  {
    this.mCursor = null;
    int i = 0;
    int j = this.mCursors.length;
    int k = 0;
    if (k < j) {
      if (this.mCursors[k] != null) {}
    }
    for (;;)
    {
      k++;
      break;
      if (paramInt2 < i + this.mCursors[k].getCount())
      {
        this.mCursor = this.mCursors[k];
        if (this.mCursor == null) {
          break label107;
        }
        return this.mCursor.moveToPosition(paramInt2 - i);
      }
      i += this.mCursors[k].getCount();
    }
    label107:
    return false;
  }
  
  public void registerContentObserver(ContentObserver paramContentObserver)
  {
    int i = this.mCursors.length;
    for (int j = 0; j < i; j++) {
      if (this.mCursors[j] != null) {
        this.mCursors[j].registerContentObserver(paramContentObserver);
      }
    }
  }
  
  public void registerDataSetObserver(DataSetObserver paramDataSetObserver)
  {
    int i = this.mCursors.length;
    for (int j = 0; j < i; j++) {
      if (this.mCursors[j] != null) {
        this.mCursors[j].registerDataSetObserver(paramDataSetObserver);
      }
    }
  }
  
  public boolean requery()
  {
    int i = this.mCursors.length;
    int j = 0;
    if (j < i)
    {
      if (this.mCursors[j] == null) {}
      while (this.mCursors[j].requery())
      {
        j++;
        break;
      }
      return false;
    }
    return true;
  }
  
  public void unregisterContentObserver(ContentObserver paramContentObserver)
  {
    int i = this.mCursors.length;
    for (int j = 0; j < i; j++) {
      if (this.mCursors[j] != null) {
        this.mCursors[j].unregisterContentObserver(paramContentObserver);
      }
    }
  }
  
  public void unregisterDataSetObserver(DataSetObserver paramDataSetObserver)
  {
    int i = this.mCursors.length;
    for (int j = 0; j < i; j++) {
      if (this.mCursors[j] != null) {
        this.mCursors[j].unregisterDataSetObserver(paramDataSetObserver);
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\MergeCursor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
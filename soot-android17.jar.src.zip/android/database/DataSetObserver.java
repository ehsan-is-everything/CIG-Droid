package android.database;

public abstract class DataSetObserver
{
  public void onChanged() {}
  
  public void onInvalidated() {}
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\database\DataSetObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.bluetooth;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import java.util.ArrayList;
import java.util.List;

public abstract interface IBluetoothHealth
  extends IInterface
{
  public abstract boolean connectChannelToSink(BluetoothDevice paramBluetoothDevice, BluetoothHealthAppConfiguration paramBluetoothHealthAppConfiguration, int paramInt)
    throws RemoteException;
  
  public abstract boolean connectChannelToSource(BluetoothDevice paramBluetoothDevice, BluetoothHealthAppConfiguration paramBluetoothHealthAppConfiguration)
    throws RemoteException;
  
  public abstract boolean disconnectChannel(BluetoothDevice paramBluetoothDevice, BluetoothHealthAppConfiguration paramBluetoothHealthAppConfiguration, int paramInt)
    throws RemoteException;
  
  public abstract List<BluetoothDevice> getConnectedHealthDevices()
    throws RemoteException;
  
  public abstract int getHealthDeviceConnectionState(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract List<BluetoothDevice> getHealthDevicesMatchingConnectionStates(int[] paramArrayOfInt)
    throws RemoteException;
  
  public abstract ParcelFileDescriptor getMainChannelFd(BluetoothDevice paramBluetoothDevice, BluetoothHealthAppConfiguration paramBluetoothHealthAppConfiguration)
    throws RemoteException;
  
  public abstract boolean registerAppConfiguration(BluetoothHealthAppConfiguration paramBluetoothHealthAppConfiguration, IBluetoothHealthCallback paramIBluetoothHealthCallback)
    throws RemoteException;
  
  public abstract boolean unregisterAppConfiguration(BluetoothHealthAppConfiguration paramBluetoothHealthAppConfiguration)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IBluetoothHealth
  {
    private static final String DESCRIPTOR = "android.bluetooth.IBluetoothHealth";
    static final int TRANSACTION_connectChannelToSink = 4;
    static final int TRANSACTION_connectChannelToSource = 3;
    static final int TRANSACTION_disconnectChannel = 5;
    static final int TRANSACTION_getConnectedHealthDevices = 7;
    static final int TRANSACTION_getHealthDeviceConnectionState = 9;
    static final int TRANSACTION_getHealthDevicesMatchingConnectionStates = 8;
    static final int TRANSACTION_getMainChannelFd = 6;
    static final int TRANSACTION_registerAppConfiguration = 1;
    static final int TRANSACTION_unregisterAppConfiguration = 2;
    
    public Stub()
    {
      attachInterface(this, "android.bluetooth.IBluetoothHealth");
    }
    
    public static IBluetoothHealth asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.bluetooth.IBluetoothHealth");
      if ((localIInterface != null) && ((localIInterface instanceof IBluetoothHealth))) {
        return (IBluetoothHealth)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.bluetooth.IBluetoothHealth");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHealth");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothHealthAppConfiguration localBluetoothHealthAppConfiguration6 = (BluetoothHealthAppConfiguration)BluetoothHealthAppConfiguration.CREATOR.createFromParcel(paramParcel1);; localBluetoothHealthAppConfiguration6 = null)
        {
          boolean bool5 = registerAppConfiguration(localBluetoothHealthAppConfiguration6, IBluetoothHealthCallback.Stub.asInterface(paramParcel1.readStrongBinder()));
          paramParcel2.writeNoException();
          int i1 = 0;
          if (bool5) {
            i1 = 1;
          }
          paramParcel2.writeInt(i1);
          return true;
        }
      case 2: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHealth");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothHealthAppConfiguration localBluetoothHealthAppConfiguration5 = (BluetoothHealthAppConfiguration)BluetoothHealthAppConfiguration.CREATOR.createFromParcel(paramParcel1);; localBluetoothHealthAppConfiguration5 = null)
        {
          boolean bool4 = unregisterAppConfiguration(localBluetoothHealthAppConfiguration5);
          paramParcel2.writeNoException();
          int n = 0;
          if (bool4) {
            n = 1;
          }
          paramParcel2.writeInt(n);
          return true;
        }
      case 3: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHealth");
        BluetoothDevice localBluetoothDevice5;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice5 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label332;
          }
        }
        for (BluetoothHealthAppConfiguration localBluetoothHealthAppConfiguration4 = (BluetoothHealthAppConfiguration)BluetoothHealthAppConfiguration.CREATOR.createFromParcel(paramParcel1);; localBluetoothHealthAppConfiguration4 = null)
        {
          boolean bool3 = connectChannelToSource(localBluetoothDevice5, localBluetoothHealthAppConfiguration4);
          paramParcel2.writeNoException();
          int m = 0;
          if (bool3) {
            m = 1;
          }
          paramParcel2.writeInt(m);
          return true;
          localBluetoothDevice5 = null;
          break;
        }
      case 4: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHealth");
        BluetoothDevice localBluetoothDevice4;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice4 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label429;
          }
        }
        for (BluetoothHealthAppConfiguration localBluetoothHealthAppConfiguration3 = (BluetoothHealthAppConfiguration)BluetoothHealthAppConfiguration.CREATOR.createFromParcel(paramParcel1);; localBluetoothHealthAppConfiguration3 = null)
        {
          boolean bool2 = connectChannelToSink(localBluetoothDevice4, localBluetoothHealthAppConfiguration3, paramParcel1.readInt());
          paramParcel2.writeNoException();
          int k = 0;
          if (bool2) {
            k = 1;
          }
          paramParcel2.writeInt(k);
          return true;
          localBluetoothDevice4 = null;
          break;
        }
      case 5: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHealth");
        BluetoothDevice localBluetoothDevice3;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice3 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label526;
          }
        }
        for (BluetoothHealthAppConfiguration localBluetoothHealthAppConfiguration2 = (BluetoothHealthAppConfiguration)BluetoothHealthAppConfiguration.CREATOR.createFromParcel(paramParcel1);; localBluetoothHealthAppConfiguration2 = null)
        {
          boolean bool1 = disconnectChannel(localBluetoothDevice3, localBluetoothHealthAppConfiguration2, paramParcel1.readInt());
          paramParcel2.writeNoException();
          int j = 0;
          if (bool1) {
            j = 1;
          }
          paramParcel2.writeInt(j);
          return true;
          localBluetoothDevice3 = null;
          break;
        }
      case 6: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHealth");
        BluetoothDevice localBluetoothDevice2;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice2 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label619;
          }
        }
        for (BluetoothHealthAppConfiguration localBluetoothHealthAppConfiguration1 = (BluetoothHealthAppConfiguration)BluetoothHealthAppConfiguration.CREATOR.createFromParcel(paramParcel1);; localBluetoothHealthAppConfiguration1 = null)
        {
          ParcelFileDescriptor localParcelFileDescriptor = getMainChannelFd(localBluetoothDevice2, localBluetoothHealthAppConfiguration1);
          paramParcel2.writeNoException();
          if (localParcelFileDescriptor == null) {
            break label625;
          }
          paramParcel2.writeInt(1);
          localParcelFileDescriptor.writeToParcel(paramParcel2, 1);
          return true;
          localBluetoothDevice2 = null;
          break;
        }
        paramParcel2.writeInt(0);
        return true;
      case 7: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHealth");
        List localList2 = getConnectedHealthDevices();
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList2);
        return true;
      case 8: 
        label332:
        label429:
        label526:
        label619:
        label625:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHealth");
        List localList1 = getHealthDevicesMatchingConnectionStates(paramParcel1.createIntArray());
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList1);
        return true;
      }
      paramParcel1.enforceInterface("android.bluetooth.IBluetoothHealth");
      if (paramParcel1.readInt() != 0) {}
      for (BluetoothDevice localBluetoothDevice1 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice1 = null)
      {
        int i = getHealthDeviceConnectionState(localBluetoothDevice1);
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i);
        return true;
      }
    }
    
    private static class Proxy
      implements IBluetoothHealth
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public boolean connectChannelToSink(BluetoothDevice paramBluetoothDevice, BluetoothHealthAppConfiguration paramBluetoothHealthAppConfiguration, int paramInt)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHealth");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              if (paramBluetoothHealthAppConfiguration != null)
              {
                localParcel1.writeInt(1);
                paramBluetoothHealthAppConfiguration.writeToParcel(localParcel1, 0);
                localParcel1.writeInt(paramInt);
                this.mRemote.transact(4, localParcel1, localParcel2, 0);
                localParcel2.readException();
                int i = localParcel2.readInt();
                if (i == 0) {
                  break label139;
                }
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            localParcel1.writeInt(0);
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          continue;
          label139:
          bool = false;
        }
      }
      
      public boolean connectChannelToSource(BluetoothDevice paramBluetoothDevice, BluetoothHealthAppConfiguration paramBluetoothHealthAppConfiguration)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHealth");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              if (paramBluetoothHealthAppConfiguration != null)
              {
                localParcel1.writeInt(1);
                paramBluetoothHealthAppConfiguration.writeToParcel(localParcel1, 0);
                this.mRemote.transact(3, localParcel1, localParcel2, 0);
                localParcel2.readException();
                int i = localParcel2.readInt();
                if (i == 0) {
                  break label131;
                }
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            localParcel1.writeInt(0);
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          continue;
          label131:
          bool = false;
        }
      }
      
      public boolean disconnectChannel(BluetoothDevice paramBluetoothDevice, BluetoothHealthAppConfiguration paramBluetoothHealthAppConfiguration, int paramInt)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHealth");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              if (paramBluetoothHealthAppConfiguration != null)
              {
                localParcel1.writeInt(1);
                paramBluetoothHealthAppConfiguration.writeToParcel(localParcel1, 0);
                localParcel1.writeInt(paramInt);
                this.mRemote.transact(5, localParcel1, localParcel2, 0);
                localParcel2.readException();
                int i = localParcel2.readInt();
                if (i == 0) {
                  break label139;
                }
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            localParcel1.writeInt(0);
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          continue;
          label139:
          bool = false;
        }
      }
      
      public List<BluetoothDevice> getConnectedHealthDevices()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHealth");
          this.mRemote.transact(7, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(BluetoothDevice.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public int getHealthDeviceConnectionState(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +50 -> 65
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 43	android/bluetooth/BluetoothDevice:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/bluetooth/IBluetoothHealth$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: bipush 9
        //   35: aload_2
        //   36: aload_3
        //   37: iconst_0
        //   38: invokeinterface 52 5 0
        //   43: pop
        //   44: aload_3
        //   45: invokevirtual 55	android/os/Parcel:readException	()V
        //   48: aload_3
        //   49: invokevirtual 59	android/os/Parcel:readInt	()I
        //   52: istore 6
        //   54: aload_3
        //   55: invokevirtual 62	android/os/Parcel:recycle	()V
        //   58: aload_2
        //   59: invokevirtual 62	android/os/Parcel:recycle	()V
        //   62: iload 6
        //   64: ireturn
        //   65: aload_2
        //   66: iconst_0
        //   67: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   70: goto -41 -> 29
        //   73: astore 4
        //   75: aload_3
        //   76: invokevirtual 62	android/os/Parcel:recycle	()V
        //   79: aload_2
        //   80: invokevirtual 62	android/os/Parcel:recycle	()V
        //   83: aload 4
        //   85: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	86	0	this	Proxy
        //   0	86	1	paramBluetoothDevice	BluetoothDevice
        //   3	77	2	localParcel1	Parcel
        //   7	69	3	localParcel2	Parcel
        //   73	11	4	localObject	Object
        //   52	11	6	i	int
        // Exception table:
        //   from	to	target	type
        //   8	14	73	finally
        //   18	29	73	finally
        //   29	54	73	finally
        //   65	70	73	finally
      }
      
      public List<BluetoothDevice> getHealthDevicesMatchingConnectionStates(int[] paramArrayOfInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHealth");
          localParcel1.writeIntArray(paramArrayOfInt);
          this.mRemote.transact(8, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(BluetoothDevice.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.bluetooth.IBluetoothHealth";
      }
      
      public ParcelFileDescriptor getMainChannelFd(BluetoothDevice paramBluetoothDevice, BluetoothHealthAppConfiguration paramBluetoothHealthAppConfiguration)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHealth");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              if (paramBluetoothHealthAppConfiguration != null)
              {
                localParcel1.writeInt(1);
                paramBluetoothHealthAppConfiguration.writeToParcel(localParcel1, 0);
                this.mRemote.transact(6, localParcel1, localParcel2, 0);
                localParcel2.readException();
                if (localParcel2.readInt() == 0) {
                  break label131;
                }
                localParcelFileDescriptor = (ParcelFileDescriptor)ParcelFileDescriptor.CREATOR.createFromParcel(localParcel2);
                return localParcelFileDescriptor;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            localParcel1.writeInt(0);
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          continue;
          label131:
          ParcelFileDescriptor localParcelFileDescriptor = null;
        }
      }
      
      public boolean registerAppConfiguration(BluetoothHealthAppConfiguration paramBluetoothHealthAppConfiguration, IBluetoothHealthCallback paramIBluetoothHealthCallback)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHealth");
            if (paramBluetoothHealthAppConfiguration != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothHealthAppConfiguration.writeToParcel(localParcel1, 0);
              if (paramIBluetoothHealthCallback != null)
              {
                localIBinder = paramIBluetoothHealthCallback.asBinder();
                localParcel1.writeStrongBinder(localIBinder);
                this.mRemote.transact(1, localParcel1, localParcel2, 0);
                localParcel2.readException();
                int i = localParcel2.readInt();
                if (i == 0) {
                  break label130;
                }
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            IBinder localIBinder = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          continue;
          label130:
          bool = false;
        }
      }
      
      public boolean unregisterAppConfiguration(BluetoothHealthAppConfiguration paramBluetoothHealthAppConfiguration)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHealth");
            if (paramBluetoothHealthAppConfiguration != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothHealthAppConfiguration.writeToParcel(localParcel1, 0);
              this.mRemote.transact(2, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\bluetooth\IBluetoothHealth.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
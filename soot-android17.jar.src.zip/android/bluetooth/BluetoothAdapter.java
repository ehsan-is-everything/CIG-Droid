package android.bluetooth;

import android.content.Context;
import android.os.Handler;
import android.os.ParcelUuid;
import android.os.RemoteException;
import android.util.Log;
import android.util.Pair;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;

public final class BluetoothAdapter
{
  public static final String ACTION_CONNECTION_STATE_CHANGED = "android.bluetooth.adapter.action.CONNECTION_STATE_CHANGED";
  public static final String ACTION_DISCOVERY_FINISHED = "android.bluetooth.adapter.action.DISCOVERY_FINISHED";
  public static final String ACTION_DISCOVERY_STARTED = "android.bluetooth.adapter.action.DISCOVERY_STARTED";
  public static final String ACTION_LOCAL_NAME_CHANGED = "android.bluetooth.adapter.action.LOCAL_NAME_CHANGED";
  public static final String ACTION_REQUEST_DISCOVERABLE = "android.bluetooth.adapter.action.REQUEST_DISCOVERABLE";
  public static final String ACTION_REQUEST_ENABLE = "android.bluetooth.adapter.action.REQUEST_ENABLE";
  public static final String ACTION_SCAN_MODE_CHANGED = "android.bluetooth.adapter.action.SCAN_MODE_CHANGED";
  public static final String ACTION_STATE_CHANGED = "android.bluetooth.adapter.action.STATE_CHANGED";
  private static final int ADDRESS_LENGTH = 17;
  public static final String BLUETOOTH_MANAGER_SERVICE = "bluetooth_manager";
  private static final boolean DBG = true;
  public static final int ERROR = Integer.MIN_VALUE;
  public static final String EXTRA_CONNECTION_STATE = "android.bluetooth.adapter.extra.CONNECTION_STATE";
  public static final String EXTRA_DISCOVERABLE_DURATION = "android.bluetooth.adapter.extra.DISCOVERABLE_DURATION";
  public static final String EXTRA_LOCAL_NAME = "android.bluetooth.adapter.extra.LOCAL_NAME";
  public static final String EXTRA_PREVIOUS_CONNECTION_STATE = "android.bluetooth.adapter.extra.PREVIOUS_CONNECTION_STATE";
  public static final String EXTRA_PREVIOUS_SCAN_MODE = "android.bluetooth.adapter.extra.PREVIOUS_SCAN_MODE";
  public static final String EXTRA_PREVIOUS_STATE = "android.bluetooth.adapter.extra.PREVIOUS_STATE";
  public static final String EXTRA_SCAN_MODE = "android.bluetooth.adapter.extra.SCAN_MODE";
  public static final String EXTRA_STATE = "android.bluetooth.adapter.extra.STATE";
  public static final int SCAN_MODE_CONNECTABLE = 21;
  public static final int SCAN_MODE_CONNECTABLE_DISCOVERABLE = 23;
  public static final int SCAN_MODE_NONE = 20;
  public static final int STATE_CONNECTED = 2;
  public static final int STATE_CONNECTING = 1;
  public static final int STATE_DISCONNECTED = 0;
  public static final int STATE_DISCONNECTING = 3;
  public static final int STATE_OFF = 10;
  public static final int STATE_ON = 12;
  public static final int STATE_TURNING_OFF = 13;
  public static final int STATE_TURNING_ON = 11;
  private static final String TAG = "BluetoothAdapter";
  private static final boolean VDBG;
  private static BluetoothAdapter sAdapter;
  private final IBluetoothManagerCallback mManagerCallback = new IBluetoothManagerCallback.Stub()
  {
    public void onBluetoothServiceDown()
    {
      Log.d("BluetoothAdapter", "onBluetoothServiceDown: " + BluetoothAdapter.this.mService);
      for (;;)
      {
        synchronized (BluetoothAdapter.this.mManagerCallback)
        {
          BluetoothAdapter.access$102(BluetoothAdapter.this, null);
          Iterator localIterator = BluetoothAdapter.this.mProxyServiceStateCallbacks.iterator();
          if (!localIterator.hasNext()) {
            break;
          }
          IBluetoothManagerCallback localIBluetoothManagerCallback2 = (IBluetoothManagerCallback)localIterator.next();
          if (localIBluetoothManagerCallback2 != null) {
            try
            {
              localIBluetoothManagerCallback2.onBluetoothServiceDown();
            }
            catch (Exception localException)
            {
              Log.e("BluetoothAdapter", "", localException);
            }
          }
        }
        Log.d("BluetoothAdapter", "onBluetoothServiceDown: cb is null!!!");
      }
    }
    
    public void onBluetoothServiceUp(IBluetooth paramAnonymousIBluetooth)
    {
      Log.d("BluetoothAdapter", "onBluetoothServiceUp: " + paramAnonymousIBluetooth);
      for (;;)
      {
        synchronized (BluetoothAdapter.this.mManagerCallback)
        {
          BluetoothAdapter.access$102(BluetoothAdapter.this, paramAnonymousIBluetooth);
          Iterator localIterator = BluetoothAdapter.this.mProxyServiceStateCallbacks.iterator();
          if (!localIterator.hasNext()) {
            break;
          }
          IBluetoothManagerCallback localIBluetoothManagerCallback2 = (IBluetoothManagerCallback)localIterator.next();
          if (localIBluetoothManagerCallback2 != null) {
            try
            {
              localIBluetoothManagerCallback2.onBluetoothServiceUp(paramAnonymousIBluetooth);
            }
            catch (Exception localException)
            {
              Log.e("BluetoothAdapter", "", localException);
            }
          }
        }
        Log.d("BluetoothAdapter", "onBluetoothServiceUp: cb is null!!!");
      }
    }
  };
  private final IBluetoothManager mManagerService;
  private ArrayList<IBluetoothManagerCallback> mProxyServiceStateCallbacks = new ArrayList();
  private IBluetooth mService;
  private Handler mServiceRecordHandler;
  
  BluetoothAdapter(IBluetoothManager paramIBluetoothManager)
  {
    if (paramIBluetoothManager == null) {
      throw new IllegalArgumentException("bluetooth manager service is null");
    }
    try
    {
      this.mService = paramIBluetoothManager.registerAdapter(this.mManagerCallback);
      this.mManagerService = paramIBluetoothManager;
      this.mServiceRecordHandler = null;
      return;
    }
    catch (RemoteException localRemoteException)
    {
      for (;;)
      {
        Log.e("BluetoothAdapter", "", localRemoteException);
      }
    }
  }
  
  public static boolean checkBluetoothAddress(String paramString)
  {
    if ((paramString == null) || (paramString.length() != 17)) {
      return false;
    }
    int i = 0;
    label17:
    if (i < 17)
    {
      int j = paramString.charAt(i);
      switch (i % 3)
      {
      }
      for (;;)
      {
        i++;
        break label17;
        if ((j < 48) || (j > 57))
        {
          if ((j < 65) || (j > 70)) {
            break;
          }
          continue;
          if (j != 58) {
            break;
          }
        }
      }
    }
    return true;
  }
  
  private BluetoothServerSocket createNewRfcommSocketAndRecord(String paramString, UUID paramUUID, boolean paramBoolean1, boolean paramBoolean2)
    throws IOException
  {
    BluetoothServerSocket localBluetoothServerSocket = new BluetoothServerSocket(1, paramBoolean1, paramBoolean2, new ParcelUuid(paramUUID));
    localBluetoothServerSocket.setServiceName(paramString);
    int i = localBluetoothServerSocket.mSocket.bindListen();
    if (i != 0) {
      throw new IOException("Error: " + i);
    }
    return localBluetoothServerSocket;
  }
  
  /* Error */
  public static BluetoothAdapter getDefaultAdapter()
  {
    // Byte code:
    //   0: ldc 2
    //   2: monitorenter
    //   3: getstatic 215	android/bluetooth/BluetoothAdapter:sAdapter	Landroid/bluetooth/BluetoothAdapter;
    //   6: ifnonnull +27 -> 33
    //   9: ldc 35
    //   11: invokestatic 221	android/os/ServiceManager:getService	(Ljava/lang/String;)Landroid/os/IBinder;
    //   14: astore_2
    //   15: aload_2
    //   16: ifnull +26 -> 42
    //   19: new 2	android/bluetooth/BluetoothAdapter
    //   22: dup
    //   23: aload_2
    //   24: invokestatic 227	android/bluetooth/IBluetoothManager$Stub:asInterface	(Landroid/os/IBinder;)Landroid/bluetooth/IBluetoothManager;
    //   27: invokespecial 229	android/bluetooth/BluetoothAdapter:<init>	(Landroid/bluetooth/IBluetoothManager;)V
    //   30: putstatic 215	android/bluetooth/BluetoothAdapter:sAdapter	Landroid/bluetooth/BluetoothAdapter;
    //   33: getstatic 215	android/bluetooth/BluetoothAdapter:sAdapter	Landroid/bluetooth/BluetoothAdapter;
    //   36: astore_1
    //   37: ldc 2
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: ldc 88
    //   44: ldc -25
    //   46: invokestatic 234	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   49: pop
    //   50: goto -17 -> 33
    //   53: astore_0
    //   54: ldc 2
    //   56: monitorexit
    //   57: aload_0
    //   58: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   53	5	0	localObject	Object
    //   36	5	1	localBluetoothAdapter	BluetoothAdapter
    //   14	10	2	localIBinder	android.os.IBinder
    // Exception table:
    //   from	to	target	type
    //   3	15	53	finally
    //   19	33	53	finally
    //   33	37	53	finally
    //   42	50	53	finally
  }
  
  public static BluetoothServerSocket listenUsingScoOn()
    throws IOException
  {
    BluetoothServerSocket localBluetoothServerSocket = new BluetoothServerSocket(2, false, false, -1);
    if (localBluetoothServerSocket.mSocket.bindListen() < 0) {}
    return localBluetoothServerSocket;
  }
  
  private Set<BluetoothDevice> toDeviceSet(BluetoothDevice[] paramArrayOfBluetoothDevice)
  {
    return Collections.unmodifiableSet(new HashSet(Arrays.asList(paramArrayOfBluetoothDevice)));
  }
  
  public boolean cancelDiscovery()
  {
    if (getState() != 12) {
      return false;
    }
    try
    {
      synchronized (this.mManagerCallback)
      {
        if (this.mService != null)
        {
          boolean bool = this.mService.cancelDiscovery();
          return bool;
        }
        return false;
      }
      return false;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
    }
  }
  
  public boolean changeApplicationBluetoothState(boolean paramBoolean, BluetoothStateChangeCallback paramBluetoothStateChangeCallback)
  {
    if (paramBluetoothStateChangeCallback == null) {}
    return false;
  }
  
  public void closeProfileProxy(int paramInt, BluetoothProfile paramBluetoothProfile)
  {
    if (paramBluetoothProfile == null) {
      return;
    }
    switch (paramInt)
    {
    default: 
      return;
    case 1: 
      ((BluetoothHeadset)paramBluetoothProfile).close();
      return;
    case 2: 
      ((BluetoothA2dp)paramBluetoothProfile).close();
      return;
    case 4: 
      ((BluetoothInputDevice)paramBluetoothProfile).close();
      return;
    case 5: 
      ((BluetoothPan)paramBluetoothProfile).close();
      return;
    }
    ((BluetoothHealth)paramBluetoothProfile).close();
  }
  
  public boolean disable()
  {
    try
    {
      boolean bool = this.mManagerService.disable(true);
      return bool;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
    }
    return false;
  }
  
  public boolean disable(boolean paramBoolean)
  {
    try
    {
      boolean bool = this.mManagerService.disable(paramBoolean);
      return bool;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
    }
    return false;
  }
  
  public boolean enable()
  {
    if (isEnabled() == true)
    {
      Log.d("BluetoothAdapter", "enable(): BT is already enabled..!");
      return true;
    }
    try
    {
      boolean bool = this.mManagerService.enable();
      return bool;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
    }
    return false;
  }
  
  public boolean enableNoAutoConnect()
  {
    if (isEnabled() == true)
    {
      Log.d("BluetoothAdapter", "enableNoAutoConnect(): BT is already enabled..!");
      return true;
    }
    try
    {
      boolean bool = this.mManagerService.enableNoAutoConnect();
      return bool;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
    }
    return false;
  }
  
  protected void finalize()
    throws Throwable
  {
    try
    {
      this.mManagerService.unregisterAdapter(this.mManagerCallback);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      for (;;)
      {
        Log.e("BluetoothAdapter", "", localRemoteException);
      }
    }
    finally
    {
      super.finalize();
    }
  }
  
  public String getAddress()
  {
    try
    {
      String str = this.mManagerService.getAddress();
      return str;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
    }
    return null;
  }
  
  IBluetoothManager getBluetoothManager()
  {
    return this.mManagerService;
  }
  
  IBluetooth getBluetoothService(IBluetoothManagerCallback paramIBluetoothManagerCallback)
  {
    localIBluetoothManagerCallback = this.mManagerCallback;
    if (paramIBluetoothManagerCallback == null) {}
    for (;;)
    {
      try
      {
        Log.w("BluetoothAdapter", "getBluetoothService() called with no BluetoothManagerCallback");
        return this.mService;
      }
      finally {}
      if (!this.mProxyServiceStateCallbacks.contains(paramIBluetoothManagerCallback)) {
        this.mProxyServiceStateCallbacks.add(paramIBluetoothManagerCallback);
      }
    }
  }
  
  public Set<BluetoothDevice> getBondedDevices()
  {
    if (getState() != 12) {
      return toDeviceSet(new BluetoothDevice[0]);
    }
    try
    {
      synchronized (this.mManagerCallback)
      {
        if (this.mService != null)
        {
          Set localSet2 = toDeviceSet(this.mService.getBondedDevices());
          return localSet2;
        }
      }
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
      return null;
    }
    Set localSet1 = toDeviceSet(new BluetoothDevice[0]);
    return localSet1;
  }
  
  public int getConnectionState()
  {
    if (getState() != 12) {
      return 0;
    }
    try
    {
      synchronized (this.mManagerCallback)
      {
        if (this.mService != null)
        {
          int i = this.mService.getAdapterConnectionState();
          return i;
        }
        return 0;
      }
      return 0;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "getConnectionState:", localRemoteException);
    }
  }
  
  public int getDiscoverableTimeout()
  {
    if (getState() != 12) {
      return -1;
    }
    try
    {
      synchronized (this.mManagerCallback)
      {
        if (this.mService != null)
        {
          int i = this.mService.getDiscoverableTimeout();
          return i;
        }
        return -1;
      }
      return -1;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
    }
  }
  
  public String getName()
  {
    try
    {
      String str = this.mManagerService.getName();
      return str;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
    }
    return null;
  }
  
  public int getProfileConnectionState(int paramInt)
  {
    if (getState() != 12) {
      return 0;
    }
    try
    {
      synchronized (this.mManagerCallback)
      {
        if (this.mService != null)
        {
          int i = this.mService.getProfileConnectionState(paramInt);
          return i;
        }
        return 0;
      }
      return 0;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "getProfileConnectionState:", localRemoteException);
    }
  }
  
  public boolean getProfileProxy(Context paramContext, BluetoothProfile.ServiceListener paramServiceListener, int paramInt)
  {
    if ((paramContext == null) || (paramServiceListener == null)) {
      return false;
    }
    if (paramInt == 1)
    {
      new BluetoothHeadset(paramContext, paramServiceListener);
      return true;
    }
    if (paramInt == 2)
    {
      new BluetoothA2dp(paramContext, paramServiceListener);
      return true;
    }
    if (paramInt == 4)
    {
      new BluetoothInputDevice(paramContext, paramServiceListener);
      return true;
    }
    if (paramInt == 5)
    {
      new BluetoothPan(paramContext, paramServiceListener);
      return true;
    }
    if (paramInt == 3)
    {
      new BluetoothHealth(paramContext, paramServiceListener);
      return true;
    }
    return false;
  }
  
  public BluetoothDevice getRemoteDevice(String paramString)
  {
    return new BluetoothDevice(paramString);
  }
  
  public BluetoothDevice getRemoteDevice(byte[] paramArrayOfByte)
  {
    if ((paramArrayOfByte == null) || (paramArrayOfByte.length != 6)) {
      throw new IllegalArgumentException("Bluetooth address must have 6 bytes");
    }
    Object[] arrayOfObject = new Object[6];
    arrayOfObject[0] = Byte.valueOf(paramArrayOfByte[0]);
    arrayOfObject[1] = Byte.valueOf(paramArrayOfByte[1]);
    arrayOfObject[2] = Byte.valueOf(paramArrayOfByte[2]);
    arrayOfObject[3] = Byte.valueOf(paramArrayOfByte[3]);
    arrayOfObject[4] = Byte.valueOf(paramArrayOfByte[4]);
    arrayOfObject[5] = Byte.valueOf(paramArrayOfByte[5]);
    return new BluetoothDevice(String.format("%02X:%02X:%02X:%02X:%02X:%02X", arrayOfObject));
  }
  
  public int getScanMode()
  {
    if (getState() != 12) {
      return 20;
    }
    try
    {
      synchronized (this.mManagerCallback)
      {
        if (this.mService != null)
        {
          int i = this.mService.getScanMode();
          return i;
        }
        return 20;
      }
      return 20;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
    }
  }
  
  /* Error */
  public int getState()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 116	android/bluetooth/BluetoothAdapter:mManagerCallback	Landroid/bluetooth/IBluetoothManagerCallback;
    //   4: astore 4
    //   6: aload 4
    //   8: monitorenter
    //   9: aload_0
    //   10: getfield 136	android/bluetooth/BluetoothAdapter:mService	Landroid/bluetooth/IBluetooth;
    //   13: ifnull +20 -> 33
    //   16: aload_0
    //   17: getfield 136	android/bluetooth/BluetoothAdapter:mService	Landroid/bluetooth/IBluetooth;
    //   20: invokeinterface 393 1 0
    //   25: istore 6
    //   27: aload 4
    //   29: monitorexit
    //   30: iload 6
    //   32: ireturn
    //   33: aload 4
    //   35: monitorexit
    //   36: ldc 88
    //   38: new 196	java/lang/StringBuilder
    //   41: dup
    //   42: invokespecial 197	java/lang/StringBuilder:<init>	()V
    //   45: ldc -114
    //   47: invokevirtual 203	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   50: aload_0
    //   51: invokevirtual 396	java/lang/Object:hashCode	()I
    //   54: invokevirtual 206	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   57: ldc_w 398
    //   60: invokevirtual 203	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   63: invokevirtual 210	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   66: invokestatic 301	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   69: pop
    //   70: bipush 10
    //   72: ireturn
    //   73: astore 5
    //   75: aload 4
    //   77: monitorexit
    //   78: aload 5
    //   80: athrow
    //   81: astore_1
    //   82: ldc 88
    //   84: ldc -114
    //   86: aload_1
    //   87: invokestatic 148	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   90: pop
    //   91: goto -55 -> 36
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	94	0	this	BluetoothAdapter
    //   81	6	1	localRemoteException	RemoteException
    //   73	6	5	localObject	Object
    //   25	6	6	i	int
    // Exception table:
    //   from	to	target	type
    //   9	30	73	finally
    //   33	36	73	finally
    //   75	78	73	finally
    //   0	9	81	android/os/RemoteException
    //   78	81	81	android/os/RemoteException
  }
  
  public ParcelUuid[] getUuids()
  {
    if (getState() != 12) {
      return null;
    }
    try
    {
      synchronized (this.mManagerCallback)
      {
        if (this.mService != null)
        {
          ParcelUuid[] arrayOfParcelUuid = this.mService.getUuids();
          return arrayOfParcelUuid;
        }
        return null;
      }
      return null;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
    }
  }
  
  public boolean isDiscovering()
  {
    if (getState() != 12) {
      return false;
    }
    try
    {
      synchronized (this.mManagerCallback)
      {
        if (this.mService != null)
        {
          boolean bool = this.mService.isDiscovering();
          return bool;
        }
        return false;
      }
      return false;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
    }
  }
  
  public boolean isEnabled()
  {
    try
    {
      synchronized (this.mManagerCallback)
      {
        if (this.mService != null)
        {
          boolean bool = this.mService.isEnabled();
          return bool;
        }
      }
      return false;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
    }
  }
  
  public BluetoothServerSocket listenUsingEncryptedRfcommOn(int paramInt)
    throws IOException
  {
    BluetoothServerSocket localBluetoothServerSocket = new BluetoothServerSocket(1, false, true, paramInt);
    int i = localBluetoothServerSocket.mSocket.bindListen();
    if (i < 0) {
      throw new IOException("Error: " + i);
    }
    return localBluetoothServerSocket;
  }
  
  public BluetoothServerSocket listenUsingEncryptedRfcommWithServiceRecord(String paramString, UUID paramUUID)
    throws IOException
  {
    return createNewRfcommSocketAndRecord(paramString, paramUUID, false, true);
  }
  
  public BluetoothServerSocket listenUsingInsecureRfcommOn(int paramInt)
    throws IOException
  {
    BluetoothServerSocket localBluetoothServerSocket = new BluetoothServerSocket(1, false, false, paramInt);
    int i = localBluetoothServerSocket.mSocket.bindListen();
    if (i != 0) {
      throw new IOException("Error: " + i);
    }
    return localBluetoothServerSocket;
  }
  
  public BluetoothServerSocket listenUsingInsecureRfcommWithServiceRecord(String paramString, UUID paramUUID)
    throws IOException
  {
    return createNewRfcommSocketAndRecord(paramString, paramUUID, false, false);
  }
  
  public BluetoothServerSocket listenUsingRfcommOn(int paramInt)
    throws IOException
  {
    BluetoothServerSocket localBluetoothServerSocket = new BluetoothServerSocket(1, true, true, paramInt);
    int i = localBluetoothServerSocket.mSocket.bindListen();
    if (i != 0) {
      throw new IOException("Error: " + i);
    }
    return localBluetoothServerSocket;
  }
  
  public BluetoothServerSocket listenUsingRfcommWithServiceRecord(String paramString, UUID paramUUID)
    throws IOException
  {
    return createNewRfcommSocketAndRecord(paramString, paramUUID, true, true);
  }
  
  public Pair<byte[], byte[]> readOutOfBandData()
  {
    if (getState() != 12) {}
    return null;
  }
  
  void removeServiceStateCallback(IBluetoothManagerCallback paramIBluetoothManagerCallback)
  {
    synchronized (this.mManagerCallback)
    {
      this.mProxyServiceStateCallbacks.remove(paramIBluetoothManagerCallback);
      return;
    }
  }
  
  public void setDiscoverableTimeout(int paramInt)
  {
    if (getState() != 12) {
      return;
    }
    try
    {
      synchronized (this.mManagerCallback)
      {
        if (this.mService != null) {
          this.mService.setDiscoverableTimeout(paramInt);
        }
        return;
      }
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
    }
  }
  
  public boolean setName(String paramString)
  {
    if (getState() != 12) {
      return false;
    }
    try
    {
      synchronized (this.mManagerCallback)
      {
        if (this.mService != null)
        {
          boolean bool = this.mService.setName(paramString);
          return bool;
        }
        return false;
      }
      return false;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
    }
  }
  
  public boolean setScanMode(int paramInt)
  {
    if (getState() != 12) {
      return false;
    }
    return setScanMode(paramInt, getDiscoverableTimeout());
  }
  
  public boolean setScanMode(int paramInt1, int paramInt2)
  {
    if (getState() != 12) {
      return false;
    }
    try
    {
      synchronized (this.mManagerCallback)
      {
        if (this.mService != null)
        {
          boolean bool = this.mService.setScanMode(paramInt1, paramInt2);
          return bool;
        }
        return false;
      }
      return false;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
    }
  }
  
  public boolean startDiscovery()
  {
    if (getState() != 12) {
      return false;
    }
    try
    {
      synchronized (this.mManagerCallback)
      {
        if (this.mService != null)
        {
          boolean bool = this.mService.startDiscovery();
          return bool;
        }
        return false;
      }
      return false;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothAdapter", "", localRemoteException);
    }
  }
  
  public static abstract interface BluetoothStateChangeCallback
  {
    public abstract void onBluetoothStateChange(boolean paramBoolean);
  }
  
  public class StateChangeCallbackWrapper
    extends IBluetoothStateChangeCallback.Stub
  {
    private BluetoothAdapter.BluetoothStateChangeCallback mCallback;
    
    StateChangeCallbackWrapper(BluetoothAdapter.BluetoothStateChangeCallback paramBluetoothStateChangeCallback)
    {
      this.mCallback = paramBluetoothStateChangeCallback;
    }
    
    public void onBluetoothStateChange(boolean paramBoolean)
    {
      this.mCallback.onBluetoothStateChange(paramBoolean);
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\bluetooth\BluetoothAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
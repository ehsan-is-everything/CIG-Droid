package android.bluetooth;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.res.Resources;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;

public final class BluetoothHeadset
  implements BluetoothProfile
{
  public static final String ACTION_AUDIO_STATE_CHANGED = "android.bluetooth.headset.profile.action.AUDIO_STATE_CHANGED";
  public static final String ACTION_CONNECTION_STATE_CHANGED = "android.bluetooth.headset.profile.action.CONNECTION_STATE_CHANGED";
  public static final String ACTION_VENDOR_SPECIFIC_HEADSET_EVENT = "android.bluetooth.headset.action.VENDOR_SPECIFIC_HEADSET_EVENT";
  public static final int AT_CMD_TYPE_ACTION = 4;
  public static final int AT_CMD_TYPE_BASIC = 3;
  public static final int AT_CMD_TYPE_READ = 0;
  public static final int AT_CMD_TYPE_SET = 2;
  public static final int AT_CMD_TYPE_TEST = 1;
  private static final boolean DBG = true;
  public static final String EXTRA_VENDOR_SPECIFIC_HEADSET_EVENT_ARGS = "android.bluetooth.headset.extra.VENDOR_SPECIFIC_HEADSET_EVENT_ARGS";
  public static final String EXTRA_VENDOR_SPECIFIC_HEADSET_EVENT_CMD = "android.bluetooth.headset.extra.VENDOR_SPECIFIC_HEADSET_EVENT_CMD";
  public static final String EXTRA_VENDOR_SPECIFIC_HEADSET_EVENT_CMD_TYPE = "android.bluetooth.headset.extra.VENDOR_SPECIFIC_HEADSET_EVENT_CMD_TYPE";
  public static final int STATE_AUDIO_CONNECTED = 12;
  public static final int STATE_AUDIO_CONNECTING = 11;
  public static final int STATE_AUDIO_DISCONNECTED = 10;
  private static final String TAG = "BluetoothHeadset";
  private static final boolean VDBG = false;
  public static final String VENDOR_SPECIFIC_HEADSET_EVENT_COMPANY_ID_CATEGORY = "android.bluetooth.headset.intent.category.companyid";
  private BluetoothAdapter mAdapter;
  private final IBluetoothStateChangeCallback mBluetoothStateChangeCallback = new IBluetoothStateChangeCallback.Stub()
  {
    public void onBluetoothStateChange(boolean paramAnonymousBoolean)
    {
      Log.d("BluetoothHeadset", "onBluetoothStateChange: up=" + paramAnonymousBoolean);
      if (!paramAnonymousBoolean) {
        synchronized (BluetoothHeadset.this.mConnection)
        {
          try
          {
            BluetoothHeadset.access$102(BluetoothHeadset.this, null);
            BluetoothHeadset.this.mContext.unbindService(BluetoothHeadset.this.mConnection);
            return;
          }
          catch (Exception localException2)
          {
            for (;;)
            {
              Log.e("BluetoothHeadset", "", localException2);
            }
          }
        }
      }
      try
      {
        synchronized (BluetoothHeadset.this.mConnection)
        {
          if ((BluetoothHeadset.this.mService == null) && (!BluetoothHeadset.this.mContext.bindService(new Intent(IBluetoothHeadset.class.getName()), BluetoothHeadset.this.mConnection, 0))) {
            Log.e("BluetoothHeadset", "Could not bind to Bluetooth Headset Service");
          }
          return;
        }
      }
      catch (Exception localException1)
      {
        for (;;)
        {
          Log.e("BluetoothHeadset", "", localException1);
        }
      }
    }
  };
  private ServiceConnection mConnection = new ServiceConnection()
  {
    public void onServiceConnected(ComponentName paramAnonymousComponentName, IBinder paramAnonymousIBinder)
    {
      Log.d("BluetoothHeadset", "Proxy object connected");
      BluetoothHeadset.access$102(BluetoothHeadset.this, IBluetoothHeadset.Stub.asInterface(paramAnonymousIBinder));
      if (BluetoothHeadset.this.mServiceListener != null) {
        BluetoothHeadset.this.mServiceListener.onServiceConnected(1, BluetoothHeadset.this);
      }
    }
    
    public void onServiceDisconnected(ComponentName paramAnonymousComponentName)
    {
      Log.d("BluetoothHeadset", "Proxy object disconnected");
      BluetoothHeadset.access$102(BluetoothHeadset.this, null);
      if (BluetoothHeadset.this.mServiceListener != null) {
        BluetoothHeadset.this.mServiceListener.onServiceDisconnected(1);
      }
    }
  };
  private Context mContext;
  private IBluetoothHeadset mService;
  private BluetoothProfile.ServiceListener mServiceListener;
  
  BluetoothHeadset(Context paramContext, BluetoothProfile.ServiceListener paramServiceListener)
  {
    this.mContext = paramContext;
    this.mServiceListener = paramServiceListener;
    this.mAdapter = BluetoothAdapter.getDefaultAdapter();
    IBluetoothManager localIBluetoothManager = this.mAdapter.getBluetoothManager();
    if (localIBluetoothManager != null) {}
    try
    {
      localIBluetoothManager.registerStateChangeCallback(this.mBluetoothStateChangeCallback);
      if (!paramContext.bindService(new Intent(IBluetoothHeadset.class.getName()), this.mConnection, 0)) {
        Log.e("BluetoothHeadset", "Could not bind to Bluetooth Headset Service");
      }
      return;
    }
    catch (RemoteException localRemoteException)
    {
      for (;;)
      {
        Log.e("BluetoothHeadset", "", localRemoteException);
      }
    }
  }
  
  public static boolean isBluetoothVoiceDialingEnabled(Context paramContext)
  {
    return paramContext.getResources().getBoolean(17891372);
  }
  
  private boolean isDisabled()
  {
    return this.mAdapter.getState() == 10;
  }
  
  private boolean isEnabled()
  {
    return this.mAdapter.getState() == 12;
  }
  
  private boolean isValidDevice(BluetoothDevice paramBluetoothDevice)
  {
    if (paramBluetoothDevice == null) {}
    while (!BluetoothAdapter.checkBluetoothAddress(paramBluetoothDevice.getAddress())) {
      return false;
    }
    return true;
  }
  
  private static void log(String paramString)
  {
    Log.d("BluetoothHeadset", paramString);
  }
  
  public boolean acceptIncomingConnect(BluetoothDevice paramBluetoothDevice)
  {
    log("acceptIncomingConnect");
    if ((this.mService != null) && (isEnabled())) {
      try
      {
        boolean bool = this.mService.acceptIncomingConnect(paramBluetoothDevice);
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", localRemoteException.toString());
      }
    }
    for (;;)
    {
      return false;
      Log.w("BluetoothHeadset", "Proxy not attached to service");
      Log.d("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
    }
  }
  
  public void clccResponse(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean, String paramString, int paramInt5)
  {
    if ((this.mService != null) && (isEnabled())) {
      try
      {
        this.mService.clccResponse(paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean, paramString, paramInt5);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", localRemoteException.toString());
        return;
      }
    }
    Log.w("BluetoothHeadset", "Proxy not attached to service");
    Log.d("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
  }
  
  void close()
  {
    IBluetoothManager localIBluetoothManager = this.mAdapter.getBluetoothManager();
    if (localIBluetoothManager != null) {}
    try
    {
      localIBluetoothManager.unregisterStateChangeCallback(this.mBluetoothStateChangeCallback);
    }
    catch (Exception localException2)
    {
      synchronized (this.mConnection)
      {
        for (;;)
        {
          IBluetoothHeadset localIBluetoothHeadset = this.mService;
          if (localIBluetoothHeadset != null) {}
          try
          {
            this.mService = null;
            this.mContext.unbindService(this.mConnection);
            this.mServiceListener = null;
            return;
            localException2 = localException2;
            Log.e("BluetoothHeadset", "", localException2);
          }
          catch (Exception localException1)
          {
            for (;;)
            {
              Log.e("BluetoothHeadset", "", localException1);
            }
          }
        }
      }
    }
  }
  
  public boolean connect(BluetoothDevice paramBluetoothDevice)
  {
    log("connect(" + paramBluetoothDevice + ")");
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {}
    IBluetoothHeadset localIBluetoothHeadset;
    do
    {
      try
      {
        boolean bool2 = this.mService.connect(paramBluetoothDevice);
        bool1 = bool2;
        return bool1;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
        return false;
      }
      localIBluetoothHeadset = this.mService;
      boolean bool1 = false;
    } while (localIBluetoothHeadset != null);
    Log.w("BluetoothHeadset", "Proxy not attached to service");
    return false;
  }
  
  public boolean connectAudio()
  {
    if ((this.mService != null) && (isEnabled())) {
      try
      {
        boolean bool = this.mService.connectAudio();
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", localRemoteException.toString());
      }
    }
    for (;;)
    {
      return false;
      Log.w("BluetoothHeadset", "Proxy not attached to service");
      Log.d("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
    }
  }
  
  public boolean disconnect(BluetoothDevice paramBluetoothDevice)
  {
    log("disconnect(" + paramBluetoothDevice + ")");
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {}
    IBluetoothHeadset localIBluetoothHeadset;
    do
    {
      try
      {
        boolean bool2 = this.mService.disconnect(paramBluetoothDevice);
        bool1 = bool2;
        return bool1;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
        return false;
      }
      localIBluetoothHeadset = this.mService;
      boolean bool1 = false;
    } while (localIBluetoothHeadset != null);
    Log.w("BluetoothHeadset", "Proxy not attached to service");
    return false;
  }
  
  public boolean disconnectAudio()
  {
    if ((this.mService != null) && (isEnabled())) {
      try
      {
        boolean bool = this.mService.disconnectAudio();
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", localRemoteException.toString());
      }
    }
    for (;;)
    {
      return false;
      Log.w("BluetoothHeadset", "Proxy not attached to service");
      Log.d("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
    }
  }
  
  public int getAudioState(BluetoothDevice paramBluetoothDevice)
  {
    if ((this.mService != null) && (!isDisabled())) {
      try
      {
        int i = this.mService.getAudioState(paramBluetoothDevice);
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", localRemoteException.toString());
      }
    }
    for (;;)
    {
      return 10;
      Log.w("BluetoothHeadset", "Proxy not attached to service");
      Log.d("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
    }
  }
  
  public int getBatteryUsageHint(BluetoothDevice paramBluetoothDevice)
  {
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {
      try
      {
        int i = this.mService.getBatteryUsageHint(paramBluetoothDevice);
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
      }
    }
    if (this.mService == null) {
      Log.w("BluetoothHeadset", "Proxy not attached to service");
    }
    return -1;
  }
  
  public List<BluetoothDevice> getConnectedDevices()
  {
    if ((this.mService != null) && (isEnabled())) {
      try
      {
        List localList = this.mService.getConnectedDevices();
        return localList;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
        return new ArrayList();
      }
    }
    if (this.mService == null) {
      Log.w("BluetoothHeadset", "Proxy not attached to service");
    }
    return new ArrayList();
  }
  
  public int getConnectionState(BluetoothDevice paramBluetoothDevice)
  {
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {}
    IBluetoothHeadset localIBluetoothHeadset;
    do
    {
      try
      {
        int j = this.mService.getConnectionState(paramBluetoothDevice);
        i = j;
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
        return 0;
      }
      localIBluetoothHeadset = this.mService;
      int i = 0;
    } while (localIBluetoothHeadset != null);
    Log.w("BluetoothHeadset", "Proxy not attached to service");
    return 0;
  }
  
  public List<BluetoothDevice> getDevicesMatchingConnectionStates(int[] paramArrayOfInt)
  {
    if ((this.mService != null) && (isEnabled())) {
      try
      {
        List localList = this.mService.getDevicesMatchingConnectionStates(paramArrayOfInt);
        return localList;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
        return new ArrayList();
      }
    }
    if (this.mService == null) {
      Log.w("BluetoothHeadset", "Proxy not attached to service");
    }
    return new ArrayList();
  }
  
  public int getPriority(BluetoothDevice paramBluetoothDevice)
  {
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {}
    IBluetoothHeadset localIBluetoothHeadset;
    do
    {
      try
      {
        int j = this.mService.getPriority(paramBluetoothDevice);
        i = j;
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
        return 0;
      }
      localIBluetoothHeadset = this.mService;
      int i = 0;
    } while (localIBluetoothHeadset != null);
    Log.w("BluetoothHeadset", "Proxy not attached to service");
    return 0;
  }
  
  public boolean isAudioConnected(BluetoothDevice paramBluetoothDevice)
  {
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {
      try
      {
        boolean bool = this.mService.isAudioConnected(paramBluetoothDevice);
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
      }
    }
    if (this.mService == null) {
      Log.w("BluetoothHeadset", "Proxy not attached to service");
    }
    return false;
  }
  
  public boolean isAudioOn()
  {
    if ((this.mService != null) && (isEnabled())) {
      try
      {
        boolean bool = this.mService.isAudioOn();
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
      }
    }
    if (this.mService == null) {
      Log.w("BluetoothHeadset", "Proxy not attached to service");
    }
    return false;
  }
  
  public void phoneStateChanged(int paramInt1, int paramInt2, int paramInt3, String paramString, int paramInt4)
  {
    if ((this.mService != null) && (isEnabled())) {
      try
      {
        this.mService.phoneStateChanged(paramInt1, paramInt2, paramInt3, paramString, paramInt4);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", localRemoteException.toString());
        return;
      }
    }
    Log.w("BluetoothHeadset", "Proxy not attached to service");
    Log.d("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
  }
  
  public boolean rejectIncomingConnect(BluetoothDevice paramBluetoothDevice)
  {
    log("rejectIncomingConnect");
    if (this.mService != null) {
      try
      {
        boolean bool = this.mService.rejectIncomingConnect(paramBluetoothDevice);
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", localRemoteException.toString());
      }
    }
    for (;;)
    {
      return false;
      Log.w("BluetoothHeadset", "Proxy not attached to service");
      Log.d("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
    }
  }
  
  public void roamChanged(boolean paramBoolean)
  {
    if ((this.mService != null) && (isEnabled())) {
      try
      {
        this.mService.roamChanged(paramBoolean);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", localRemoteException.toString());
        return;
      }
    }
    Log.w("BluetoothHeadset", "Proxy not attached to service");
    Log.d("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
  }
  
  public boolean setPriority(BluetoothDevice paramBluetoothDevice, int paramInt)
  {
    log("setPriority(" + paramBluetoothDevice + ", " + paramInt + ")");
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {
      if ((paramInt == 0) || (paramInt == 100)) {}
    }
    while (this.mService != null)
    {
      return false;
      try
      {
        boolean bool = this.mService.setPriority(paramBluetoothDevice, paramInt);
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
        return false;
      }
    }
    Log.w("BluetoothHeadset", "Proxy not attached to service");
    return false;
  }
  
  public boolean startScoUsingVirtualVoiceCall(BluetoothDevice paramBluetoothDevice)
  {
    log("startScoUsingVirtualVoiceCall()");
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {
      try
      {
        boolean bool = this.mService.startScoUsingVirtualVoiceCall(paramBluetoothDevice);
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", localRemoteException.toString());
      }
    }
    for (;;)
    {
      return false;
      Log.w("BluetoothHeadset", "Proxy not attached to service");
      Log.d("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
    }
  }
  
  public boolean startVoiceRecognition(BluetoothDevice paramBluetoothDevice)
  {
    log("startVoiceRecognition()");
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {
      try
      {
        boolean bool = this.mService.startVoiceRecognition(paramBluetoothDevice);
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
      }
    }
    if (this.mService == null) {
      Log.w("BluetoothHeadset", "Proxy not attached to service");
    }
    return false;
  }
  
  public boolean stopScoUsingVirtualVoiceCall(BluetoothDevice paramBluetoothDevice)
  {
    log("stopScoUsingVirtualVoiceCall()");
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {
      try
      {
        boolean bool = this.mService.stopScoUsingVirtualVoiceCall(paramBluetoothDevice);
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", localRemoteException.toString());
      }
    }
    for (;;)
    {
      return false;
      Log.w("BluetoothHeadset", "Proxy not attached to service");
      Log.d("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
    }
  }
  
  public boolean stopVoiceRecognition(BluetoothDevice paramBluetoothDevice)
  {
    log("stopVoiceRecognition()");
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {
      try
      {
        boolean bool = this.mService.stopVoiceRecognition(paramBluetoothDevice);
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothHeadset", Log.getStackTraceString(new Throwable()));
      }
    }
    if (this.mService == null) {
      Log.w("BluetoothHeadset", "Proxy not attached to service");
    }
    return false;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\bluetooth\BluetoothHeadset.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
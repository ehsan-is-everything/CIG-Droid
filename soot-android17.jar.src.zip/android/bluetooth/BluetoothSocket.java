package android.bluetooth;

import android.net.LocalSocket;
import android.os.ParcelFileDescriptor;
import android.os.ParcelUuid;
import android.os.RemoteException;
import android.util.Log;
import java.io.Closeable;
import java.io.FileDescriptor;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.UUID;

public final class BluetoothSocket
  implements Closeable
{
  private static final boolean DBG = true;
  static final int EADDRINUSE = 98;
  static final int EBADFD = 77;
  public static final int MAX_RFCOMM_CHANNEL = 30;
  private static int PROXY_CONNECTION_TIMEOUT = 5000;
  static final int SEC_FLAG_AUTH = 2;
  static final int SEC_FLAG_ENCRYPT = 1;
  private static int SOCK_SIGNAL_SIZE = 16;
  private static final String TAG = "BluetoothSocket";
  static final int TYPE_L2CAP = 3;
  static final int TYPE_RFCOMM = 1;
  static final int TYPE_SCO = 2;
  private static final boolean VDBG;
  private String mAddress;
  private final boolean mAuth;
  private BluetoothDevice mDevice;
  private final boolean mEncrypt;
  private int mFd;
  private final BluetoothInputStream mInputStream;
  private final BluetoothOutputStream mOutputStream;
  private ParcelFileDescriptor mPfd;
  private int mPort;
  private String mServiceName;
  private LocalSocket mSocket;
  private InputStream mSocketIS;
  private OutputStream mSocketOS;
  private volatile SocketState mSocketState;
  private final int mType;
  private final ParcelUuid mUuid;
  
  BluetoothSocket(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, BluetoothDevice paramBluetoothDevice, int paramInt3, ParcelUuid paramParcelUuid)
    throws IOException
  {
    if ((paramInt1 == 1) && (paramParcelUuid == null) && (paramInt2 == -1) && ((paramInt3 < 1) || (paramInt3 > 30))) {
      throw new IOException("Invalid RFCOMM channel: " + paramInt3);
    }
    if (paramParcelUuid != null)
    {
      this.mUuid = paramParcelUuid;
      this.mType = paramInt1;
      this.mAuth = paramBoolean1;
      this.mEncrypt = paramBoolean2;
      this.mDevice = paramBluetoothDevice;
      this.mPort = paramInt3;
      this.mFd = paramInt2;
      this.mSocketState = SocketState.INIT;
      if (paramBluetoothDevice != null) {
        break label174;
      }
    }
    label174:
    for (this.mAddress = BluetoothAdapter.getDefaultAdapter().getAddress();; this.mAddress = paramBluetoothDevice.getAddress())
    {
      this.mInputStream = new BluetoothInputStream(this);
      this.mOutputStream = new BluetoothOutputStream(this);
      return;
      this.mUuid = new ParcelUuid(new UUID(0L, 0L));
      break;
    }
  }
  
  private BluetoothSocket(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, String paramString, int paramInt3)
    throws IOException
  {
    this(paramInt1, paramInt2, paramBoolean1, paramBoolean2, new BluetoothDevice(paramString), paramInt3, null);
  }
  
  private BluetoothSocket(BluetoothSocket paramBluetoothSocket)
  {
    this.mUuid = paramBluetoothSocket.mUuid;
    this.mType = paramBluetoothSocket.mType;
    this.mAuth = paramBluetoothSocket.mAuth;
    this.mEncrypt = paramBluetoothSocket.mEncrypt;
    this.mPort = paramBluetoothSocket.mPort;
    this.mInputStream = new BluetoothInputStream(this);
    this.mOutputStream = new BluetoothOutputStream(this);
    this.mServiceName = paramBluetoothSocket.mServiceName;
  }
  
  private BluetoothSocket acceptSocket(String paramString)
    throws IOException
  {
    BluetoothSocket localBluetoothSocket = new BluetoothSocket(this);
    localBluetoothSocket.mSocketState = SocketState.CONNECTED;
    FileDescriptor[] arrayOfFileDescriptor = this.mSocket.getAncillaryFileDescriptors();
    if ((arrayOfFileDescriptor == null) || (arrayOfFileDescriptor.length != 1))
    {
      Log.e("BluetoothSocket", "socket fd passed from stack failed, fds: " + arrayOfFileDescriptor);
      throw new IOException("bt socket acept failed");
    }
    localBluetoothSocket.mSocket = new LocalSocket(arrayOfFileDescriptor[0]);
    localBluetoothSocket.mSocketIS = localBluetoothSocket.mSocket.getInputStream();
    localBluetoothSocket.mSocketOS = localBluetoothSocket.mSocket.getOutputStream();
    localBluetoothSocket.mAddress = paramString;
    localBluetoothSocket.mDevice = BluetoothAdapter.getDefaultAdapter().getRemoteDevice(paramString);
    return localBluetoothSocket;
  }
  
  private String convertAddr(byte[] paramArrayOfByte)
  {
    Object[] arrayOfObject = new Object[6];
    arrayOfObject[0] = Byte.valueOf(paramArrayOfByte[0]);
    arrayOfObject[1] = Byte.valueOf(paramArrayOfByte[1]);
    arrayOfObject[2] = Byte.valueOf(paramArrayOfByte[2]);
    arrayOfObject[3] = Byte.valueOf(paramArrayOfByte[3]);
    arrayOfObject[4] = Byte.valueOf(paramArrayOfByte[4]);
    arrayOfObject[5] = Byte.valueOf(paramArrayOfByte[5]);
    return String.format("%02X:%02X:%02X:%02X:%02X:%02X", arrayOfObject);
  }
  
  private int getSecurityFlags()
  {
    boolean bool = this.mAuth;
    int i = 0;
    if (bool) {
      i = 0x0 | 0x2;
    }
    if (this.mEncrypt) {
      i |= 0x1;
    }
    return i;
  }
  
  private int readAll(InputStream paramInputStream, byte[] paramArrayOfByte)
    throws IOException
  {
    int i = paramArrayOfByte.length;
    while (i > 0)
    {
      int j = paramInputStream.read(paramArrayOfByte, paramArrayOfByte.length - i, i);
      if (j <= 0) {
        throw new IOException("read failed, socket might closed, read ret: " + j);
      }
      i -= j;
      if (i != 0) {
        Log.w("BluetoothSocket", "readAll() looping, read partial size: " + (paramArrayOfByte.length - i) + ", expect size: " + paramArrayOfByte.length);
      }
    }
    return paramArrayOfByte.length;
  }
  
  private int readInt(InputStream paramInputStream)
    throws IOException
  {
    byte[] arrayOfByte = new byte[4];
    readAll(paramInputStream, arrayOfByte);
    ByteBuffer localByteBuffer = ByteBuffer.wrap(arrayOfByte);
    localByteBuffer.order(ByteOrder.nativeOrder());
    return localByteBuffer.getInt();
  }
  
  private String waitSocketSignal(InputStream paramInputStream)
    throws IOException
  {
    byte[] arrayOfByte1 = new byte[SOCK_SIGNAL_SIZE];
    readAll(paramInputStream, arrayOfByte1);
    ByteBuffer localByteBuffer = ByteBuffer.wrap(arrayOfByte1);
    localByteBuffer.order(ByteOrder.nativeOrder());
    localByteBuffer.getShort();
    byte[] arrayOfByte2 = new byte[6];
    localByteBuffer.get(arrayOfByte2);
    localByteBuffer.getInt();
    int i = localByteBuffer.getInt();
    String str = convertAddr(arrayOfByte2);
    if (i != 0) {
      throw new IOException("Connection failure, status: " + i);
    }
    return str;
  }
  
  BluetoothSocket accept(int paramInt)
    throws IOException
  {
    if (this.mSocketState != SocketState.LISTENING) {
      throw new IOException("bt socket is not in listen state");
    }
    String str = waitSocketSignal(this.mSocketIS);
    try
    {
      if (this.mSocketState != SocketState.LISTENING) {
        throw new IOException("bt socket is not in listen state");
      }
    }
    finally {}
    BluetoothSocket localBluetoothSocket = acceptSocket(str);
    return localBluetoothSocket;
  }
  
  int available()
    throws IOException
  {
    return this.mSocketIS.available();
  }
  
  /* Error */
  int bindListen()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 108	android/bluetooth/BluetoothSocket:mSocketState	Landroid/bluetooth/BluetoothSocket$SocketState;
    //   4: getstatic 287	android/bluetooth/BluetoothSocket$SocketState:CLOSED	Landroid/bluetooth/BluetoothSocket$SocketState;
    //   7: if_acmpne +6 -> 13
    //   10: bipush 77
    //   12: ireturn
    //   13: invokestatic 114	android/bluetooth/BluetoothAdapter:getDefaultAdapter	()Landroid/bluetooth/BluetoothAdapter;
    //   16: aconst_null
    //   17: invokevirtual 291	android/bluetooth/BluetoothAdapter:getBluetoothService	(Landroid/bluetooth/IBluetoothManagerCallback;)Landroid/bluetooth/IBluetooth;
    //   20: astore_1
    //   21: aload_1
    //   22: ifnonnull +14 -> 36
    //   25: ldc 26
    //   27: ldc_w 293
    //   30: invokestatic 175	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   33: pop
    //   34: iconst_m1
    //   35: ireturn
    //   36: aload_0
    //   37: aload_1
    //   38: aload_0
    //   39: getfield 91	android/bluetooth/BluetoothSocket:mType	I
    //   42: aload_0
    //   43: getfield 150	android/bluetooth/BluetoothSocket:mServiceName	Ljava/lang/String;
    //   46: aload_0
    //   47: getfield 89	android/bluetooth/BluetoothSocket:mUuid	Landroid/os/ParcelUuid;
    //   50: aload_0
    //   51: getfield 99	android/bluetooth/BluetoothSocket:mPort	I
    //   54: aload_0
    //   55: invokespecial 295	android/bluetooth/BluetoothSocket:getSecurityFlags	()I
    //   58: invokeinterface 301 6 0
    //   63: putfield 303	android/bluetooth/BluetoothSocket:mPfd	Landroid/os/ParcelFileDescriptor;
    //   66: aload_0
    //   67: monitorenter
    //   68: aload_0
    //   69: getfield 108	android/bluetooth/BluetoothSocket:mSocketState	Landroid/bluetooth/BluetoothSocket$SocketState;
    //   72: getstatic 106	android/bluetooth/BluetoothSocket$SocketState:INIT	Landroid/bluetooth/BluetoothSocket$SocketState;
    //   75: if_acmpeq +65 -> 140
    //   78: aload_0
    //   79: monitorexit
    //   80: bipush 77
    //   82: ireturn
    //   83: astore 6
    //   85: aload_0
    //   86: monitorexit
    //   87: aload 6
    //   89: athrow
    //   90: astore 4
    //   92: ldc 26
    //   94: new 70	java/lang/StringBuilder
    //   97: dup
    //   98: invokespecial 71	java/lang/StringBuilder:<init>	()V
    //   101: ldc_w 305
    //   104: invokevirtual 77	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   107: aload 4
    //   109: invokevirtual 169	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   112: invokevirtual 84	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   115: invokestatic 175	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   118: pop
    //   119: iconst_m1
    //   120: ireturn
    //   121: astore_2
    //   122: ldc 26
    //   124: new 307	java/lang/Throwable
    //   127: dup
    //   128: invokespecial 308	java/lang/Throwable:<init>	()V
    //   131: invokestatic 312	android/util/Log:getStackTraceString	(Ljava/lang/Throwable;)Ljava/lang/String;
    //   134: invokestatic 175	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   137: pop
    //   138: iconst_m1
    //   139: ireturn
    //   140: aload_0
    //   141: getfield 303	android/bluetooth/BluetoothSocket:mPfd	Landroid/os/ParcelFileDescriptor;
    //   144: ifnonnull +7 -> 151
    //   147: aload_0
    //   148: monitorexit
    //   149: iconst_m1
    //   150: ireturn
    //   151: aload_0
    //   152: new 160	android/net/LocalSocket
    //   155: dup
    //   156: aload_0
    //   157: getfield 303	android/bluetooth/BluetoothSocket:mPfd	Landroid/os/ParcelFileDescriptor;
    //   160: invokevirtual 318	android/os/ParcelFileDescriptor:getFileDescriptor	()Ljava/io/FileDescriptor;
    //   163: invokespecial 180	android/net/LocalSocket:<init>	(Ljava/io/FileDescriptor;)V
    //   166: putfield 158	android/bluetooth/BluetoothSocket:mSocket	Landroid/net/LocalSocket;
    //   169: aload_0
    //   170: aload_0
    //   171: getfield 158	android/bluetooth/BluetoothSocket:mSocket	Landroid/net/LocalSocket;
    //   174: invokevirtual 184	android/net/LocalSocket:getInputStream	()Ljava/io/InputStream;
    //   177: putfield 186	android/bluetooth/BluetoothSocket:mSocketIS	Ljava/io/InputStream;
    //   180: aload_0
    //   181: aload_0
    //   182: getfield 158	android/bluetooth/BluetoothSocket:mSocket	Landroid/net/LocalSocket;
    //   185: invokevirtual 190	android/net/LocalSocket:getOutputStream	()Ljava/io/OutputStream;
    //   188: putfield 192	android/bluetooth/BluetoothSocket:mSocketOS	Ljava/io/OutputStream;
    //   191: aload_0
    //   192: monitorexit
    //   193: aload_0
    //   194: aload_0
    //   195: getfield 186	android/bluetooth/BluetoothSocket:mSocketIS	Ljava/io/InputStream;
    //   198: invokespecial 320	android/bluetooth/BluetoothSocket:readInt	(Ljava/io/InputStream;)I
    //   201: istore 7
    //   203: aload_0
    //   204: monitorenter
    //   205: aload_0
    //   206: getfield 108	android/bluetooth/BluetoothSocket:mSocketState	Landroid/bluetooth/BluetoothSocket$SocketState;
    //   209: getstatic 106	android/bluetooth/BluetoothSocket$SocketState:INIT	Landroid/bluetooth/BluetoothSocket$SocketState;
    //   212: if_acmpne +10 -> 222
    //   215: aload_0
    //   216: getstatic 272	android/bluetooth/BluetoothSocket$SocketState:LISTENING	Landroid/bluetooth/BluetoothSocket$SocketState;
    //   219: putfield 108	android/bluetooth/BluetoothSocket:mSocketState	Landroid/bluetooth/BluetoothSocket$SocketState;
    //   222: aload_0
    //   223: monitorexit
    //   224: aload_0
    //   225: getfield 99	android/bluetooth/BluetoothSocket:mPort	I
    //   228: iconst_m1
    //   229: if_icmpne +9 -> 238
    //   232: aload_0
    //   233: iload 7
    //   235: putfield 99	android/bluetooth/BluetoothSocket:mPort	I
    //   238: iconst_0
    //   239: ireturn
    //   240: astore 8
    //   242: aload_0
    //   243: monitorexit
    //   244: aload 8
    //   246: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	247	0	this	BluetoothSocket
    //   20	18	1	localIBluetooth	IBluetooth
    //   121	1	2	localRemoteException	RemoteException
    //   90	18	4	localIOException	IOException
    //   83	5	6	localObject1	Object
    //   201	33	7	i	int
    //   240	5	8	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   68	80	83	finally
    //   85	87	83	finally
    //   140	149	83	finally
    //   151	193	83	finally
    //   66	68	90	java/io/IOException
    //   87	90	90	java/io/IOException
    //   193	205	90	java/io/IOException
    //   224	238	90	java/io/IOException
    //   244	247	90	java/io/IOException
    //   36	66	121	android/os/RemoteException
    //   205	222	240	finally
    //   222	224	240	finally
    //   242	244	240	finally
  }
  
  public void close()
    throws IOException
  {
    Log.d("BluetoothSocket", "close() in, this: " + this + ", channel: " + this.mPort + ", state: " + this.mSocketState);
    if (this.mSocketState == SocketState.CLOSED) {
      return;
    }
    try
    {
      if (this.mSocketState == SocketState.CLOSED) {
        return;
      }
    }
    finally {}
    this.mSocketState = SocketState.CLOSED;
    if (this.mSocket != null)
    {
      this.mSocket.shutdownInput();
      this.mSocket.shutdownOutput();
      this.mSocket.close();
      this.mSocket = null;
    }
    if (this.mPfd != null) {
      this.mPfd.detachFd();
    }
  }
  
  public void connect()
    throws IOException
  {
    if (this.mDevice == null) {
      throw new IOException("Connect is called on null device");
    }
    try
    {
      if (this.mSocketState == SocketState.CLOSED) {
        throw new IOException("socket closed");
      }
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothSocket", Log.getStackTraceString(new Throwable()));
      return;
    }
    IBluetooth localIBluetooth = BluetoothAdapter.getDefaultAdapter().getBluetoothService(null);
    if (localIBluetooth == null) {
      throw new IOException("Bluetooth is off");
    }
    this.mPfd = localIBluetooth.connectSocket(this.mDevice, this.mType, this.mUuid, this.mPort, getSecurityFlags());
    try
    {
      Log.d("BluetoothSocket", "connect(), SocketState: " + this.mSocketState + ", mPfd: " + this.mPfd);
      if (this.mSocketState == SocketState.CLOSED) {
        throw new IOException("socket closed");
      }
    }
    finally {}
    if (this.mPfd == null) {
      throw new IOException("bt socket connect failed");
    }
    this.mSocket = new LocalSocket(this.mPfd.getFileDescriptor());
    this.mSocketIS = this.mSocket.getInputStream();
    this.mSocketOS = this.mSocket.getOutputStream();
    int i = readInt(this.mSocketIS);
    if (i <= 0) {
      throw new IOException("bt socket connect failed");
    }
    this.mPort = i;
    waitSocketSignal(this.mSocketIS);
    try
    {
      if (this.mSocketState == SocketState.CLOSED) {
        throw new IOException("bt socket closed");
      }
    }
    finally {}
    this.mSocketState = SocketState.CONNECTED;
  }
  
  protected void finalize()
    throws Throwable
  {
    try
    {
      close();
      return;
    }
    finally
    {
      super.finalize();
    }
  }
  
  public InputStream getInputStream()
    throws IOException
  {
    return this.mInputStream;
  }
  
  public OutputStream getOutputStream()
    throws IOException
  {
    return this.mOutputStream;
  }
  
  int getPort()
  {
    return this.mPort;
  }
  
  public BluetoothDevice getRemoteDevice()
  {
    return this.mDevice;
  }
  
  public boolean isConnected()
  {
    return this.mSocketState == SocketState.CONNECTED;
  }
  
  int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = this.mSocketIS.read(paramArrayOfByte, paramInt1, paramInt2);
    if (i < 0) {
      throw new IOException("bt socket closed, read return: " + i);
    }
    return i;
  }
  
  void removeChannel() {}
  
  void setServiceName(String paramString)
  {
    this.mServiceName = paramString;
  }
  
  int write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    this.mSocketOS.write(paramArrayOfByte, paramInt1, paramInt2);
    return paramInt2;
  }
  
  private static enum SocketState
  {
    static
    {
      CONNECTED = new SocketState("CONNECTED", 1);
      LISTENING = new SocketState("LISTENING", 2);
      CLOSED = new SocketState("CLOSED", 3);
      SocketState[] arrayOfSocketState = new SocketState[4];
      arrayOfSocketState[0] = INIT;
      arrayOfSocketState[1] = CONNECTED;
      arrayOfSocketState[2] = LISTENING;
      arrayOfSocketState[3] = CLOSED;
      $VALUES = arrayOfSocketState;
    }
    
    private SocketState() {}
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\bluetooth\BluetoothSocket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.bluetooth;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

public class BluetoothPbap
{
  private static final boolean DBG = true;
  public static final String PBAP_PREVIOUS_STATE = "android.bluetooth.pbap.intent.PBAP_PREVIOUS_STATE";
  public static final String PBAP_STATE = "android.bluetooth.pbap.intent.PBAP_STATE";
  public static final String PBAP_STATE_CHANGED_ACTION = "android.bluetooth.pbap.intent.action.PBAP_STATE_CHANGED";
  public static final int RESULT_CANCELED = 2;
  public static final int RESULT_FAILURE = 0;
  public static final int RESULT_SUCCESS = 1;
  public static final int STATE_CONNECTED = 2;
  public static final int STATE_CONNECTING = 1;
  public static final int STATE_DISCONNECTED = 0;
  public static final int STATE_ERROR = -1;
  private static final String TAG = "BluetoothPbap";
  private static final boolean VDBG;
  private BluetoothAdapter mAdapter;
  private final IBluetoothStateChangeCallback mBluetoothStateChangeCallback = new IBluetoothStateChangeCallback.Stub()
  {
    public void onBluetoothStateChange(boolean paramAnonymousBoolean)
    {
      Log.d("BluetoothPbap", "onBluetoothStateChange: up=" + paramAnonymousBoolean);
      if (!paramAnonymousBoolean) {
        synchronized (BluetoothPbap.this.mConnection)
        {
          try
          {
            BluetoothPbap.access$102(BluetoothPbap.this, null);
            BluetoothPbap.this.mContext.unbindService(BluetoothPbap.this.mConnection);
            return;
          }
          catch (Exception localException2)
          {
            for (;;)
            {
              Log.e("BluetoothPbap", "", localException2);
            }
          }
        }
      }
      try
      {
        synchronized (BluetoothPbap.this.mConnection)
        {
          if ((BluetoothPbap.this.mService == null) && (!BluetoothPbap.this.mContext.bindService(new Intent(IBluetoothPbap.class.getName()), BluetoothPbap.this.mConnection, 0))) {
            Log.e("BluetoothPbap", "Could not bind to Bluetooth PBAP Service");
          }
          return;
        }
      }
      catch (Exception localException1)
      {
        for (;;)
        {
          Log.e("BluetoothPbap", "", localException1);
        }
      }
    }
  };
  private ServiceConnection mConnection = new ServiceConnection()
  {
    public void onServiceConnected(ComponentName paramAnonymousComponentName, IBinder paramAnonymousIBinder)
    {
      BluetoothPbap.log("Proxy object connected");
      BluetoothPbap.access$102(BluetoothPbap.this, IBluetoothPbap.Stub.asInterface(paramAnonymousIBinder));
      if (BluetoothPbap.this.mServiceListener != null) {
        BluetoothPbap.this.mServiceListener.onServiceConnected(BluetoothPbap.this);
      }
    }
    
    public void onServiceDisconnected(ComponentName paramAnonymousComponentName)
    {
      BluetoothPbap.log("Proxy object disconnected");
      BluetoothPbap.access$102(BluetoothPbap.this, null);
      if (BluetoothPbap.this.mServiceListener != null) {
        BluetoothPbap.this.mServiceListener.onServiceDisconnected();
      }
    }
  };
  private final Context mContext;
  private IBluetoothPbap mService;
  private ServiceListener mServiceListener;
  
  public BluetoothPbap(Context paramContext, ServiceListener paramServiceListener)
  {
    this.mContext = paramContext;
    this.mServiceListener = paramServiceListener;
    this.mAdapter = BluetoothAdapter.getDefaultAdapter();
    IBluetoothManager localIBluetoothManager = this.mAdapter.getBluetoothManager();
    if (localIBluetoothManager != null) {}
    try
    {
      localIBluetoothManager.registerStateChangeCallback(this.mBluetoothStateChangeCallback);
      if (!paramContext.bindService(new Intent(IBluetoothPbap.class.getName()), this.mConnection, 0)) {
        Log.e("BluetoothPbap", "Could not bind to Bluetooth Pbap Service");
      }
      return;
    }
    catch (RemoteException localRemoteException)
    {
      for (;;)
      {
        Log.e("BluetoothPbap", "", localRemoteException);
      }
    }
  }
  
  public static boolean doesClassMatchSink(BluetoothClass paramBluetoothClass)
  {
    switch (paramBluetoothClass.getDeviceClass())
    {
    default: 
      return false;
    }
    return true;
  }
  
  private static void log(String paramString)
  {
    Log.d("BluetoothPbap", paramString);
  }
  
  /* Error */
  public void close()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 75	android/bluetooth/BluetoothPbap:mAdapter	Landroid/bluetooth/BluetoothAdapter;
    //   6: invokevirtual 79	android/bluetooth/BluetoothAdapter:getBluetoothManager	()Landroid/bluetooth/IBluetoothManager;
    //   9: astore_2
    //   10: aload_2
    //   11: ifnull +13 -> 24
    //   14: aload_2
    //   15: aload_0
    //   16: getfield 58	android/bluetooth/BluetoothPbap:mBluetoothStateChangeCallback	Landroid/bluetooth/IBluetoothStateChangeCallback;
    //   19: invokeinterface 150 2 0
    //   24: aload_0
    //   25: getfield 63	android/bluetooth/BluetoothPbap:mConnection	Landroid/content/ServiceConnection;
    //   28: astore_3
    //   29: aload_3
    //   30: monitorenter
    //   31: aload_0
    //   32: getfield 123	android/bluetooth/BluetoothPbap:mService	Landroid/bluetooth/IBluetoothPbap;
    //   35: astore 5
    //   37: aload 5
    //   39: ifnull +24 -> 63
    //   42: aload_0
    //   43: aconst_null
    //   44: putfield 123	android/bluetooth/BluetoothPbap:mService	Landroid/bluetooth/IBluetoothPbap;
    //   47: aload_0
    //   48: getfield 65	android/bluetooth/BluetoothPbap:mContext	Landroid/content/Context;
    //   51: aload_0
    //   52: getfield 63	android/bluetooth/BluetoothPbap:mConnection	Landroid/content/ServiceConnection;
    //   55: invokevirtual 154	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   58: aload_0
    //   59: aconst_null
    //   60: putfield 63	android/bluetooth/BluetoothPbap:mConnection	Landroid/content/ServiceConnection;
    //   63: aload_3
    //   64: monitorexit
    //   65: aload_0
    //   66: aconst_null
    //   67: putfield 67	android/bluetooth/BluetoothPbap:mServiceListener	Landroid/bluetooth/BluetoothPbap$ServiceListener;
    //   70: aload_0
    //   71: monitorexit
    //   72: return
    //   73: astore 8
    //   75: ldc 31
    //   77: ldc 114
    //   79: aload 8
    //   81: invokestatic 117	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   84: pop
    //   85: goto -61 -> 24
    //   88: astore_1
    //   89: aload_0
    //   90: monitorexit
    //   91: aload_1
    //   92: athrow
    //   93: astore 6
    //   95: ldc 31
    //   97: ldc 114
    //   99: aload 6
    //   101: invokestatic 117	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   104: pop
    //   105: goto -42 -> 63
    //   108: astore 4
    //   110: aload_3
    //   111: monitorexit
    //   112: aload 4
    //   114: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	115	0	this	BluetoothPbap
    //   88	4	1	localObject1	Object
    //   9	6	2	localIBluetoothManager	IBluetoothManager
    //   108	5	4	localObject2	Object
    //   35	3	5	localIBluetoothPbap	IBluetoothPbap
    //   93	7	6	localException1	Exception
    //   73	7	8	localException2	Exception
    // Exception table:
    //   from	to	target	type
    //   14	24	73	java/lang/Exception
    //   2	10	88	finally
    //   14	24	88	finally
    //   24	31	88	finally
    //   65	70	88	finally
    //   75	85	88	finally
    //   112	115	88	finally
    //   42	63	93	java/lang/Exception
    //   31	37	108	finally
    //   42	63	108	finally
    //   63	65	108	finally
    //   95	105	108	finally
    //   110	112	108	finally
  }
  
  public boolean disconnect()
  {
    log("disconnect()");
    if (this.mService != null) {
      try
      {
        this.mService.disconnect();
        return true;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothPbap", localRemoteException.toString());
      }
    }
    for (;;)
    {
      return false;
      Log.w("BluetoothPbap", "Proxy not attached to service");
      log(Log.getStackTraceString(new Throwable()));
    }
  }
  
  protected void finalize()
    throws Throwable
  {
    try
    {
      close();
      return;
    }
    finally
    {
      super.finalize();
    }
  }
  
  public BluetoothDevice getClient()
  {
    if (this.mService != null) {
      try
      {
        BluetoothDevice localBluetoothDevice = this.mService.getClient();
        return localBluetoothDevice;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothPbap", localRemoteException.toString());
      }
    }
    for (;;)
    {
      return null;
      Log.w("BluetoothPbap", "Proxy not attached to service");
      log(Log.getStackTraceString(new Throwable()));
    }
  }
  
  public int getState()
  {
    if (this.mService != null) {
      try
      {
        int i = this.mService.getState();
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothPbap", localRemoteException.toString());
      }
    }
    for (;;)
    {
      return -1;
      Log.w("BluetoothPbap", "Proxy not attached to service");
      log(Log.getStackTraceString(new Throwable()));
    }
  }
  
  public boolean isConnected(BluetoothDevice paramBluetoothDevice)
  {
    if (this.mService != null) {
      try
      {
        boolean bool = this.mService.isConnected(paramBluetoothDevice);
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothPbap", localRemoteException.toString());
      }
    }
    for (;;)
    {
      return false;
      Log.w("BluetoothPbap", "Proxy not attached to service");
      log(Log.getStackTraceString(new Throwable()));
    }
  }
  
  public static abstract interface ServiceListener
  {
    public abstract void onServiceConnected(BluetoothPbap paramBluetoothPbap);
    
    public abstract void onServiceDisconnected();
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\bluetooth\BluetoothPbap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
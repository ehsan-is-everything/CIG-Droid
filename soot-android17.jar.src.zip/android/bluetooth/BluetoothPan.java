package android.bluetooth;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;

public final class BluetoothPan
  implements BluetoothProfile
{
  public static final String ACTION_CONNECTION_STATE_CHANGED = "android.bluetooth.pan.profile.action.CONNECTION_STATE_CHANGED";
  private static final boolean DBG = true;
  public static final String EXTRA_LOCAL_ROLE = "android.bluetooth.pan.extra.LOCAL_ROLE";
  public static final int LOCAL_NAP_ROLE = 1;
  public static final int LOCAL_PANU_ROLE = 2;
  public static final int PAN_CONNECT_FAILED_ALREADY_CONNECTED = 1001;
  public static final int PAN_CONNECT_FAILED_ATTEMPT_FAILED = 1002;
  public static final int PAN_DISCONNECT_FAILED_NOT_CONNECTED = 1000;
  public static final int PAN_OPERATION_GENERIC_FAILURE = 1003;
  public static final int PAN_OPERATION_SUCCESS = 1004;
  public static final int PAN_ROLE_NONE = 0;
  public static final int REMOTE_NAP_ROLE = 1;
  public static final int REMOTE_PANU_ROLE = 2;
  private static final String TAG = "BluetoothPan";
  private static final boolean VDBG;
  private BluetoothAdapter mAdapter;
  private ServiceConnection mConnection = new ServiceConnection()
  {
    public void onServiceConnected(ComponentName paramAnonymousComponentName, IBinder paramAnonymousIBinder)
    {
      Log.d("BluetoothPan", "BluetoothPAN Proxy object connected");
      BluetoothPan.access$202(BluetoothPan.this, IBluetoothPan.Stub.asInterface(paramAnonymousIBinder));
      if (BluetoothPan.this.mServiceListener != null) {
        BluetoothPan.this.mServiceListener.onServiceConnected(5, BluetoothPan.this);
      }
    }
    
    public void onServiceDisconnected(ComponentName paramAnonymousComponentName)
    {
      Log.d("BluetoothPan", "BluetoothPAN Proxy object disconnected");
      BluetoothPan.access$202(BluetoothPan.this, null);
      if (BluetoothPan.this.mServiceListener != null) {
        BluetoothPan.this.mServiceListener.onServiceDisconnected(5);
      }
    }
  };
  private Context mContext;
  private IBluetoothPan mPanService;
  private BluetoothProfile.ServiceListener mServiceListener;
  private IBluetoothStateChangeCallback mStateChangeCallback = new IBluetoothStateChangeCallback.Stub()
  {
    public void onBluetoothStateChange(boolean paramAnonymousBoolean)
      throws RemoteException
    {
      if (paramAnonymousBoolean)
      {
        Log.d("BluetoothPan", "onBluetoothStateChange(on) call bindService");
        if (!BluetoothPan.this.mContext.bindService(new Intent(IBluetoothPan.class.getName()), BluetoothPan.this.mConnection, 0)) {
          Log.e("BluetoothPan", "Could not bind to Bluetooth HID Service");
        }
        Log.d("BluetoothPan", "BluetoothPan(), bindService called");
        return;
      }
      try
      {
        synchronized (BluetoothPan.this.mConnection)
        {
          BluetoothPan.access$202(BluetoothPan.this, null);
          BluetoothPan.this.mContext.unbindService(BluetoothPan.this.mConnection);
          return;
        }
      }
      catch (Exception localException)
      {
        for (;;)
        {
          Log.e("BluetoothPan", "", localException);
        }
      }
    }
  };
  
  BluetoothPan(Context paramContext, BluetoothProfile.ServiceListener paramServiceListener)
  {
    this.mContext = paramContext;
    this.mServiceListener = paramServiceListener;
    this.mAdapter = BluetoothAdapter.getDefaultAdapter();
    try
    {
      this.mAdapter.getBluetoothManager().registerStateChangeCallback(this.mStateChangeCallback);
      Log.d("BluetoothPan", "BluetoothPan() call bindService");
      if (!paramContext.bindService(new Intent(IBluetoothPan.class.getName()), this.mConnection, 0)) {
        Log.e("BluetoothPan", "Could not bind to Bluetooth HID Service");
      }
      Log.d("BluetoothPan", "BluetoothPan(), bindService called");
      return;
    }
    catch (RemoteException localRemoteException)
    {
      for (;;)
      {
        Log.w("BluetoothPan", "Unable to register BluetoothStateChangeCallback", localRemoteException);
      }
    }
  }
  
  private boolean isEnabled()
  {
    return this.mAdapter.getState() == 12;
  }
  
  private boolean isValidDevice(BluetoothDevice paramBluetoothDevice)
  {
    if (paramBluetoothDevice == null) {}
    while (!BluetoothAdapter.checkBluetoothAddress(paramBluetoothDevice.getAddress())) {
      return false;
    }
    return true;
  }
  
  private static void log(String paramString)
  {
    Log.d("BluetoothPan", paramString);
  }
  
  void close()
  {
    if (this.mConnection != null)
    {
      this.mContext.unbindService(this.mConnection);
      this.mConnection = null;
    }
    this.mServiceListener = null;
    try
    {
      this.mAdapter.getBluetoothManager().unregisterStateChangeCallback(this.mStateChangeCallback);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.w("BluetoothPan", "Unable to register BluetoothStateChangeCallback", localRemoteException);
    }
  }
  
  public boolean connect(BluetoothDevice paramBluetoothDevice)
  {
    log("connect(" + paramBluetoothDevice + ")");
    if ((this.mPanService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {}
    IBluetoothPan localIBluetoothPan;
    do
    {
      try
      {
        boolean bool2 = this.mPanService.connect(paramBluetoothDevice);
        bool1 = bool2;
        return bool1;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothPan", "Stack:" + Log.getStackTraceString(new Throwable()));
        return false;
      }
      localIBluetoothPan = this.mPanService;
      boolean bool1 = false;
    } while (localIBluetoothPan != null);
    Log.w("BluetoothPan", "Proxy not attached to service");
    return false;
  }
  
  public boolean disconnect(BluetoothDevice paramBluetoothDevice)
  {
    log("disconnect(" + paramBluetoothDevice + ")");
    if ((this.mPanService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {}
    IBluetoothPan localIBluetoothPan;
    do
    {
      try
      {
        boolean bool2 = this.mPanService.disconnect(paramBluetoothDevice);
        bool1 = bool2;
        return bool1;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothPan", "Stack:" + Log.getStackTraceString(new Throwable()));
        return false;
      }
      localIBluetoothPan = this.mPanService;
      boolean bool1 = false;
    } while (localIBluetoothPan != null);
    Log.w("BluetoothPan", "Proxy not attached to service");
    return false;
  }
  
  protected void finalize()
  {
    close();
  }
  
  public List<BluetoothDevice> getConnectedDevices()
  {
    if ((this.mPanService != null) && (isEnabled())) {
      try
      {
        List localList = this.mPanService.getConnectedDevices();
        return localList;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothPan", "Stack:" + Log.getStackTraceString(new Throwable()));
        return new ArrayList();
      }
    }
    if (this.mPanService == null) {
      Log.w("BluetoothPan", "Proxy not attached to service");
    }
    return new ArrayList();
  }
  
  public int getConnectionState(BluetoothDevice paramBluetoothDevice)
  {
    if ((this.mPanService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {}
    IBluetoothPan localIBluetoothPan;
    do
    {
      try
      {
        int j = this.mPanService.getConnectionState(paramBluetoothDevice);
        i = j;
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothPan", "Stack:" + Log.getStackTraceString(new Throwable()));
        return 0;
      }
      localIBluetoothPan = this.mPanService;
      int i = 0;
    } while (localIBluetoothPan != null);
    Log.w("BluetoothPan", "Proxy not attached to service");
    return 0;
  }
  
  public List<BluetoothDevice> getDevicesMatchingConnectionStates(int[] paramArrayOfInt)
  {
    if ((this.mPanService != null) && (isEnabled())) {
      try
      {
        List localList = this.mPanService.getDevicesMatchingConnectionStates(paramArrayOfInt);
        return localList;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothPan", "Stack:" + Log.getStackTraceString(new Throwable()));
        return new ArrayList();
      }
    }
    if (this.mPanService == null) {
      Log.w("BluetoothPan", "Proxy not attached to service");
    }
    return new ArrayList();
  }
  
  public boolean isTetheringOn()
  {
    try
    {
      boolean bool = this.mPanService.isTetheringOn();
      return bool;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothPan", "Stack:" + Log.getStackTraceString(new Throwable()));
    }
    return false;
  }
  
  public void setBluetoothTethering(boolean paramBoolean)
  {
    log("setBluetoothTethering(" + paramBoolean + ")");
    try
    {
      this.mPanService.setBluetoothTethering(paramBoolean);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.e("BluetoothPan", "Stack:" + Log.getStackTraceString(new Throwable()));
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\bluetooth\BluetoothPan.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
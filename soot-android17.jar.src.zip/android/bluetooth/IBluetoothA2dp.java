package android.bluetooth;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import java.util.ArrayList;
import java.util.List;

public abstract interface IBluetoothA2dp
  extends IInterface
{
  public abstract boolean connect(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract boolean disconnect(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract List<BluetoothDevice> getConnectedDevices()
    throws RemoteException;
  
  public abstract int getConnectionState(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract List<BluetoothDevice> getDevicesMatchingConnectionStates(int[] paramArrayOfInt)
    throws RemoteException;
  
  public abstract int getPriority(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract boolean isA2dpPlaying(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract boolean setPriority(BluetoothDevice paramBluetoothDevice, int paramInt)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IBluetoothA2dp
  {
    private static final String DESCRIPTOR = "android.bluetooth.IBluetoothA2dp";
    static final int TRANSACTION_connect = 1;
    static final int TRANSACTION_disconnect = 2;
    static final int TRANSACTION_getConnectedDevices = 3;
    static final int TRANSACTION_getConnectionState = 5;
    static final int TRANSACTION_getDevicesMatchingConnectionStates = 4;
    static final int TRANSACTION_getPriority = 7;
    static final int TRANSACTION_isA2dpPlaying = 8;
    static final int TRANSACTION_setPriority = 6;
    
    public Stub()
    {
      attachInterface(this, "android.bluetooth.IBluetoothA2dp");
    }
    
    public static IBluetoothA2dp asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.bluetooth.IBluetoothA2dp");
      if ((localIInterface != null) && ((localIInterface instanceof IBluetoothA2dp))) {
        return (IBluetoothA2dp)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.bluetooth.IBluetoothA2dp");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothA2dp");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice6 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice6 = null)
        {
          boolean bool4 = connect(localBluetoothDevice6);
          paramParcel2.writeNoException();
          int i1 = 0;
          if (bool4) {
            i1 = 1;
          }
          paramParcel2.writeInt(i1);
          return true;
        }
      case 2: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothA2dp");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice5 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice5 = null)
        {
          boolean bool3 = disconnect(localBluetoothDevice5);
          paramParcel2.writeNoException();
          int n = 0;
          if (bool3) {
            n = 1;
          }
          paramParcel2.writeInt(n);
          return true;
        }
      case 3: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothA2dp");
        List localList2 = getConnectedDevices();
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList2);
        return true;
      case 4: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothA2dp");
        List localList1 = getDevicesMatchingConnectionStates(paramParcel1.createIntArray());
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList1);
        return true;
      case 5: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothA2dp");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice4 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice4 = null)
        {
          int m = getConnectionState(localBluetoothDevice4);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(m);
          return true;
        }
      case 6: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothA2dp");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice3 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice3 = null)
        {
          boolean bool2 = setPriority(localBluetoothDevice3, paramParcel1.readInt());
          paramParcel2.writeNoException();
          int k = 0;
          if (bool2) {
            k = 1;
          }
          paramParcel2.writeInt(k);
          return true;
        }
      case 7: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothA2dp");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice2 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice2 = null)
        {
          int j = getPriority(localBluetoothDevice2);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(j);
          return true;
        }
      }
      paramParcel1.enforceInterface("android.bluetooth.IBluetoothA2dp");
      if (paramParcel1.readInt() != 0) {}
      for (BluetoothDevice localBluetoothDevice1 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice1 = null)
      {
        boolean bool1 = isA2dpPlaying(localBluetoothDevice1);
        paramParcel2.writeNoException();
        int i = 0;
        if (bool1) {
          i = 1;
        }
        paramParcel2.writeInt(i);
        return true;
      }
    }
    
    private static class Proxy
      implements IBluetoothA2dp
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public boolean connect(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothA2dp");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(1, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean disconnect(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothA2dp");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(2, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public List<BluetoothDevice> getConnectedDevices()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothA2dp");
          this.mRemote.transact(3, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(BluetoothDevice.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public int getConnectionState(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +49 -> 64
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 43	android/bluetooth/BluetoothDevice:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/bluetooth/IBluetoothA2dp$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: iconst_5
        //   34: aload_2
        //   35: aload_3
        //   36: iconst_0
        //   37: invokeinterface 49 5 0
        //   42: pop
        //   43: aload_3
        //   44: invokevirtual 52	android/os/Parcel:readException	()V
        //   47: aload_3
        //   48: invokevirtual 56	android/os/Parcel:readInt	()I
        //   51: istore 6
        //   53: aload_3
        //   54: invokevirtual 59	android/os/Parcel:recycle	()V
        //   57: aload_2
        //   58: invokevirtual 59	android/os/Parcel:recycle	()V
        //   61: iload 6
        //   63: ireturn
        //   64: aload_2
        //   65: iconst_0
        //   66: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   69: goto -40 -> 29
        //   72: astore 4
        //   74: aload_3
        //   75: invokevirtual 59	android/os/Parcel:recycle	()V
        //   78: aload_2
        //   79: invokevirtual 59	android/os/Parcel:recycle	()V
        //   82: aload 4
        //   84: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	85	0	this	Proxy
        //   0	85	1	paramBluetoothDevice	BluetoothDevice
        //   3	76	2	localParcel1	Parcel
        //   7	68	3	localParcel2	Parcel
        //   72	11	4	localObject	Object
        //   51	11	6	i	int
        // Exception table:
        //   from	to	target	type
        //   8	14	72	finally
        //   18	29	72	finally
        //   29	53	72	finally
        //   64	69	72	finally
      }
      
      public List<BluetoothDevice> getDevicesMatchingConnectionStates(int[] paramArrayOfInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothA2dp");
          localParcel1.writeIntArray(paramArrayOfInt);
          this.mRemote.transact(4, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(BluetoothDevice.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.bluetooth.IBluetoothA2dp";
      }
      
      /* Error */
      public int getPriority(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +50 -> 65
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 43	android/bluetooth/BluetoothDevice:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/bluetooth/IBluetoothA2dp$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: bipush 7
        //   35: aload_2
        //   36: aload_3
        //   37: iconst_0
        //   38: invokeinterface 49 5 0
        //   43: pop
        //   44: aload_3
        //   45: invokevirtual 52	android/os/Parcel:readException	()V
        //   48: aload_3
        //   49: invokevirtual 56	android/os/Parcel:readInt	()I
        //   52: istore 6
        //   54: aload_3
        //   55: invokevirtual 59	android/os/Parcel:recycle	()V
        //   58: aload_2
        //   59: invokevirtual 59	android/os/Parcel:recycle	()V
        //   62: iload 6
        //   64: ireturn
        //   65: aload_2
        //   66: iconst_0
        //   67: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   70: goto -41 -> 29
        //   73: astore 4
        //   75: aload_3
        //   76: invokevirtual 59	android/os/Parcel:recycle	()V
        //   79: aload_2
        //   80: invokevirtual 59	android/os/Parcel:recycle	()V
        //   83: aload 4
        //   85: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	86	0	this	Proxy
        //   0	86	1	paramBluetoothDevice	BluetoothDevice
        //   3	77	2	localParcel1	Parcel
        //   7	69	3	localParcel2	Parcel
        //   73	11	4	localObject	Object
        //   52	11	6	i	int
        // Exception table:
        //   from	to	target	type
        //   8	14	73	finally
        //   18	29	73	finally
        //   29	54	73	finally
        //   65	70	73	finally
      }
      
      public boolean isA2dpPlaying(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothA2dp");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(8, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean setPriority(BluetoothDevice paramBluetoothDevice, int paramInt)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothA2dp");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              localParcel1.writeInt(paramInt);
              this.mRemote.transact(6, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\bluetooth\IBluetoothA2dp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
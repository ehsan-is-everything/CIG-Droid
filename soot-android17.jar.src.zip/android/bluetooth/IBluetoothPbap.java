package android.bluetooth;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface IBluetoothPbap
  extends IInterface
{
  public abstract boolean connect(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract void disconnect()
    throws RemoteException;
  
  public abstract BluetoothDevice getClient()
    throws RemoteException;
  
  public abstract int getState()
    throws RemoteException;
  
  public abstract boolean isConnected(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IBluetoothPbap
  {
    private static final String DESCRIPTOR = "android.bluetooth.IBluetoothPbap";
    static final int TRANSACTION_connect = 3;
    static final int TRANSACTION_disconnect = 4;
    static final int TRANSACTION_getClient = 2;
    static final int TRANSACTION_getState = 1;
    static final int TRANSACTION_isConnected = 5;
    
    public Stub()
    {
      attachInterface(this, "android.bluetooth.IBluetoothPbap");
    }
    
    public static IBluetoothPbap asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.bluetooth.IBluetoothPbap");
      if ((localIInterface != null) && ((localIInterface instanceof IBluetoothPbap))) {
        return (IBluetoothPbap)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.bluetooth.IBluetoothPbap");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothPbap");
        int k = getState();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(k);
        return true;
      case 2: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothPbap");
        BluetoothDevice localBluetoothDevice3 = getClient();
        paramParcel2.writeNoException();
        if (localBluetoothDevice3 != null)
        {
          paramParcel2.writeInt(1);
          localBluetoothDevice3.writeToParcel(paramParcel2, 1);
          return true;
        }
        paramParcel2.writeInt(0);
        return true;
      case 3: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothPbap");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice2 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice2 = null)
        {
          boolean bool2 = connect(localBluetoothDevice2);
          paramParcel2.writeNoException();
          int j = 0;
          if (bool2) {
            j = 1;
          }
          paramParcel2.writeInt(j);
          return true;
        }
      case 4: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothPbap");
        disconnect();
        paramParcel2.writeNoException();
        return true;
      }
      paramParcel1.enforceInterface("android.bluetooth.IBluetoothPbap");
      if (paramParcel1.readInt() != 0) {}
      for (BluetoothDevice localBluetoothDevice1 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice1 = null)
      {
        boolean bool1 = isConnected(localBluetoothDevice1);
        paramParcel2.writeNoException();
        int i = 0;
        if (bool1) {
          i = 1;
        }
        paramParcel2.writeInt(i);
        return true;
      }
    }
    
    private static class Proxy
      implements IBluetoothPbap
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public boolean connect(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothPbap");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(3, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public void disconnect()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothPbap");
          this.mRemote.transact(4, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public BluetoothDevice getClient()
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_1
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_2
        //   8: aload_1
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_0
        //   15: getfield 15	android/bluetooth/IBluetoothPbap$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   18: iconst_2
        //   19: aload_1
        //   20: aload_2
        //   21: iconst_0
        //   22: invokeinterface 49 5 0
        //   27: pop
        //   28: aload_2
        //   29: invokevirtual 52	android/os/Parcel:readException	()V
        //   32: aload_2
        //   33: invokevirtual 56	android/os/Parcel:readInt	()I
        //   36: ifeq +28 -> 64
        //   39: getstatic 66	android/bluetooth/BluetoothDevice:CREATOR	Landroid/os/Parcelable$Creator;
        //   42: aload_2
        //   43: invokeinterface 72 2 0
        //   48: checkcast 39	android/bluetooth/BluetoothDevice
        //   51: astore 5
        //   53: aload_2
        //   54: invokevirtual 59	android/os/Parcel:recycle	()V
        //   57: aload_1
        //   58: invokevirtual 59	android/os/Parcel:recycle	()V
        //   61: aload 5
        //   63: areturn
        //   64: aconst_null
        //   65: astore 5
        //   67: goto -14 -> 53
        //   70: astore_3
        //   71: aload_2
        //   72: invokevirtual 59	android/os/Parcel:recycle	()V
        //   75: aload_1
        //   76: invokevirtual 59	android/os/Parcel:recycle	()V
        //   79: aload_3
        //   80: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	81	0	this	Proxy
        //   3	73	1	localParcel1	Parcel
        //   7	65	2	localParcel2	Parcel
        //   70	10	3	localObject	Object
        //   51	15	5	localBluetoothDevice	BluetoothDevice
        // Exception table:
        //   from	to	target	type
        //   8	53	70	finally
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.bluetooth.IBluetoothPbap";
      }
      
      public int getState()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothPbap");
          this.mRemote.transact(1, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean isConnected(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothPbap");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(5, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\bluetooth\IBluetoothPbap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
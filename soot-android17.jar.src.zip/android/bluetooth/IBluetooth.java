package android.bluetooth;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.ParcelUuid;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface IBluetooth
  extends IInterface
{
  public abstract boolean cancelBondProcess(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract boolean cancelDiscovery()
    throws RemoteException;
  
  public abstract ParcelFileDescriptor connectSocket(BluetoothDevice paramBluetoothDevice, int paramInt1, ParcelUuid paramParcelUuid, int paramInt2, int paramInt3)
    throws RemoteException;
  
  public abstract boolean createBond(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract ParcelFileDescriptor createSocketChannel(int paramInt1, String paramString, ParcelUuid paramParcelUuid, int paramInt2, int paramInt3)
    throws RemoteException;
  
  public abstract boolean disable()
    throws RemoteException;
  
  public abstract boolean enable()
    throws RemoteException;
  
  public abstract boolean enableNoAutoConnect()
    throws RemoteException;
  
  public abstract boolean fetchRemoteUuids(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract int getAdapterConnectionState()
    throws RemoteException;
  
  public abstract String getAddress()
    throws RemoteException;
  
  public abstract int getBondState(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract BluetoothDevice[] getBondedDevices()
    throws RemoteException;
  
  public abstract int getDiscoverableTimeout()
    throws RemoteException;
  
  public abstract String getName()
    throws RemoteException;
  
  public abstract int getProfileConnectionState(int paramInt)
    throws RemoteException;
  
  public abstract String getRemoteAlias(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract int getRemoteClass(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract String getRemoteName(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract ParcelUuid[] getRemoteUuids(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract int getScanMode()
    throws RemoteException;
  
  public abstract int getState()
    throws RemoteException;
  
  public abstract ParcelUuid[] getUuids()
    throws RemoteException;
  
  public abstract boolean isDiscovering()
    throws RemoteException;
  
  public abstract boolean isEnabled()
    throws RemoteException;
  
  public abstract void registerCallback(IBluetoothCallback paramIBluetoothCallback)
    throws RemoteException;
  
  public abstract boolean removeBond(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract void sendConnectionStateChange(BluetoothDevice paramBluetoothDevice, int paramInt1, int paramInt2, int paramInt3)
    throws RemoteException;
  
  public abstract boolean setDiscoverableTimeout(int paramInt)
    throws RemoteException;
  
  public abstract boolean setName(String paramString)
    throws RemoteException;
  
  public abstract boolean setPairingConfirmation(BluetoothDevice paramBluetoothDevice, boolean paramBoolean)
    throws RemoteException;
  
  public abstract boolean setPasskey(BluetoothDevice paramBluetoothDevice, boolean paramBoolean, int paramInt, byte[] paramArrayOfByte)
    throws RemoteException;
  
  public abstract boolean setPin(BluetoothDevice paramBluetoothDevice, boolean paramBoolean, int paramInt, byte[] paramArrayOfByte)
    throws RemoteException;
  
  public abstract boolean setRemoteAlias(BluetoothDevice paramBluetoothDevice, String paramString)
    throws RemoteException;
  
  public abstract boolean setScanMode(int paramInt1, int paramInt2)
    throws RemoteException;
  
  public abstract boolean startDiscovery()
    throws RemoteException;
  
  public abstract void unregisterCallback(IBluetoothCallback paramIBluetoothCallback)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IBluetooth
  {
    private static final String DESCRIPTOR = "android.bluetooth.IBluetooth";
    static final int TRANSACTION_cancelBondProcess = 21;
    static final int TRANSACTION_cancelDiscovery = 15;
    static final int TRANSACTION_connectSocket = 36;
    static final int TRANSACTION_createBond = 20;
    static final int TRANSACTION_createSocketChannel = 37;
    static final int TRANSACTION_disable = 5;
    static final int TRANSACTION_enable = 3;
    static final int TRANSACTION_enableNoAutoConnect = 4;
    static final int TRANSACTION_fetchRemoteUuids = 29;
    static final int TRANSACTION_getAdapterConnectionState = 17;
    static final int TRANSACTION_getAddress = 6;
    static final int TRANSACTION_getBondState = 23;
    static final int TRANSACTION_getBondedDevices = 19;
    static final int TRANSACTION_getDiscoverableTimeout = 12;
    static final int TRANSACTION_getName = 9;
    static final int TRANSACTION_getProfileConnectionState = 18;
    static final int TRANSACTION_getRemoteAlias = 25;
    static final int TRANSACTION_getRemoteClass = 27;
    static final int TRANSACTION_getRemoteName = 24;
    static final int TRANSACTION_getRemoteUuids = 28;
    static final int TRANSACTION_getScanMode = 10;
    static final int TRANSACTION_getState = 2;
    static final int TRANSACTION_getUuids = 7;
    static final int TRANSACTION_isDiscovering = 16;
    static final int TRANSACTION_isEnabled = 1;
    static final int TRANSACTION_registerCallback = 34;
    static final int TRANSACTION_removeBond = 22;
    static final int TRANSACTION_sendConnectionStateChange = 33;
    static final int TRANSACTION_setDiscoverableTimeout = 13;
    static final int TRANSACTION_setName = 8;
    static final int TRANSACTION_setPairingConfirmation = 32;
    static final int TRANSACTION_setPasskey = 31;
    static final int TRANSACTION_setPin = 30;
    static final int TRANSACTION_setRemoteAlias = 26;
    static final int TRANSACTION_setScanMode = 11;
    static final int TRANSACTION_startDiscovery = 14;
    static final int TRANSACTION_unregisterCallback = 35;
    
    public Stub()
    {
      attachInterface(this, "android.bluetooth.IBluetooth");
    }
    
    public static IBluetooth asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.bluetooth.IBluetooth");
      if ((localIInterface != null) && ((localIInterface instanceof IBluetooth))) {
        return (IBluetooth)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.bluetooth.IBluetooth");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        boolean bool21 = isEnabled();
        paramParcel2.writeNoException();
        if (bool21) {}
        for (int i22 = 1;; i22 = 0)
        {
          paramParcel2.writeInt(i22);
          return true;
        }
      case 2: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        int i21 = getState();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i21);
        return true;
      case 3: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        boolean bool20 = enable();
        paramParcel2.writeNoException();
        int i20 = 0;
        if (bool20) {
          i20 = 1;
        }
        paramParcel2.writeInt(i20);
        return true;
      case 4: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        boolean bool19 = enableNoAutoConnect();
        paramParcel2.writeNoException();
        int i19 = 0;
        if (bool19) {
          i19 = 1;
        }
        paramParcel2.writeInt(i19);
        return true;
      case 5: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        boolean bool18 = disable();
        paramParcel2.writeNoException();
        int i18 = 0;
        if (bool18) {
          i18 = 1;
        }
        paramParcel2.writeInt(i18);
        return true;
      case 6: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        String str5 = getAddress();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str5);
        return true;
      case 7: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        ParcelUuid[] arrayOfParcelUuid2 = getUuids();
        paramParcel2.writeNoException();
        paramParcel2.writeTypedArray(arrayOfParcelUuid2, 1);
        return true;
      case 8: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        boolean bool17 = setName(paramParcel1.readString());
        paramParcel2.writeNoException();
        int i17 = 0;
        if (bool17) {
          i17 = 1;
        }
        paramParcel2.writeInt(i17);
        return true;
      case 9: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        String str4 = getName();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str4);
        return true;
      case 10: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        int i16 = getScanMode();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i16);
        return true;
      case 11: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        boolean bool16 = setScanMode(paramParcel1.readInt(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        int i15 = 0;
        if (bool16) {
          i15 = 1;
        }
        paramParcel2.writeInt(i15);
        return true;
      case 12: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        int i14 = getDiscoverableTimeout();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i14);
        return true;
      case 13: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        boolean bool15 = setDiscoverableTimeout(paramParcel1.readInt());
        paramParcel2.writeNoException();
        int i13 = 0;
        if (bool15) {
          i13 = 1;
        }
        paramParcel2.writeInt(i13);
        return true;
      case 14: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        boolean bool14 = startDiscovery();
        paramParcel2.writeNoException();
        int i12 = 0;
        if (bool14) {
          i12 = 1;
        }
        paramParcel2.writeInt(i12);
        return true;
      case 15: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        boolean bool13 = cancelDiscovery();
        paramParcel2.writeNoException();
        int i11 = 0;
        if (bool13) {
          i11 = 1;
        }
        paramParcel2.writeInt(i11);
        return true;
      case 16: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        boolean bool12 = isDiscovering();
        paramParcel2.writeNoException();
        int i10 = 0;
        if (bool12) {
          i10 = 1;
        }
        paramParcel2.writeInt(i10);
        return true;
      case 17: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        int i9 = getAdapterConnectionState();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i9);
        return true;
      case 18: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        int i8 = getProfileConnectionState(paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i8);
        return true;
      case 19: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        BluetoothDevice[] arrayOfBluetoothDevice = getBondedDevices();
        paramParcel2.writeNoException();
        paramParcel2.writeTypedArray(arrayOfBluetoothDevice, 1);
        return true;
      case 20: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice15 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice15 = null)
        {
          boolean bool11 = createBond(localBluetoothDevice15);
          paramParcel2.writeNoException();
          int i7 = 0;
          if (bool11) {
            i7 = 1;
          }
          paramParcel2.writeInt(i7);
          return true;
        }
      case 21: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice14 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice14 = null)
        {
          boolean bool10 = cancelBondProcess(localBluetoothDevice14);
          paramParcel2.writeNoException();
          int i6 = 0;
          if (bool10) {
            i6 = 1;
          }
          paramParcel2.writeInt(i6);
          return true;
        }
      case 22: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice13 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice13 = null)
        {
          boolean bool9 = removeBond(localBluetoothDevice13);
          paramParcel2.writeNoException();
          int i5 = 0;
          if (bool9) {
            i5 = 1;
          }
          paramParcel2.writeInt(i5);
          return true;
        }
      case 23: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice12 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice12 = null)
        {
          int i4 = getBondState(localBluetoothDevice12);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i4);
          return true;
        }
      case 24: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice11 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice11 = null)
        {
          String str3 = getRemoteName(localBluetoothDevice11);
          paramParcel2.writeNoException();
          paramParcel2.writeString(str3);
          return true;
        }
      case 25: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice10 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice10 = null)
        {
          String str2 = getRemoteAlias(localBluetoothDevice10);
          paramParcel2.writeNoException();
          paramParcel2.writeString(str2);
          return true;
        }
      case 26: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice9 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice9 = null)
        {
          boolean bool8 = setRemoteAlias(localBluetoothDevice9, paramParcel1.readString());
          paramParcel2.writeNoException();
          int i3 = 0;
          if (bool8) {
            i3 = 1;
          }
          paramParcel2.writeInt(i3);
          return true;
        }
      case 27: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice8 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice8 = null)
        {
          int i2 = getRemoteClass(localBluetoothDevice8);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i2);
          return true;
        }
      case 28: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice7 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice7 = null)
        {
          ParcelUuid[] arrayOfParcelUuid1 = getRemoteUuids(localBluetoothDevice7);
          paramParcel2.writeNoException();
          paramParcel2.writeTypedArray(arrayOfParcelUuid1, 1);
          return true;
        }
      case 29: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice6 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice6 = null)
        {
          boolean bool7 = fetchRemoteUuids(localBluetoothDevice6);
          paramParcel2.writeNoException();
          int i1 = 0;
          if (bool7) {
            i1 = 1;
          }
          paramParcel2.writeInt(i1);
          return true;
        }
      case 30: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        BluetoothDevice localBluetoothDevice5;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice5 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label1599;
          }
        }
        for (boolean bool5 = true;; bool5 = false)
        {
          boolean bool6 = setPin(localBluetoothDevice5, bool5, paramParcel1.readInt(), paramParcel1.createByteArray());
          paramParcel2.writeNoException();
          int n = 0;
          if (bool6) {
            n = 1;
          }
          paramParcel2.writeInt(n);
          return true;
          localBluetoothDevice5 = null;
          break;
        }
      case 31: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        BluetoothDevice localBluetoothDevice4;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice4 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label1689;
          }
        }
        for (boolean bool3 = true;; bool3 = false)
        {
          boolean bool4 = setPasskey(localBluetoothDevice4, bool3, paramParcel1.readInt(), paramParcel1.createByteArray());
          paramParcel2.writeNoException();
          int m = 0;
          if (bool4) {
            m = 1;
          }
          paramParcel2.writeInt(m);
          return true;
          localBluetoothDevice4 = null;
          break;
        }
      case 32: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        BluetoothDevice localBluetoothDevice3;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice3 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          if (paramParcel1.readInt() == 0) {
            break label1771;
          }
        }
        for (boolean bool1 = true;; bool1 = false)
        {
          boolean bool2 = setPairingConfirmation(localBluetoothDevice3, bool1);
          paramParcel2.writeNoException();
          int k = 0;
          if (bool2) {
            k = 1;
          }
          paramParcel2.writeInt(k);
          return true;
          localBluetoothDevice3 = null;
          break;
        }
      case 33: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice2 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice2 = null)
        {
          sendConnectionStateChange(localBluetoothDevice2, paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      case 34: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        registerCallback(IBluetoothCallback.Stub.asInterface(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 35: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        unregisterCallback(IBluetoothCallback.Stub.asInterface(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 36: 
        label1599:
        label1689:
        label1771:
        paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
        BluetoothDevice localBluetoothDevice1;
        int j;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice1 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          j = paramParcel1.readInt();
          if (paramParcel1.readInt() == 0) {
            break label1983;
          }
        }
        label1983:
        for (ParcelUuid localParcelUuid2 = (ParcelUuid)ParcelUuid.CREATOR.createFromParcel(paramParcel1);; localParcelUuid2 = null)
        {
          ParcelFileDescriptor localParcelFileDescriptor2 = connectSocket(localBluetoothDevice1, j, localParcelUuid2, paramParcel1.readInt(), paramParcel1.readInt());
          paramParcel2.writeNoException();
          if (localParcelFileDescriptor2 == null) {
            break label1989;
          }
          paramParcel2.writeInt(1);
          localParcelFileDescriptor2.writeToParcel(paramParcel2, 1);
          return true;
          localBluetoothDevice1 = null;
          break;
        }
        label1989:
        paramParcel2.writeInt(0);
        return true;
      }
      paramParcel1.enforceInterface("android.bluetooth.IBluetooth");
      int i = paramParcel1.readInt();
      String str1 = paramParcel1.readString();
      if (paramParcel1.readInt() != 0) {}
      for (ParcelUuid localParcelUuid1 = (ParcelUuid)ParcelUuid.CREATOR.createFromParcel(paramParcel1);; localParcelUuid1 = null)
      {
        ParcelFileDescriptor localParcelFileDescriptor1 = createSocketChannel(i, str1, localParcelUuid1, paramParcel1.readInt(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        if (localParcelFileDescriptor1 == null) {
          break;
        }
        paramParcel2.writeInt(1);
        localParcelFileDescriptor1.writeToParcel(paramParcel2, 1);
        return true;
      }
      paramParcel2.writeInt(0);
      return true;
    }
    
    private static class Proxy
      implements IBluetooth
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public boolean cancelBondProcess(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(21, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean cancelDiscovery()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          this.mRemote.transact(15, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public ParcelFileDescriptor connectSocket(BluetoothDevice paramBluetoothDevice, int paramInt1, ParcelUuid paramParcelUuid, int paramInt2, int paramInt3)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              localParcel1.writeInt(paramInt1);
              if (paramParcelUuid != null)
              {
                localParcel1.writeInt(1);
                paramParcelUuid.writeToParcel(localParcel1, 0);
                localParcel1.writeInt(paramInt2);
                localParcel1.writeInt(paramInt3);
                this.mRemote.transact(36, localParcel1, localParcel2, 0);
                localParcel2.readException();
                if (localParcel2.readInt() == 0) {
                  break label162;
                }
                localParcelFileDescriptor = (ParcelFileDescriptor)ParcelFileDescriptor.CREATOR.createFromParcel(localParcel2);
                return localParcelFileDescriptor;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            localParcel1.writeInt(0);
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          continue;
          label162:
          ParcelFileDescriptor localParcelFileDescriptor = null;
        }
      }
      
      public boolean createBond(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(20, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public ParcelFileDescriptor createSocketChannel(int paramInt1, String paramString, ParcelUuid paramParcelUuid, int paramInt2, int paramInt3)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
            localParcel1.writeInt(paramInt1);
            localParcel1.writeString(paramString);
            if (paramParcelUuid != null)
            {
              localParcel1.writeInt(1);
              paramParcelUuid.writeToParcel(localParcel1, 0);
              localParcel1.writeInt(paramInt2);
              localParcel1.writeInt(paramInt3);
              this.mRemote.transact(37, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                localParcelFileDescriptor = (ParcelFileDescriptor)ParcelFileDescriptor.CREATOR.createFromParcel(localParcel2);
                return localParcelFileDescriptor;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            ParcelFileDescriptor localParcelFileDescriptor = null;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean disable()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          this.mRemote.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean enable()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          this.mRemote.transact(3, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean enableNoAutoConnect()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          this.mRemote.transact(4, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean fetchRemoteUuids(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(29, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public int getAdapterConnectionState()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          this.mRemote.transact(17, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String getAddress()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          this.mRemote.transact(6, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str = localParcel2.readString();
          return str;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public int getBondState(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +50 -> 65
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 43	android/bluetooth/BluetoothDevice:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/bluetooth/IBluetooth$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: bipush 23
        //   35: aload_2
        //   36: aload_3
        //   37: iconst_0
        //   38: invokeinterface 49 5 0
        //   43: pop
        //   44: aload_3
        //   45: invokevirtual 52	android/os/Parcel:readException	()V
        //   48: aload_3
        //   49: invokevirtual 56	android/os/Parcel:readInt	()I
        //   52: istore 6
        //   54: aload_3
        //   55: invokevirtual 59	android/os/Parcel:recycle	()V
        //   58: aload_2
        //   59: invokevirtual 59	android/os/Parcel:recycle	()V
        //   62: iload 6
        //   64: ireturn
        //   65: aload_2
        //   66: iconst_0
        //   67: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   70: goto -41 -> 29
        //   73: astore 4
        //   75: aload_3
        //   76: invokevirtual 59	android/os/Parcel:recycle	()V
        //   79: aload_2
        //   80: invokevirtual 59	android/os/Parcel:recycle	()V
        //   83: aload 4
        //   85: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	86	0	this	Proxy
        //   0	86	1	paramBluetoothDevice	BluetoothDevice
        //   3	77	2	localParcel1	Parcel
        //   7	69	3	localParcel2	Parcel
        //   73	11	4	localObject	Object
        //   52	11	6	i	int
        // Exception table:
        //   from	to	target	type
        //   8	14	73	finally
        //   18	29	73	finally
        //   29	54	73	finally
        //   65	70	73	finally
      }
      
      public BluetoothDevice[] getBondedDevices()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          this.mRemote.transact(19, localParcel1, localParcel2, 0);
          localParcel2.readException();
          BluetoothDevice[] arrayOfBluetoothDevice = (BluetoothDevice[])localParcel2.createTypedArray(BluetoothDevice.CREATOR);
          return arrayOfBluetoothDevice;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public int getDiscoverableTimeout()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          this.mRemote.transact(12, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.bluetooth.IBluetooth";
      }
      
      public String getName()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          this.mRemote.transact(9, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str = localParcel2.readString();
          return str;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public int getProfileConnectionState(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(18, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public String getRemoteAlias(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +50 -> 65
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 43	android/bluetooth/BluetoothDevice:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/bluetooth/IBluetooth$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: bipush 25
        //   35: aload_2
        //   36: aload_3
        //   37: iconst_0
        //   38: invokeinterface 49 5 0
        //   43: pop
        //   44: aload_3
        //   45: invokevirtual 52	android/os/Parcel:readException	()V
        //   48: aload_3
        //   49: invokevirtual 94	android/os/Parcel:readString	()Ljava/lang/String;
        //   52: astore 6
        //   54: aload_3
        //   55: invokevirtual 59	android/os/Parcel:recycle	()V
        //   58: aload_2
        //   59: invokevirtual 59	android/os/Parcel:recycle	()V
        //   62: aload 6
        //   64: areturn
        //   65: aload_2
        //   66: iconst_0
        //   67: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   70: goto -41 -> 29
        //   73: astore 4
        //   75: aload_3
        //   76: invokevirtual 59	android/os/Parcel:recycle	()V
        //   79: aload_2
        //   80: invokevirtual 59	android/os/Parcel:recycle	()V
        //   83: aload 4
        //   85: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	86	0	this	Proxy
        //   0	86	1	paramBluetoothDevice	BluetoothDevice
        //   3	77	2	localParcel1	Parcel
        //   7	69	3	localParcel2	Parcel
        //   73	11	4	localObject	Object
        //   52	11	6	str	String
        // Exception table:
        //   from	to	target	type
        //   8	14	73	finally
        //   18	29	73	finally
        //   29	54	73	finally
        //   65	70	73	finally
      }
      
      /* Error */
      public int getRemoteClass(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +50 -> 65
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 43	android/bluetooth/BluetoothDevice:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/bluetooth/IBluetooth$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: bipush 27
        //   35: aload_2
        //   36: aload_3
        //   37: iconst_0
        //   38: invokeinterface 49 5 0
        //   43: pop
        //   44: aload_3
        //   45: invokevirtual 52	android/os/Parcel:readException	()V
        //   48: aload_3
        //   49: invokevirtual 56	android/os/Parcel:readInt	()I
        //   52: istore 6
        //   54: aload_3
        //   55: invokevirtual 59	android/os/Parcel:recycle	()V
        //   58: aload_2
        //   59: invokevirtual 59	android/os/Parcel:recycle	()V
        //   62: iload 6
        //   64: ireturn
        //   65: aload_2
        //   66: iconst_0
        //   67: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   70: goto -41 -> 29
        //   73: astore 4
        //   75: aload_3
        //   76: invokevirtual 59	android/os/Parcel:recycle	()V
        //   79: aload_2
        //   80: invokevirtual 59	android/os/Parcel:recycle	()V
        //   83: aload 4
        //   85: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	86	0	this	Proxy
        //   0	86	1	paramBluetoothDevice	BluetoothDevice
        //   3	77	2	localParcel1	Parcel
        //   7	69	3	localParcel2	Parcel
        //   73	11	4	localObject	Object
        //   52	11	6	i	int
        // Exception table:
        //   from	to	target	type
        //   8	14	73	finally
        //   18	29	73	finally
        //   29	54	73	finally
        //   65	70	73	finally
      }
      
      /* Error */
      public String getRemoteName(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +50 -> 65
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 43	android/bluetooth/BluetoothDevice:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/bluetooth/IBluetooth$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: bipush 24
        //   35: aload_2
        //   36: aload_3
        //   37: iconst_0
        //   38: invokeinterface 49 5 0
        //   43: pop
        //   44: aload_3
        //   45: invokevirtual 52	android/os/Parcel:readException	()V
        //   48: aload_3
        //   49: invokevirtual 94	android/os/Parcel:readString	()Ljava/lang/String;
        //   52: astore 6
        //   54: aload_3
        //   55: invokevirtual 59	android/os/Parcel:recycle	()V
        //   58: aload_2
        //   59: invokevirtual 59	android/os/Parcel:recycle	()V
        //   62: aload 6
        //   64: areturn
        //   65: aload_2
        //   66: iconst_0
        //   67: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   70: goto -41 -> 29
        //   73: astore 4
        //   75: aload_3
        //   76: invokevirtual 59	android/os/Parcel:recycle	()V
        //   79: aload_2
        //   80: invokevirtual 59	android/os/Parcel:recycle	()V
        //   83: aload 4
        //   85: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	86	0	this	Proxy
        //   0	86	1	paramBluetoothDevice	BluetoothDevice
        //   3	77	2	localParcel1	Parcel
        //   7	69	3	localParcel2	Parcel
        //   73	11	4	localObject	Object
        //   52	11	6	str	String
        // Exception table:
        //   from	to	target	type
        //   8	14	73	finally
        //   18	29	73	finally
        //   29	54	73	finally
        //   65	70	73	finally
      }
      
      /* Error */
      public ParcelUuid[] getRemoteUuids(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +56 -> 71
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 43	android/bluetooth/BluetoothDevice:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/bluetooth/IBluetooth$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: bipush 28
        //   35: aload_2
        //   36: aload_3
        //   37: iconst_0
        //   38: invokeinterface 49 5 0
        //   43: pop
        //   44: aload_3
        //   45: invokevirtual 52	android/os/Parcel:readException	()V
        //   48: aload_3
        //   49: getstatic 117	android/os/ParcelUuid:CREATOR	Landroid/os/Parcelable$Creator;
        //   52: invokevirtual 103	android/os/Parcel:createTypedArray	(Landroid/os/Parcelable$Creator;)[Ljava/lang/Object;
        //   55: checkcast 119	[Landroid/os/ParcelUuid;
        //   58: astore 6
        //   60: aload_3
        //   61: invokevirtual 59	android/os/Parcel:recycle	()V
        //   64: aload_2
        //   65: invokevirtual 59	android/os/Parcel:recycle	()V
        //   68: aload 6
        //   70: areturn
        //   71: aload_2
        //   72: iconst_0
        //   73: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   76: goto -47 -> 29
        //   79: astore 4
        //   81: aload_3
        //   82: invokevirtual 59	android/os/Parcel:recycle	()V
        //   85: aload_2
        //   86: invokevirtual 59	android/os/Parcel:recycle	()V
        //   89: aload 4
        //   91: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	92	0	this	Proxy
        //   0	92	1	paramBluetoothDevice	BluetoothDevice
        //   3	83	2	localParcel1	Parcel
        //   7	75	3	localParcel2	Parcel
        //   79	11	4	localObject	Object
        //   58	11	6	arrayOfParcelUuid	ParcelUuid[]
        // Exception table:
        //   from	to	target	type
        //   8	14	79	finally
        //   18	29	79	finally
        //   29	60	79	finally
        //   71	76	79	finally
      }
      
      public int getScanMode()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          this.mRemote.transact(10, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public int getState()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          this.mRemote.transact(2, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public ParcelUuid[] getUuids()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          this.mRemote.transact(7, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ParcelUuid[] arrayOfParcelUuid = (ParcelUuid[])localParcel2.createTypedArray(ParcelUuid.CREATOR);
          return arrayOfParcelUuid;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean isDiscovering()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          this.mRemote.transact(16, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public boolean isEnabled()
        throws RemoteException
      {
        // Byte code:
        //   0: iconst_1
        //   1: istore_1
        //   2: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   5: astore_2
        //   6: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   9: astore_3
        //   10: aload_2
        //   11: ldc 29
        //   13: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   16: aload_0
        //   17: getfield 15	android/bluetooth/IBluetooth$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   20: iconst_1
        //   21: aload_2
        //   22: aload_3
        //   23: iconst_0
        //   24: invokeinterface 49 5 0
        //   29: pop
        //   30: aload_3
        //   31: invokevirtual 52	android/os/Parcel:readException	()V
        //   34: aload_3
        //   35: invokevirtual 56	android/os/Parcel:readInt	()I
        //   38: istore 6
        //   40: iload 6
        //   42: ifeq +13 -> 55
        //   45: aload_3
        //   46: invokevirtual 59	android/os/Parcel:recycle	()V
        //   49: aload_2
        //   50: invokevirtual 59	android/os/Parcel:recycle	()V
        //   53: iload_1
        //   54: ireturn
        //   55: iconst_0
        //   56: istore_1
        //   57: goto -12 -> 45
        //   60: astore 4
        //   62: aload_3
        //   63: invokevirtual 59	android/os/Parcel:recycle	()V
        //   66: aload_2
        //   67: invokevirtual 59	android/os/Parcel:recycle	()V
        //   70: aload 4
        //   72: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	73	0	this	Proxy
        //   1	56	1	bool	boolean
        //   5	62	2	localParcel1	Parcel
        //   9	54	3	localParcel2	Parcel
        //   60	11	4	localObject	Object
        //   38	3	6	i	int
        // Exception table:
        //   from	to	target	type
        //   10	40	60	finally
      }
      
      /* Error */
      public void registerCallback(IBluetoothCallback paramIBluetoothCallback)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +45 -> 60
        //   18: aload_1
        //   19: invokeinterface 131 1 0
        //   24: astore 5
        //   26: aload_2
        //   27: aload 5
        //   29: invokevirtual 134	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   32: aload_0
        //   33: getfield 15	android/bluetooth/IBluetooth$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   36: bipush 34
        //   38: aload_2
        //   39: aload_3
        //   40: iconst_0
        //   41: invokeinterface 49 5 0
        //   46: pop
        //   47: aload_3
        //   48: invokevirtual 52	android/os/Parcel:readException	()V
        //   51: aload_3
        //   52: invokevirtual 59	android/os/Parcel:recycle	()V
        //   55: aload_2
        //   56: invokevirtual 59	android/os/Parcel:recycle	()V
        //   59: return
        //   60: aconst_null
        //   61: astore 5
        //   63: goto -37 -> 26
        //   66: astore 4
        //   68: aload_3
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: aload_2
        //   73: invokevirtual 59	android/os/Parcel:recycle	()V
        //   76: aload 4
        //   78: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	79	0	this	Proxy
        //   0	79	1	paramIBluetoothCallback	IBluetoothCallback
        //   3	70	2	localParcel1	Parcel
        //   7	62	3	localParcel2	Parcel
        //   66	11	4	localObject	Object
        //   24	38	5	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   8	14	66	finally
        //   18	26	66	finally
        //   26	51	66	finally
      }
      
      public boolean removeBond(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(22, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      /* Error */
      public void sendConnectionStateChange(BluetoothDevice paramBluetoothDevice, int paramInt1, int paramInt2, int paramInt3)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore 5
        //   5: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   8: astore 6
        //   10: aload 5
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: aload_1
        //   18: ifnull +68 -> 86
        //   21: aload 5
        //   23: iconst_1
        //   24: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   27: aload_1
        //   28: aload 5
        //   30: iconst_0
        //   31: invokevirtual 43	android/bluetooth/BluetoothDevice:writeToParcel	(Landroid/os/Parcel;I)V
        //   34: aload 5
        //   36: iload_2
        //   37: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   40: aload 5
        //   42: iload_3
        //   43: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   46: aload 5
        //   48: iload 4
        //   50: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   53: aload_0
        //   54: getfield 15	android/bluetooth/IBluetooth$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   57: bipush 33
        //   59: aload 5
        //   61: aload 6
        //   63: iconst_0
        //   64: invokeinterface 49 5 0
        //   69: pop
        //   70: aload 6
        //   72: invokevirtual 52	android/os/Parcel:readException	()V
        //   75: aload 6
        //   77: invokevirtual 59	android/os/Parcel:recycle	()V
        //   80: aload 5
        //   82: invokevirtual 59	android/os/Parcel:recycle	()V
        //   85: return
        //   86: aload 5
        //   88: iconst_0
        //   89: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   92: goto -58 -> 34
        //   95: astore 7
        //   97: aload 6
        //   99: invokevirtual 59	android/os/Parcel:recycle	()V
        //   102: aload 5
        //   104: invokevirtual 59	android/os/Parcel:recycle	()V
        //   107: aload 7
        //   109: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	110	0	this	Proxy
        //   0	110	1	paramBluetoothDevice	BluetoothDevice
        //   0	110	2	paramInt1	int
        //   0	110	3	paramInt2	int
        //   0	110	4	paramInt3	int
        //   3	100	5	localParcel1	Parcel
        //   8	90	6	localParcel2	Parcel
        //   95	13	7	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   10	17	95	finally
        //   21	34	95	finally
        //   34	75	95	finally
        //   86	92	95	finally
      }
      
      public boolean setDiscoverableTimeout(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          localParcel1.writeInt(paramInt);
          this.mRemote.transact(13, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean setName(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          localParcel1.writeString(paramString);
          this.mRemote.transact(8, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean setPairingConfirmation(BluetoothDevice paramBluetoothDevice, boolean paramBoolean)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              break label127;
              localParcel1.writeInt(j);
              this.mRemote.transact(32, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int k = localParcel2.readInt();
              if (k != 0) {
                label80:
                return i;
              }
            }
            else
            {
              localParcel1.writeInt(0);
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          label127:
          do
          {
            j = 0;
            break;
            i = 0;
            break label80;
          } while (!paramBoolean);
          int j = i;
        }
      }
      
      public boolean setPasskey(BluetoothDevice paramBluetoothDevice, boolean paramBoolean, int paramInt, byte[] paramArrayOfByte)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              break label143;
              localParcel1.writeInt(j);
              localParcel1.writeInt(paramInt);
              localParcel1.writeByteArray(paramArrayOfByte);
              this.mRemote.transact(31, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int k = localParcel2.readInt();
              if (k != 0) {
                label94:
                return i;
              }
            }
            else
            {
              localParcel1.writeInt(0);
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          label143:
          do
          {
            j = 0;
            break;
            i = 0;
            break label94;
          } while (!paramBoolean);
          int j = i;
        }
      }
      
      public boolean setPin(BluetoothDevice paramBluetoothDevice, boolean paramBoolean, int paramInt, byte[] paramArrayOfByte)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              break label143;
              localParcel1.writeInt(j);
              localParcel1.writeInt(paramInt);
              localParcel1.writeByteArray(paramArrayOfByte);
              this.mRemote.transact(30, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int k = localParcel2.readInt();
              if (k != 0) {
                label94:
                return i;
              }
            }
            else
            {
              localParcel1.writeInt(0);
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          label143:
          do
          {
            j = 0;
            break;
            i = 0;
            break label94;
          } while (!paramBoolean);
          int j = i;
        }
      }
      
      public boolean setRemoteAlias(BluetoothDevice paramBluetoothDevice, String paramString)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              localParcel1.writeString(paramString);
              this.mRemote.transact(26, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean setScanMode(int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          this.mRemote.transact(11, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean startDiscovery()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetooth");
          this.mRemote.transact(14, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public void unregisterCallback(IBluetoothCallback paramIBluetoothCallback)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +45 -> 60
        //   18: aload_1
        //   19: invokeinterface 131 1 0
        //   24: astore 5
        //   26: aload_2
        //   27: aload 5
        //   29: invokevirtual 134	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   32: aload_0
        //   33: getfield 15	android/bluetooth/IBluetooth$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   36: bipush 35
        //   38: aload_2
        //   39: aload_3
        //   40: iconst_0
        //   41: invokeinterface 49 5 0
        //   46: pop
        //   47: aload_3
        //   48: invokevirtual 52	android/os/Parcel:readException	()V
        //   51: aload_3
        //   52: invokevirtual 59	android/os/Parcel:recycle	()V
        //   55: aload_2
        //   56: invokevirtual 59	android/os/Parcel:recycle	()V
        //   59: return
        //   60: aconst_null
        //   61: astore 5
        //   63: goto -37 -> 26
        //   66: astore 4
        //   68: aload_3
        //   69: invokevirtual 59	android/os/Parcel:recycle	()V
        //   72: aload_2
        //   73: invokevirtual 59	android/os/Parcel:recycle	()V
        //   76: aload 4
        //   78: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	79	0	this	Proxy
        //   0	79	1	paramIBluetoothCallback	IBluetoothCallback
        //   3	70	2	localParcel1	Parcel
        //   7	62	3	localParcel2	Parcel
        //   66	11	4	localObject	Object
        //   24	38	5	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   8	14	66	finally
        //   18	26	66	finally
        //   26	51	66	finally
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\bluetooth\IBluetooth.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.bluetooth;

import android.content.Context;
import android.net.LinkAddress;
import android.net.LinkCapabilities;
import android.net.LinkProperties;
import android.net.NetworkInfo;
import android.net.NetworkInfo.DetailedState;
import android.net.NetworkStateTracker;
import android.net.NetworkUtils;
import android.net.RouteInfo;
import android.os.Handler;
import android.os.Message;
import android.os.SystemProperties;
import android.util.Log;
import java.net.InetAddress;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class BluetoothTetheringDataTracker
  implements NetworkStateTracker
{
  private static final boolean DBG = true;
  private static final String NETWORKTYPE = "BLUETOOTH_TETHER";
  private static final String TAG = "BluetoothTethering";
  private static final boolean VDBG;
  private static String mIface;
  public static BluetoothTetheringDataTracker sInstance;
  private BluetoothPan mBluetoothPan;
  private Context mContext;
  private Handler mCsHandler;
  private AtomicInteger mDefaultGatewayAddr = new AtomicInteger(0);
  private AtomicBoolean mDefaultRouteSet = new AtomicBoolean(false);
  private Thread mDhcpThread;
  private LinkCapabilities mLinkCapabilities = new LinkCapabilities();
  private LinkProperties mLinkProperties = new LinkProperties();
  private NetworkInfo mNetworkInfo = new NetworkInfo(7, 0, "BLUETOOTH_TETHER", "");
  private AtomicBoolean mPrivateDnsRouteSet = new AtomicBoolean(false);
  private BluetoothProfile.ServiceListener mProfileServiceListener = new BluetoothProfile.ServiceListener()
  {
    public void onServiceConnected(int paramAnonymousInt, BluetoothProfile paramAnonymousBluetoothProfile)
    {
      BluetoothTetheringDataTracker.access$002(BluetoothTetheringDataTracker.this, (BluetoothPan)paramAnonymousBluetoothProfile);
    }
    
    public void onServiceDisconnected(int paramAnonymousInt)
    {
      BluetoothTetheringDataTracker.access$002(BluetoothTetheringDataTracker.this, null);
    }
  };
  private AtomicBoolean mTeardownRequested = new AtomicBoolean(false);
  
  private BluetoothTetheringDataTracker()
  {
    this.mNetworkInfo.setIsAvailable(false);
    setTeardownRequested(false);
  }
  
  private static short countPrefixLength(byte[] paramArrayOfByte)
  {
    short s = 0;
    int i = paramArrayOfByte.length;
    for (int j = 0; j < i; j++)
    {
      int k = paramArrayOfByte[j];
      for (int m = 0; m < 8; m++) {
        if ((k & 1 << m) != 0) {
          s = (short)(s + 1);
        }
      }
    }
    return s;
  }
  
  public static BluetoothTetheringDataTracker getInstance()
  {
    try
    {
      if (sInstance == null) {
        sInstance = new BluetoothTetheringDataTracker();
      }
      BluetoothTetheringDataTracker localBluetoothTetheringDataTracker = sInstance;
      return localBluetoothTetheringDataTracker;
    }
    finally {}
  }
  
  private boolean readLinkProperty(String paramString)
  {
    String str1 = "dhcp." + paramString + ".";
    String str2 = SystemProperties.get(str1 + "ipaddress");
    String str3 = SystemProperties.get(str1 + "dns1");
    String str4 = SystemProperties.get(str1 + "dns2");
    String str5 = SystemProperties.get(str1 + "gateway");
    String str6 = SystemProperties.get(str1 + "mask");
    if ((str2.isEmpty()) || (str5.isEmpty()))
    {
      Log.e("BluetoothTethering", "readLinkProperty, ip: " + str2 + ", gateway: " + str5 + ", can not be empty");
      return false;
    }
    int i = countPrefixLength(NetworkUtils.numericToInetAddress(str6).getAddress());
    this.mLinkProperties.addLinkAddress(new LinkAddress(NetworkUtils.numericToInetAddress(str2), i));
    RouteInfo localRouteInfo = new RouteInfo(NetworkUtils.numericToInetAddress(str5));
    this.mLinkProperties.addRoute(localRouteInfo);
    if (!str3.isEmpty()) {
      this.mLinkProperties.addDns(NetworkUtils.numericToInetAddress(str3));
    }
    if (!str4.isEmpty()) {
      this.mLinkProperties.addDns(NetworkUtils.numericToInetAddress(str4));
    }
    this.mLinkProperties.setInterfaceName(paramString);
    return true;
  }
  
  public Object Clone()
    throws CloneNotSupportedException
  {
    throw new CloneNotSupportedException();
  }
  
  public void captivePortalCheckComplete() {}
  
  public void defaultRouteSet(boolean paramBoolean)
  {
    this.mDefaultRouteSet.set(paramBoolean);
  }
  
  public int getDefaultGatewayAddr()
  {
    return this.mDefaultGatewayAddr.get();
  }
  
  public LinkCapabilities getLinkCapabilities()
  {
    return new LinkCapabilities(this.mLinkCapabilities);
  }
  
  public LinkProperties getLinkProperties()
  {
    try
    {
      LinkProperties localLinkProperties = new LinkProperties(this.mLinkProperties);
      return localLinkProperties;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public NetworkInfo getNetworkInfo()
  {
    try
    {
      NetworkInfo localNetworkInfo = this.mNetworkInfo;
      return localNetworkInfo;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public String getTcpBufferSizesPropName()
  {
    return "net.tcp.buffersize.wifi";
  }
  
  public boolean isAvailable()
  {
    try
    {
      boolean bool = this.mNetworkInfo.isAvailable();
      return bool;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public boolean isDefaultRouteSet()
  {
    return this.mDefaultRouteSet.get();
  }
  
  public boolean isPrivateDnsRouteSet()
  {
    return this.mPrivateDnsRouteSet.get();
  }
  
  public boolean isTeardownRequested()
  {
    return this.mTeardownRequested.get();
  }
  
  public void privateDnsRouteSet(boolean paramBoolean)
  {
    this.mPrivateDnsRouteSet.set(paramBoolean);
  }
  
  public boolean reconnect()
  {
    this.mTeardownRequested.set(false);
    return true;
  }
  
  public void setDependencyMet(boolean paramBoolean) {}
  
  public void setPolicyDataEnable(boolean paramBoolean)
  {
    Log.w("BluetoothTethering", "ignoring setPolicyDataEnable(" + paramBoolean + ")");
  }
  
  public boolean setRadio(boolean paramBoolean)
  {
    return true;
  }
  
  public void setTeardownRequested(boolean paramBoolean)
  {
    this.mTeardownRequested.set(paramBoolean);
  }
  
  public void setUserDataEnable(boolean paramBoolean)
  {
    Log.w("BluetoothTethering", "ignoring setUserDataEnable(" + paramBoolean + ")");
  }
  
  public void startMonitoring(Context paramContext, Handler paramHandler)
  {
    Log.d("BluetoothTethering", "startMonitoring: target: " + paramHandler);
    this.mContext = paramContext;
    this.mCsHandler = paramHandler;
    BluetoothAdapter localBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    if (localBluetoothAdapter != null) {
      localBluetoothAdapter.getProfileProxy(this.mContext, this.mProfileServiceListener, 5);
    }
  }
  
  public void startReverseTether(String paramString)
  {
    try
    {
      mIface = paramString;
      Log.d("BluetoothTethering", "startReverseTether mCsHandler: " + this.mCsHandler);
      this.mDhcpThread = new Thread(new Runnable()
      {
        public void run()
        {
          Log.d("BluetoothTethering", "startReverseTether mCsHandler: " + BluetoothTetheringDataTracker.this.mCsHandler);
          String str1 = "dhcp." + BluetoothTetheringDataTracker.mIface + ".result";
          String str2 = "";
          for (int i = 0; i < 150; i++)
          {
            do
            {
              do
              {
                try
                {
                  Thread.sleep(200L);
                  str2 = SystemProperties.get(str1);
                  if (str2.equals("failed"))
                  {
                    Log.e("BluetoothTethering", "startReverseTether, failed to start dhcp service");
                    return;
                  }
                }
                catch (InterruptedException localInterruptedException)
                {
                  return;
                }
                if (!str2.equals("ok")) {
                  break;
                }
              } while (!BluetoothTetheringDataTracker.this.readLinkProperty(BluetoothTetheringDataTracker.mIface));
              BluetoothTetheringDataTracker.this.mNetworkInfo.setIsAvailable(true);
              BluetoothTetheringDataTracker.this.mNetworkInfo.setDetailedState(NetworkInfo.DetailedState.CONNECTED, null, null);
            } while (BluetoothTetheringDataTracker.this.mCsHandler == null);
            BluetoothTetheringDataTracker.this.mCsHandler.obtainMessage(3, BluetoothTetheringDataTracker.this.mNetworkInfo).sendToTarget();
            BluetoothTetheringDataTracker.this.mCsHandler.obtainMessage(1, BluetoothTetheringDataTracker.this.mNetworkInfo).sendToTarget();
            return;
          }
          Log.e("BluetoothTethering", "startReverseTether, dhcp failed, resut: " + str2);
        }
      });
      this.mDhcpThread.start();
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public int startUsingNetworkFeature(String paramString, int paramInt1, int paramInt2)
  {
    return -1;
  }
  
  public void stopReverseTether()
  {
    try
    {
      if ((this.mDhcpThread != null) && (this.mDhcpThread.isAlive())) {
        this.mDhcpThread.interrupt();
      }
      try
      {
        this.mDhcpThread.join();
        this.mLinkProperties.clear();
        this.mNetworkInfo.setIsAvailable(false);
        this.mNetworkInfo.setDetailedState(NetworkInfo.DetailedState.DISCONNECTED, null, null);
        this.mCsHandler.obtainMessage(3, this.mNetworkInfo).sendToTarget();
        this.mCsHandler.obtainMessage(1, this.mNetworkInfo).sendToTarget();
      }
      catch (InterruptedException localInterruptedException)
      {
        for (;;) {}
      }
      return;
    }
    finally {}
  }
  
  public int stopUsingNetworkFeature(String paramString, int paramInt1, int paramInt2)
  {
    return -1;
  }
  
  public boolean teardown()
  {
    this.mTeardownRequested.set(true);
    if (this.mBluetoothPan != null)
    {
      Iterator localIterator = this.mBluetoothPan.getConnectedDevices().iterator();
      while (localIterator.hasNext())
      {
        BluetoothDevice localBluetoothDevice = (BluetoothDevice)localIterator.next();
        this.mBluetoothPan.disconnect(localBluetoothDevice);
      }
    }
    return true;
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\bluetooth\BluetoothTetheringDataTracker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
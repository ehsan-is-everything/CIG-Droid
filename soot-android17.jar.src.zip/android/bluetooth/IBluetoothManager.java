package android.bluetooth;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface IBluetoothManager
  extends IInterface
{
  public abstract boolean disable(boolean paramBoolean)
    throws RemoteException;
  
  public abstract boolean enable()
    throws RemoteException;
  
  public abstract boolean enableNoAutoConnect()
    throws RemoteException;
  
  public abstract String getAddress()
    throws RemoteException;
  
  public abstract String getName()
    throws RemoteException;
  
  public abstract boolean isEnabled()
    throws RemoteException;
  
  public abstract IBluetooth registerAdapter(IBluetoothManagerCallback paramIBluetoothManagerCallback)
    throws RemoteException;
  
  public abstract void registerStateChangeCallback(IBluetoothStateChangeCallback paramIBluetoothStateChangeCallback)
    throws RemoteException;
  
  public abstract void unregisterAdapter(IBluetoothManagerCallback paramIBluetoothManagerCallback)
    throws RemoteException;
  
  public abstract void unregisterStateChangeCallback(IBluetoothStateChangeCallback paramIBluetoothStateChangeCallback)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IBluetoothManager
  {
    private static final String DESCRIPTOR = "android.bluetooth.IBluetoothManager";
    static final int TRANSACTION_disable = 8;
    static final int TRANSACTION_enable = 6;
    static final int TRANSACTION_enableNoAutoConnect = 7;
    static final int TRANSACTION_getAddress = 9;
    static final int TRANSACTION_getName = 10;
    static final int TRANSACTION_isEnabled = 5;
    static final int TRANSACTION_registerAdapter = 1;
    static final int TRANSACTION_registerStateChangeCallback = 3;
    static final int TRANSACTION_unregisterAdapter = 2;
    static final int TRANSACTION_unregisterStateChangeCallback = 4;
    
    public Stub()
    {
      attachInterface(this, "android.bluetooth.IBluetoothManager");
    }
    
    public static IBluetoothManager asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.bluetooth.IBluetoothManager");
      if ((localIInterface != null) && ((localIInterface instanceof IBluetoothManager))) {
        return (IBluetoothManager)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.bluetooth.IBluetoothManager");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothManager");
        IBluetooth localIBluetooth = registerAdapter(IBluetoothManagerCallback.Stub.asInterface(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        if (localIBluetooth != null) {}
        for (IBinder localIBinder = localIBluetooth.asBinder();; localIBinder = null)
        {
          paramParcel2.writeStrongBinder(localIBinder);
          return true;
        }
      case 2: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothManager");
        unregisterAdapter(IBluetoothManagerCallback.Stub.asInterface(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 3: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothManager");
        registerStateChangeCallback(IBluetoothStateChangeCallback.Stub.asInterface(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 4: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothManager");
        unregisterStateChangeCallback(IBluetoothStateChangeCallback.Stub.asInterface(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 5: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothManager");
        boolean bool5 = isEnabled();
        paramParcel2.writeNoException();
        int m = 0;
        if (bool5) {
          m = 1;
        }
        paramParcel2.writeInt(m);
        return true;
      case 6: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothManager");
        boolean bool4 = enable();
        paramParcel2.writeNoException();
        int k = 0;
        if (bool4) {
          k = 1;
        }
        paramParcel2.writeInt(k);
        return true;
      case 7: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothManager");
        boolean bool3 = enableNoAutoConnect();
        paramParcel2.writeNoException();
        int j = 0;
        if (bool3) {
          j = 1;
        }
        paramParcel2.writeInt(j);
        return true;
      case 8: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothManager");
        if (paramParcel1.readInt() != 0) {}
        for (boolean bool1 = true;; bool1 = false)
        {
          boolean bool2 = disable(bool1);
          paramParcel2.writeNoException();
          int i = 0;
          if (bool2) {
            i = 1;
          }
          paramParcel2.writeInt(i);
          return true;
        }
      case 9: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothManager");
        String str2 = getAddress();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str2);
        return true;
      }
      paramParcel1.enforceInterface("android.bluetooth.IBluetoothManager");
      String str1 = getName();
      paramParcel2.writeNoException();
      paramParcel2.writeString(str1);
      return true;
    }
    
    private static class Proxy
      implements IBluetoothManager
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      /* Error */
      public boolean disable(boolean paramBoolean)
        throws RemoteException
      {
        // Byte code:
        //   0: iconst_1
        //   1: istore_2
        //   2: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   5: astore_3
        //   6: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   9: astore 4
        //   11: aload_3
        //   12: ldc 29
        //   14: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   17: iload_1
        //   18: ifeq +56 -> 74
        //   21: iload_2
        //   22: istore 6
        //   24: aload_3
        //   25: iload 6
        //   27: invokevirtual 37	android/os/Parcel:writeInt	(I)V
        //   30: aload_0
        //   31: getfield 15	android/bluetooth/IBluetoothManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   34: bipush 8
        //   36: aload_3
        //   37: aload 4
        //   39: iconst_0
        //   40: invokeinterface 43 5 0
        //   45: pop
        //   46: aload 4
        //   48: invokevirtual 46	android/os/Parcel:readException	()V
        //   51: aload 4
        //   53: invokevirtual 50	android/os/Parcel:readInt	()I
        //   56: istore 8
        //   58: iload 8
        //   60: ifeq +20 -> 80
        //   63: aload 4
        //   65: invokevirtual 53	android/os/Parcel:recycle	()V
        //   68: aload_3
        //   69: invokevirtual 53	android/os/Parcel:recycle	()V
        //   72: iload_2
        //   73: ireturn
        //   74: iconst_0
        //   75: istore 6
        //   77: goto -53 -> 24
        //   80: iconst_0
        //   81: istore_2
        //   82: goto -19 -> 63
        //   85: astore 5
        //   87: aload 4
        //   89: invokevirtual 53	android/os/Parcel:recycle	()V
        //   92: aload_3
        //   93: invokevirtual 53	android/os/Parcel:recycle	()V
        //   96: aload 5
        //   98: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	99	0	this	Proxy
        //   0	99	1	paramBoolean	boolean
        //   1	81	2	i	int
        //   5	88	3	localParcel1	Parcel
        //   9	79	4	localParcel2	Parcel
        //   85	12	5	localObject	Object
        //   22	4	6	j	int
        //   75	1	6	k	int
        //   56	3	8	m	int
        // Exception table:
        //   from	to	target	type
        //   11	17	85	finally
        //   24	58	85	finally
      }
      
      public boolean enable()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothManager");
          this.mRemote.transact(6, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean enableNoAutoConnect()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothManager");
          this.mRemote.transact(7, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String getAddress()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothManager");
          this.mRemote.transact(9, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str = localParcel2.readString();
          return str;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.bluetooth.IBluetoothManager";
      }
      
      public String getName()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothManager");
          this.mRemote.transact(10, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str = localParcel2.readString();
          return str;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean isEnabled()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothManager");
          this.mRemote.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public IBluetooth registerAdapter(IBluetoothManagerCallback paramIBluetoothManagerCallback)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +55 -> 70
        //   18: aload_1
        //   19: invokeinterface 70 1 0
        //   24: astore 5
        //   26: aload_2
        //   27: aload 5
        //   29: invokevirtual 73	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   32: aload_0
        //   33: getfield 15	android/bluetooth/IBluetoothManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   36: iconst_1
        //   37: aload_2
        //   38: aload_3
        //   39: iconst_0
        //   40: invokeinterface 43 5 0
        //   45: pop
        //   46: aload_3
        //   47: invokevirtual 46	android/os/Parcel:readException	()V
        //   50: aload_3
        //   51: invokevirtual 76	android/os/Parcel:readStrongBinder	()Landroid/os/IBinder;
        //   54: invokestatic 82	android/bluetooth/IBluetooth$Stub:asInterface	(Landroid/os/IBinder;)Landroid/bluetooth/IBluetooth;
        //   57: astore 7
        //   59: aload_3
        //   60: invokevirtual 53	android/os/Parcel:recycle	()V
        //   63: aload_2
        //   64: invokevirtual 53	android/os/Parcel:recycle	()V
        //   67: aload 7
        //   69: areturn
        //   70: aconst_null
        //   71: astore 5
        //   73: goto -47 -> 26
        //   76: astore 4
        //   78: aload_3
        //   79: invokevirtual 53	android/os/Parcel:recycle	()V
        //   82: aload_2
        //   83: invokevirtual 53	android/os/Parcel:recycle	()V
        //   86: aload 4
        //   88: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	89	0	this	Proxy
        //   0	89	1	paramIBluetoothManagerCallback	IBluetoothManagerCallback
        //   3	80	2	localParcel1	Parcel
        //   7	72	3	localParcel2	Parcel
        //   76	11	4	localObject	Object
        //   24	48	5	localIBinder	IBinder
        //   57	11	7	localIBluetooth	IBluetooth
        // Exception table:
        //   from	to	target	type
        //   8	14	76	finally
        //   18	26	76	finally
        //   26	59	76	finally
      }
      
      /* Error */
      public void registerStateChangeCallback(IBluetoothStateChangeCallback paramIBluetoothStateChangeCallback)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +44 -> 59
        //   18: aload_1
        //   19: invokeinterface 87 1 0
        //   24: astore 5
        //   26: aload_2
        //   27: aload 5
        //   29: invokevirtual 73	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   32: aload_0
        //   33: getfield 15	android/bluetooth/IBluetoothManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   36: iconst_3
        //   37: aload_2
        //   38: aload_3
        //   39: iconst_0
        //   40: invokeinterface 43 5 0
        //   45: pop
        //   46: aload_3
        //   47: invokevirtual 46	android/os/Parcel:readException	()V
        //   50: aload_3
        //   51: invokevirtual 53	android/os/Parcel:recycle	()V
        //   54: aload_2
        //   55: invokevirtual 53	android/os/Parcel:recycle	()V
        //   58: return
        //   59: aconst_null
        //   60: astore 5
        //   62: goto -36 -> 26
        //   65: astore 4
        //   67: aload_3
        //   68: invokevirtual 53	android/os/Parcel:recycle	()V
        //   71: aload_2
        //   72: invokevirtual 53	android/os/Parcel:recycle	()V
        //   75: aload 4
        //   77: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	78	0	this	Proxy
        //   0	78	1	paramIBluetoothStateChangeCallback	IBluetoothStateChangeCallback
        //   3	69	2	localParcel1	Parcel
        //   7	61	3	localParcel2	Parcel
        //   65	11	4	localObject	Object
        //   24	37	5	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   8	14	65	finally
        //   18	26	65	finally
        //   26	50	65	finally
      }
      
      /* Error */
      public void unregisterAdapter(IBluetoothManagerCallback paramIBluetoothManagerCallback)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +44 -> 59
        //   18: aload_1
        //   19: invokeinterface 70 1 0
        //   24: astore 5
        //   26: aload_2
        //   27: aload 5
        //   29: invokevirtual 73	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   32: aload_0
        //   33: getfield 15	android/bluetooth/IBluetoothManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   36: iconst_2
        //   37: aload_2
        //   38: aload_3
        //   39: iconst_0
        //   40: invokeinterface 43 5 0
        //   45: pop
        //   46: aload_3
        //   47: invokevirtual 46	android/os/Parcel:readException	()V
        //   50: aload_3
        //   51: invokevirtual 53	android/os/Parcel:recycle	()V
        //   54: aload_2
        //   55: invokevirtual 53	android/os/Parcel:recycle	()V
        //   58: return
        //   59: aconst_null
        //   60: astore 5
        //   62: goto -36 -> 26
        //   65: astore 4
        //   67: aload_3
        //   68: invokevirtual 53	android/os/Parcel:recycle	()V
        //   71: aload_2
        //   72: invokevirtual 53	android/os/Parcel:recycle	()V
        //   75: aload 4
        //   77: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	78	0	this	Proxy
        //   0	78	1	paramIBluetoothManagerCallback	IBluetoothManagerCallback
        //   3	69	2	localParcel1	Parcel
        //   7	61	3	localParcel2	Parcel
        //   65	11	4	localObject	Object
        //   24	37	5	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   8	14	65	finally
        //   18	26	65	finally
        //   26	50	65	finally
      }
      
      /* Error */
      public void unregisterStateChangeCallback(IBluetoothStateChangeCallback paramIBluetoothStateChangeCallback)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 27	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 29
        //   11: invokevirtual 33	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +44 -> 59
        //   18: aload_1
        //   19: invokeinterface 87 1 0
        //   24: astore 5
        //   26: aload_2
        //   27: aload 5
        //   29: invokevirtual 73	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   32: aload_0
        //   33: getfield 15	android/bluetooth/IBluetoothManager$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   36: iconst_4
        //   37: aload_2
        //   38: aload_3
        //   39: iconst_0
        //   40: invokeinterface 43 5 0
        //   45: pop
        //   46: aload_3
        //   47: invokevirtual 46	android/os/Parcel:readException	()V
        //   50: aload_3
        //   51: invokevirtual 53	android/os/Parcel:recycle	()V
        //   54: aload_2
        //   55: invokevirtual 53	android/os/Parcel:recycle	()V
        //   58: return
        //   59: aconst_null
        //   60: astore 5
        //   62: goto -36 -> 26
        //   65: astore 4
        //   67: aload_3
        //   68: invokevirtual 53	android/os/Parcel:recycle	()V
        //   71: aload_2
        //   72: invokevirtual 53	android/os/Parcel:recycle	()V
        //   75: aload 4
        //   77: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	78	0	this	Proxy
        //   0	78	1	paramIBluetoothStateChangeCallback	IBluetoothStateChangeCallback
        //   3	69	2	localParcel1	Parcel
        //   7	61	3	localParcel2	Parcel
        //   65	11	4	localObject	Object
        //   24	37	5	localIBinder	IBinder
        // Exception table:
        //   from	to	target	type
        //   8	14	65	finally
        //   18	26	65	finally
        //   26	50	65	finally
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\bluetooth\IBluetoothManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
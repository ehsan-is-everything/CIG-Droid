package android.bluetooth;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import java.util.ArrayList;
import java.util.List;

public abstract interface IBluetoothHeadset
  extends IInterface
{
  public abstract boolean acceptIncomingConnect(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract void clccResponse(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean, String paramString, int paramInt5)
    throws RemoteException;
  
  public abstract boolean connect(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract boolean connectAudio()
    throws RemoteException;
  
  public abstract boolean disconnect(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract boolean disconnectAudio()
    throws RemoteException;
  
  public abstract int getAudioState(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract int getBatteryUsageHint(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract List<BluetoothDevice> getConnectedDevices()
    throws RemoteException;
  
  public abstract int getConnectionState(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract List<BluetoothDevice> getDevicesMatchingConnectionStates(int[] paramArrayOfInt)
    throws RemoteException;
  
  public abstract int getPriority(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract boolean isAudioConnected(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract boolean isAudioOn()
    throws RemoteException;
  
  public abstract void phoneStateChanged(int paramInt1, int paramInt2, int paramInt3, String paramString, int paramInt4)
    throws RemoteException;
  
  public abstract boolean rejectIncomingConnect(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract void roamChanged(boolean paramBoolean)
    throws RemoteException;
  
  public abstract boolean setPriority(BluetoothDevice paramBluetoothDevice, int paramInt)
    throws RemoteException;
  
  public abstract boolean startScoUsingVirtualVoiceCall(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract boolean startVoiceRecognition(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract boolean stopScoUsingVirtualVoiceCall(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public abstract boolean stopVoiceRecognition(BluetoothDevice paramBluetoothDevice)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IBluetoothHeadset
  {
    private static final String DESCRIPTOR = "android.bluetooth.IBluetoothHeadset";
    static final int TRANSACTION_acceptIncomingConnect = 12;
    static final int TRANSACTION_clccResponse = 22;
    static final int TRANSACTION_connect = 1;
    static final int TRANSACTION_connectAudio = 16;
    static final int TRANSACTION_disconnect = 2;
    static final int TRANSACTION_disconnectAudio = 17;
    static final int TRANSACTION_getAudioState = 14;
    static final int TRANSACTION_getBatteryUsageHint = 11;
    static final int TRANSACTION_getConnectedDevices = 3;
    static final int TRANSACTION_getConnectionState = 5;
    static final int TRANSACTION_getDevicesMatchingConnectionStates = 4;
    static final int TRANSACTION_getPriority = 7;
    static final int TRANSACTION_isAudioConnected = 10;
    static final int TRANSACTION_isAudioOn = 15;
    static final int TRANSACTION_phoneStateChanged = 20;
    static final int TRANSACTION_rejectIncomingConnect = 13;
    static final int TRANSACTION_roamChanged = 21;
    static final int TRANSACTION_setPriority = 6;
    static final int TRANSACTION_startScoUsingVirtualVoiceCall = 18;
    static final int TRANSACTION_startVoiceRecognition = 8;
    static final int TRANSACTION_stopScoUsingVirtualVoiceCall = 19;
    static final int TRANSACTION_stopVoiceRecognition = 9;
    
    public Stub()
    {
      attachInterface(this, "android.bluetooth.IBluetoothHeadset");
    }
    
    public static IBluetoothHeadset asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.bluetooth.IBluetoothHeadset");
      if ((localIInterface != null) && ((localIInterface instanceof IBluetoothHeadset))) {
        return (IBluetoothHeadset)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.bluetooth.IBluetoothHeadset");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice14;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice14 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool15 = connect(localBluetoothDevice14);
          paramParcel2.writeNoException();
          if (!bool15) {
            break label275;
          }
        }
        for (int i16 = 1;; i16 = 0)
        {
          paramParcel2.writeInt(i16);
          return true;
          localBluetoothDevice14 = null;
          break;
        }
      case 2: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice13;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice13 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool14 = disconnect(localBluetoothDevice13);
          paramParcel2.writeNoException();
          if (!bool14) {
            break label342;
          }
        }
        for (int i15 = 1;; i15 = 0)
        {
          paramParcel2.writeInt(i15);
          return true;
          localBluetoothDevice13 = null;
          break;
        }
      case 3: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        List localList2 = getConnectedDevices();
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList2);
        return true;
      case 4: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        List localList1 = getDevicesMatchingConnectionStates(paramParcel1.createIntArray());
        paramParcel2.writeNoException();
        paramParcel2.writeTypedList(localList1);
        return true;
      case 5: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice12 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice12 = null)
        {
          int i14 = getConnectionState(localBluetoothDevice12);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i14);
          return true;
        }
      case 6: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice11;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice11 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool13 = setPriority(localBluetoothDevice11, paramParcel1.readInt());
          paramParcel2.writeNoException();
          if (!bool13) {
            break label518;
          }
        }
        for (int i13 = 1;; i13 = 0)
        {
          paramParcel2.writeInt(i13);
          return true;
          localBluetoothDevice11 = null;
          break;
        }
      case 7: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice10 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice10 = null)
        {
          int i12 = getPriority(localBluetoothDevice10);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i12);
          return true;
        }
      case 8: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice9;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice9 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool12 = startVoiceRecognition(localBluetoothDevice9);
          paramParcel2.writeNoException();
          if (!bool12) {
            break label638;
          }
        }
        for (int i11 = 1;; i11 = 0)
        {
          paramParcel2.writeInt(i11);
          return true;
          localBluetoothDevice9 = null;
          break;
        }
      case 9: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice8;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice8 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool11 = stopVoiceRecognition(localBluetoothDevice8);
          paramParcel2.writeNoException();
          if (!bool11) {
            break label705;
          }
        }
        for (int i10 = 1;; i10 = 0)
        {
          paramParcel2.writeInt(i10);
          return true;
          localBluetoothDevice8 = null;
          break;
        }
      case 10: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice7;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice7 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool10 = isAudioConnected(localBluetoothDevice7);
          paramParcel2.writeNoException();
          if (!bool10) {
            break label772;
          }
        }
        for (int i9 = 1;; i9 = 0)
        {
          paramParcel2.writeInt(i9);
          return true;
          localBluetoothDevice7 = null;
          break;
        }
      case 11: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice6 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice6 = null)
        {
          int i8 = getBatteryUsageHint(localBluetoothDevice6);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i8);
          return true;
        }
      case 12: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice5;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice5 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool9 = acceptIncomingConnect(localBluetoothDevice5);
          paramParcel2.writeNoException();
          if (!bool9) {
            break label892;
          }
        }
        for (int i7 = 1;; i7 = 0)
        {
          paramParcel2.writeInt(i7);
          return true;
          localBluetoothDevice5 = null;
          break;
        }
      case 13: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice4;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice4 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool8 = rejectIncomingConnect(localBluetoothDevice4);
          paramParcel2.writeNoException();
          if (!bool8) {
            break label959;
          }
        }
        for (int i6 = 1;; i6 = 0)
        {
          paramParcel2.writeInt(i6);
          return true;
          localBluetoothDevice4 = null;
          break;
        }
      case 14: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothDevice localBluetoothDevice3 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);; localBluetoothDevice3 = null)
        {
          int i5 = getAudioState(localBluetoothDevice3);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i5);
          return true;
        }
      case 15: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        boolean bool7 = isAudioOn();
        paramParcel2.writeNoException();
        if (bool7) {}
        for (int i4 = 1;; i4 = 0)
        {
          paramParcel2.writeInt(i4);
          return true;
        }
      case 16: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        boolean bool6 = connectAudio();
        paramParcel2.writeNoException();
        if (bool6) {}
        for (int i3 = 1;; i3 = 0)
        {
          paramParcel2.writeInt(i3);
          return true;
        }
      case 17: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        boolean bool5 = disconnectAudio();
        paramParcel2.writeNoException();
        if (bool5) {}
        for (int i2 = 1;; i2 = 0)
        {
          paramParcel2.writeInt(i2);
          return true;
        }
      case 18: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice2;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice2 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool4 = startScoUsingVirtualVoiceCall(localBluetoothDevice2);
          paramParcel2.writeNoException();
          if (!bool4) {
            break label1193;
          }
        }
        for (int i1 = 1;; i1 = 0)
        {
          paramParcel2.writeInt(i1);
          return true;
          localBluetoothDevice2 = null;
          break;
        }
      case 19: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        BluetoothDevice localBluetoothDevice1;
        if (paramParcel1.readInt() != 0)
        {
          localBluetoothDevice1 = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
          boolean bool3 = stopScoUsingVirtualVoiceCall(localBluetoothDevice1);
          paramParcel2.writeNoException();
          if (!bool3) {
            break label1260;
          }
        }
        for (int n = 1;; n = 0)
        {
          paramParcel2.writeInt(n);
          return true;
          localBluetoothDevice1 = null;
          break;
        }
      case 20: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        phoneStateChanged(paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 21: 
        label275:
        label342:
        label518:
        label638:
        label705:
        label772:
        label892:
        label959:
        label1193:
        label1260:
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
        if (paramParcel1.readInt() != 0) {}
        for (boolean bool2 = true;; bool2 = false)
        {
          roamChanged(bool2);
          paramParcel2.writeNoException();
          return true;
        }
      }
      paramParcel1.enforceInterface("android.bluetooth.IBluetoothHeadset");
      int i = paramParcel1.readInt();
      int j = paramParcel1.readInt();
      int k = paramParcel1.readInt();
      int m = paramParcel1.readInt();
      if (paramParcel1.readInt() != 0) {}
      for (boolean bool1 = true;; bool1 = false)
      {
        clccResponse(i, j, k, m, bool1, paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      }
    }
    
    private static class Proxy
      implements IBluetoothHeadset
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public boolean acceptIncomingConnect(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(12, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public void clccResponse(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean, String paramString, int paramInt5)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          localParcel1.writeInt(paramInt3);
          localParcel1.writeInt(paramInt4);
          int i = 0;
          if (paramBoolean) {
            i = 1;
          }
          localParcel1.writeInt(i);
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt5);
          this.mRemote.transact(22, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean connect(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(1, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean connectAudio()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          this.mRemote.transact(16, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean disconnect(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(2, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean disconnectAudio()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          this.mRemote.transact(17, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public int getAudioState(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +50 -> 65
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 41	android/bluetooth/BluetoothDevice:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/bluetooth/IBluetoothHeadset$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: bipush 14
        //   35: aload_2
        //   36: aload_3
        //   37: iconst_0
        //   38: invokeinterface 47 5 0
        //   43: pop
        //   44: aload_3
        //   45: invokevirtual 50	android/os/Parcel:readException	()V
        //   48: aload_3
        //   49: invokevirtual 54	android/os/Parcel:readInt	()I
        //   52: istore 6
        //   54: aload_3
        //   55: invokevirtual 57	android/os/Parcel:recycle	()V
        //   58: aload_2
        //   59: invokevirtual 57	android/os/Parcel:recycle	()V
        //   62: iload 6
        //   64: ireturn
        //   65: aload_2
        //   66: iconst_0
        //   67: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   70: goto -41 -> 29
        //   73: astore 4
        //   75: aload_3
        //   76: invokevirtual 57	android/os/Parcel:recycle	()V
        //   79: aload_2
        //   80: invokevirtual 57	android/os/Parcel:recycle	()V
        //   83: aload 4
        //   85: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	86	0	this	Proxy
        //   0	86	1	paramBluetoothDevice	BluetoothDevice
        //   3	77	2	localParcel1	Parcel
        //   7	69	3	localParcel2	Parcel
        //   73	11	4	localObject	Object
        //   52	11	6	i	int
        // Exception table:
        //   from	to	target	type
        //   8	14	73	finally
        //   18	29	73	finally
        //   29	54	73	finally
        //   65	70	73	finally
      }
      
      /* Error */
      public int getBatteryUsageHint(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +50 -> 65
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 41	android/bluetooth/BluetoothDevice:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/bluetooth/IBluetoothHeadset$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: bipush 11
        //   35: aload_2
        //   36: aload_3
        //   37: iconst_0
        //   38: invokeinterface 47 5 0
        //   43: pop
        //   44: aload_3
        //   45: invokevirtual 50	android/os/Parcel:readException	()V
        //   48: aload_3
        //   49: invokevirtual 54	android/os/Parcel:readInt	()I
        //   52: istore 6
        //   54: aload_3
        //   55: invokevirtual 57	android/os/Parcel:recycle	()V
        //   58: aload_2
        //   59: invokevirtual 57	android/os/Parcel:recycle	()V
        //   62: iload 6
        //   64: ireturn
        //   65: aload_2
        //   66: iconst_0
        //   67: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   70: goto -41 -> 29
        //   73: astore 4
        //   75: aload_3
        //   76: invokevirtual 57	android/os/Parcel:recycle	()V
        //   79: aload_2
        //   80: invokevirtual 57	android/os/Parcel:recycle	()V
        //   83: aload 4
        //   85: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	86	0	this	Proxy
        //   0	86	1	paramBluetoothDevice	BluetoothDevice
        //   3	77	2	localParcel1	Parcel
        //   7	69	3	localParcel2	Parcel
        //   73	11	4	localObject	Object
        //   52	11	6	i	int
        // Exception table:
        //   from	to	target	type
        //   8	14	73	finally
        //   18	29	73	finally
        //   29	54	73	finally
        //   65	70	73	finally
      }
      
      public List<BluetoothDevice> getConnectedDevices()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          this.mRemote.transact(3, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(BluetoothDevice.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      /* Error */
      public int getConnectionState(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +49 -> 64
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 41	android/bluetooth/BluetoothDevice:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/bluetooth/IBluetoothHeadset$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: iconst_5
        //   34: aload_2
        //   35: aload_3
        //   36: iconst_0
        //   37: invokeinterface 47 5 0
        //   42: pop
        //   43: aload_3
        //   44: invokevirtual 50	android/os/Parcel:readException	()V
        //   47: aload_3
        //   48: invokevirtual 54	android/os/Parcel:readInt	()I
        //   51: istore 6
        //   53: aload_3
        //   54: invokevirtual 57	android/os/Parcel:recycle	()V
        //   57: aload_2
        //   58: invokevirtual 57	android/os/Parcel:recycle	()V
        //   61: iload 6
        //   63: ireturn
        //   64: aload_2
        //   65: iconst_0
        //   66: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   69: goto -40 -> 29
        //   72: astore 4
        //   74: aload_3
        //   75: invokevirtual 57	android/os/Parcel:recycle	()V
        //   78: aload_2
        //   79: invokevirtual 57	android/os/Parcel:recycle	()V
        //   82: aload 4
        //   84: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	85	0	this	Proxy
        //   0	85	1	paramBluetoothDevice	BluetoothDevice
        //   3	76	2	localParcel1	Parcel
        //   7	68	3	localParcel2	Parcel
        //   72	11	4	localObject	Object
        //   51	11	6	i	int
        // Exception table:
        //   from	to	target	type
        //   8	14	72	finally
        //   18	29	72	finally
        //   29	53	72	finally
        //   64	69	72	finally
      }
      
      public List<BluetoothDevice> getDevicesMatchingConnectionStates(int[] paramArrayOfInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          localParcel1.writeIntArray(paramArrayOfInt);
          this.mRemote.transact(4, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(BluetoothDevice.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.bluetooth.IBluetoothHeadset";
      }
      
      /* Error */
      public int getPriority(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore_3
        //   8: aload_2
        //   9: ldc 27
        //   11: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   14: aload_1
        //   15: ifnull +50 -> 65
        //   18: aload_2
        //   19: iconst_1
        //   20: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   23: aload_1
        //   24: aload_2
        //   25: iconst_0
        //   26: invokevirtual 41	android/bluetooth/BluetoothDevice:writeToParcel	(Landroid/os/Parcel;I)V
        //   29: aload_0
        //   30: getfield 15	android/bluetooth/IBluetoothHeadset$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   33: bipush 7
        //   35: aload_2
        //   36: aload_3
        //   37: iconst_0
        //   38: invokeinterface 47 5 0
        //   43: pop
        //   44: aload_3
        //   45: invokevirtual 50	android/os/Parcel:readException	()V
        //   48: aload_3
        //   49: invokevirtual 54	android/os/Parcel:readInt	()I
        //   52: istore 6
        //   54: aload_3
        //   55: invokevirtual 57	android/os/Parcel:recycle	()V
        //   58: aload_2
        //   59: invokevirtual 57	android/os/Parcel:recycle	()V
        //   62: iload 6
        //   64: ireturn
        //   65: aload_2
        //   66: iconst_0
        //   67: invokevirtual 35	android/os/Parcel:writeInt	(I)V
        //   70: goto -41 -> 29
        //   73: astore 4
        //   75: aload_3
        //   76: invokevirtual 57	android/os/Parcel:recycle	()V
        //   79: aload_2
        //   80: invokevirtual 57	android/os/Parcel:recycle	()V
        //   83: aload 4
        //   85: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	86	0	this	Proxy
        //   0	86	1	paramBluetoothDevice	BluetoothDevice
        //   3	77	2	localParcel1	Parcel
        //   7	69	3	localParcel2	Parcel
        //   73	11	4	localObject	Object
        //   52	11	6	i	int
        // Exception table:
        //   from	to	target	type
        //   8	14	73	finally
        //   18	29	73	finally
        //   29	54	73	finally
        //   65	70	73	finally
      }
      
      public boolean isAudioConnected(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(10, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean isAudioOn()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          this.mRemote.transact(15, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0) {
            bool = true;
          }
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public void phoneStateChanged(int paramInt1, int paramInt2, int paramInt3, String paramString, int paramInt4)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          localParcel1.writeInt(paramInt3);
          localParcel1.writeString(paramString);
          localParcel1.writeInt(paramInt4);
          this.mRemote.transact(20, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean rejectIncomingConnect(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(13, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public void roamChanged(boolean paramBoolean)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
          int i = 0;
          if (paramBoolean) {
            i = 1;
          }
          localParcel1.writeInt(i);
          this.mRemote.transact(21, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
      
      public boolean setPriority(BluetoothDevice paramBluetoothDevice, int paramInt)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              localParcel1.writeInt(paramInt);
              this.mRemote.transact(6, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean startScoUsingVirtualVoiceCall(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(18, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean startVoiceRecognition(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(8, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean stopScoUsingVirtualVoiceCall(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(19, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
      
      public boolean stopVoiceRecognition(BluetoothDevice paramBluetoothDevice)
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHeadset");
            if (paramBluetoothDevice != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothDevice.writeToParcel(localParcel1, 0);
              this.mRemote.transact(9, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              if (i != 0) {
                return bool;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            bool = false;
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\bluetooth\IBluetoothHeadset.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
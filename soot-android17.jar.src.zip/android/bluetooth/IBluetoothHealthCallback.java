package android.bluetooth;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface IBluetoothHealthCallback
  extends IInterface
{
  public abstract void onHealthAppConfigurationStatusChange(BluetoothHealthAppConfiguration paramBluetoothHealthAppConfiguration, int paramInt)
    throws RemoteException;
  
  public abstract void onHealthChannelStateChange(BluetoothHealthAppConfiguration paramBluetoothHealthAppConfiguration, BluetoothDevice paramBluetoothDevice, int paramInt1, int paramInt2, ParcelFileDescriptor paramParcelFileDescriptor, int paramInt3)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IBluetoothHealthCallback
  {
    private static final String DESCRIPTOR = "android.bluetooth.IBluetoothHealthCallback";
    static final int TRANSACTION_onHealthAppConfigurationStatusChange = 1;
    static final int TRANSACTION_onHealthChannelStateChange = 2;
    
    public Stub()
    {
      attachInterface(this, "android.bluetooth.IBluetoothHealthCallback");
    }
    
    public static IBluetoothHealthCallback asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.bluetooth.IBluetoothHealthCallback");
      if ((localIInterface != null) && ((localIInterface instanceof IBluetoothHealthCallback))) {
        return (IBluetoothHealthCallback)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.bluetooth.IBluetoothHealthCallback");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.bluetooth.IBluetoothHealthCallback");
        if (paramParcel1.readInt() != 0) {}
        for (BluetoothHealthAppConfiguration localBluetoothHealthAppConfiguration2 = (BluetoothHealthAppConfiguration)BluetoothHealthAppConfiguration.CREATOR.createFromParcel(paramParcel1);; localBluetoothHealthAppConfiguration2 = null)
        {
          onHealthAppConfigurationStatusChange(localBluetoothHealthAppConfiguration2, paramParcel1.readInt());
          paramParcel2.writeNoException();
          return true;
        }
      }
      paramParcel1.enforceInterface("android.bluetooth.IBluetoothHealthCallback");
      BluetoothHealthAppConfiguration localBluetoothHealthAppConfiguration1;
      BluetoothDevice localBluetoothDevice;
      label151:
      int i;
      int j;
      if (paramParcel1.readInt() != 0)
      {
        localBluetoothHealthAppConfiguration1 = (BluetoothHealthAppConfiguration)BluetoothHealthAppConfiguration.CREATOR.createFromParcel(paramParcel1);
        if (paramParcel1.readInt() == 0) {
          break label214;
        }
        localBluetoothDevice = (BluetoothDevice)BluetoothDevice.CREATOR.createFromParcel(paramParcel1);
        i = paramParcel1.readInt();
        j = paramParcel1.readInt();
        if (paramParcel1.readInt() == 0) {
          break label220;
        }
      }
      label214:
      label220:
      for (ParcelFileDescriptor localParcelFileDescriptor = (ParcelFileDescriptor)ParcelFileDescriptor.CREATOR.createFromParcel(paramParcel1);; localParcelFileDescriptor = null)
      {
        onHealthChannelStateChange(localBluetoothHealthAppConfiguration1, localBluetoothDevice, i, j, localParcelFileDescriptor, paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
        localBluetoothHealthAppConfiguration1 = null;
        break;
        localBluetoothDevice = null;
        break label151;
      }
    }
    
    private static class Proxy
      implements IBluetoothHealthCallback
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.bluetooth.IBluetoothHealthCallback";
      }
      
      /* Error */
      public void onHealthAppConfigurationStatusChange(BluetoothHealthAppConfiguration paramBluetoothHealthAppConfiguration, int paramInt)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 31	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: invokestatic 31	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   7: astore 4
        //   9: aload_3
        //   10: ldc 21
        //   12: invokevirtual 35	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   15: aload_1
        //   16: ifnull +49 -> 65
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   24: aload_1
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 45	android/bluetooth/BluetoothHealthAppConfiguration:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_3
        //   31: iload_2
        //   32: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   35: aload_0
        //   36: getfield 15	android/bluetooth/IBluetoothHealthCallback$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   39: iconst_1
        //   40: aload_3
        //   41: aload 4
        //   43: iconst_0
        //   44: invokeinterface 51 5 0
        //   49: pop
        //   50: aload 4
        //   52: invokevirtual 54	android/os/Parcel:readException	()V
        //   55: aload 4
        //   57: invokevirtual 57	android/os/Parcel:recycle	()V
        //   60: aload_3
        //   61: invokevirtual 57	android/os/Parcel:recycle	()V
        //   64: return
        //   65: aload_3
        //   66: iconst_0
        //   67: invokevirtual 39	android/os/Parcel:writeInt	(I)V
        //   70: goto -40 -> 30
        //   73: astore 5
        //   75: aload 4
        //   77: invokevirtual 57	android/os/Parcel:recycle	()V
        //   80: aload_3
        //   81: invokevirtual 57	android/os/Parcel:recycle	()V
        //   84: aload 5
        //   86: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	87	0	this	Proxy
        //   0	87	1	paramBluetoothHealthAppConfiguration	BluetoothHealthAppConfiguration
        //   0	87	2	paramInt	int
        //   3	78	3	localParcel1	Parcel
        //   7	69	4	localParcel2	Parcel
        //   73	12	5	localObject	Object
        // Exception table:
        //   from	to	target	type
        //   9	15	73	finally
        //   19	30	73	finally
        //   30	55	73	finally
        //   65	70	73	finally
      }
      
      public void onHealthChannelStateChange(BluetoothHealthAppConfiguration paramBluetoothHealthAppConfiguration, BluetoothDevice paramBluetoothDevice, int paramInt1, int paramInt2, ParcelFileDescriptor paramParcelFileDescriptor, int paramInt3)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.bluetooth.IBluetoothHealthCallback");
            if (paramBluetoothHealthAppConfiguration != null)
            {
              localParcel1.writeInt(1);
              paramBluetoothHealthAppConfiguration.writeToParcel(localParcel1, 0);
              if (paramBluetoothDevice != null)
              {
                localParcel1.writeInt(1);
                paramBluetoothDevice.writeToParcel(localParcel1, 0);
                localParcel1.writeInt(paramInt1);
                localParcel1.writeInt(paramInt2);
                if (paramParcelFileDescriptor == null) {
                  break label155;
                }
                localParcel1.writeInt(1);
                paramParcelFileDescriptor.writeToParcel(localParcel1, 0);
                localParcel1.writeInt(paramInt3);
                this.mRemote.transact(2, localParcel1, localParcel2, 0);
                localParcel2.readException();
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
            localParcel1.writeInt(0);
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          continue;
          label155:
          localParcel1.writeInt(0);
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\bluetooth\IBluetoothHealthCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
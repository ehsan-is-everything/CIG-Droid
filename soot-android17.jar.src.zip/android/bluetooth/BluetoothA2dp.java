package android.bluetooth;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.ParcelUuid;
import android.os.RemoteException;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;

public final class BluetoothA2dp
  implements BluetoothProfile
{
  public static final String ACTION_CONNECTION_STATE_CHANGED = "android.bluetooth.a2dp.profile.action.CONNECTION_STATE_CHANGED";
  public static final String ACTION_PLAYING_STATE_CHANGED = "android.bluetooth.a2dp.profile.action.PLAYING_STATE_CHANGED";
  private static final boolean DBG = true;
  public static final int STATE_NOT_PLAYING = 11;
  public static final int STATE_PLAYING = 10;
  private static final String TAG = "BluetoothA2dp";
  private static final boolean VDBG;
  private BluetoothAdapter mAdapter;
  private final IBluetoothStateChangeCallback mBluetoothStateChangeCallback = new IBluetoothStateChangeCallback.Stub()
  {
    public void onBluetoothStateChange(boolean paramAnonymousBoolean)
    {
      Log.d("BluetoothA2dp", "onBluetoothStateChange: up=" + paramAnonymousBoolean);
      if (!paramAnonymousBoolean) {
        synchronized (BluetoothA2dp.this.mConnection)
        {
          try
          {
            BluetoothA2dp.access$102(BluetoothA2dp.this, null);
            BluetoothA2dp.this.mContext.unbindService(BluetoothA2dp.this.mConnection);
            return;
          }
          catch (Exception localException2)
          {
            for (;;)
            {
              Log.e("BluetoothA2dp", "", localException2);
            }
          }
        }
      }
      try
      {
        synchronized (BluetoothA2dp.this.mConnection)
        {
          if ((BluetoothA2dp.this.mService == null) && (!BluetoothA2dp.this.mContext.bindService(new Intent(IBluetoothA2dp.class.getName()), BluetoothA2dp.this.mConnection, 0))) {
            Log.e("BluetoothA2dp", "Could not bind to Bluetooth A2DP Service");
          }
          return;
        }
      }
      catch (Exception localException1)
      {
        for (;;)
        {
          Log.e("BluetoothA2dp", "", localException1);
        }
      }
    }
  };
  private ServiceConnection mConnection = new ServiceConnection()
  {
    public void onServiceConnected(ComponentName paramAnonymousComponentName, IBinder paramAnonymousIBinder)
    {
      Log.d("BluetoothA2dp", "Proxy object connected");
      BluetoothA2dp.access$102(BluetoothA2dp.this, IBluetoothA2dp.Stub.asInterface(paramAnonymousIBinder));
      if (BluetoothA2dp.this.mServiceListener != null) {
        BluetoothA2dp.this.mServiceListener.onServiceConnected(2, BluetoothA2dp.this);
      }
    }
    
    public void onServiceDisconnected(ComponentName paramAnonymousComponentName)
    {
      Log.d("BluetoothA2dp", "Proxy object disconnected");
      BluetoothA2dp.access$102(BluetoothA2dp.this, null);
      if (BluetoothA2dp.this.mServiceListener != null) {
        BluetoothA2dp.this.mServiceListener.onServiceDisconnected(2);
      }
    }
  };
  private Context mContext;
  private IBluetoothA2dp mService;
  private BluetoothProfile.ServiceListener mServiceListener;
  
  BluetoothA2dp(Context paramContext, BluetoothProfile.ServiceListener paramServiceListener)
  {
    this.mContext = paramContext;
    this.mServiceListener = paramServiceListener;
    this.mAdapter = BluetoothAdapter.getDefaultAdapter();
    IBluetoothManager localIBluetoothManager = this.mAdapter.getBluetoothManager();
    if (localIBluetoothManager != null) {}
    try
    {
      localIBluetoothManager.registerStateChangeCallback(this.mBluetoothStateChangeCallback);
      if (!paramContext.bindService(new Intent(IBluetoothA2dp.class.getName()), this.mConnection, 0)) {
        Log.e("BluetoothA2dp", "Could not bind to Bluetooth A2DP Service");
      }
      return;
    }
    catch (RemoteException localRemoteException)
    {
      for (;;)
      {
        Log.e("BluetoothA2dp", "", localRemoteException);
      }
    }
  }
  
  private boolean isEnabled()
  {
    return this.mAdapter.getState() == 12;
  }
  
  private boolean isValidDevice(BluetoothDevice paramBluetoothDevice)
  {
    if (paramBluetoothDevice == null) {}
    while (!BluetoothAdapter.checkBluetoothAddress(paramBluetoothDevice.getAddress())) {
      return false;
    }
    return true;
  }
  
  private static void log(String paramString)
  {
    Log.d("BluetoothA2dp", paramString);
  }
  
  public static String stateToString(int paramInt)
  {
    switch (paramInt)
    {
    case 4: 
    case 5: 
    case 6: 
    case 7: 
    case 8: 
    case 9: 
    default: 
      return "<unknown state " + paramInt + ">";
    case 0: 
      return "disconnected";
    case 1: 
      return "connecting";
    case 2: 
      return "connected";
    case 3: 
      return "disconnecting";
    case 10: 
      return "playing";
    }
    return "not playing";
  }
  
  void close()
  {
    this.mServiceListener = null;
    IBluetoothManager localIBluetoothManager = this.mAdapter.getBluetoothManager();
    if (localIBluetoothManager != null) {}
    try
    {
      localIBluetoothManager.unregisterStateChangeCallback(this.mBluetoothStateChangeCallback);
    }
    catch (Exception localException2)
    {
      synchronized (this.mConnection)
      {
        for (;;)
        {
          IBluetoothA2dp localIBluetoothA2dp = this.mService;
          if (localIBluetoothA2dp != null) {}
          try
          {
            this.mService = null;
            this.mContext.unbindService(this.mConnection);
            return;
            localException2 = localException2;
            Log.e("BluetoothA2dp", "", localException2);
          }
          catch (Exception localException1)
          {
            for (;;)
            {
              Log.e("BluetoothA2dp", "", localException1);
            }
          }
        }
      }
    }
  }
  
  public boolean connect(BluetoothDevice paramBluetoothDevice)
  {
    log("connect(" + paramBluetoothDevice + ")");
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {}
    IBluetoothA2dp localIBluetoothA2dp;
    do
    {
      try
      {
        boolean bool2 = this.mService.connect(paramBluetoothDevice);
        bool1 = bool2;
        return bool1;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothA2dp", "Stack:" + Log.getStackTraceString(new Throwable()));
        return false;
      }
      localIBluetoothA2dp = this.mService;
      boolean bool1 = false;
    } while (localIBluetoothA2dp != null);
    Log.w("BluetoothA2dp", "Proxy not attached to service");
    return false;
  }
  
  public boolean disconnect(BluetoothDevice paramBluetoothDevice)
  {
    log("disconnect(" + paramBluetoothDevice + ")");
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {}
    IBluetoothA2dp localIBluetoothA2dp;
    do
    {
      try
      {
        boolean bool2 = this.mService.disconnect(paramBluetoothDevice);
        bool1 = bool2;
        return bool1;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothA2dp", "Stack:" + Log.getStackTraceString(new Throwable()));
        return false;
      }
      localIBluetoothA2dp = this.mService;
      boolean bool1 = false;
    } while (localIBluetoothA2dp != null);
    Log.w("BluetoothA2dp", "Proxy not attached to service");
    return false;
  }
  
  public void finalize()
  {
    close();
  }
  
  public List<BluetoothDevice> getConnectedDevices()
  {
    if ((this.mService != null) && (isEnabled())) {
      try
      {
        List localList = this.mService.getConnectedDevices();
        return localList;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothA2dp", "Stack:" + Log.getStackTraceString(new Throwable()));
        return new ArrayList();
      }
    }
    if (this.mService == null) {
      Log.w("BluetoothA2dp", "Proxy not attached to service");
    }
    return new ArrayList();
  }
  
  public int getConnectionState(BluetoothDevice paramBluetoothDevice)
  {
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {}
    IBluetoothA2dp localIBluetoothA2dp;
    do
    {
      try
      {
        int j = this.mService.getConnectionState(paramBluetoothDevice);
        i = j;
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothA2dp", "Stack:" + Log.getStackTraceString(new Throwable()));
        return 0;
      }
      localIBluetoothA2dp = this.mService;
      int i = 0;
    } while (localIBluetoothA2dp != null);
    Log.w("BluetoothA2dp", "Proxy not attached to service");
    return 0;
  }
  
  public List<BluetoothDevice> getDevicesMatchingConnectionStates(int[] paramArrayOfInt)
  {
    if ((this.mService != null) && (isEnabled())) {
      try
      {
        List localList = this.mService.getDevicesMatchingConnectionStates(paramArrayOfInt);
        return localList;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothA2dp", "Stack:" + Log.getStackTraceString(new Throwable()));
        return new ArrayList();
      }
    }
    if (this.mService == null) {
      Log.w("BluetoothA2dp", "Proxy not attached to service");
    }
    return new ArrayList();
  }
  
  public int getPriority(BluetoothDevice paramBluetoothDevice)
  {
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {}
    IBluetoothA2dp localIBluetoothA2dp;
    do
    {
      try
      {
        int j = this.mService.getPriority(paramBluetoothDevice);
        i = j;
        return i;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothA2dp", "Stack:" + Log.getStackTraceString(new Throwable()));
        return 0;
      }
      localIBluetoothA2dp = this.mService;
      int i = 0;
    } while (localIBluetoothA2dp != null);
    Log.w("BluetoothA2dp", "Proxy not attached to service");
    return 0;
  }
  
  public boolean isA2dpPlaying(BluetoothDevice paramBluetoothDevice)
  {
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {}
    IBluetoothA2dp localIBluetoothA2dp;
    do
    {
      try
      {
        boolean bool2 = this.mService.isA2dpPlaying(paramBluetoothDevice);
        bool1 = bool2;
        return bool1;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothA2dp", "Stack:" + Log.getStackTraceString(new Throwable()));
        return false;
      }
      localIBluetoothA2dp = this.mService;
      boolean bool1 = false;
    } while (localIBluetoothA2dp != null);
    Log.w("BluetoothA2dp", "Proxy not attached to service");
    return false;
  }
  
  public boolean setPriority(BluetoothDevice paramBluetoothDevice, int paramInt)
  {
    log("setPriority(" + paramBluetoothDevice + ", " + paramInt + ")");
    if ((this.mService != null) && (isEnabled()) && (isValidDevice(paramBluetoothDevice))) {
      if ((paramInt == 0) || (paramInt == 100)) {}
    }
    while (this.mService != null)
    {
      return false;
      try
      {
        boolean bool = this.mService.setPriority(paramBluetoothDevice, paramInt);
        return bool;
      }
      catch (RemoteException localRemoteException)
      {
        Log.e("BluetoothA2dp", "Stack:" + Log.getStackTraceString(new Throwable()));
        return false;
      }
    }
    Log.w("BluetoothA2dp", "Proxy not attached to service");
    return false;
  }
  
  public boolean shouldSendVolumeKeys(BluetoothDevice paramBluetoothDevice)
  {
    ParcelUuid[] arrayOfParcelUuid;
    if ((isEnabled()) && (isValidDevice(paramBluetoothDevice)))
    {
      arrayOfParcelUuid = paramBluetoothDevice.getUuids();
      if (arrayOfParcelUuid != null) {
        break label26;
      }
    }
    for (;;)
    {
      return false;
      label26:
      int i = arrayOfParcelUuid.length;
      for (int j = 0; j < i; j++) {
        if (BluetoothUuid.isAvrcpTarget(arrayOfParcelUuid[j])) {
          return true;
        }
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\bluetooth\BluetoothA2dp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
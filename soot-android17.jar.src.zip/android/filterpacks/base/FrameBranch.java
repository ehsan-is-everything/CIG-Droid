package android.filterpacks.base;

import android.filterfw.core.Filter;
import android.filterfw.core.FilterContext;
import android.filterfw.core.Frame;
import android.filterfw.core.FrameFormat;
import android.filterfw.core.GenerateFinalPort;

public class FrameBranch
  extends Filter
{
  @GenerateFinalPort(hasDefault=true, name="outputs")
  private int mNumberOfOutputs = 2;
  
  public FrameBranch(String paramString)
  {
    super(paramString);
  }
  
  public FrameFormat getOutputFormat(String paramString, FrameFormat paramFrameFormat)
  {
    return paramFrameFormat;
  }
  
  public void process(FilterContext paramFilterContext)
  {
    Frame localFrame = pullInput("in");
    for (int i = 0; i < this.mNumberOfOutputs; i++) {
      pushOutput("out" + i, localFrame);
    }
  }
  
  public void setupPorts()
  {
    addInputPort("in");
    for (int i = 0; i < this.mNumberOfOutputs; i++) {
      addOutputBasedOnInput("out" + i, "in");
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\filterpacks\base\FrameBranch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
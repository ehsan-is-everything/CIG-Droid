package android.filterpacks.base;

import android.filterfw.core.Filter;
import android.filterfw.core.FilterContext;
import android.filterfw.core.Frame;
import android.filterfw.core.FrameFormat;
import android.filterfw.core.GenerateFieldPort;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;

public class OutputStreamTarget
  extends Filter
{
  @GenerateFieldPort(name="stream")
  private OutputStream mOutputStream;
  
  public OutputStreamTarget(String paramString)
  {
    super(paramString);
  }
  
  public void process(FilterContext paramFilterContext)
  {
    Frame localFrame = pullInput("data");
    if (localFrame.getFormat().getObjectClass() == String.class) {}
    for (ByteBuffer localByteBuffer = ByteBuffer.wrap(((String)localFrame.getObjectValue()).getBytes());; localByteBuffer = localFrame.getData()) {
      try
      {
        this.mOutputStream.write(localByteBuffer.array(), 0, localByteBuffer.limit());
        this.mOutputStream.flush();
        return;
      }
      catch (IOException localIOException)
      {
        throw new RuntimeException("OutputStreamTarget: Could not write to stream: " + localIOException.getMessage() + "!");
      }
    }
  }
  
  public void setupPorts()
  {
    addInputPort("data");
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\filterpacks\base\OutputStreamTarget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
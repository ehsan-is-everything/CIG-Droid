package android.appwidget;

import android.content.ComponentName;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class AppWidgetProviderInfo
  implements Parcelable
{
  public static final Parcelable.Creator<AppWidgetProviderInfo> CREATOR = new Parcelable.Creator()
  {
    public AppWidgetProviderInfo createFromParcel(Parcel paramAnonymousParcel)
    {
      return new AppWidgetProviderInfo(paramAnonymousParcel);
    }
    
    public AppWidgetProviderInfo[] newArray(int paramAnonymousInt)
    {
      return new AppWidgetProviderInfo[paramAnonymousInt];
    }
  };
  public static final int RESIZE_BOTH = 3;
  public static final int RESIZE_HORIZONTAL = 1;
  public static final int RESIZE_NONE = 0;
  public static final int RESIZE_VERTICAL = 2;
  public static final int WIDGET_CATEGORY_HOME_SCREEN = 1;
  public static final int WIDGET_CATEGORY_KEYGUARD = 2;
  public int autoAdvanceViewId;
  public ComponentName configure;
  public int icon;
  public int initialKeyguardLayout;
  public int initialLayout;
  public String label;
  public int minHeight;
  public int minResizeHeight;
  public int minResizeWidth;
  public int minWidth;
  public int previewImage;
  public ComponentName provider;
  public int resizeMode;
  public int updatePeriodMillis;
  public int widgetCategory;
  
  public AppWidgetProviderInfo() {}
  
  public AppWidgetProviderInfo(Parcel paramParcel)
  {
    if (paramParcel.readInt() != 0) {
      this.provider = new ComponentName(paramParcel);
    }
    this.minWidth = paramParcel.readInt();
    this.minHeight = paramParcel.readInt();
    this.minResizeWidth = paramParcel.readInt();
    this.minResizeHeight = paramParcel.readInt();
    this.updatePeriodMillis = paramParcel.readInt();
    this.initialLayout = paramParcel.readInt();
    this.initialKeyguardLayout = paramParcel.readInt();
    if (paramParcel.readInt() != 0) {
      this.configure = new ComponentName(paramParcel);
    }
    this.label = paramParcel.readString();
    this.icon = paramParcel.readInt();
    this.previewImage = paramParcel.readInt();
    this.autoAdvanceViewId = paramParcel.readInt();
    this.resizeMode = paramParcel.readInt();
    this.widgetCategory = paramParcel.readInt();
  }
  
  public AppWidgetProviderInfo clone()
  {
    AppWidgetProviderInfo localAppWidgetProviderInfo = new AppWidgetProviderInfo();
    ComponentName localComponentName1;
    ComponentName localComponentName2;
    label87:
    String str2;
    if (this.provider == null)
    {
      localComponentName1 = null;
      localAppWidgetProviderInfo.provider = localComponentName1;
      localAppWidgetProviderInfo.minWidth = this.minWidth;
      localAppWidgetProviderInfo.minHeight = this.minHeight;
      localAppWidgetProviderInfo.minResizeWidth = this.minResizeHeight;
      localAppWidgetProviderInfo.minResizeHeight = this.minResizeHeight;
      localAppWidgetProviderInfo.updatePeriodMillis = this.updatePeriodMillis;
      localAppWidgetProviderInfo.initialLayout = this.initialLayout;
      localAppWidgetProviderInfo.initialKeyguardLayout = this.initialKeyguardLayout;
      if (this.configure != null) {
        break label165;
      }
      localComponentName2 = null;
      localAppWidgetProviderInfo.configure = localComponentName2;
      String str1 = this.label;
      str2 = null;
      if (str1 != null) {
        break label176;
      }
    }
    for (;;)
    {
      localAppWidgetProviderInfo.label = str2;
      localAppWidgetProviderInfo.icon = this.icon;
      localAppWidgetProviderInfo.previewImage = this.previewImage;
      localAppWidgetProviderInfo.autoAdvanceViewId = this.autoAdvanceViewId;
      localAppWidgetProviderInfo.resizeMode = this.resizeMode;
      localAppWidgetProviderInfo.widgetCategory = this.widgetCategory;
      return localAppWidgetProviderInfo;
      localComponentName1 = this.provider.clone();
      break;
      label165:
      localComponentName2 = this.configure.clone();
      break label87;
      label176:
      str2 = this.label.substring(0);
    }
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public String toString()
  {
    return "AppWidgetProviderInfo(provider=" + this.provider + ")";
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    if (this.provider != null)
    {
      paramParcel.writeInt(1);
      this.provider.writeToParcel(paramParcel, paramInt);
      paramParcel.writeInt(this.minWidth);
      paramParcel.writeInt(this.minHeight);
      paramParcel.writeInt(this.minResizeWidth);
      paramParcel.writeInt(this.minResizeHeight);
      paramParcel.writeInt(this.updatePeriodMillis);
      paramParcel.writeInt(this.initialLayout);
      paramParcel.writeInt(this.initialKeyguardLayout);
      if (this.configure == null) {
        break label155;
      }
      paramParcel.writeInt(1);
      this.configure.writeToParcel(paramParcel, paramInt);
    }
    for (;;)
    {
      paramParcel.writeString(this.label);
      paramParcel.writeInt(this.icon);
      paramParcel.writeInt(this.previewImage);
      paramParcel.writeInt(this.autoAdvanceViewId);
      paramParcel.writeInt(this.resizeMode);
      paramParcel.writeInt(this.widgetCategory);
      return;
      paramParcel.writeInt(0);
      break;
      label155:
      paramParcel.writeInt(0);
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\appwidget\AppWidgetProviderInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.appwidget;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Filter;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.RemoteViews;
import android.widget.RemoteViews.OnClickHandler;
import android.widget.RemoteViews.RemoteView;
import android.widget.RemoteViewsAdapter.RemoteAdapterConnectionCallback;
import android.widget.TextView;

public class AppWidgetHostView
  extends FrameLayout
{
  static final boolean CROSSFADE = false;
  static final int FADE_DURATION = 1000;
  static final boolean LOGD = false;
  static final String TAG = "AppWidgetHostView";
  static final int VIEW_MODE_CONTENT = 1;
  static final int VIEW_MODE_DEFAULT = 3;
  static final int VIEW_MODE_ERROR = 2;
  static final int VIEW_MODE_NOINIT;
  static final LayoutInflater.Filter sInflaterFilter = new LayoutInflater.Filter()
  {
    public boolean onLoadClass(Class paramAnonymousClass)
    {
      return paramAnonymousClass.isAnnotationPresent(RemoteViews.RemoteView.class);
    }
  };
  int mAppWidgetId;
  Context mContext;
  long mFadeStartTime = -1L;
  AppWidgetProviderInfo mInfo;
  int mLayoutId = -1;
  Bitmap mOld;
  Paint mOldPaint = new Paint();
  private RemoteViews.OnClickHandler mOnClickHandler;
  Context mRemoteContext;
  View mView;
  int mViewMode = 0;
  
  public AppWidgetHostView(Context paramContext)
  {
    this(paramContext, 17432576, 17432577);
  }
  
  public AppWidgetHostView(Context paramContext, int paramInt1, int paramInt2)
  {
    super(paramContext);
    this.mContext = paramContext;
    setIsRootNamespace(true);
  }
  
  public AppWidgetHostView(Context paramContext, RemoteViews.OnClickHandler paramOnClickHandler)
  {
    this(paramContext, 17432576, 17432577);
    this.mOnClickHandler = paramOnClickHandler;
  }
  
  private int generateId()
  {
    int i = getId();
    if (i == -1) {
      i = this.mAppWidgetId;
    }
    return i;
  }
  
  public static Rect getDefaultPaddingForWidget(Context paramContext, ComponentName paramComponentName, Rect paramRect)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    if (paramRect == null) {
      paramRect = new Rect(0, 0, 0, 0);
    }
    for (;;)
    {
      try
      {
        ApplicationInfo localApplicationInfo = localPackageManager.getApplicationInfo(paramComponentName.getPackageName(), 0);
        if (localApplicationInfo.targetSdkVersion >= 14)
        {
          Resources localResources = paramContext.getResources();
          paramRect.left = localResources.getDimensionPixelSize(17104974);
          paramRect.right = localResources.getDimensionPixelSize(17104976);
          paramRect.top = localResources.getDimensionPixelSize(17104975);
          paramRect.bottom = localResources.getDimensionPixelSize(17104977);
        }
        return paramRect;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException) {}
      paramRect.set(0, 0, 0, 0);
    }
    return paramRect;
  }
  
  private Context getRemoteContext(RemoteViews paramRemoteViews)
  {
    String str = paramRemoteViews.getPackage();
    if (str == null) {
      return this.mContext;
    }
    try
    {
      Context localContext = this.mContext.createPackageContext(str, 4);
      return localContext;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      Log.e("AppWidgetHostView", "Package name " + str + " not found");
    }
    return this.mContext;
  }
  
  protected void dispatchRestoreInstanceState(SparseArray<Parcelable> paramSparseArray)
  {
    Parcelable localParcelable = (Parcelable)paramSparseArray.get(generateId());
    ParcelableSparseArray localParcelableSparseArray = null;
    if (localParcelable != null)
    {
      boolean bool = localParcelable instanceof ParcelableSparseArray;
      localParcelableSparseArray = null;
      if (bool) {
        localParcelableSparseArray = (ParcelableSparseArray)localParcelable;
      }
    }
    if (localParcelableSparseArray == null) {
      localParcelableSparseArray = new ParcelableSparseArray(null);
    }
    StringBuilder localStringBuilder;
    try
    {
      super.dispatchRestoreInstanceState(localParcelableSparseArray);
      return;
    }
    catch (Exception localException)
    {
      localStringBuilder = new StringBuilder().append("failed to restoreInstanceState for widget id: ").append(this.mAppWidgetId).append(", ");
      if (this.mInfo != null) {}
    }
    for (Object localObject = "null";; localObject = this.mInfo.provider)
    {
      Log.e("AppWidgetHostView", localObject, localException);
      return;
    }
  }
  
  protected void dispatchSaveInstanceState(SparseArray<Parcelable> paramSparseArray)
  {
    ParcelableSparseArray localParcelableSparseArray = new ParcelableSparseArray(null);
    super.dispatchSaveInstanceState(localParcelableSparseArray);
    paramSparseArray.put(generateId(), localParcelableSparseArray);
  }
  
  protected boolean drawChild(Canvas paramCanvas, View paramView, long paramLong)
  {
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public FrameLayout.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet)
  {
    if (this.mRemoteContext != null) {}
    for (Context localContext = this.mRemoteContext;; localContext = this.mContext) {
      return new FrameLayout.LayoutParams(localContext, paramAttributeSet);
    }
  }
  
  public int getAppWidgetId()
  {
    return this.mAppWidgetId;
  }
  
  public AppWidgetProviderInfo getAppWidgetInfo()
  {
    return this.mInfo;
  }
  
  protected View getDefaultView()
  {
    localObject = null;
    for (;;)
    {
      try
      {
        if (this.mInfo == null) {
          continue;
        }
        Context localContext = this.mContext.createPackageContext(this.mInfo.provider.getPackageName(), 4);
        this.mRemoteContext = localContext;
        LayoutInflater localLayoutInflater = ((LayoutInflater)localContext.getSystemService("layout_inflater")).cloneInContext(localContext);
        localLayoutInflater.setFilter(sInflaterFilter);
        Bundle localBundle = AppWidgetManager.getInstance(this.mContext).getAppWidgetOptions(this.mAppWidgetId);
        i = this.mInfo.initialLayout;
        if ((localBundle.containsKey("appWidgetCategory")) && (localBundle.getInt("appWidgetCategory") == 2))
        {
          j = this.mInfo.initialKeyguardLayout;
          if (j != 0) {
            continue;
          }
        }
        View localView2 = localLayoutInflater.inflate(i, this, false);
        localView1 = localView2;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        int i;
        int j;
        localObject = localNameNotFoundException;
        localView1 = null;
        continue;
      }
      catch (RuntimeException localRuntimeException)
      {
        localObject = localRuntimeException;
        View localView1 = null;
        continue;
      }
      if (localObject != null) {
        Log.w("AppWidgetHostView", "Error inflating AppWidget " + this.mInfo + ": " + ((Exception)localObject).toString());
      }
      if (localView1 == null) {
        localView1 = getErrorView();
      }
      return localView1;
      i = j;
      continue;
      Log.w("AppWidgetHostView", "can't inflate defaultView because mInfo is missing");
      localView1 = null;
      localObject = null;
    }
  }
  
  protected View getErrorView()
  {
    TextView localTextView = new TextView(this.mContext);
    localTextView.setText(17040496);
    localTextView.setBackgroundColor(Color.argb(127, 0, 0, 0));
    return localTextView;
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo)
  {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName(AppWidgetHostView.class.getName());
  }
  
  protected void prepareView(View paramView)
  {
    FrameLayout.LayoutParams localLayoutParams = (FrameLayout.LayoutParams)paramView.getLayoutParams();
    if (localLayoutParams == null) {
      localLayoutParams = new FrameLayout.LayoutParams(-1, -1);
    }
    localLayoutParams.gravity = 17;
    paramView.setLayoutParams(localLayoutParams);
  }
  
  void resetAppWidget(AppWidgetProviderInfo paramAppWidgetProviderInfo)
  {
    this.mInfo = paramAppWidgetProviderInfo;
    this.mViewMode = 0;
    updateAppWidget(null);
  }
  
  public void setAppWidget(int paramInt, AppWidgetProviderInfo paramAppWidgetProviderInfo)
  {
    this.mAppWidgetId = paramInt;
    this.mInfo = paramAppWidgetProviderInfo;
    if (paramAppWidgetProviderInfo != null)
    {
      Rect localRect = getDefaultPaddingForWidget(this.mContext, paramAppWidgetProviderInfo.provider, null);
      setPadding(localRect.left, localRect.top, localRect.right, localRect.bottom);
      setContentDescription(paramAppWidgetProviderInfo.label);
    }
  }
  
  public void setOnClickHandler(RemoteViews.OnClickHandler paramOnClickHandler)
  {
    this.mOnClickHandler = paramOnClickHandler;
  }
  
  public void updateAppWidget(RemoteViews paramRemoteViews)
  {
    i = 0;
    localObject1 = null;
    if (paramRemoteViews == null)
    {
      if (this.mViewMode == 3) {
        return;
      }
      localObject2 = getDefaultView();
      this.mLayoutId = -1;
    }
    for (this.mViewMode = 3;; this.mViewMode = 1)
    {
      if (localObject2 == null)
      {
        if (this.mViewMode == 2) {
          break;
        }
        Log.w("AppWidgetHostView", "updateAppWidget couldn't find any view, using error view", (Throwable)localObject1);
        localObject2 = getErrorView();
        this.mViewMode = 2;
      }
      if (i == 0)
      {
        prepareView((View)localObject2);
        addView((View)localObject2);
      }
      if (this.mView == localObject2) {
        break;
      }
      removeView(this.mView);
      this.mView = ((View)localObject2);
      return;
      this.mRemoteContext = getRemoteContext(paramRemoteViews);
      int j = paramRemoteViews.getLayoutId();
      localObject2 = null;
      localObject1 = null;
      i = 0;
      if (0 == 0)
      {
        int k = this.mLayoutId;
        localObject2 = null;
        localObject1 = null;
        i = 0;
        if (j != k) {}
      }
      try
      {
        paramRemoteViews.reapply(this.mContext, this.mView, this.mOnClickHandler);
        localObject2 = this.mView;
        i = 1;
      }
      catch (RuntimeException localRuntimeException2)
      {
        for (;;)
        {
          localObject1 = localRuntimeException2;
          localObject2 = null;
          i = 0;
        }
      }
      if (localObject2 == null) {}
      try
      {
        View localView = paramRemoteViews.apply(this.mContext, this, this.mOnClickHandler);
        localObject2 = localView;
      }
      catch (RuntimeException localRuntimeException1)
      {
        for (;;)
        {
          localObject1 = localRuntimeException1;
        }
      }
      this.mLayoutId = j;
    }
  }
  
  public void updateAppWidgetOptions(Bundle paramBundle)
  {
    AppWidgetManager.getInstance(this.mContext).updateAppWidgetOptions(this.mAppWidgetId, paramBundle);
  }
  
  public void updateAppWidgetSize(Bundle paramBundle, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    updateAppWidgetSize(paramBundle, paramInt1, paramInt2, paramInt3, paramInt4, false);
  }
  
  public void updateAppWidgetSize(Bundle paramBundle, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    if (paramBundle == null) {
      paramBundle = new Bundle();
    }
    Rect localRect = new Rect();
    if (this.mInfo != null) {
      localRect = getDefaultPaddingForWidget(this.mContext, this.mInfo.provider, localRect);
    }
    float f = getResources().getDisplayMetrics().density;
    int i = (int)((localRect.left + localRect.right) / f);
    int j = (int)((localRect.top + localRect.bottom) / f);
    int k;
    int m;
    if (paramBoolean)
    {
      k = 0;
      m = paramInt1 - k;
      if (!paramBoolean) {
        break label284;
      }
    }
    label284:
    for (int n = 0;; n = j)
    {
      int i1 = paramInt2 - n;
      if (paramBoolean) {
        i = 0;
      }
      int i2 = paramInt3 - i;
      if (paramBoolean) {
        j = 0;
      }
      int i3 = paramInt4 - j;
      Bundle localBundle = AppWidgetManager.getInstance(this.mContext).getAppWidgetOptions(this.mAppWidgetId);
      int i4;
      if ((m == localBundle.getInt("appWidgetMinWidth")) && (i1 == localBundle.getInt("appWidgetMinHeight")) && (i2 == localBundle.getInt("appWidgetMaxWidth")))
      {
        int i5 = localBundle.getInt("appWidgetMaxHeight");
        i4 = 0;
        if (i3 == i5) {}
      }
      else
      {
        i4 = 1;
      }
      if (i4 != 0)
      {
        paramBundle.putInt("appWidgetMinWidth", m);
        paramBundle.putInt("appWidgetMinHeight", i1);
        paramBundle.putInt("appWidgetMaxWidth", i2);
        paramBundle.putInt("appWidgetMaxHeight", i3);
        updateAppWidgetOptions(paramBundle);
      }
      return;
      k = i;
      break;
    }
  }
  
  void viewDataChanged(int paramInt)
  {
    View localView = findViewById(paramInt);
    AdapterView localAdapterView;
    Adapter localAdapter;
    if ((localView != null) && ((localView instanceof AdapterView)))
    {
      localAdapterView = (AdapterView)localView;
      localAdapter = localAdapterView.getAdapter();
      if (!(localAdapter instanceof BaseAdapter)) {
        break label45;
      }
      ((BaseAdapter)localAdapter).notifyDataSetChanged();
    }
    label45:
    while ((localAdapter != null) || (!(localAdapterView instanceof RemoteViewsAdapter.RemoteAdapterConnectionCallback))) {
      return;
    }
    ((RemoteViewsAdapter.RemoteAdapterConnectionCallback)localAdapterView).deferNotifyDataSetChanged();
  }
  
  private static class ParcelableSparseArray
    extends SparseArray<Parcelable>
    implements Parcelable
  {
    public static final Parcelable.Creator<ParcelableSparseArray> CREATOR = new Parcelable.Creator()
    {
      public AppWidgetHostView.ParcelableSparseArray createFromParcel(Parcel paramAnonymousParcel)
      {
        AppWidgetHostView.ParcelableSparseArray localParcelableSparseArray = new AppWidgetHostView.ParcelableSparseArray(null);
        ClassLoader localClassLoader = localParcelableSparseArray.getClass().getClassLoader();
        int i = paramAnonymousParcel.readInt();
        for (int j = 0; j < i; j++) {
          localParcelableSparseArray.put(paramAnonymousParcel.readInt(), paramAnonymousParcel.readParcelable(localClassLoader));
        }
        return localParcelableSparseArray;
      }
      
      public AppWidgetHostView.ParcelableSparseArray[] newArray(int paramAnonymousInt)
      {
        return new AppWidgetHostView.ParcelableSparseArray[paramAnonymousInt];
      }
    };
    
    public int describeContents()
    {
      return 0;
    }
    
    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      int i = size();
      paramParcel.writeInt(i);
      for (int j = 0; j < i; j++)
      {
        paramParcel.writeInt(keyAt(j));
        paramParcel.writeParcelable((Parcelable)valueAt(j), 0);
      }
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\appwidget\AppWidgetHostView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.appwidget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public class AppWidgetProvider
  extends BroadcastReceiver
{
  public void onAppWidgetOptionsChanged(Context paramContext, AppWidgetManager paramAppWidgetManager, int paramInt, Bundle paramBundle) {}
  
  public void onDeleted(Context paramContext, int[] paramArrayOfInt) {}
  
  public void onDisabled(Context paramContext) {}
  
  public void onEnabled(Context paramContext) {}
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    String str = paramIntent.getAction();
    if ("android.appwidget.action.APPWIDGET_UPDATE".equals(str))
    {
      Bundle localBundle4 = paramIntent.getExtras();
      if (localBundle4 != null)
      {
        int[] arrayOfInt = localBundle4.getIntArray("appWidgetIds");
        if ((arrayOfInt != null) && (arrayOfInt.length > 0)) {
          onUpdate(paramContext, AppWidgetManager.getInstance(paramContext), arrayOfInt);
        }
      }
    }
    do
    {
      Bundle localBundle1;
      do
      {
        Bundle localBundle3;
        do
        {
          return;
          if (!"android.appwidget.action.APPWIDGET_DELETED".equals(str)) {
            break;
          }
          localBundle3 = paramIntent.getExtras();
        } while ((localBundle3 == null) || (!localBundle3.containsKey("appWidgetId")));
        onDeleted(paramContext, new int[] { localBundle3.getInt("appWidgetId") });
        return;
        if (!"android.appwidget.action.APPWIDGET_UPDATE_OPTIONS".equals(str)) {
          break;
        }
        localBundle1 = paramIntent.getExtras();
      } while ((localBundle1 == null) || (!localBundle1.containsKey("appWidgetId")) || (!localBundle1.containsKey("appWidgetOptions")));
      int i = localBundle1.getInt("appWidgetId");
      Bundle localBundle2 = localBundle1.getBundle("appWidgetOptions");
      onAppWidgetOptionsChanged(paramContext, AppWidgetManager.getInstance(paramContext), i, localBundle2);
      return;
      if ("android.appwidget.action.APPWIDGET_ENABLED".equals(str))
      {
        onEnabled(paramContext);
        return;
      }
    } while (!"android.appwidget.action.APPWIDGET_DISABLED".equals(str));
    onDisabled(paramContext);
  }
  
  public void onUpdate(Context paramContext, AppWidgetManager paramAppWidgetManager, int[] paramArrayOfInt) {}
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\appwidget\AppWidgetProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
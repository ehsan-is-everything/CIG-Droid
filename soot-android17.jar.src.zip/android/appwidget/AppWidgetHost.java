package android.appwidget;

import android.app.ActivityThread;
import android.content.Context;
import android.content.res.Resources;
import android.os.Binder;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.UserHandle;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.widget.RemoteViews;
import android.widget.RemoteViews.OnClickHandler;
import com.android.internal.appwidget.IAppWidgetHost.Stub;
import com.android.internal.appwidget.IAppWidgetService;
import com.android.internal.appwidget.IAppWidgetService.Stub;
import java.util.ArrayList;
import java.util.HashMap;

public class AppWidgetHost
{
  static final int HANDLE_PROVIDERS_CHANGED = 3;
  static final int HANDLE_PROVIDER_CHANGED = 2;
  static final int HANDLE_UPDATE = 1;
  static final int HANDLE_VIEW_DATA_CHANGED = 4;
  static IAppWidgetService sService;
  static final Object sServiceLock = new Object();
  Callbacks mCallbacks = new Callbacks();
  Context mContext;
  private DisplayMetrics mDisplayMetrics;
  Handler mHandler;
  int mHostId;
  private RemoteViews.OnClickHandler mOnClickHandler;
  String mPackageName;
  final HashMap<Integer, AppWidgetHostView> mViews = new HashMap();
  
  public AppWidgetHost(Context paramContext, int paramInt)
  {
    this(paramContext, paramInt, null, paramContext.getMainLooper());
  }
  
  public AppWidgetHost(Context paramContext, int paramInt, RemoteViews.OnClickHandler paramOnClickHandler, Looper paramLooper)
  {
    this.mContext = paramContext;
    this.mHostId = paramInt;
    this.mOnClickHandler = paramOnClickHandler;
    this.mHandler = new UpdateHandler(paramLooper);
    this.mDisplayMetrics = paramContext.getResources().getDisplayMetrics();
    bindService();
  }
  
  public static int allocateAppWidgetIdForSystem(int paramInt)
  {
    
    try
    {
      if (sService == null) {
        bindService();
      }
      String str = ActivityThread.currentActivityThread().getSystemContext().getPackageName();
      int i = sService.allocateAppWidgetId(str, paramInt);
      return i;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("system server dead?", localRemoteException);
    }
  }
  
  private static void bindService()
  {
    synchronized (sServiceLock)
    {
      if (sService == null) {
        sService = IAppWidgetService.Stub.asInterface(ServiceManager.getService("appwidget"));
      }
      return;
    }
  }
  
  private static void checkCallerIsSystem()
  {
    int i = Process.myUid();
    if ((UserHandle.getAppId(i) == 1000) || (i == 0)) {
      return;
    }
    throw new SecurityException("Disallowed call for uid " + i);
  }
  
  public static void deleteAllHosts()
  {
    try
    {
      sService.deleteAllHosts();
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("system server dead?", localRemoteException);
    }
  }
  
  public static void deleteAppWidgetIdForSystem(int paramInt)
  {
    
    try
    {
      if (sService == null) {
        bindService();
      }
      sService.deleteAppWidgetId(paramInt);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("system server dead?", localRemoteException);
    }
  }
  
  private boolean isLocalBinder()
  {
    return Process.myPid() == Binder.getCallingPid();
  }
  
  public int allocateAppWidgetId()
  {
    try
    {
      if (this.mPackageName == null) {
        this.mPackageName = this.mContext.getPackageName();
      }
      int i = sService.allocateAppWidgetId(this.mPackageName, this.mHostId);
      return i;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("system server dead?", localRemoteException);
    }
  }
  
  protected void clearViews()
  {
    this.mViews.clear();
  }
  
  public final AppWidgetHostView createView(Context paramContext, int paramInt, AppWidgetProviderInfo paramAppWidgetProviderInfo)
  {
    AppWidgetHostView localAppWidgetHostView = onCreateView(paramContext, paramInt, paramAppWidgetProviderInfo);
    localAppWidgetHostView.setOnClickHandler(this.mOnClickHandler);
    localAppWidgetHostView.setAppWidget(paramInt, paramAppWidgetProviderInfo);
    RemoteViews localRemoteViews;
    synchronized (this.mViews)
    {
      this.mViews.put(Integer.valueOf(paramInt), localAppWidgetHostView);
    }
  }
  
  public void deleteAppWidgetId(int paramInt)
  {
    synchronized (this.mViews)
    {
      this.mViews.remove(Integer.valueOf(paramInt));
      try
      {
        sService.deleteAppWidgetId(paramInt);
        return;
      }
      catch (RemoteException localRemoteException)
      {
        throw new RuntimeException("system server dead?", localRemoteException);
      }
    }
  }
  
  public void deleteHost()
  {
    try
    {
      sService.deleteHost(this.mHostId);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("system server dead?", localRemoteException);
    }
  }
  
  protected AppWidgetHostView onCreateView(Context paramContext, int paramInt, AppWidgetProviderInfo paramAppWidgetProviderInfo)
  {
    return new AppWidgetHostView(paramContext, this.mOnClickHandler);
  }
  
  protected void onProviderChanged(int paramInt, AppWidgetProviderInfo paramAppWidgetProviderInfo)
  {
    paramAppWidgetProviderInfo.minWidth = TypedValue.complexToDimensionPixelSize(paramAppWidgetProviderInfo.minWidth, this.mDisplayMetrics);
    paramAppWidgetProviderInfo.minHeight = TypedValue.complexToDimensionPixelSize(paramAppWidgetProviderInfo.minHeight, this.mDisplayMetrics);
    paramAppWidgetProviderInfo.minResizeWidth = TypedValue.complexToDimensionPixelSize(paramAppWidgetProviderInfo.minResizeWidth, this.mDisplayMetrics);
    paramAppWidgetProviderInfo.minResizeHeight = TypedValue.complexToDimensionPixelSize(paramAppWidgetProviderInfo.minResizeHeight, this.mDisplayMetrics);
    synchronized (this.mViews)
    {
      AppWidgetHostView localAppWidgetHostView = (AppWidgetHostView)this.mViews.get(Integer.valueOf(paramInt));
      if (localAppWidgetHostView != null) {
        localAppWidgetHostView.resetAppWidget(paramAppWidgetProviderInfo);
      }
      return;
    }
  }
  
  protected void onProvidersChanged() {}
  
  public void startListening()
  {
    ArrayList localArrayList = new ArrayList();
    try
    {
      if (this.mPackageName == null) {
        this.mPackageName = this.mContext.getPackageName();
      }
      int[] arrayOfInt = sService.startListening(this.mCallbacks, this.mPackageName, this.mHostId, localArrayList);
      int i = arrayOfInt.length;
      for (int j = 0; j < i; j++) {
        updateAppWidgetView(arrayOfInt[j], (RemoteViews)localArrayList.get(j));
      }
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("system server dead?", localRemoteException);
    }
  }
  
  public void stopListening()
  {
    try
    {
      sService.stopListening(this.mHostId);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("system server dead?", localRemoteException);
    }
  }
  
  void updateAppWidgetView(int paramInt, RemoteViews paramRemoteViews)
  {
    synchronized (this.mViews)
    {
      AppWidgetHostView localAppWidgetHostView = (AppWidgetHostView)this.mViews.get(Integer.valueOf(paramInt));
      if (localAppWidgetHostView != null) {
        localAppWidgetHostView.updateAppWidget(paramRemoteViews);
      }
      return;
    }
  }
  
  void viewDataChanged(int paramInt1, int paramInt2)
  {
    synchronized (this.mViews)
    {
      AppWidgetHostView localAppWidgetHostView = (AppWidgetHostView)this.mViews.get(Integer.valueOf(paramInt1));
      if (localAppWidgetHostView != null) {
        localAppWidgetHostView.viewDataChanged(paramInt2);
      }
      return;
    }
  }
  
  class Callbacks
    extends IAppWidgetHost.Stub
  {
    Callbacks() {}
    
    public void providerChanged(int paramInt, AppWidgetProviderInfo paramAppWidgetProviderInfo)
    {
      if ((AppWidgetHost.this.isLocalBinder()) && (paramAppWidgetProviderInfo != null)) {
        paramAppWidgetProviderInfo = paramAppWidgetProviderInfo.clone();
      }
      Message localMessage = AppWidgetHost.this.mHandler.obtainMessage(2);
      localMessage.arg1 = paramInt;
      localMessage.obj = paramAppWidgetProviderInfo;
      localMessage.sendToTarget();
    }
    
    public void providersChanged()
    {
      AppWidgetHost.this.mHandler.obtainMessage(3).sendToTarget();
    }
    
    public void updateAppWidget(int paramInt, RemoteViews paramRemoteViews)
    {
      if ((AppWidgetHost.this.isLocalBinder()) && (paramRemoteViews != null)) {
        paramRemoteViews = paramRemoteViews.clone();
      }
      Message localMessage = AppWidgetHost.this.mHandler.obtainMessage(1);
      localMessage.arg1 = paramInt;
      localMessage.obj = paramRemoteViews;
      localMessage.sendToTarget();
    }
    
    public void viewDataChanged(int paramInt1, int paramInt2)
    {
      Message localMessage = AppWidgetHost.this.mHandler.obtainMessage(4);
      localMessage.arg1 = paramInt1;
      localMessage.arg2 = paramInt2;
      localMessage.sendToTarget();
    }
  }
  
  class UpdateHandler
    extends Handler
  {
    public UpdateHandler(Looper paramLooper)
    {
      super();
    }
    
    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default: 
        return;
      case 1: 
        AppWidgetHost.this.updateAppWidgetView(paramMessage.arg1, (RemoteViews)paramMessage.obj);
        return;
      case 2: 
        AppWidgetHost.this.onProviderChanged(paramMessage.arg1, (AppWidgetProviderInfo)paramMessage.obj);
        return;
      case 3: 
        AppWidgetHost.this.onProvidersChanged();
        return;
      }
      AppWidgetHost.this.viewDataChanged(paramMessage.arg1, paramMessage.arg2);
    }
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\appwidget\AppWidgetHost.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
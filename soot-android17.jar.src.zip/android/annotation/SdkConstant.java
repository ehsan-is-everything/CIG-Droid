package android.annotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.SOURCE)
@Target({java.lang.annotation.ElementType.FIELD})
public @interface SdkConstant
{
  SdkConstantType value();
  
  public static enum SdkConstantType
  {
    static
    {
      INTENT_CATEGORY = new SdkConstantType("INTENT_CATEGORY", 3);
      FEATURE = new SdkConstantType("FEATURE", 4);
      SdkConstantType[] arrayOfSdkConstantType = new SdkConstantType[5];
      arrayOfSdkConstantType[0] = ACTIVITY_INTENT_ACTION;
      arrayOfSdkConstantType[1] = BROADCAST_INTENT_ACTION;
      arrayOfSdkConstantType[2] = SERVICE_ACTION;
      arrayOfSdkConstantType[3] = INTENT_CATEGORY;
      arrayOfSdkConstantType[4] = FEATURE;
      $VALUES = arrayOfSdkConstantType;
    }
    
    private SdkConstantType() {}
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\annotation\SdkConstant.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
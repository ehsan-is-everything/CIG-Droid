package android.ddm;

import android.os.Debug;
import android.util.Log;
import java.nio.ByteBuffer;
import org.apache.harmony.dalvik.ddmc.Chunk;
import org.apache.harmony.dalvik.ddmc.ChunkHandler;
import org.apache.harmony.dalvik.ddmc.DdmServer;

public class DdmHandleProfiling
  extends ChunkHandler
{
  public static final int CHUNK_MPRE;
  public static final int CHUNK_MPRQ = type("MPRQ");
  public static final int CHUNK_MPRS = type("MPRS");
  public static final int CHUNK_MPSE;
  public static final int CHUNK_MPSS;
  private static DdmHandleProfiling mInstance = new DdmHandleProfiling();
  
  static
  {
    CHUNK_MPRE = type("MPRE");
    CHUNK_MPSS = type("MPSS");
    CHUNK_MPSE = type("MPSE");
  }
  
  private Chunk handleMPRE(Chunk paramChunk)
  {
    try
    {
      Debug.stopMethodTracing();
      i = 0;
    }
    catch (RuntimeException localRuntimeException)
    {
      for (;;)
      {
        byte[] arrayOfByte;
        Log.w("ddm-heap", "Method profiling end failed: " + localRuntimeException.getMessage());
        int i = 1;
      }
    }
    arrayOfByte = new byte[] { i };
    return new Chunk(CHUNK_MPRE, arrayOfByte, 0, arrayOfByte.length);
  }
  
  private Chunk handleMPRQ(Chunk paramChunk)
  {
    if (Debug.isMethodTracingActive()) {}
    for (int i = 1;; i = 0)
    {
      byte[] arrayOfByte = new byte[1];
      arrayOfByte[0] = ((byte)i);
      return new Chunk(CHUNK_MPRQ, arrayOfByte, 0, arrayOfByte.length);
    }
  }
  
  private Chunk handleMPRS(Chunk paramChunk)
  {
    ByteBuffer localByteBuffer = wrapChunk(paramChunk);
    int i = localByteBuffer.getInt();
    int j = localByteBuffer.getInt();
    String str = getString(localByteBuffer, localByteBuffer.getInt());
    try
    {
      Debug.startMethodTracing(str, i, j);
      return null;
    }
    catch (RuntimeException localRuntimeException)
    {
      return createFailChunk(1, localRuntimeException.getMessage());
    }
  }
  
  private Chunk handleMPSE(Chunk paramChunk)
  {
    try
    {
      Debug.stopMethodTracing();
      return null;
    }
    catch (RuntimeException localRuntimeException)
    {
      Log.w("ddm-heap", "Method prof stream end failed: " + localRuntimeException.getMessage());
      return createFailChunk(1, localRuntimeException.getMessage());
    }
  }
  
  private Chunk handleMPSS(Chunk paramChunk)
  {
    ByteBuffer localByteBuffer = wrapChunk(paramChunk);
    int i = localByteBuffer.getInt();
    int j = localByteBuffer.getInt();
    try
    {
      Debug.startMethodTracingDdms(i, j);
      return null;
    }
    catch (RuntimeException localRuntimeException)
    {
      return createFailChunk(1, localRuntimeException.getMessage());
    }
  }
  
  public static void register()
  {
    DdmServer.registerHandler(CHUNK_MPRS, mInstance);
    DdmServer.registerHandler(CHUNK_MPRE, mInstance);
    DdmServer.registerHandler(CHUNK_MPSS, mInstance);
    DdmServer.registerHandler(CHUNK_MPSE, mInstance);
    DdmServer.registerHandler(CHUNK_MPRQ, mInstance);
  }
  
  public void connected() {}
  
  public void disconnected() {}
  
  public Chunk handleChunk(Chunk paramChunk)
  {
    int i = paramChunk.type;
    if (i == CHUNK_MPRS) {
      return handleMPRS(paramChunk);
    }
    if (i == CHUNK_MPRE) {
      return handleMPRE(paramChunk);
    }
    if (i == CHUNK_MPSS) {
      return handleMPSS(paramChunk);
    }
    if (i == CHUNK_MPSE) {
      return handleMPSE(paramChunk);
    }
    if (i == CHUNK_MPRQ) {
      return handleMPRQ(paramChunk);
    }
    throw new RuntimeException("Unknown packet " + ChunkHandler.name(i));
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\ddm\DdmHandleProfiling.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
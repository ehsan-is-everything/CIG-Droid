package android.ddm;

import java.nio.ByteBuffer;
import org.apache.harmony.dalvik.ddmc.Chunk;
import org.apache.harmony.dalvik.ddmc.ChunkHandler;
import org.apache.harmony.dalvik.ddmc.DdmServer;
import org.apache.harmony.dalvik.ddmc.DdmVmInternal;

public class DdmHandleThread
  extends ChunkHandler
{
  public static final int CHUNK_STKL = type("STKL");
  public static final int CHUNK_THCR;
  public static final int CHUNK_THDE;
  public static final int CHUNK_THEN = type("THEN");
  public static final int CHUNK_THST;
  private static DdmHandleThread mInstance = new DdmHandleThread();
  
  static
  {
    CHUNK_THCR = type("THCR");
    CHUNK_THDE = type("THDE");
    CHUNK_THST = type("THST");
  }
  
  private Chunk createStackChunk(StackTraceElement[] paramArrayOfStackTraceElement, int paramInt)
  {
    int i = 4 + (4 + (0 + 4));
    int j = paramArrayOfStackTraceElement.length;
    for (int k = 0; k < j; k++)
    {
      StackTraceElement localStackTraceElement2 = paramArrayOfStackTraceElement[k];
      int i1 = 4 + (i + (4 + 2 * localStackTraceElement2.getClassName().length()) + (4 + 2 * localStackTraceElement2.getMethodName().length()));
      if (localStackTraceElement2.getFileName() != null) {
        i1 += 2 * localStackTraceElement2.getFileName().length();
      }
      i = i1 + 4;
    }
    ByteBuffer localByteBuffer = ByteBuffer.allocate(i);
    localByteBuffer.putInt(0);
    localByteBuffer.putInt(paramInt);
    localByteBuffer.putInt(paramArrayOfStackTraceElement.length);
    int m = paramArrayOfStackTraceElement.length;
    int n = 0;
    if (n < m)
    {
      StackTraceElement localStackTraceElement1 = paramArrayOfStackTraceElement[n];
      localByteBuffer.putInt(localStackTraceElement1.getClassName().length());
      putString(localByteBuffer, localStackTraceElement1.getClassName());
      localByteBuffer.putInt(localStackTraceElement1.getMethodName().length());
      putString(localByteBuffer, localStackTraceElement1.getMethodName());
      if (localStackTraceElement1.getFileName() != null)
      {
        localByteBuffer.putInt(localStackTraceElement1.getFileName().length());
        putString(localByteBuffer, localStackTraceElement1.getFileName());
      }
      for (;;)
      {
        localByteBuffer.putInt(localStackTraceElement1.getLineNumber());
        n++;
        break;
        localByteBuffer.putInt(0);
      }
    }
    return new Chunk(CHUNK_STKL, localByteBuffer);
  }
  
  private Chunk handleSTKL(Chunk paramChunk)
  {
    int i = wrapChunk(paramChunk).getInt();
    StackTraceElement[] arrayOfStackTraceElement = DdmVmInternal.getStackTraceById(i);
    if (arrayOfStackTraceElement == null) {
      return createFailChunk(1, "Stack trace unavailable");
    }
    return createStackChunk(arrayOfStackTraceElement, i);
  }
  
  private Chunk handleTHEN(Chunk paramChunk)
  {
    if (wrapChunk(paramChunk).get() != 0) {}
    for (boolean bool = true;; bool = false)
    {
      DdmVmInternal.threadNotify(bool);
      return null;
    }
  }
  
  private Chunk handleTHST(Chunk paramChunk)
  {
    wrapChunk(paramChunk);
    byte[] arrayOfByte = DdmVmInternal.getThreadStats();
    if (arrayOfByte != null) {
      return new Chunk(CHUNK_THST, arrayOfByte, 0, arrayOfByte.length);
    }
    return createFailChunk(1, "Can't build THST chunk");
  }
  
  public static void register()
  {
    DdmServer.registerHandler(CHUNK_THEN, mInstance);
    DdmServer.registerHandler(CHUNK_THST, mInstance);
    DdmServer.registerHandler(CHUNK_STKL, mInstance);
  }
  
  public void connected() {}
  
  public void disconnected() {}
  
  public Chunk handleChunk(Chunk paramChunk)
  {
    int i = paramChunk.type;
    if (i == CHUNK_THEN) {
      return handleTHEN(paramChunk);
    }
    if (i == CHUNK_THST) {
      return handleTHST(paramChunk);
    }
    if (i == CHUNK_STKL) {
      return handleSTKL(paramChunk);
    }
    throw new RuntimeException("Unknown packet " + ChunkHandler.name(i));
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\ddm\DdmHandleThread.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
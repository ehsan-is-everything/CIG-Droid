package android.ddm;

import org.apache.harmony.dalvik.ddmc.DdmServer;

public class DdmRegister
{
  public static void registerHandlers()
  {
    DdmHandleHello.register();
    DdmHandleThread.register();
    DdmHandleHeap.register();
    DdmHandleNativeHeap.register();
    DdmHandleProfiling.register();
    DdmHandleExit.register();
    DdmServer.registrationComplete();
  }
}


/* Location:              C:\Users\Lab\Desktop\android-jar\soot-android17.jar!\android\ddm\DdmRegister.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
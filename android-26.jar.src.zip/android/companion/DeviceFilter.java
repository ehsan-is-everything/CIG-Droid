package android.companion;

import android.os.Parcelable;

public abstract interface DeviceFilter<D extends Parcelable>
  extends Parcelable
{}


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\companion\DeviceFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
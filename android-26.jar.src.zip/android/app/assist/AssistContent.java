/*    */ package android.app.assist;
/*    */ 
/*    */ import android.content.ClipData;
/*    */ 
/*  5 */ public class AssistContent implements android.os.Parcelable { public AssistContent() { throw new RuntimeException("Stub!"); }
/*  6 */   public void setIntent(android.content.Intent intent) { throw new RuntimeException("Stub!"); }
/*  7 */   public android.content.Intent getIntent() { throw new RuntimeException("Stub!"); }
/*  8 */   public boolean isAppProvidedIntent() { throw new RuntimeException("Stub!"); }
/*  9 */   public void setClipData(ClipData clip) { throw new RuntimeException("Stub!"); }
/* 10 */   public ClipData getClipData() { throw new RuntimeException("Stub!"); }
/* 11 */   public void setStructuredData(String structuredData) { throw new RuntimeException("Stub!"); }
/* 12 */   public String getStructuredData() { throw new RuntimeException("Stub!"); }
/* 13 */   public void setWebUri(android.net.Uri uri) { throw new RuntimeException("Stub!"); }
/* 14 */   public android.net.Uri getWebUri() { throw new RuntimeException("Stub!"); }
/* 15 */   public boolean isAppProvidedWebUri() { throw new RuntimeException("Stub!"); }
/* 16 */   public android.os.Bundle getExtras() { throw new RuntimeException("Stub!"); }
/* 17 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/* 18 */   public void writeToParcel(android.os.Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/*    */   
/* 20 */   public static final android.os.Parcelable.Creator<AssistContent> CREATOR = null;
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\app\assist\AssistContent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
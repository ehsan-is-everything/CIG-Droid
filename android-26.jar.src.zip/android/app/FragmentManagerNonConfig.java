/*    */ package android.app;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FragmentManagerNonConfig
/*    */ {
/*    */   FragmentManagerNonConfig()
/*    */   {
/* 21 */     throw new RuntimeException("Stub!");
/*    */   }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\app\FragmentManagerNonConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
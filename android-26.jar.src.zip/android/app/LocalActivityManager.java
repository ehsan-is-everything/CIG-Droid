/*    */ package android.app;
/*    */ 
/*    */ import android.content.Intent;
/*    */ import android.os.Bundle;
/*    */ import android.view.Window;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class LocalActivityManager
/*    */ {
/* 21 */   public LocalActivityManager(Activity parent, boolean singleMode) { throw new RuntimeException("Stub!"); }
/* 22 */   public Window startActivity(String id, Intent intent) { throw new RuntimeException("Stub!"); }
/* 23 */   public Window destroyActivity(String id, boolean finish) { throw new RuntimeException("Stub!"); }
/* 24 */   public Activity getCurrentActivity() { throw new RuntimeException("Stub!"); }
/* 25 */   public String getCurrentId() { throw new RuntimeException("Stub!"); }
/* 26 */   public Activity getActivity(String id) { throw new RuntimeException("Stub!"); }
/* 27 */   public void dispatchCreate(Bundle state) { throw new RuntimeException("Stub!"); }
/* 28 */   public Bundle saveInstanceState() { throw new RuntimeException("Stub!"); }
/* 29 */   public void dispatchResume() { throw new RuntimeException("Stub!"); }
/* 30 */   public void dispatchPause(boolean finishing) { throw new RuntimeException("Stub!"); }
/* 31 */   public void dispatchStop() { throw new RuntimeException("Stub!"); }
/* 32 */   public void removeAllActivities() { throw new RuntimeException("Stub!"); }
/* 33 */   public void dispatchDestroy(boolean finishing) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\app\LocalActivityManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
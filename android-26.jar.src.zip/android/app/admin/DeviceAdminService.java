/*    */ package android.app.admin;
/*    */ 
/*    */ import android.app.Service;
/*    */ import android.content.Intent;
/*    */ import android.os.IBinder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeviceAdminService
/*    */   extends Service
/*    */ {
/* 20 */   public DeviceAdminService() { throw new RuntimeException("Stub!"); }
/* 21 */   public final IBinder onBind(Intent intent) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\app\admin\DeviceAdminService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.app;
/*    */ 
/*    */ import android.os.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AliasActivity
/*    */   extends Activity
/*    */ {
/* 21 */   public AliasActivity() { throw new RuntimeException("Stub!"); }
/* 22 */   protected void onCreate(Bundle savedInstanceState) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\app\AliasActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
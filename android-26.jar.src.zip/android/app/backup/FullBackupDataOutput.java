/*   */ package android.app.backup;
/*   */ 
/*   */ public class FullBackupDataOutput {
/* 4 */   FullBackupDataOutput() { throw new RuntimeException("Stub!"); }
/* 5 */   public long getQuota() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\app\backup\FullBackupDataOutput.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.app.backup;
/*    */ 
/*    */ import android.os.ParcelFileDescriptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FileBackupHelperBase
/*    */ {
/* 20 */   FileBackupHelperBase() { throw new RuntimeException("Stub!"); }
/* 21 */   protected void finalize() throws Throwable { throw new RuntimeException("Stub!"); }
/* 22 */   public void writeNewStateDescription(ParcelFileDescriptor fd) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\app\backup\FileBackupHelperBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
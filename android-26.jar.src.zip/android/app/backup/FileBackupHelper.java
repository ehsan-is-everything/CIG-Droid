/*    */ package android.app.backup;
/*    */ 
/*    */ import android.content.Context;
/*    */ import android.os.ParcelFileDescriptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileBackupHelper
/*    */   extends FileBackupHelperBase
/*    */   implements BackupHelper
/*    */ {
/* 22 */   public FileBackupHelper(Context context, String... files) { throw new RuntimeException("Stub!"); }
/* 23 */   public void performBackup(ParcelFileDescriptor oldState, BackupDataOutput data, ParcelFileDescriptor newState) { throw new RuntimeException("Stub!"); }
/* 24 */   public void restoreEntity(BackupDataInputStream data) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\app\backup\FileBackupHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
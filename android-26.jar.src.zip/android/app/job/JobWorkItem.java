/*    */ package android.app.job;
/*    */ 
/*    */ import android.content.Intent;
/*    */ import android.os.Parcel;
/*    */ import android.os.Parcelable;
/*    */ import android.os.Parcelable.Creator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JobWorkItem
/*    */   implements Parcelable
/*    */ {
/* 21 */   public JobWorkItem(Intent intent) { throw new RuntimeException("Stub!"); }
/* 22 */   public Intent getIntent() { throw new RuntimeException("Stub!"); }
/* 23 */   public int getDeliveryCount() { throw new RuntimeException("Stub!"); }
/* 24 */   public String toString() { throw new RuntimeException("Stub!"); }
/* 25 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/* 26 */   public void writeToParcel(Parcel out, int flags) { throw new RuntimeException("Stub!"); }
/*    */   
/* 28 */   public static final Parcelable.Creator<JobWorkItem> CREATOR = null;
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\app\job\JobWorkItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
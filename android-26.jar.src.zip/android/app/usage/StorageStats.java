/*    */ package android.app.usage;
/*    */ 
/*    */ import android.os.Parcel;
/*    */ import android.os.Parcelable;
/*    */ import android.os.Parcelable.Creator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StorageStats
/*    */   implements Parcelable
/*    */ {
/* 21 */   StorageStats() { throw new RuntimeException("Stub!"); }
/* 22 */   public long getAppBytes() { throw new RuntimeException("Stub!"); }
/* 23 */   public long getDataBytes() { throw new RuntimeException("Stub!"); }
/* 24 */   public long getCacheBytes() { throw new RuntimeException("Stub!"); }
/* 25 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/* 26 */   public void writeToParcel(Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/*    */   
/* 28 */   public static final Parcelable.Creator<StorageStats> CREATOR = null;
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\app\usage\StorageStats.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
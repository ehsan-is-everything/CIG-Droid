/*    */ package android.database;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StaleDataException
/*    */   extends RuntimeException
/*    */ {
/* 21 */   public StaleDataException() { throw new RuntimeException("Stub!"); }
/* 22 */   public StaleDataException(String description) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\database\StaleDataException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
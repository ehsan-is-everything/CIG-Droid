/*    */ package android.database;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CharArrayBuffer
/*    */ {
/* 20 */   public CharArrayBuffer(int size) { throw new RuntimeException("Stub!"); }
/* 21 */   public CharArrayBuffer(char[] buf) { throw new RuntimeException("Stub!"); }
/* 22 */   public char[] data = null;
/*    */   public int sizeCopied;
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\database\CharArrayBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
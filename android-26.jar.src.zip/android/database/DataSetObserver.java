/*    */ package android.database;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DataSetObserver
/*    */ {
/* 20 */   public DataSetObserver() { throw new RuntimeException("Stub!"); }
/* 21 */   public void onChanged() { throw new RuntimeException("Stub!"); }
/* 22 */   public void onInvalidated() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\database\DataSetObserver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
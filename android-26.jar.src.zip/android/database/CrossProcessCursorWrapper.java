/*    */ package android.database;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CrossProcessCursorWrapper
/*    */   extends CursorWrapper
/*    */   implements CrossProcessCursor
/*    */ {
/*    */   public CrossProcessCursorWrapper(Cursor cursor)
/*    */   {
/* 22 */     super((Cursor)null);throw new RuntimeException("Stub!"); }
/* 23 */   public void fillWindow(int position, CursorWindow window) { throw new RuntimeException("Stub!"); }
/* 24 */   public CursorWindow getWindow() { throw new RuntimeException("Stub!"); }
/* 25 */   public boolean onMove(int oldPosition, int newPosition) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\database\CrossProcessCursorWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.database;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLException
/*    */   extends RuntimeException
/*    */ {
/* 21 */   public SQLException() { throw new RuntimeException("Stub!"); }
/* 22 */   public SQLException(String error) { throw new RuntimeException("Stub!"); }
/* 23 */   public SQLException(String error, Throwable cause) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\database\SQLException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
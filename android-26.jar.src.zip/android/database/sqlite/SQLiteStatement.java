/*    */ package android.database.sqlite;
/*    */ 
/*    */ import android.os.ParcelFileDescriptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SQLiteStatement
/*    */   extends SQLiteProgram
/*    */ {
/* 21 */   SQLiteStatement() { throw new RuntimeException("Stub!"); }
/* 22 */   public void execute() { throw new RuntimeException("Stub!"); }
/* 23 */   public int executeUpdateDelete() { throw new RuntimeException("Stub!"); }
/* 24 */   public long executeInsert() { throw new RuntimeException("Stub!"); }
/* 25 */   public long simpleQueryForLong() { throw new RuntimeException("Stub!"); }
/* 26 */   public String simpleQueryForString() { throw new RuntimeException("Stub!"); }
/* 27 */   public ParcelFileDescriptor simpleQueryForBlobFileDescriptor() { throw new RuntimeException("Stub!"); }
/* 28 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\database\sqlite\SQLiteStatement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
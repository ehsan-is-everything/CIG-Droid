/*    */ package android.database.sqlite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLiteDatabaseLockedException
/*    */   extends SQLiteException
/*    */ {
/* 21 */   public SQLiteDatabaseLockedException() { throw new RuntimeException("Stub!"); }
/* 22 */   public SQLiteDatabaseLockedException(String error) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\database\sqlite\SQLiteDatabaseLockedException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
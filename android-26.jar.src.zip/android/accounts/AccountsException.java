/*    */ package android.accounts;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccountsException
/*    */   extends Exception
/*    */ {
/* 21 */   public AccountsException() { throw new RuntimeException("Stub!"); }
/* 22 */   public AccountsException(String message) { throw new RuntimeException("Stub!"); }
/* 23 */   public AccountsException(String message, Throwable cause) { throw new RuntimeException("Stub!"); }
/* 24 */   public AccountsException(Throwable cause) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\accounts\AccountsException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
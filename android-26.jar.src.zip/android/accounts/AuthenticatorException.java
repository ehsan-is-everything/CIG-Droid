/*    */ package android.accounts;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticatorException
/*    */   extends AccountsException
/*    */ {
/* 21 */   public AuthenticatorException() { throw new RuntimeException("Stub!"); }
/* 22 */   public AuthenticatorException(String message) { throw new RuntimeException("Stub!"); }
/* 23 */   public AuthenticatorException(String message, Throwable cause) { throw new RuntimeException("Stub!"); }
/* 24 */   public AuthenticatorException(Throwable cause) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\accounts\AuthenticatorException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
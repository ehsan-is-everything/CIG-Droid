/*    */ package android.accounts;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OperationCanceledException
/*    */   extends AccountsException
/*    */ {
/* 20 */   public OperationCanceledException() { throw new RuntimeException("Stub!"); }
/* 21 */   public OperationCanceledException(String message) { throw new RuntimeException("Stub!"); }
/* 22 */   public OperationCanceledException(String message, Throwable cause) { throw new RuntimeException("Stub!"); }
/* 23 */   public OperationCanceledException(Throwable cause) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\accounts\OperationCanceledException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
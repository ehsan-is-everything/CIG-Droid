/*    */ package android.drm;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DrmSupportInfo
/*    */ {
/* 20 */   public DrmSupportInfo() { throw new RuntimeException("Stub!"); }
/* 21 */   public void addMimeType(String mimeType) { throw new RuntimeException("Stub!"); }
/* 22 */   public void addFileSuffix(String fileSuffix) { throw new RuntimeException("Stub!"); }
/* 23 */   public Iterator<String> getMimeTypeIterator() { throw new RuntimeException("Stub!"); }
/* 24 */   public Iterator<String> getFileSuffixIterator() { throw new RuntimeException("Stub!"); }
/* 25 */   public void setDescription(String description) { throw new RuntimeException("Stub!"); }
/*    */   @Deprecated
/* 27 */   public String getDescriprition() { throw new RuntimeException("Stub!"); }
/* 28 */   public String getDescription() { throw new RuntimeException("Stub!"); }
/* 29 */   public int hashCode() { throw new RuntimeException("Stub!"); }
/* 30 */   public boolean equals(Object object) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\drm\DrmSupportInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.drm;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DrmUtils
/*    */ {
/*    */   public static class ExtendedMetadataParser
/*    */   {
/* 22 */     ExtendedMetadataParser() { throw new RuntimeException("Stub!"); }
/* 23 */     public Iterator<String> iterator() { throw new RuntimeException("Stub!"); }
/* 24 */     public Iterator<String> keyIterator() { throw new RuntimeException("Stub!"); }
/* 25 */     public String get(String key) { throw new RuntimeException("Stub!"); } }
/*    */   
/* 27 */   public DrmUtils() { throw new RuntimeException("Stub!"); }
/* 28 */   public static ExtendedMetadataParser getExtendedMetadataParser(byte[] extendedMetadata) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\drm\DrmUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
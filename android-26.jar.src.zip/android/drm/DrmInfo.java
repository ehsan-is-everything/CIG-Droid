/*    */ package android.drm;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DrmInfo
/*    */ {
/* 20 */   public DrmInfo(int infoType, byte[] data, String mimeType) { throw new RuntimeException("Stub!"); }
/* 21 */   public DrmInfo(int infoType, String path, String mimeType) { throw new RuntimeException("Stub!"); }
/* 22 */   public void put(String key, Object value) { throw new RuntimeException("Stub!"); }
/* 23 */   public Object get(String key) { throw new RuntimeException("Stub!"); }
/* 24 */   public Iterator<String> keyIterator() { throw new RuntimeException("Stub!"); }
/* 25 */   public Iterator<Object> iterator() { throw new RuntimeException("Stub!"); }
/* 26 */   public byte[] getData() { throw new RuntimeException("Stub!"); }
/* 27 */   public String getMimeType() { throw new RuntimeException("Stub!"); }
/* 28 */   public int getInfoType() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\drm\DrmInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
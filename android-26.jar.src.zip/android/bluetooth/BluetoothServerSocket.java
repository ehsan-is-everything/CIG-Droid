/*    */ package android.bluetooth;
/*    */ 
/*    */ import java.io.Closeable;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BluetoothServerSocket
/*    */   implements Closeable
/*    */ {
/* 21 */   BluetoothServerSocket() { throw new RuntimeException("Stub!"); }
/* 22 */   public BluetoothSocket accept() throws IOException { throw new RuntimeException("Stub!"); }
/* 23 */   public BluetoothSocket accept(int timeout) throws IOException { throw new RuntimeException("Stub!"); }
/* 24 */   public void close() throws IOException { throw new RuntimeException("Stub!"); }
/* 25 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\bluetooth\BluetoothServerSocket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
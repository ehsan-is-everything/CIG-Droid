/*    */ package android.hardware.camera2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CaptureFailure
/*    */ {
/*    */   public static final int REASON_ERROR = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final int REASON_FLUSHED = 1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 19 */   CaptureFailure() { throw new RuntimeException("Stub!"); }
/* 20 */   public CaptureRequest getRequest() { throw new RuntimeException("Stub!"); }
/* 21 */   public long getFrameNumber() { throw new RuntimeException("Stub!"); }
/* 22 */   public int getReason() { throw new RuntimeException("Stub!"); }
/* 23 */   public boolean wasImageCaptured() { throw new RuntimeException("Stub!"); }
/* 24 */   public int getSequenceId() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\hardware\camera2\CaptureFailure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.hardware.camera2.params;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class InputConfiguration
/*    */ {
/* 20 */   public InputConfiguration(int width, int height, int format) { throw new RuntimeException("Stub!"); }
/* 21 */   public int getWidth() { throw new RuntimeException("Stub!"); }
/* 22 */   public int getHeight() { throw new RuntimeException("Stub!"); }
/* 23 */   public int getFormat() { throw new RuntimeException("Stub!"); }
/* 24 */   public boolean equals(Object obj) { throw new RuntimeException("Stub!"); }
/* 25 */   public int hashCode() { throw new RuntimeException("Stub!"); }
/* 26 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\hardware\camera2\params\InputConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.hardware;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TriggerEvent
/*    */ {
/*    */   public Sensor sensor;
/*    */   
/*    */ 
/*    */ 
/*    */   public long timestamp;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   TriggerEvent()
/*    */   {
/* 20 */     throw new RuntimeException("Stub!");
/*    */   }
/*    */   
/* 23 */   public final float[] values = null;
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\hardware\TriggerEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
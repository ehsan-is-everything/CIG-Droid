/*    */ package android.content.pm;
/*    */ 
/*    */ import android.os.Parcel;
/*    */ import android.os.Parcelable;
/*    */ import android.os.Parcelable.Creator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Signature
/*    */   implements Parcelable
/*    */ {
/* 21 */   public Signature(byte[] signature) { throw new RuntimeException("Stub!"); }
/* 22 */   public Signature(String text) { throw new RuntimeException("Stub!"); }
/* 23 */   public char[] toChars() { throw new RuntimeException("Stub!"); }
/* 24 */   public char[] toChars(char[] existingArray, int[] outLen) { throw new RuntimeException("Stub!"); }
/* 25 */   public String toCharsString() { throw new RuntimeException("Stub!"); }
/* 26 */   public byte[] toByteArray() { throw new RuntimeException("Stub!"); }
/* 27 */   public boolean equals(Object obj) { throw new RuntimeException("Stub!"); }
/* 28 */   public int hashCode() { throw new RuntimeException("Stub!"); }
/* 29 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/* 30 */   public void writeToParcel(Parcel dest, int parcelableFlags) { throw new RuntimeException("Stub!"); }
/*    */   
/* 32 */   public static final Parcelable.Creator<Signature> CREATOR = null;
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\content\pm\Signature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
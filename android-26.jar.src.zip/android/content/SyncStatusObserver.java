package android.content;

public abstract interface SyncStatusObserver
{
  public abstract void onStatusChanged(int paramInt);
}


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\content\SyncStatusObserver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
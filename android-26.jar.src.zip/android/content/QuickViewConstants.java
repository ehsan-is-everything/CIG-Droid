/*    */ package android.content;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QuickViewConstants
/*    */ {
/*    */   public static final String FEATURE_DOWNLOAD = "android:download";
/*    */   
/*    */   public static final String FEATURE_EDIT = "android:edit";
/*    */   
/*    */   public static final String FEATURE_PRINT = "android:print";
/*    */   
/*    */   public static final String FEATURE_SEND = "android:send";
/*    */   
/*    */   public static final String FEATURE_VIEW = "android:view";
/*    */   
/*    */ 
/*    */   QuickViewConstants()
/*    */   {
/* 20 */     throw new RuntimeException("Stub!");
/*    */   }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\content\QuickViewConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
package android.content;

import android.content.res.Configuration;

public abstract interface ComponentCallbacks
{
  public abstract void onConfigurationChanged(Configuration paramConfiguration);
  
  public abstract void onLowMemory();
}


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\content\ComponentCallbacks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.content.res;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObbScanner
/*    */ {
/* 20 */   ObbScanner() { throw new RuntimeException("Stub!"); }
/* 21 */   public static ObbInfo getObbInfo(String filePath) throws IOException { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\content\res\ObbScanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
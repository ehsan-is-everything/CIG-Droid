package android.graphics.drawable;

public abstract interface Animatable
{
  public abstract void start();
  
  public abstract void stop();
  
  public abstract boolean isRunning();
}


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\graphics\drawable\Animatable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
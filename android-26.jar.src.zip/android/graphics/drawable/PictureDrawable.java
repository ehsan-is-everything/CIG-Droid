/*    */ package android.graphics.drawable;
/*    */ 
/*    */ import android.graphics.Canvas;
/*    */ import android.graphics.ColorFilter;
/*    */ import android.graphics.Picture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PictureDrawable
/*    */   extends Drawable
/*    */ {
/* 21 */   public PictureDrawable(Picture picture) { throw new RuntimeException("Stub!"); }
/* 22 */   public Picture getPicture() { throw new RuntimeException("Stub!"); }
/* 23 */   public void setPicture(Picture picture) { throw new RuntimeException("Stub!"); }
/* 24 */   public void draw(Canvas canvas) { throw new RuntimeException("Stub!"); }
/* 25 */   public int getIntrinsicWidth() { throw new RuntimeException("Stub!"); }
/* 26 */   public int getIntrinsicHeight() { throw new RuntimeException("Stub!"); }
/* 27 */   public int getOpacity() { throw new RuntimeException("Stub!"); }
/* 28 */   public void setColorFilter(ColorFilter colorFilter) { throw new RuntimeException("Stub!"); }
/* 29 */   public void setAlpha(int alpha) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\graphics\drawable\PictureDrawable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
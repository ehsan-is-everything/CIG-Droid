/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColorMatrixColorFilter
/*    */   extends ColorFilter
/*    */ {
/* 21 */   public ColorMatrixColorFilter(ColorMatrix matrix) { throw new RuntimeException("Stub!"); }
/* 22 */   public ColorMatrixColorFilter(float[] array) { throw new RuntimeException("Stub!"); }
/* 23 */   public void getColorMatrix(ColorMatrix colorMatrix) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\graphics\ColorMatrixColorFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BitmapShader
/*    */   extends Shader
/*    */ {
/*    */   public BitmapShader(Bitmap bitmap, Shader.TileMode tileX, Shader.TileMode tileY)
/*    */   {
/* 21 */     throw new RuntimeException("Stub!");
/*    */   }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\graphics\BitmapShader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
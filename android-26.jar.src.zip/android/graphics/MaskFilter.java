/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MaskFilter
/*    */ {
/* 20 */   public MaskFilter() { throw new RuntimeException("Stub!"); }
/* 21 */   protected void finalize() throws Throwable { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\graphics\MaskFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.graphics.fonts;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FontVariationAxis
/*    */ {
/* 20 */   public FontVariationAxis(String tagString, float styleValue) { throw new RuntimeException("Stub!"); }
/* 21 */   public String getTag() { throw new RuntimeException("Stub!"); }
/* 22 */   public float getStyleValue() { throw new RuntimeException("Stub!"); }
/* 23 */   public String toString() { throw new RuntimeException("Stub!"); }
/* 24 */   public static FontVariationAxis[] fromFontVariationSettings(String settings) { throw new RuntimeException("Stub!"); }
/* 25 */   public static String toFontVariationSettings(FontVariationAxis[] axes) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\graphics\fonts\FontVariationAxis.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SweepGradient
/*    */   extends Shader
/*    */ {
/* 21 */   public SweepGradient(float cx, float cy, int[] colors, float[] positions) { throw new RuntimeException("Stub!"); }
/* 22 */   public SweepGradient(float cx, float cy, int color0, int color1) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\graphics\SweepGradient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
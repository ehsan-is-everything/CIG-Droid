/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmbossMaskFilter
/*    */   extends MaskFilter
/*    */ {
/*    */   public EmbossMaskFilter(float[] direction, float ambient, float specular, float blurRadius)
/*    */   {
/* 21 */     throw new RuntimeException("Stub!");
/*    */   }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\graphics\EmbossMaskFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.graphics;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Picture
/*    */ {
/* 20 */   public Picture() { throw new RuntimeException("Stub!"); }
/* 21 */   public Picture(Picture src) { throw new RuntimeException("Stub!"); }
/* 22 */   protected void finalize() throws Throwable { throw new RuntimeException("Stub!"); }
/* 23 */   public Canvas beginRecording(int width, int height) { throw new RuntimeException("Stub!"); }
/* 24 */   public void endRecording() { throw new RuntimeException("Stub!"); }
/* 25 */   public int getWidth() { throw new RuntimeException("Stub!"); }
/* 26 */   public int getHeight() { throw new RuntimeException("Stub!"); }
/* 27 */   public void draw(Canvas canvas) { throw new RuntimeException("Stub!"); }
/*    */   @Deprecated
/* 29 */   public static Picture createFromStream(InputStream stream) { throw new RuntimeException("Stub!"); }
/*    */   @Deprecated
/* 31 */   public void writeToStream(OutputStream stream) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\graphics\Picture.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
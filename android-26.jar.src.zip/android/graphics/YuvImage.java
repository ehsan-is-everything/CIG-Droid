/*    */ package android.graphics;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class YuvImage
/*    */ {
/* 20 */   public YuvImage(byte[] yuv, int format, int width, int height, int[] strides) { throw new RuntimeException("Stub!"); }
/* 21 */   public boolean compressToJpeg(Rect rectangle, int quality, OutputStream stream) { throw new RuntimeException("Stub!"); }
/* 22 */   public byte[] getYuvData() { throw new RuntimeException("Stub!"); }
/* 23 */   public int getYuvFormat() { throw new RuntimeException("Stub!"); }
/* 24 */   public int[] getStrides() { throw new RuntimeException("Stub!"); }
/* 25 */   public int getWidth() { throw new RuntimeException("Stub!"); }
/* 26 */   public int getHeight() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\graphics\YuvImage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
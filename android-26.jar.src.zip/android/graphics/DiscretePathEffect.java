/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DiscretePathEffect
/*    */   extends PathEffect
/*    */ {
/*    */   public DiscretePathEffect(float segmentLength, float deviation)
/*    */   {
/* 21 */     throw new RuntimeException("Stub!");
/*    */   }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\graphics\DiscretePathEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
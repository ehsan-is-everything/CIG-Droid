/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NinePatch
/*    */ {
/* 20 */   public NinePatch(Bitmap bitmap, byte[] chunk) { throw new RuntimeException("Stub!"); }
/* 21 */   public NinePatch(Bitmap bitmap, byte[] chunk, String srcName) { throw new RuntimeException("Stub!"); }
/* 22 */   protected void finalize() throws Throwable { throw new RuntimeException("Stub!"); }
/* 23 */   public String getName() { throw new RuntimeException("Stub!"); }
/* 24 */   public Paint getPaint() { throw new RuntimeException("Stub!"); }
/* 25 */   public void setPaint(Paint p) { throw new RuntimeException("Stub!"); }
/* 26 */   public Bitmap getBitmap() { throw new RuntimeException("Stub!"); }
/* 27 */   public void draw(Canvas canvas, RectF location) { throw new RuntimeException("Stub!"); }
/* 28 */   public void draw(Canvas canvas, Rect location) { throw new RuntimeException("Stub!"); }
/* 29 */   public void draw(Canvas canvas, Rect location, Paint paint) { throw new RuntimeException("Stub!"); }
/* 30 */   public int getDensity() { throw new RuntimeException("Stub!"); }
/* 31 */   public int getWidth() { throw new RuntimeException("Stub!"); }
/* 32 */   public int getHeight() { throw new RuntimeException("Stub!"); }
/* 33 */   public final boolean hasAlpha() { throw new RuntimeException("Stub!"); }
/* 34 */   public final Region getTransparentRegion(Rect bounds) { throw new RuntimeException("Stub!"); }
/*    */   
/*    */   public static native boolean isNinePatchChunk(byte[] paramArrayOfByte);
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\graphics\NinePatch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegionIterator
/*    */ {
/* 20 */   public RegionIterator(Region region) { throw new RuntimeException("Stub!"); }
/* 21 */   public final boolean next(Rect r) { throw new RuntimeException("Stub!"); }
/* 22 */   protected void finalize() throws Throwable { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\graphics\RegionIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
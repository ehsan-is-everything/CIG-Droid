/*    */ package android.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PorterDuffColorFilter
/*    */   extends ColorFilter
/*    */ {
/* 21 */   public PorterDuffColorFilter(int color, PorterDuff.Mode mode) { throw new RuntimeException("Stub!"); }
/* 22 */   public boolean equals(Object object) { throw new RuntimeException("Stub!"); }
/* 23 */   public int hashCode() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\graphics\PorterDuffColorFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
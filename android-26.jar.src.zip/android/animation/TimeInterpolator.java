package android.animation;

public abstract interface TimeInterpolator
{
  public abstract float getInterpolation(float paramFloat);
}


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\animation\TimeInterpolator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package android.animation;
/*    */ 
/*    */ import android.content.Context;
/*    */ import android.content.res.Resources.NotFoundException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnimatorInflater
/*    */ {
/* 19 */   public AnimatorInflater() { throw new RuntimeException("Stub!"); }
/* 20 */   public static Animator loadAnimator(Context context, int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 21 */   public static StateListAnimator loadStateListAnimator(Context context, int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\animation\AnimatorInflater.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
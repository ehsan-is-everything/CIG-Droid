/*    */ package android.animation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntArrayEvaluator
/*    */   implements TypeEvaluator<int[]>
/*    */ {
/* 21 */   public IntArrayEvaluator() { throw new RuntimeException("Stub!"); }
/* 22 */   public IntArrayEvaluator(int[] reuseArray) { throw new RuntimeException("Stub!"); }
/* 23 */   public int[] evaluate(float fraction, int[] startValue, int[] endValue) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\animation\IntArrayEvaluator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
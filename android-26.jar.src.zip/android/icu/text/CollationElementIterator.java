/*    */ package android.icu.text;
/*    */ 
/*    */ import java.text.CharacterIterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CollationElementIterator
/*    */ {
/*    */   public static final int IGNORABLE = 0;
/*    */   public static final int NULLORDER = -1;
/*    */   
/* 13 */   CollationElementIterator() { throw new RuntimeException("Stub!"); }
/* 14 */   public static final int primaryOrder(int ce) { throw new RuntimeException("Stub!"); }
/* 15 */   public static final int secondaryOrder(int ce) { throw new RuntimeException("Stub!"); }
/* 16 */   public static final int tertiaryOrder(int ce) { throw new RuntimeException("Stub!"); }
/* 17 */   public int getOffset() { throw new RuntimeException("Stub!"); }
/* 18 */   public int next() { throw new RuntimeException("Stub!"); }
/* 19 */   public int previous() { throw new RuntimeException("Stub!"); }
/* 20 */   public void reset() { throw new RuntimeException("Stub!"); }
/* 21 */   public void setOffset(int newOffset) { throw new RuntimeException("Stub!"); }
/* 22 */   public void setText(String source) { throw new RuntimeException("Stub!"); }
/* 23 */   public void setText(UCharacterIterator source) { throw new RuntimeException("Stub!"); }
/* 24 */   public void setText(CharacterIterator source) { throw new RuntimeException("Stub!"); }
/* 25 */   public int getMaxExpansion(int ce) { throw new RuntimeException("Stub!"); }
/* 26 */   public boolean equals(Object that) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\icu\text\CollationElementIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
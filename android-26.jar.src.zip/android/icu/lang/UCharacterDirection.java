/*    */ package android.icu.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class UCharacterDirection
/*    */   implements UCharacterEnums.ECharacterDirection
/*    */ {
/* 15 */   UCharacterDirection() { throw new RuntimeException("Stub!"); }
/* 16 */   public static String toString(int dir) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\android-jar\android-26.jar!\android\icu\lang\UCharacterDirection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
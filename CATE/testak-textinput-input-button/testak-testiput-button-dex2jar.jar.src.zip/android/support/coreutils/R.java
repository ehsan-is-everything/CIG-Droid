package android.support.coreutils;

public final class R {}


/* Location:              C:\Users\Lab\Desktop\testak-testiput-button-dex2jar.jar!\android\support\coreutils\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.support.fragment;

public final class R {}


/* Location:              C:\Users\Lab\Desktop\testak-testiput-button-dex2jar.jar!\android\support\fragment\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package com.topjohnwu.snet;

public interface SafetyNetCallback {
    void onResponse(int responseCode);
}

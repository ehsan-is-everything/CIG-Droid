# Wifi_Direct
File transfer is an android application used for transfering filesbetween two devices using Wifi-Direct technology.   
Chat application is also an android app using for chatting between two device using Wifi-Direct technology.
Group members:
Aditya Raj 
Arjun Jha 
Tushar Mittal 
Siva Sutapali Baba
Marshal Kumar Gond

# Simple-Accounting
Android app that helps you balance: https://play.google.com/store/apps/details?id=com.emmanuelmess.simpleaccounting

### Main
<img src="Screenshot_1491862500.png" data-canonical-src="Screenshot_1491862500.png" height="350" /> <img src="Screenshot_1491862506.png" data-canonical-src="Screenshot_1491862506.png" height="350" /> <img src="Screenshot_1491945273.png" data-canonical-src="Screenshot_1491945273.png" height="350" /> <img src="Screenshot_1491945294.png" data-canonical-src="Screenshot_1491945294.png" height="350" />

### Settings
<img src="Screenshot_1491862511.png" data-canonical-src="Screenshot_1491862511.png" height="350" /> <img src="Screenshot_1491945261.png" data-canonical-src="Screenshot_1491945261.png" height="350" /> <img src="Screenshot_1491945267.png" data-canonical-src="Screenshot_1491945267.png" height="350" />

### Month selection
<img src="Screenshot_1491945314.png" data-canonical-src="Screenshot_1491945314.png" height="350" />

### Printing
<img src="Screenshot_1491945299.png" data-canonical-src="Screenshot_1491945299.png" height="350" />

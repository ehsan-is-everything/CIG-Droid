package io.github.hidroh.tldroid

interface Constants {

  companion object {
    const val ZIP_FILENAME = "tldr.zip"
    const val COMMAND_PATH = "pages/%s/%2s.md"
  }

}
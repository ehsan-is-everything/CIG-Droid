DroidOVPN
======

An unofficial [VPN Gate](http://www.vpngate.net/en/) client app for Android.

<img src="/screenshots/vpn_servers.png" width="33%" /> <img src="/screenshots/vpn_server_details.png" width="33%" />

License
-------

DroidOVPN is licensed under the [GNU General Public License v3.0 License](https://www.gnu.org/licenses/gpl.html).

TODO
======

- [x] Show server details
- [x] Import profile to OpenVPN Connect app (net.openvpn.openvpn)
- [x] Import profile to OpenVPN for Android app (de.blinkt.openvpn)
- [x] Cache recently fetched servers
- [x] Sort the list of servers
- [x] Share .ovpn server profile
- [ ] Add server to favorites
- [ ] Settings
  - [ ] Select the desired mirror sites
  - [ ] Select source of VPN Gate servers (parsed from HTML or CSV)

package net.codersgarage.iseeu.models;

/**
 * Created by s4kib on 6/16/16.
 */

public class BusAction {
    private boolean isStart;

    public BusAction(boolean isStart) {
        this.isStart = isStart;
    }

    public boolean isStart() {
        return isStart;
    }
}

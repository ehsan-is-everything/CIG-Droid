package com.sketchpunk.ocomicreader;

import android.app.Application;
//TODO Can Delete.
public class App extends Application{
	@Override
	public void onCreate(){ super.onCreate(); }//func
}//cls

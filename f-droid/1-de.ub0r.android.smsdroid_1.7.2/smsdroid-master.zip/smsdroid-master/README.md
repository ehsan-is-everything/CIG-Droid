# SMSdroid

SMSdroid is a light and fast app for reading and sending text messages.
It is optimized to play well with any app capable of sending messages.
A good example is [WebSMS](https://github.com/felixb/websms).

## Translation

Help translating this app to your favorite langauge on [crowdin](https://crowdin.com/project/smsdroid/invite)

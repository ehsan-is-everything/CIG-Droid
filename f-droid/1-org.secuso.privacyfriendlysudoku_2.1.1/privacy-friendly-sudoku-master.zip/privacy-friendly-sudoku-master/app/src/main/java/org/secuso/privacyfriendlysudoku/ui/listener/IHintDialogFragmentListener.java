package org.secuso.privacyfriendlysudoku.ui.listener;

/**
 * Created by Chris on 17.01.2016.
 */
public interface IHintDialogFragmentListener {
    public void onHintDialogPositiveClick();
    public void onDialogNegativeClick();
}

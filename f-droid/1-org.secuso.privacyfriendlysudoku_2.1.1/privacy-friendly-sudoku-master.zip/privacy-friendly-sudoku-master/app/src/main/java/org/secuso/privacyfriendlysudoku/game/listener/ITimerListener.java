package org.secuso.privacyfriendlysudoku.game.listener;

/**
 * Created by TMZ_LToP on 20.11.2015.
 */
public interface ITimerListener {
    public void onTick(int time);
}

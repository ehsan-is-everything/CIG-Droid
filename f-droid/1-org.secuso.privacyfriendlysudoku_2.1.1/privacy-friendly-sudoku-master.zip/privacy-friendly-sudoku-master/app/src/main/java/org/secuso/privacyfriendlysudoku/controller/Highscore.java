package org.secuso.privacyfriendlysudoku.controller;

/**
 * Created by Chris on 17.11.2015.
 */
public class Highscore {

}

package org.secuso.privacyfriendlysudoku.ui.listener;

/**
 * Created by Chris on 24.11.2015.
 */
public interface IDeleteDialogFragmentListener {
    public void onDialogPositiveClick(int position);
    public void onDialogNegativeClick(int position);
}
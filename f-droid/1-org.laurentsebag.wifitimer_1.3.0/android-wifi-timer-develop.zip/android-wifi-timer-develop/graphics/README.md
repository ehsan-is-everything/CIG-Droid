This folder contains all the graphic assets that were created for this
project.

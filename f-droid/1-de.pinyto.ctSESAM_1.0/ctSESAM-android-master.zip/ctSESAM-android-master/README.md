# ctSESAM-android
This is the Android version of the c't SESAM password manager. 

There might be other implementations of c't SESAM for other platforms.

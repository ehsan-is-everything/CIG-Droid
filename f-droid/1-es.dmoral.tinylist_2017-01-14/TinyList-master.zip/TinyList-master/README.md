# TinyList
<img src="./art/512icon.png" width="128px" height="128px"/> <a href='https://play.google.com/store/apps/details?id=es.dmoral.tinylist&utm_source=global_co&utm_medium=prtnr&utm_content=Mar2515&utm_campaign=PartBadge&pcampaignid=MKT-Other-global-all-co-prtnr-ap-PartBadge-Mar2515-1'><img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/images/apps/en-play-badge.png' width="128px"/></a>
<p>Just a tiny list app.</p>

# Images
<img src="./art/device-2016-01-17-160529.png" width="250px"/>
<img src="./art/device-2016-01-17-160641.png" width="250px"/>
<img src="./art/device-2016-01-17-160659.png" width="250px"/>


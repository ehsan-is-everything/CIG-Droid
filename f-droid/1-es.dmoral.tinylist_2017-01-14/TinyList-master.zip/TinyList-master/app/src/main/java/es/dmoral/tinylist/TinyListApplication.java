package es.dmoral.tinylist;

import android.app.Application;

/**
 * Created by grender on 13/01/16.
 * <p>
 * This class represents the entire Application's context (Android best practices)
 */
public class TinyListApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}

# Paperwork-Android

Android App for [Paperwork](https://github.com/twostairs/paperwork)

![Screenshot1](https://i.imgur.com/8tjOTVo.png)
![Screenshot2](https://i.imgur.com/lnfhiUR.png)

Building
---------

1. Install Android Studio
2. Import the project into Android Studio
3. Install Android Support library
4. Gradle should fetch all needed libraries




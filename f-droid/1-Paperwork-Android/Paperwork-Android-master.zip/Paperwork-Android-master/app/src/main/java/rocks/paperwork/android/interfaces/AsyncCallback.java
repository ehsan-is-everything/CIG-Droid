package rocks.paperwork.android.interfaces;


public interface AsyncCallback
{
    void updateView();
}

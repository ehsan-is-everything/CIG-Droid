package com.arcao.geocaching4locus.constants;

public interface CrashlyticsConstants {
  String LOCUS_PACKAGE = "LOCUS_PACKAGE";
  String LOCUS_VERSION = "LOCUS_VERSION";
  String PREMIUM_MEMBER = "PREMIUM_MEMBER";
}

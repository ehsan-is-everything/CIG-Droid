package com.arcao.geocaching4locus;

import android.support.v7.app.AppCompatActivity;

public abstract class AbstractActionBarActivity extends AppCompatActivity {
}

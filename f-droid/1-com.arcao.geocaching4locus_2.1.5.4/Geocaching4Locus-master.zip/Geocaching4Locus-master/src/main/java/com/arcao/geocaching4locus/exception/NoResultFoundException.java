package com.arcao.geocaching4locus.exception;

public class NoResultFoundException extends Exception {
	private static final long serialVersionUID = -661856468973373380L;
}

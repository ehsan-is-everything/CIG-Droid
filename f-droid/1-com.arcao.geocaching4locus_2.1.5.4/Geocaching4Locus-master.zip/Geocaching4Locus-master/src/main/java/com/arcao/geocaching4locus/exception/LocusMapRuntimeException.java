package com.arcao.geocaching4locus.exception;

public class LocusMapRuntimeException extends RuntimeException {
	private static final long serialVersionUID = -4019163571054565979L;

	public LocusMapRuntimeException(Throwable cause) {
		super(cause);
	}
}

package io.github.xSocks;

import android.app.Application;

public class xSocksApplication extends Application {

    @Override
    public void onCreate() {
    }
}

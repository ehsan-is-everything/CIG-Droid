v1.5.0 (2015-10-21)
-----------
* Change: rename program


v1.4.0 (2015-10-18)
-----------
* Feature: Protect VpnService
* Change: Black list


v1.3.0 (2015-10-9)
-----------
* Feature: Support ACL
* Feature: Add App Manager
* Change: Adjust Route policy


v1.2.2 (2015-9-16)
-----------
* Hotfix: crypto initialization


v1.2.1 (2015-9-12)
-----------
* Change: update 3rd library to latest
* Change: update appcompat
* Change: update xsocks's arguments


v1.2.0 (2015-6-07)
-----------
* Change: json instead of realm for profile store
* Change: Remove libsuperuser


v1.1.7 (2015-5-22)
-----------
* Change: Remove snackbar action
* Change: Remove redundant code and icon


v1.1.6 (2015-5-20)
-----------
* The first public version.

package com.QuarkLabs.BTCeClient.interfaces;

public interface ActivityCallbacks {
    void makeNotification(int id, String message);
}

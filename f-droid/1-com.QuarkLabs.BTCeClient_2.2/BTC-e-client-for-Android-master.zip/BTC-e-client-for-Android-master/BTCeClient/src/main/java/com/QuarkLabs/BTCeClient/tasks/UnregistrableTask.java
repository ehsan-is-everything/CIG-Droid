package com.QuarkLabs.BTCeClient.tasks;

public interface UnregistrableTask {

    void unregisterListener();
}

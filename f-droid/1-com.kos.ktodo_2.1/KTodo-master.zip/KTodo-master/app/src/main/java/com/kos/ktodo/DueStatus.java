package com.kos.ktodo;

public enum DueStatus {
	NONE, EXPIRED, TODAY, FUTURE
}

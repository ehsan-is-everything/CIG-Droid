Harass Me is copyright (c) 2010-2011 Samuel Tardieu <sam@rfc1149.net>

It is available under the GNU General Public License version 3.
See the file COPYING in this directory for more information.
